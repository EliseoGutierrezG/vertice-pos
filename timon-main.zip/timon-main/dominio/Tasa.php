<?php
declare(strict_types=1);

namespace Dominio;

use InvalidArgumentException;

/**
 * Una tasa de impuesto: 0.1600, 0.2650.
 *
 * Se guarda como entero en diezmilésimas, igual que la columna
 * `DECIMAL(6,4)` de la que sale. Nunca se escribe una tasa en el código: una
 * Tasa siempre viene de la base, con su vigencia.
 */
final class Tasa
{
    public const ESCALA_PUBLICA = 10000;
    private const ESCALA = self::ESCALA_PUBLICA;

    private function __construct(private int $diezmilesimas)
    {
    }

    /** Desde lo que devuelve la base: "0.1600". */
    public static function deCadena(string $valor): self
    {
        $valor = trim($valor);

        if (preg_match('/^-?\d+(\.\d+)?$/', $valor) !== 1) {
            throw new InvalidArgumentException('No es una tasa: "' . $valor . '"');
        }

        return new self(Escala::aEntero($valor, self::ESCALA));
    }

    public static function cero(): self
    {
        return new self(0);
    }

    /** La propia tasa más uno: 0.16 → 1.16. Para dividir un precio neto. */
    public function masUno(): self
    {
        return new self($this->diezmilesimas + self::ESCALA);
    }

    public function esCero(): bool
    {
        return $this->diezmilesimas === 0;
    }

    public function diezmilesimas(): int
    {
        return $this->diezmilesimas;
    }

    public function aCadena(): string
    {
        return Escala::aCadena($this->diezmilesimas, self::ESCALA, 4);
    }
}
