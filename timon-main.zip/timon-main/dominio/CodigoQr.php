<?php
declare(strict_types=1);

namespace Dominio;

use InvalidArgumentException;

/**
 * Código QR (ISO/IEC 18004) para el alta del segundo factor.
 *
 * Es propio y sin dependencias a propósito: lo que se codifica es la URI
 * `otpauth://` con el secreto del usuario, y ese secreto no debe pasar por
 * código de terceros en el navegador ni por un servicio externo. El servidor
 * arma la matriz y la vista la dibuja como SVG; no hace falta JavaScript.
 *
 * Alcance: modo byte, corrección de errores nivel M (15 %) y versiones 1 a 15,
 * hasta 412 bytes. Una URI de Authenticator mide unos 120.
 */
final class CodigoQr
{
    /**
     * Nivel M por versión: [EC por bloque, bloques grupo 1, datos grupo 1,
     * bloques grupo 2, datos grupo 2]. Tabla 9 de la norma.
     */
    private const BLOQUES_M = [
        1 => [10, 1, 16, 0, 0],   2 => [16, 1, 28, 0, 0],   3 => [26, 1, 44, 0, 0],
        4 => [18, 2, 32, 0, 0],   5 => [24, 2, 43, 0, 0],   6 => [16, 4, 27, 0, 0],
        7 => [18, 4, 31, 0, 0],   8 => [22, 2, 38, 2, 39],  9 => [22, 3, 36, 2, 37],
        10 => [26, 4, 43, 1, 44], 11 => [30, 1, 50, 4, 51], 12 => [22, 6, 36, 2, 37],
        13 => [22, 8, 37, 1, 38], 14 => [24, 4, 40, 5, 41], 15 => [24, 5, 41, 5, 42],
    ];

    /** Bits del nivel M en la información de formato. */
    private const NIVEL_M = 0;

    private int $version;
    private int $tamano;
    /** @var list<list<bool>> */
    private array $modulos = [];
    /** @var list<list<bool>> */
    private array $esFuncion = [];

    private function __construct(string $texto)
    {
        $this->version = self::versionPara(strlen($texto));
        $this->tamano = $this->version * 4 + 17;
        $fila = array_fill(0, $this->tamano, false);
        $this->modulos = array_fill(0, $this->tamano, $fila);
        $this->esFuncion = array_fill(0, $this->tamano, $fila);

        $this->dibujaPatrones();
        $this->colocaDatos($this->entrelaza(self::datos($texto, $this->version)));
        $this->aplicaMejorMascara();
    }

    public static function codifica(string $texto): self
    {
        return new self($texto);
    }

    public function version(): int
    {
        return $this->version;
    }

    public function tamano(): int
    {
        return $this->tamano;
    }

    /** `true` es oscuro. Fila y columna desde la esquina superior izquierda. */
    public function oscuro(int $fila, int $columna): bool
    {
        return $this->modulos[$fila][$columna];
    }

    /** La matriz como renglones de `1` y `0`, para pruebas y depuración. */
    public function comoTexto(): string
    {
        $renglones = [];
        foreach ($this->modulos as $fila) {
            $renglones[] = implode('', array_map(static fn(bool $m): string => $m ? '1' : '0', $fila));
        }
        return implode("\n", $renglones);
    }

    /** Palabras de datos que caben en la versión (sin las de corrección). */
    public static function capacidadDatos(int $version): int
    {
        [, $b1, $d1, $b2, $d2] = self::BLOQUES_M[$version];
        return $b1 * $d1 + $b2 * $d2;
    }

    /** Total de palabras de la versión, deducido de sus módulos. */
    public static function palabrasTotales(int $version): int
    {
        $modulos = (16 * $version + 128) * $version + 64;
        if ($version >= 2) {
            $alineacion = intdiv($version, 7) + 2;
            $modulos -= (25 * $alineacion - 10) * $alineacion - 55;
            if ($version >= 7) $modulos -= 36;
        }
        return intdiv($modulos, 8);
    }

    /** Lo que suma la tabla de bloques, para compararlo con `palabrasTotales`. */
    public static function palabrasDeTabla(int $version): int
    {
        [$ec, $b1, $d1, $b2, $d2] = self::BLOQUES_M[$version];
        return $b1 * ($d1 + $ec) + $b2 * ($d2 + $ec);
    }

    private static function versionPara(int $bytes): int
    {
        foreach (array_keys(self::BLOQUES_M) as $version) {
            $bitsCuenta = $version <= 9 ? 8 : 16;
            if (4 + $bitsCuenta + $bytes * 8 <= self::capacidadDatos($version) * 8) return $version;
        }
        throw new InvalidArgumentException('El texto no cabe en un código QR de versión 15');
    }

    /** @return list<int> palabras de datos con encabezado, terminador y relleno */
    private static function datos(string $texto, int $version): array
    {
        $bits = [];
        $agrega = static function (int $valor, int $largo) use (&$bits): void {
            for ($i = $largo - 1; $i >= 0; $i--) $bits[] = ($valor >> $i) & 1;
        };
        $agrega(0b0100, 4);
        $agrega(strlen($texto), $version <= 9 ? 8 : 16);
        foreach (str_split($texto) as $byte) $agrega(ord($byte), 8);

        $capacidad = self::capacidadDatos($version) * 8;
        $agrega(0, min(4, $capacidad - count($bits)));
        $agrega(0, (8 - count($bits) % 8) % 8);

        $palabras = [];
        foreach (array_chunk($bits, 8) as $octeto) $palabras[] = (int) bindec(implode('', $octeto));
        for ($relleno = 0xEC; count($palabras) < self::capacidadDatos($version); $relleno ^= 0xEC ^ 0x11) {
            $palabras[] = $relleno;
        }
        return $palabras;
    }

    /**
     * Parte en bloques, calcula la corrección de cada uno y entrelaza.
     *
     * @param list<int> $datos
     * @return list<int>
     */
    private function entrelaza(array $datos): array
    {
        [$ec, $b1, $d1, $b2, $d2] = self::BLOQUES_M[$this->version];
        $divisor = self::divisorReedSolomon($ec);
        $bloques = []; $correcciones = []; $inicio = 0;
        foreach (array_merge(array_fill(0, $b1, $d1), array_fill(0, $b2, $d2)) as $largo) {
            $bloque = array_slice($datos, $inicio, $largo);
            $inicio += $largo;
            $bloques[] = $bloque;
            $correcciones[] = self::residuoReedSolomon($bloque, $divisor);
        }

        $resultado = [];
        for ($i = 0, $mayor = max($d1, $d2); $i < $mayor; $i++) {
            foreach ($bloques as $bloque) if ($i < count($bloque)) $resultado[] = $bloque[$i];
        }
        for ($i = 0; $i < $ec; $i++) {
            foreach ($correcciones as $correccion) $resultado[] = $correccion[$i];
        }
        return $resultado;
    }

    /** @return list<int> */
    public static function divisorReedSolomon(int $grado): array
    {
        $resultado = array_fill(0, $grado, 0);
        $resultado[$grado - 1] = 1;
        $raiz = 1;
        for ($i = 0; $i < $grado; $i++) {
            for ($j = 0; $j < $grado; $j++) {
                $resultado[$j] = self::multiplica($resultado[$j], $raiz);
                if ($j + 1 < $grado) $resultado[$j] ^= $resultado[$j + 1];
            }
            $raiz = self::multiplica($raiz, 0x02);
        }
        return $resultado;
    }

    /**
     * @param list<int> $datos
     * @param list<int> $divisor
     * @return list<int>
     */
    public static function residuoReedSolomon(array $datos, array $divisor): array
    {
        $resultado = array_fill(0, count($divisor), 0);
        foreach ($datos as $byte) {
            $factor = $byte ^ array_shift($resultado);
            $resultado[] = 0;
            foreach ($divisor as $i => $coeficiente) $resultado[$i] ^= self::multiplica($coeficiente, $factor);
        }
        return $resultado;
    }

    /** Producto en GF(2⁸) con el polinomio 0x11D. */
    private static function multiplica(int $x, int $y): int
    {
        $z = 0;
        for ($i = 7; $i >= 0; $i--) {
            $z = ($z << 1) ^ (($z >> 7) * 0x11D);
            $z ^= (($y >> $i) & 1) * $x;
        }
        return $z;
    }

    private function dibujaPatrones(): void
    {
        for ($i = 0; $i < $this->tamano; $i++) {
            $this->funcion($i, 6, $i % 2 === 0);
            $this->funcion(6, $i, $i % 2 === 0);
        }
        $this->localizador(3, 3);
        $this->localizador($this->tamano - 4, 3);
        $this->localizador(3, $this->tamano - 4);

        $posiciones = $this->posicionesAlineacion();
        $ultimo = count($posiciones) - 1;
        foreach ($posiciones as $i => $x) {
            foreach ($posiciones as $j => $y) {
                if (($i === 0 && $j === 0) || ($i === 0 && $j === $ultimo) || ($i === $ultimo && $j === 0)) continue;
                for ($dy = -2; $dy <= 2; $dy++) {
                    for ($dx = -2; $dx <= 2; $dx++) $this->funcion($x + $dx, $y + $dy, max(abs($dx), abs($dy)) !== 1);
                }
            }
        }

        $this->formato(0); // reserva el área; se escribe de verdad con la máscara elegida
        $this->informacionVersion();
    }

    private function localizador(int $x, int $y): void
    {
        for ($dy = -4; $dy <= 4; $dy++) {
            for ($dx = -4; $dx <= 4; $dx++) {
                $distancia = max(abs($dx), abs($dy));
                $xx = $x + $dx; $yy = $y + $dy;
                if ($xx >= 0 && $xx < $this->tamano && $yy >= 0 && $yy < $this->tamano) {
                    $this->funcion($xx, $yy, $distancia !== 2 && $distancia !== 4);
                }
            }
        }
    }

    /** @return list<int> */
    private function posicionesAlineacion(): array
    {
        if ($this->version === 1) return [];
        $cuantas = intdiv($this->version, 7) + 2;
        $paso = (int) ceil(($this->version * 4 + 4) / ($cuantas * 2 - 2)) * 2;
        $posiciones = [];
        for ($i = 0, $p = $this->tamano - 7; $i < $cuantas - 1; $i++, $p -= $paso) array_unshift($posiciones, $p);
        array_unshift($posiciones, 6);
        return $posiciones;
    }

    private function formato(int $mascara): void
    {
        $dato = self::NIVEL_M << 3 | $mascara;
        $residuo = $dato;
        for ($i = 0; $i < 10; $i++) $residuo = ($residuo << 1) ^ (($residuo >> 9) * 0x537);
        $bits = ($dato << 10 | $residuo) ^ 0x5412;
        $bit = static fn(int $i): bool => (($bits >> $i) & 1) !== 0;

        for ($i = 0; $i <= 5; $i++) $this->funcion(8, $i, $bit($i));
        $this->funcion(8, 7, $bit(6));
        $this->funcion(8, 8, $bit(7));
        $this->funcion(7, 8, $bit(8));
        for ($i = 9; $i < 15; $i++) $this->funcion(14 - $i, 8, $bit($i));

        for ($i = 0; $i < 8; $i++) $this->funcion($this->tamano - 1 - $i, 8, $bit($i));
        for ($i = 8; $i < 15; $i++) $this->funcion(8, $this->tamano - 15 + $i, $bit($i));
        $this->funcion(8, $this->tamano - 8, true);
    }

    private function informacionVersion(): void
    {
        if ($this->version < 7) return;
        $residuo = $this->version;
        for ($i = 0; $i < 12; $i++) $residuo = ($residuo << 1) ^ (($residuo >> 11) * 0x1F25);
        $bits = $this->version << 12 | $residuo;
        for ($i = 0; $i < 18; $i++) {
            $oscuro = (($bits >> $i) & 1) !== 0;
            $a = $this->tamano - 11 + $i % 3;
            $b = intdiv($i, 3);
            $this->funcion($a, $b, $oscuro);
            $this->funcion($b, $a, $oscuro);
        }
    }

    /** @param list<int> $palabras */
    private function colocaDatos(array $palabras): void
    {
        $i = 0; $total = count($palabras) * 8;
        for ($derecha = $this->tamano - 1; $derecha >= 1; $derecha -= 2) {
            if ($derecha === 6) $derecha = 5;
            for ($vertical = 0; $vertical < $this->tamano; $vertical++) {
                for ($j = 0; $j < 2; $j++) {
                    $x = $derecha - $j;
                    $sube = (($derecha + 1) & 2) === 0;
                    $y = $sube ? $this->tamano - 1 - $vertical : $vertical;
                    if (!$this->esFuncion[$y][$x] && $i < $total) {
                        $this->modulos[$y][$x] = (($palabras[$i >> 3] >> (7 - ($i & 7))) & 1) !== 0;
                        $i++;
                    }
                }
            }
        }
    }

    private function aplicaMejorMascara(): void
    {
        $mejor = 0; $menor = PHP_INT_MAX;
        for ($mascara = 0; $mascara < 8; $mascara++) {
            $this->mascara($mascara);
            $this->formato($mascara);
            $penalidad = $this->penalidad();
            if ($penalidad < $menor) { $menor = $penalidad; $mejor = $mascara; }
            $this->mascara($mascara); // XOR: la segunda vez la quita
        }
        $this->mascara($mejor);
        $this->formato($mejor);
    }

    private function mascara(int $mascara): void
    {
        for ($y = 0; $y < $this->tamano; $y++) {
            for ($x = 0; $x < $this->tamano; $x++) {
                if ($this->esFuncion[$y][$x]) continue;
                $invierte = match ($mascara) {
                    0 => ($x + $y) % 2 === 0,
                    1 => $y % 2 === 0,
                    2 => $x % 3 === 0,
                    3 => ($x + $y) % 3 === 0,
                    4 => (intdiv($x, 3) + intdiv($y, 2)) % 2 === 0,
                    5 => $x * $y % 2 + $x * $y % 3 === 0,
                    6 => ($x * $y % 2 + $x * $y % 3) % 2 === 0,
                    default => (($x + $y) % 2 + $x * $y % 3) % 2 === 0,
                };
                if ($invierte) $this->modulos[$y][$x] = !$this->modulos[$y][$x];
            }
        }
    }

    /** Las cuatro reglas de penalidad de la norma (§7.8.3). */
    private function penalidad(): int
    {
        $n = $this->tamano; $total = 0; $oscuros = 0;
        $lineas = [];
        for ($i = 0; $i < $n; $i++) {
            $fila = ''; $columna = '';
            for ($j = 0; $j < $n; $j++) {
                $fila .= $this->modulos[$i][$j] ? '1' : '0';
                $columna .= $this->modulos[$j][$i] ? '1' : '0';
            }
            $lineas[] = $fila; $lineas[] = $columna;
            $oscuros += substr_count($fila, '1');
        }
        foreach ($lineas as $linea) {
            preg_match_all('/0{5,}|1{5,}/', $linea, $corridas);
            foreach ($corridas[0] as $corrida) $total += 3 + strlen($corrida) - 5;
            $total += 40 * (preg_match_all('/(?=10111010000|00001011101)/', $linea));
        }
        for ($y = 0; $y < $n - 1; $y++) {
            for ($x = 0; $x < $n - 1; $x++) {
                $m = $this->modulos[$y][$x];
                if ($m === $this->modulos[$y][$x + 1] && $m === $this->modulos[$y + 1][$x] && $m === $this->modulos[$y + 1][$x + 1]) $total += 3;
            }
        }
        $k = (int) ceil(abs($oscuros * 20 - $n * $n * 10) / ($n * $n)) - 1;
        return $total + max(0, $k) * 10;
    }

    private function funcion(int $x, int $y, bool $oscuro): void
    {
        $this->modulos[$y][$x] = $oscuro;
        $this->esFuncion[$y][$x] = true;
    }
}
