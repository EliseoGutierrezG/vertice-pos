<?php
declare(strict_types=1);

namespace Dominio;

/**
 * El desglose fiscal de una línea: de dónde sale lo que paga el cliente.
 *
 *     neto = bruto + IEPS de tasa + IEPS por litro + IVA
 *
 * Esa igualdad se cumple **exactamente**, no aproximadamente. Es lo que
 * permite que el ticket, el reporte y la factura digan lo mismo.
 */
final class Desglose
{
    public function __construct(
        /** Lo que paga el cliente, con impuestos incluidos. */
        public readonly Dinero $neto,
        /** La base gravable: el precio sin impuestos. */
        public readonly Dinero $bruto,
        public readonly Dinero $ieps,
        public readonly Dinero $iepsPorLitro,
        public readonly Dinero $iva,
        /** Los litros que causaron la cuota, para el nodo del CFDI. */
        public readonly Cantidad $litros
    ) {
    }

    /** La base sobre la que se calculó el IVA: incluye los dos IEPS. */
    public function baseDelIva(): Dinero
    {
        return $this->bruto->mas($this->ieps)->mas($this->iepsPorLitro);
    }

    public function impuestos(): Dinero
    {
        return $this->ieps->mas($this->iepsPorLitro)->mas($this->iva);
    }

    /** Las partes suman el neto. Si esto falla, algo está mal. */
    public function cuadra(): bool
    {
        return $this->bruto->mas($this->impuestos())->igualA($this->neto);
    }

    /**
     * El mismo desglose con dos decimales, y **sigue cuadrando**.
     *
     * Aquí se guarda: las columnas `pedido_detalle.importe_*` son
     * `DECIMAL(14,2)`. Redondear cada parte por su cuenta rompe la igualdad que
     * esta clase existe para sostener —con IEPS falla en una de cada cuatro
     * ventas, y con cuota por litro en casi la mitad—, y entonces el ticket que
     * enseña el desglose no suma el total que cobró.
     *
     * Se hace con la misma regla que `CalculoFiscal` usa con las
     * diezmilésimas: **el neto es la verdad y el IVA se acomoda a él.** Las
     * otras tres partes se redondean y el IVA es lo que falta para llegar al
     * neto, así que la suma cierra por construcción y no por suerte. El IVA
     * carga con el redondeo de las otras: hasta centavo y medio en un renglón,
     * y ni un centavo en el total que se cobra.
     */
    public function enCentavos(): self
    {
        $neto  = $this->neto->enCentavos();
        $bruto = $this->bruto->enCentavos();
        $ieps  = $this->ieps->enCentavos();
        $cuota = $this->iepsPorLitro->enCentavos();

        return new self(
            $neto,
            $bruto,
            $ieps,
            $cuota,
            $neto->menos($bruto)->menos($ieps)->menos($cuota),
            $this->litros
        );
    }

    /** @return array<string,string> Lo que viaja a la app y se guarda. */
    public function aArreglo(): array
    {
        return [
            'neto'           => $this->neto->aCadena(),
            'bruto'          => $this->bruto->aCadena(),
            'ieps'           => $this->ieps->aCadena(),
            'ieps_por_litro' => $this->iepsPorLitro->aCadena(),
            'iva'            => $this->iva->aCadena(),
            'litros'         => $this->litros->aCadena(),
        ];
    }
}
