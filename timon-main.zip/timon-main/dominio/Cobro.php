<?php
declare(strict_types=1);

namespace Dominio;

use Nucleo\Errores\Errores;

/**
 * Las cuentas de un cobro, sin base de datos.
 *
 * Recibe el consumo, la propina, el descuento y las formas de pago, y dice
 * cuánto se paga y cuánto cambio se regresa. Todo en centavos enteros.
 *
 *   consumo − descuento = venta
 *   venta + propina     = total a pagar = suma de los importes
 *   recibido − importe  = cambio (sólo en efectivo)
 *
 * El importe de cada forma es lo que se aplica a la cuenta; lo recibido es lo
 * que el cliente entregó. Por eso el corte de caja suma importes y no recibidos.
 */
final class Cobro
{
    public const MEDIOS = ['efectivo', 'tarjeta', 'transferencia'];

    /**
     * @param list<array{medio: string, importe: Dinero, recibido: ?Dinero, referencia?: ?string}> $formas
     * @param ?int $porcentaje Descuento de 1 a 100 sobre el consumo; excluye al descuento en importe.
     * @return array{descuento: Dinero, venta: Dinero, total: Dinero, cambio: Dinero, formas: list<array<string, mixed>>}
     */
    public static function calcula(Dinero $consumo, Dinero $propina, Dinero $descuento, ?int $porcentaje, array $formas): array
    {
        if ($porcentaje !== null) {
            if (!$descuento->esCero()) {
                throw Errores::datosInvalidos(['descuento' => 'Capture el descuento en importe o en porcentaje']);
            }
            if ($porcentaje < 1 || $porcentaje > 100) {
                throw Errores::datosInvalidos(['descuento_porcentaje' => 'El porcentaje va de 1 a 100']);
            }
            $descuento = self::porcentaje($consumo, $porcentaje);
        }
        if ($descuento->comparaCon($consumo) > 0) {
            throw Errores::datosInvalidos(['descuento' => 'El descuento supera el consumo']);
        }
        $venta = $consumo->menos($descuento);
        $total = $venta->mas($propina);

        $suma = Dinero::cero();
        $cambio = Dinero::cero();
        $salida = [];
        foreach ($formas as $forma) {
            $importe = $forma['importe'];
            $recibido = $forma['recibido'] ?? null;
            if ($importe->esCero()) {
                throw Errores::datosInvalidos(['formas' => 'Cada pago lleva un importe mayor que cero']);
            }
            if ($recibido !== null && $forma['medio'] !== 'efectivo') {
                throw Errores::datosInvalidos(['formas' => 'Solo el efectivo lleva importe recibido']);
            }
            if ($recibido !== null && $recibido->comparaCon($importe) < 0) {
                throw Errores::datosInvalidos(['formas' => 'Lo recibido no cubre el importe en efectivo']);
            }
            $vuelto = $recibido === null ? Dinero::cero() : $recibido->menos($importe);
            $suma = $suma->mas($importe);
            $cambio = $cambio->mas($vuelto);
            $salida[] = ['recibido' => $recibido, 'cambio' => $vuelto] + $forma;
        }
        if (!$suma->igualA($total)) {
            throw Errores::datosInvalidos(['formas' => 'La suma de los pagos debe ser $' . $total->aPesos()]);
        }
        return ['descuento' => $descuento, 'venta' => $venta, 'total' => $total, 'cambio' => $cambio, 'formas' => $salida];
    }

    /** El porcentaje sobre el consumo, al centavo, con el medio centavo hacia arriba. */
    public static function porcentaje(Dinero $consumo, int $porcentaje): Dinero
    {
        $centavos = intdiv($consumo->diezmilesimas(), 100);
        return Dinero::deDiezmilesimas(intdiv($centavos * $porcentaje + 50, 100) * 100);
    }
}
