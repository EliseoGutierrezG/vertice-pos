<?php
declare(strict_types=1);

namespace Dominio;

/**
 * De precio neto a desglose fiscal. La regla más delicada del sistema.
 *
 * El precio que se le muestra al cliente y el que se guarda es el **neto**:
 * lo que paga, impuestos incluidos. Todo lo demás se calcula a partir de ahí.
 *
 * Ida (cómo se forma el neto):
 *
 *     neto = (bruto·(1+ieps) + cuota·litros) · (1+iva)
 *
 * Vuelta, que es la que hace falta:
 *
 *     bruto = (neto/(1+iva) − cuota·litros) / (1+ieps)
 *     IEPS de tasa  = bruto · ieps
 *     IEPS de cuota = cuota · litros
 *     base del IVA  = bruto + IEPS de tasa + IEPS de cuota
 *     IVA           = base del IVA · iva
 *
 * **La base del IVA incluye el IEPS.** No es una elección: así lo calcula la
 * referencia y así lo exige la ley.
 *
 * Dos cosas que la referencia hace y aquí NO se hacen
 * ([06 §8.2](../docs/referencia/06-reglas-de-negocio.md)):
 *
 *  - Allí el IVA se saca con `neto·iva/1.16`, **con el 1.16 escrito en el
 *    código**. El día que cambie la tasa, el precio cambia y el IVA no.
 *    Aquí el divisor siempre es `1 + iva`, y el `iva` viene de la base.
 *  - Allí la cuota por litro se calcula distinto en dos partes del mismo
 *    archivo. Aquí existe una sola vez, en esta clase.
 *
 * Esta clase no toca la base de datos ni sabe qué es un pedido. Recibe
 * números y devuelve números, para poder comprobarla contra casos calculados
 * a mano.
 */
final class CalculoFiscal
{
    /**
     * Desglosa una línea.
     *
     * @param Dinero   $neto   Lo que paga el cliente por la línea completa.
     * @param Cantidad $litros Litros totales de la línea, ya multiplicados.
     */
    public function desglosa(Dinero $neto, Impuesto $impuesto, Cantidad $litros): Desglose
    {
        // La cuota por litro no depende del precio: es fija por volumen.
        $iepsPorLitro = $impuesto->iepsPorLitro->por($litros);

        // Se quita el IVA, se quita la cuota, y lo que queda se limpia del
        // IEPS de tasa. En ese orden, que es el inverso al de la formación.
        $sinIva = $neto->entreTasa($impuesto->iva->masUno());
        $bruto  = $sinIva->menos($iepsPorLitro)->entreTasa($impuesto->ieps->masUno());

        $ieps = $bruto->porTasa($impuesto->ieps);

        // El IVA se saca por diferencia, no multiplicando otra vez.
        //
        // Multiplicar la base por la tasa da el mismo número salvo por una
        // diezmilésima de redondeo. Pero esa diezmilésima haría que las
        // partes no sumaran EXACTAMENTE lo que el cliente paga, y entonces
        // el ticket y la factura discreparían por un centavo cada tantas
        // ventas. El neto es lo que se cobra: es la verdad, y el resto se
        // acomoda a él.
        $iva = $neto->menos($bruto)->menos($ieps)->menos($iepsPorLitro);

        return new Desglose($neto, $bruto, $ieps, $iepsPorLitro, $iva, $litros);
    }

    /**
     * El camino de ida: de una base gravable al precio al público.
     *
     * Hace falta para dar de alta precios partiendo de un costo, y sirve de
     * comprobación cruzada: desglosar lo que esto arma tiene que devolver la
     * base de la que se partió.
     */
    public function neto(Dinero $bruto, Impuesto $impuesto, Cantidad $litros): Dinero
    {
        $conIeps = $bruto->mas($bruto->porTasa($impuesto->ieps));
        $conCuota = $conIeps->mas($impuesto->iepsPorLitro->por($litros));

        return $conCuota->mas($conCuota->porTasa($impuesto->iva));
    }
}
