<?php
declare(strict_types=1);

namespace Dominio;

use InvalidArgumentException;

/**
 * Convertir entre cadenas decimales y enteros escalados.
 *
 * El proyecto no guarda dinero en números de punto flotante, ni siquiera de
 * paso. `0.1 + 0.2` no da `0.3` en ningún lenguaje que use IEEE 754, y una
 * distribuidora que vende 140 pedidos al día acumula esa diferencia hasta
 * que alguien pregunta por qué no cuadra el corte.
 *
 * Todo viaja como entero: un precio de 25.5000 es 255000 diezmilésimas.
 * MariaDB entrega y recibe cadenas decimales, así que la conversión ocurre
 * exactamente en la frontera con la base y en ningún otro sitio.
 */
final class Escala
{
    /**
     * "25.5" con escala 10000 → 255000.
     *
     * Los decimales sobrantes se redondean, no se recortan: recortar sesga
     * todos los importes hacia abajo, y el sesgo se nota al sumar mil.
     */
    public static function aEntero(string $valor, int $escala): int
    {
        $valor = trim($valor);

        if (preg_match('/^(-?)(\d+)(?:\.(\d*))?$/', $valor, $partes) !== 1) {
            throw new InvalidArgumentException('No es un número decimal: "' . $valor . '"');
        }

        [, $signo, $enteros, $decimales] = [...$partes, ''];
        $decimales = $partes[3] ?? '';

        $digitosDeEscala = (int) round(log10((float) $escala));

        // Se toma un dígito de más para poder redondear con él.
        $conUnoDeMas = str_pad(substr($decimales, 0, $digitosDeEscala + 1), $digitosDeEscala + 1, '0');

        $escalado = $enteros . substr($conUnoDeMas, 0, $digitosDeEscala);

        // ⚠️ `(int)` de una cadena que no cabe **no falla: se pega al tope**. Se
        // midió: «9999999999999999» con escala 1000 salía 9223372036854775807,
        // o sea 9223372036854775.807 unidades, un número **distinto** del que se
        // recibió y sin un solo aviso. Lo peligroso no es el tope, es el
        // silencio: lo que después se valida ya no es lo que alguien mandó.
        if (!self::cabeEnEntero($escalado)) {
            throw new InvalidArgumentException('El número es demasiado grande: "' . $valor . '"');
        }

        $sinRedondear = (int) $escalado;
        $siguiente    = (int) substr($conUnoDeMas, $digitosDeEscala, 1);

        // El redondeo puede empujarlo justo por encima del tope. ⚠️ No se
        // comprueba con `$resultado < $sinRedondear`: en PHP el entero que se
        // desborda **no da la vuelta, se vuelve `float`**, así que la comparación
        // dice lo contrario de lo que uno espera y lo que sale es un `TypeError`
        // desde el tipo de retorno. Se comprueba antes de sumar.
        if ($sinRedondear === PHP_INT_MAX && $siguiente >= 5) {
            throw new InvalidArgumentException('El número es demasiado grande: "' . $valor . '"');
        }

        $resultado = $sinRedondear + ($siguiente >= 5 ? 1 : 0);

        return $signo === '-' ? -$resultado : $resultado;
    }

    /**
     * ¿Cabe esa cadena de dígitos en un entero de esta máquina?
     *
     * Se compara como texto porque convertirla es justo lo que no se puede
     * hacer todavía: `(int)` de lo que no cabe devuelve el tope sin quejarse.
     */
    /**
     * Multiplica dos enteros escalados, o se niega.
     *
     * ⚠️ Hace falta porque el desbordamiento **no se nota**: `Escala::aEntero()`
     * ya vigila lo que entra —con su comentario de que un `(int)` que no cabe se
     * pega al tope— y nadie vigilaba lo que sale de multiplicar dos importes que
     * sí cabían. Medido contra el sistema corriendo: con un precio de
     * 99,999,999.9999 —que el sistema **acepta**, 302 por su propia pantalla— y
     * un renglón de 100,000 unidades, `Dinero::por()` daba
     * `TypeError: Redondeo::divide(): Argument #1 must be of type int, float
     * given` y **500 en el botón de agregar del mostrador**, que es el que más
     * se aprieta en todo el sistema.
     *
     * La detección es la misma que ya estaba escrita aquí: en PHP el entero que
     * se desborda no da la vuelta, **se vuelve `float`**. Así que se multiplica y
     * se pregunta si el resultado sigue siendo entero.
     */
    public static function multiplica(int $uno, int $otro): int
    {
        $producto = $uno * $otro;

        if (!is_int($producto)) {
            throw new InvalidArgumentException(
                'El producto de ' . $uno . ' por ' . $otro . ' no cabe en un entero'
            );
        }

        return $producto;
    }

    private static function cabeEnEntero(string $digitos): bool
    {
        $digitos = ltrim($digitos, '0');
        $tope    = (string) PHP_INT_MAX;

        if (strlen($digitos) !== strlen($tope)) {
            return strlen($digitos) < strlen($tope);
        }

        return strcmp($digitos, $tope) <= 0;
    }

    /** 255000 con escala 10000 → "25.5000". */
    public static function aCadena(int $valor, int $escala, int $decimales): string
    {
        $digitosDeEscala = (int) round(log10((float) $escala));

        $negativo = $valor < 0;
        $valor    = abs($valor);

        $enteros    = intdiv($valor, $escala);
        $fraccion   = str_pad((string) ($valor % $escala), $digitosDeEscala, '0', STR_PAD_LEFT);

        if ($decimales < $digitosDeEscala) {
            // Se redondea a los decimales pedidos, no se recorta.
            $factor   = (int) (10 ** ($digitosDeEscala - $decimales));
            $valor    = Redondeo::divide($valor, $factor);
            $enteros  = intdiv($valor, (int) (10 ** $decimales));
            $fraccion = str_pad((string) ($valor % (int) (10 ** $decimales)), $decimales, '0', STR_PAD_LEFT);
        } elseif ($decimales > $digitosDeEscala) {
            $fraccion = str_pad($fraccion, $decimales, '0');
        }

        $texto = $decimales === 0 ? (string) $enteros : $enteros . '.' . $fraccion;

        return $negativo && $valor !== 0 ? '-' . $texto : $texto;
    }
}
