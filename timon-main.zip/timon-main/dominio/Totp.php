<?php
declare(strict_types=1);

namespace Dominio;

use InvalidArgumentException;

/** TOTP RFC 6238 (SHA-1, 6 dígitos, periodo de 30 s), compatible con Authenticator. */
final class Totp
{
    private const ALFABETO = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public function generaSecreto(int $bytes = 20): string
    {
        if ($bytes < 16) {
            throw new InvalidArgumentException('El secreto TOTP es demasiado corto');
        }

        return self::base32Codifica(random_bytes($bytes));
    }

    public function codigo(string $secreto, ?int $momento = null): string
    {
        return $this->codigoPeriodo($secreto, intdiv($momento ?? time(), 30));
    }

    /** Devuelve el periodo aceptado; null si el código no coincide en ±$ventana. */
    public function verifica(string $secreto, string $codigo, ?int $momento = null, int $ventana = 1): ?int
    {
        if (preg_match('/^\d{6}$/D', $codigo) !== 1 || $ventana < 0 || $ventana > 10) {
            return null;
        }

        $periodo = intdiv($momento ?? time(), 30);
        for ($desfase = -$ventana; $desfase <= $ventana; $desfase++) {
            $candidato = $periodo + $desfase;
            if ($candidato >= 0 && hash_equals($this->codigoPeriodo($secreto, $candidato), $codigo)) {
                return $candidato;
            }
        }

        return null;
    }

    public function uri(string $secreto, string $cuenta, string $emisor = 'El Timón'): string
    {
        $etiqueta = rawurlencode($emisor . ':' . $cuenta);
        return 'otpauth://totp/' . $etiqueta
            . '?secret=' . rawurlencode($secreto)
            . '&issuer=' . rawurlencode($emisor)
            . '&algorithm=SHA1&digits=6&period=30';
    }

    private function codigoPeriodo(string $secreto, int $periodo): string
    {
        $llave = self::base32Decodifica($secreto);
        $contador = pack('N2', intdiv($periodo, 0x100000000), $periodo & 0xffffffff);
        $hash = hash_hmac('sha1', $contador, $llave, true);
        $desfase = ord($hash[19]) & 0x0f;
        $entero = unpack('N', substr($hash, $desfase, 4))[1] & 0x7fffffff;

        return str_pad((string) ($entero % 1000000), 6, '0', STR_PAD_LEFT);
    }

    private static function base32Codifica(string $datos): string
    {
        $bits = '';
        foreach (str_split($datos) as $byte) {
            $bits .= str_pad(decbin(ord($byte)), 8, '0', STR_PAD_LEFT);
        }
        $salida = '';
        foreach (str_split($bits, 5) as $grupo) {
            $salida .= self::ALFABETO[bindec(str_pad($grupo, 5, '0', STR_PAD_RIGHT))];
        }
        return $salida;
    }

    private static function base32Decodifica(string $texto): string
    {
        $texto = strtoupper(str_replace([' ', '-', '='], '', trim($texto)));
        if ($texto === '' || preg_match('/^[A-Z2-7]+$/D', $texto) !== 1) {
            throw new InvalidArgumentException('El secreto TOTP no es Base32 válido');
        }
        $bits = '';
        foreach (str_split($texto) as $caracter) {
            $posicion = strpos(self::ALFABETO, $caracter);
            $bits .= str_pad(decbin((int) $posicion), 5, '0', STR_PAD_LEFT);
        }
        $salida = '';
        foreach (str_split($bits, 8) as $grupo) {
            if (strlen($grupo) === 8) {
                $salida .= chr(bindec($grupo));
            }
        }
        return $salida;
    }
}

