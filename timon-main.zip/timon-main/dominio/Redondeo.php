<?php
declare(strict_types=1);

namespace Dominio;

/**
 * El redondeo, definido en UN solo lugar.
 *
 * Todo el dinero del sistema pasa por aquí. Si algún día hay que cambiar el
 * criterio —de medio arriba a medio par, por decir—, se cambia aquí y cambia
 * en todas partes a la vez. Tener el redondeo repartido es cómo terminan dos
 * pantallas mostrando totales distintos para la misma venta.
 *
 * Criterio: **medio hacia arriba, alejándose del cero**. Es lo que espera
 * quien cobra, y lo que hace la calculadora del mostrador.
 */
final class Redondeo
{
    /**
     * Divide dos enteros redondeando medio hacia arriba.
     *
     * Sin números de punto flotante en ningún paso: `(int) round(7/2)` y
     * `intdiv(7 + 1, 2)` coinciden hoy, pero el primero pasa por un double y
     * el segundo no. Con dinero, esa diferencia acaba apareciendo.
     */
    public static function divide(int $dividendo, int $divisor): int
    {
        if ($divisor === 0) {
            throw new \DivisionByZeroError('No se divide entre cero');
        }

        $negativo = ($dividendo < 0) !== ($divisor < 0);
        $a = abs($dividendo);
        $b = abs($divisor);

        $resultado = intdiv($a * 2 + $b, $b * 2);

        return $negativo ? -$resultado : $resultado;
    }
}
