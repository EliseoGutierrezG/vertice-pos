<?php
declare(strict_types=1);

namespace Dominio;

use InvalidArgumentException;

/**
 * Lo que una persona escribe en un campo de texto, limpio y comparable.
 *
 * «Sucursal  Centro » y «Sucursal Centro» son la misma sucursal: si se guardaran
 * distinto, la regla de «nombre único» dejaría pasar la segunda y la lista
 * enseñaría dos renglones que nadie distingue. La mayúscula y el acento ya los
 * iguala la intercalación de la base (`utf8mb4_unicode_ci`); los espacios, no.
 */
final class Texto
{
    /** Sin espacios en las orillas y con uno solo entre palabras. */
    public static function limpio(string $texto): string
    {
        return trim((string) preg_replace('/\s+/u', ' ', $texto));
    }

    /** El texto limpio, o `null` si quedó vacío. Para los campos opcionales. */
    public static function opcional(mixed $texto): ?string
    {
        $limpio = self::limpio((string) ($texto ?? ''));

        return $limpio === '' ? null : $limpio;
    }

    /**
     * Un teléfono de México: diez dígitos, se escriba como se escriba.
     *
     * Se guardan sólo los dígitos. Con guiones, espacios o paréntesis el mismo
     * número se guardaría de cinco formas y una búsqueda encontraría una.
     *
     * @throws InvalidArgumentException si no son diez dígitos
     */
    public static function telefono(mixed $texto): ?string
    {
        $crudo = trim((string) ($texto ?? ''));

        if ($crudo === '') {
            return null;
        }

        if (preg_match('/^[\d\s().+-]+$/', $crudo) !== 1) {
            throw new InvalidArgumentException('El teléfono lleva sólo números');
        }

        $digitos = (string) preg_replace('/\D/', '', $crudo);

        // Quien copia el número de otro lado suele traer la lada del país.
        if (strlen($digitos) === 12 && str_starts_with($digitos, '52')) {
            $digitos = substr($digitos, 2);
        }

        if (strlen($digitos) !== 10) {
            throw new InvalidArgumentException('El teléfono lleva 10 dígitos');
        }

        return $digitos;
    }

    /**
     * Un código postal: cinco dígitos.
     *
     * @throws InvalidArgumentException si no son cinco dígitos
     */
    public static function codigoPostal(mixed $texto): ?string
    {
        $crudo = trim((string) ($texto ?? ''));

        if ($crudo === '') {
            return null;
        }

        if (preg_match('/^\d{5}$/', $crudo) !== 1) {
            throw new InvalidArgumentException('El código postal lleva 5 dígitos');
        }

        return $crudo;
    }

    /**
     * Una llave estable para comparar nombres y direcciones escritos distinto.
     *
     * La intercalación de MariaDB ya ignora mayúsculas y acentos, pero no la
     * puntuación ni dos espacios. Esta llave no se enseña: sólo permite que
     * «Abarrotes San José» y «ABARROTES SAN JOSE» no nazcan como dos clientes
     * cuando además tienen la misma dirección.
     */
    public static function claveComparacion(string ...$partes): string
    {
        $texto = mb_strtolower(self::limpio(implode(' ', $partes)), 'UTF-8');
        $ascii = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $texto);
        $texto = is_string($ascii) ? $ascii : $texto;
        $texto = (string) preg_replace('/[^a-z0-9]+/i', '', $texto);

        return mb_substr($texto, 0, 160);
    }
}
