<?php
declare(strict_types=1);

namespace Dominio;

use Nucleo\Errores\Errores;

final class Reparto
{
    /** @return list<Dinero> */
    public static function divide(Dinero $total, int $partes): array
    {
        $centavos = intdiv($total->enCentavos()->diezmilesimas(), 100);
        if ($partes < 2 || $partes > 20 || $centavos < $partes) {
            throw Errores::datosInvalidos(['partes' => 'Seleccione entre 2 y 20 partes con importe']);
        }
        $base = intdiv($centavos, $partes);
        $resto = $centavos % $partes;
        $resultado = [];
        for ($n = 0; $n < $partes; $n++) {
            $resultado[] = Dinero::deDiezmilesimas(($base + ($n < $resto ? 1 : 0)) * 100);
        }
        return $resultado;
    }
}
