<?php
declare(strict_types=1);

namespace Dominio;

use InvalidArgumentException;

/** Deriva claves cortas y reproducibles sin persistirlas. */
final class ClaveDia
{
    public function __construct(private string $llave)
    {
        if (strlen($llave) < 32) {
            throw new InvalidArgumentException('La llave de las claves del día es demasiado corta');
        }
    }

    public function ruta(int $id, string $fecha): string
    {
        return $this->deriva('ruta', $id, $fecha);
    }

    public function cliente(int $id, string $fecha): string
    {
        return $this->deriva('cliente', $id, $fecha);
    }

    public function compruebaRuta(int $id, string $fecha, string $clave): bool
    {
        return hash_equals($this->ruta($id, $fecha), trim($clave));
    }

    public function compruebaCliente(int $id, string $fecha, string $clave): bool
    {
        return hash_equals($this->cliente($id, $fecha), trim($clave));
    }

    /**
     * Comprueba la prueba SHA-256 que conserva el teléfono. La clave corta no
     * queda en la cola offline ni viaja a la API; sólo su huella de 64 bytes.
     */
    public function compruebaHuellaRuta(int $id, string $fecha, string $huella): bool
    {
        return $this->compruebaHuella($this->ruta($id, $fecha), $huella);
    }

    public function compruebaHuellaCliente(int $id, string $fecha, string $huella): bool
    {
        return $this->compruebaHuella($this->cliente($id, $fecha), $huella);
    }

    private function deriva(string $tipo, int $id, string $fecha): string
    {
        if ($id < 1 || preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha) !== 1) {
            throw new InvalidArgumentException('Entidad o fecha inválida para derivar la clave');
        }
        $binario = hash_hmac('sha256', 'plantilla-v1|' . $tipo . '|' . $id . '|' . $fecha, $this->llave, true);
        $numero = (int) unpack('N', substr($binario, 0, 4))[1];
        return str_pad((string) ($numero % 100000000), 8, '0', STR_PAD_LEFT);
    }

    private function compruebaHuella(string $clave, string $huella): bool
    {
        $huella = strtolower(trim($huella));
        return preg_match('/^[0-9a-f]{64}$/', $huella) === 1
            && hash_equals(hash('sha256', $clave), $huella);
    }
}
