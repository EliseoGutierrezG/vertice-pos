<?php
declare(strict_types=1);

namespace Dominio;

use DateTimeImmutable;
use Nucleo\Errores\Errores;

/**
 * Las reglas de una promoción de platillo, sin base de datos.
 *
 * Tres tipos:
 *   porcentaje  rebaja de 1 a 90 % del precio unitario, suplementos incluidos
 *   precio      precio especial en lugar del precio base; los suplementos se cobran
 *   nxm         lleva N y paga M del mismo platillo; salen gratis las unidades más baratas
 *
 * La vigencia junta fechas, días (máscara: lunes = 1 … domingo = 64) y un
 * horario opcional que puede cruzar la medianoche: el martes de 22:00 a 02:00
 * sigue vigente el miércoles a la 01:00.
 *
 * Una promoción se representa como el renglón de la tabla `promocion`.
 */
final class Promocion
{
    public const TIPOS = ['porcentaje' => 'Porcentaje', 'precio' => 'Precio especial', 'nxm' => 'Lleva N, paga M'];
    public const DIAS = [1 => 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
    public const TODOS_LOS_DIAS = 127;

    public static function bitDia(int $dia): int
    {
        return 1 << ($dia - 1);
    }

    /** Si la promoción aplica en ese momento. */
    public static function vigente(array $p, DateTimeImmutable $momento): bool
    {
        if ((int) ($p['activa'] ?? 1) !== 1 || (int) ($p['baja'] ?? 0) === 1) {
            return false;
        }
        $inicio = self::hora($p['hora_inicio'] ?? null);
        $fin = self::hora($p['hora_fin'] ?? null);
        if ($inicio === null || $fin === null) {
            return self::diaValido($p, $momento);
        }
        // El turno pertenece al día en que empieza, aunque termine pasada la medianoche.
        foreach ([$momento, $momento->modify('-1 day')] as $fecha) {
            if (!self::diaValido($p, $fecha)) {
                continue;
            }
            $desde = new DateTimeImmutable($fecha->format('Y-m-d') . ' ' . $inicio, $momento->getTimezone());
            $hasta = new DateTimeImmutable($fecha->format('Y-m-d') . ' ' . $fin, $momento->getTimezone());
            if ($hasta <= $desde) {
                $hasta = $hasta->modify('+1 day');
            }
            if ($momento >= $desde && $momento < $hasta) {
                return true;
            }
        }
        return false;
    }

    /** Si ya terminó para siempre: su última fecha quedó atrás. */
    public static function vencida(array $p, DateTimeImmutable $momento): bool
    {
        $hasta = $p['hasta'] ?? null;
        return $hasta !== null && $hasta !== '' && (string) $hasta < $momento->format('Y-m-d');
    }

    /**
     * Lo que rebaja de una unidad un porcentaje o un precio especial. Un N×M
     * no rebaja por unidad: se calcula con todos los renglones de la cuenta.
     */
    public static function descuentoUnitario(array $p, Dinero $base, Dinero $suplementos): Dinero
    {
        if ($p['tipo'] === 'porcentaje') {
            return Cobro::porcentaje($base->mas($suplementos), (int) round((float) $p['valor']));
        }
        if ($p['tipo'] === 'precio') {
            $especial = Dinero::deCadena((string) $p['valor']);
            return $especial->comparaCon($base) < 0 ? $base->menos($especial) : Dinero::cero();
        }
        return Dinero::cero();
    }

    /**
     * Lo que rebaja por unidad, para elegir entre dos promociones que coinciden.
     * Gana la de mayor rebaja.
     */
    public static function rebajaEstimada(array $p, Dinero $base, Dinero $suplementos): int
    {
        if ($p['tipo'] === 'nxm') {
            $lleva = (int) $p['lleva'];
            return intdiv($base->mas($suplementos)->diezmilesimas() * ($lleva - (int) $p['paga']), $lleva);
        }
        return self::descuentoUnitario($p, $base, $suplementos)->diezmilesimas();
    }

    public static function unidadesGratis(int $cantidad, int $lleva, int $paga): int
    {
        return intdiv($cantidad, $lleva) * ($lleva - $paga);
    }

    /**
     * Reparte el descuento de un N×M entre los renglones del mismo platillo y
     * la misma promoción. Las unidades gratis son las más baratas; a igual
     * precio, las del renglón capturado primero.
     *
     * @param list<array{id: int|string, precio: Dinero, cantidad: int}> $renglones
     * @return array<int|string, Dinero> El descuento de cada renglón
     */
    public static function descuentosNxM(array $p, array $renglones): array
    {
        $unidades = [];
        $total = 0;
        foreach ($renglones as $orden => $r) {
            $total += $r['cantidad'];
            $unidades[] = ['id' => $r['id'], 'precio' => $r['precio'], 'orden' => $orden, 'cantidad' => $r['cantidad']];
        }
        $descuentos = array_fill_keys(array_column($renglones, 'id'), Dinero::cero());
        $gratis = self::unidadesGratis($total, (int) $p['lleva'], (int) $p['paga']);
        usort($unidades, static fn (array $a, array $b): int
            => [$a['precio']->diezmilesimas(), $a['orden']] <=> [$b['precio']->diezmilesimas(), $b['orden']]);
        foreach ($unidades as $u) {
            if ($gratis <= 0) {
                break;
            }
            $toma = min($gratis, $u['cantidad']);
            $descuentos[$u['id']] = $descuentos[$u['id']]->mas($u['precio']->porEntero($toma));
            $gratis -= $toma;
        }
        return $descuentos;
    }

    /** El precio de una unidad con la promoción, cuando se puede decir por unidad. */
    public static function precioPromocion(array $p, Dinero $base): ?Dinero
    {
        if ($p['tipo'] === 'nxm') {
            return null;
        }
        $rebaja = self::descuentoUnitario($p, $base, Dinero::cero());
        return $rebaja->esCero() ? null : $base->menos($rebaja);
    }

    /** La insignia: «2x1», «−15 %» o «$199». */
    public static function etiqueta(array $p): string
    {
        return match ($p['tipo']) {
            'nxm' => (int) $p['lleva'] . 'x' . (int) $p['paga'],
            'porcentaje' => '−' . rtrim(rtrim(number_format((float) $p['valor'], 2, '.', ''), '0'), '.') . ' %',
            default => '$' . number_format((float) $p['valor'], 2),
        };
    }

    /** Cuándo aplica, en palabras: «Martes y jueves, de 13:00 a 17:00». */
    public static function horario(array $p): string
    {
        $mascara = (int) ($p['dias'] ?? self::TODOS_LOS_DIAS);
        $dias = [];
        foreach (self::DIAS as $n => $nombre) {
            if ($mascara & self::bitDia($n)) {
                $dias[] = $nombre;
            }
        }
        if ($mascara === self::TODOS_LOS_DIAS) {
            $texto = 'Todos los días';
        } elseif ($mascara === 31) {
            $texto = 'De lunes a viernes';
        } elseif ($mascara === 96) {
            $texto = 'Sábado y domingo';
        } else {
            $ultimo = array_pop($dias);
            $texto = $dias === [] ? $ultimo : implode(', ', $dias) . ' y ' . mb_strtolower($ultimo);
            $texto = mb_strtoupper(mb_substr($texto, 0, 1)) . mb_strtolower(mb_substr($texto, 1));
        }
        $inicio = self::hora($p['hora_inicio'] ?? null);
        $fin = self::hora($p['hora_fin'] ?? null);
        if ($inicio !== null && $fin !== null) {
            $texto .= ', de ' . substr($inicio, 0, 5) . ' a ' . substr($fin, 0, 5);
        }
        return $texto;
    }

    /**
     * Valida y normaliza lo capturado en el panel.
     *
     * @return array{nombre: string, tipo: string, valor: ?string, lleva: ?int, paga: ?int, desde: string,
     *               hasta: ?string, dias: int, hora_inicio: ?string, hora_fin: ?string}
     */
    public static function normaliza(array $datos): array
    {
        $errores = [];
        $nombre = trim((string) ($datos['nombre'] ?? ''));
        if ($nombre === '' || mb_strlen($nombre) > 80) {
            $errores['nombre'] = 'Capture un nombre de hasta 80 caracteres';
        }
        $tipo = (string) ($datos['tipo'] ?? '');
        if (!isset(self::TIPOS[$tipo])) {
            $errores['tipo'] = 'Seleccione el tipo de promoción';
        }
        $valor = null;
        $lleva = null;
        $paga = null;
        if ($tipo === 'porcentaje') {
            $crudo = trim((string) ($datos['porcentaje'] ?? ''));
            if (!preg_match('/^\d{1,2}$/D', $crudo) || (int) $crudo < 1 || (int) $crudo > 90) {
                $errores['porcentaje'] = 'El porcentaje va de 1 a 90';
            } else {
                $valor = (string) (int) $crudo . '.00';
            }
        } elseif ($tipo === 'precio') {
            $crudo = trim((string) ($datos['precio_especial'] ?? ''));
            if (!preg_match('/^\d{1,6}(?:\.\d{1,2})?$/D', $crudo) || (float) $crudo <= 0) {
                $errores['precio_especial'] = 'Capture un precio mayor que cero';
            } else {
                $valor = Dinero::deCadena($crudo)->aPesos();
            }
        } elseif ($tipo === 'nxm') {
            $lleva = filter_var($datos['lleva'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 2, 'max_range' => 10]]);
            $paga = filter_var($datos['paga'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 9]]);
            if ($lleva === false) {
                $errores['lleva'] = 'Lleva de 2 a 10 piezas';
                $lleva = null;
            }
            if ($paga === false || ($lleva !== null && $paga >= $lleva)) {
                $errores['paga'] = 'Paga menos piezas de las que lleva';
                $paga = null;
            }
        }
        $desde = (string) ($datos['desde'] ?? '');
        if (!self::fecha($desde)) {
            $errores['desde'] = 'Capture la fecha de inicio';
        }
        $hasta = trim((string) ($datos['hasta'] ?? ''));
        if ($hasta !== '' && (!self::fecha($hasta) || $hasta < $desde)) {
            $errores['hasta'] = 'La fecha final va después del inicio';
        }
        $dias = 0;
        foreach ((array) ($datos['dias'] ?? []) as $dia) {
            $n = (int) $dia;
            if ($n >= 1 && $n <= 7) {
                $dias |= self::bitDia($n);
            }
        }
        if ($dias === 0) {
            $errores['dias'] = 'Seleccione al menos un día';
        }
        $inicio = trim((string) ($datos['hora_inicio'] ?? ''));
        $fin = trim((string) ($datos['hora_fin'] ?? ''));
        if ($inicio !== '' || $fin !== '') {
            $formato = '/^(?:[01]\d|2[0-3]):[0-5]\d$/D';
            if (!preg_match($formato, $inicio) || !preg_match($formato, $fin) || $inicio === $fin) {
                $errores['hora_inicio'] = 'Capture dos horas distintas o deje ambas vacías';
            }
        }
        if ($errores !== []) {
            throw Errores::datosInvalidos($errores);
        }
        return [
            'nombre' => $nombre, 'tipo' => $tipo, 'valor' => $valor, 'lleva' => $lleva, 'paga' => $paga,
            'desde' => $desde, 'hasta' => $hasta === '' ? null : $hasta, 'dias' => $dias,
            'hora_inicio' => $inicio === '' ? null : $inicio, 'hora_fin' => $fin === '' ? null : $fin,
        ];
    }

    private static function diaValido(array $p, DateTimeImmutable $fecha): bool
    {
        $dia = $fecha->format('Y-m-d');
        $hasta = $p['hasta'] ?? null;
        return (string) $p['desde'] <= $dia
            && ($hasta === null || $hasta === '' || $dia <= (string) $hasta)
            && ((int) ($p['dias'] ?? self::TODOS_LOS_DIAS) & self::bitDia((int) $fecha->format('N'))) !== 0;
    }

    private static function hora(mixed $valor): ?string
    {
        if ($valor === null || $valor === '') {
            return null;
        }
        $texto = (string) $valor;
        return strlen($texto) === 5 ? $texto . ':00' : $texto;
    }

    private static function fecha(string $valor): bool
    {
        $f = DateTimeImmutable::createFromFormat('!Y-m-d', $valor);
        return $f !== false && $f->format('Y-m-d') === $valor;
    }
}
