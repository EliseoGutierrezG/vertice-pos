<?php
declare(strict_types=1);

namespace Dominio;

/**
 * Dinero, en diezmilésimas de peso y siempre entero.
 *
 * Cuatro decimales porque es lo que guardan las columnas unitarias
 * `DECIMAL(12,4)`, y porque el desglose de impuestos necesita ese margen para
 * que la suma de las partes dé exactamente el total.
 *
 * Es inmutable: cada operación devuelve otro Dinero. Un importe que se puede
 * modificar por accidente a media suma es de los errores más caros que hay.
 */
final class Dinero
{
    public const ESCALA = 10000;

    private function __construct(private int $diezmilesimas)
    {
    }

    /** Desde lo que devuelve la base: "25.5000". */
    public static function deCadena(string $valor): self
    {
        return new self(Escala::aEntero($valor, self::ESCALA));
    }

    public static function dePesos(int|float|string $pesos): self
    {
        return self::deCadena((string) $pesos);
    }

    public static function cero(): self
    {
        return new self(0);
    }

    public static function deDiezmilesimas(int $valor): self
    {
        return new self($valor);
    }

    public function mas(self $otro): self
    {
        return new self($this->diezmilesimas + $otro->diezmilesimas);
    }

    public function menos(self $otro): self
    {
        return new self($this->diezmilesimas - $otro->diezmilesimas);
    }

    /**
     * Multiplica por una cantidad, que puede tener decimales.
     *
     * ⚠️ Por `Escala::multiplica()` y no con `*` a secas: el producto de dos
     * enteros que caben puede no caber, y entonces PHP lo vuelve `float` en
     * silencio. Ahí está medido con qué precio y qué renglón pasaba.
     */
    public function por(Cantidad $cantidad): self
    {
        return new self(Redondeo::divide(
            Escala::multiplica($this->diezmilesimas, $cantidad->milesimas()),
            Cantidad::ESCALA
        ));
    }

    public function porEntero(int $veces): self
    {
        return new self(Escala::multiplica($this->diezmilesimas, $veces));
    }

    /** Aplica una tasa: 100.00 al 16% → 16.00 */
    public function porTasa(Tasa $tasa): self
    {
        return new self(Redondeo::divide(
            Escala::multiplica($this->diezmilesimas, $tasa->diezmilesimas()),
            Tasa::ESCALA_PUBLICA
        ));
    }

    /** Divide entre una tasa: el neto entre 1.16 da la base. */
    public function entreTasa(Tasa $tasa): self
    {
        return new self(Redondeo::divide(
            $this->diezmilesimas * Tasa::ESCALA_PUBLICA,
            $tasa->diezmilesimas()
        ));
    }

    public function negado(): self
    {
        return new self(-$this->diezmilesimas);
    }

    public function esCero(): bool
    {
        return $this->diezmilesimas === 0;
    }

    public function esNegativo(): bool
    {
        return $this->diezmilesimas < 0;
    }

    public function comparaCon(self $otro): int
    {
        return $this->diezmilesimas <=> $otro->diezmilesimas;
    }

    public function igualA(self $otro): bool
    {
        return $this->diezmilesimas === $otro->diezmilesimas;
    }

    public function diezmilesimas(): int
    {
        return $this->diezmilesimas;
    }

    /** Para guardar en una columna DECIMAL(12,4). */
    public function aCadena(): string
    {
        return Escala::aCadena($this->diezmilesimas, self::ESCALA, 4);
    }

    /** Para enseñar y para cobrar: dos decimales. */
    public function aPesos(): string
    {
        return Escala::aCadena($this->diezmilesimas, self::ESCALA, 2);
    }

    /**
     * El mismo importe, ya redondeado a centavos.
     *
     * Existe porque hay un momento exacto en que un importe deja de ser un
     * cálculo y se vuelve **lo que se cobra**: cuando se escribe en el renglón
     * de un pedido, que es una columna de dos decimales. A partir de ahí, la
     * suma de los renglones tiene que dar el total de la nota, y para eso el
     * total hay que sumarlo **con los renglones ya redondeados**.
     *
     * Sumar los exactos y redondear al final da otro número: dos renglones de
     * 25.005 y 31.005 son 56.01 sumando exacto y 56.02 sumando lo que dice cada
     * renglón. El cliente puede sumar la nota con la calculadora; el sistema no
     * puede darle un peso distinto.
     */
    public function enCentavos(): self
    {
        return self::deCadena($this->aPesos());
    }

    public function __toString(): string
    {
        return $this->aCadena();
    }
}
