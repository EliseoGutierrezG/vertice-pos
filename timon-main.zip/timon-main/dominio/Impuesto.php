<?php
declare(strict_types=1);

namespace Dominio;

/**
 * El impuesto que le toca a un producto, tal como está en la base.
 *
 * Tres piezas que conviven:
 *  - **IVA**, una tasa.
 *  - **IEPS de tasa**, un porcentaje sobre la base.
 *  - **IEPS de cuota**, una cantidad fija por litro.
 *
 * Ninguna de las tres se escribe en el código. Salen de la tabla `impuesto`,
 * que tiene vigencia: el día que cambie una tasa, se agrega un renglón nuevo
 * y lo viejo sigue explicando las ventas viejas.
 */
final class Impuesto
{
    public function __construct(
        public readonly Tasa $iva,
        public readonly Tasa $ieps,
        public readonly Dinero $iepsPorLitro,
        public readonly string $nombre = ''
    ) {
    }

    /** @param array<string,mixed> $fila Un renglón de la tabla `impuesto`. */
    public static function deFila(array $fila): self
    {
        return new self(
            Tasa::deCadena((string) $fila['iva']),
            Tasa::deCadena((string) $fila['ieps']),
            Dinero::deCadena((string) $fila['ieps_por_litro']),
            (string) ($fila['nombre'] ?? '')
        );
    }

    public static function exento(): self
    {
        return new self(Tasa::cero(), Tasa::cero(), Dinero::cero(), 'Exento');
    }

    public function tieneCuotaPorLitro(): bool
    {
        return !$this->iepsPorLitro->esCero();
    }
}
