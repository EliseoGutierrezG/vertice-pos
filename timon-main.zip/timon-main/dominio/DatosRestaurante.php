<?php
declare(strict_types=1);

namespace Dominio;

use Nucleo\Errores\Errores;

final class DatosRestaurante
{
    public static function entero(mixed $valor, string $campo, int $min = 1, int $max = PHP_INT_MAX): int
    {
        $numero = is_int($valor) || is_string($valor)
            ? filter_var($valor, FILTER_VALIDATE_INT, ['options' => ['min_range' => $min, 'max_range' => $max]])
            : false;
        if ($numero === false) {
            throw Errores::datosInvalidos([$campo => 'Capture un número entero válido']);
        }
        return $numero;
    }

    public static function texto(mixed $valor, string $campo, int $max, bool $obligatorio = true): string
    {
        if (!is_string($valor) || mb_strlen(trim($valor)) > $max || ($obligatorio && trim($valor) === '')) {
            throw Errores::datosInvalidos([$campo => 'Capture un texto de hasta ' . $max . ' caracteres']);
        }
        return trim($valor);
    }

    public static function opcion(mixed $valor, string $campo, array $opciones): string
    {
        if (!in_array($valor, $opciones, true)) {
            throw Errores::datosInvalidos([$campo => 'Seleccione una opción válida']);
        }
        return $valor;
    }

    public static function precio(mixed $valor, string $campo): Dinero
    {
        if (!(is_int($valor) || is_string($valor)) || preg_match('/^\d{1,8}(?:\.\d{1,2})?$/D', (string) $valor) !== 1) {
            throw Errores::datosInvalidos([$campo => 'Capture un importe válido con hasta dos decimales']);
        }
        return Dinero::deCadena((string) $valor);
    }
}
