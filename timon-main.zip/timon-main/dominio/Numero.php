<?php
declare(strict_types=1);

namespace Dominio;

use InvalidArgumentException;

/**
 * El número que escribió una persona, convertido en un decimal limpio.
 *
 * `Dinero::deCadena()` y `Cantidad::deCadena()` son estrictas a propósito: sólo
 * entienden `-?\d+(\.\d+)?`, y con cualquier otra cosa lanzan. Eso está bien
 * para la frontera con la base de datos, y **no** está bien para un campo de
 * formulario: quien captura una compra en el almacén escribe «$1,250.00» o
 * «18,50», y lo que recibía era una respuesta 500 —«algo salió mal», sin decir
 * qué corregir— o algo peor.
 *
 * Algo peor: ⚠️ los ayudantes que sí filtraban hacían `str_replace(',', '')`,
 * o sea **le quitaban la coma a todo**. Y eso está bien para el separador de
 * miles y es catastrófico para la coma decimal:
 *
 *     «1,250.00»  →  1250.00   ✓ es lo que quiso decir
 *     «18,50»     →  1850.00   ⚠️ quiso decir 18.50 — cien veces más
 *     «1,250»     →  1250      ⚠️ ¿o quiso decir 1.250? no hay manera de saber
 *
 * Medido contra el servidor: un precio de compra de «18,50» se guardaba como
 * **1850.0000**, con respuesta 302 y sin una sola señal de que algo iba mal. Un
 * error de cien veces en el costo de un producto, en silencio, es peor que
 * cualquier pantalla de error.
 *
 * Por eso la regla de aquí: **la coma sólo se acepta donde un separador de
 * miles puede estar**, en grupos de tres. En cualquier otro sitio no se
 * adivina, se pregunta. Y está en un solo lugar porque el sistema tiene seis
 * campos que leen números escritos a mano, y cinco de ellos ya habían
 * divergido; es el mismo argumento que `Redondeo` tiene escrito para el
 * redondeo.
 */
final class Numero
{
    /**
     * @throws InvalidArgumentException si no es un número que alguien escribiría
     */
    public static function escrito(string $texto): string
    {
        // El signo de pesos y los espacios son adorno: quien teclea «$ 1,250.00»
        // escribió un importe, y pedirle que lo repita sin adornos no protege
        // de nada. El espacio duro entra porque lo mete el copiar y pegar.
        $texto = str_replace(['$', ' ', "\u{00a0}"], '', trim($texto));

        // La coma se acepta **sólo** cuando el punto decimal también está, en
        // grupos de tres: entonces no hay duda de que es separador de miles.
        //
        // Sin el punto no se puede saber. «1,250» es mil doscientos cincuenta
        // para quien usa la coma de miles y 1.250 para quien la usa de
        // decimales, y en un campo de cantidad —que lleva milésimas— eso son mil
        // veces de diferencia. Con dos lecturas plausibles no se elige una: se
        // pregunta. Cuesta que alguien reescriba «1,250» como «1250»; la
        // alternativa cuesta un costo de producto multiplicado por mil.
        if (str_contains($texto, ',')) {
            if (preg_match('/^-?\d{1,3}(,\d{3})+\.\d+$/', $texto) !== 1) {
                throw new InvalidArgumentException(
                    'La coma sólo vale para los miles, y sólo junto al punto decimal'
                );
            }

            $texto = str_replace(',', '', $texto);
        }

        if (preg_match('/^-?\d+(\.\d+)?$/', $texto) !== 1) {
            throw new InvalidArgumentException('No es un número: "' . $texto . '"');
        }

        return $texto;
    }
}
