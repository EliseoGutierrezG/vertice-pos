<?php
declare(strict_types=1);

namespace Dominio;

/**
 * Los anchos de rollo en que sale un ticket (decisión del 2026-11-08, C3).
 *
 * - 58 mm: térmica portátil de ruta; imprime unos 48 mm, 32 caracteres.
 * - 80 mm: térmica de mostrador; imprime unos 72 mm, 48 caracteres.
 * - 76 mm: de impacto (matriz de punto); imprime unos 63 mm, 40 caracteres.
 *
 * Se elige al imprimir, no se configura por sucursal ni por persona. El 78 que
 * existió hasta esa fecha se lee como 80, para que no se rompan los enlaces
 * guardados.
 */
final class AnchoTicket
{
    /** El orden es el de los botones: el más común primero. */
    public const ANCHOS = ['58', '80', '76'];

    public const POR_OMISION = '58';

    /** Un ancho válido a partir de lo que llegó en la dirección. */
    public static function normaliza(mixed $valor): string
    {
        $ancho = trim((string) $valor);
        if ($ancho === '78') {
            return '80';
        }

        return in_array($ancho, self::ANCHOS, true) ? $ancho : self::POR_OMISION;
    }

    public static function esTicket(string $ancho): bool
    {
        return in_array($ancho, self::ANCHOS, true);
    }

    /** @return array<string,string> ancho => «80 mm» */
    public static function nombres(): array
    {
        $nombres = [];
        foreach (self::ANCHOS as $ancho) {
            $nombres[$ancho] = $ancho . ' mm';
        }

        return $nombres;
    }
}
