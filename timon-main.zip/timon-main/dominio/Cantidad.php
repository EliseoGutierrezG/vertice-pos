<?php
declare(strict_types=1);

namespace Dominio;

use InvalidArgumentException;

/**
 * Una cantidad de producto, en milésimas de unidad.
 *
 * Tres decimales porque es lo que guardan `presentacion.unidades` y
 * `producto.litros_unidad`. En la práctica se venden piezas enteras, pero
 * los litros de una presentación sí llevan decimales, y la conversión entre
 * presentación y unidad base pasa por aquí.
 */
final class Cantidad
{
    public const ESCALA = 1000;

    private function __construct(private int $milesimas)
    {
    }

    public static function deCadena(string $valor): self
    {
        return new self(Escala::aEntero($valor, self::ESCALA));
    }

    public static function deEntero(int $unidades): self
    {
        return new self($unidades * self::ESCALA);
    }

    public static function cero(): self
    {
        return new self(0);
    }

    public function mas(self $otra): self
    {
        return new self($this->milesimas + $otra->milesimas);
    }

    public function menos(self $otra): self
    {
        return new self($this->milesimas - $otra->milesimas);
    }

    /** Cuántas unidades base son: 3 cajas × 24 = 72. */
    public function por(self $otra): self
    {
        return new self(Redondeo::divide(Escala::multiplica($this->milesimas, $otra->milesimas), self::ESCALA));
    }

    public function esCero(): bool
    {
        return $this->milesimas === 0;
    }

    public function esPositiva(): bool
    {
        return $this->milesimas > 0;
    }

    public function comparaCon(self $otra): int
    {
        return $this->milesimas <=> $otra->milesimas;
    }

    public function milesimas(): int
    {
        return $this->milesimas;
    }

    /**
     * El valor como entero, cuando tiene que serlo.
     *
     * Lanza si tiene decimales: pedir "2.5 piezas" es un error de captura, y
     * redondearlo en silencio lo convierte en un error de inventario.
     */
    public function aEntero(): int
    {
        if ($this->milesimas % self::ESCALA !== 0) {
            throw new InvalidArgumentException(
                'La cantidad ' . $this->aCadena() . ' no es entera'
            );
        }

        return intdiv($this->milesimas, self::ESCALA);
    }

    public function aCadena(): string
    {
        return Escala::aCadena($this->milesimas, self::ESCALA, 3);
    }

    /** Para los mensajes a la persona: sin ceros de más y con separador de miles. */
    public function aTexto(): string
    {
        [$entero, $decimales] = explode('.', $this->aCadena());
        $signo = str_starts_with($entero, '-') ? '-' : '';
        $decimales = rtrim($decimales, '0');
        return $signo . number_format((float) ltrim($entero, '-')) . ($decimales !== '' ? '.' . $decimales : '');
    }

    public function __toString(): string
    {
        return $this->aCadena();
    }
}
