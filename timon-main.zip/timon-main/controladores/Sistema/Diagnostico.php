<?php
declare(strict_types=1);

namespace Controladores\Sistema;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\BaseDatos;
use Nucleo\Contenedor;
use Nucleo\Errores\Errores;
use Nucleo\MigracionesEsquema;
use Nucleo\Peticion;
use Nucleo\Respuesta;

/**
 * Comprueba que el entorno es el que se supone.
 *
 * Nació como la página de arranque de la fase 0. Se conserva como ruta porque
 * en la fase 20 sirve para lo mismo contra Hostinger: saber en un vistazo qué
 * versión de PHP hay, si `mysqli` está, y si la base responde.
 *
 * ⚠️ Sólo en entornos locales (`local` y `pruebas`). En produccion dice 404,
 * porque una página que anuncia versiones y conteos de tablas le sirve más a
 * quien busca un hueco que a nosotros.
 */
#[Modulo('sistema', 'Diagnóstico del entorno')]
final class Diagnostico extends Controlador
{
    public function __construct(private Contenedor $contenedor)
    {
    }

    #[Accion(publica: true)]
    public function ver(Peticion $peticion): Respuesta
    {
        if ($this->contenedor->config('entorno') === 'produccion') {
            throw Errores::noEncontrado();
        }

        $esServidorDePruebas=$this->contenedor->config('entorno')==='pruebas'&&PHP_SAPI==='cli-server';
        $comprobaciones = [
            'PHP 8.2'       => [version_compare(PHP_VERSION, '8.2.0', '>='), PHP_VERSION],
            'mysqli'        => [extension_loaded('mysqli'), extension_loaded('mysqli') ? 'cargada' : 'ausente'],
            'PHP-FPM'       => [PHP_SAPI === 'fpm-fcgi'||$esServidorDePruebas, $esServidorDePruebas?'cli-server (sólo pruebas)':PHP_SAPI],
            'Servidor'      => [true, (string) ($_SERVER['SERVER_SOFTWARE'] ?? 'desconocido')],
        ];

        try {
            /** @var BaseDatos $bd */
            $bd      = $this->contenedor->obtiene(BaseDatos::class);
            $version = (string) $bd->valor('SELECT VERSION()');

            // ⚠️ Se comparan **los nombres**, no la cuenta, y eso costó dos
            // arreglos. El primero: el número estaba escrito a mano —decía 44
            // cuando el esquema ya declaraba 45— y dejaba la comprobación ciega
            // justo para lo que existe, un guion del esquema sin aplicar.
            //
            // El segundo: contar tampoco basta. Medido en local, con una tabla
            // que una prueba deja olvidada, la base tenía **46 contra 45** y la
            // página decía «Todo en orden» con `>=`. La cuenta se cuadra sola: a
            // una base a la que le falte una tabla del negocio y le sobre una de
            // basura le salen los mismos 45, y entonces **la basura tapa el
            // hueco**. Comparar nombres no se puede cuadrar, y además dice
            // **cuál** falta, que es lo que sirve a quien está desplegando de
            // noche. Lo que sobra se dice pero no pone en rojo: una tabla de más
            // no es un problema de despliegue.
            $faltan = $this->tablasQueFaltan($bd);
            $sobran = $this->tablasQueSobran($bd);

            $detalle = $version . ' · ' . count($this->tablasDelEsquema()) . ' tablas del esquema';

            if ($faltan !== []) {
                $detalle .= ' · ⚠️ faltan: ' . implode(', ', $faltan);
            }

            if ($sobran !== []) {
                $detalle .= ' · sobran (no es problema de despliegue): ' . implode(', ', $sobran);
            }

            $comprobaciones['Base de datos'] = [$faltan === [], $detalle];
        } catch (\Throwable $e) {
            $comprobaciones['Base de datos'] = [false, 'sin conexión'];
        }

        $filas = '';
        $todoBien = true;
        foreach ($comprobaciones as $nombre => [$bien, $detalle]) {
            $todoBien = $todoBien && $bien;
            $marca    = $bien ? '✅' : '❌';
            $nombreSeguro  = htmlspecialchars((string) $nombre, ENT_QUOTES, 'UTF-8');
            $detalleSeguro = htmlspecialchars((string) $detalle, ENT_QUOTES, 'UTF-8');
            $filas .= "<tr><td>{$marca}</td><td>{$nombreSeguro}</td><td>{$detalleSeguro}</td></tr>";
        }

        $resumen = $todoBien ? 'Todo en orden' : 'Hay algo fuera de lugar';

        $html = <<<HTML
        <!doctype html>
        <html lang="es">
        <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Diagnóstico · El Timón</title>
        <style>
          body { margin:0; min-height:100vh; display:grid; place-items:center;
                 background:#F4F1EA; color:#172D4D;
                 font:16px/1.6 system-ui, -apple-system, "Segoe UI", sans-serif; }
          main { max-width:40rem; padding:2rem; }
          h1 { color:#172D4D; margin:0 0 .25rem; }
          p.resumen { color:#172D4D; font-weight:600; margin:0 0 1.5rem; }
          table { border-collapse:collapse; width:100%; background:#fff;
                  border-radius:.5rem; overflow:hidden; }
          td { padding:.6rem .8rem; border-bottom:1px solid #E3DDD0; }
          td:first-child { width:2rem; text-align:center; }
          td:last-child { color:#5B6675; font-family:ui-monospace, monospace; font-size:.9rem; }
          tr:last-child td { border-bottom:0; }
        </style>
        </head>
        <body>
          <main>
            <h1>Diagnóstico</h1>
            <p class="resumen">{$resumen}</p>
            <table>{$filas}</table>
          </main>
        </body>
        </html>
        HTML;

        return Respuesta::html($html, $todoBien ? 200 : 503);
    }

    /**
     * Qué tablas declaran los guiones de `esquema/`.
     *
     * Leer los nombres de los `CREATE TABLE` es más burdo que interpretar el
     * DDL, y es exactamente lo que hace falta: saber si la base tiene lo que el
     * código espera sin que nadie tenga que acordarse de subir un número.
     *
     * @return list<string>
     */
    private function tablasDelEsquema(): array
    {
        $guiones = glob(dirname(__DIR__, 2) . '/esquema/*.sql') ?: [];
        sort($guiones, SORT_STRING);

        return MigracionesEsquema::tablasDeclaradas($guiones);
    }

    /**
     * Las del esquema que no están en la base: un guion sin aplicar.
     *
     * @return list<string>
     */
    private function tablasQueFaltan(BaseDatos $bd): array
    {
        return array_values(array_diff($this->tablasDelEsquema(), $this->tablasDeLaBase($bd)));
    }

    /**
     * Las de la base que el esquema no declara. Se dicen, no alarman.
     *
     * @return list<string>
     */
    private function tablasQueSobran(BaseDatos $bd): array
    {
        return array_values(array_diff($this->tablasDeLaBase($bd), $this->tablasDelEsquema()));
    }

    /** @return list<string> */
    private function tablasDeLaBase(BaseDatos $bd): array
    {
        $tablas = [];

        foreach ($bd->filas(
            "SELECT table_name AS t FROM information_schema.tables
             WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'"
        ) as $fila) {
            $tablas[] = strtolower((string) $fila['t']);
        }

        return $tablas;
    }

}
