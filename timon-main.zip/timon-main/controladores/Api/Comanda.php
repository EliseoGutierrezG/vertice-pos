<?php
declare(strict_types=1);

namespace Controladores\Api;

use Controladores\Controlador;
use Dominio\DatosRestaurante as Datos;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Errores\Errores;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Servicios\CajaRestaurante;
use Servicios\CocinaRestaurante;
use Servicios\Comandas;
use Servicios\CuentasSeparadas;
use Servicios\ImpresionRestaurante;
use Servicios\MenuRestaurante;

#[Modulo('comanda', 'Comanda')]
final class Comanda extends Controlador
{
    public function __construct(
        private Comandas $comandas,
        private CuentasSeparadas $separadas,
        private MenuRestaurante $menu,
        private CocinaRestaurante $cocina,
        private CajaRestaurante $caja,
        private ImpresionRestaurante $impresion
    ) {
    }

    #[Accion('plano_ver')]
    public function plano(Peticion $p): Respuesta
    {
        return $this->ok($this->comandas->plano($this->sucursal($p, ['mesero','caja','gerencia'])));
    }

    #[Accion('comanda_ver,cocina_opera')]
    public function cambios(Peticion $p): Respuesta
    {
        return $this->ok($this->comandas->cambios(
            $this->sucursal($p, ['mesero','caja','cocina','barra','gerencia','impresor']),
            $p->consulta('desde') === null ? null : Datos::entero($p->consulta('desde'), 'desde', 0)
        ));
    }

    #[Accion('menu_ver')]
    public function menu(Peticion $p): Respuesta
    {
        // La carta pesa y cambia poco: quien ya la tiene recibe un 304 sin cuerpo.
        $carta = $this->menu->cartaConHuella($this->sucursal($p, ['mesero','caja','gerencia','cocina','barra']));
        if (trim((string) $p->cabecera('if-none-match', '')) === $carta['huella']) {
            return Respuesta::noModificada($carta['huella']);
        }
        return $this->ok($carta['platillos'])->conCabecera('ETag', $carta['huella']);
    }

    #[Accion('menu_agota')]
    public function agota(Peticion $p): Respuesta
    {
        return $this->ok($this->menu->agota($this->sucursal($p, ['cocina','barra','gerencia']), $p->acceso()['tipo'],
            (int) $p->parametro('id'), $this->llave($p), $p->dato('agotado')));
    }

    #[Accion('comanda_ver')]
    public function cuenta(Peticion $p): Respuesta
    {
        return $this->ok($this->comandas->cuenta($this->sucursal($p, ['mesero','caja','gerencia']), (int) $p->parametro('id')));
    }

    #[Accion('comanda_captura')]
    public function abre(Peticion $p): Respuesta
    {
        return $this->ok($this->comandas->abrir(
            $this->sucursal($p, ['mesero','caja','gerencia']), $this->llave($p), $p->datos()
        ), 201);
    }

    #[Accion('comanda_captura')]
    public function accion(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p, ['mesero','caja','gerencia']);
        $id = (int) $p->parametro('id');
        $llave = $this->llave($p);
        $accion = $p->parametro('accion');
        // Sólo las operaciones que compiten exigen la versión. En las demás
        // se ignora si llega: así una app anterior sigue funcionando.
        $version = in_array($accion, ['cambia-mesa', 'une-mesa', 'transfiere', 'cancelar', 'separa', 'reparte', 'reune'], true)
            ? Datos::entero($p->dato('version'), 'version') : 0;
        $respuesta = match ($accion) {
            'cambia-mesa' => $this->comandas->cambiarMesa($sucursal, $id, $version, Datos::entero($p->dato('id_mesa'), 'id_mesa'), $llave),
            'une-mesa' => $this->comandas->unirMesa($sucursal, $id, $version, Datos::entero($p->dato('id_mesa'), 'id_mesa'), $llave),
            'items' => $this->comandas->agregar($sucursal, $id, $llave, $p->datos()),
            'edita-item' => $this->comandas->editaItem($sucursal, $id, $llave, $p->datos()),
            'rondas' => $this->comandas->enviar($sucursal, $id, $llave),
            'estado-item' => $this->comandas->cambiaItem($sucursal, $id, $llave, $p->datos(), $p->ip()),
            'entrega' => $this->comandas->entrega($sucursal, $id, $llave, $p->datos()),
            'transfiere' => $this->comandas->transfiere($sucursal, $id, $version, $llave, $p->datos()),
            'cancelar' => $this->comandas->cancelaCuenta($sucursal, $id, $version, $llave),
            'separa' => $this->separadas->separa($sucursal, $id, $version, $llave, $p->datos()),
            'reparte' => $this->separadas->reparte($sucursal, $id, $version, $llave, Datos::entero($p->dato('partes'), 'partes', 2, 20)),
            'reune' => $this->separadas->reune($sucursal, $id, $version, $llave, $p->datos()),
            'precuenta' => $this->comandas->pedirCuenta($sucursal, $id, $llave),
            default => throw Errores::noEncontrado(),
        };
        return $this->ok($respuesta, in_array($accion, ['items','rondas'], true) ? 201 : 200);
    }

    #[Accion('comanda_captura')]
    public function limpiaMesa(Peticion $p): Respuesta
    {
        return $this->ok($this->comandas->limpiaMesa(
            $this->sucursal($p, ['mesero','caja','gerencia']), (int) $p->parametro('id'), $this->llave($p)
        ));
    }

    #[Accion('comanda_ver')]
    public function pedidos(Peticion $p): Respuesta
    {
        return $this->ok($this->comandas->pedidos($this->sucursal($p, ['mesero','caja','gerencia'])));
    }

    #[Accion('cocina_opera')]
    public function cocina(Peticion $p): Respuesta
    {
        return $this->ok($this->cocina->lista($this->sucursal($p, ['cocina','barra']), $p->acceso()['tipo']));
    }

    #[Accion('cocina_opera')]
    public function cocinaAvanza(Peticion $p): Respuesta
    {
        return $this->ok($this->cocina->avanza(
            $this->sucursal($p, ['cocina','barra']), $p->acceso()['tipo'], (int) $p->parametro('id'),
            Datos::opcion($p->dato('area'), 'area', array_keys(MenuRestaurante::AREAS)),
            (string) $p->parametro('accion'), $this->llave($p)
        ));
    }

    #[Accion('comanda_cobra')]
    public function caja(Peticion $p): Respuesta
    {
        return $this->ok($this->caja->estado($this->sucursal($p, ['caja','gerencia'])));
    }

    #[Accion('comanda_cobra')]
    public function cajaAccion(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p, ['caja','gerencia']);
        $llave = $this->llave($p);
        $resultado = match ($p->parametro('accion')) {
            'abrir' => $this->caja->abre($sucursal, $llave, $p->dato('fondo')),
            'cerrar' => $this->caja->cierra($sucursal, $llave, Datos::entero($p->dato('id_turno'), 'id_turno'), $p->dato('efectivo')),
            'movimiento' => $this->caja->movimiento($sucursal, $llave, $p->datos()),
            default => throw Errores::noEncontrado(),
        };
        return $this->ok($resultado);
    }

    #[Accion('comanda_cobra')]
    public function cobra(Peticion $p): Respuesta
    {
        return $this->ok($this->caja->cobra(
            $this->sucursal($p, ['caja','gerencia']), (int) $p->parametro('id'), Datos::entero($p->dato('version'), 'version'),
            $this->llave($p), $p->datos(), $p->ip()
        ), 201);
    }

    #[Accion('comanda_cobra')]
    public function cotiza(Peticion $p): Respuesta
    {
        return $this->ok($this->caja->cotiza($this->sucursal($p, ['caja','gerencia']), $p->datos()));
    }

    #[Accion('comanda_cobra')]
    public function mostrador(Peticion $p): Respuesta
    {
        return $this->ok($this->caja->mostrador(
            $this->sucursal($p, ['caja','gerencia']), $this->llave($p), $p->datos(), $p->ip()
        ), 201);
    }

    #[Accion('cocina_opera,comanda_cobra')]
    public function trabajos(Peticion $p): Respuesta
    {
        return $this->ok($this->impresion->trabajos($this->sucursal($p, ['caja','gerencia','cocina','barra'])));
    }

    #[Accion('cocina_opera,comanda_cobra')]
    public function reimprime(Peticion $p): Respuesta
    {
        return $this->ok($this->impresion->reimprime($this->sucursal($p, ['caja','gerencia','cocina','barra']),
            (int) $p->parametro('id'), $this->llave($p)), 201);
    }

    #[Accion('cocina_opera')]
    public function tomaImpresion(Peticion $p): Respuesta
    {
        return $this->ok($this->impresion->toma($this->sucursal($p, ['impresor']), (int) $p->acceso()['id_equipo']));
    }

    #[Accion('cocina_opera')]
    public function confirmaImpresion(Peticion $p): Respuesta
    {
        if (!is_bool($p->dato('impreso'))) {
            throw Errores::datosInvalidos(['impreso' => 'Indique si la impresión terminó']);
        }
        $this->impresion->confirma($this->sucursal($p, ['impresor']), (int) $p->acceso()['id_equipo'],
            (int) $p->parametro('id'), $p->dato('impreso'),
            $p->dato('intento') === null ? null : Datos::entero($p->dato('intento'), 'intento', 1, 3),
            $p->dato('reintentable') === true);
        return $this->ok();
    }

    private function llave(Peticion $p): string
    {
        return $p->cabecera('idempotency-key', '') ?? '';
    }

    private function sucursal(Peticion $p, array $tipos): int
    {
        $acceso = $p->acceso();
        if (!in_array($acceso['tipo'], $tipos, true)) {
            throw Errores::prohibido('Acción ajena al modo del equipo');
        }
        return (int) $acceso['id_sucursal'];
    }
}
