<?php
declare(strict_types=1);

namespace Controladores\Api;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Errores\Errores;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Servicios\Instalaciones;
use Servicios\Liberaciones;
use Servicios\Replica as Servicio;

/**
 * Lo que pide la computadora de sucursal al central: la réplica
 * (`guiones/sincroniza.php`) y sus actualizaciones (`guiones/actualiza.php`).
 * Todas las rutas pasan por `ExigeInstalacion`; son públicas para el control
 * de permisos porque quien llama no es una persona.
 */
#[Modulo('replica', 'Réplica con servidores de sucursal')]
final class Replica extends Controlador
{
    public function __construct(private Servicio $replica, private Instalaciones $instalaciones, private Liberaciones $liberaciones)
    {
    }

    #[Accion(publica: true)]
    public function catalogo(Peticion $p): Respuesta
    {
        $instalacion = $this->instalacion($p);
        $catalogo = $this->replica->catalogo($instalacion['id_sucursal']);
        $this->instalaciones->anota($instalacion['id'], 'bajada', $this->pendientes($p), (string) $p->cabecera('x-version', ''));
        // El esquema del central, para que una computadora atrasada espere a
        // actualizarse en lugar de tropezar con columnas que no tiene.
        $esquema = $this->replica->esquema();
        if ((string) $p->consulta('huella', '') === $catalogo['huella']) {
            return $this->ok(['huella' => $catalogo['huella'], 'esquema' => $esquema, 'cambio' => false]);
        }

        return $this->ok(['huella' => $catalogo['huella'], 'esquema' => $esquema, 'cambio' => true, 'tablas' => $catalogo['tablas']]);
    }

    #[Accion(publica: true)]
    public function arranque(Peticion $p): Respuesta
    {
        $instalacion = $this->instalacion($p);

        return $this->ok(['tablas' => $this->replica->arranque($instalacion['id_sucursal'])]);
    }

    #[Accion(publica: true)]
    public function subida(Peticion $p): Respuesta
    {
        $instalacion = $this->instalacion($p);
        $filas = $p->dato('filas');
        if (!is_array($filas) || count($filas) > Servicio::LOTE * 2) {
            throw Errores::datosInvalidos(['filas' => 'Mande de 0 a ' . (Servicio::LOTE * 2) . ' filas']);
        }
        try {
            $hecho = $this->replica->aplicaSubida($instalacion, array_values($filas));
        } catch (ErrorHttp $e) {
            $this->instalaciones->anota($instalacion['id'], 'error', $this->pendientes($p), (string) $p->cabecera('x-version', ''), $e->getMessage());
            throw $e;
        }
        $this->instalaciones->anota($instalacion['id'], 'subida', $this->pendientes($p), (string) $p->cabecera('x-version', ''));

        return $this->ok($hecho);
    }

    /** La versión del sistema que debe tener esta computadora, firmada; null es quedarse como está. */
    #[Accion(publica: true)]
    public function liberacion(Peticion $p): Respuesta
    {
        return $this->ok(['asignada' => $this->liberaciones->asignada($this->instalacion($p)['id'])]);
    }

    /** El paquete de la versión asignada, reanudable con `Range`. */
    #[Accion(publica: true)]
    public function paquete(Peticion $p): Respuesta
    {
        $ruta = $this->liberaciones->paqueteDe($this->instalacion($p)['id'], (string) $p->consulta('id', ''));

        return Respuesta::archivoEnDisco($ruta, 'application/gzip', $p->cabecera('range'));
    }

    /** Cómo va la actualización, para la pantalla «Operación local». */
    #[Accion(publica: true)]
    public function actualizacion(Peticion $p): Respuesta
    {
        $estado = $p->dato('estado');
        if (!is_string($estado) || trim($estado) === '') {
            throw Errores::datosInvalidos(['estado' => 'Mande el estado de la actualización']);
        }
        $this->liberaciones->anota($this->instalacion($p)['id'], $estado, (bool) $p->dato('error', false), (bool) $p->dato('aplicada', false));

        return $this->ok(['anotado' => true]);
    }

    /** @return array{id:int,id_sucursal:int,nombre:string,desplazamiento:int} */
    private function instalacion(Peticion $p): array
    {
        $acceso = $p->acceso();
        if (!is_array($acceso['instalacion'] ?? null)) {
            throw Errores::noAutenticado('Computadora de sucursal no registrada');
        }

        return $acceso['instalacion'];
    }

    private function pendientes(Peticion $p): int
    {
        return max(0, (int) $p->cabecera('x-pendientes', '0'));
    }
}
