<?php
declare(strict_types=1);

namespace Controladores\Api;

use Controladores\Controlador;
use Dominio\DatosRestaurante as Datos;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Servicios\EquiposRestaurante;

#[Modulo('equipo_restaurante', 'Equipos de comanda')]
final class EquipoRestaurante extends Controlador
{
    public function __construct(private EquiposRestaurante $equipos)
    {
    }

    #[Accion(publica: true)]
    public function registra(Peticion $p): Respuesta
    {
        return $this->ok($this->equipos->alta($p->datos(), $p->ip()), 201);
    }

    #[Accion(publica: true)]
    public function estado(Peticion $p): Respuesta
    {
        return $this->ok($this->equipos->estado($p->cabecera('x-equipo', '') ?? ''));
    }

    #[Accion(publica: true)]
    public function entra(Peticion $p): Respuesta
    {
        return $this->ok($this->equipos->entrar(
            $p->cabecera('x-equipo', '') ?? '',
            Datos::texto($p->dato('usuario'), 'usuario', 60),
            Datos::texto($p->dato('pin'), 'pin', 6),
            $p->ip()
        ));
    }

    #[Accion(publica: true)]
    public function sale(Peticion $p): Respuesta
    {
        $this->equipos->sale($p->acceso()['token_equipo']);
        return $this->ok();
    }

    #[Accion(publica: true)]
    public function actividad(Peticion $p): Respuesta
    {
        return $this->ok();
    }
}
