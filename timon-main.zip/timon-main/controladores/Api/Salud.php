<?php
declare(strict_types=1);

namespace Controladores\Api;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\BaseDatos;
use Nucleo\Contenedor;
use Nucleo\Instalacion;
use Nucleo\Peticion;
use Nucleo\Respuesta;

/**
 * El latido de la API.
 *
 * La app lo consulta antes de sincronizar: si esto no responde, no tiene caso
 * intentar subir la cola de operaciones. Es la única ruta de la API que no
 * pide token, y a propósito no dice nada que no se pueda decir en público.
 */
#[Modulo('api_salud', 'Latido de la API')]
final class Salud extends Controlador
{
    public function __construct(private Contenedor $contenedor)
    {
    }

    #[Accion(publica: true)]
    public function ver(Peticion $peticion): Respuesta
    {
        $baseViva = true;
        $versionEsquema = null;
        try {
            /** @var BaseDatos $bd */
            $bd = $this->contenedor->obtiene(BaseDatos::class);
            $bd->valor('SELECT 1');
            try {
                $versionEsquema = (int) $bd->valor('SELECT MAX(numero) FROM migracion_esquema');
            } catch (\Throwable $e) {
                // Una base anterior a 022 sigue contestando salud; el null deja
                // visible que todavía no tiene gobierno de migraciones.
                $versionEsquema = null;
            }
        } catch (\Throwable $e) {
            $baseViva = false;
        }

        $datos = [
            'servicio' => 'api',
            'version'  => 'v1',
            'base'     => $baseViva ? 'viva' : 'sin conexión',
            'liberacion' => (string) $this->contenedor->config('liberacion', 'sin-identificar'),
            'esquema'  => $versionEsquema,
            'momento'  => date('c'),
        ];
        $datos += \Servicios\AppMovil::datos($this->raiz());
        // En el servidor de sucursal, si alcanza al central y cuánto falta por
        // subir: la app avisa «Sin internet: todo funciona».
        if ($this->contenedor->obtiene(Instalacion::class)->esSucursal()) {
            $estado = json_decode((string) @file_get_contents($this->raiz() . '/almacenamiento/replica/estado.json'), true);
            $datos['central'] = [
                'alcanzable' => (bool) ($estado['alcanzable'] ?? false),
                'pendientes' => (int) ($estado['pendientes'] ?? 0),
                'espera_actualizacion' => (bool) ($estado['espera_actualizacion'] ?? false),
            ];
        }

        return $this->ok($datos, $baseViva ? 200 : 503);
    }

    /**
     * Lo que la app pregunta justo antes de sincronizar.
     *
     * Exige token Y dispositivo autorizado: es la primera puerta que se topa
     * un teléfono que todavía está en espera, y el sitio donde se comprueba
     * que esa puerta cierra.
     */
    private function raiz(): string
    {
        return dirname(__DIR__, 2);
    }

    /** Descarga local: también funciona cuando no hay internet. */
    #[Accion(publica: true)]
    public function apk(Peticion $peticion): Respuesta
    {
        $ruta = $this->raiz() . '/movil/comanda.apk';
        if (!is_file($ruta)) {
            throw \Nucleo\Errores\Errores::noEncontrado('Todavía no hay un APK disponible en esta computadora');
        }
        return Respuesta::archivoEnDisco($ruta, 'application/vnd.android.package-archive', $peticion->cabecera('range'))
            ->conCabecera('Content-Disposition', 'attachment; filename="el-timon.apk"');
    }

    #[Accion(publica: true)]
    public function listoParaSincronizar(Peticion $peticion): Respuesta
    {
        return $this->ok([
            'puede_sincronizar' => true,
            'servidor'          => date('c'),
        ]);
    }
}
