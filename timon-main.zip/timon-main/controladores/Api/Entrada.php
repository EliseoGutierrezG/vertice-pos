<?php
declare(strict_types=1);

namespace Controladores\Api;

use Controladores\Controlador;
use Modelos\Dispositivos;
use Modelos\IntentosAcceso;
use Modelos\Tokens;
use Modelos\Usuarios;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Registro;
use Nucleo\Respuesta;

/**
 * Acceso de la app de campo.
 *
 * El teléfono manda usuario, contraseña y su identificador. Si todo cuadra,
 * recibe un token. Pero el token **no basta**: mientras el dispositivo no se
 * autorice desde la web, sólo sirve para preguntar "¿ya me autorizaron?".
 *
 * Que se entregue token a un dispositivo sin autorizar es a propósito: así la
 * app puede decirle al vendedor "tu teléfono está en espera" en lugar de
 * rechazarlo sin explicación, que es cuando la gente llama por teléfono.
 */
#[Modulo('api_entrada', 'Acceso de la app')]
final class Entrada extends Controlador
{
    public function __construct(
        private Usuarios $usuarios,
        private Dispositivos $dispositivos,
        private Tokens $tokens,
        private Identidad $identidad,
        private Bitacora $bitacora,
        private Registro $registro,
        private IntentosAcceso $intentos,
        private BaseDatos $bd
    ) {
    }

    #[Accion(publica: true)]
    public function entra(Peticion $peticion): Respuesta
    {
        $datos = $peticion->datos();
        $this->exige($datos, ['usuario', 'clave', 'dispositivo']);

        $usuario = trim((string) $datos['usuario']);
        $clave   = (string) $datos['clave'];

        /** @var array<string,mixed> $dispositivo */
        $dispositivo   = (array) $datos['dispositivo'];
        $identificador = trim((string) ($dispositivo['identificador'] ?? ''));

        if ($identificador === '') {
            throw Errores::datosInvalidos(['dispositivo' => 'No se reconoció el teléfono. Entre de nuevo']);
        }

        $reintentarEn = $this->intentos->reintento('entrada', $usuario, $peticion->ip());
        if ($reintentarEn > 0) {
            throw Errores::demasiadosIntentos($reintentarEn);
        }

        // El mismo camino que la web, y en tiempo parejo.
        $registro = $this->usuarios->autentica($usuario, $clave);

        if ($registro === null) {
            $reintentarEn = $this->intentos->falla('entrada', $usuario, $peticion->ip());
            $this->registro->aviso('Acceso fallido por la API', [
                'ip_hash' => IntentosAcceso::hashDireccion($peticion->ip()),
            ]);

            if ($reintentarEn > 0) {
                throw Errores::demasiadosIntentos($reintentarEn);
            }

            // El mismo mensaje pase lo que pase, igual que en la web.
            throw Errores::noAutenticado('Usuario o contraseña incorrectos');
        }

        /** @var array<string,mixed> $registro */
        $idUsuario = (int) $registro['id'];
        $this->intentos->acierta('entrada', $usuario, $peticion->ip());

        // Una contraseña temporal la vio alguien más: no se le da token hasta
        // que su dueño la cambie, desde la app (`/cambiar-clave`) o la web. La
        // contraseña sí era correcta, así que no cuenta como intento fallido.
        if ((int) $registro['cambiar_clave'] === 1) {
            throw new \Nucleo\Errores\ErrorHttp(
                403,
                'Su contraseña es temporal: cámbiela para entrar.',
                'clave_temporal'
            );
        }

        $telefono = $this->dispositivos->registraOEncuentra(
            $idUsuario,
            $identificador,
            isset($dispositivo['nombre']) ? (string) $dispositivo['nombre'] : null
        );

        $token = $this->tokens->emite($idUsuario, (int) $telefono['id']);

        $this->identidad->establece($idUsuario);

        $this->bitacora->registra(
            'api_entrada',
            'entra',
            'dispositivo',
            (int) $telefono['id'],
            despues:   ['autorizado' => (int) $telefono['autorizado']],
            idUsuario: $idUsuario,
            ip:        $peticion->ip()
        );

        return $this->ok([
            // Existe una sola vez: de aquí en adelante sólo lo tiene el teléfono.
            'token'       => $token,
            'usuario'     => [
                'id'     => $idUsuario,
                'nombre' => $this->identidad->nombre(),
                'puesto' => $this->identidad->puesto(),
            ],
            'permisos'    => $this->identidad->permisos(),
            'dispositivo' => [
                'autorizado' => (int) $telefono['autorizado'] === 1,
                'aviso'      => (int) $telefono['autorizado'] === 1
                    ? null
                    : 'Equipo sin autorizar. Avise a la gerencia de su sucursal.',
            ],
        ]);
    }

    /**
     * Cambia una contraseña **temporal** sin token: quien la tiene todavía no
     * puede entrar, así que se identifica con ella, igual que en `/entrar` y
     * con el mismo freno de intentos. Después la app entra con la nueva.
     *
     * Sólo la temporal: una definitiva se cambia ya dentro, en la web.
     */
    #[Accion(publica: true)]
    public function cambiaClave(Peticion $peticion): Respuesta
    {
        $datos = $peticion->datos();
        $this->exige($datos, ['usuario', 'clave', 'clave_nueva', 'confirma']);

        $usuario = trim((string) $datos['usuario']);
        $clave = (string) $datos['clave'];
        $nueva = (string) $datos['clave_nueva'];

        $reintentarEn = $this->intentos->reintento('entrada', $usuario, $peticion->ip());
        if ($reintentarEn > 0) {
            throw Errores::demasiadosIntentos($reintentarEn);
        }

        $registro = $this->usuarios->autentica($usuario, $clave);
        if ($registro === null) {
            $reintentarEn = $this->intentos->falla('entrada', $usuario, $peticion->ip());
            if ($reintentarEn > 0) {
                throw Errores::demasiadosIntentos($reintentarEn);
            }
            throw Errores::noAutenticado('Usuario o contraseña incorrectos');
        }
        $this->intentos->acierta('entrada', $usuario, $peticion->ip());

        if ((int) $registro['cambiar_clave'] !== 1) {
            throw Errores::conflicto('Su contraseña no es temporal: cámbiela desde la web');
        }

        $errores = [];
        if (($queja = Usuarios::quejaDeClave($nueva, (string) $registro['usuario'])) !== null) {
            $errores['clave_nueva'] = $queja;
        } elseif (hash_equals($clave, $nueva)) {
            $errores['clave_nueva'] = 'Tiene que ser distinta de la temporal';
        } elseif (!hash_equals($nueva, (string) $datos['confirma'])) {
            $errores['confirma'] = 'No coincide con la nueva';
        }
        if ($errores !== []) {
            throw Errores::datosInvalidos($errores);
        }

        $idUsuario = (int) $registro['id'];
        $this->bd->transaccion(function () use ($idUsuario, $nueva, $peticion): void {
            $this->usuarios->cambiaClave($idUsuario, $nueva, temporal: false);
            $this->usuarios->revocaTokens($idUsuario);
            $this->bitacora->registra('api_entrada', 'cambia_clave', 'usuario', $idUsuario,
                despues: ['clave' => 'temporal_a_propia'], idUsuario: $idUsuario, ip: $peticion->ip());
        });

        return Respuesta::sinContenido();
    }

    /**
     * Quién soy y qué puedo. La app lo consulta antes de cada subida para
     * saber si su token sigue vivo.
     *
     * Sólo exige token: contesta aunque el teléfono siga en espera de
     * autorización (ver `rutas/api.php`). Que ya puede operar lo dice una
     * bajada que contesta, no esta ruta.
     */
    #[Accion(publica: true)]
    public function yo(Peticion $peticion): Respuesta
    {
        return $this->ok([
            'usuario'  => [
                'id'     => $this->identidad->id(),
                'nombre' => $this->identidad->nombre(),
                'puesto' => $this->identidad->puesto(),
            ],
            'permisos' => $this->identidad->permisos(),
        ]);
    }

    #[Accion(publica: true)]
    public function sale(Peticion $peticion): Respuesta
    {
        $cabecera = $peticion->cabecera('authorization', '') ?? '';

        if (preg_match('/^Bearer\s+(\S+)$/i', $cabecera, $coincidencia) === 1) {
            $token = $coincidencia[1];
            $this->bd->transaccion(function () use ($token, $peticion): void {
                $quien = $this->tokens->revoca($token);
                if ($quien === null) return;
                $this->bitacora->registra(
                    'api_entrada', 'sale', 'dispositivo', $quien['id_dispositivo'],
                    idUsuario: $quien['id_usuario'], ip: $peticion->ip()
                );
            });
        }

        return Respuesta::sinContenido();
    }
}
