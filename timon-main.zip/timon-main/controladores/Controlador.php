<?php
declare(strict_types=1);

namespace Controladores;

use Dominio\Cantidad;
use Dominio\Dinero;
use Dominio\Numero;
use Nucleo\Errores\Errores;
use Nucleo\Exporta\Xlsx;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;

/**
 * Lo común a todos los controladores.
 *
 * Un controlador hace tres cosas y ninguna más: valida lo que entra, le pide
 * el trabajo a quien sabe hacerlo, y arma la respuesta. Las reglas del negocio
 * no viven aquí; viven en dominio/ y en los servicios.
 */
abstract class Controlador
{
    protected function ok(mixed $datos = null, int $estado = 200): Respuesta
    {
        return Respuesta::json($datos, $estado);
    }

    /**
     * Lo que se contesta después de guardar desde una pantalla.
     *
     * Los formularios de la v2 viven en modales y se mandan por `fetch`
     * (`plantilla.js`, `form[data-pb-ajax]`): así un 422 pinta cada queja debajo
     * de su campo **sin cerrar el modal ni perder lo capturado**. A ellos se les
     * contesta JSON con a dónde ir. Un POST de formulario de toda la vida —sin
     * JavaScript, o `curl`— recibe la redirección de siempre. El aviso va a la
     * sesión en los dos casos y lo pinta la pantalla siguiente.
     */
    protected function hecho(Peticion $peticion, Sesion $sesion, string $destino, string $aviso): Respuesta
    {
        $sesion->avisa($aviso);

        return $peticion->esperaJson()
            ? $this->ok(['redirige' => $destino])
            : Respuesta::redireccion($destino);
    }

    /**
     * La ficha de un registro (Fase 4): ya no es una página. Pedida como JSON
     * (el modal de detalle) devuelve su título, el fragmento ya pintado y, si
     * se da, el registro para llenar el modal de «Actualizar». La URL vieja
     * abierta en el navegador vuelve al listado con `?ver={id}`.
     *
     * @param callable():array{titulo:string,html:string,registro?:array<string,mixed>} $arma
     */
    protected function fichaEnModal(Peticion $peticion, string $listado, int $id, callable $arma, array $filtros = []): Respuesta
    {
        if (!$peticion->esperaJson()) {
            return Respuesta::redireccion($listado . '?' . http_build_query(['ver' => $id] + $filtros, encoding_type: PHP_QUERY_RFC3986));
        }

        return $this->ok($arma());
    }

    /**
     * «Exportar XLS» (homologación §7, D20): el archivo, con su nombre de
     * pantalla y fecha, y sin guardarse en caché.
     *
     * @param list<array{titulo:string,tipo?:string}> $columnas
     * @param iterable<list<mixed>>                   $filas
     */
    protected function xlsx(string $pantalla, array $columnas, iterable $filas, string ...$fechas): Respuesta
    {
        return Respuesta::archivo(
            Xlsx::de($pantalla, $columnas, $filas),
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )->conCabecera('Content-Disposition', 'attachment; filename="' . Xlsx::archivo($pantalla, ...$fechas) . '"');
    }

    /**
     * El filtro de estatus de una lista de catálogo: `activas` salvo que se
     * pida `inactivas` o `todas`. Lo que no se entiende no es un error: es la
     * lista de siempre.
     */
    protected function filtroEstatus(Peticion $peticion): string
    {
        $estatus = (string) $peticion->consulta('estatus', 'activas');

        return in_array($estatus, ['activas', 'inactivas', 'todas'], true) ? $estatus : 'activas';
    }

    /**
     * A dónde volver después de guardar: a la lista, con su filtro, o a la
     * ficha, según de dónde se mandó el formulario (campo `volver`).
     *
     * Sólo se acepta una ruta de las pantallas que se nombran —`$raiz`,
     * `$raiz/123` y una consulta de letras, números, `_`, `=` y `&`—. Cualquier
     * otra cosa vuelve al destino fijo: un campo oculto se puede cambiar, y una
     * redirección a donde diga el cliente es la puerta clásica para mandar a
     * alguien fuera.
     *
     * @param string|list<string> $raiz Una pantalla, o varias: un teléfono se
     *        autoriza desde su lista y desde la ficha de la persona.
     */
    protected function regreso(Peticion $peticion, string|array $raiz, string $porOmision): string
    {
        $volver = (string) $peticion->dato('volver', '');

        foreach ((array) $raiz as $una) {
            // La consulta admite fechas, folios y búsquedas (`-`, `+`, `%`), nunca otra ruta.
            $patron = '#^' . preg_quote($una, '#') . '(/\d+)?(\?[A-Za-z0-9_=&%+.\-]*)?$#';

            if (preg_match($patron, $volver) === 1) {
                return $volver;
            }
        }

        return $porOmision;
    }

    /**
     * Exige que estos campos vengan y no estén vacíos.
     *
     * Devuelve TODOS los que faltan de una vez, no el primero: quien captura
     * merece ver la lista completa en lugar de corregir de uno en uno.
     *
     * @param array<string,mixed> $datos
     * @param list<string> $obligatorios
     */
    protected function exige(array $datos, array $obligatorios): void
    {
        $faltantes = [];

        foreach ($obligatorios as $campo) {
            $valor = $datos[$campo] ?? null;
            if ($valor === null || $valor === '' || $valor === []) {
                $faltantes[$campo] = 'Es obligatorio';
            }
        }

        if ($faltantes !== []) {
            throw Errores::datosInvalidos($faltantes);
        }
    }

    /**
     * Una fecha escrita por alguien, en el formato en que la base la entiende.
     *
     * ⚠️ Antes las cuatro pantallas que reciben una fecha —precio, impuesto,
     * compra y hoja de reparto— la pasaban con un `trim()` a una columna `DATE`.
     * Los `<input type="date">` del navegador mandan siempre `AAAA-MM-DD`, así
     * que en el uso normal nunca se notó; pero cualquier cosa que no venga del
     * navegador —un formulario viejo, un guion, `curl`— llegaba a MariaDB y
     * salía por **500**: `hola` daba 500, `2026-13-45` daba 500, y `2026/07/01`
     * se **aceptaba**, no porque estuviera validado sino porque el motor es
     * indulgente con las diagonales. Validado por el motor, no por nosotros, es
     * validado hasta que el motor cambie de opinión.
     *
     * Aquí y no en cada controlador porque son cuatro campos con la misma regla:
     * el mismo argumento que `Dominio\Redondeo` tiene escrito para el redondeo.
     *
     * Se llama `fechaEscrita` y no `fecha` porque `Reportes` y `BitacoraWeb` ya
     * tienen una `fecha()` **privada** con otra firma, y en PHP una privada del
     * hijo no puede tapar una protegida del padre: el nombre corto tumbaba las
     * dos pantallas con un error fatal. Lo encontró la tanda de pruebas.
     */
    protected function fechaEscrita(string $texto, string $campo = 'fecha'): string
    {
        $texto = trim($texto);

        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $texto, $partes) !== 1) {
            throw Errores::datosInvalidos([$campo => 'Capture la fecha como 2026-09-24']);
        }

        // El formato no basta: 2026-02-31 lo cumple y no existe.
        if (!checkdate((int) $partes[2], (int) $partes[3], (int) $partes[1])) {
            throw Errores::datosInvalidos([$campo => 'Esa fecha no existe en el calendario']);
        }

        return $texto;
    }

    /**
     * El número que escribió una persona, listo para `Dinero` o `Cantidad`.
     *
     * La regla vive en `Dominio\Numero`, que es de donde la toman también los
     * servicios; aquí sólo se convierte su queja en un 422 con el nombre del
     * campo, que es lo que necesita una pantalla. Quien llame sigue decidiendo
     * si acepta el cero y el negativo: eso cambia por campo.
     */
    protected function numeroEscrito(string $texto, string $campo, string $ejemplo): string
    {
        try {
            return Numero::escrito($texto);
        } catch (\InvalidArgumentException) {
            throw Errores::datosInvalidos([
                $campo => 'Capture un número con punto decimal, por ejemplo ' . $ejemplo,
            ]);
        }
    }

    /**
     * Una cantidad que entra, con su tope, convertida y lista.
     *
     * ⚠️ **No había tope.** Medido contra la API con un token de vendedor: un
     * renglón de `999999999.999` entraba con **201** y escribía un pedido de
     * $20,999,999,999.98 —y comprometía mil millones de unidades, así que todas
     * las pantallas de disponibilidad quedaban en cero—; uno de `1000000000`
     * daba **500**, porque la columna es `DECIMAL(12,3)`.
     *
     * El 500 es el peor de los dos. La app cuenta un 5xx como `sin_senal`, y
     * `sin_senal` **se reintenta solo**: una operación que no puede salir bien
     * nunca deja la cola dando vueltas, sin avisarle a nadie. Un dato que el
     * servidor no va a aceptar jamás tiene que contestarse con un 422, que es lo
     * único que la app entiende como «esto no se arregla reintentando».
     *
     * El tope lo dice el parámetro `cantidad_maxima_renglon` —100,000, con el
     * camión de una compra adentro— y quien llama sigue decidiendo si acepta el
     * cero y el negativo: eso cambia por campo.
     */
    protected function cantidadEscrita(string $texto, string $campo, int $tope): Cantidad
    {
        $limpio = $this->numeroEscrito($texto, $campo, '12 o 12.5');

        try {
            $cantidad = Cantidad::deCadena($limpio);
        } catch (\InvalidArgumentException) {
            // `Escala` rechaza lo que no cabe en un entero. Que eso salga como
            // 422 y no como 500 es justo lo que evita el reintento infinito.
            throw Errores::datosInvalidos([
                $campo => 'Esa cantidad es demasiado grande. El tope es ' . $tope,
            ]);
        }

        if ($cantidad->comparaCon(Cantidad::deEntero($tope)) > 0) {
            throw Errores::datosInvalidos([
                $campo => 'Esa cantidad es demasiado grande. El tope es ' . $tope,
            ]);
        }

        return $cantidad;
    }

    /**
     * Un importe que entra, convertido y listo.
     *
     * ⚠️ **Los tres campos de dinero contestaban 500.** Medido por la pantalla de
     * precios del catálogo: `100000000` daba «Out of range value for column
     * 'precio_neto'» y un número de veinte cifras daba «El número es demasiado
     * grande» —la queja del dominio, que es correcta y que nadie traducía—. Los
     * dos son 500 ante un dato que la persona puede corregir, y los tres campos
     * —precio, descuento y precio de compra— tenían la misma línea:
     * `Dinero::deCadena($this->numeroEscrito(...))`, con el `try` puesto sólo
     * alrededor del formato.
     *
     * Es el mismo defecto que se arregló anoche en `cantidadEscrita()`, en el
     * método de al lado, con el comentario de por qué el 500 es la peor
     * respuesta escrito ahí mismo. Por eso esto vive aquí y no en cada pantalla:
     * un campo de dinero nuevo lo hereda en lugar de tener que acordarse.
     *
     * El tope es opcional porque no todos los campos lo tienen: un descuento lo
     * acota el porcentaje autorizado contra su propia venta, no un número suelto.
     * Sin tope, esto sigue haciendo lo esencial, que es que lo que no cabe se
     * conteste 422 y no 500.
     */
    protected function dineroEscrito(string $texto, string $campo, ?int $tope = null, string $ejemplo = '25.50'): Dinero
    {
        $limpio = $this->numeroEscrito($texto, $campo, $ejemplo);

        try {
            $importe = Dinero::deCadena($limpio);
        } catch (\InvalidArgumentException) {
            throw Errores::datosInvalidos([
                $campo => $tope === null
                    ? 'Ese importe es demasiado grande'
                    : 'Ese importe es demasiado grande. El tope es $' . number_format($tope, 2),
            ]);
        }

        if ($tope !== null && $importe->comparaCon(Dinero::dePesos($tope)) > 0) {
            throw Errores::datosInvalidos([
                $campo => 'El tope es $' . number_format($tope, 2) . ' por unidad',
            ]);
        }

        return $importe;
    }
}
