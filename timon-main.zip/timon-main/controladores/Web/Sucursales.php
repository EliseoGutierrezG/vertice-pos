<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Errores\Errores;
use Nucleo\Exporta\Xlsx;
use Nucleo\Giro;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Servicios\Organizacion;
use Servicios\HorariosRestaurante;

/**
 * Sucursales del negocio: nombre, clave corta para tickets y dirección.
 */
#[Modulo('organizacion', 'Organización')]
final class Sucursales extends Controlador
{
    public function __construct(
        private Vista $vista,
        private Organizacion $organizacion,
        private Sesion $sesion,
        private HorariosRestaurante $horarios
    ) {
    }

    #[Accion('organizacion_ver')]
    public function lista(Peticion $peticion): Respuesta
    {
        $estatus = $this->filtroEstatus($peticion);

        return Respuesta::html($this->vista->pinta('organizacion/sucursales', [
            'titulo'   => 'Sucursales',
            'sucursales'  => $this->organizacion->sucursales($estatus),
            'estatus'  => $estatus,
            'estados'  => $this->organizacion->opcionesEstado(),
        ]));
    }

    /** Exportar XLS (ficha 37): la misma consulta del listado, sin la columna de acción (D21). */
    #[Accion('organizacion_ver')]
    public function exporta(Peticion $peticion): Respuesta
    {
        return $this->xlsx('Sucursales', [
            ['titulo' => 'Clave'], ['titulo' => 'Sucursal'], ['titulo' => 'Dirección'], ['titulo' => 'Teléfono'],
            ['titulo' => 'Personal activo', 'tipo' => Xlsx::ENTERO], ['titulo' => 'Estatus'],
        ], array_map(static fn (array $b): array => [
            $b['clave'] ?? '', $b['nombre'], implode(', ', array_filter([trim(($b['calle'] ?? '') . ' ' . ($b['numero'] ?? '')), $b['colonia'] ?? null, $b['estado'] ?? null])),
            $b['telefono'] ?? '', (int) $b['personas'], (int) $b['id_estatus'] === 4 ? 'Activa' : 'Dada de baja',
        ], $this->organizacion->sucursales($this->filtroEstatus($peticion))));
    }

    /** Ver: la ficha en el modal; la URL directa llega al listado. */
    #[Accion('organizacion_ver')]
    public function ver(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');

        return $this->fichaEnModal($peticion, '/sucursales', $id, function () use ($id): array {
            $sucursal = $this->organizacion->sucursal($id);
            $horarios = Giro::activo('restaurante') ? $this->horarios->de($id) : [];
            $registro = [
                'sucursal' => $id, 'horario' => $sucursal['horario_publico'] ?? '', 'whatsapp' => $sucursal['whatsapp_publico'] ?? '',
                'latitud' => $sucursal['latitud'], 'longitud' => $sucursal['longitud'],
            ];
            foreach ($horarios as $dia) {
                $registro['abre[' . $dia['dia'] . ']'] = $dia['abre'];
                $registro['cierra[' . $dia['dia'] . ']'] = $dia['cierra'];
            }
            $arranque = Giro::activo('restaurante') ? $this->organizacion->arranque($id) : [];
            return ['titulo' => (string) $sucursal['nombre'], 'registro' => $registro,
                'html' => $this->vista->suelta('organizacion/sucursal', compact('sucursal', 'horarios', 'arranque'))];
        });
    }

    #[Accion('organizacion_admin', unaVez: true)]
    public function crea(Peticion $peticion): Respuesta
    {
        $this->exigeClavePublica($peticion);
        $id = $this->organizacion->guardaSucursal(null, $peticion->datos(), $peticion->ip());

        return $this->hecho($peticion, $this->sesion, '/sucursales?ver=' . $id, 'Sucursal dada de alta.');
    }

    #[Accion('organizacion_admin')]
    public function edita(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        $this->organizacion->sucursal($id);
        $this->exigeClavePublica($peticion);
        $this->organizacion->guardaSucursal($id, $peticion->datos(), $peticion->ip());

        return $this->hecho($peticion, $this->sesion, $this->regreso($peticion, '/sucursales', '/sucursales?ver=' . $id), 'Sucursal guardada.');
    }

    #[Accion('organizacion_admin')]
    public function baja(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        $this->organizacion->cambiaEstatusSucursal($id, false, $peticion->ip());

        return $this->hecho($peticion, $this->sesion, $this->regreso($peticion, '/sucursales', '/sucursales'), 'Sucursal dada de baja.');
    }

    #[Accion('organizacion_admin')]
    public function reactiva(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        $this->organizacion->cambiaEstatusSucursal($id, true, $peticion->ip());

        return $this->hecho($peticion, $this->sesion, $this->regreso($peticion, '/sucursales', '/sucursales'), 'Sucursal reactivada.');
    }

    private function exigeClavePublica(Peticion $peticion): void
    {
        $clave = $peticion->dato('clave');
        if (Giro::activo('restaurante') && (!is_string($clave) || trim($clave) === '')) {
            throw Errores::datosInvalidos(['clave' => 'Capture la clave pública']);
        }
    }
}
