<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Exporta\Xlsx;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Servicios\Notificaciones;

/**
 * Avisos a los teléfonos del personal (C5, 2026-11-08): un mismo aviso a una
 * persona, un puesto, una sucursal o a todos, y su historial.
 */
#[Modulo('avisos', 'Avisos a los teléfonos')]
final class AvisosWeb extends Controlador
{
    public function __construct(
        private Vista $vista,
        private Notificaciones $notificaciones,
        private Sesion $sesion
    ) {
    }

    #[Accion('avisos_ver,notificaciones_envia')]
    public function lista(Peticion $p): Respuesta
    {
        $f = self::filtros($p);
        return Respuesta::html($this->vista->pinta('avisos/lista', [
            'titulo' => 'Avisos', 'desde' => $f['desde'], 'hasta' => $f['hasta'],
            'avisos' => $this->notificaciones->avisos($f['desde'], $f['hasta']),
            'destinos' => $this->notificaciones->opcionesAviso(),
        ]));
    }

    #[Accion('avisos_ver,notificaciones_envia')]
    public function exporta(Peticion $p): Respuesta
    {
        $f = self::filtros($p);
        return $this->xlsx('Avisos', [
            ['titulo' => 'Enviado', 'tipo' => Xlsx::FECHAHORA], ['titulo' => 'Título'], ['titulo' => 'Mensaje'], ['titulo' => 'Destino'],
            ['titulo' => 'Personas', 'tipo' => Xlsx::ENTERO], ['titulo' => 'Teléfonos', 'tipo' => Xlsx::ENTERO],
            ['titulo' => 'Recibidos', 'tipo' => Xlsx::ENTERO], ['titulo' => 'Fallidos', 'tipo' => Xlsx::ENTERO], ['titulo' => 'Envió'],
        ], array_map(static fn (array $a): array => [
            $a['creado_en'], $a['titulo'], $a['cuerpo'], self::destino($a), (int) $a['personas'], (int) $a['telefonos'],
            (int) $a['aceptados'], (int) $a['fallidos'], $a['envio'],
        ], $this->notificaciones->avisos($f['desde'], $f['hasta'])), $f['desde'], $f['hasta']);
    }

    /** Ver: el aviso y cómo le fue en cada teléfono. */
    #[Accion('avisos_ver,notificaciones_envia')]
    public function ver(Peticion $p): Respuesta
    {
        $id = (int) $p->parametro('id', '0');
        return $this->fichaEnModal($p, '/avisos', $id, function () use ($id): array {
            $aviso = $this->notificaciones->aviso($id);
            return [
                'titulo' => (string) $aviso['titulo'],
                'html' => $this->vista->suelta('avisos/ver', ['aviso' => $aviso, 'destino' => self::destino($aviso)]),
            ];
        });
    }

    #[Accion('notificaciones_envia', unaVez: true)]
    public function envia(Peticion $p): Respuesta
    {
        $r = $this->notificaciones->enviaAviso($p->datos(), $p->ip());
        $mensaje = $r['fallidos'] === 0
            ? 'Aviso enviado a ' . $r['aceptados'] . ' ' . ($r['aceptados'] === 1 ? 'teléfono' : 'teléfonos') . '.'
            : 'Aviso enviado a ' . $r['aceptados'] . ' de ' . $r['telefonos'] . ' teléfonos.';
        return $this->hecho($p, $this->sesion, $this->regreso($p, '/avisos', '/avisos'), $mensaje);
    }

    /** «Puesto · Preventa»; «Todos» va solo. @param array<string,mixed> $aviso */
    public static function destino(array $aviso): string
    {
        $tipo = Notificaciones::DESTINOS[(string) $aviso['destino_tipo']] ?? (string) $aviso['destino_tipo'];
        return $aviso['destino_tipo'] === 'todos' ? $tipo : $tipo . ' · ' . $aviso['destino_nombre'];
    }

    /** @return array{desde:string,hasta:string} Del día 1 del mes a hoy (D16). */
    private static function filtros(Peticion $p): array
    {
        return [
            'desde' => trim((string) $p->consulta('desde', date('Y-m-01'))),
            'hasta' => trim((string) $p->consulta('hasta', date('Y-m-d'))),
        ];
    }
}
