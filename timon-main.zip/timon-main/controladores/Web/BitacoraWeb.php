<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Modelos\Bitacora as ModeloBitacora;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Errores\Errores;
use Nucleo\Exporta\Csv;
use Nucleo\Exporta\Xlsx;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Vista;

/**
 * La bitácora: quién, cuándo, qué había antes y qué quedó.
 *
 * Es la pantalla de la escena 11 de la demostración y la respuesta a la
 * pregunta 9.3 del cuestionario. **No tiene ni una acción de escritura**: no se
 * edita, no se borra y no se corrige. Una bitácora con botón de borrar no
 * contesta nada.
 *
 * Lo que se enseña de cada apunte es el **antes y el después**, no una frase
 * como «se cambió el precio». La frase obliga a creerle al sistema; los dos
 * valores se pueden leer.
 */
#[Modulo('bitacora', 'Bitácora')]
final class BitacoraWeb extends Controlador
{
    public function __construct(
        private Vista $vista,
        private ModeloBitacora $bitacora,
        private \Nucleo\AuditoriaLectura $lecturas
    ) {
    }

    #[Accion('bitacora_ver')]
    public function lista(Peticion $peticion): Respuesta
    {
        $filtros = $this->filtros($peticion);

        $tamano = filter_var($peticion->consulta('por_pagina', 25), FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1, 'max_range' => 100]]);
        $tamano = $tamano === false ? 25 : $tamano;
        $pagina = $this->bitacora->apuntes($filtros, $tamano);

        return Respuesta::html($this->vista->pinta('bitacora/lista', [
            'titulo'   => 'Bitácora',
            'apuntes'  => $pagina['apuntes'],
            'hay_mas'  => $pagina['hay_mas'],
            'ultimo'   => $pagina['ultimo'],
            'tamano'   => $tamano,
            'total'    => $this->bitacora->total($filtros),
            'filtros'  => $filtros,
            'modulos'  => $this->bitacora->modulos(),
            'acciones' => $this->bitacora->acciones(),
            'entidades'=> $this->bitacora->entidades(),
            'quienes'  => $this->bitacora->quienes(),
            'nombres'  => $this->bitacora->nombresDe($pagina['apuntes']),
        ]));
    }

    /**
     * Exportar XLS (ficha 43, D18): las columnas de la tabla con los mismos
     * filtros, recorridas por llave como el CSV.
     */
    #[Accion('bitacora_exporta')]
    public function exporta(Peticion $peticion): Respuesta
    {
        require_once dirname(__DIR__, 2) . '/vistas/partes/piezas.php';
        $filtros = $this->filtros($peticion);
        unset($filtros['antes_de']);
        $this->lecturas->anota('exporta_bitacora', 'bitacora', null, array_filter($filtros), $peticion->ip());
        $canales = ['web' => 'Web', 'api' => 'App', 'tarea' => 'Tarea', 'guion' => 'Guion'];
        $filas = (function () use ($filtros, $canales): \Generator {
            foreach ($this->bitacora->recorre($filtros) as $a) {
                yield [
                    (string) $a['momento'], (string) ($a['usuario'] ?? 'el sistema'), $canales[$a['canal'] ?? ''] ?? 'Histórico',
                    \pb_legible((string) $a['accion']), \pb_legible((string) $a['modulo']),
                    $a['entidad'] === null ? '' : \pb_legible((string) $a['entidad']) . ($a['id_entidad'] === null ? '' : ' #' . (int) $a['id_entidad']),
                    (string) ($a['operacion'] ?? ''), (string) ($a['antes'] ?? ''), (string) ($a['despues'] ?? ''),
                ];
            }
        })();
        return $this->xlsx('Bitácora', [
            ['titulo' => 'Cuándo', 'tipo' => Xlsx::FECHAHORA], ['titulo' => 'Quién'], ['titulo' => 'Canal'], ['titulo' => 'Qué hizo'],
            ['titulo' => 'Módulo'], ['titulo' => 'Sobre qué'], ['titulo' => 'Operación'], ['titulo' => 'Antes'], ['titulo' => 'Después'],
        ], $filas, (string) $filtros['desde'], (string) $filtros['hasta']);
    }

    /** Ver (ficha 43): el antes y el después completos del apunte. */
    #[Accion('bitacora_ver')]
    public function ver(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        return $this->fichaEnModal($peticion, '/bitacora', $id, function () use ($id): array {
            require_once dirname(__DIR__, 2) . '/vistas/partes/piezas.php';
            $apunte = $this->bitacora->apunte($id) ?? throw Errores::noEncontrado('El apunte no existe');
            return ['titulo' => \pb_legible((string) $apunte['accion']), 'registro' => [], 'html' => $this->vista->suelta('bitacora/apunte', [
                'apunte' => $apunte,
                'nombres' => $this->bitacora->nombresDe([$apunte]),
            ])];
        });
    }

    #[Accion('bitacora_exporta')]
    public function csv(Peticion $peticion): Respuesta
    {
        $filtros = $this->filtros($peticion);
        unset($filtros['antes_de']);
        $filas = $this->bitacora->recorre($filtros);
        $this->lecturas->anota('exporta_bitacora', 'bitacora', null, array_filter($filtros), $peticion->ip());

        return Respuesta::flujo(static function (callable $emite) use ($filas): void {
            $renglones = (static function () use ($filas): \Generator {
                foreach ($filas as $a) {
                    yield [
                        (string) $a['id'], (string) $a['momento'], (string) ($a['usuario'] ?? 'sistema'),
                        (string) ($a['canal'] ?? ''), (string) $a['modulo'], (string) $a['accion'],
                        (string) ($a['entidad'] ?? ''), (string) ($a['id_entidad'] ?? ''),
                        (string) ($a['operacion'] ?? ''), (string) ($a['ruta'] ?? ''),
                        (string) ($a['accion_ruta'] ?? ''), (string) ($a['id_dispositivo'] ?? ''),
                        (string) ($a['correlacion_hash'] ?? ''), (string) ($a['ip'] ?? ''),
                        (string) ($a['antes'] ?? ''), (string) ($a['despues'] ?? ''),
                    ];
                }
            })();
            Csv::enFlujo('Bitácora general', 'Exportación inmutable', [
                'Número','Momento','Usuario','Canal','Módulo','Acción','Tipo de registro','Número de registro',
                'Operación','Ruta','Acción de ruta','Teléfono','Referencia','IP','Antes','Después',
            ], $renglones, $emite);
        }, 'text/csv; charset=utf-8')->conCabecera(
            'Content-Disposition',
            'attachment; filename="bitacora-' . date('Y-m-d-His') . '.csv"'
        );
    }

    /** @return array<string,mixed> */
    private function filtros(Peticion $peticion): array
    {
        $canal = trim((string) $peticion->consulta('canal', ''));
        if (!in_array($canal, ['', 'web', 'api', 'tarea', 'guion'], true)) {
            $canal = '';
        }

        return [
            'canal'         => $canal,
            'modulo'        => trim((string) $peticion->consulta('modulo', '')),
            'accion'        => trim((string) $peticion->consulta('accion', '')),
            'id_usuario'    => (int) $peticion->consulta('id_usuario', '0'),
            'entidad'       => trim((string) $peticion->consulta('entidad', '')),
            'identificador' => (int) $peticion->consulta('identificador', '0'),
            'operacion'     => trim((string) $peticion->consulta('operacion', '')),
            // Sin consulta abre con el mes en curso (D16); con los campos
            // vacíos a propósito, toda la historia.
            'desde'         => $peticion->consulta('desde') === null ? date('Y-m-01') : $this->fecha($peticion->consulta('desde', '')),
            'hasta'         => $peticion->consulta('hasta') === null ? date('Y-m-d') : $this->fecha($peticion->consulta('hasta', '')),
            'antes_de'      => (int) $peticion->consulta('antes_de', '0'),
        ];
    }

    /**
     * Una fecha mal escrita no es un error: es un filtro que no se aplica.
     *
     * En una pantalla de consulta, contestar 422 porque alguien dejó el campo a
     * medias es castigar a quien está buscando. Aquí lo que no se entiende se
     * ignora, y la pantalla dice con qué filtros salió.
     */
    private function fecha(mixed $valor): string
    {
        $valor = trim((string) $valor);

        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $valor) === 1 ? $valor : '';
    }
}
