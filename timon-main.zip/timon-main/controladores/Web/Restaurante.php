<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Dominio\DatosRestaurante as Datos;
use Dominio\Texto;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;
use Nucleo\Exporta\Csv;
use Nucleo\Exporta\Pdf;
use Nucleo\Exporta\Xlsx;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Servicios\CartaImpresa;
use Servicios\Comandas;
use Servicios\EquiposRestaurante;
use Servicios\FotosCarta;
use Servicios\GastosRestaurante;
use Servicios\HistoriasRestaurante;
use Servicios\ImpresionRestaurante;
use Servicios\InventarioRestaurante;
use Servicios\MenuRestaurante;
use Servicios\PlanoRestaurante;
use Servicios\Promociones;
use Servicios\ReportesRestaurante;
use Servicios\Reservaciones;

#[Modulo('restaurante', 'Restaurante')]
final class Restaurante extends Controlador
{
    public function __construct(
        private BaseDatos $bd,
        private Identidad $identidad,
        private Vista $vista,
        private Sesion $sesion,
        private Comandas $comandas,
        private PlanoRestaurante $plano,
        private MenuRestaurante $menu,
        private EquiposRestaurante $equipos,
        private ImpresionRestaurante $impresion,
        private Reservaciones $reservaciones,
        private InventarioRestaurante $inventario,
        private GastosRestaurante $gastos,
        private ReportesRestaurante $reportes,
        private HistoriasRestaurante $historias,
        private FotosCarta $fotos,
        private Promociones $promociones,
        private CartaImpresa $carta
    ) {
    }

    #[Accion('plano_ver')]
    public function areas(Peticion $p): Respuesta
    {
        return $this->pantalla($p, 'areas', 'Áreas', fn (int $id) => ['areas' => $this->plano->areas($id)]);
    }

    #[Accion('plano_ver')]
    public function verArea(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $id = (int) $p->parametro('id');
        $area = $this->plano->areas($sucursal, $id)[0] ?? throw Errores::noEncontrado('Área no disponible');
        return $this->fichaEnModal($p, '/areas', $id, fn (): array => [
            'titulo' => $area['nombre'], 'registro' => $area,
            'html' => $this->vista->suelta('restaurante/ficha', ['campos' => ['Mesas' => $area['mesas']]]),
        ], ['sucursal' => $sucursal]);
    }

    #[Accion('plano_ver')]
    public function mesas(Peticion $p): Respuesta
    {
        return $this->pantalla($p, 'mesas', 'Mesas', fn (int $id) => $this->comandas->plano($id));
    }

    #[Accion('plano_ver')]
    public function planoSalon(Peticion $p): Respuesta
    {
        return $this->pantalla($p, 'plano', 'Plano del salón', fn (int $id) => $this->comandas->plano($id));
    }

    #[Accion('plano_ver')]
    public function verMesa(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $id = (int) $p->parametro('id');
        $plano = $this->comandas->plano($sucursal, $id);
        $mesa = $plano['mesas'][0] ?? throw Errores::noEncontrado('Mesa no disponible');
        $areas = array_column($plano['areas'], 'nombre', 'id');
        $estados = PlanoRestaurante::ESTADOS + ['ocupada' => 'Ocupada', 'cuenta_pedida' => 'Cuenta pedida', 'reservada' => 'Reservada'];
        return $this->fichaDatos($p, '/mesas', $sucursal, 'Mesa ' . $mesa['numero'], $mesa, [
            'Área' => $areas[$mesa['id_area']], 'Capacidad' => $mesa['capacidad'], 'Forma' => PlanoRestaurante::FORMAS[$mesa['forma']],
            'Posición' => $mesa['x'] . ' %, ' . $mesa['y'] . ' %', 'Estado' => $estados[$mesa['estado']] ?? $mesa['estado'],
        ]);
    }

    #[Accion('plano_admin', unaVez: true)]
    public function guardaArea(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $this->plano->area($id, (int) $p->parametro('id'), $p->datos());
        return $this->hecho($p, $this->sesion, '/areas?sucursal=' . $id, 'Área guardada.');
    }

    #[Accion('plano_admin', unaVez: true)]
    public function guardaMesa(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $this->plano->mesa($id, (int) $p->parametro('id'), $p->datos());
        return $this->hecho($p, $this->sesion, '/mesas?sucursal=' . $id, 'Mesa guardada.');
    }

    #[Accion('plano_admin', unaVez: true)]
    public function bajaPlano(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $tipo = (string) $p->parametro('plano');
        $this->plano->baja($sucursal, (int) $p->parametro('id'), $tipo);
        return $this->hecho($p, $this->sesion, '/' . $tipo . '?sucursal=' . $sucursal, 'Registro dado de baja.');
    }

    #[Accion('plano_admin')]
    public function mueveMesa(Peticion $p): Respuesta
    {
        $this->plano->mueve($this->sucursal($p), (int) $p->parametro('id'), $p->datos());
        return $this->ok();
    }

    #[Accion('menu_admin')]
    public function categorias(Peticion $p): Respuesta
    {
        return $this->pantalla($p, 'categorias', 'Categorías del menú', fn (): array => ['categorias' => $this->menu->categorias()]);
    }

    #[Accion('menu_admin')]
    public function verCategoria(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $id = (int) $p->parametro('id');
        $fila = $this->menu->categorias($id)[0] ?? throw Errores::noEncontrado('Categoría no disponible');
        return $this->fichaDatos($p, '/categorias-menu', $sucursal, $fila['nombre'], $fila,
            ['Orden' => $fila['orden'], 'Leyenda en la carta' => $fila['descripcion'] ?: 'Sin leyenda']);
    }

    #[Accion('menu_admin', unaVez: true)]
    public function bajaCategoria(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $this->menu->bajaCategoria((int) $p->parametro('id'));
        return $this->hecho($p, $this->sesion, '/categorias-menu?sucursal=' . $sucursal, 'Categoría dada de baja.');
    }

    #[Accion('menu_admin,menu_sucursal')]
    public function platillos(Peticion $p): Respuesta
    {
        return $this->pantalla($p, 'platillos', 'Platillos', fn (int $id) => $this->menu->administracion($id));
    }

    #[Accion('menu_admin,menu_sucursal')]
    public function verPlatillo(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $id = (int) $p->parametro('id');
        $platillo = $this->menu->detallePlatillo($sucursal, $id);
        return $this->fichaEnModal($p, '/platillos', $id, fn (): array => [
            'titulo' => $platillo['nombre'],
            'registro' => $platillo,
            'html' => $this->vista->suelta('restaurante/ficha-platillo', ['platillo' => $platillo, 'sucursal' => $sucursal]),
        ], ['sucursal' => $sucursal]);
    }

    #[Accion('menu_admin', unaVez: true)]
    public function guardaCatalogo(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $id = (int) $p->parametro('id');
        $destino = match ($p->parametro('catalogo')) {
            'categorias-menu' => 'categorias-menu',
            'platillos', 'modificadores' => 'platillos',
            default => throw Errores::noEncontrado(),
        };
        match ($p->parametro('catalogo')) {
            'categorias-menu' => $this->menu->categoria($id, $p->datos()),
            'platillos' => $this->guardaPlatillo($p, $id),
            'modificadores' => $this->menu->modificador($id, $p->datos()),
        };
        return $this->hecho($p, $this->sesion, '/' . $destino . '?sucursal=' . $sucursal, 'Catálogo actualizado.');
    }

    private function guardaPlatillo(Peticion $p, int $id): void
    {
        $datos = $p->datos();
        $foto = $this->fotos->sube($p->archivo('imagen'));
        if ($foto !== null) {
            $datos['foto'] = $foto;
        }
        try {
            $this->menu->platillo($id, $datos);
        } catch (\Throwable $error) {
            if ($foto !== null) {
                $this->fotos->retiraRecienSubida($foto);
            }
            throw $error;
        }
    }

    #[Accion('promocion_admin')]
    public function promociones(Peticion $p): Respuesta
    {
        $estado = Datos::opcion($p->consulta('estado', ''), 'estado', ['', ...array_keys(Promociones::ESTADOS)]);
        $platillo = (int) $p->consulta('platillo', 0);
        return $this->pantalla($p, 'promociones', 'Promociones', fn (int $id): array => [
            'promociones' => $this->promociones->listado(['sucursal' => $id, 'estado' => $estado, 'platillo' => $platillo]),
            'platillos' => $this->menu->administracion($id)['platillos'],
        ], ['estadoFiltro' => $estado, 'platilloFiltro' => $platillo]);
    }

    #[Accion('promocion_admin')]
    public function verPromocion(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $id = (int) $p->parametro('id');
        $promo = $this->promociones->ficha($id);
        return $this->fichaEnModal($p, '/promociones', $id, fn (): array => [
            'titulo' => $promo['nombre'],
            'registro' => [
                'id' => $promo['id'], 'nombre' => $promo['nombre'], 'tipo' => $promo['tipo'],
                'porcentaje' => $promo['tipo'] === 'porcentaje' ? (string) (int) $promo['valor'] : '',
                'precio_especial' => $promo['tipo'] === 'precio' ? $promo['valor'] : '',
                'lleva' => $promo['lleva'] ?? '', 'paga' => $promo['paga'] ?? '',
                'desde' => $promo['desde'], 'hasta' => $promo['hasta'] ?? '',
                'hora_inicio' => $promo['hora_inicio'] === null ? '' : substr((string) $promo['hora_inicio'], 0, 5),
                'hora_fin' => $promo['hora_fin'] === null ? '' : substr((string) $promo['hora_fin'], 0, 5),
                'dias[]' => $promo['dias_lista'], 'sucursales[]' => $promo['sucursales'],
                'platillos[]' => array_map('intval', array_column($promo['platillos'], 'id')),
            ],
            'html' => $this->vista->suelta('restaurante/ficha-promocion', ['promo' => $promo]),
        ], ['sucursal' => $sucursal]);
    }

    #[Accion('promocion_admin', unaVez: true)]
    public function guardaPromocion(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $resultado = $this->promociones->guarda((int) $p->parametro('id'), $p->datos());
        $aviso = trim('Promoción guardada. ' . implode(' ', $resultado['avisos']));
        return $this->hecho($p, $this->sesion, '/promociones?sucursal=' . $sucursal, $aviso);
    }

    #[Accion('promocion_admin', unaVez: true)]
    public function estadoPromocion(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $accion = (string) $p->parametro('accion');
        $this->promociones->cambiaEstado((int) $p->parametro('id'), $accion);
        $aviso = match ($accion) { 'pausar' => 'Promoción pausada.', 'reanudar' => 'Promoción reanudada.', default => 'Promoción dada de baja.' };
        return $this->hecho($p, $this->sesion, '/promociones?sucursal=' . $sucursal, $aviso);
    }

    #[Accion('menu_admin,menu_sucursal')]
    public function carta(Peticion $p): Respuesta
    {
        return $this->pantalla($p, 'carta', 'Carta', fn (int $id): array => [
            'textos' => $this->carta->textos(),
            'huella' => $this->carta->huella($id),
            'puedeEditar' => $this->identidad->puede('menu_admin'),
        ]);
    }

    /** La hoja tal como se imprime. La pantalla Carta la muestra en un marco. */
    #[Accion('menu_admin,menu_sucursal')]
    public function hojaCarta(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $carta = $this->carta->arma($sucursal, $p->consulta('promociones', '1') !== '0');
        return Respuesta::html($this->vista->suelta('restaurante/carta-hoja', [
            'carta' => $carta,
            'compacta' => $p->consulta('tamano', '') === 'compacta',
            'imprimir' => $p->consulta('imprimir', '') === '1',
        ]))->conCabecera('Cache-Control', 'no-store')->conMarcoPropio();
    }

    #[Accion('menu_admin,menu_sucursal')]
    public function huellaCarta(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        return $this->ok(['huella' => $this->carta->huella($sucursal, $p->consulta('promociones', '1') !== '0')]);
    }

    #[Accion('menu_admin', unaVez: true)]
    public function guardaTextosCarta(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $this->carta->guardaTextos($p->datos());
        return $this->hecho($p, $this->sesion, '/carta?sucursal=' . $sucursal, 'Textos de la carta guardados.');
    }

    #[Accion('menu_sucursal', unaVez: true)]
    public function precios(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $origen = $p->dato('origen', '');
        $precios = $p->dato('precios', []);
        if (!is_array($precios)) {
            throw Errores::datosInvalidos(['precios' => 'Revise los precios']);
        }
        $this->menu->precios($sucursal, $origen === '' ? null : Datos::entero($origen, 'origen', 1, 65535), $precios);
        return $this->hecho($p, $this->sesion, '/platillos?sucursal=' . $sucursal, 'Precios guardados.');
    }

    #[Accion('menu_sucursal', unaVez: true)]
    public function disponibilidad(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $this->menu->disponibilidad($sucursal, (int) $p->parametro('id'), $p->datos());
        return $this->hecho($p, $this->sesion, '/platillos?sucursal=' . $sucursal, 'Disponibilidad actualizada.');
    }

    #[Accion('equipo_admin')]
    public function equipos(Peticion $p): Respuesta
    {
        return $this->pantalla($p, 'equipos', 'Equipos de comanda', fn (int $id) => [
            'equipos' => $this->equipos->lista($id), 'pendientes' => $this->equipos->pendientes(),
        ]);
    }

    #[Accion('equipo_admin', unaVez: true)]
    public function autorizaEquipo(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $this->equipos->autoriza($id, Datos::texto($p->dato('codigo'), 'codigo', 10), (string) $p->dato('tipo'));
        return $this->hecho($p, $this->sesion, '/equipos-comanda?sucursal=' . $id, 'Equipo autorizado.');
    }

    #[Accion('equipo_admin', unaVez: true)]
    public function retiraEquipo(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $this->equipos->retira($id, (int) $p->parametro('id'));
        return $this->hecho($p, $this->sesion, '/equipos-comanda?sucursal=' . $id, 'Equipo retirado.');
    }

    #[Accion('equipo_admin', unaVez: true)]
    public function autorizaPendiente(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $this->equipos->autorizaPendiente($id, (int) $p->parametro('id'), (string) $p->dato('tipo'));
        return $this->hecho($p, $this->sesion, '/equipos-comanda?sucursal=' . $id, 'Equipo autorizado.');
    }

    #[Accion('equipo_admin', unaVez: true)]
    public function actualizaEquipo(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $this->equipos->actualiza($id, (int) $p->parametro('id'), $p->datos());
        return $this->hecho($p, $this->sesion, '/equipos-comanda?sucursal=' . $id, 'Equipo actualizado.');
    }

    #[Accion(publica: true, unaVez: true)]
    public function cambiaPin(Peticion $p): Respuesta
    {
        $this->equipos->cambiaPin(
            Datos::texto($p->dato('pin'), 'pin', 6),
            Datos::texto($p->dato('clave'), 'clave', 250)
        );
        return $this->hecho($p, $this->sesion, '/perfil', 'PIN de comanda actualizado.');
    }

    #[Accion('plano_admin')]
    public function impresoras(Peticion $p): Respuesta
    {
        return $this->pantalla($p, 'impresoras', 'Impresoras', fn (int $id) => ['impresoras' => $this->impresion->lista($id)]);
    }

    #[Accion('plano_admin')]
    public function verImpresora(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $id = (int) $p->parametro('id');
        $fila = $this->impresion->lista($sucursal, $id)[0] ?? throw Errores::noEncontrado('Impresora no disponible');
        $destinos = MenuRestaurante::AREAS + ['caja' => 'Caja'];
        return $this->fichaDatos($p, '/impresoras', $sucursal, $fila['nombre'], $fila, [
            'Área' => $destinos[$fila['destino']], 'Red' => $fila['ip'] . ':' . $fila['puerto'],
            'Rollo' => $fila['ancho'] . ' mm', 'Estado' => (int) $fila['activa'] === 1 ? 'Activa' : 'Inactiva',
        ]);
    }

    #[Accion('plano_admin', unaVez: true)]
    public function guardaImpresora(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $this->impresion->registra($id, (int) $p->parametro('id'), $p->datos());
        return $this->hecho($p, $this->sesion, '/impresoras?sucursal=' . $id, 'Impresora guardada.');
    }

    #[Accion('reservaciones_opera')]
    public function reservaciones(Peticion $p): Respuesta
    {
        $desde = (string) $p->consulta('desde', '');
        $desde = $desde === '' ? date('Y-m-d', strtotime('yesterday')) : $this->fechaEscrita($desde, 'desde');
        $hasta = (string) $p->consulta('hasta', '');
        if ($hasta !== '') {
            $hasta = $this->fechaEscrita($hasta, 'hasta');
        }
        if ($hasta !== '' && $hasta < $desde) {
            throw Errores::datosInvalidos(['hasta' => 'La fecha final precede a la inicial']);
        }
        $estado = Datos::opcion($p->consulta('estado', ''), 'estado', ['', ...array_keys(Reservaciones::ESTADOS)]);
        return $this->pantalla($p, 'reservaciones', 'Reservaciones', fn (int $id) => [
            'reservaciones' => $this->reservaciones->agenda($id, $desde, $hasta, $estado),
            'mesas' => $this->comandas->plano($id)['mesas'],
        ], ['desde' => $desde, 'hasta' => $hasta, 'estadoFiltro' => $estado]);
    }

    #[Accion('reservaciones_opera')]
    public function verReserva(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $fila = $this->reservaciones->detalle($sucursal, (int) $p->parametro('id'));
        // El modal de confirmar solo precarga la mesa. Enviar el estado actual
        // sobrescribía su destino fijo «confirmada» con «solicitada».
        $registro = ['id' => $fila['id'], 'id_mesa' => $fila['id_mesa']];
        return $this->fichaDatos($p, '/reservaciones', $sucursal, $fila['cliente'], $registro, [
            'Teléfono' => $fila['telefono'], 'Personas' => $fila['personas'], 'Llegada' => $fila['desde'],
            'Fin' => $fila['hasta'], 'Mesa' => $fila['mesa'] ?? 'Sin asignar', 'Estado' => Reservaciones::ESTADOS[$fila['estado']],
            'Folio' => $fila['folio'], 'Nota' => $fila['nota'],
        ]);
    }

    #[Accion('reservaciones_opera', unaVez: true)]
    public function reservaManual(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $folio = $this->reservaciones->manual($sucursal, $p->datos());
        return $this->hecho($p, $this->sesion, '/reservaciones?sucursal=' . $sucursal, 'Reservación ' . $folio . ' registrada.');
    }

    #[Accion('reservaciones_opera', unaVez: true)]
    public function reservaAccion(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $this->reservaciones->cambia($id, (int) $p->parametro('id'), $p->datos());
        return $this->hecho($p, $this->sesion, $this->regreso($p, '/reservaciones', '/reservaciones?sucursal=' . $id), 'Reservación actualizada.');
    }

    #[Accion('organizacion_admin', unaVez: true)]
    public function datosPublicos(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $this->reservaciones->datosPublicos($id, $p->datos());
        return $this->hecho($p, $this->sesion, $this->regreso($p, '/sucursales', '/sucursales?ver=' . $id), 'Datos públicos guardados.');
    }

    #[Accion('inventario_opera')]
    public function inventario(Peticion $p): Respuesta
    {
        $tipo = (string) $p->parametro('tipo');
        $titulos = ['insumos' => 'Insumos', 'lotes' => 'Lotes de insumo', 'compras' => 'Compras',
            'proveedores' => 'Proveedores', 'recetas' => 'Recetas', 'movimientos' => 'Kardex de insumos'];
        return $this->pantalla($p, 'inventario', $titulos[$tipo],
            function (int $id) use ($p, $tipo): array {
                if (in_array($tipo, ['insumos', 'proveedores'], true)) {
                    $buscar = trim((string) $p->consulta('buscar', ''));
                    $datos = $this->inventario->datos($id, $tipo);
                    $datos[$tipo] = $this->catalogoFiltrado($datos[$tipo], $buscar);
                    return $datos + ['buscar' => $buscar];
                }
                if ($tipo === 'recetas') {
                    // Filtrar por platillo deja ver la receta completa de uno.
                    $platillo = (int) $p->consulta('platillo', 0);
                    $datos = $this->inventario->datos($id, $tipo);
                    if ($platillo > 0) {
                        $datos['recetas'] = array_values(array_filter($datos['recetas'],
                            static fn (array $r): bool => (int) $r['id_platillo'] === $platillo));
                    }
                    return $datos + ['platilloFiltro' => $platillo];
                }
                if (!isset(HistoriasRestaurante::TITULOS[$tipo])) {
                    return $this->inventario->datos($id, $tipo);
                }
                [$filtros, $pagina] = $this->historial($p, $id, $tipo);
                return $this->inventario->datos($id, $tipo, $pagina['filas']) + compact('filtros', 'pagina');
            }, ['tipo' => $tipo]);
    }

    #[Accion('inventario_opera', unaVez: true)]
    public function inventarioAccion(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $accion = (string) $p->parametro('accion');
        $this->inventario->guarda($id, $accion, $p->datos());
        $ruta = match ($accion) {
            'insumo' => 'insumos', 'compra', 'recibir', 'cancelar-compra' => 'compras', 'proveedor' => 'proveedores',
            'receta' => 'recetas', 'merma', 'conteo', 'existencia-inicial' => 'lotes',
        };
        $ruta = '/inventario/' . $ruta;
        return $this->hecho($p, $this->sesion, $this->regreso($p, $ruta, $ruta . '?sucursal=' . $id), 'Inventario actualizado.');
    }

    #[Accion('inventario_opera')]
    public function verCompra(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $id = (int) $p->parametro('id');
        $compra = $this->inventario->detalleCompra($sucursal, $id);
        return $this->fichaEnModal($p, '/inventario/compras', $id, fn (): array => [
            'titulo' => $compra['referencia'], 'html' => $this->vista->suelta('restaurante/compra', ['compra' => $compra]),
        ], ['sucursal' => $sucursal]);
    }

    #[Accion('inventario_opera')]
    public function verCatalogoInventario(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $tipo = (string) $p->parametro('tipo');
        $fila = $this->inventario->detalleCatalogo($sucursal, (int) $p->parametro('id'), $tipo);
        $campos = $tipo === 'insumos' ? ['Unidad' => $fila['unidad']] : ['Contacto' => $fila['contacto']];
        return $this->fichaDatos($p, '/inventario/' . $tipo, $sucursal, $fila['nombre'], $fila, $campos);
    }

    #[Accion('inventario_opera', unaVez: true)]
    public function cambiaCatalogoInventario(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $tipo = (string) $p->parametro('tipo');
        $datos = str_ends_with($p->ruta(), '/baja') ? null : $p->datos();
        $this->inventario->cambiaCatalogo($sucursal, (int) $p->parametro('id'), $tipo, $datos);
        return $this->hecho($p, $this->sesion, '/inventario/' . $tipo . '?sucursal=' . $sucursal, 'Inventario actualizado.');
    }

    #[Accion('inventario_opera')]
    public function recibirCompra(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $id = (int) $p->parametro('id');
        $compra = $this->inventario->detalleCompra($sucursal, $id);
        if (!in_array($compra['estado'], ['ordenada', 'parcial'], true)) {
            throw Errores::conflicto('La orden no está pendiente');
        }
        return $this->fichaEnModal($p, '/inventario/compras', $id, fn (): array => [
            'titulo' => 'Recibir ' . $compra['referencia'],
            'html' => $this->vista->suelta('restaurante/recibe-compra', ['compra' => $compra, 'sucursal' => $sucursal]),
        ], ['sucursal' => $sucursal]);
    }

    #[Accion('gastos_opera')]
    public function gastos(Peticion $p): Respuesta
    {
        return $this->pantalla($p, 'gastos', 'Gastos', function (int $id) use ($p): array {
            [$filtros, $pagina] = $this->historial($p, $id, 'gastos');
            return ['gastos' => $pagina['filas'], 'proveedores' => $this->gastos->proveedores($id)] + compact('filtros', 'pagina');
        });
    }

    #[Accion('faltantes_atiende')]
    public function faltantes(Peticion $p): Respuesta
    {
        $estado = Datos::opcion($p->consulta('estado', 'pendientes'), 'estado', ['pendientes', 'atendidos', 'todos']);
        return $this->pantalla($p, 'faltantes', 'Faltantes',
            fn (int $id): array => ['faltantes' => $this->inventario->faltantes($id, $estado)], ['estado' => $estado]);
    }

    #[Accion('faltantes_atiende', unaVez: true)]
    public function atiendeFaltante(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $this->inventario->atiendeFaltante($sucursal, (int) $p->parametro('id'), $p->dato('nota', ''));
        return $this->hecho($p, $this->sesion, '/inventario/faltantes?sucursal=' . $sucursal, 'Faltante atendido.');
    }

    #[Accion('inventario_opera')]
    public function inventarioExporta(Peticion $p): Respuesta
    {
        return $this->exportaHistorial($p, (string) $p->parametro('tipo'));
    }

    /** Insumos y Proveedores en XLS, con el mismo «Buscar» que el listado. */
    #[Accion('inventario_opera')]
    public function catalogoExporta(Peticion $p): Respuesta
    {
        $tipo = (string) $p->parametro('tipo');
        $sucursal = $this->sucursal($p);
        $filas = $this->catalogoFiltrado($this->inventario->datos($sucursal, $tipo)[$tipo], trim((string) $p->consulta('buscar', '')));
        if ($tipo === 'insumos') {
            return $this->xlsx('Insumos', [['titulo' => 'Insumo'], ['titulo' => 'Unidad'],
                ['titulo' => 'Existencia', 'tipo' => Xlsx::DECIMAL], ['titulo' => 'Vencido', 'tipo' => Xlsx::DECIMAL]],
                array_map(fn (array $f): array => [$f['nombre'], $f['unidad'], $f['saldo'], $f['vencido']], $filas));
        }
        return $this->xlsx('Proveedores', [['titulo' => 'Proveedor'], ['titulo' => 'Contacto']],
            array_map(fn (array $f): array => [$f['nombre'], (string) ($f['contacto'] ?? '')], $filas));
    }

    /** «camaron» encuentra «Camarón»: se compara sin acentos ni mayúsculas. */
    private function catalogoFiltrado(array $filas, string $buscar): array
    {
        if ($buscar === '') {
            return $filas;
        }
        $busca = Texto::claveComparacion($buscar);
        return array_values(array_filter($filas, static fn (array $f): bool =>
            str_contains(Texto::claveComparacion((string) ($f['nombre'] ?? ''), (string) ($f['contacto'] ?? ''), (string) ($f['unidad'] ?? '')), $busca)));
    }

    #[Accion('gastos_opera')]
    public function gastosExporta(Peticion $p): Respuesta
    {
        return $this->exportaHistorial($p, 'gastos');
    }

    private function exportaHistorial(Peticion $p, string $tipo): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $filtros = $this->filtrosHistorial($p, $tipo);
        return $this->xlsx(HistoriasRestaurante::TITULOS[$tipo], $this->historias->columnas($tipo),
            $this->historias->exporta($sucursal, $tipo, $filtros), ...array_values(array_filter([$filtros['desde'], $filtros['hasta']])));
    }

    private function historial(Peticion $p, int $sucursal, string $tipo): array
    {
        $filtros = $this->filtrosHistorial($p, $tipo);
        $numero = Datos::entero($p->consulta('pagina', 1), 'pagina');
        $tamano = Datos::entero($p->consulta('por_pagina', 25), 'por_pagina', 1, 100);
        return [$filtros + ['sucursal' => $sucursal], $this->historias->pagina($sucursal, $tipo, $filtros, $numero, $tamano)];
    }

    private function filtrosHistorial(Peticion $p, string $tipo): array
    {
        $desde = $p->consulta('desde', '');
        $hasta = $p->consulta('hasta', '');
        $desde = $desde === '' ? '' : $this->fechaEscrita((string) $desde, 'desde');
        $hasta = $hasta === '' ? '' : $this->fechaEscrita((string) $hasta, 'hasta');
        if ($desde !== '' && $hasta !== '' && $hasta < $desde) {
            throw Errores::datosInvalidos(['hasta' => 'La fecha final precede a la inicial']);
        }
        $opciones = match ($tipo) {
            'compras' => HistoriasRestaurante::ESTADOS_COMPRA, 'movimientos' => HistoriasRestaurante::MOVIMIENTOS,
            'gastos' => HistoriasRestaurante::ESTADOS_GASTO, default => [],
        };
        $estado = Datos::opcion($p->consulta('estado', ''), 'estado', ['', ...array_keys($opciones)]);
        $catalogo = Datos::entero($p->consulta('catalogo', 0), 'catalogo', 0);
        $buscar = Datos::texto($p->consulta('buscar', ''), 'buscar', 120, false);
        return compact('desde', 'hasta', 'estado', 'catalogo', 'buscar');
    }

    #[Accion('gastos_opera', unaVez: true)]
    public function gastoRegistra(Peticion $p): Respuesta
    {
        $id = $this->sucursal($p);
        $this->gastos->registra($id, $p->datos());
        return $this->hecho($p, $this->sesion, '/gastos?sucursal=' . $id, 'Gasto registrado.');
    }

    #[Accion('gastos_opera')]
    public function verGasto(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $gasto = $this->gastos->detalle($sucursal, (int) $p->parametro('id'));
        return $this->fichaDatos($p, '/gastos', $sucursal, $gasto['concepto'], $gasto, [
            'Importe' => $gasto['importe'], 'Proveedor' => $gasto['proveedor'], 'Comprobante' => $gasto['comprobante'],
            'Pagado en caja' => $gasto['caja'] ? 'Sí' : 'No', 'Fecha' => $gasto['creado_en'],
            'Cancelado' => $gasto['cancelado_en'], 'Motivo de cancelación' => $gasto['motivo_cancelacion'],
        ]);
    }

    #[Accion('gastos_opera', unaVez: true)]
    public function corrigeGasto(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $this->gastos->corrige($sucursal, (int) $p->parametro('id'), Datos::entero($p->dato('version'), 'version'), $p->datos());
        return $this->hecho($p, $this->sesion, $this->regreso($p, '/gastos', '/gastos?sucursal=' . $sucursal), 'Gasto actualizado.');
    }

    #[Accion('gastos_opera', unaVez: true)]
    public function cancelaGasto(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $this->gastos->cancela($sucursal, (int) $p->parametro('id'), Datos::entero($p->dato('version'), 'version'), $p->dato('motivo'));
        return $this->hecho($p, $this->sesion, $this->regreso($p, '/gastos', '/gastos?sucursal=' . $sucursal), 'Gasto cancelado.');
    }

    #[Accion('reportes_restaurante')]
    public function reportes(Peticion $p): Respuesta
    {
        return $this->pantalla($p, 'reportes', 'Reportes', function (int $id) use ($p): array {
            [$tipo, $desde, $hasta] = $this->periodo($p);
            return ['tipo' => $tipo, 'desde' => $desde, 'hasta' => $hasta,
                'tabla' => $this->reportes->tabla($id, $tipo, $desde, $hasta)];
        });
    }

    #[Accion('reportes_restaurante')]
    public function reporteVivo(Peticion $p): Respuesta
    {
        return $this->ok($this->reportes->vivos($this->sucursal($p)));
    }

    #[Accion('reportes_restaurante')]
    public function reporteExporta(Peticion $p): Respuesta
    {
        [$tipo, $desde, $hasta] = $this->periodo($p);
        $tabla = $this->reportes->tabla($this->sucursal($p), $tipo, $desde, $hasta);
        $formato = (string) $p->parametro('formato');
        if ($formato === 'xlsx') {
            $columnas = [];
            foreach ($tabla->encabezados as $n => $nombre) {
                $columnas[] = ['titulo' => $nombre, 'tipo' => $tabla->esNumerica($n) ? 'numero' : 'texto'];
            }
            return $this->xlsx($tabla->titulo, $columnas, $tabla->filas, $desde, $hasta);
        }
        $respuesta = $formato === 'pdf'
            ? Respuesta::archivo(Pdf::de($tabla, true), 'application/pdf')
            : Respuesta::archivo(Csv::de($tabla), 'text/csv; charset=utf-8');
        return $respuesta->conCabecera('Content-Disposition', 'attachment; filename="' . $tabla->archivo($formato) . '"');
    }

    private function periodo(Peticion $p): array
    {
        $desde = $this->fechaEscrita((string) $p->consulta('desde', date('Y-m-01')), 'desde');
        $hasta = $this->fechaEscrita((string) $p->consulta('hasta', date('Y-m-d')), 'hasta');
        if ($hasta < $desde || (new \DateTimeImmutable($desde))->diff(new \DateTimeImmutable($hasta))->days > 366) {
            throw Errores::datosInvalidos(['hasta' => 'Seleccione un periodo de hasta un año']);
        }
        $tipo = Datos::opcion($p->consulta('tipo', 'dia'), 'tipo', array_keys(ReportesRestaurante::TIPOS));
        return [$tipo, $desde, $hasta];
    }

    private function fichaDatos(Peticion $p, string $ruta, int $sucursal, string $titulo, array $registro, array $campos): Respuesta
    {
        return $this->fichaEnModal($p, $ruta, (int) $registro['id'], fn (): array => [
            'titulo' => $titulo, 'registro' => $registro, 'html' => $this->vista->suelta('restaurante/ficha', ['campos' => $campos]),
        ], ['sucursal' => $sucursal]);
    }

    private function pantalla(Peticion $p, string $archivo, string $titulo, callable $datos, array $comunes = []): Respuesta
    {
        $sucursales = array_filter(
            $this->bd->filas('SELECT id, nombre, clave FROM sucursal WHERE id_estatus = 4 ORDER BY nombre'),
            fn (array $s) => $this->identidad->alcanzaSucursal((int) $s['id'])
        );
        $opciones = array_column($sucursales, 'nombre', 'id');
        $id = (int) $p->consulta('sucursal', array_key_first($opciones));
        if ($id > 0 && !isset($opciones[$id])) {
            throw Errores::noEncontrado('Sucursal no disponible');
        }
        return Respuesta::html($this->vista->pinta('restaurante/' . $archivo, [
            'titulo' => $titulo, 'sucursal' => $id, 'opciones' => $opciones,
            'claveSucursal' => array_column($sucursales, 'clave', 'id')[$id] ?? '',
        ] + $comunes + ($id > 0 ? $datos($id) : [])));
    }

    private function sucursal(Peticion $p): int
    {
        $id = Datos::entero($p->dato('sucursal', $p->consulta('sucursal')), 'sucursal', 1, 65535);
        $this->identidad->exigeSucursal($id);
        return $id;
    }
}
