<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Bitacora;
use Nucleo\Csrf;
use Nucleo\Identidad;
use Nucleo\Middleware\ExigeSesion;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\VidaSesion;
use Nucleo\Vista;

/**
 * El aviso antes de que venza la sesión (homologación §S, D19).
 *
 *  - `GET /sesion/estado` dice cuánto queda y cuál es la marca vigente. **No
 *    cuenta como uso** (`ExigeSesion::SIN_USO`): si contara, la pestaña que
 *    pregunta mantendría viva la sesión sola. Sin sesión responde el 401 de
 *    `ExigeSesion`, y eso es lo que la pantalla necesita saber.
 *  - `POST /sesion/renovar` es «Seguir conectado»: lo pulsa una persona, con su
 *    marca, y abre otra jornada. El identificador se renueva al hacerlo.
 *  - `GET /sesion/lista` es la pestaña que se abrió para volver a entrar: dice
 *    que ya se puede cerrar y regresar a guardar.
 */
#[Modulo('sesion', 'Sesión')]
final class SesionWeb extends Controlador
{
    public function __construct(
        private Sesion $sesion,
        private Csrf $csrf,
        private VidaSesion $vida,
        private Identidad $identidad,
        private Bitacora $bitacora,
        private Vista $vista
    ) {
    }

    #[Accion(publica: true, conClaveTemporal: true)]
    public function estado(Peticion $peticion): Respuesta
    {
        return Respuesta::json([
            'restante' => $this->vida->restante(),
            'marca'    => $this->csrf->marca(),
        ])->conCabecera('Cache-Control', 'no-store');
    }

    #[Accion(publica: true, conClaveTemporal: true)]
    public function renueva(Peticion $peticion): Respuesta
    {
        $this->sesion->renueva();
        $this->sesion->pon(ExigeSesion::ENTRADA, time());
        $this->sesion->pon(ExigeSesion::SELLO, time());

        $this->bitacora->registra(
            'entrada',
            'sigue_conectado',
            'usuario',
            $this->identidad->id(),
            idUsuario: $this->identidad->id(),
            ip: $peticion->ip()
        );

        return Respuesta::json([
            'restante' => $this->vida->restante(),
            'marca'    => $this->csrf->marca(),
        ])->conCabecera('Cache-Control', 'no-store');
    }

    #[Accion(publica: true, conClaveTemporal: true)]
    public function lista(Peticion $peticion): Respuesta
    {
        return Respuesta::html($this->vista->pinta('sesion/lista', ['titulo' => 'Sesión iniciada'], 'plantilla/limpia'))
            ->conCabecera('Cache-Control', 'no-store');
    }
}
