<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Errores\Errores;
use Nucleo\Exporta\Xlsx;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Servicios\Personal;
use Servicios\Notificaciones;

/**
 * Los equipos que piden entrar a la app.
 *
 * El usuario y la contraseña no bastan para operar con la app: el equipo se
 * autoriza desde aquí. Es el segundo factor del alcance, y el que evita que
 * una contraseña prestada sirva desde cualquier lado. La fase 2 convierte
 * estos registros en equipos fijos por sucursal.
 */
#[Modulo('personal', 'Personal')]
final class DispositivosWeb extends Controlador
{
    public function __construct(
        private Vista $vista,
        private Personal $personal,
        private Sesion $sesion,
        private Notificaciones $notificaciones,
        private Identidad $identidad
    ) {
    }

    #[Accion('personal_ver')]
    public function lista(Peticion $peticion): Respuesta
    {
        $filtro = $this->filtro($peticion);

        return Respuesta::html($this->vista->pinta('dispositivos/lista', [
            'titulo'    => 'Equipos del personal',
            'telefonos' => $this->personal->dispositivos($filtro),
            'filtro'    => $filtro,
        ]));
    }

    /** Exportar XLS (ficha 40): las columnas del listado con el mismo filtro. */
    #[Accion('personal_ver')]
    public function exporta(Peticion $peticion): Respuesta
    {
        return $this->xlsx('Equipos', [
            ['titulo' => 'Persona'], ['titulo' => 'Usuario'], ['titulo' => 'Puesto'], ['titulo' => 'Sucursal'], ['titulo' => 'Equipo'],
            ['titulo' => 'Último acceso', 'tipo' => Xlsx::FECHAHORA], ['titulo' => 'Estatus'], ['titulo' => 'Avisos'],
        ], array_map(static fn (array $t): array => [
            $t['persona'], $t['usuario'], $t['puesto'], $t['sucursal'] ?? 'Todas', $t['nombre'] ?? 'Sin nombre',
            $t['ultimo_acceso'] ?? '', (int) $t['autorizado'] === 1 ? 'Autorizado' : 'En espera', (int) $t['push_listo'] === 1 ? 'Listos' : 'Sin avisos',
        ], $this->personal->dispositivos($this->filtro($peticion))));
    }

    /** Ver (ficha 40): el teléfono en un modal, dentro del alcance de sucursal. */
    #[Accion('personal_ver')]
    public function ver(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        return $this->fichaEnModal($peticion, '/dispositivos', $id, function () use ($id): array {
            require_once dirname(__DIR__, 2) . '/vistas/partes/piezas.php';
            foreach ($this->personal->dispositivos('todos') as $t) {
                if ((int) $t['id'] === $id) {
                    return ['titulo' => (string) $t['persona'], 'registro' => [], 'html' => $this->vista->suelta('dispositivos/telefono', ['telefono' => $t])];
                }
            }
            throw Errores::noEncontrado('El teléfono no existe');
        });
    }

    private function filtro(Peticion $peticion): string
    {
        $filtro = (string) $peticion->consulta('filtro', 'pendientes');
        return in_array($filtro, ['pendientes', 'autorizados', 'todos'], true) ? $filtro : 'pendientes';
    }

    #[Accion('personal_admin')]
    public function autoriza(Peticion $peticion): Respuesta
    {
        $this->personal->autorizaDispositivo((int) $peticion->parametro('id', '0'), $peticion->ip());

        return $this->hecho($peticion, $this->sesion, $this->regreso($peticion, ['/dispositivos', '/personal'], '/dispositivos'), 'Teléfono autorizado.');
    }

    #[Accion('personal_admin')]
    public function retira(Peticion $peticion): Respuesta
    {
        $this->personal->retiraDispositivo((int) $peticion->parametro('id', '0'), $peticion->ip());

        return $this->hecho($peticion, $this->sesion, $this->regreso($peticion, ['/dispositivos', '/personal'], '/dispositivos'), 'Autorización retirada.');
    }

    #[Accion('notificaciones_envia', unaVez: true)]
    public function notifica(Peticion $peticion): Respuesta
    {
        $this->notificaciones->envia(
            (int)$peticion->dato('destino',$peticion->parametro('id','0')),
            (string)$peticion->dato('titulo',''),
            (string)$peticion->dato('cuerpo',''),
            [],$peticion->ip()
        );
        return $this->hecho($peticion,$this->sesion,'/dispositivos?filtro=autorizados','Notificación enviada.');
    }
}
