<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Giro;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Vista;
use Servicios\Organizacion;
use Servicios\ReportesRestaurante;
use Servicios\TableroVivo;

/**
 * La primera pantalla después de entrar.
 *
 * **Enseña lo que hay que atender hoy, no todo lo que existe.** Cada fase del
 * giro agrega aquí sus fichas, y cada número se consulta sólo si quien mira
 * puede verlo. Quien no tiene tablero ve los accesos a sus pantallas.
 */
#[Modulo('tablero', 'Tablero')]
final class Tablero extends Controlador
{
    public function __construct(
        private Vista $vista,
        private Identidad $identidad,
        private TableroVivo $tablero,
        private Organizacion $organizacion,
        private ReportesRestaurante $reportes
    ) {
    }

    /** `/` del panel cuando no hay landing delante: al tablero, conservando la consulta. */
    #[Accion(publica: true)]
    public function raiz(Peticion $peticion): Respuesta
    {
        $consulta = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_QUERY);

        return Respuesta::redireccion('/panel' . ($consulta !== '' ? '?' . $consulta : ''));
    }

    #[Accion(publica: true)]
    public function ver(Peticion $peticion): Respuesta
    {
        $resumen = $this->identidad->puede('tablero_ver') ? $this->tablero->resumen() : null;
        $fichas  = [];

        if ($resumen !== null) {
            $fichas[] = ['titulo' => 'Sucursales activas', 'dato' => (string) $resumen['sucursales'],
                'pie' => 'en su alcance', 'ruta' => '/sucursales'];
            $fichas[] = ['titulo' => 'Personal activo', 'dato' => (string) $resumen['personal'],
                'pie' => 'personas con puesto', 'ruta' => '/personal'];
            $restaurante = Giro::activo('restaurante');
            if ($this->identidad->puede($restaurante ? 'equipo_admin' : 'personal_ver')) {
                $n = $resumen['equipos_pendientes'];
                $fichas[] = ['titulo' => 'Equipos por autorizar', 'dato' => (string) $n,
                    'pie' => $n === 1 ? 'equipo espera autorización' : 'equipos esperan autorización',
                    'ruta' => $restaurante ? '/equipos-comanda' : '/dispositivos'];
            }
            if ($this->identidad->esAdministrador()) {
                $n = $resumen['bloqueos'];
                $fichas[] = ['titulo' => 'Accesos bloqueados', 'dato' => (string) $n,
                    'pie' => 'por intentos fallidos, ahora', 'ruta' => '/seguridad'];
            }
        }

        $operacion = [];
        $sucursales = [];
        $sucursal = 0;
        if (Giro::activo('restaurante') && $this->identidad->puede('reportes_restaurante')) {
            $sucursales = $this->organizacion->opcionesSucursal();
            $sucursal = (int) $peticion->consulta('sucursal', array_key_first($sucursales));
            if (isset($sucursales[$sucursal])) {
                $operacion = $this->reportes->vivos($sucursal);
            }
        }

        return Respuesta::html($this->vista->pinta('tablero/inicio', [
            'titulo'   => 'Tablero',
            'permisos' => $this->identidad->permisos(),
            'fichas'   => $fichas,
            'resumen'  => $resumen,
            'operacion' => $operacion,
            'sucursal' => $sucursal,
            'sucursales' => $sucursales,
        ]));
    }
}
