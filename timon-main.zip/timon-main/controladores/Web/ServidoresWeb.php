<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Errores\Errores;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Servicios\Instalaciones;
use Servicios\Liberaciones;

/**
 * Las computadoras de sucursal: registrarlas, ver cómo va su sincronización
 * y decidir a qué versión del sistema se actualiza cada una
 * (`docs/servidor-sucursal.md`).
 */
#[Modulo('replica', 'Servidores de sucursal')]
final class ServidoresWeb extends Controlador
{
    public function __construct(
        private Vista $vista,
        private Instalaciones $instalaciones,
        private Liberaciones $liberaciones,
        private Sesion $sesion
    ) {
    }

    #[Accion('servidor_admin')]
    public function lista(Peticion $p): Respuesta
    {
        return Respuesta::html($this->vista->pinta('admin/servidores', [
            'titulo' => 'Operación local',
            'servidores' => $this->instalaciones->lista(),
            'liberaciones' => $this->liberaciones->lista(),
            'minutos' => Instalaciones::SIN_NOTICIAS,
        ]));
    }

    #[Accion('servidor_admin', unaVez: true)]
    public function registra(Peticion $p): Respuesta
    {
        $hecho = $this->instalaciones->registra((int) $p->dato('sucursal', 0), (string) $p->dato('nombre', ''));

        // El secreto se ve una sola vez: aquí solo queda su SHA-256.
        // Son el `desplazamiento` y el `secreto` de su config/instalacion.php.
        return $this->hecho($p, $this->sesion, '/servidores', sprintf(
            'Registrada. Anote el número %d y la llave %s.', $hecho['desplazamiento'], $hecho['secreto']));
    }

    /**
     * Sube un paquete firmado: el `.tar.gz` y su `.firma.json`, los dos de
     * `guiones/prepara-liberacion-sucursal.sh`. Si pesa más de lo que deja el
     * hospedaje, se registra con `guiones/registra-liberacion.php`.
     */
    #[Accion('servidor_admin', unaVez: true)]
    public function subeVersion(Peticion $p): Respuesta
    {
        $paquete = $p->archivo('paquete');
        $firma = $p->archivo('firma');
        if ($paquete === null || $paquete['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($paquete['ruta'])) {
            throw Errores::datosInvalidos(['paquete' => 'Seleccione el paquete .tar.gz']);
        }
        $descriptor = $firma !== null && $firma['error'] === UPLOAD_ERR_OK && is_uploaded_file($firma['ruta']) && $firma['peso'] < 4096
            ? json_decode((string) file_get_contents($firma['ruta']), true) : null;
        if (!is_array($descriptor)) {
            throw Errores::datosInvalidos(['firma' => 'Seleccione la firma del paquete']);
        }
        $id = $this->liberaciones->registra($paquete['ruta'], $descriptor, (string) $p->dato('notas', ''));

        return $this->hecho($p, $this->sesion, '/servidores', 'Versión ' . $id . ' registrada.');
    }

    /** La versión a la que se actualiza esa computadora; vacío es quedarse como está. */
    #[Accion('servidor_admin', unaVez: true)]
    public function asignaVersion(Peticion $p): Respuesta
    {
        $version = trim((string) $p->dato('liberacion', ''));
        $this->liberaciones->asigna((int) $p->dato('instalacion', 0), $version === '' ? null : $version);

        return $this->hecho($p, $this->sesion, '/servidores',
            $version === '' ? 'Se queda con la versión que tiene.' : 'Se actualiza sola cuando cierren las cuentas.');
    }

    #[Accion('servidor_admin', unaVez: true)]
    public function regresa(Peticion $p): Respuesta
    {
        $this->instalaciones->regresaAlCentral((int) $p->parametro('id', '0'), (string) $p->dato('aun_con_pendientes', '') === '1');

        return $this->hecho($p, $this->sesion, '/servidores', 'La sucursal opera de nuevo en el central.');
    }
}
