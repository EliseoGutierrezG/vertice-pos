<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Modelos\Usuarios;
use Modelos\IntentosAcceso;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Bitacora;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Registro;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Servicios\SegundoFactor;

/**
 * Entrar y salir del sistema.
 *
 * Dos decisiones que parecen detalles y no lo son:
 *
 *  - **El mensaje de error es siempre el mismo.** Distinguir "no existe ese
 *    usuario" de "esa no es la contraseña" le regala a quien prueba la mitad
 *    del trabajo: le confirma qué nombres existen.
 *  - **Se renueva el identificador de sesión al entrar.** Si alguien plantó
 *    una cookie antes del acceso, la que queda después es otra.
 */
#[Modulo('entrada', 'Entrada al sistema')]
final class Entrada extends Controlador
{
    public function __construct(
        private Vista $vista,
        private Sesion $sesion,
        private Usuarios $usuarios,
        private Identidad $identidad,
        private Bitacora $bitacora,
        private Registro $registro,
        private IntentosAcceso $intentos,
        private SegundoFactor $segundoFactor
    ) {
    }

    /**
     * A dónde volver después de entrar (homologación §S.6 y §S.9).
     *
     * Solo una ruta de este mismo sitio, o `cerrar`: la pestaña que se abrió
     * para recuperar la sesión de otra, y que solo tiene que decir que ya se
     * puede cerrar. ⚠️ Nunca un dominio: `//otro.sitio` o `/\otro.sitio` los
     * navegadores los leen como direcciones de fuera, y la entrada se volvería
     * un trampolín para mandar a la gente a una copia del sistema.
     */
    public static function vueltaValida(mixed $vuelta): ?string
    {
        if (!is_string($vuelta) || $vuelta === '' || strlen($vuelta) > 500) {
            return null;
        }

        if ($vuelta === 'cerrar') {
            return $vuelta;
        }

        if (preg_match('#^/(?![/\\\\])[^\\s\\\\]*$#', $vuelta) !== 1 || str_contains($vuelta, '://')) {
            return null;
        }

        $ruta = (string) parse_url($vuelta, PHP_URL_PATH);
        foreach (['/entrar', '/salir', '/segundo-factor', '/sesion'] as $sinVuelta) {
            if ($ruta === $sinVuelta || str_starts_with($ruta, $sinVuelta . '/')) {
                return null;
            }
        }

        return $vuelta;
    }

    /** La pantalla que sigue a la entrada. */
    public static function destino(?string $vuelta): string
    {
        return match ($vuelta) {
            null     => '/panel',
            'cerrar' => '/sesion/lista',
            default  => $vuelta,
        };
    }

    #[Accion(publica: true)]
    public function formulario(Peticion $peticion): Respuesta
    {
        $vuelta = self::vueltaValida($peticion->consulta('vuelta'));

        if (is_int($this->sesion->saca('id_usuario'))) {
            return Respuesta::redireccion(self::destino($vuelta));
        }

        return Respuesta::html($this->vista->pinta(
            'entrada/formulario',
            ['titulo' => 'Entrar', 'usuario' => '', 'error' => null, 'vuelta' => $vuelta],
            'plantilla/limpia'
        ));
    }

    #[Accion(publica: true)]
    public function entra(Peticion $peticion): Respuesta
    {
        $usuario = trim((string) $peticion->dato('usuario', ''));
        $clave   = (string) $peticion->dato('clave', '');
        $vuelta  = self::vueltaValida($peticion->dato('vuelta'));

        $reintentarEn = $this->intentos->reintento('entrada', $usuario, $peticion->ip());
        if ($reintentarEn > 0) {
            throw \Nucleo\Errores\Errores::demasiadosIntentos($reintentarEn);
        }

        // Un solo camino para la web y para la app, y en tiempo parejo: el
        // usuario que no existe cuesta el mismo bcrypt que el que sí. Sin eso,
        // el reloj contesta lo que el mensaje calla. Está en `Usuarios::autentica`.
        $registro = $this->usuarios->autentica($usuario, $clave);

        if ($registro === null) {
            $reintentarEn = $this->intentos->falla('entrada', $usuario, $peticion->ip());
            $this->registro->aviso('Acceso fallido', [
                'ip_hash' => IntentosAcceso::hashDireccion($peticion->ip()),
            ]);

            if ($reintentarEn > 0) {
                throw \Nucleo\Errores\Errores::demasiadosIntentos($reintentarEn);
            }

            return Respuesta::html($this->vista->pinta(
                'entrada/formulario',
                [
                    'titulo'  => 'Entrar',
                    'usuario' => $usuario,
                    // El mismo mensaje pase lo que pase.
                    'error'   => 'Usuario o contraseña incorrectos.',
                    'vuelta'  => $vuelta,
                ],
                'plantilla/limpia'
            ), 401);
        }

        /** @var array<string,mixed> $registro */
        $this->intentos->acierta('entrada', $usuario, $peticion->ip());

        if ($this->segundoFactor->requiere((int) $registro['id'])) {
            // La contraseña ya fue correcta, pero todavía no hay identidad.
            // Se destruye cualquier sesión anterior y la espera vence pronto.
            $this->sesion->vacia();
            $this->sesion->pon('entrada_pendiente', [
                'id' => (int) $registro['id'],
                'usuario' => (string) $registro['usuario'],
                'hasta' => time() + 300,
                'vuelta' => $vuelta,
            ]);

            if (!$this->segundoFactor->configurado((int) $registro['id'])) {
                $this->segundoFactor->prepara((int) $registro['id'], $peticion->ip());
                return Respuesta::redireccion('/segundo-factor/configurar');
            }

            return Respuesta::redireccion('/segundo-factor');
        }

        $this->completa($registro, $peticion->ip());

        return Respuesta::redireccion(self::destino($vuelta));
    }

    /** @param array<string,mixed> $registro */
    private function completa(array $registro, string $ip): void
    {
        $this->sesion->renueva();
        $this->sesion->pon('id_usuario', (int) $registro['id']);
        $this->sesion->pon('sesion_version', (int) ($registro['sesion_version'] ?? 1));
        $this->sesion->pon(\Nucleo\Middleware\ExigeSesion::ENTRADA, time());
        $this->sesion->quita('entrada_pendiente');

        $this->bitacora->registra(
            'entrada',
            'entra',
            'usuario',
            (int) $registro['id'],
            idUsuario: (int) $registro['id'],
            ip: $ip
        );
    }

    #[Accion(publica: true, conClaveTemporal: true)]
    public function sale(Peticion $peticion): Respuesta
    {
        if ($this->identidad->hay()) {
            $this->bitacora->registra(
                'entrada',
                'sale',
                'usuario',
                $this->identidad->id(),
                idUsuario: $this->identidad->id(),
                ip: $peticion->ip()
            );
        }

        $this->sesion->cierra();
        $this->identidad->olvida();

        return Respuesta::redireccion('/entrar');
    }
}
