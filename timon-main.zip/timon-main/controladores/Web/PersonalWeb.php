<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Peticion;
use Nucleo\Identidad;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Servicios\Organizacion;
use Servicios\Personal;
use Servicios\SegundoFactor;

/**
 * Personal, su usuario y sus equipos.
 *
 * Se llama `PersonalWeb` porque `Personal` es el
 * servicio, igual que `BitacoraWeb`.
 *
 * La contraseña temporal que sale al crear el usuario, restablecerla o
 * reactivar el acceso viaja a la ficha **por la sesión, una sola vez**: la ficha
 * la saca y la borra al pintarla. Así no queda en una URL, en el historial ni
 * en la bitácora.
 */
#[Modulo('personal', 'Personal')]
final class PersonalWeb extends Controlador
{
    private const CLAVE_TEMPORAL = 'clave_temporal';

    public function __construct(
        private Vista $vista,
        private Personal $personal,
        private Organizacion $organizacion,
        private Sesion $sesion,
        private SegundoFactor $segundoFactor,
        private Identidad $identidad
    ) {
    }

    #[Accion('personal_ver')]
    public function lista(Peticion $peticion): Respuesta
    {
        $estatus  = $this->filtroEstatus($peticion);
        $idSucursal = (int) $peticion->consulta('sucursal', '0');
        $idPuesto = (int) $peticion->consulta('puesto', '0');

        return Respuesta::html($this->vista->pinta('personal/lista', [
            'titulo'     => 'Personal',
            'personas'   => $this->personal->personas($estatus, $idSucursal, $idPuesto),
            'estatus'    => $estatus,
            'idSucursal'   => $idSucursal,
            'idPuesto'   => $idPuesto,
            'sucursales'    => $this->organizacion->opcionesSucursal(),
            'puestos'    => $this->personal->opcionesPuesto(),
            'superiores' => $this->personal->opcionesSuperior(),
            'mostrarCredencial' => (string) $peticion->consulta('credencial', '') === '1',
            'personaSolicitada' => (int) $peticion->consulta('ver', '0'),
        ]));
    }

    #[Accion('personal_ver')]
    public function exporta(Peticion $peticion): Respuesta
    {
        $personas = $this->personal->personas($this->filtroEstatus($peticion), (int) $peticion->consulta('sucursal', '0'), (int) $peticion->consulta('puesto', '0'));
        $filas = array_map(static function (array $p): array {
            $acceso = $p['usuario'] === null ? 'Sin usuario' : ((int) $p['estatus_usuario'] !== 4 ? 'Bloqueado' : ((int) $p['cambiar_clave'] === 1 ? 'Contraseña temporal' : 'Activo'));
            return [trim($p['nombre'] . ' ' . $p['apellido_paterno'] . ' ' . ($p['apellido_materno'] ?? '')),
                $p['puesto'], $p['sucursal'] ?? 'Todas', ($p['usuario'] === null ? '' : $p['usuario'] . "\n") . $acceso,
                (int) $p['id_estatus'] === 4 ? 'Activo' : 'Dado de baja'];
        }, $personas);
        return $this->xlsx('Personal', [
            ['titulo' => 'Nombre'], ['titulo' => 'Puesto'], ['titulo' => 'Sucursal'], ['titulo' => 'Usuario'], ['titulo' => 'Estatus'],
        ], $filas)->conCabecera('Cache-Control', 'no-store');
    }

    #[Accion('personal_ver')]
    public function ver(Peticion $peticion): Respuesta
    {
        $id      = (int) $peticion->parametro('id', '0');
        $persona = $this->personal->persona($id);

        if ($peticion->esperaJson()) return $this->detalleModal($peticion);
        if ((string) $peticion->consulta('sinjs', '') !== '1') {
            $pendiente = $this->sesion->saca(self::CLAVE_TEMPORAL);
            $mostrar = is_array($pendiente) && (int) ($pendiente['id_personal'] ?? 0) === $id && $this->identidad->puede('personal_admin');
            return Respuesta::redireccion('/personal?ver=' . $id . ($mostrar ? '&credencial=1' : ''))->conCabecera('Cache-Control', 'no-store');
        }

        $temporal = $this->sesion->saca(self::CLAVE_TEMPORAL);
        $temporal = is_array($temporal) && (int) ($temporal['id_personal'] ?? 0) === $id && $this->identidad->puede('personal_admin') ? $temporal : null;
        if ($temporal !== null) $this->sesion->quita(self::CLAVE_TEMPORAL);

        $idUsuario = $persona['id_usuario'] === null ? null : (int) $persona['id_usuario'];

        $respuesta = Respuesta::html($this->vista->pinta('personal/ficha', [
            'titulo'       => trim($persona['nombre'] . ' ' . $persona['apellido_paterno']),
            'persona'      => $persona,
            'temporal'     => $temporal,
            'sugerencia'   => $idUsuario === null ? $this->personal->sugiereUsuario($persona) : '',
            'telefonos'    => $idUsuario === null ? [] : $this->personal->dispositivos('todos', $idUsuario),
            'sucursales'      => $this->organizacion->opcionesSucursal(),
            'asignadas'    => $idUsuario === null ? [] : $this->personal->sucursalesAsignadas($idUsuario),
            'puestos'      => $this->personal->opcionesPuesto(),
            'superiores'   => $this->personal->opcionesSuperior(),
        ]));

        // La página que trae una contraseña no se guarda en ningún caché.
        return $temporal === null ? $respuesta : $respuesta->conCabecera('Cache-Control', 'no-store');
    }

    /** La contraseña solo se entrega al abrir explícitamente su ficha desde la redirección. */
    #[Accion('personal_ver')]
    public function detalleModal(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        $persona = $this->personal->persona($id);
        $usuario = $persona['id_usuario'] === null ? null : (int) $persona['id_usuario'];
        $temporal = null;
        if ((string) $peticion->consulta('credencial', '') === '1' && $this->identidad->puede('personal_admin')) {
            $pendiente = $this->sesion->saca(self::CLAVE_TEMPORAL);
            if (is_array($pendiente) && (int) ($pendiente['id_personal'] ?? 0) === $id) $temporal = $pendiente;
        }
        $html = $this->vista->suelta('personal/gestion-modal', [
            'persona' => $persona,
            'temporal' => $temporal,
            'sugerencia' => $usuario === null ? $this->personal->sugiereUsuario($persona) : '',
            'telefonos' => $usuario === null ? [] : $this->personal->dispositivos('todos', $usuario),
            'sucursales' => $this->organizacion->opcionesSucursal(),
            'asignadas' => $usuario === null ? [] : $this->personal->sucursalesAsignadas($usuario),
        ]);
        if ($temporal !== null) $this->sesion->quita(self::CLAVE_TEMPORAL);
        $registro = array_intersect_key($persona, array_flip(['nombre', 'apellido_paterno', 'apellido_materno', 'fecha_ingreso', 'telefono', 'correo', 'id_puesto', 'id_sucursal', 'id_superior']));
        return $this->ok(['titulo' => trim($persona['nombre'] . ' ' . $persona['apellido_paterno'] . ' ' . ($persona['apellido_materno'] ?? '')), 'html' => $html, 'registro' => $registro])
            ->conCabecera('Cache-Control', 'no-store');
    }

    #[Accion('personal_admin', unaVez: true)]
    public function asignaSucursales(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id');
        $this->personal->asignaSucursales($id, $peticion->dato('sucursales', []), $peticion->ip());
        return $this->hecho($peticion, $this->sesion, '/personal?ver=' . $id, 'Sucursales actualizadas.');
    }

    #[Accion('personal_admin', unaVez: true)]
    public function crea(Peticion $peticion): Respuesta
    {
        $id = $this->personal->guardaPersona(null, $peticion->datos(), $peticion->ip());

        return $this->hecho($peticion, $this->sesion, '/personal/' . $id, 'Persona creada. Falta su usuario.');
    }

    #[Accion('personal_admin')]
    public function edita(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        $this->personal->guardaPersona($id, $peticion->datos(), $peticion->ip());

        return $this->hecho($peticion, $this->sesion, $this->regreso($peticion, '/personal', '/personal/' . $id), 'Datos guardados.');
    }

    #[Accion('personal_admin')]
    public function baja(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        $this->personal->cambiaEstatusPersona($id, false, $peticion->ip());

        return $this->hecho($peticion, $this->sesion, $this->regreso($peticion, '/personal', '/personal'), 'Persona dada de baja.');
    }

    #[Accion('personal_admin')]
    public function reactiva(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        $this->personal->cambiaEstatusPersona($id, true, $peticion->ip());

        return $this->hecho($peticion, $this->sesion, $this->regreso($peticion, '/personal', '/personal/' . $id), 'Persona reactivada. Falta su acceso.');
    }

    #[Accion('personal_admin', unaVez: true)]
    public function creaUsuario(Peticion $peticion): Respuesta
    {
        $id      = (int) $peticion->parametro('id', '0');
        $usuario = mb_strtolower(trim((string) $peticion->dato('usuario', '')));
        $clave   = $this->personal->creaUsuario($id, $usuario, $peticion->ip());

        return $this->conClave($peticion, $id, $usuario, $clave, 'Usuario creado.');
    }

    #[Accion('personal_admin', unaVez: true)]
    public function restableceClave(Peticion $peticion): Respuesta
    {
        $id    = (int) $peticion->parametro('id', '0');
        $clave = $this->personal->restableceClave($id, $peticion->ip());

        return $this->conClave($peticion, $id, (string) $this->personal->persona($id)['usuario'], $clave, 'Contraseña restablecida. Debe entrar de nuevo en sus equipos.');
    }

    #[Accion('personal_admin')]
    public function restableceSegundoFactor(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        $persona = $this->personal->persona($id);
        if ($persona['id_usuario'] === null) {
            throw \Nucleo\Errores\Errores::conflicto('La persona no tiene usuario');
        }
        $this->segundoFactor->restablece((int) $persona['id_usuario'], $this->identidad->id(), $peticion->ip());

        return $this->hecho($peticion, $this->sesion, '/personal/' . $id, 'Segundo factor restablecido.');
    }

    #[Accion('personal_admin')]
    public function bloqueaUsuario(Peticion $peticion): Respuesta
    {
        $id = (int) $peticion->parametro('id', '0');
        $this->personal->cambiaEstatusUsuario($id, false, $peticion->ip());

        return $this->hecho($peticion, $this->sesion, $this->regreso($peticion, ['/personal', '/seguridad/accesos'], '/personal/' . $id), 'Acceso bloqueado.');
    }

    #[Accion('personal_admin', unaVez: true)]
    public function reactivaUsuario(Peticion $peticion): Respuesta
    {
        $id    = (int) $peticion->parametro('id', '0');
        $clave = (string) $this->personal->cambiaEstatusUsuario($id, true, $peticion->ip());

        return $this->conClave($peticion, $id, (string) $this->personal->persona($id)['usuario'], $clave, 'Acceso reactivado.');
    }

    private function conClave(Peticion $peticion, int $id, string $usuario, string $clave, string $aviso): Respuesta
    {
        $this->sesion->pon(self::CLAVE_TEMPORAL, ['id_personal' => $id, 'usuario' => $usuario, 'clave' => $clave]);

        return $this->hecho($peticion, $this->sesion, '/personal/' . $id, $aviso);
    }
}
