<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Dominio\DatosRestaurante as Datos;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Contenedor;
use Nucleo\Errores\Errores;
use Nucleo\Giro;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Vista;
use Servicios\CajaRestaurante;
use Servicios\CartaImpresa;
use Servicios\Comandas;
use Servicios\FotosCarta;
use Servicios\MenuRestaurante;
use Servicios\Reservaciones;

#[Modulo('sitio_restaurante', 'Sitio de El Timón')]
final class SitioRestaurante extends Controlador
{
    public function __construct(
        private Vista $vista,
        private MenuRestaurante $menu,
        private Reservaciones $reservaciones,
        private Comandas $comandas,
        private CajaRestaurante $caja,
        private Contenedor $contenedor,
        private FotosCarta $fotos
    ) {
    }

    #[Accion(publica: true)]
    public function carta(Peticion $p): Respuesta
    {
        $menu = $this->menu->publica((string) $p->parametro('sucursal'));
        $mesa = $this->menu->mesaPublica((int) $menu['sucursal']['id'], (int) $p->consulta('mesa', 0));
        return Respuesta::html($this->vista->suelta('restaurante/carta-publica', $menu + ['mesa' => $mesa]));
    }

    /** Los buscadores ven la landing y los menús; el panel y la app, no. */
    #[Accion(publica: true)]
    public function robots(Peticion $p): Respuesta
    {
        $origen = $this->origen();
        // Son reglas para buscadores, no texto para personas: van una por renglón.
        $reglas = ['User-agent: *', 'Allow: /', 'Allow: /menu/', 'Allow: /api/v1/sucursales-publicas', 'Allow: /api/v1/menu-publico/',
            'Disallow: /panel', 'Disallow: /app/', 'Disallow: /api/', 'Disallow: /ticket/', 'Disallow: /entrar'];
        if ($origen !== '') {
            $reglas[] = 'Sitemap: ' . $origen . '/sitemap.xml';
        }
        return Respuesta::texto(implode("\n", $reglas) . "\n")
            ->conCabecera('Cache-Control', 'public, max-age=86400');
    }

    /** La landing y el menú de cada sucursal publicada. */
    #[Accion(publica: true)]
    public function mapaSitio(Peticion $p): Respuesta
    {
        $origen = $this->origen();
        $direcciones = [$origen . '/'];
        foreach ($this->reservaciones->sucursalesPublicas() as $sucursal) {
            $direcciones[] = $origen . '/menu/' . rawurlencode((string) $sucursal['clave']);
        }
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($direcciones as $direccion) {
            $xml .= '  <url><loc>' . htmlspecialchars($direccion, ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</loc></url>' . "\n";
        }
        return Respuesta::texto($xml . '</urlset>' . "\n")
            ->conCabecera('Content-Type', 'application/xml; charset=utf-8')
            ->conCabecera('Cache-Control', 'public, max-age=3600');
    }

    #[Accion(publica: true)]
    public function foto(Peticion $p): Respuesta
    {
        return Respuesta::archivo($this->fotos->lee((string) $p->parametro('clave')), 'image/webp', 31536000);
    }

    /**
     * El menú de una sucursal para la portada: lo mismo que el menú QR, sin lo
     * que sólo le sirve a la operación (área de preparación, modificadores).
     */
    #[Accion(publica: true)]
    public function menuPublico(Peticion $p): Respuesta
    {
        $menu = $this->menu->publica((string) $p->parametro('sucursal'));
        return $this->ok([
            'sucursal' => ['clave' => $menu['sucursal']['clave'], 'nombre' => $menu['sucursal']['nombre']],
            'platillos' => array_map(static fn (array $fila): array => [
                'categoria' => $fila['categoria'],
                'nombre' => $fila['nombre'],
                'descripcion' => $fila['descripcion'],
                'foto' => $fila['foto'],
                'precio' => $fila['precio'],
                'agotado' => (bool) (int) $fila['agotado'],
                'especialidad' => (bool) (int) $fila['especialidad'],
                'porcion' => $fila['porcion'],
                'descripcion_categoria' => $fila['descripcion_categoria'],
                'preparaciones' => CartaImpresa::preparaciones($fila['modificadores'] ?? []),
                'promocion' => $fila['promocion'],
            ], $menu['platillos']),
        ]);
    }

    #[Accion(publica: true)]
    public function sucursales(Peticion $p): Respuesta
    {
        // El identificador interno no sale al público: la clave basta.
        return $this->ok(array_map(static function (array $s): array {
            unset($s['id']);
            return $s;
        }, $this->reservaciones->sucursalesPublicas()));
    }

    #[Accion(publica: true)]
    public function redes(Peticion $p): Respuesta
    {
        return $this->ok(Giro::redes());
    }

    #[Accion(publica: true)]
    public function reserva(Peticion $p): Respuesta
    {
        return $this->ok(['folio' => $this->reservaciones->solicita($p->datos(), $p->ip())], 201);
    }

    #[Accion('plano_ver')]
    public function qrMesa(Peticion $p): Respuesta
    {
        $idSucursal = Datos::entero($p->consulta('sucursal'), 'sucursal');
        $sucursal = null;
        foreach ($this->reservaciones->sucursalesPublicas() as $fila) {
            if ((int) $fila['id'] === $idSucursal) {
                $sucursal = $fila;
                break;
            }
        }
        if ($sucursal === null) {
            throw Errores::noEncontrado('Configure la clave pública de la sucursal');
        }
        $idMesa = (int) $p->parametro('id');
        foreach ($this->comandas->plano($idSucursal)['mesas'] as $mesa) {
            if ((int) $mesa['id'] === $idMesa) {
                $enlace = $this->origen() . '/menu/' . rawurlencode($sucursal['clave']) . '?mesa=' . $idMesa;
                return Respuesta::html($this->vista->pinta('restaurante/qr-mesa', [
                    'titulo' => 'Menú de la mesa', 'ancho' => '80', 'sucursal' => $sucursal,
                    'mesa' => $mesa, 'enlace' => $enlace,
                ], 'plantilla/papel'));
            }
        }
        throw Errores::noEncontrado('Mesa no disponible');
    }

    #[Accion(publica: true)]
    public function ticket(Peticion $p): Respuesta
    {
        $token = (string) $p->parametro('token');
        if (strlen($token) !== 32) {
            throw Errores::noEncontrado('Ticket no disponible');
        }
        $ancho = $p->consulta('ancho', '80');
        return Respuesta::html($this->vista->pinta('restaurante/ticket', [
            'titulo' => 'Ticket', 'ancho' => in_array($ancho, ['58','76','80'], true) ? $ancho : '80',
            'ticket' => $this->caja->ticket($token), 'enlace' => $this->origen() . '/ticket/' . $token,
        ], 'plantilla/papel'))->conCabecera('Cache-Control', 'no-store')->conCabecera('X-Robots-Tag', 'noindex');
    }

    private function origen(): string
    {
        return rtrim((string) $this->contenedor->config('url_publica', ''), '/');
    }
}
