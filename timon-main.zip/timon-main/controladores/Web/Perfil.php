<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Modelos\Usuarios;
use Servicios\Personal;

/**
 * La cuenta de quien está usando el sistema: sus datos, sus permisos y su
 * contraseña. Los datos y los permisos no se editan aquí: los da su puesto.
 */
#[Modulo('perfil', 'Mi perfil')]
final class Perfil extends Controlador
{
    public function __construct(
        private Vista $vista,
        private Identidad $identidad,
        private Personal $personal,
        private Sesion $sesion,
        private Usuarios $usuarios
    ) {
    }

    #[Accion(publica: true)]
    public function ver(Peticion $peticion): Respuesta
    {
        return Respuesta::html($this->vista->pinta('perfil/ver', [
            'titulo'   => 'Mi perfil',
            'usuario'  => $this->identidad->usuario(),
            'permisos' => $this->identidad->permisos(),
            'descripciones' => $this->usuarios->descripcionesPermisos($this->identidad->permisos()),
        ]));
    }

    /**
     * Cambiar la contraseña propia. Es también a donde `ExigeClaveDefinitiva`
     * manda a quien entró con una temporal.
     */
    #[Accion(publica: true, conClaveTemporal: true)]
    public function clave(Peticion $peticion): Respuesta
    {
        return Respuesta::html($this->vista->pinta('perfil/clave', [
            'titulo'   => 'Cambiar contraseña',
            'temporal' => $this->identidad->debeCambiarClave(),
            'minimo'   => \Modelos\Usuarios::LARGO_MINIMO,
        ]));
    }

    #[Accion(publica: true, conClaveTemporal: true)]
    public function cambiaClave(Peticion $peticion): Respuesta
    {
        $this->personal->cambiaClavePropia(
            $peticion->dato('actual', ''),
            $peticion->dato('nueva', ''),
            $peticion->dato('confirma', ''),
            $peticion->ip()
        );

        // El cambio invalida todas las demás sesiones mediante sesion_version,
        // pero la sesión que acaba de demostrar la contraseña actual continúa.
        $version = $this->sesion->saca('sesion_version');
        if (is_int($version)) {
            $this->sesion->pon('sesion_version', $version + 1);
        }

        return $this->hecho($peticion, $this->sesion, '/panel', 'Contraseña cambiada. Entre de nuevo en sus teléfonos.');
    }
}
