<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Modelos\IntentosAcceso;
use Modelos\Usuarios;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Errores\Errores;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Servicios\SegundoFactor;

#[Modulo('segundo_factor', 'Segundo factor de acceso')]
final class SegundoFactorWeb extends Controlador
{
    public function __construct(
        private Vista $vista,
        private Sesion $sesion,
        private SegundoFactor $segundoFactor,
        private Usuarios $usuarios,
        private IntentosAcceso $intentos,
        private Bitacora $bitacora
    ) {
    }

    #[Accion(publica: true)]
    public function formulario(Peticion $peticion): Respuesta
    {
        $pendiente = $this->pendiente();
        if ($pendiente instanceof Respuesta) return $pendiente;
        if (!$this->segundoFactor->configurado((int) $pendiente['id'])) {
            return Respuesta::redireccion('/segundo-factor/configurar');
        }
        return $this->pintaCodigo($pendiente, null);
    }

    #[Accion(publica: true)]
    public function valida(Peticion $peticion): Respuesta
    {
        $pendiente = $this->pendiente();
        if ($pendiente instanceof Respuesta) return $pendiente;
        $usuario = (string) $pendiente['usuario'];
        $reintentar = $this->intentos->reintento('segundo_factor', $usuario, $peticion->ip());
        if ($reintentar > 0) throw Errores::demasiadosIntentos($reintentar);

        try {
            $this->segundoFactor->valida((int) $pendiente['id'], (string) $peticion->dato('codigo', ''), 'entrada', $peticion->ip());
        } catch (ErrorHttp $e) {
            $reintentar = $this->intentos->falla('segundo_factor', $usuario, $peticion->ip());
            if ($reintentar > 0) throw Errores::demasiadosIntentos($reintentar);
            return $this->pintaCodigo($pendiente, 'El código no es válido, venció o ya fue utilizado.', 401);
        }

        $this->intentos->acierta('segundo_factor', $usuario, $peticion->ip());
        $this->completa((int) $pendiente['id'], $peticion->ip());
        return Respuesta::redireccion(Entrada::destino($pendiente['vuelta']));
    }

    #[Accion(publica: true)]
    public function configurar(Peticion $peticion): Respuesta
    {
        $pendiente = $this->pendiente();
        if ($pendiente instanceof Respuesta) return $pendiente;
        if ($this->segundoFactor->configurado((int) $pendiente['id'])) {
            return Respuesta::redireccion('/segundo-factor');
        }
        $configuracion = $this->segundoFactor->prepara((int) $pendiente['id'], $peticion->ip());
        return Respuesta::html($this->vista->pinta('entrada/configura-segundo-factor', [
            'titulo' => 'Configurar segundo factor',
            'configuracion' => $configuracion,
            'error' => null,
        ], 'plantilla/limpia'))->conCabecera('Cache-Control', 'no-store');
    }

    #[Accion(publica: true)]
    public function confirma(Peticion $peticion): Respuesta
    {
        $pendiente = $this->pendiente();
        if ($pendiente instanceof Respuesta) return $pendiente;
        try {
            $codigos = $this->segundoFactor->confirma(
                (int) $pendiente['id'], (string) $peticion->dato('codigo', ''), $peticion->ip()
            );
        } catch (ErrorHttp $e) {
            $configuracion = $this->segundoFactor->prepara((int) $pendiente['id'], $peticion->ip());
            return Respuesta::html($this->vista->pinta('entrada/configura-segundo-factor', [
                'titulo' => 'Configurar segundo factor', 'configuracion' => $configuracion,
                'error' => 'El código no es válido o ya venció.',
            ], 'plantilla/limpia'), $e->estado())->conCabecera('Cache-Control', 'no-store');
        }

        $this->completa((int) $pendiente['id'], $peticion->ip());
        // Se muestran con una redirección: recargar la página de los códigos
        // ya no reenvía el formulario de confirmación.
        $this->sesion->pon('codigos_recuperacion', $codigos);
        return Respuesta::redireccion('/segundo-factor/codigos');
    }

    /** Los códigos de recuperación, una sola vez: al pintarlos salen de la sesión. */
    #[Accion(publica: true)]
    public function codigos(Peticion $peticion): Respuesta
    {
        $codigos = $this->sesion->saca('codigos_recuperacion');
        $this->sesion->quita('codigos_recuperacion');
        if (!is_array($codigos) || $codigos === [] || !$this->sesion->tiene('id_usuario')) {
            return Respuesta::redireccion('/panel');
        }
        return Respuesta::html($this->vista->pinta('entrada/codigos-recuperacion', [
            'titulo' => 'Códigos de recuperación', 'codigos' => array_values(array_map('strval', $codigos)),
        ], 'plantilla/limpia'))->conCabecera('Cache-Control', 'no-store');
    }

    /** @return array{id:int,usuario:string,hasta:int,vuelta:?string}|Respuesta */
    private function pendiente(): array|Respuesta
    {
        $pendiente = $this->sesion->saca('entrada_pendiente');
        if (!is_array($pendiente) || !is_int($pendiente['id'] ?? null)
            || !is_int($pendiente['hasta'] ?? null) || $pendiente['hasta'] < time()) {
            $this->sesion->vacia();
            $this->sesion->avisa('Sesión vencida. Entre de nuevo.', 'mal');
            return Respuesta::redireccion('/entrar');
        }
        // Lo apagaron a media verificación: con el parámetro en 0 la entrada ya
        // no lo pide, y basta volver a escribir la contraseña.
        if (!$this->segundoFactor->activo()) {
            $this->sesion->vacia();
            $this->sesion->avisa('Ya no se pide código. Entre de nuevo.', 'bien');
            return Respuesta::redireccion('/entrar');
        }
        return [
            'id' => $pendiente['id'], 'usuario' => (string) ($pendiente['usuario'] ?? ''), 'hasta' => $pendiente['hasta'],
            'vuelta' => Entrada::vueltaValida($pendiente['vuelta'] ?? null),
        ];
    }

    /** @param array{id:int,usuario:string,hasta:int} $pendiente */
    private function pintaCodigo(array $pendiente, ?string $error, int $estado = 200): Respuesta
    {
        return Respuesta::html($this->vista->pinta('entrada/segundo-factor', [
            'titulo' => 'Verificar acceso', 'usuario' => $pendiente['usuario'], 'error' => $error,
        ], 'plantilla/limpia'), $estado)->conCabecera('Cache-Control', 'no-store');
    }

    private function completa(int $idUsuario, string $ip): void
    {
        $registro = $this->usuarios->porId($idUsuario);
        if ($registro === null || (int) $registro['id_estatus'] !== 4) {
            throw Errores::noAutenticado('Cuenta inactiva');
        }
        $this->sesion->renueva();
        $this->sesion->pon('id_usuario', $idUsuario);
        $this->sesion->pon('sesion_version', (int) $registro['sesion_version']);
        $this->sesion->pon(\Nucleo\Middleware\ExigeSesion::ENTRADA, time());
        $this->sesion->quita('entrada_pendiente');
        $this->bitacora->registra('entrada', 'entra', 'usuario', $idUsuario, idUsuario: $idUsuario, ip: $ip);
    }
}

