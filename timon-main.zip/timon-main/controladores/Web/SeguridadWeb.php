<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Nucleo\Exporta\Csv;
use Servicios\RevisionAccesos;
use Servicios\Seguridad;

/** El interruptor del segundo factor web (bitácora 98). */
#[Modulo('seguridad', 'Seguridad')]
final class SeguridadWeb extends Controlador
{
    public function __construct(
        private Vista $vista,
        private Sesion $sesion,
        private Identidad $identidad,
        private Seguridad $seguridad,
        private RevisionAccesos $revision,
        private \Nucleo\AuditoriaLectura $lecturas
    ) {
    }

    #[Accion('seguridad_admin')]
    public function ver(Peticion $p): Respuesta
    {
        return Respuesta::html($this->vista->pinta('seguridad/ver', [
            'titulo' => 'Verificación en dos pasos',
            'estado' => $this->seguridad->estado(),
        ]))->conCabecera('Cache-Control', 'no-store');
    }

    #[Accion('seguridad_admin')]
    public function segundoFactor(Peticion $p): Respuesta
    {
        $encender = (string) $p->dato('encender', '') === '1';
        $this->seguridad->cambiaSegundoFactor($encender, $this->identidad->id(), $p->datos(), $p->ip());

        return $this->hecho($p, $this->sesion, '/seguridad', $encender
            ? 'Segundo factor encendido.'
            : 'Segundo factor apagado.');
    }

    #[Accion('accesos_revisa,seguridad_admin')]
    public function accesos(Peticion $p): Respuesta
    {
        return Respuesta::html($this->vista->pinta('seguridad/accesos', [
            'titulo' => 'Revisión de accesos',
            'reporte' => $this->revision->reporte(),
        ]))->conCabecera('Cache-Control', 'no-store');
    }

    #[Accion('accesos_revisa,seguridad_admin')]
    public function accesosXlsx(Peticion $p): Respuesta
    {
        require_once dirname(__DIR__, 2) . '/vistas/partes/piezas.php';
        $this->lecturas->anota('exporta_accesos', 'usuario', null, [], $p->ip());
        $filas = array_map(static fn (array $c): array => [
            $c['usuario'], $c['nombre'], $c['puesto'], $c['sucursal'] ?? 'Todas',
            (int) $c['id_estatus'] === 4 ? 'Activa' : 'Inactiva', $c['totp_confirmado_en'] === null ? 'No' : 'Sí',
            $c['acceso_hasta'] === null ? 'Sin caducidad' : \pb_fecha($c['acceso_hasta']) . ' · ' . ($c['acceso_motivo'] ?? ''),
        ], $this->revision->reporte()['cuentas']);
        return $this->xlsx('Revisión de accesos', [
            ['titulo' => 'Usuario'], ['titulo' => 'Nombre'], ['titulo' => 'Puesto'], ['titulo' => 'Sucursal'],
            ['titulo' => 'Cuenta'], ['titulo' => 'Authenticator'], ['titulo' => 'Acceso hasta'],
        ], $filas)->conCabecera('Cache-Control', 'no-store');
    }

    #[Accion('accesos_revisa,seguridad_admin')]
    public function accesosCsv(Peticion $p): Respuesta
    {
        $this->lecturas->anota('exporta_accesos', 'usuario', null, [], $p->ip());

        return Respuesta::archivo(Csv::de($this->revision->tabla()), 'text/csv; charset=utf-8')
            ->conCabecera('Content-Disposition', 'attachment; filename="revision-accesos-' . date('Y-m-d') . '.csv"');
    }

    #[Accion('accesos_revisa,seguridad_admin', unaVez: true)]
    public function registraRevision(Peticion $p): Respuesta
    {
        $this->revision->registra((string) $p->dato('nota', ''), $this->identidad->id(), $p->ip());

        return $this->hecho($p, $this->sesion, '/seguridad/accesos', 'Revisión registrada.');
    }
}
