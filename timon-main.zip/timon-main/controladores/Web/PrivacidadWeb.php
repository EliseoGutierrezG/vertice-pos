<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Modelos\Parametros;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Errores\Errores;
use Nucleo\Exporta\Xlsx;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Nucleo\Vista;
use Servicios\DerechosTitular;

/** Derechos del titular y aviso de privacidad (docs/seguridad/tratamientos.md). */
#[Modulo('seguridad', 'Seguridad')]
final class PrivacidadWeb extends Controlador
{
    public function __construct(
        private Vista $vista,
        private Sesion $sesion,
        private Identidad $identidad,
        private DerechosTitular $derechos,
        private Parametros $parametros
    ) {
    }

    /** Público: quien va a entrar, y cualquier titular, tiene que poder leerlo. */
    #[Accion(publica: true)]
    public function aviso(Peticion $p): Respuesta
    {
        return Respuesta::html($this->vista->pinta('privacidad/aviso', [
            'titulo' => 'Aviso de privacidad',
            'aprobado' => $this->parametros->entero('aviso_privacidad_aprobado', 0) === 1,
            'responsable' => $this->parametros->valor('privacidad_responsable', 'Por definir'),
            'domicilio' => $this->parametros->valor('privacidad_domicilio', 'Por definir'),
            'contacto' => $this->parametros->valor('privacidad_contacto', 'Por definir'),
        ], 'plantilla/documento'));
    }

    #[Accion('seguridad_admin')]
    public function lista(Peticion $p): Respuesta
    {
        return Respuesta::html($this->vista->pinta('privacidad/lista', [
            'titulo' => 'Privacidad',
            'solicitudes' => $this->derechos->solicitudes(),
            'tipos' => DerechosTitular::TIPOS,
            'titulares' => DerechosTitular::TITULARES,
        ]))->conCabecera('Cache-Control', 'no-store');
    }

    /** Exportar XLS (ficha 44): las columnas de la tabla, sin la de acción. */
    #[Accion('seguridad_admin')]
    public function exportaSolicitudes(Peticion $p): Respuesta
    {
        $hoy = date('Y-m-d');
        return $this->xlsx('Privacidad', [
            ['titulo' => 'Quién'], ['titulo' => 'Derecho'], ['titulo' => 'Titular'], ['titulo' => 'Recibida', 'tipo' => Xlsx::FECHA],
            ['titulo' => 'Vence', 'tipo' => Xlsx::FECHA], ['titulo' => 'Estatus'], ['titulo' => 'Detalle'], ['titulo' => 'Qué se contestó'],
        ], array_map(static fn (array $s): array => [
            $s['solicitante'], DerechosTitular::TIPOS[$s['tipo']] ?? $s['tipo'],
            (DerechosTitular::TITULARES[$s['titular_tipo']] ?? '') . ($s['id_titular'] === null ? '' : ' ' . $s['id_titular']),
            $s['recibida_en'], $s['vence_en'],
            match ($s['estado']) { 'abierta' => $s['vence_en'] < $hoy ? 'Vencida' : 'Abierta', 'atendida' => 'Atendida', default => 'Rechazada' },
            $s['detalle'], $s['resolucion'] ?? '',
        ], $this->derechos->solicitudes()))->conCabecera('Cache-Control', 'no-store');
    }

    /** Ver (ficha 44): la solicitud completa en un modal. */
    #[Accion('seguridad_admin')]
    public function verSolicitud(Peticion $p): Respuesta
    {
        $id = (int) $p->parametro('id', '0');
        return $this->fichaEnModal($p, '/privacidad', $id, function () use ($id): array {
            require_once dirname(__DIR__, 2) . '/vistas/partes/piezas.php';
            foreach ($this->derechos->solicitudes() as $s) {
                if ((int) $s['id'] === $id) {
                    return ['titulo' => 'Solicitud de ' . $s['solicitante'], 'registro' => [], 'html' => $this->vista->suelta('privacidad/solicitud', [
                        'solicitud' => $s, 'tipos' => DerechosTitular::TIPOS, 'titulares' => DerechosTitular::TITULARES,
                    ])];
                }
            }
            throw Errores::noEncontrado('La solicitud no existe');
        });
    }

    #[Accion('seguridad_admin', unaVez: true)]
    public function registra(Peticion $p): Respuesta
    {
        $this->derechos->registra($p->datos(), $this->identidad->id(), $p->ip());

        return $this->hecho($p, $this->sesion, '/privacidad', 'Solicitud registrada.');
    }

    #[Accion('seguridad_admin')]
    public function cierra(Peticion $p): Respuesta
    {
        $this->derechos->cierra(
            (int) $p->parametro('id', '0'),
            (string) $p->dato('estado', ''),
            (string) $p->dato('resolucion', ''),
            $this->identidad->id(),
            $p->ip()
        );

        return $this->hecho($p, $this->sesion, '/privacidad', 'Solicitud cerrada.');
    }

    #[Accion('seguridad_admin')]
    public function exporta(Peticion $p): Respuesta
    {
        $tipo = (string) $p->parametro('tipo', '');
        $id = (int) $p->parametro('id', '0');
        $datos = $this->derechos->exporta($tipo, $id, $this->identidad->id(), $p->ip());
        $json = json_encode($datos, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);

        return Respuesta::archivo($json, 'application/json; charset=utf-8')
            ->conCabecera('Content-Disposition', 'attachment; filename="datos-' . $tipo . '-' . $id . '.json"')
            ->conCabecera('Cache-Control', 'no-store');
    }

    #[Accion('seguridad_admin')]
    public function anonimiza(Peticion $p): Respuesta
    {
        $tipo = (string) $p->parametro('tipo', '');
        $id = (int) $p->parametro('id', '0');
        // No tiene vuelta atrás: se escribe la palabra, no basta con un clic.
        if (trim((string) $p->dato('confirmacion', '')) !== 'ANONIMIZAR') {
            throw Errores::datosInvalidos(['confirmacion' => 'Capture ANONIMIZAR para confirmar. No se puede deshacer']);
        }

        $this->derechos->anonimizaEmpleado($id, $this->identidad->id(), $p->ip());

        return $this->hecho($p, $this->sesion, '/privacidad', 'Datos anonimizados.');
    }
}
