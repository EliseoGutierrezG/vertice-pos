<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Dominio\DatosRestaurante as Datos;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Errores\Errores;
use Nucleo\Exporta\Xlsx;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Vista;
use Servicios\CajaConsulta;
use Servicios\Organizacion;

#[Modulo('caja_consulta', 'Turnos y cortes')]
final class CajaConsultaWeb extends Controlador
{
    private const RUTA = '/caja/turnos';

    public function __construct(
        private Vista $vista,
        private Identidad $identidad,
        private Organizacion $organizacion,
        private CajaConsulta $caja
    ) {
    }

    #[Accion('caja_consulta')]
    public function lista(Peticion $p): Respuesta
    {
        [$desde, $hasta] = $this->periodo($p);
        $opciones = $this->organizacion->opcionesSucursal();
        $sucursal = (int) $p->consulta('sucursal', array_key_first($opciones));
        if ($sucursal > 0 && !isset($opciones[$sucursal])) {
            throw Errores::noEncontrado('Sucursal no disponible');
        }
        $turnos = $sucursal === 0 ? [] : $this->caja->turnos($sucursal, $desde, $hasta);
        return Respuesta::html($this->vista->pinta('restaurante/turnos', [
            'titulo' => 'Turnos y cortes', 'ruta' => self::RUTA,
        ] + compact('desde', 'hasta', 'opciones', 'sucursal', 'turnos')));
    }

    #[Accion('caja_consulta')]
    public function ver(Peticion $p): Respuesta
    {
        $sucursal = $this->sucursal($p);
        $id = (int) $p->parametro('id');
        $corte = $this->caja->corte($sucursal, $id);
        return $this->fichaEnModal($p, self::RUTA, $id, fn (): array => [
            'titulo' => 'Turno #' . $id, 'html' => $this->vista->suelta('restaurante/corte', $corte),
        ], ['sucursal' => $sucursal]);
    }

    #[Accion('caja_consulta')]
    public function exporta(Peticion $p): Respuesta
    {
        [$desde, $hasta] = $this->periodo($p);
        $turnos = $this->caja->turnos($this->sucursal($p), $desde, $hasta);
        return $this->xlsx('Turnos y cortes', [
            ['titulo' => 'Turno', 'tipo' => Xlsx::ENTERO], ['titulo' => 'Apertura', 'tipo' => Xlsx::FECHAHORA],
            ['titulo' => 'Cierre', 'tipo' => Xlsx::FECHAHORA], ['titulo' => 'Cajero'], ['titulo' => 'Fondo', 'tipo' => Xlsx::IMPORTE],
            ['titulo' => 'Esperado', 'tipo' => Xlsx::IMPORTE], ['titulo' => 'Contado', 'tipo' => Xlsx::IMPORTE],
            ['titulo' => 'Diferencia', 'tipo' => Xlsx::IMPORTE],
        ], array_map(static fn (array $t): array => [
            $t['id'], $t['abierto_en'], $t['cerrado_en'], $t['cajero'], $t['fondo'],
            $t['efectivo_esperado'], $t['efectivo_declarado'], $t['diferencia'],
        ], $turnos), $desde, $hasta);
    }

    private function periodo(Peticion $p): array
    {
        $desde = $this->fechaEscrita((string) $p->consulta('desde', date('Y-m-01')), 'desde');
        $hasta = $this->fechaEscrita((string) $p->consulta('hasta', date('Y-m-d')), 'hasta');
        if ($hasta < $desde || (new \DateTimeImmutable($desde))->diff(new \DateTimeImmutable($hasta))->days > 366) {
            throw Errores::datosInvalidos(['hasta' => 'Seleccione un periodo de hasta un año']);
        }
        return [$desde, $hasta];
    }

    private function sucursal(Peticion $p): int
    {
        $id = Datos::entero($p->consulta('sucursal'), 'sucursal', 1, 65535);
        $this->identidad->exigeSucursal($id);
        return $id;
    }
}
