<?php
declare(strict_types=1);

namespace Controladores\Web;

use Controladores\Controlador;
use Nucleo\Atributos\Accion;
use Nucleo\Atributos\Modulo;
use Nucleo\Errores\Errores;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Servicios\MarcaVisual;

/**
 * La hoja de colores y el logotipo de la instalación (2026-11-09, D24).
 *
 * Públicas: las usan Entrar y los tickets públicos, antes de cualquier sesión.
 * No reciben rutas ni nombres de archivo: sirven lo que `MarcaVisual` validó.
 */
#[Modulo('marca_visual', 'Marca visual')]
final class MarcaWeb extends Controlador
{
    private const UN_ANIO = 31536000;

    public function __construct(private MarcaVisual $marca)
    {
    }

    #[Accion(publica: true)]
    public function tema(Peticion $peticion): Respuesta
    {
        $etag = '"' . $this->marca->revision() . '"';
        if ($this->yaLaTiene($peticion, $etag)) {
            return Respuesta::noModificada($etag);
        }

        return $this->conCache(Respuesta::archivo($this->marca->css(), 'text/css; charset=utf-8'), $peticion, $etag);
    }

    #[Accion(publica: true)]
    public function logo(Peticion $peticion): Respuesta
    {
        $logo = $this->marca->logo();
        if ($logo === null) {
            throw Errores::noEncontrado('Sin logotipo propio');
        }

        $etag = '"' . substr($logo['sha256'], 0, 16) . '"';
        if ($this->yaLaTiene($peticion, $etag)) {
            return Respuesta::noModificada($etag);
        }

        $bytes = file_get_contents($logo['ruta']);
        if ($bytes === false) {
            throw Errores::noEncontrado('Sin logotipo propio');
        }

        return $this->conCache(Respuesta::archivo($bytes, $logo['tipo']), $peticion, $etag);
    }

    private function yaLaTiene(Peticion $peticion, string $etag): bool
    {
        $recibido = trim((string) $peticion->cabecera('if-none-match', ''));
        return $recibido !== '' && ($recibido === $etag || $recibido === 'W/' . $etag);
    }

    /**
     * Un año si la dirección trae la revisión vigente; si no, el navegador la
     * guarda pero pregunta cada vez, y el ETag le contesta 304.
     */
    private function conCache(Respuesta $respuesta, Peticion $peticion, string $etag): Respuesta
    {
        $vigente = (string) $peticion->consulta('v', '') === $this->marca->revision();
        return $respuesta
            ->conCabecera('Cache-Control', $vigente ? 'public, max-age=' . self::UN_ANIO . ', immutable' : 'no-cache')
            ->conCabecera('ETag', $etag);
    }
}
