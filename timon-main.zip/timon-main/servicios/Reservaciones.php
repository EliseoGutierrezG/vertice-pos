<?php
declare(strict_types=1);

namespace Servicios;

use DateTimeImmutable;
use Dominio\DatosRestaurante as Datos;
use Modelos\Folios;
use Modelos\IntentosAcceso;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Errores\Errores;
use Nucleo\Instalacion;

final class Reservaciones
{
    public const MINUTOS_ANTES = 30;
    public const MINUTOS_MESA = 90;
    public const ESTADOS = ['solicitada' => 'Solicitada', 'confirmada' => 'Confirmada', 'atendida' => 'Atendida',
        'cancelada' => 'Cancelada', 'ausente' => 'No se presentó'];
    private const SOLICITUDES_POR_VENTANA = 20;

    public function __construct(
        private BaseDatos $bd,
        private Bitacora $bitacora,
        private OperacionRestaurante $operacion,
        private IntentosAcceso $intentos,
        private HorariosRestaurante $horarios,
        private Folios $folios,
        private Instalacion $instalacion
    ) {
    }

    private function claveSucursal(int $sucursal): string
    {
        return (string) ($this->bd->valor('SELECT clave FROM sucursal WHERE id = ?', [$sucursal]) ?: 'S' . $sucursal);
    }

    public function sucursalesPublicas(): array
    {
        $sucursales = $this->bd->filas(
            'SELECT s.id,s.clave,s.nombre,s.calle,s.numero,s.colonia,s.cp,s.telefono,s.horario_publico,
                    s.whatsapp_publico,s.latitud,s.longitud,e.nombre AS estado
             FROM sucursal s LEFT JOIN estado e ON e.id = s.id_estado
             WHERE s.id_estatus = 4 AND s.clave IS NOT NULL ORDER BY s.nombre'
        );
        $ahora = new DateTimeImmutable();
        foreach ($sucursales as &$sucursal) {
            $dias = $this->horarios->de((int) $sucursal['id']);
            $fin = HorariosRestaurante::cierre($dias, $ahora);
            $sucursal['horarios'] = $dias;
            $sucursal['abierta'] = $dias === [] ? null : $fin !== null;
            $sucursal['cierra'] = $fin?->format('H:i');
        }
        return $sucursales;
    }

    public function solicita(array $datos, string $ip): ?string
    {
        if (($datos['sitio_web'] ?? '') !== '') {
            return null;
        }
        $espera = $this->intentos->reintento('reservacion', 'publica', $ip);
        if ($espera > 0) {
            throw Errores::demasiadosIntentos($espera);
        }

        try {
            $clave = Datos::texto($datos['sucursal'] ?? '', 'sucursal', 8);
            $captura = $this->captura($datos);
            return $this->bd->transaccion(function () use ($clave, $captura, $ip): string {
                $sucursal = (int) ($this->bd->valor('SELECT id FROM sucursal WHERE clave = ? AND id_estatus = 4 FOR UPDATE', [$clave])
                    ?? throw Errores::noEncontrado('Sucursal no disponible'));
                $hash = IntentosAcceso::hashDireccion($ip);
                $recientes = (int) $this->bd->valor(
                    'SELECT COUNT(*) FROM reservacion WHERE id_sucursal = ? AND solicitante_hash = ?
                     AND creada_en >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)',
                    [$sucursal, $hash]
                );
                if ($recientes >= self::SOLICITUDES_POR_VENTANA) {
                    throw Errores::demasiadosIntentos(900);
                }
                return $this->inserta($sucursal, $captura, $hash);
            });
        } catch (ErrorHttp $error) {
            if (in_array($error->estado(), [404, 422], true)) {
                $this->intentos->falla('reservacion', 'publica', $ip);
            }
            throw $error;
        }
    }

    public function manual(int $sucursal, array $datos): string
    {
        $captura = $this->captura($datos);
        return $this->bd->transaccion(function () use ($sucursal, $captura): string {
            $this->operacion->bloqueaSucursal($sucursal);
            return $this->inserta($sucursal, $captura, null);
        });
    }

    private function captura(array $datos): array
    {
        $inicio = $this->fecha($datos['desde'] ?? '');
        $fin = $inicio->modify('+' . self::MINUTOS_MESA . ' minutes');
        $cliente = Datos::texto($datos['cliente'] ?? '', 'cliente', 100);
        $telefono = Datos::texto($datos['telefono'] ?? '', 'telefono', 25);
        $personas = Datos::entero($datos['personas'] ?? null, 'personas', 1, 255);
        if ($inicio <= new DateTimeImmutable() || $inicio > new DateTimeImmutable('+180 days')) {
            throw Errores::datosInvalidos(['desde' => 'Seleccione una fecha futura dentro de seis meses']);
        }
        if (!preg_match('/^[+()\d .-]{7,25}$/D', $telefono)) {
            throw Errores::datosInvalidos(['telefono' => 'Capture un teléfono válido']);
        }
        $nota = Datos::texto($datos['nota'] ?? '', 'nota', 240, false);
        return compact('inicio', 'fin', 'cliente', 'telefono', 'personas', 'nota');
    }

    private function inserta(int $sucursal, array $captura, ?string $hash): string
    {
        $dias = $this->horarios->de($sucursal);
        if ($dias !== []) {
            $fin = HorariosRestaurante::cierre($dias, $captura['inicio']);
            if ($fin === null || $captura['fin'] > $fin) {
                throw Errores::datosInvalidos(['desde' => 'Seleccione una hora dentro del servicio']);
            }
        }
        // En el servidor de sucursal, una serie propia: sus folios no chocan
        // con los del central (`RES-CEN-000001`).
        $folio = $this->instalacion->esSucursal()
            ? $this->folios->siguiente('reservaciones:' . $sucursal, 'RES-' . $this->claveSucursal($sucursal), 6)
            : $this->folios->siguiente('reservaciones', 'RES', 6);
        $id = $this->bd->inserta(
            'INSERT INTO reservacion (id_sucursal,cliente,telefono,personas,desde,hasta,folio,nota,solicitante_hash)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$sucursal, $captura['cliente'], $captura['telefono'], $captura['personas'], $captura['inicio']->format('Y-m-d H:i:s'),
                $captura['fin']->format('Y-m-d H:i:s'), $folio, $captura['nota'], $hash]
        );
        if ($hash === null) {
            $this->operacion->registra($sucursal, 'reserva_solicitada', $id, ['folio' => $folio]);
        } else {
            $this->bd->ejecuta("INSERT INTO evento_sucursal (id_sucursal,tipo,entidad) VALUES (?, 'reserva_solicitada', ?)",
                [$sucursal, $id]);
            $this->bitacora->registra('restaurante', 'reserva_solicitada', 'reservacion', $id, despues: ['sucursal' => $sucursal, 'folio' => $folio]);
        }
        return $folio;
    }

    public function agenda(int $sucursal, string $desde, string $hasta = '', string $estado = ''): array
    {
        $this->operacion->consultaSucursal($sucursal);
        $filtros = [];
        $valores = [$sucursal, $desde];
        if ($hasta !== '') {
            $filtros[] = 'r.desde < DATE_ADD(?, INTERVAL 1 DAY)';
            $valores[] = $hasta;
        }
        if ($estado !== '') {
            $filtros[] = 'r.estado = ?';
            $valores[] = $estado;
        }
        return $this->bd->filas(
            'SELECT r.id,r.cliente,r.telefono,r.personas,r.desde,r.hasta,r.estado,r.id_mesa,r.folio,m.numero AS mesa
             FROM reservacion r LEFT JOIN mesa m ON m.id = r.id_mesa
             WHERE r.id_sucursal = ? AND r.desde >= ?' . ($filtros === [] ? '' : ' AND ' . implode(' AND ', $filtros))
            . ' ORDER BY r.desde,r.id LIMIT 200', $valores
        );
    }

    public function detalle(int $sucursal, int $id): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->fila(
            'SELECT r.id,r.cliente,r.telefono,r.personas,r.desde,r.hasta,r.estado,r.id_mesa,r.folio,r.nota,m.numero AS mesa
             FROM reservacion r LEFT JOIN mesa m ON m.id = r.id_mesa WHERE r.id_sucursal = ? AND r.id = ?',
            [$sucursal, $id]
        ) ?? throw Errores::noEncontrado('Reservación no disponible');
    }

    public function cambia(int $sucursal, int $id, array $datos): void
    {
        $estado = Datos::opcion($datos['estado'] ?? '', 'estado', ['confirmada','atendida','cancelada','ausente']);
        $mesa = $estado === 'confirmada' ? Datos::entero($datos['id_mesa'] ?? null, 'id_mesa') : null;
        $this->bd->transaccion(function () use ($sucursal, $id, $estado, $mesa): void {
            $this->operacion->bloqueaSucursal($sucursal);
            $reserva = $this->bd->fila('SELECT id_mesa,personas,desde,hasta,estado FROM reservacion WHERE id = ? AND id_sucursal = ? FOR UPDATE',
                [$id, $sucursal]) ?? throw Errores::noEncontrado('Reservación no disponible');
            $permitido = match ($reserva['estado']) {
                'solicitada' => in_array($estado, ['confirmada','cancelada'], true),
                'confirmada' => in_array($estado, ['confirmada','atendida','cancelada','ausente'], true),
                default => false,
            };
            if (!$permitido) {
                throw Errores::conflicto('La reservación ya cambió');
            }
            if ($estado === 'ausente' && $reserva['desde'] > date('Y-m-d H:i:s')) {
                throw Errores::conflicto('La hora de la reservación aún no llega');
            }
            if ($mesa !== null) {
                $fila = $this->bd->fila('SELECT capacidad,estado FROM mesa WHERE id = ? AND id_sucursal = ? AND activa = 1 FOR UPDATE', [$mesa, $sucursal]);
                if ($fila === null || (int) $fila['capacidad'] < (int) $reserva['personas'] || $fila['estado'] === 'bloqueada') {
                    throw Errores::conflicto('La mesa no tiene capacidad o está bloqueada');
                }
                if ($this->bd->valor(
                    "SELECT id FROM reservacion WHERE id_mesa = ? AND estado = 'confirmada' AND id <> ?
                     AND desde < DATE_ADD(?, INTERVAL ? MINUTE) AND hasta > DATE_SUB(?, INTERVAL ? MINUTE) LIMIT 1",
                    [$mesa, $id, $reserva['hasta'], self::MINUTOS_ANTES, $reserva['desde'], self::MINUTOS_ANTES]
                ) !== null) {
                    throw Errores::conflicto('La mesa ya tiene otra reservación en ese horario');
                }
            }
            $this->bd->ejecuta('UPDATE reservacion SET id_mesa = COALESCE(?, id_mesa), estado = ? WHERE id = ?',
                [$mesa, $estado, $id]);
            $this->operacion->registra($sucursal, 'reserva_' . $estado, $id, ['mesa' => $mesa]);
        });
    }

    public function datosPublicos(int $sucursal, array $datos): void
    {
        $horario = Datos::texto($datos['horario'] ?? '', 'horario', 160, false);
        $whatsapp = Datos::texto($datos['whatsapp'] ?? '', 'whatsapp', 20, false);
        if ($whatsapp !== '' && !preg_match('/^\d{10,15}$/D', $whatsapp)) {
            throw Errores::datosInvalidos(['whatsapp' => 'Use solo dígitos e incluya el código de país']);
        }
        $coordenadas = null;
        if (array_key_exists('latitud', $datos) || array_key_exists('longitud', $datos)) {
            $latitud = $this->coordenada($datos['latitud'] ?? '', 'latitud', 90);
            $longitud = $this->coordenada($datos['longitud'] ?? '', 'longitud', 180);
            if (($latitud === null) !== ($longitud === null)) {
                throw Errores::datosInvalidos(['longitud' => 'Capture ambas coordenadas']);
            }
            $coordenadas = [$latitud, $longitud];
        }
        $cambiaHorario = isset($datos['abre']) || isset($datos['cierra']);
        if ($cambiaHorario && (!is_array($datos['abre'] ?? null) || !is_array($datos['cierra'] ?? null))) {
            throw Errores::datosInvalidos(['abre[1]' => 'Revise los horarios']);
        }
        $this->bd->transaccion(function () use ($sucursal, $horario, $whatsapp, $coordenadas, $cambiaHorario, $datos): void {
            $this->operacion->bloqueaCatalogo($sucursal);
            $this->bd->ejecuta('UPDATE sucursal SET horario_publico = ?, whatsapp_publico = ? WHERE id = ?', [$horario, $whatsapp, $sucursal]);
            if ($coordenadas !== null) {
                $this->bd->ejecuta('UPDATE sucursal SET latitud = ?, longitud = ? WHERE id = ?', [...$coordenadas, $sucursal]);
            }
            if ($cambiaHorario) {
                $this->horarios->guarda($sucursal, $datos['abre'], $datos['cierra']);
            }
            $this->operacion->registra($sucursal, 'sucursal_datos_publicos', $sucursal);
        });
    }

    private function coordenada(mixed $valor, string $campo, int $limite): ?string
    {
        $valor = Datos::texto($valor, $campo, 16, false);
        if ($valor === '') {
            return null;
        }
        if (!preg_match('/^-?\d{1,3}(?:\.\d{1,7})?$/D', $valor) || abs((float) $valor) > $limite) {
            throw Errores::datosInvalidos([$campo => 'Capture una coordenada válida']);
        }
        return $valor;
    }

    public function bloqueaMesa(int $mesa): bool
    {
        return $this->bd->valor(
            "SELECT id FROM reservacion WHERE id_mesa = ? AND estado = 'confirmada'
             AND desde <= DATE_ADD(NOW(), INTERVAL ? MINUTE) AND hasta > NOW() LIMIT 1",
            [$mesa, self::MINUTOS_ANTES]
        ) !== null;
    }

    private function fecha(mixed $valor): DateTimeImmutable
    {
        $texto = Datos::texto($valor, 'desde', 16);
        $fecha = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $texto);
        if ($fecha === false || $fecha->format('Y-m-d\TH:i') !== $texto) {
            throw Errores::datosInvalidos(['desde' => 'Capture la fecha y hora de la reservación']);
        }
        return $fecha;
    }
}
