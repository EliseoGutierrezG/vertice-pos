<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\Totp;
use Modelos\Parametros;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Seguridad\Cifrador;

/**
 * Alta, comprobación y recuperación del segundo factor web.
 *
 * Se enciende y se apaga con el parámetro `segundo_factor_web` (esquema 049).
 * Apagado, nadie lo pide —ni la entrada ni las autorizaciones de otra persona—,
 * pero las altas no se tocan: al volver a encenderlo, cada quien sigue con el
 * código que ya tenía en Authenticator.
 */
final class SegundoFactor
{
    public const PARAMETRO = 'segundo_factor_web';
    private const PUESTOS_SENSIBLES = \Nucleo\Identidad::PUESTOS_SENSIBLES;
    private const ALFABETO_RECUPERACION = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

    public function __construct(
        private BaseDatos $bd,
        private Cifrador $cifrador,
        private Totp $totp,
        private Bitacora $bitacora,
        private Parametros $parametros
    ) {
    }

    /** Si el renglón faltara, se pide: el valor por omisión es el seguro. */
    public function activo(): bool
    {
        // La clave va escrita: la prueba de arquitectura busca quién lee cada parámetro.
        return $this->parametros->entero('segundo_factor_web', 1) !== 0;
    }

    public function requiere(int $idUsuario): bool
    {
        if (!$this->activo()) {
            return false;
        }
        $puesto = $this->bd->valor(
            'SELECT p.clave FROM usuario u JOIN personal pe ON pe.id=u.id_personal JOIN puesto p ON p.id=pe.id_puesto WHERE u.id=?',
            [$idUsuario]
        );
        return is_string($puesto) && in_array($puesto, self::PUESTOS_SENSIBLES, true);
    }

    /**
     * Cuántas personas activas de puestos sensibles hay y cuántas ya tienen
     * Authenticator: al encenderlo, las demás lo darán de alta al entrar.
     *
     * @return array{total:int,configurados:int}
     */
    public function cobertura(): array
    {
        $marcas = implode(', ', array_fill(0, count(self::PUESTOS_SENSIBLES), '?'));
        $fila = $this->bd->fila(
            'SELECT COUNT(*) AS total, COUNT(u.totp_confirmado_en) AS configurados
             FROM usuario u JOIN personal pe ON pe.id = u.id_personal JOIN puesto p ON p.id = pe.id_puesto
             WHERE u.id_estatus = 4 AND p.clave IN (' . $marcas . ')',
            self::PUESTOS_SENSIBLES
        );

        return ['total' => (int) ($fila['total'] ?? 0), 'configurados' => (int) ($fila['configurados'] ?? 0)];
    }

    public function configurado(int $idUsuario): bool
    {
        return $this->bd->valor('SELECT totp_confirmado_en FROM usuario WHERE id=?', [$idUsuario]) !== null;
    }

    /** @return array{secreto:string,uri:string,usuario:string} */
    public function prepara(int $idUsuario, string $ip): array
    {
        return $this->bd->transaccion(function (BaseDatos $bd) use ($idUsuario, $ip): array {
            $usuario = $this->usuarioBloqueado($idUsuario);
            if (!$this->requiere($idUsuario)) {
                throw Errores::conflicto($this->activo() ? 'Este puesto no requiere segundo factor' : 'El segundo factor está apagado');
            }
            if ($usuario['totp_confirmado_en'] !== null) {
                throw Errores::conflicto('El segundo factor ya está configurado');
            }

            $sobre = (string) ($usuario['totp_secreto_cifrado'] ?? '');
            $secreto = $sobre === '' ? $this->totp->generaSecreto() : $this->cifrador->descifra($sobre);
            if ($sobre === '') {
                $bd->ejecuta(
                    'UPDATE usuario SET totp_secreto_cifrado=?, totp_ultimo_periodo=NULL WHERE id=?',
                    [$this->cifrador->cifra($secreto), $idUsuario]
                );
                $this->bitacora->registra(
                    'segundo_factor', 'inicia_configuracion', 'usuario', $idUsuario,
                    despues: ['estado' => 'pendiente'], idUsuario: $idUsuario, ip: $ip
                );
            }

            $nombre = (string) $usuario['usuario'];
            return ['secreto' => $secreto, 'uri' => $this->totp->uri($secreto, $nombre), 'usuario' => $nombre];
        });
    }

    /** Confirma el alta y devuelve códigos que sólo se muestran esta vez. @return list<string> */
    public function confirma(int $idUsuario, string $codigo, string $ip): array
    {
        return $this->bd->transaccion(function (BaseDatos $bd) use ($idUsuario, $codigo, $ip): array {
            $usuario = $this->usuarioBloqueado($idUsuario);
            if ($usuario['totp_confirmado_en'] !== null) {
                throw Errores::conflicto('El segundo factor ya está configurado');
            }
            $sobre = (string) ($usuario['totp_secreto_cifrado'] ?? '');
            if ($sobre === '') {
                throw Errores::conflicto('Primero inicie la configuración del segundo factor');
            }
            $periodo = $this->totp->verifica($this->cifrador->descifra($sobre), trim($codigo));
            if ($periodo === null) {
                throw Errores::datosInvalidos(['codigo' => 'El código no es válido o ya venció']);
            }

            $codigos = [];
            $bd->ejecuta('DELETE FROM totp_codigo_recuperacion WHERE id_usuario=?', [$idUsuario]);
            for ($i = 0; $i < 8; $i++) {
                $enClaro = $this->codigoRecuperacion();
                $codigos[] = $enClaro;
                $bd->ejecuta(
                    'INSERT INTO totp_codigo_recuperacion(id_usuario,codigo_hash) VALUES(?,?)',
                    [$idUsuario, password_hash($this->normalizaRecuperacion($enClaro), PASSWORD_DEFAULT)]
                );
            }
            $bd->ejecuta(
                'UPDATE usuario SET totp_confirmado_en=NOW(), totp_ultimo_periodo=? WHERE id=?',
                [$periodo, $idUsuario]
            );
            $this->bitacora->registra(
                'segundo_factor', 'confirma', 'usuario', $idUsuario,
                despues: ['recuperaciones' => count($codigos)], idUsuario: $idUsuario, ip: $ip
            );
            return $codigos;
        });
    }

    /** Acepta TOTP o un código de recuperación; ambos son de un solo uso. */
    public function valida(int $idUsuario, string $codigo, string $uso, string $ip): void
    {
        $this->bd->transaccion(function (BaseDatos $bd) use ($idUsuario, $codigo, $uso, $ip): void {
            $usuario = $this->usuarioBloqueado($idUsuario);
            if ($usuario['totp_confirmado_en'] === null || (string) ($usuario['totp_secreto_cifrado'] ?? '') === '') {
                throw Errores::conflicto('El segundo factor no está configurado');
            }

            $limpio = trim($codigo);
            $metodo = 'totp';
            if (preg_match('/^\d{6}$/D', $limpio) === 1) {
                $periodo = $this->totp->verifica(
                    $this->cifrador->descifra((string) $usuario['totp_secreto_cifrado']),
                    $limpio
                );
                $ultimo = $usuario['totp_ultimo_periodo'] === null ? null : (int) $usuario['totp_ultimo_periodo'];
                if ($periodo === null || ($ultimo !== null && $periodo <= $ultimo)) {
                    throw Errores::datosInvalidos(['codigo' => 'El código no es válido, venció o ya fue utilizado']);
                }
                $bd->ejecuta('UPDATE usuario SET totp_ultimo_periodo=? WHERE id=?', [$periodo, $idUsuario]);
            } else {
                $metodo = 'recuperacion';
                $normalizado = $this->normalizaRecuperacion($limpio);
                $encontrado = null;
                foreach ($bd->filas(
                    'SELECT id,codigo_hash FROM totp_codigo_recuperacion WHERE id_usuario=? AND usado_en IS NULL FOR UPDATE',
                    [$idUsuario]
                ) as $fila) {
                    if (password_verify($normalizado, (string) $fila['codigo_hash'])) {
                        $encontrado = (int) $fila['id'];
                        break;
                    }
                }
                if ($encontrado === null) {
                    throw Errores::datosInvalidos(['codigo' => 'El código no es válido, venció o ya fue utilizado']);
                }
                $bd->ejecuta('UPDATE totp_codigo_recuperacion SET usado_en=NOW() WHERE id=? AND usado_en IS NULL', [$encontrado]);
            }

            $this->bitacora->registra(
                'segundo_factor', 'valida', 'usuario', $idUsuario,
                despues: ['uso' => $uso, 'metodo' => $metodo], idUsuario: $idUsuario, ip: $ip
            );
        });
    }

    /** Restablece el alta y corta sesiones web y tokens de app. */
    public function restablece(int $idUsuario, int $idActor, string $ip): void
    {
        if ($idUsuario === $idActor) {
            throw Errores::conflicto('No puede restablecer su propio segundo factor');
        }
        $this->bd->transaccion(function (BaseDatos $bd) use ($idUsuario, $idActor, $ip): void {
            $usuario = $this->usuarioBloqueado($idUsuario);
            $antes = ['configurado' => $usuario['totp_confirmado_en'] !== null];
            $bd->ejecuta('DELETE FROM totp_codigo_recuperacion WHERE id_usuario=?', [$idUsuario]);
            $bd->ejecuta(
                'UPDATE usuario SET totp_secreto_cifrado=NULL,totp_confirmado_en=NULL,totp_ultimo_periodo=NULL,sesion_version=sesion_version+1 WHERE id=?',
                [$idUsuario]
            );
            $bd->ejecuta('UPDATE token_acceso SET revocado_en=NOW() WHERE id_usuario=? AND revocado_en IS NULL', [$idUsuario]);
            $this->bitacora->registra(
                'segundo_factor', 'restablece', 'usuario', $idUsuario,
                antes: $antes, despues: ['configurado' => false], idUsuario: $idActor, ip: $ip
            );
        });
    }

    /** @return array<string,mixed> */
    private function usuarioBloqueado(int $idUsuario): array
    {
        $fila = $this->bd->fila(
            'SELECT id,usuario,id_estatus,totp_secreto_cifrado,totp_confirmado_en,totp_ultimo_periodo,sesion_version FROM usuario WHERE id=? FOR UPDATE',
            [$idUsuario]
        );
        if ($fila === null || (int) $fila['id_estatus'] !== 4) {
            throw Errores::noEncontrado('El usuario no existe o no está activo');
        }
        return $fila;
    }

    private function codigoRecuperacion(): string
    {
        $salida = '';
        $tope = strlen(self::ALFABETO_RECUPERACION) - 1;
        for ($i = 0; $i < 12; $i++) {
            $salida .= self::ALFABETO_RECUPERACION[random_int(0, $tope)];
        }
        return substr($salida, 0, 4) . '-' . substr($salida, 4, 4) . '-' . substr($salida, 8, 4);
    }

    private function normalizaRecuperacion(string $codigo): string
    {
        return strtoupper((string) preg_replace('/[^A-Z0-9]/i', '', $codigo));
    }
}

