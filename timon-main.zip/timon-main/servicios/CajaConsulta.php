<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;

final class CajaConsulta
{
    public function __construct(
        private BaseDatos $bd,
        private OperacionRestaurante $operacion,
        private CajaRestaurante $caja
    ) {
    }

    public function turnos(int $sucursal, string $desde, string $hasta): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->filas(
            "SELECT t.id,t.abierto_en,t.cerrado_en,t.fondo,t.efectivo_esperado,t.efectivo_declarado,
                    t.efectivo_declarado - t.efectivo_esperado AS diferencia,
                    COALESCE(CONCAT_WS(' ', p.nombre, p.apellido_paterno), u.usuario) AS cajero
             FROM turno_caja t JOIN usuario u ON u.id = t.id_cajero JOIN personal p ON p.id = u.id_personal
             WHERE t.id_sucursal = ? AND t.abierto_en >= ? AND t.abierto_en < DATE_ADD(?, INTERVAL 1 DAY)
             ORDER BY t.abierto_en DESC, t.id DESC",
            [$sucursal, $desde, $hasta]
        );
    }

    public function corte(int $sucursal, int $id): array
    {
        return $this->bd->transaccion(function () use ($sucursal, $id): array {
            $turno = $this->bd->fila(
                "SELECT t.id,t.abierto_en,t.cerrado_en,t.fondo,t.efectivo_esperado,t.efectivo_declarado,
                        t.efectivo_declarado - t.efectivo_esperado AS diferencia,
                        COALESCE(CONCAT_WS(' ', p.nombre, p.apellido_paterno), u.usuario) AS cajero
                 FROM turno_caja t JOIN usuario u ON u.id = t.id_cajero JOIN personal p ON p.id = u.id_personal
                 WHERE t.id_sucursal = ? AND t.id = ?",
                [$sucursal, $id]
            ) ?? throw Errores::noEncontrado('Turno no disponible');
            $resumen = $this->caja->resumenTurno($sucursal, $id);
            $movimientos = $this->bd->filas(
                "SELECT a.creado_en,a.concepto,a.importe,CONCAT_WS(' ', p.nombre, p.apellido_paterno) AS quien
                 FROM asiento_caja a JOIN usuario u ON u.id = a.id_usuario JOIN personal p ON p.id = u.id_personal
                 WHERE a.id_turno = ? ORDER BY a.creado_en DESC, a.id DESC",
                [$id]
            );
            return compact('turno', 'resumen', 'movimientos');
        });
    }
}
