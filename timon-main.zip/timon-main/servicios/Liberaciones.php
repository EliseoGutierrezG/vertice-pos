<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;
use Nucleo\Seguridad\FirmaLiberacion;
use RuntimeException;

/**
 * Los paquetes del sistema que el central ofrece a las computadoras de
 * sucursal (`docs/servidor-sucursal.md`, «Actualizaciones»).
 *
 * El central solo guarda y reparte: registra un paquete si su firma es buena
 * con la llave pública del código, y anota a qué versión debe llegar cada
 * computadora. Quien instala es la computadora (`guiones/actualiza.php`), que
 * vuelve a comprobar la firma con la llave que ya tiene.
 */
final class Liberaciones
{
    public function __construct(
        private BaseDatos $bd,
        private Bitacora $bitacora,
        private Identidad $identidad,
        private string $carpeta,
        private ?string $llavePublica
    ) {
    }

    /**
     * Registra un paquete firmado. Copia el archivo a la carpeta de paquetes
     * (fuera de `publico/`) y anota su descriptor. Repetirlo con el mismo
     * paquete no hace nada.
     *
     * @param array<string,mixed> $descriptor
     */
    public function registra(string $paquete, array $descriptor, string $notas = ''): string
    {
        if ($this->llavePublica === null) {
            throw Errores::conflicto('Falta la llave pública de firma en el código.');
        }
        try {
            FirmaLiberacion::verificaPaquete($descriptor, $paquete, $this->llavePublica);
        } catch (RuntimeException $e) {
            throw Errores::datosInvalidos(['paquete' => $e->getMessage()]);
        }
        $id = (string) $descriptor['id'];
        $existente = $this->bd->fila('SELECT id, sha256 FROM liberacion WHERE id = ? OR sha256 = ?', [$id, $descriptor['sha256']]);
        if ($existente !== null) {
            if ($existente['id'] === $id && $existente['sha256'] === $descriptor['sha256']) {
                return $id;
            }
            throw Errores::conflicto('Ya hay otra versión con ese nombre o ese paquete.');
        }
        $notas = trim($notas);
        if (mb_strlen($notas) > 300) {
            throw Errores::datosInvalidos(['notas' => 'Capture hasta 300 letras']);
        }
        if (!is_dir($this->carpeta) && !mkdir($this->carpeta, 0770, true) && !is_dir($this->carpeta)) {
            throw new RuntimeException('No se pudo crear la carpeta de paquetes');
        }
        $destino = $this->ruta($id);
        $temporal = $destino . '.tmp-' . bin2hex(random_bytes(4));
        if (!copy($paquete, $temporal) || !rename($temporal, $destino)) {
            @unlink($temporal);
            throw new RuntimeException('No se pudo guardar el paquete');
        }

        $this->bd->ejecuta('INSERT INTO liberacion (id, esquema, sha256, firma, peso, notas, creada_por) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$id, $descriptor['esquema'], $descriptor['sha256'], $descriptor['firma'], $descriptor['peso'], $notas, $this->identidad->id()]);
        $this->bitacora->registra('replica', 'registra_liberacion', 'liberacion', null,
            despues: ['id' => $id, 'esquema' => $descriptor['esquema'], 'sha256' => $descriptor['sha256']], idUsuario: $this->identidad->id());

        return $id;
    }

    /**
     * La versión que debe tener esa computadora. Null es quedarse como está.
     */
    public function asigna(int $instalacion, ?string $liberacion): void
    {
        $this->bd->transaccion(function () use ($instalacion, $liberacion): void {
            $antes = $this->bd->fila('SELECT liberacion_asignada FROM instalacion WHERE id = ? AND activa = 1 FOR UPDATE', [$instalacion]);
            if ($antes === null) {
                throw Errores::noEncontrado();
            }
            if ($liberacion !== null && $this->bd->valor('SELECT id FROM liberacion WHERE id = ?', [$liberacion]) === null) {
                throw Errores::datosInvalidos(['liberacion' => 'Seleccione una versión registrada']);
            }
            $this->bd->ejecuta('UPDATE instalacion SET liberacion_asignada = ? WHERE id = ?', [$liberacion, $instalacion]);
            $this->bitacora->registra('replica', 'asigna_liberacion', 'instalacion', $instalacion,
                antes: ['liberacion' => $antes['liberacion_asignada']], despues: ['liberacion' => $liberacion], idUsuario: $this->identidad->id());
        });
    }

    /**
     * El descriptor firmado de la versión asignada a esa computadora, o null.
     *
     * @return array{id:string,esquema:int,sha256:string,peso:int,firma:string}|null
     */
    public function asignada(int $instalacion): ?array
    {
        $fila = $this->bd->fila(
            'SELECT l.id, l.esquema, l.sha256, l.peso, l.firma FROM instalacion i
               JOIN liberacion l ON l.id = i.liberacion_asignada
              WHERE i.id = ? AND i.activa = 1', [$instalacion]);

        return $fila === null ? null : [
            'id' => (string) $fila['id'], 'esquema' => (int) $fila['esquema'], 'sha256' => (string) $fila['sha256'],
            'peso' => (int) $fila['peso'], 'firma' => (string) $fila['firma'],
        ];
    }

    /**
     * El archivo del paquete, solo si es el asignado a esa computadora: una
     * llave de sucursal no sirve para bajar cualquier versión.
     */
    public function paqueteDe(int $instalacion, string $liberacion): string
    {
        $asignada = $this->asignada($instalacion);
        if ($asignada === null || $asignada['id'] !== $liberacion || !is_file($this->ruta($liberacion))) {
            throw Errores::noEncontrado('Esa versión no está asignada a esta computadora');
        }

        return $this->ruta($liberacion);
    }

    /** Lo que reporta el actualizador de la computadora. */
    public function anota(int $instalacion, string $estado, bool $error, bool $aplicada = false): void
    {
        $estado = mb_substr(trim($estado), 0, 200);
        $this->bd->transaccion(function () use ($instalacion, $estado, $error, $aplicada): void {
            $antes = $this->bd->fila('SELECT actualizacion, actualizacion_error FROM instalacion WHERE id = ? FOR UPDATE', [$instalacion]);
            if ($antes === null || (!$aplicada && $antes['actualizacion'] === $estado && (bool) $antes['actualizacion_error'] === $error)) {
                return;
            }
            $this->bd->ejecuta(
                'UPDATE instalacion SET actualizacion = ?, actualizacion_error = ?' . ($aplicada ? ', actualizada_en = NOW()' : '') . ' WHERE id = ?',
                [$estado, $error ? 1 : 0, $instalacion]);
            $this->bitacora->registra('replica', 'actualizacion', 'instalacion', $instalacion,
                antes: $antes, despues: ['actualizacion' => $estado, 'actualizacion_error' => $error, 'aplicada' => $aplicada]);
        });
    }

    /** @return list<array<string,mixed>> */
    public function lista(): array
    {
        return $this->bd->filas(
            'SELECT l.id, l.esquema, l.peso, l.notas, l.creada_en,
                    (SELECT COUNT(*) FROM instalacion i WHERE i.activa = 1 AND i.liberacion_asignada = l.id) AS asignada_a,
                    (SELECT COUNT(*) FROM instalacion i WHERE i.activa = 1 AND i.version = l.id) AS instalada_en
               FROM liberacion l ORDER BY l.creada_en DESC, l.id DESC');
    }

    private function ruta(string $id): string
    {
        // El id ya pasó por `FirmaLiberacion::exigeForma`: no trae diagonales.
        return rtrim($this->carpeta, '/') . '/' . str_replace(':', '_', $id) . '.tar.gz';
    }
}
