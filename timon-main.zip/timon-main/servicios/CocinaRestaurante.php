<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;

final class CocinaRestaurante
{
    public function __construct(
        private BaseDatos $bd,
        private OperacionRestaurante $operacion,
        private ImpresionRestaurante $impresion
    ) {
    }

    public function lista(int $sucursal, string $modo): array
    {
        $this->operacion->consultaSucursal($sucursal);
        // Antes que las comandas: un avance que entre en medio vuelve a llegar por `/cambios`.
        $cursor = (int) $this->bd->valor('SELECT COALESCE(MAX(id), 0) FROM evento_sucursal WHERE id_sucursal = ?', [$sucursal]);
        $items = $this->bd->filas(
            "SELECT i.id,i.id_ronda,i.platillo,i.cantidad,i.nota,i.modificadores,i.tiempo,i.asiento,
                    i.preparacion,i.estado,r.enviada_en,TIMESTAMPDIFF(SECOND, r.enviada_en, NOW()) AS segundos,
                    c.tipo,COALESCE(m.numero, CONCAT('#', c.id)) AS origen
             FROM cuenta c JOIN cuenta_item i ON i.id_cuenta = c.id
             JOIN ronda r ON r.id = i.id_ronda LEFT JOIN cuenta madre ON madre.id = c.id_cuenta_madre
             LEFT JOIN mesa m ON m.id = COALESCE(c.id_mesa, madre.id_mesa)
             WHERE c.id_sucursal = ? AND (c.abierta = 1 OR c.estado = 'pagada') AND i.estado IN ('enviado','en_preparacion','listo')
               AND ((? = 'barra' AND i.preparacion = 'barra') OR (? = 'cocina' AND i.preparacion IN ('caliente','fria')))
             ORDER BY r.id, i.preparacion, i.id", [$sucursal, $modo, $modo]
        );
        foreach ($items as &$item) {
            $item['modificadores'] = json_decode($item['modificadores'], true, flags: JSON_THROW_ON_ERROR);
        }
        return ['cursor' => $cursor, 'items' => $items, 'impresiones_demoradas' => $this->impresion->demora($sucursal)];
    }

    public function avanza(int $sucursal, string $modo, int $ronda, string $area, string $accion, string $llave): array
    {
        if (($modo === 'barra') !== ($area === 'barra')) {
            throw Errores::prohibido('Esta comanda corresponde a otra área');
        }
        [$antes, $estado] = match ($accion) {
            'preparar' => ['enviado','en_preparacion'],
            'listo' => ['en_preparacion','listo'],
            'retomar' => ['listo','en_preparacion'],
            'despachar' => ['listo','entregado'],
            default => throw Errores::noEncontrado(),
        };
        return $this->operacion->unaVez($sucursal, $llave, 'cocina_avance', [$ronda, $area, $accion],
            function () use ($sucursal, $ronda, $area, $antes, $estado): array {
                $cuenta = $this->bd->valor(
                    "SELECT c.id FROM ronda r JOIN cuenta c ON c.id = r.id_cuenta
                     WHERE r.id = ? AND c.id_sucursal = ? AND (c.abierta = 1 OR c.estado = 'pagada') FOR UPDATE",
                    [$ronda, $sucursal]
                ) ?? throw Errores::noEncontrado('La comanda ya no está abierta');
                if ($this->bd->ejecuta(
                    "UPDATE cuenta_item SET estado = ?, estado_en = NOW(),
                     preparado_en = IF(? = 'en_preparacion', COALESCE(preparado_en, NOW()), preparado_en),
                     listo_en = CASE ? WHEN 'listo' THEN NOW() WHEN 'en_preparacion' THEN NULL ELSE listo_en END
                     WHERE id_ronda = ? AND preparacion = ? AND estado = ?",
                    [$estado, $estado, $estado, $ronda, $area, $antes]
                ) === 0) {
                    throw Errores::conflicto('La comanda ya cambió');
                }
                // Cocina no toca la versión de la cuenta: su candado es el estado
                // del platillo. Subirla hacía chocar lo que el mesero capturaba.
                $this->operacion->registra($sucursal, 'cocina_avance', $ronda,
                    ['cuenta' => $cuenta, 'area' => $area, 'estado' => $estado], (int) $cuenta);
                return ['id' => $ronda, 'estado' => $estado];
            }
        );
    }
}
