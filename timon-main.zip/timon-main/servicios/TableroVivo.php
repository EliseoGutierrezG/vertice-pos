<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;
use Nucleo\Giro;
use Nucleo\Identidad;

/**
 * Los números del tablero de la capa base.
 *
 * Cuenta lo que el panel puede atender hoy: sucursales activas, personal
 * activo, equipos esperando autorización y bloqueos de acceso del día. Cada
 * fase del giro agrega aquí sus fichas (mesas ocupadas, ventas del día,
 * comandas atrasadas) siempre dentro del alcance de sucursal de quien mira.
 */
final class TableroVivo
{
    public function __construct(private BaseDatos $bd, private Identidad $identidad)
    {
    }

    /** @return array{sucursales:int,personal:int,equipos_pendientes:int,bloqueos:int,actualizado_en:string} */
    public function resumen(): array
    {
        [$filtro, $params] = $this->alcance('p.id_sucursal');
        [$filtroS, $paramsS] = $this->alcance('s.id');

        return [
            'sucursales' => (int) $this->bd->valor('SELECT COUNT(*) FROM sucursal s WHERE s.id_estatus = 4' . $filtroS, $paramsS),
            'personal'   => (int) $this->bd->valor('SELECT COUNT(*) FROM personal p WHERE p.id_estatus = 4' . $filtro, $params),
            'equipos_pendientes' => Giro::activo('restaurante') ? $this->equiposComanda() : (int) $this->bd->valor(
                'SELECT COUNT(*) FROM dispositivo d
                 JOIN usuario u ON u.id = d.id_usuario AND u.id_estatus = 4
                 JOIN personal p ON p.id = u.id_personal AND p.id_estatus = 4
                 JOIN puesto pu ON pu.id = p.id_puesto AND pu.usa_app = 1
                 WHERE d.autorizado = 0' . $filtro,
                $params
            ),
            'bloqueos' => $this->identidad->esAdministrador()
                ? (int) $this->bd->valor('SELECT COUNT(*) FROM intento_acceso WHERE bloqueado_hasta > NOW()')
                : 0,
            'actualizado_en' => date('Y-m-d H:i:s'),
        ];
    }

    private function equiposComanda(): int
    {
        if (!$this->identidad->puede('equipo_admin')) {
            return 0;
        }
        return (int) $this->bd->valor(
            'SELECT COUNT(*) FROM equipo WHERE id_sucursal IS NULL
             AND creado_en >= DATE_SUB(NOW(), INTERVAL 1 DAY)'
        );
    }

    /** @return array{0:string,1:list<int>} */
    private function alcance(string $columna): array
    {
        if ($this->identidad->esAdministrador()) {
            return ['', []];
        }

        $sucursales = $this->identidad->sucursales();
        if ($sucursales === []) {
            return [' AND 1 = 0', []];
        }

        return [' AND ' . $columna . ' IN (' . implode(',', array_fill(0, count($sucursales), '?')) . ')', $sucursales];
    }
}
