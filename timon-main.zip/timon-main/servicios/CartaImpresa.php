<?php
declare(strict_types=1);

namespace Servicios;

use DateTimeImmutable;
use Dominio\Dinero;
use Dominio\Promocion;
use Modelos\Parametros;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Giro;
use Nucleo\Identidad;

/**
 * La carta impresa de una sucursal, armada con lo que se captura en el panel:
 * categorías con su leyenda, platillos en su orden con porción, precio y la
 * línea de preparaciones (sus modificadores), las promociones que no han
 * vencido y los textos del pie.
 *
 * La misma lectura alimenta la vista previa del panel, la hoja para imprimir
 * y la huella con la que la vista previa sabe que hay algo nuevo.
 */
final class CartaImpresa
{
    /** Los textos del pie, con el parámetro que los guarda. */
    public const TEXTOS = [
        'carta_fundacion' => 'Año de fundación',
        'carta_sello' => 'Frase del encabezado',
        'carta_lema' => 'Lema',
        'carta_advertencia' => 'Advertencia sanitaria',
        'carta_pagos' => 'Formas de pago',
    ];

    public function __construct(
        private BaseDatos $bd,
        private Promociones $promociones,
        private Parametros $parametros,
        private Bitacora $bitacora,
        private Identidad $identidad
    ) {
    }

    public function arma(int $sucursal, bool $conPromociones = true): array
    {
        $this->identidad->exigeSucursal($sucursal);
        $datos = $this->bd->fila(
            'SELECT s.id, s.nombre, s.clave, s.telefono, s.whatsapp_publico, s.calle, s.numero, s.colonia, s.cp, e.nombre AS estado
             FROM sucursal s LEFT JOIN estado e ON e.id = s.id_estado WHERE s.id = ? AND s.id_estatus = 4',
            [$sucursal]
        ) ?? throw Errores::noEncontrado('Sucursal no disponible');

        $platillos = $this->bd->filas(
            'SELECT p.id, p.nombre, p.porcion, p.descripcion, p.especialidad, ps.precio, ps.agotado,
                    c.id AS id_categoria, c.nombre AS categoria, c.descripcion AS leyenda
             FROM platillo p JOIN categoria_menu c ON c.id = p.id_categoria
             JOIN platillo_sucursal ps ON ps.id_platillo = p.id AND ps.id_sucursal = ?
             WHERE p.activo = 1 AND c.activa = 1
             ORDER BY c.orden, c.nombre, p.orden, p.nombre, p.id',
            [$sucursal]
        );
        $modificadores = [];
        foreach ($this->bd->filas(
            'SELECT m.id, m.id_platillo, m.nombre, m.suplemento FROM modificador_platillo m
             JOIN platillo_sucursal ps ON ps.id_platillo = m.id_platillo AND ps.id_sucursal = ?
             WHERE m.activo = 1 ORDER BY m.id',
            [$sucursal]
        ) as $m) {
            $modificadores[(int) $m['id_platillo']][] = $m;
        }

        $ahora = new DateTimeImmutable();
        $promos = $conPromociones ? $this->promociones->vigentesOProgramadas($sucursal, $ahora) : [];
        $porPlatillo = [];
        foreach ($promos as $p) {
            foreach ($p['ids_platillos'] as $id) {
                $porPlatillo[$id][] = $p;
            }
        }

        $categorias = [];
        $nombres = [];
        foreach ($platillos as $pl) {
            $id = (int) $pl['id'];
            $nombres[$id] = $pl['nombre'];
            $clave = (int) $pl['id_categoria'];
            $categorias[$clave] ??= ['nombre' => $pl['categoria'], 'leyenda' => $pl['leyenda'], 'platillos' => []];
            $promo = Promociones::mejor($porPlatillo[$id] ?? [], Dinero::deCadena($pl['precio']), Dinero::cero());
            $categorias[$clave]['platillos'][] = [
                'nombre' => $pl['nombre'], 'porcion' => $pl['porcion'], 'descripcion' => $pl['descripcion'],
                'precio' => $pl['precio'], 'especialidad' => (int) $pl['especialidad'] === 1,
                'preparaciones' => self::preparaciones($modificadores[$id] ?? []),
                'promocion' => MenuRestaurante::promocionPublica($promo, $pl['precio']),
            ];
        }

        $anuncios = [];
        foreach ($promos as $p) {
            $incluidos = array_values(array_filter(array_map(static fn (int $id): ?string => $nombres[$id] ?? null, $p['ids_platillos'])));
            if ($incluidos === []) {
                continue;
            }
            $anuncios[] = ['nombre' => $p['nombre'], 'etiqueta' => Promocion::etiqueta($p), 'horario' => Promocion::horario($p),
                'platillos' => $incluidos, 'vigente' => Promocion::vigente($p, $ahora),
                'hasta' => $p['hasta']];
        }

        return [
            'sucursal' => $datos,
            'direccion' => self::direccion($datos),
            'categorias' => array_values($categorias),
            'promociones' => $anuncios,
            'textos' => $this->textos(),
            'redes' => array_map(static fn (array $r): array => $r + ['usuario' => self::usuarioRed($r['url'])], Giro::redes()),
        ];
    }

    /** Cambia cuando cambia cualquier cosa que sale en la hoja. */
    public function huella(int $sucursal, bool $conPromociones = true): string
    {
        return substr(hash('sha256', json_encode($this->arma($sucursal, $conPromociones), JSON_THROW_ON_ERROR)), 0, 24);
    }

    /** @return array<string,string> */
    public function textos(): array
    {
        return [
            'carta_fundacion' => $this->parametros->valor('carta_fundacion'),
            'carta_sello' => $this->parametros->valor('carta_sello'),
            'carta_lema' => $this->parametros->valor('carta_lema'),
            'carta_advertencia' => $this->parametros->valor('carta_advertencia'),
            'carta_pagos' => $this->parametros->valor('carta_pagos'),
        ];
    }

    /** Guarda los textos del pie. Vigentes desde hoy; lo anterior queda en su historia. */
    public function guardaTextos(array $datos): void
    {
        $antes = $this->textos();
        $nuevos = [];
        foreach (self::TEXTOS as $clave => $nombre) {
            $valor = trim((string) ($datos[$clave] ?? ''));
            if (mb_strlen($valor) > 255) {
                throw Errores::datosInvalidos([$clave => 'Capture hasta 255 caracteres']);
            }
            if ($clave === 'carta_fundacion' && $valor !== '' && !preg_match('/^(19|20)\d{2}$/D', $valor)) {
                throw Errores::datosInvalidos([$clave => 'Capture un año de cuatro cifras']);
            }
            $nuevos[$clave] = $valor;
        }
        foreach ($nuevos as $clave => $valor) {
            if ($valor !== $antes[$clave]) {
                $this->parametros->cambia($clave, $valor, date('Y-m-d'));
            }
        }
        $this->bitacora->registra('restaurante', 'carta_textos', 'parametro', null, antes: $antes, despues: $nuevos,
            idUsuario: $this->identidad->id());
    }

    /** «Frita + mojo + ajillo», con «+$20» cuando el modificador cuesta. */
    public static function preparaciones(array $modificadores): string
    {
        // En el orden en que se capturaron: así los acomoda quien arma la carta.
        usort($modificadores, static fn (array $a, array $b): int => (int) ($a['id'] ?? 0) <=> (int) ($b['id'] ?? 0));
        $linea = implode(' + ', array_map(static function (array $m): string {
            $suplemento = Dinero::deCadena((string) $m['suplemento']);
            $nombre = mb_strtolower(mb_substr($m['nombre'], 0, 1)) . mb_substr($m['nombre'], 1);
            return $nombre . ($suplemento->esCero() ? '' : ' +$' . rtrim(rtrim($suplemento->aPesos(), '0'), '.'));
        }, $modificadores));
        return mb_strtoupper(mb_substr($linea, 0, 1)) . mb_substr($linea, 1);
    }

    private static function direccion(array $s): string
    {
        $calle = trim(implode(' ', array_filter([$s['calle'] ?? '', $s['numero'] ?? ''])));
        return implode(', ', array_filter([$calle, $s['colonia'] ?? '', trim(($s['cp'] ?? '') . ' ' . ($s['estado'] ?? ''))]));
    }

    private static function usuarioRed(string $url): string
    {
        $ruta = trim((string) parse_url($url, PHP_URL_PATH), '/');
        $primero = explode('/', $ruta)[0] ?? '';
        return $primero === '' ? '' : '@' . ltrim($primero, '@');
    }
}
