<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;

/**
 * El sello diario de la bitácora: alterarla deja de pasar inadvertido.
 *
 * La bitácora vive en la misma base que todo lo demás, así que quien pueda
 * escribir ahí podría borrar su rastro. Cada tramo de renglones de días
 * cerrados recibe un HMAC con una llave que **no** está en la base, encadenado
 * con el tramo anterior: quitar, cambiar o agregar un renglón, o quitar un tramo
 * entero, deja una huella que no cuadra.
 *
 * Por tramos y no renglón por renglón para no serializar las escrituras de todo
 * el sistema en una cadena. Esto **detecta**; no impide. Quien tenga la llave y
 * la base puede rehacerlo todo, por eso la llave se guarda aparte.
 */
final class SelloBitacora
{
    private const TANDA = 2000;

    public function __construct(private BaseDatos $bd, private string $llave)
    {
    }

    /** Sella lo pendiente de días ya cerrados. Devuelve cuántos renglones. */
    public function sella(?string $hoy = null): int
    {
        $hoy ??= date('Y-m-d');
        $ultimo = $this->bd->fila('SELECT hasta_id, huella FROM bitacora_sello ORDER BY hasta_id DESC LIMIT 1');
        $desde = $ultimo === null ? 0 : (int) $ultimo['hasta_id'];
        $hasta = (int) $this->bd->valor('SELECT COALESCE(MAX(id), 0) FROM bitacora WHERE momento < ?', [$hoy . ' 00:00:00']);

        if ($hasta <= $desde) {
            return 0;
        }

        $anterior = $ultimo === null ? null : (string) $ultimo['huella'];
        [$huella, $renglones] = $this->huella($desde + 1, $hasta, $anterior);

        $this->bd->ejecuta(
            'INSERT INTO bitacora_sello (desde_id, hasta_id, renglones, huella, huella_anterior) VALUES (?, ?, ?, ?, ?)',
            [$desde + 1, $hasta, $renglones, $huella, $anterior]
        );

        return $renglones;
    }

    /**
     * Rehace todos los sellos y dice qué no cuadra. Vacío: todo en orden.
     *
     * @return list<string>
     */
    public function verifica(): array
    {
        $problemas = [];
        $anterior = null;
        $siguiente = null;

        foreach ($this->bd->filas('SELECT * FROM bitacora_sello ORDER BY hasta_id') as $sello) {
            $desde = (int) $sello['desde_id'];
            $hasta = (int) $sello['hasta_id'];
            $tramo = "tramo $desde a $hasta";
            $guardadaAntes = $sello['huella_anterior'] === null ? null : (string) $sello['huella_anterior'];

            if ($siguiente !== null && $desde !== $siguiente) {
                $problemas[] = "Falta un tramo antes del $tramo";
            }
            if ($guardadaAntes !== $anterior) {
                $problemas[] = "La cadena se rompe en el $tramo";
            }

            [$huella, $renglones] = $this->huella($desde, $hasta, $guardadaAntes);
            if ($renglones !== (int) $sello['renglones']) {
                $problemas[] = "El $tramo tenía {$sello['renglones']} renglones y ahora tiene $renglones";
            } elseif (!hash_equals((string) $sello['huella'], $huella)) {
                $problemas[] = "Se alteró un renglón del $tramo";
            }

            $anterior = (string) $sello['huella'];
            $siguiente = $hasta + 1;
        }

        return $problemas;
    }

    /** @return array{0:string,1:int} */
    private function huella(int $desde, int $hasta, ?string $anterior): array
    {
        $contexto = hash_init('sha256', HASH_HMAC, $this->llave);
        hash_update($contexto, $anterior ?? '');
        $renglones = 0;
        $cursor = $desde - 1;

        do {
            $filas = $this->bd->filas(
                'SELECT id, id_usuario, momento, modulo, accion, entidad, id_entidad, antes, despues, ip,
                        canal, operacion, ruta, accion_ruta, id_dispositivo, correlacion_hash
                 FROM bitacora WHERE id > ? AND id <= ? ORDER BY id LIMIT ' . self::TANDA,
                [$cursor, $hasta]
            );

            foreach ($filas as $fila) {
                hash_update($contexto, (string) json_encode(array_values($fila), JSON_UNESCAPED_UNICODE) . "\n");
                $cursor = (int) $fila['id'];
                $renglones++;
            }
        } while (count($filas) === self::TANDA);

        return [hash_final($contexto), $renglones];
    }
}
