<?php
declare(strict_types=1);

namespace Servicios;

use RuntimeException;

/** Metadatos públicos del binario; viajan dentro de la liberación firmada. */
final class AppMovil
{
    public static function datos(string $raiz): array
    {
        $ruta = $raiz . '/config/app-movil.php';
        $datos = is_file($ruta) ? require $ruta : ['version' => '1.0.0', 'minima' => '1.0.0'];
        foreach (['version', 'minima'] as $campo) {
            if (!is_string($datos[$campo] ?? null) || preg_match('/^\d+\.\d+\.\d+$/D', $datos[$campo]) !== 1) {
                throw new RuntimeException('La versión de la app no es válida');
            }
        }
        if (version_compare($datos['minima'], $datos['version'], '>')) {
            throw new RuntimeException('La versión mínima supera a la disponible');
        }
        return ['app_minima' => $datos['minima'], 'app_version' => $datos['version'],
            'apk' => is_file($raiz . '/movil/comanda.apk') ? '/api/v1/app/apk' : null];
    }
}
