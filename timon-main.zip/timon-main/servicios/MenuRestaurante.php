<?php
declare(strict_types=1);

namespace Servicios;

use DateTimeImmutable;
use Dominio\DatosRestaurante as Datos;
use Dominio\Dinero;
use Dominio\Promocion;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;

final class MenuRestaurante
{
    public const AREAS = ['caliente' => 'Cocina caliente', 'fria' => 'Cocina fría', 'barra' => 'Barra'];

    public function __construct(
        private BaseDatos $bd,
        private OperacionRestaurante $operacion,
        private Bitacora $bitacora,
        private Identidad $identidad,
        private Promociones $promociones
    ) {
    }

    public function carta(int $sucursal): array
    {
        return $this->leeCarta($sucursal, false);
    }

    /** La carta con su huella, para que el equipo sólo la baje cuando cambió. */
    public function cartaConHuella(int $sucursal): array
    {
        $platillos = $this->leeCarta($sucursal, false);
        return [
            'huella' => '"' . substr(hash('sha256', json_encode($platillos, JSON_THROW_ON_ERROR)), 0, 32) . '"',
            'platillos' => $platillos,
        ];
    }

    public function publica(string $clave): array
    {
        $sucursal = $this->bd->fila(
            'SELECT id, clave, nombre FROM sucursal WHERE clave = ? AND id_estatus = 4', [$clave]
        ) ?? throw Errores::noEncontrado('No encontramos el menú de esa sucursal');
        return ['sucursal' => $sucursal, 'platillos' => $this->leeCarta((int) $sucursal['id'], false)];
    }

    /** El número de la mesa del código QR, solo si es de esa sucursal y sigue activa. */
    public function mesaPublica(int $sucursal, int $mesa): ?string
    {
        if ($mesa <= 0) {
            return null;
        }
        $numero = $this->bd->valor('SELECT numero FROM mesa WHERE id_sucursal = ? AND id = ? AND activa = 1', [$sucursal, $mesa]);
        return $numero === null ? null : (string) $numero;
    }

    public function administracion(int $sucursal): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return [
            'categorias' => $this->categorias(),
            'platillos' => $this->leeCarta($sucursal, true, modificadores: false),
        ];
    }

    public function categorias(?int $id = null): array
    {
        return $this->bd->filas('SELECT id,nombre,orden,descripcion FROM categoria_menu WHERE activa = 1'
            . ($id === null ? '' : ' AND id = ?') . ' ORDER BY orden,nombre,id',
            $id === null ? [] : [$id]);
    }

    public function detallePlatillo(int $sucursal, int $id): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->leeCarta($sucursal, true, $id)[0] ?? throw Errores::noEncontrado('Platillo no disponible');
    }

    public function categoria(int $id, array $datos): void
    {
        $nombre = Datos::texto($datos['nombre'] ?? '', 'nombre', 80);
        $orden = Datos::entero($datos['orden'] ?? 0, 'orden', 0, 65535);
        $descripcion = Datos::texto($datos['descripcion'] ?? '', 'descripcion', 300, false);
        $this->cambiaCatalogo('categoria_menu', $id, ['nombre' => $nombre, 'orden' => $orden, 'descripcion' => $descripcion]);
    }

    public function bajaCategoria(int $id): void
    {
        $this->cambiaCatalogo('categoria_menu', $id, ['activa' => 0]);
    }

    public function platillo(int $id, array $datos): void
    {
        $foto = Datos::texto($datos['foto'] ?? '', 'foto', 255, false);
        if ($foto !== '' && !preg_match('#^(/recursos/menu/[a-z0-9][a-z0-9_-]*\.(avif|webp|png|jpe?g)|/fotos-menu/[a-f0-9]{32}\.webp)$#iD', $foto)) {
            throw Errores::datosInvalidos(['imagen' => 'Seleccione una foto válida']);
        }
        $this->cambiaCatalogo('platillo', $id, [
            'id_categoria' => Datos::entero($datos['id_categoria'] ?? null, 'id_categoria'),
            'nombre' => Datos::texto($datos['nombre'] ?? '', 'nombre', 100),
            'descripcion' => Datos::texto($datos['descripcion'] ?? '', 'descripcion', 400, false),
            'porcion' => Datos::texto($datos['porcion'] ?? '', 'porcion', 40, false),
            'orden' => Datos::entero(in_array($datos['orden'] ?? '', ['', null], true) ? 0 : $datos['orden'], 'orden', 0, 65535),
            'preparacion' => Datos::opcion($datos['preparacion'] ?? '', 'preparacion', array_keys(self::AREAS)),
            'foto' => $foto === '' ? null : $foto,
            'activo' => Datos::entero($datos['activo'] ?? 0, 'activo', 0, 1),
            'especialidad' => Datos::entero($datos['especialidad'] ?? 0, 'especialidad', 0, 1),
        ]);
    }

    public function modificador(int $id, array $datos): void
    {
        $this->cambiaCatalogo('modificador_platillo', $id, [
            'id_platillo' => Datos::entero($datos['id_platillo'] ?? null, 'id_platillo'),
            'nombre' => Datos::texto($datos['nombre'] ?? '', 'nombre', 80),
            'suplemento' => Datos::precio($datos['suplemento'] ?? '0', 'suplemento')->aPesos(),
            'activo' => Datos::entero($datos['activo'] ?? 0, 'activo', 0, 1),
        ]);
    }

    public function disponibilidad(int $sucursal, int $platillo, array $datos): void
    {
        $precio = Datos::precio($datos['precio'] ?? '', 'precio')->aPesos();
        $agotado = Datos::entero($datos['agotado'] ?? 0, 'agotado', 0, 1);
        $this->bd->transaccion(function () use ($sucursal, $platillo, $precio, $agotado): void {
            $this->operacion->bloqueaCatalogo($sucursal);
            if ($this->operacion->operaEnSuServidor($sucursal)) {
                // El precio se fija aquí; lo agotado lo marca la sucursal en su servidor.
                $this->bd->ejecuta(
                    'INSERT INTO platillo_sucursal (id_sucursal, id_platillo, precio) VALUES (?, ?, ?)
                     ON DUPLICATE KEY UPDATE precio = VALUES(precio)',
                    [$sucursal, $platillo, $precio]
                );
                $agotado = (int) $this->bd->valor('SELECT agotado FROM platillo_sucursal WHERE id_sucursal = ? AND id_platillo = ?', [$sucursal, $platillo]);
            } else {
                $this->bd->ejecuta(
                    'INSERT INTO platillo_sucursal (id_sucursal, id_platillo, precio, agotado) VALUES (?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE precio = VALUES(precio), agotado = VALUES(agotado)',
                    [$sucursal, $platillo, $precio, $agotado]
                );
            }
            $this->operacion->registra($sucursal, 'menu_sucursal', $platillo, ['precio' => $precio, 'agotado' => $agotado]);
        });
    }

    public function agota(int $sucursal, string $modo, int $platillo, string $llave, mixed $valor): array
    {
        $agotado = Datos::entero($valor, 'agotado', 0, 1);
        return $this->operacion->unaVez($sucursal, $llave, 'menu_agotado', [$platillo, $agotado],
            function () use ($sucursal, $modo, $platillo, $agotado): array {
                $actual = $this->bd->fila(
                    'SELECT ps.agotado, p.preparacion FROM platillo_sucursal ps JOIN platillo p ON p.id = ps.id_platillo
                     WHERE ps.id_sucursal = ? AND ps.id_platillo = ? AND p.activo = 1 FOR UPDATE',
                    [$sucursal, $platillo]
                ) ?? throw Errores::noEncontrado('El platillo no está en la carta de esta sucursal');
                if ($modo !== 'gerencia' && (($modo === 'barra') !== ($actual['preparacion'] === 'barra'))) {
                    throw Errores::prohibido('Este platillo corresponde a otra área');
                }
                if ((int) $actual['agotado'] !== $agotado) {
                    $this->bd->ejecuta('UPDATE platillo_sucursal SET agotado = ? WHERE id_sucursal = ? AND id_platillo = ?',
                        [$agotado, $sucursal, $platillo]);
                    $this->operacion->registra($sucursal, 'menu_agotado', $platillo, ['agotado' => $agotado]);
                }
                return ['id' => $platillo, 'agotado' => $agotado];
            }
        );
    }

    public function precios(int $sucursal, ?int $origen, array $captura): void
    {
        $precios = [];
        foreach ($captura as $id => $precio) {
            if ($precio !== '') {
                $precios[Datos::entero($id, 'precios')] = Datos::precio($precio, 'precios[' . $id . ']')->aPesos();
            }
        }
        if ($sucursal === $origen) {
            throw Errores::datosInvalidos(['origen' => 'Seleccione otra sucursal']);
        }
        $this->bd->transaccion(function () use ($sucursal, $origen, $precios): void {
            if ($origen !== null) {
                $this->operacion->bloqueaCatalogo(min($sucursal, $origen));
                $this->operacion->bloqueaCatalogo(max($sucursal, $origen));
                $precios = array_replace(array_column($this->bd->filas(
                    'SELECT ps.id_platillo, ps.precio FROM platillo_sucursal ps JOIN platillo p ON p.id = ps.id_platillo AND p.activo = 1
                     WHERE ps.id_sucursal = ?', [$origen]
                ), 'precio', 'id_platillo'), $precios);
            } else {
                $this->operacion->bloqueaCatalogo($sucursal);
            }
            if ($precios === []) {
                throw Errores::datosInvalidos(['origen' => 'Capture precios o seleccione otra sucursal']);
            }
            foreach ($precios as $id => $precio) {
                if ($this->bd->valor('SELECT id FROM platillo WHERE id = ?', [$id]) === null) {
                    throw Errores::noEncontrado('Platillo no disponible');
                }
                $this->bd->ejecuta(
                    'INSERT INTO platillo_sucursal (id_sucursal,id_platillo,precio) VALUES (?, ?, ?)
                     ON DUPLICATE KEY UPDATE precio = VALUES(precio)',
                    [$sucursal, $id, $precio]
                );
            }
            $this->operacion->registra($sucursal, 'menu_precios', $sucursal, ['origen' => $origen, 'precios' => $precios]);
        });
    }

    private function leeCarta(int $sucursal, bool $admin, ?int $id = null, bool $modificadores = true): array
    {
        $sql = 'SELECT p.id, p.id_categoria, p.nombre, p.descripcion, p.porcion, p.orden, p.foto, p.preparacion, p.activo, p.especialidad,
                    c.nombre AS categoria, c.descripcion AS descripcion_categoria, ps.precio, ps.agotado
                FROM platillo p JOIN categoria_menu c ON c.id = p.id_categoria
                LEFT JOIN platillo_sucursal ps ON ps.id_platillo = p.id AND ps.id_sucursal = ?';
        if (!$admin) {
            $sql .= ' WHERE p.activo = 1 AND c.activa = 1 AND ps.precio IS NOT NULL';
        } elseif ($id !== null) {
            $sql .= ' WHERE p.id = ?';
        }
        $platillos = $this->bd->filas($sql . ' ORDER BY c.orden, c.nombre, p.orden, p.nombre, p.id', $id === null ? [$sucursal] : [$sucursal, $id]);
        $vigentes = $this->promociones->vigentesPara($sucursal, new DateTimeImmutable());
        foreach ($platillos as &$fila) {
            $fila['promocion'] = $fila['precio'] === null ? null
                : self::promocionPublica(Promociones::mejor($vigentes[(int) $fila['id']] ?? [], Dinero::deCadena($fila['precio']), Dinero::cero()), $fila['precio']);
        }
        unset($fila);
        if (!$modificadores) {
            return $platillos;
        }
        $opciones = $this->bd->filas(
            'SELECT id, id_platillo, nombre, suplemento, activo FROM modificador_platillo'
            . (!$admin ? ' WHERE activo = 1' : ($id === null ? '' : ' WHERE id_platillo = ?')) . ' ORDER BY nombre, id',
            $id === null ? [] : [$id]
        );
        $porPlatillo = [];
        foreach ($opciones as $modificador) {
            $porPlatillo[$modificador['id_platillo']][] = $modificador;
        }
        foreach ($platillos as &$platillo) {
            $platillo['modificadores'] = $porPlatillo[$platillo['id']] ?? [];
        }
        return $platillos;
    }

    /** Lo que la carta enseña de una promoción: insignia, precio tachado y horario. */
    public static function promocionPublica(?array $p, string $precio): ?array
    {
        if ($p === null) {
            return null;
        }
        return [
            'id' => (int) $p['id'], 'nombre' => $p['nombre'], 'tipo' => $p['tipo'], 'etiqueta' => Promocion::etiqueta($p),
            'lleva' => $p['lleva'] === null ? null : (int) $p['lleva'], 'paga' => $p['paga'] === null ? null : (int) $p['paga'],
            'precio_promocion' => Promocion::precioPromocion($p, Dinero::deCadena($precio))?->aPesos(),
            'horario' => Promocion::horario($p),
        ];
    }

    private function cambiaCatalogo(string $tabla, int $id, array $valores): void
    {
        $this->bd->transaccion(function () use ($tabla, $id, $valores): void {
            $sucursales = $this->bd->filas('SELECT id FROM sucursal WHERE id_estatus = 4 ORDER BY id FOR UPDATE');
            if ($tabla === 'categoria_menu' && ($valores['activa'] ?? 1) === 0
                && $this->bd->valor('SELECT id FROM platillo WHERE id_categoria = ? AND activo = 1 LIMIT 1', [$id]) !== null) {
                throw Errores::conflicto('La categoría tiene platillos activos');
            }
            if ($tabla === 'platillo' && $this->bd->valor(
                'SELECT id FROM categoria_menu WHERE id = ? AND activa = 1 FOR UPDATE', [$valores['id_categoria']]
            ) === null) {
                throw Errores::datosInvalidos(['id_categoria' => 'Seleccione una categoría activa']);
            }
            if ($id === 0) {
                $id = $this->bd->inserta(
                    'INSERT INTO ' . $tabla . '(' . implode(', ', array_keys($valores)) . ')
                     VALUES (' . implode(', ', array_fill(0, count($valores), '?')) . ')',
                    array_values($valores)
                );
            } else {
                if ($this->bd->valor('SELECT id FROM ' . $tabla . ' WHERE id = ? FOR UPDATE', [$id]) === null) {
                    throw Errores::noEncontrado();
                }
                $campos = implode(', ', array_map(fn (string $campo) => "$campo = ?", array_keys($valores)));
                $this->bd->ejecuta('UPDATE ' . $tabla . ' SET ' . $campos . ' WHERE id = ?', [...array_values($valores), $id]);
            }
            foreach ($sucursales as $sucursal) {
                $this->bd->ejecuta("INSERT INTO evento_sucursal (id_sucursal, tipo, entidad) VALUES (?, 'catalogo_menu', ?)",
                    [$sucursal['id'], $id]);
            }
            $this->bitacora->registra('restaurante', 'catalogo_menu', $tabla, $id, despues: $valores,
                idUsuario: $this->identidad->id());
        });
    }
}
