<?php
declare(strict_types=1);

namespace Servicios;

use InvalidArgumentException;

/**
 * La identidad visual de la instalación: nombre, colores y logotipo
 * (rediseño del 2026-11-09, D24).
 *
 * Sin archivo de configuración, la instalación es El Timón y nada cambia. Con
 * `config/marca-visual.php` —o `marca-visual.pruebas.php` en pruebas— otra
 * distribuidora pone su nombre, sus seis colores y su logotipo, sin editor y
 * sin tocar la base.
 *
 * Se llama «marca visual» y no «marca» a secas porque en este sistema la
 * marca es el token CSRF (`ExigeMarca`, `_marca`).
 *
 * Lo que entra aquí termina dentro de una hoja de estilos y de la respuesta
 * de la app, así que nada pasa sin validar:
 * - un color es `#RRGGBB` y nada más: ni nombres, ni `url(…)`, ni `;`;
 * - el texto contra el fondo y el blanco contra el primario dan 4.5:1 o más,
 *   y el acento se distingue de las tarjetas (2.5:1);
 * - el logotipo es un PNG o WebP de 512 KB como máximo, dentro de
 *   `almacenamiento/marca/`. No se acepta SVG: puede llevar guiones.
 *
 * Una configuración inválida falla de forma explícita en
 * `guiones/verifica-host.php`. En ejecución, la pantalla vuelve a El Timón y el
 * problema se anota, para no tirar el panel por un color mal escrito.
 */
final class MarcaVisual
{
    /** La marca de la casa: lo que se ve sin archivo de configuración. */
    public const BASE = MarcaBase::VALORES;

    public const LOGO_MAXIMO = 524288;
    private const TIPOS_LOGO = ['image/png' => 'png', 'image/webp' => 'webp'];
    private const LLAVES = ['nombre', 'nombre_corto', 'lema', 'colores', 'logo'];
    private const LARGOS = ['nombre' => 60, 'nombre_corto' => 20, 'lema' => 120];

    /** @var array{nombre:string,nombre_corto:string,lema:string,colores:array<string,string>,logo:?array{ruta:string,tipo:string,sha256:string,bytes:int}}|null */
    private ?array $vigente = null;
    private ?string $problema = null;

    /**
     * @param array<mixed>|null $config lo que devolvió el archivo; null si no hay archivo
     */
    public function __construct(private ?array $config, private string $carpetaLogo)
    {
    }

    /** Lee la configuración de la instalación, si la hay. */
    public static function deInstalacion(string $raiz, string $entorno): self
    {
        $sufijo = $entorno === 'pruebas' ? '.pruebas' : '';
        $ruta = rtrim($raiz, '/') . '/config/marca-visual' . $sufijo . '.php';
        $config = null;

        if (is_file($ruta)) {
            $leido = require $ruta;
            // Un archivo que no devuelve un arreglo es una configuración
            // presente e inválida, no una ausente.
            $config = is_array($leido) ? $leido : ['_ilegible' => true];
        }

        return new self($config, rtrim($raiz, '/') . '/almacenamiento/marca');
    }

    /** ¿Hay una configuración propia y es válida? */
    public function personalizada(): bool
    {
        $this->vigente();
        return $this->config !== null && $this->problema === null;
    }

    /** Por qué se ignoró la configuración, o null si no hubo problema. */
    public function problema(): ?string
    {
        $this->vigente();
        return $this->problema;
    }

    /**
     * Para el preflight: lanza con la lista de problemas. Sin archivo no hay
     * nada que validar.
     */
    public function valida(): void
    {
        if ($this->config === null) {
            return;
        }

        $this->normaliza($this->config);
    }

    /**
     * La marca con que se pinta todo: la configurada si es válida, El Timón si no.
     *
     * @return array{nombre:string,nombre_corto:string,lema:string,colores:array<string,string>,logo:?array{ruta:string,tipo:string,sha256:string,bytes:int}}
     */
    public function vigente(): array
    {
        if ($this->vigente !== null) {
            return $this->vigente;
        }

        if ($this->config === null) {
            return $this->vigente = self::BASE;
        }

        try {
            return $this->vigente = $this->normaliza($this->config);
        } catch (InvalidArgumentException $e) {
            $this->problema = $e->getMessage();
            return $this->vigente = self::BASE;
        }
    }

    /** Doce hexadecimales que cambian si cambia algo que se ve. */
    public function revision(): string
    {
        $m = $this->vigente();
        $huella = json_encode([
            $m['nombre'], $m['nombre_corto'], $m['lema'], $m['colores'], $m['logo']['sha256'] ?? null,
        ], JSON_UNESCAPED_UNICODE);

        return substr(hash('sha256', (string) $huella), 0, 12);
    }

    /** @return array{ruta:string,tipo:string,sha256:string,bytes:int}|null */
    public function logo(): ?array
    {
        return $this->vigente()['logo'];
    }

    /**
     * Las variables de la hoja `/marca/tema.css`. Sólo cambia tokens: la
     * estructura sigue siendo la de `main.css` y `tema.css`.
     */
    public function css(): string
    {
        $c = $this->vigente()['colores'];
        $rgb = static fn (string $hex): string => implode(', ', self::canales($hex));
        $primarioOscuro = $this->personalizada() ? self::mezcla($c['primario'], '#000000', 0.3) : $c['tinta'];
        $primarioClaro = self::mezcla($c['primario'], '#FFFFFF', 0.18);
        $acentoFoco = self::oscureceHasta($c['acento'], $c['superficie'], 3.0);
        [$r, $g, $b] = self::canales($c['primario']);

        $variables = [
            '--app-bg'                 => $c['fondo'],
            '--app-surface'            => $c['superficie'],
            '--app-text'               => $c['tinta'],
            '--app-muted'              => $c['secundario'],
            '--app-surface-muted'      => self::mezcla($c['fondo'], $c['superficie'], 0.55),
            '--app-border'             => $c['borde'],
            '--app-primary'            => $c['primario'],
            '--app-primary-dark'       => $primarioOscuro,
            '--app-primary-light'      => $primarioClaro,
            '--app-primary-soft'       => "rgb($r $g $b / 8%)",
            '--app-secondary'          => $primarioClaro,
            '--app-secondary-dark'     => $primarioOscuro,
            '--app-accent'             => $c['acento'],
            '--app-accent-bright'      => $this->personalizada() ? self::mezcla($c['acento'], '#FFFFFF', 0.35) : $c['aviso'],
            '--app-accent-dark'        => $acentoFoco,
            '--bs-body-bg'             => $c['superficie'],   // tablas, tarjetas y campos (D24)
            '--bs-body-color'          => $c['tinta'],
            '--bs-border-color'        => $c['borde'],
            '--bs-primary'             => $c['primario'],
            '--bs-primary-rgb'         => $rgb($c['primario']),
            '--bs-primary-text-emphasis' => $c['primario'],
            '--bs-link-color'          => $c['primario'],
            '--bs-link-color-rgb'      => $rgb($c['primario']),
            '--bs-link-hover-color'    => $primarioOscuro,
            '--bs-link-hover-color-rgb' => $rgb($primarioOscuro),
            '--bs-focus-ring-color'    => 'rgb(' . implode(' ', self::canales($acentoFoco)) . ' / 35%)',
        ];

        $lineas = ['/* Marca visual ' . $this->revision() . ': variables saneadas de config/marca-visual.php. */', ':root {'];
        foreach ($variables as $nombre => $valor) {
            $lineas[] = '    ' . $nombre . ': ' . $valor . ';';
        }
        $lineas[] = '}';

        return implode("\n", $lineas) . "\n";
    }

    /**
     * Lo que baja la app (`marca` en la bajada). Sin rutas del servidor: el
     * logotipo se pide aparte, por su huella.
     *
     * @return array{revision:string,nombre:string,nombre_corto:string,colores:array<string,string>,logo:?array{sha256:string,tipo:string}}
     */
    public function manifiesto(): array
    {
        $m = $this->vigente();

        return [
            'revision'     => $this->revision(),
            'nombre'       => $m['nombre'],
            'nombre_corto' => $m['nombre_corto'],
            'colores'      => $m['colores'],
            'logo'         => $m['logo'] === null ? null : ['sha256' => $m['logo']['sha256'], 'tipo' => $m['logo']['tipo']],
        ];
    }

    /** Contraste WCAG entre dos colores `#RRGGBB`. */
    public static function contraste(string $a, string $b): float
    {
        $la = self::luminancia($a);
        $lb = self::luminancia($b);

        return (max($la, $lb) + 0.05) / (min($la, $lb) + 0.05);
    }

    /**
     * @param array<mixed> $config
     * @return array{nombre:string,nombre_corto:string,lema:string,colores:array<string,string>,logo:?array{ruta:string,tipo:string,sha256:string,bytes:int}}
     */
    private function normaliza(array $config): array
    {
        $problemas = [];

        foreach (array_keys($config) as $llave) {
            if (!in_array($llave, self::LLAVES, true)) {
                $problemas[] = 'llave desconocida «' . (string) $llave . '»';
            }
        }

        $marca = self::BASE;

        foreach (self::LARGOS as $campo => $maximo) {
            if (!array_key_exists($campo, $config)) {
                continue;
            }
            $valor = $config[$campo];
            if (!is_string($valor) || trim($valor) === '' || mb_strlen($valor) > $maximo
                || preg_match('/[\x00-\x1F\x7F<>]/u', $valor) === 1) {
                $problemas[] = "«{$campo}» debe ser texto de 1 a {$maximo} caracteres, sin < ni >";
                continue;
            }
            $marca[$campo] = trim($valor);
        }

        if (array_key_exists('colores', $config)) {
            if (!is_array($config['colores'])) {
                $problemas[] = '«colores» debe ser una lista';
            } else {
                foreach ($config['colores'] as $nombre => $valor) {
                    if (!array_key_exists((string) $nombre, self::BASE['colores'])) {
                        $problemas[] = 'color desconocido «' . (string) $nombre . '»';
                        continue;
                    }
                    if (!is_string($valor) || preg_match('/^#[0-9A-Fa-f]{6}$/', $valor) !== 1) {
                        $problemas[] = "el color «{$nombre}» debe ser #RRGGBB";
                        continue;
                    }
                    $marca['colores'][(string) $nombre] = strtoupper($valor);
                }
            }
        }

        $c = $marca['colores'];
        foreach ([
            ['tinta', 'fondo', 4.5, 'el texto sobre el fondo'],
            ['tinta', 'superficie', 4.5, 'el texto sobre las tarjetas'],
            ['primario', '#FFFFFF', 4.5, 'el texto blanco sobre el primario'],
            // El acento adorna (aros, indicadores); el anillo de foco usa su
            // versión oscurecida hasta 3:1 (`css()`). El lager de El Timón da 2.99:1.
            ['acento', 'superficie', 2.5, 'el acento sobre las tarjetas'],
        ] as [$uno, $otro, $minimo, $que]) {
            $a = $c[$uno];
            $b = $c[$otro] ?? $otro;
            if (preg_match('/^#[0-9A-F]{6}$/', $a) !== 1 || preg_match('/^#[0-9A-F]{6}$/', $b) !== 1) {
                continue;
            }
            $medido = self::contraste($a, $b);
            if ($medido < $minimo) {
                $problemas[] = sprintf('%s da %.2f:1 y necesita %.1f:1', $que, $medido, $minimo);
            }
        }

        if (array_key_exists('logo', $config) && $config['logo'] !== null) {
            try {
                $marca['logo'] = $this->validaLogo($config['logo']);
            } catch (InvalidArgumentException $e) {
                $problemas[] = $e->getMessage();
            }
        }

        if (isset($config['_ilegible'])) {
            $problemas = ['el archivo no devuelve un arreglo'];
        }

        if ($problemas !== []) {
            throw new InvalidArgumentException('Marca visual inválida: ' . implode('; ', $problemas) . '.');
        }

        return $marca;
    }

    /** @return array{ruta:string,tipo:string,sha256:string,bytes:int} */
    private function validaLogo(mixed $nombre): array
    {
        // Sólo un nombre de archivo: la carpeta la pone el sistema.
        if (!is_string($nombre) || preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{0,80}\.(png|webp)$/', $nombre) !== 1) {
            throw new InvalidArgumentException('«logo» debe ser el nombre de un .png o .webp dentro de almacenamiento/marca/');
        }

        $carpeta = realpath($this->carpetaLogo);
        $ruta = realpath($this->carpetaLogo . '/' . $nombre);
        if ($carpeta === false || $ruta === false || !str_starts_with($ruta, $carpeta . DIRECTORY_SEPARATOR) || !is_file($ruta)) {
            throw new InvalidArgumentException('el logotipo no está dentro de almacenamiento/marca/');
        }

        $bytes = (int) filesize($ruta);
        if ($bytes < 1 || $bytes > self::LOGO_MAXIMO) {
            throw new InvalidArgumentException('el logotipo debe pesar de 1 byte a 512 KB');
        }

        $tipo = (string) (new \finfo(FILEINFO_MIME_TYPE))->file($ruta);
        if (!isset(self::TIPOS_LOGO[$tipo])) {
            throw new InvalidArgumentException('el logotipo debe ser PNG o WebP');
        }

        return ['ruta' => $ruta, 'tipo' => $tipo, 'sha256' => (string) hash_file('sha256', $ruta), 'bytes' => $bytes];
    }

    /** @return array{0:int,1:int,2:int} */
    private static function canales(string $hex): array
    {
        return [hexdec(substr($hex, 1, 2)), hexdec(substr($hex, 3, 2)), hexdec(substr($hex, 5, 2))];
    }

    private static function luminancia(string $hex): float
    {
        $lineal = static function (int $canal): float {
            $c = $canal / 255;
            return $c <= 0.03928 ? $c / 12.92 : (($c + 0.055) / 1.055) ** 2.4;
        };
        [$r, $g, $b] = self::canales($hex);

        return 0.2126 * $lineal($r) + 0.7152 * $lineal($g) + 0.0722 * $lineal($b);
    }

    private static function mezcla(string $color, string $con, float $cuanto): string
    {
        $a = self::canales($color);
        $b = self::canales($con);
        $mezcla = array_map(static fn (int $x, int $y): int => (int) round($x + ($y - $x) * $cuanto), $a, $b);

        return sprintf('#%02X%02X%02X', ...$mezcla);
    }

    /** Oscurece un color hasta que contraste lo pedido contra el fondo. */
    private static function oscureceHasta(string $color, string $fondo, float $minimo): string
    {
        $actual = $color;
        for ($paso = 0; $paso < 20 && self::contraste($actual, $fondo) < $minimo; $paso++) {
            $actual = self::mezcla($actual, '#000000', 0.08);
        }

        return $actual;
    }
}
