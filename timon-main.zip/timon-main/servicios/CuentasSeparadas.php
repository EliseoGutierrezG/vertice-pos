<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\DatosRestaurante as Datos;
use Dominio\Dinero;
use Dominio\Reparto;
use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;

final class CuentasSeparadas
{
    private const MAX_CUENTAS = 40;

    public function __construct(
        private BaseDatos $bd,
        private OperacionRestaurante $operacion,
        private Comandas $comandas,
        private Promociones $promociones
    ) {
    }

    public function separa(int $sucursal, int $id, int $version, string $llave, array $datos): array
    {
        $modo = Datos::opcion($datos['modo'] ?? null, 'modo', ['asiento', 'platillos']);
        $asiento = $modo === 'asiento' ? Datos::entero($datos['asiento'] ?? null, 'asiento', 1, 99) : null;
        $ids = [];
        if ($modo === 'platillos') {
            $items = $datos['items'] ?? null;
            if (!is_array($items) || !array_is_list($items) || $items === [] || count($items) > 100) {
                throw Errores::datosInvalidos(['items' => 'Seleccione los platillos para separar']);
            }
            $ids = array_values(array_unique(array_map(static fn (mixed $item) => Datos::entero($item, 'items'), $items)));
            sort($ids);
        }
        return $this->comandas->modifica($sucursal, $id, $version, $llave, 'cuenta_separada', [$modo, $asiento, $ids],
            function (array $cuenta) use ($sucursal, $id, $asiento, $ids): array {
                $this->exigeMesa($cuenta);
                if (!Dinero::deCadena($cuenta['ajuste_reparto'])->esCero()) {
                    throw Errores::conflicto('Reúna el reparto antes de separar platillos');
                }
                $madre = (int) ($cuenta['id_cuenta_madre'] ?? $id);
                if (count($this->comandas->grupoAbierto($sucursal, $madre)) >= self::MAX_CUENTAS) {
                    throw Errores::conflicto('La mesa ya alcanzó el máximo de cuentas abiertas');
                }
                $activos = $this->items($id);
                $seleccion = array_values(array_filter($activos, static fn (array $fila): bool => $asiento === null
                    ? in_array((int) $fila['id'], $ids, true) : (int) $fila['asiento'] === $asiento));
                if ($seleccion === [] || ($asiento === null && count($seleccion) !== count($ids))) {
                    throw Errores::conflicto('Los platillos seleccionados ya cambiaron');
                }
                if (count($seleccion) === count($activos)) {
                    throw Errores::datosInvalidos(['items' => 'Deje un platillo en la cuenta de origen']);
                }
                $hija = $this->crea($cuenta, '0.00');
                $this->mueveItems($hija, $seleccion);
                // Cada cuenta calcula sus promociones: un 2x1 partido en dos
                // cuentas deja de regalar la pieza.
                $this->promociones->recalcula($hija);
                $this->operacion->registra($sucursal, 'subcuenta_abierta', $hija, ['origen' => $id], $hija);
                return ['id_subcuenta' => $hija];
            }
        );
    }

    public function reparte(int $sucursal, int $id, int $version, string $llave, int $partes): array
    {
        return $this->comandas->modifica($sucursal, $id, $version, $llave, 'cuenta_repartida', [$partes],
            function (array $cuenta) use ($sucursal, $id, $partes): array {
                $this->exigeMesa($cuenta);
                $grupo = (int) ($cuenta['id_cuenta_madre'] ?? $id);
                if (!Dinero::deCadena($cuenta['ajuste_reparto'])->esCero()
                    || count($this->comandas->grupoAbierto($sucursal, $grupo)) > 1) {
                    throw Errores::conflicto('Reúna las cuentas abiertas antes de repartir');
                }

                $items = $this->items($id);
                $consumo = Dinero::cero();
                foreach ($items as $item) {
                    if ($item['estado'] === 'capturado') {
                        throw Errores::conflicto('Envíe los platillos antes de repartir');
                    }
                    $consumo = $consumo->mas(Comandas::importe($item));
                }
                // Los platillos físicos conservan su cuenta y sus rondas. Los
                // ajustes trasladan solo saldo y suman cero dentro del reparto.
                $cuotas = Reparto::divide($consumo, $partes);
                $primera = array_shift($cuotas);
                $ajuste = $primera->menos($consumo)->aPesos();
                $this->bd->ejecuta('UPDATE cuenta SET ajuste_reparto = ? WHERE id = ?', [$ajuste, $id]);
                $hijas = [];
                foreach ($cuotas as $cuota) {
                    $hija = $this->crea($cuenta, $cuota->aPesos());
                    $hijas[] = $hija;
                    $this->operacion->registra($sucursal, 'subcuenta_abierta', $hija, ['origen' => $id], $hija);
                }
                return ['subcuentas_creadas' => $hijas, 'ajuste' => $ajuste];
            }
        );
    }

    public function reune(int $sucursal, int $id, int $version, string $llave, array $datos): array
    {
        $versiones = $datos['versiones'] ?? null;
        if (!is_array($versiones) || $versiones === [] || count($versiones) > self::MAX_CUENTAS) {
            throw Errores::datosInvalidos(['versiones' => 'Recargue las cuentas separadas']);
        }
        return $this->comandas->modifica($sucursal, $id, $version, $llave, 'cuentas_reunidas', [$versiones],
            function (array $cuenta) use ($sucursal, $id, $versiones): array {
                $this->exigeMesa($cuenta);
                $grupo = $this->comandas->grupoAbierto($sucursal, (int) ($cuenta['id_cuenta_madre'] ?? $id));
                if (count($grupo) < 2 || $cuenta['id_mesa'] === null) {
                    throw Errores::conflicto('Reúna desde la cuenta que tiene la mesa');
                }
                $ajuste = Dinero::deCadena($cuenta['ajuste_reparto']);
                $reunidas = [];
                foreach ($grupo as $fila) {
                    $origen = (int) $fila['id'];
                    if ($origen === $id) {
                        continue;
                    }
                    if ((int) ($versiones[$origen] ?? 0) !== (int) $fila['version']) {
                        throw Errores::conflicto('Cambió una cuenta separada. Revise los importes');
                    }
                    $ajuste = $ajuste->mas(Dinero::deCadena($fila['ajuste_reparto']));
                    $this->mueveItems($id, $this->items($origen));
                    $this->bd->ejecuta(
                        "UPDATE cuenta SET estado = 'unida', abierta = NULL, cerrada_en = NOW(), version = version + 1 WHERE id = ?",
                        [$origen]
                    );
                    $this->operacion->registra($sucursal, 'subcuenta_reunida', $origen, ['destino' => $id], $origen);
                    $reunidas[] = $origen;
                }
                $this->bd->ejecuta('UPDATE cuenta SET ajuste_reparto = ? WHERE id = ?', [$ajuste->aPesos(), $id]);
                return ['reunidas' => $reunidas, 'ajuste' => $ajuste->aPesos()];
            }
        );
    }

    private function exigeMesa(array $cuenta): void
    {
        if ($cuenta['tipo'] !== 'mesa') {
            throw Errores::conflicto('Esta operación requiere una cuenta de mesa');
        }
    }

    private function crea(array $cuenta, string $ajuste): int
    {
        return $this->bd->inserta(
            "INSERT INTO cuenta (id_sucursal, id_mesero, tipo, id_cuenta_madre, ajuste_reparto)
             VALUES (?, ?, 'mesa', ?, ?)",
            [$cuenta['id_sucursal'], $cuenta['id_mesero'], $cuenta['id_cuenta_madre'] ?? $cuenta['id'], $ajuste]
        );
    }

    private function items(int $id): array
    {
        return $this->bd->filas(
            "SELECT i.id, i.id_ronda, i.asiento, i.cantidad, i.precio, i.descuento, i.estado, r.id_usuario, r.enviada_en
             FROM cuenta_item i LEFT JOIN ronda r ON r.id = i.id_ronda
             WHERE i.id_cuenta = ? AND i.estado <> 'cancelado' ORDER BY i.id FOR UPDATE",
            [$id]
        );
    }

    private function mueveItems(int $destino, array $items): void
    {
        $rondas = [];
        foreach ($items as $item) {
            $origen = $item['id_ronda'];
            $ronda = $origen === null ? null : ($rondas[$origen] ??= $this->bd->inserta(
                'INSERT INTO ronda (id_cuenta, id_usuario, enviada_en) VALUES (?, ?, ?)',
                [$destino, $item['id_usuario'], $item['enviada_en']]
            ));
            $this->bd->ejecuta(
                'UPDATE cuenta_item SET id_cuenta = ?, id_ronda = ? WHERE id = ?',
                [$destino, $ronda, $item['id']]
            );
        }
    }
}
