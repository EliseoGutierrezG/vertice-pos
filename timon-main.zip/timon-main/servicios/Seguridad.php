<?php
declare(strict_types=1);

namespace Servicios;

use Modelos\IntentosAcceso;
use Modelos\Parametros;
use Modelos\Usuarios;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Errores\Errores;

/**
 * El interruptor del segundo factor web (pantalla «Seguridad», bitácora 98).
 *
 * Es la llave de todas las demás, así que no basta con tener la sesión: quien
 * lo cambia confirma su contraseña y, mientras esté encendido, su código de
 * Authenticator. Una computadora con la sesión abierta y sola no alcanza para
 * apagarlo. El cambio va por `Parametros::cambia()`, como el de
 * `guiones/parametro.php`: queda la historia y el apunte en la bitácora.
 */
final class Seguridad
{
    private const AMBITO = 'seguridad';

    public function __construct(
        private BaseDatos $bd,
        private Parametros $parametros,
        private SegundoFactor $segundoFactor,
        private Usuarios $usuarios,
        private IntentosAcceso $intentos,
        private Bitacora $bitacora
    ) {
    }

    /**
     * Lo que la pantalla enseña.
     *
     * @return array{
     *   activo:bool,
     *   cobertura:array{total:int,configurados:int},
     *   cambios:list<array<string,mixed>>
     * }
     */
    public function estado(): array
    {
        return [
            'activo' => $this->segundoFactor->activo(),
            'cobertura' => $this->segundoFactor->cobertura(),
            // De la pantalla y del guion de consola, que apuntan igual.
            'cambios' => $this->bd->filas(
                "SELECT b.momento, b.canal, b.antes, b.despues, u.usuario
                 FROM bitacora b LEFT JOIN usuario u ON u.id = b.id_usuario
                 WHERE b.modulo IN ('seguridad', 'parametros')
                   AND JSON_UNQUOTE(JSON_EXTRACT(b.despues, '$.clave')) = ?
                 ORDER BY b.id DESC LIMIT 20",
                [SegundoFactor::PARAMETRO]
            ),
        ];
    }

    /** @param array<string,mixed> $datos */
    public function cambiaSegundoFactor(bool $encender, int $idActor, array $datos, string $ip): void
    {
        $activo = $this->segundoFactor->activo();
        if ($encender === $activo) {
            throw Errores::conflicto($activo ? 'El segundo factor ya está encendido' : 'El segundo factor ya está apagado');
        }

        $clave = (string) ($datos['clave'] ?? '');
        $codigo = trim((string) ($datos['codigo'] ?? ''));
        $faltan = [];
        if ($clave === '') {
            $faltan['clave'] = 'Capture su contraseña';
        }
        if ($activo && $codigo === '') {
            $faltan['codigo'] = 'Capture el código de Authenticator';
        }
        if ($faltan !== []) {
            throw Errores::datosInvalidos($faltan, 'Confirme que es usted');
        }

        $usuario = (string) ($this->usuarios->porId($idActor)['usuario'] ?? '');
        if (($espera = $this->intentos->reintento(self::AMBITO, $usuario, $ip)) > 0) {
            throw Errores::demasiadosIntentos($espera);
        }

        $registro = $this->usuarios->autentica($usuario, $clave);
        if ($registro === null || (int) $registro['id'] !== $idActor) {
            $this->rechaza($usuario, $ip);
            throw Errores::datosInvalidos(['clave' => 'La contraseña no es correcta']);
        }

        $desde = date('Y-m-d');
        $posterior = $this->bd->valor(
            'SELECT MIN(vigente_desde) FROM parametro WHERE clave = ? AND vigente_desde > ?',
            [SegundoFactor::PARAMETRO, $desde]
        );
        if ($posterior !== null) {
            throw Errores::conflicto('Hay un cambio programado para el ' . $posterior . '; resuélvalo con guiones/parametro.php');
        }

        $this->bd->transaccion(function () use ($encender, $activo, $idActor, $codigo, $usuario, $desde, $ip): void {
            if ($activo) {
                try {
                    // Dentro de la transacción: si el apunte fallara, el código no se gasta.
                    $this->segundoFactor->valida($idActor, $codigo, 'seguridad_apaga', $ip);
                } catch (ErrorHttp $error) {
                    if ($error->estado() === 409) {
                        // Su sesión es de antes de encenderlo y nunca dio de alta Authenticator.
                        throw Errores::conflicto('Entre de nuevo para activar Authenticator.');
                    }
                    $this->rechaza($usuario, $ip);
                    throw $error;
                }
            }

            $valor = $encender ? '1' : '0';
            $antes = $this->parametros->cambia(SegundoFactor::PARAMETRO, $valor, $desde);
            $this->bitacora->registra(
                'seguridad', $encender ? 'enciende_segundo_factor' : 'apaga_segundo_factor', 'parametro', null,
                ['clave' => SegundoFactor::PARAMETRO, 'valor' => $antes],
                ['clave' => SegundoFactor::PARAMETRO, 'valor' => $valor, 'desde' => $desde],
                $idActor, $ip
            );
        });

        $this->intentos->acierta(self::AMBITO, $usuario, $ip);
    }

    private function rechaza(string $usuario, string $ip): void
    {
        if (($espera = $this->intentos->falla(self::AMBITO, $usuario, $ip)) > 0) {
            throw Errores::demasiadosIntentos($espera);
        }
    }
}
