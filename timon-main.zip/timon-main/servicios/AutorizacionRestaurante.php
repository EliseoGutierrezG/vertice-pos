<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\DatosRestaurante as Datos;
use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;

final class AutorizacionRestaurante
{
    public function __construct(private BaseDatos $bd, private SegundoFactor $factor)
    {
    }

    public function valida(int $sucursal, string $uso, mixed $datos, string $ip): int
    {
        if (!is_array($datos)) {
            throw Errores::datosInvalidos(['autorizacion' => 'Se requiere autorización de gerencia']);
        }
        $usuario = Datos::texto($datos['usuario'] ?? '', 'usuario_gerente', 60);
        $clave = Datos::texto($datos['clave'] ?? '', 'clave_gerente', 250);
        $firma = $this->bd->fila(
            "SELECT u.id, u.clave_hash FROM usuario u JOIN personal p ON p.id = u.id_personal
             JOIN puesto pu ON pu.id = p.id_puesto
             WHERE u.usuario = ? AND u.id_estatus = 4 AND u.cambiar_clave = 0 AND p.id_estatus = 4
               AND pu.id_estatus = 4 AND pu.clave IN ('administrador','gerente')
               AND (u.acceso_hasta IS NULL OR u.acceso_hasta > NOW()) FOR UPDATE",
            [$usuario]
        );
        if (!is_string($firma['clave_hash'] ?? null) || !password_verify($clave, $firma['clave_hash'])) {
            throw Errores::datosInvalidos(['autorizacion' => 'Verifique el usuario y la contraseña de gerencia']);
        }

        // La identidad de la petición sigue siendo la del operador.
        $gerente = new Identidad($this->bd);
        $id = (int) $firma['id'];
        $gerente->establece($id);
        $gerente->exigeSucursal($sucursal);
        if ($this->factor->activo()) {
            $this->factor->valida($id, Datos::texto($datos['codigo'] ?? '', 'codigo', 20), $uso, $ip);
        }
        return $id;
    }
}
