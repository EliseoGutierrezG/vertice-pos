<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\DatosRestaurante as Datos;
use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;

final class PlanoRestaurante
{
    public const FORMAS = ['redonda' => 'Redonda', 'cuadrada' => 'Cuadrada', 'rectangular' => 'Rectangular'];
    public const ESTADOS = ['libre' => 'Libre', 'por_limpiar' => 'Por limpiar', 'bloqueada' => 'Bloqueada'];

    public function __construct(private BaseDatos $bd, private OperacionRestaurante $operacion)
    {
    }

    public function areas(int $sucursal, ?int $id = null): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->filas(
            'SELECT a.id, a.nombre, COUNT(m.id) AS mesas FROM area a
             LEFT JOIN mesa m ON m.id_area = a.id AND m.id_sucursal = a.id_sucursal AND m.activa = 1
             WHERE a.id_sucursal = ? AND a.activa = 1' . ($id === null ? '' : ' AND a.id = ?') . '
             GROUP BY a.id, a.nombre ORDER BY a.nombre, a.id',
            $id === null ? [$sucursal] : [$sucursal, $id]
        );
    }

    public function area(int $sucursal, int $id, array $datos): void
    {
        $nombre = Datos::texto($datos['nombre'] ?? '', 'nombre', 80);
        $this->bd->transaccion(function () use ($sucursal, $id, $nombre): void {
            $this->operacion->bloqueaCatalogo($sucursal);
            if ($id === 0) {
                $id = $this->bd->inserta('INSERT INTO area (id_sucursal, nombre) VALUES (?, ?)', [$sucursal, $nombre]);
            } else {
                $this->existeArea($sucursal, $id);
                $this->bd->ejecuta('UPDATE area SET nombre = ? WHERE id = ? AND id_sucursal = ?', [$nombre, $id, $sucursal]);
            }
            $this->operacion->registra($sucursal, 'plano_area', $id, ['nombre' => $nombre]);
        });
    }

    public function mesa(int $sucursal, int $id, array $datos): void
    {
        $area = Datos::entero($datos['id_area'] ?? null, 'id_area');
        $numero = Datos::texto($datos['numero'] ?? '', 'numero', 20);
        $capacidad = Datos::entero($datos['capacidad'] ?? null, 'capacidad', 1, 255);
        $forma = Datos::opcion($datos['forma'] ?? '', 'forma', array_keys(self::FORMAS));
        $x = Datos::entero($datos['x'] ?? 50, 'x', 0, 100);
        $y = Datos::entero($datos['y'] ?? 50, 'y', 0, 100);
        $estado = Datos::opcion($datos['estado'] ?? 'libre', 'estado', array_keys(self::ESTADOS));
        $this->bd->transaccion(function () use ($sucursal, $id, $area, $numero, $capacidad, $forma, $x, $y, $estado): void {
            $this->operacion->bloqueaCatalogo($sucursal);
            $this->existeArea($sucursal, $area);
            if ($id === 0) {
                $id = $this->bd->inserta(
                    'INSERT INTO mesa (id_sucursal, id_area, numero, capacidad, forma, x, y, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [$sucursal, $area, $numero, $capacidad, $forma, $x, $y, $estado]
                );
            } else {
                $this->existeMesa($sucursal, $id);
                if ($this->bd->valor('SELECT id FROM cuenta_mesa WHERE id_mesa = ? AND abierta = 1 FOR UPDATE', [$id]) !== null) {
                    throw Errores::conflicto('La mesa tiene una cuenta abierta');
                }
                if ($this->operacion->operaEnSuServidor($sucursal)) {
                    // El estado de la mesa lo lleva la sucursal en su servidor.
                    $estado = (string) $this->bd->valor('SELECT estado FROM mesa WHERE id = ?', [$id]);
                }
                $this->bd->ejecuta(
                    'UPDATE mesa SET id_area = ?, numero = ?, capacidad = ?, forma = ?, x = ?, y = ?, estado = ?
                     WHERE id = ? AND id_sucursal = ?',
                    [$area, $numero, $capacidad, $forma, $x, $y, $estado, $id, $sucursal]
                );
            }
            $this->operacion->registra($sucursal, 'plano_mesa', $id, ['area' => $area, 'numero' => $numero, 'estado' => $estado]);
        });
    }

    public function mueve(int $sucursal, int $id, array $datos): void
    {
        $x = Datos::entero($datos['x'] ?? null, 'x', 0, 100);
        $y = Datos::entero($datos['y'] ?? null, 'y', 0, 100);
        $this->bd->transaccion(function () use ($sucursal, $id, $x, $y): void {
            $this->operacion->bloqueaCatalogo($sucursal);
            $this->existeMesa($sucursal, $id);
            $this->bd->ejecuta('UPDATE mesa SET x = ?, y = ? WHERE id = ? AND id_sucursal = ?', [$x, $y, $id, $sucursal]);
            $this->operacion->registra($sucursal, 'plano_posicion', $id, ['x' => $x, 'y' => $y]);
        });
    }

    public function baja(int $sucursal, int $id, string $tipo): void
    {
        $this->bd->transaccion(function () use ($sucursal, $id, $tipo): void {
            $this->operacion->bloqueaCatalogo($sucursal);
            if ($tipo === 'areas') {
                $this->existeArea($sucursal, $id);
                if ($this->bd->valor('SELECT id FROM mesa WHERE id_area = ? AND id_sucursal = ? AND activa = 1 LIMIT 1',
                    [$id, $sucursal]) !== null) {
                    throw Errores::conflicto('El área tiene mesas activas');
                }
                $this->bd->ejecuta('UPDATE area SET activa = 0 WHERE id_sucursal = ? AND id = ?', [$sucursal, $id]);
                $evento = 'plano_area_baja';
            } else {
                $this->existeMesa($sucursal, $id);
                $cuenta = $this->bd->valor('SELECT id FROM cuenta_mesa WHERE id_mesa = ? AND abierta = 1', [$id]);
                $reserva = $this->bd->valor(
                    "SELECT id FROM reservacion WHERE id_mesa = ? AND estado = 'confirmada' AND hasta > NOW() LIMIT 1",
                    [$id]
                );
                if ($cuenta !== null || $reserva !== null) {
                    throw Errores::conflicto('La mesa tiene una cuenta o reservación');
                }
                $this->bd->ejecuta('UPDATE mesa SET activa = 0 WHERE id_sucursal = ? AND id = ?', [$sucursal, $id]);
                $evento = 'plano_mesa_baja';
            }
            $this->operacion->registra($sucursal, $evento, $id);
        });
    }

    private function existeArea(int $sucursal, int $id): void
    {
        if ($this->bd->valor('SELECT id FROM area WHERE id = ? AND id_sucursal = ? AND activa = 1', [$id, $sucursal]) === null) {
            throw Errores::noEncontrado('Área no disponible');
        }
    }

    private function existeMesa(int $sucursal, int $id): void
    {
        if ($this->bd->valor('SELECT id FROM mesa WHERE id = ? AND id_sucursal = ? AND activa = 1', [$id, $sucursal]) === null) {
            throw Errores::noEncontrado('Mesa no disponible');
        }
    }
}
