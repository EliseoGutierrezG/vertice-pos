<?php
declare(strict_types=1);

namespace Servicios;

use Closure;
use Nucleo\BaseDatos;
use Nucleo\Configuracion;
use Nucleo\CerrojoActualizacion;
use Nucleo\Seguridad\FirmaLiberacion;
use PharData;
use RuntimeException;
use Throwable;

/**
 * Lo que mantiene al día el código de la computadora de sucursal
 * (`docs/servidor-sucursal.md`, «Actualizaciones»).
 *
 * La computadora pregunta al central qué versión le toca, la baja (reanudable),
 * comprueba la firma con la llave del código que **ya tiene** y la instala solo
 * cuando no hay cuentas ni turno abiertos. Nadie entra al local.
 *
 * Las versiones viven lado a lado y `actual` apunta a la instalada:
 *
 *   <base>/liberaciones/<id>/     el código de cada versión, sin tocarse
 *   <base>/actual                 enlace a la instalada
 *   <base>/compartido/config/     la configuración de esta computadora
 *   <base>/compartido/almacenamiento/
 *   <base>/compartido/descargas/  paquetes bajados o a medio bajar
 *   <base>/compartido/recarga     señal para que Apache recargue
 *
 * Instalar es: respaldo, extraer, enlazar lo compartido, migrar la base,
 * rehacer los disparadores y mover `actual`. Si la versión nueva no arranca,
 * `actual` regresa a la anterior: las migraciones solo agregan, así que el
 * código anterior sigue sirviendo con la base migrada.
 */
final class Actualizador
{
    /** Versiones que se guardan además de la instalada, para regresar. */
    private const CONSERVA = 2;

    /** Minutos sin movimiento que cuentan como local cerrado. */
    public const QUIETO_MINUTOS = 30;

    private Closure $ejecuta;

    /**
     * @param (Closure(list<string>):array{0:int,1:string})|null $ejecuta Corre un
     *        guion de PHP y devuelve su código de salida y su salida; las
     *        pruebas lo reemplazan.
     */
    public function __construct(
        private string $base,
        private ?BaseDatos $bd = null,
        private ?ClienteCentral $central = null,
        ?Closure $ejecuta = null,
        private ?Closure $hora = null
    ) {
        $this->ejecuta = $ejecuta ?? self::corre(...);
    }

    /** La carpeta base si este código corre dentro de `liberaciones/<id>`; si no, null. */
    public static function baseDe(string $raiz): ?string
    {
        $raiz = realpath($raiz) ?: $raiz;

        return basename(dirname($raiz)) === 'liberaciones' ? dirname($raiz, 2) : null;
    }

    /** La carpeta de una versión: el id sin los dos puntos de la hora. */
    public static function carpeta(string $id): string
    {
        return str_replace(':', '_', $id);
    }

    /** El id de la versión instalada, o null si todavía no hay ninguna. */
    public function instalada(): ?string
    {
        $actual = $this->base . '/actual';
        if (!is_link($actual) || !is_dir($actual)) {
            return null;
        }

        return Configuracion::liberacion((string) realpath($actual))['id'];
    }

    /**
     * Un ciclo completo: preguntar, bajar, esperar el horario seguro e
     * instalar. Devuelve lo que pasó y se lo cuenta al central.
     */
    public function ciclo(): string
    {
        $candado = fopen($this->compartido() . '/consulta-actualizacion.candado', 'c');
        if ($candado === false) {
            throw new RuntimeException('No se pudo abrir el candado de actualización');
        }
        if (!flock($candado, LOCK_EX | LOCK_NB)) {
            fclose($candado);
            return 'Ya hay una descarga o actualización en curso.';
        }
        try {
            return $this->ejecutaCiclo();
        } finally {
            CerrojoActualizacion::libera($candado);
        }
    }

    private function ejecutaCiclo(): string
    {
        if ($this->central === null) {
            throw new RuntimeException('El ciclo necesita al central');
        }
        $asignada = $this->central->llama('GET', '/liberacion')['asignada'] ?? null;
        $instalada = $this->instalada();
        if (!is_array($asignada) || $asignada['id'] === $instalada) {
            return 'Al día.';
        }
        $llave = FirmaLiberacion::publicaDe((string) realpath($this->base . '/actual'));
        if ($llave === null) {
            return $this->reporta('Falta la llave de firma; no se actualiza.', true);
        }
        if (!FirmaLiberacion::verifica($asignada, $llave)) {
            return $this->reporta('La versión ' . $asignada['id'] . ' no trae una firma válida.', true);
        }
        $paquete = $this->descargas() . '/' . self::carpeta($asignada['id']) . '.tar.gz';
        if (!is_file($paquete)) {
            $this->reporta('Bajando la versión ' . $asignada['id'] . '.', false);
            if (!$this->central->descarga('/liberacion/paquete?id=' . rawurlencode($asignada['id']), $paquete, (int) $asignada['peso'])) {
                return 'Bajando la versión ' . $asignada['id'] . '; sigue en el próximo intento.';
            }
        }
        try {
            FirmaLiberacion::verificaPaquete($asignada, $paquete, $llave);
        } catch (RuntimeException $e) {
            @unlink($paquete);
            return $this->reporta('Se tiró la descarga de ' . $asignada['id'] . ': ' . $e->getMessage() . '.', true);
        }
        $espera = $this->esperaPor();
        if ($espera !== null) {
            return $this->reporta('Versión ' . $asignada['id'] . ' lista. ' . $espera, false);
        }
        try {
            $this->instala($paquete, $asignada, $llave);
        } catch (Throwable $e) {
            return $this->reporta('No se instaló ' . $asignada['id'] . ': ' . mb_substr($e->getMessage(), 0, 120), true);
        }
        @unlink($paquete);

        return $this->reporta('Instalada ' . $asignada['id'] . '.', false, true);
    }

    /**
     * Null si se puede instalar ya; si no, por qué se espera. Nunca a media
     * operación: sin cuentas ni turno abiertos, y además de madrugada o tras
     * un rato sin movimiento.
     */
    public function esperaPor(): ?string
    {
        if ($this->bd === null) {
            throw new RuntimeException('El horario seguro necesita la base');
        }
        if ($this->bd->valor('SELECT 1 FROM cuenta WHERE abierta = 1 LIMIT 1') !== null) {
            return 'Espera a que cierren las cuentas.';
        }
        if ($this->bd->valor('SELECT 1 FROM turno_caja WHERE abierto = 1 LIMIT 1') !== null) {
            return 'Espera el corte de caja.';
        }
        $hora = $this->hora !== null ? ($this->hora)() : (int) date('G');
        if ($hora >= 3 && $hora < 5) {
            return null;
        }
        $quieto = $this->bd->valor('SELECT 1 FROM bitacora WHERE momento > NOW() - INTERVAL ' . self::QUIETO_MINUTOS . ' MINUTE LIMIT 1') === null;

        return $quieto ? null : 'Espera ' . self::QUIETO_MINUTOS . ' minutos sin movimiento.';
    }

    /**
     * Instala un paquete ya verificado. Con `$migrar` en false (la primera
     * instalación, cuando la base todavía no existe) solo extrae, enlaza y
     * mueve `actual`.
     *
     * @param array<string,mixed> $descriptor
     */
    public function instala(string $paquete, array $descriptor, string $llavePublica, bool $migrar = true): void
    {
        FirmaLiberacion::verificaPaquete($descriptor, $paquete, $llavePublica);
        $candado = fopen($this->compartido() . '/actualiza.candado', 'c');
        if ($candado === false || !flock($candado, LOCK_EX | LOCK_NB)) {
            if (is_resource($candado)) { fclose($candado); }
            throw new RuntimeException('Ya hay otra actualización en curso');
        }
        $operacion = null;
        try {
            if ($migrar) {
                $operacion = fopen($this->compartido() . '/operacion.candado', 'c');
                if ($operacion === false || !flock($operacion, LOCK_EX | LOCK_NB)) {
                    throw new RuntimeException('Hay operaciones en curso; se intentará después');
                }
                // Revalidar después de cerrar la entrada: pudo abrirse una
                // cuenta entre la descarga y la adquisición del candado.
                if ($this->bd !== null && ($espera = $this->esperaPor()) !== null) {
                    throw new RuntimeException($espera);
                }
            }
            $id = (string) $descriptor['id'];
            $anterior = $this->instalada();
            $destino = $this->extrae($paquete, $id, (int) $descriptor['esquema']);
            $this->enlazaCompartido($destino);
            if ($migrar) {
                $this->migra($destino);
            }
            $this->apuntaA(self::carpeta($id));
            try {
                $this->pideRecarga();
                // Sin base todavía (la primera instalación) no hay con qué comprobar.
                [$codigo, $salida] = $migrar ? ($this->ejecuta)([$this->base . '/actual/guiones/actualiza.php', '--comprueba=' . $id]) : [0, ''];
                if ($codigo !== 0) {
                    throw new RuntimeException(trim(mb_substr($salida, -160)));
                }
            } catch (Throwable $e) {
                if ($anterior !== null) {
                    $this->apuntaA(self::carpeta($anterior));
                    $this->pideRecarga();
                    [$regreso] = ($this->ejecuta)([$this->base . '/actual/guiones/actualiza.php', '--comprueba=' . $anterior]);
                    if ($regreso !== 0) {
                        throw new RuntimeException('El enlace volvió a la anterior, pero su salud web aún no responde', 0, $e);
                    }
                }
                throw new RuntimeException('la versión nueva no arrancó (' . $e->getMessage() . '); se regresó a la anterior', 0, $e);
            }
            $this->limpia();
        } finally {
            CerrojoActualizacion::libera($operacion);
            flock($candado, LOCK_UN);
            fclose($candado);
        }
    }

    /** Extrae el paquete en `liberaciones/<id>` y comprueba que sea esa versión. */
    private function extrae(string $paquete, string $id, int $esquema): string
    {
        $liberaciones = $this->base . '/liberaciones';
        if (!is_dir($liberaciones) && !mkdir($liberaciones, 0775, true) && !is_dir($liberaciones)) {
            throw new RuntimeException('No se pudo crear la carpeta de versiones');
        }
        $destino = $liberaciones . '/' . self::carpeta($id);
        $actual = realpath($this->base . '/actual') ?: '';
        if ($actual === (realpath($destino) ?: '-')) {
            throw new RuntimeException('Esa versión ya es la instalada');
        }
        self::borra($destino);
        $temporal = $destino . '.extrae-' . bin2hex(random_bytes(3));
        // PharData decide el formato por la extensión.
        $copia = $temporal . '.tar.gz';
        if (!mkdir($temporal, 0775) || !copy($paquete, $copia)) {
            throw new RuntimeException('No se pudo preparar la extracción');
        }
        try {
            (new PharData($copia))->extractTo($temporal, null, true);
        } finally {
            @unlink($copia);
        }
        if (!is_dir($temporal . '/timon') || !rename($temporal . '/timon', $destino)) {
            self::borra($temporal);
            throw new RuntimeException('El paquete no trae la carpeta timon/');
        }
        self::borra($temporal);
        $liberacion = Configuracion::liberacion($destino);
        if ($liberacion['id'] !== $id || $liberacion['esquema'] !== $esquema) {
            self::borra($destino);
            throw new RuntimeException('El paquete trae otra versión que la firmada');
        }

        return $destino;
    }

    /**
     * La configuración y el almacenamiento son de esta computadora, no de la
     * versión: se enlazan. Lo que el paquete ya trae en `config/` (el giro, la
     * llave pública, `liberacion.php`) se queda como viene.
     */
    private function enlazaCompartido(string $destino): void
    {
        $config = $this->compartido() . '/config';
        foreach (glob($config . '/*.php') ?: [] as $archivo) {
            $enlace = $destino . '/config/' . basename($archivo);
            if (!file_exists($enlace) && !is_link($enlace) && !symlink('../../../compartido/config/' . basename($archivo), $enlace)) {
                throw new RuntimeException('No se pudo enlazar ' . basename($archivo));
            }
        }
        self::borra($destino . '/almacenamiento');
        if (!symlink('../../compartido/almacenamiento', $destino . '/almacenamiento')) {
            throw new RuntimeException('No se pudo enlazar el almacenamiento');
        }
    }

    /** Respaldo con el código de ahora, migraciones y disparadores con el nuevo. */
    private function migra(string $destino): void
    {
        $actual = realpath($this->base . '/actual');
        if ($actual === false) {
            throw new RuntimeException('No hay versión instalada para respaldar');
        }
        $antes = time();
        [$codigo, $salida] = ($this->ejecuta)([$actual . '/guiones/respaldo.php', '--cifrar']);
        $respaldos = array_filter(glob($this->compartido() . '/almacenamiento/respaldos/*.sql*') ?: [],
            static fn (string $r): bool => is_file($r) && filemtime($r) >= $antes - 5 && filesize($r) > 0);
        if ($codigo !== 0 || $respaldos === []) {
            throw new RuntimeException('el respaldo falló: ' . trim(mb_substr($salida, -120)));
        }
        usort($respaldos, static fn (string $a, string $b): int => filemtime($b) <=> filemtime($a));
        $base = Configuracion::baseDatos($destino)['base'];
        foreach ([
            [$destino . '/guiones/migraciones.php', '--aplicar', '--acepto=' . $base, '--respaldo-verificado=' . $respaldos[0]],
            [$destino . '/guiones/disparadores-replica.php'],
        ] as $orden) {
            [$codigo, $salida] = ($this->ejecuta)($orden);
            if ($codigo !== 0) {
                throw new RuntimeException(basename($orden[0]) . ' falló: ' . trim(mb_substr($salida, -120)));
            }
        }
    }

    /** Mueve `actual` de un solo golpe: un enlace nuevo que reemplaza al otro. */
    private function apuntaA(string $carpeta): void
    {
        $nuevo = $this->base . '/actual.nuevo';
        @unlink($nuevo);
        if (!symlink('liberaciones/' . $carpeta, $nuevo) || !rename($nuevo, $this->base . '/actual')) {
            throw new RuntimeException('No se pudo cambiar de versión');
        }
        clearstatcache(true);
    }

    private function pideRecarga(): void
    {
        if (file_put_contents($this->compartido() . '/recarga', bin2hex(random_bytes(16)), LOCK_EX) === false) {
            throw new RuntimeException('No se pudo pedir la recarga del servidor web');
        }
    }

    /** Deja la instalada y las `CONSERVA` más recientes. */
    private function limpia(): void
    {
        $actual = realpath($this->base . '/actual');
        $otras = array_filter(glob($this->base . '/liberaciones/*', GLOB_ONLYDIR) ?: [],
            static fn (string $d): bool => realpath($d) !== $actual);
        usort($otras, static fn (string $a, string $b): int => filemtime($b) <=> filemtime($a));
        foreach (array_slice($otras, self::CONSERVA) as $vieja) {
            self::borra($vieja);
        }
    }

    private function reporta(string $estado, bool $error, bool $aplicada = false): string
    {
        try {
            $this->central?->llama('POST', '/actualizacion', ['estado' => $estado, 'error' => $error, 'aplicada' => $aplicada]);
        } catch (Throwable) {
            // Sin internet se reporta en el próximo ciclo; la actualización no depende de eso.
        }

        return $estado;
    }

    private function compartido(): string
    {
        return $this->base . '/compartido';
    }

    private function descargas(): string
    {
        $carpeta = $this->compartido() . '/descargas';
        if (!is_dir($carpeta) && !mkdir($carpeta, 0770, true) && !is_dir($carpeta)) {
            throw new RuntimeException('No se pudo crear la carpeta de descargas');
        }

        return $carpeta;
    }

    /**
     * @param list<string> $argumentos
     * @return array{0:int,1:string}
     */
    private static function corre(array $argumentos): array
    {
        $proceso = proc_open([PHP_BINARY, ...$argumentos], [1 => ['pipe', 'w'], 2 => ['redirect', 1]], $tubos);
        if (!is_resource($proceso)) {
            return [1, 'no se pudo correr ' . basename($argumentos[0])];
        }
        $salida = (string) stream_get_contents($tubos[1]);
        fclose($tubos[1]);

        return [proc_close($proceso), $salida];
    }

    /** Borra una carpeta o un enlace. No sigue enlaces: nunca borra lo compartido. */
    private static function borra(string $ruta): void
    {
        if (is_link($ruta) || is_file($ruta)) {
            unlink($ruta);
            return;
        }
        if (!is_dir($ruta)) {
            return;
        }
        foreach (scandir($ruta) ?: [] as $nombre) {
            if ($nombre !== '.' && $nombre !== '..') {
                self::borra($ruta . '/' . $nombre);
            }
        }
        rmdir($ruta);
    }
}
