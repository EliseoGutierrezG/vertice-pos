<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Exporta\Tabla;

/**
 * La revisión periódica de quién puede hacer qué.
 *
 * Un permiso que nadie revisa se queda para siempre. Esto no decide nada: junta las
 * cuentas, los accesos con caducidad y las combinaciones que una sola persona no
 * debería tener, y deja constancia de quién lo revisó y cuándo.
 */
final class RevisionAccesos
{
    /** Permisos que juntos permiten hacer algo y aprobarlo uno mismo. */
    private const CONFLICTOS = [
        ['transferencias_captura', 'transferencias_autoriza', 'Crea y autoriza transferencias'],
        ['compras_ordenes', 'compras_valida', 'Ordena y valida compras'],
        ['conteos_captura', 'conteos_autoriza', 'Captura y autoriza conteos físicos'],
        ['caja_opera', 'caja_supervisa', 'Opera y supervisa la caja'],
        ['caja_opera', 'caja_movimientos_autoriza', 'Opera la caja y autoriza sus movimientos'],
    ];

    public function __construct(private BaseDatos $bd, private Bitacora $bitacora)
    {
    }

    /**
     * @return array{
     *   cuentas:list<array<string,mixed>>,
     *   conflictos:list<array{conflicto:string,puesto:string,personas:int}>,
     *   revisiones:list<array<string,mixed>>
     * }
     */
    public function reporte(): array
    {
        return [
            'cuentas' => $this->cuentas(),
            'conflictos' => $this->conflictos(),
            'revisiones' => $this->bd->filas(
                'SELECT r.revisado_en, r.usuarios, r.conflictos, r.nota, u.usuario
                 FROM revision_acceso r JOIN usuario u ON u.id = r.revisado_por
                 ORDER BY r.id DESC LIMIT 10'
            ),
        ];
    }

    public function tabla(): Tabla
    {
        $filas = array_map(static fn (array $c): array => [
            (string) $c['usuario'], (string) $c['nombre'], (string) $c['puesto'], (string) ($c['sucursal'] ?? 'Todas'),
            (int) $c['id_estatus'] === 4 ? 'Activa' : 'Inactiva',
            $c['totp_confirmado_en'] === null ? 'No' : 'Sí',
            (string) ($c['ultimo_telefono'] ?? ''), (string) ($c['acceso_hasta'] ?? ''), (string) ($c['acceso_motivo'] ?? ''),
        ], $this->cuentas());

        return new Tabla(
            'Revisión de accesos',
            ['Usuario', 'Nombre', 'Puesto', 'Sucursal', 'Cuenta', 'Authenticator', 'Último uso del teléfono', 'Acceso hasta', 'Motivo'],
            $filas,
            [],
            'Al ' . date('Y-m-d H:i')
        );
    }

    public function registra(string $nota, int $idUsuario, string $ip): void
    {
        $nota = trim($nota);
        if (mb_strlen($nota) < 10) {
            throw Errores::datosInvalidos(['nota' => 'Anote qué revisó y qué concluyó']);
        }
        if (mb_strlen($nota) > 500) {
            throw Errores::datosInvalidos(['nota' => 'Use hasta 500 caracteres']);
        }

        $cuentas = count(array_filter($this->cuentas(), static fn (array $c): bool => (int) $c['id_estatus'] === 4));
        $conflictos = count($this->conflictos());

        $this->bd->transaccion(function () use ($nota, $idUsuario, $ip, $cuentas, $conflictos): void {
            $id = $this->bd->inserta(
                'INSERT INTO revision_acceso (revisado_por, usuarios, conflictos, nota) VALUES (?, ?, ?, ?)',
                [$idUsuario, $cuentas, $conflictos, $nota]
            );
            $this->bitacora->registra(
                'seguridad',
                'revisa_accesos',
                'revision_acceso',
                $id,
                despues: ['usuarios' => $cuentas, 'conflictos' => $conflictos, 'nota' => $nota],
                idUsuario: $idUsuario,
                ip: $ip
            );
        });
    }

    /** @return list<array<string,mixed>> */
    private function cuentas(): array
    {
        return $this->bd->filas(
            "SELECT u.id, p.id AS id_personal, u.usuario, u.id_estatus, u.totp_confirmado_en, u.acceso_hasta, u.acceso_motivo,
                    TRIM(CONCAT(p.nombre, ' ', p.apellido_paterno)) AS nombre, pu.nombre AS puesto, b.nombre AS sucursal,
                    (SELECT MAX(d.ultimo_acceso) FROM dispositivo d WHERE d.id_usuario = u.id) AS ultimo_telefono
             FROM usuario u
             JOIN personal p ON p.id = u.id_personal
             JOIN puesto pu ON pu.id = p.id_puesto
             LEFT JOIN sucursal b ON b.id = p.id_sucursal
             ORDER BY pu.nombre, u.id DESC"
        );
    }

    /** @return list<array{conflicto:string,puesto:string,personas:int}> */
    private function conflictos(): array
    {
        $hallados = [];
        foreach (self::CONFLICTOS as [$uno, $otro, $texto]) {
            $filas = $this->bd->filas(
                'SELECT pu.nombre AS puesto,
                        (SELECT COUNT(*) FROM personal pe JOIN usuario u ON u.id_personal = pe.id
                         WHERE pe.id_puesto = pu.id AND u.id_estatus = 4) AS personas
                 FROM puesto pu
                 WHERE pu.id_estatus = 4
                   AND EXISTS (SELECT 1 FROM puesto_permiso x JOIN permiso y ON y.id = x.id_permiso WHERE x.id_puesto = pu.id AND y.clave = ?)
                   AND EXISTS (SELECT 1 FROM puesto_permiso x JOIN permiso y ON y.id = x.id_permiso WHERE x.id_puesto = pu.id AND y.clave = ?)
                 ORDER BY pu.nombre',
                [$uno, $otro]
            );
            foreach ($filas as $fila) {
                $hallados[] = ['conflicto' => $texto, 'puesto' => (string) $fila['puesto'], 'personas' => (int) $fila['personas']];
            }
        }

        return $hallados;
    }
}
