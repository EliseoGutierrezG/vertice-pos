<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Configuracion;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;
use Nucleo\Instalacion;

/**
 * Los servidores de sucursal que conoce el central: registrarlos, saber cómo
 * van y regresar una sucursal a operar en el central.
 *
 * Registrar un servidor pasa la sucursal a `local`: desde ese momento el
 * central deja de escribir su operación (`exigeOperaAqui`).
 */
final class Instalaciones
{
    /** Minutos sin noticias después de los cuales el panel avisa. */
    public const SIN_NOTICIAS = 30;

    public function __construct(
        private BaseDatos $bd,
        private Bitacora $bitacora,
        private Identidad $identidad,
        private Instalacion $instalacion
    ) {
    }

    /**
     * Registra el servidor de una sucursal. El secreto se muestra una sola
     * vez: aquí solo queda su SHA-256.
     *
     * @return array{id:int, desplazamiento:int, secreto:string}
     */
    public function registra(int $sucursal, string $nombre): array
    {
        if (!$this->instalacion->esCentral()) {
            throw Errores::conflicto('Primero configure el central para la operación local.');
        }
        $nombre = trim($nombre);
        if ($nombre === '' || mb_strlen($nombre) > 80) {
            throw Errores::datosInvalidos(['nombre' => 'Capture un nombre de hasta 80 letras']);
        }

        return $this->bd->transaccion(function () use ($sucursal, $nombre): array {
            $fila = $this->bd->fila('SELECT id, servidor FROM sucursal WHERE id = ? FOR UPDATE', [$sucursal]);
            if ($fila === null) {
                throw Errores::datosInvalidos(['sucursal' => 'Seleccione una sucursal']);
            }
            if ($this->bd->valor('SELECT id FROM instalacion WHERE id_sucursal = ?', [$sucursal]) !== null) {
                throw Errores::conflicto('Esa sucursal ya tiene su computadora registrada.');
            }
            if ($this->bd->valor('SELECT id FROM cuenta WHERE id_sucursal = ? AND abierta = 1 LIMIT 1', [$sucursal]) !== null
                || $this->bd->valor('SELECT id FROM turno_caja WHERE id_sucursal = ? AND abierto = 1 LIMIT 1', [$sucursal]) !== null) {
                throw Errores::conflicto('Primero cierre las cuentas y el turno de caja.');
            }
            $ocupados = array_map('intval', array_column($this->bd->filas('SELECT desplazamiento FROM instalacion'), 'desplazamiento'));
            $libre = null;
            for ($d = 2; $d < Configuracion::INCREMENTO_IDS; $d++) {
                if (!in_array($d, $ocupados, true)) {
                    $libre = $d;
                    break;
                }
            }
            if ($libre === null) {
                throw Errores::conflicto('Ya no hay desplazamientos libres.');
            }
            $secreto = bin2hex(random_bytes(32));
            $id = $this->bd->inserta('INSERT INTO instalacion (nombre, id_sucursal, desplazamiento, secreto_hash, creado_por) VALUES (?, ?, ?, ?, ?)',
                [$nombre, $sucursal, $libre, hash('sha256', $secreto), $this->identidad->id()]);
            $this->bd->ejecuta('UPDATE sucursal SET servidor = ? WHERE id = ?', ['local', $sucursal]);
            $this->bitacora->registra('replica', 'registra_servidor', 'instalacion', $id,
                despues: ['sucursal' => $sucursal, 'nombre' => $nombre, 'desplazamiento' => $libre], idUsuario: $this->identidad->id());

            return ['id' => $id, 'desplazamiento' => $libre, 'secreto' => $secreto];
        });
    }

    /**
     * Regresa la sucursal a operar en el central, por ejemplo si su servidor
     * se descompone. Solo si ya no quedaba nada por subir.
     */
    public function regresaAlCentral(int $id, bool $aunConPendientes = false): void
    {
        $this->bd->transaccion(function () use ($id, $aunConPendientes): void {
            $fila = $this->bd->fila('SELECT id, id_sucursal, pendientes, activa FROM instalacion WHERE id = ? FOR UPDATE', [$id]);
            if ($fila === null || (int) $fila['activa'] !== 1) {
                throw Errores::noEncontrado();
            }
            if ((int) $fila['pendientes'] > 0 && !$aunConPendientes) {
                throw Errores::conflicto('Quedan cambios por subir. Espere a que suban.');
            }
            $this->bd->ejecuta('UPDATE instalacion SET activa = 0 WHERE id = ?', [$id]);
            $this->bd->ejecuta('UPDATE sucursal SET servidor = ? WHERE id = ?', ['central', $fila['id_sucursal']]);
            $this->bitacora->registra('replica', 'regresa_central', 'instalacion', $id,
                despues: ['sucursal' => (int) $fila['id_sucursal'], 'pendientes' => (int) $fila['pendientes']], idUsuario: $this->identidad->id());
        });
    }

    /**
     * La instalación activa de ese secreto, o null.
     *
     * @return array{id:int,id_sucursal:int,nombre:string,desplazamiento:int}|null
     */
    public function autentica(string $secreto): ?array
    {
        $fila = $this->bd->fila(
            "SELECT i.id, i.id_sucursal, i.nombre, i.desplazamiento FROM instalacion i
               JOIN sucursal s ON s.id = i.id_sucursal AND s.servidor = 'local'
              WHERE i.secreto_hash = ? AND i.activa = 1", [hash('sha256', $secreto)]);

        return $fila === null ? null : [
            'id' => (int) $fila['id'], 'id_sucursal' => (int) $fila['id_sucursal'],
            'nombre' => (string) $fila['nombre'], 'desplazamiento' => (int) $fila['desplazamiento'],
        ];
    }

    /** Lo que reporta el servidor en cada contacto. */
    public function anota(int $id, string $campo, int $pendientes, string $version, string $error = ''): void
    {
        $columna = match ($campo) {
            'subida' => 'UPDATE instalacion SET ultima_subida = NOW(), pendientes = ?, version = ?, ultimo_error = ? WHERE id = ?',
            'bajada' => 'UPDATE instalacion SET ultima_bajada = NOW(), pendientes = ?, version = ?, ultimo_error = ? WHERE id = ?',
            'error' => 'UPDATE instalacion SET pendientes = ?, version = ?, ultimo_error = ? WHERE id = ?',
        };
        // Fuera de la transacción del lote: el error queda aunque el lote se deshaga.
        $this->bd->independiente()->ejecuta($columna, [$pendientes, mb_substr($version, 0, 100), mb_substr($error, 0, 300), $id]);
    }

    /** @return list<array<string,mixed>> */
    public function lista(): array
    {
        return $this->bd->filas(
            'SELECT s.id AS id_sucursal, s.nombre AS sucursal, s.servidor, i.id, i.nombre, i.desplazamiento, i.activa,
                    i.version, i.ultima_subida, i.ultima_bajada, i.pendientes, i.ultimo_error,
                    i.liberacion_asignada, i.actualizacion, i.actualizacion_error, i.actualizada_en,
                    (i.id IS NOT NULL AND i.activa = 1 AND (GREATEST(COALESCE(i.ultima_subida, 0), COALESCE(i.ultima_bajada, 0))
                       < NOW() - INTERVAL ' . self::SIN_NOTICIAS . ' MINUTE)) AS sin_noticias
               FROM sucursal s LEFT JOIN instalacion i ON i.id_sucursal = s.id AND i.activa = 1
              WHERE s.id_estatus = 4 ORDER BY s.nombre');
    }

    /**
     * Falla si la operación de esa sucursal no se escribe en este servidor:
     * en el central, una sucursal `local`; en un servidor de sucursal, otra
     * sucursal que no es la suya.
     */
    public function exigeOperaAqui(int $sucursal): void
    {
        if ($this->instalacion->esSucursal()) {
            if ($sucursal !== $this->instalacion->idSucursal()) {
                throw Errores::conflicto('Esta computadora solo opera su sucursal.');
            }
            return;
        }
        if ($this->bd->valor('SELECT 1 FROM sucursal WHERE id = ? AND servidor = ?', [$sucursal, 'local']) !== null) {
            throw Errores::conflicto('Esta sucursal opera en su computadora. Hágalo desde ahí.');
        }
    }

    /** Falla en un servidor de sucursal: el catálogo se cambia en el central. */
    public function exigeCatalogoAqui(): void
    {
        if ($this->instalacion->esSucursal()) {
            throw Errores::conflicto('Esto se cambia en el panel central.');
        }
    }
}
