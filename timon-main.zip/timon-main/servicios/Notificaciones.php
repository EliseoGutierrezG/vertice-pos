<?php
declare(strict_types=1);

namespace Servicios;

use Closure;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;
use Throwable;

/**
 * Cola auditable y envío inmediato por Expo Push.
 *
 * `envia()` manda a un teléfono; desde el 2026-11-08 (C5) `enviaAviso()`
 * manda un mismo aviso a una persona, un puesto, una sucursal o a
 * todos, en tandas de 100 como pide Expo.
 */
final class Notificaciones
{
    /** @var Closure(array<string,mixed>):array<string,mixed>|null */
    private ?Closure $transportador=null;

    public function __construct(
        private BaseDatos $bd,
        private Identidad $identidad,
        private Bitacora $bitacora
    ){}

    /** @param Closure(array<string,mixed>):array<string,mixed> $transportador */
    public static function paraPruebas(BaseDatos $bd,Identidad $identidad,Bitacora $bitacora,Closure $transportador):self
    {
        $servicio=new self($bd,$identidad,$bitacora);$servicio->transportador=$transportador;return $servicio;
    }

    /** @param array<string,mixed> $datos */
    public function envia(int $idDispositivo,string $titulo,string $cuerpo,array $datos,string $ip):int
    {
        $titulo=trim($titulo);$cuerpo=trim($cuerpo);
        if($titulo===''||mb_strlen($titulo)>80)throw Errores::datosInvalidos(['titulo'=>'Capture un título de hasta 80 caracteres']);
        if($cuerpo===''||mb_strlen($cuerpo)>255)throw Errores::datosInvalidos(['cuerpo'=>'Capture un mensaje de hasta 255 caracteres']);
        $telefono=$this->bd->fila(
            'SELECT d.id,d.id_usuario,d.token_push,d.autorizado,pe.id_sucursal
             FROM dispositivo d JOIN usuario u ON u.id=d.id_usuario JOIN personal pe ON pe.id=u.id_personal
             WHERE d.id=?',[$idDispositivo]
        );
        if($telefono===null)throw Errores::noEncontrado('El teléfono no existe');
        if(!$this->identidad->esAdministrador())$this->identidad->exigeSucursal((int)$telefono['id_sucursal']);
        if((int)$telefono['autorizado']!==1||!is_string($telefono['token_push'])||$telefono['token_push']===''){
            throw Errores::conflicto('Teléfono sin autorizar o sin avisos');
        }
        $id=$this->bd->inserta(
            'INSERT INTO notificacion(id_usuario,id_dispositivo,titulo,cuerpo,datos,creado_por)VALUES(?,?,?,?,?,?)',
            [(int)$telefono['id_usuario'],(int)$telefono['id'],$titulo,$cuerpo,json_encode($datos,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$this->identidad->id()]
        );
        $mensaje=['to'=>(string)$telefono['token_push'],'sound'=>'default','title'=>$titulo,'body'=>$cuerpo,'data'=>$datos];
        try{
            $respuesta=($this->transportador??fn(array $m):array=>$this->enviaExpo($m))($mensaje);
            $resultado=$respuesta['data']??null;
            if(isset($resultado[0])&&is_array($resultado[0]))$resultado=$resultado[0];
            if(!is_array($resultado)||($resultado['status']??null)!=='ok'){
                $detalle=is_array($resultado)?(string)($resultado['message']??'El aviso no se envió. Intente de nuevo'):'El aviso no se envió. Intente de nuevo';
                throw new ErrorHttp(503,$detalle,'push_rechazado');
            }
            $this->bd->ejecuta('UPDATE notificacion SET enviado_en=NOW(),error=NULL WHERE id=?',[$id]);
            $this->bitacora->registra('notificaciones','envia','notificacion',$id,despues:['id_dispositivo'=>$idDispositivo],idUsuario:$this->identidad->id(),ip:$ip);
            return $id;
        }catch(Throwable $e){
            $mensajeError=mb_substr($e->getMessage(),0,255);
            $this->bd->ejecuta('UPDATE notificacion SET error=? WHERE id=?',[$mensajeError,$id]);
            if($e instanceof ErrorHttp)throw $e;
            throw new ErrorHttp(503,'El aviso no se envió. Intente de nuevo','push_no_disponible');
        }
    }

    /** Los destinos de un aviso, en el orden en que se ofrecen. */
    public const DESTINOS = ['todos' => 'Todos', 'sucursal' => 'Sucursal', 'puesto' => 'Puesto', 'persona' => 'Persona'];

    /** Lo que Expo acepta en una sola petición. */
    public const TANDA = 100;

    /**
     * A quién se le puede mandar un aviso, con cuántas personas y teléfonos
     * hay en cada destino: es la vista previa del formulario. Solo cuentan los
     * teléfonos autorizados, con avisos activos, de personal activo y dentro
     * del alcance de sucursal de quien envía.
     *
     * @return list<array{valor:string,tipo:string,texto:string,personas:int,telefonos:int}>
     */
    public function opcionesAviso(): array
    {
        $telefonos = $this->telefonosListos();
        $grupos = ['todos' => ['' => ['Todos', []]], 'sucursal' => [], 'puesto' => [], 'persona' => []];
        foreach ($telefonos as $t) {
            $u = (int) $t['id_usuario'];
            $grupos['todos'][''][1][$u][] = (int) $t['id'];
            $grupos['puesto'][(string) $t['id_puesto']][0] = (string) $t['puesto'];
            $grupos['puesto'][(string) $t['id_puesto']][1][$u][] = (int) $t['id'];
            $grupos['persona'][(string) $u][0] = (string) $t['persona'];
            $grupos['persona'][(string) $u][1][$u][] = (int) $t['id'];
            if ($t['id_sucursal'] !== null) {
                $grupos['sucursal'][(string) $t['id_sucursal']][0] = (string) $t['sucursal'];
                $grupos['sucursal'][(string) $t['id_sucursal']][1][$u][] = (int) $t['id'];
            }
        }
        $opciones = [];
        foreach ($grupos as $tipo => $destinos) {
            uasort($destinos, static fn (array $a, array $b): int => strcmp((string) $a[0], (string) $b[0]));
            foreach ($destinos as $id => [$nombre, $porUsuario]) {
                $total = array_sum(array_map(static fn (array $ids): int => count(array_unique($ids)), $porUsuario));
                if ($total === 0) continue;
                $opciones[] = [
                    'valor' => $tipo . ($id === '' ? '' : ':' . $id), 'tipo' => $tipo,
                    'texto' => (string) $nombre, 'personas' => count($porUsuario), 'telefonos' => $total,
                ];
            }
        }
        return $opciones;
    }

    /**
     * Los teléfonos de un destino (`todos`, `puesto:3`, `sucursal:2`…) y el nombre
     * del destino como se ve hoy. Un destino fuera del alcance o sin nadie no
     * existe para quien envía.
     *
     * @return array{tipo:string,id:?int,nombre:string,telefonos:list<array<string,mixed>>}
     */
    public function destinatarios(string $destino): array
    {
        [$tipo, $id] = array_pad(explode(':', trim($destino), 2), 2, '');
        if (!isset(self::DESTINOS[$tipo]) || ($tipo === 'todos') !== ($id === '')
            || ($id !== '' && preg_match('/^[1-9]\d{0,9}$/', $id) !== 1)) {
            throw Errores::datosInvalidos(['destino' => 'Seleccione a quién mandar el aviso']);
        }
        $id = $id === '' ? null : (int) $id;
        foreach ($this->opcionesAviso() as $o) {
            if ($o['valor'] !== $destino) continue;
            $listos = $this->telefonosListos();
            $telefonos = array_values(array_filter($listos, static function (array $t) use ($tipo, $id): bool {
                $u = (int) $t['id_usuario'];
                return match ($tipo) {
                    'todos' => true,
                    'persona' => $u === $id,
                    'puesto' => (int) $t['id_puesto'] === $id,
                    'sucursal' => (int) ($t['id_sucursal'] ?? 0) === $id,
                };
            }));
            return ['tipo' => $tipo, 'id' => $id, 'nombre' => $o['texto'], 'telefonos' => $telefonos];
        }
        throw Errores::datosInvalidos(['destino' => 'Ese destino no tiene teléfonos con avisos']);
    }

    /**
     * Manda un aviso a todos los teléfonos de un destino. Primero queda el
     * registro (el aviso y una notificación por teléfono) y después se manda
     * en tandas de 100: si Expo rechaza o no contesta, la notificación guarda
     * el motivo y el aviso cuenta el fallido, sin deshacer lo demás.
     *
     * @param array<string,mixed> $datos `destino`, `titulo`, `cuerpo`
     * @return array{id:int,telefonos:int,aceptados:int,fallidos:int}
     */
    public function enviaAviso(array $datos, string $ip): array
    {
        $titulo = trim((string) ($datos['titulo'] ?? ''));
        $cuerpo = trim((string) ($datos['cuerpo'] ?? ''));
        if ($titulo === '' || mb_strlen($titulo) > 80) throw Errores::datosInvalidos(['titulo' => 'Capture un título de hasta 80 caracteres']);
        if ($cuerpo === '' || mb_strlen($cuerpo) > 255) throw Errores::datosInvalidos(['cuerpo' => 'Capture un mensaje de hasta 255 caracteres']);
        $destino = $this->destinatarios((string) ($datos['destino'] ?? ''));
        $telefonos = $destino['telefonos'];
        $personas = count(array_unique(array_column($telefonos, 'id_usuario')));

        [$idAviso, $notificaciones] = $this->bd->transaccion(function (BaseDatos $bd) use ($titulo, $cuerpo, $destino, $telefonos, $personas): array {
            $idAviso = $bd->inserta(
                'INSERT INTO aviso (titulo,cuerpo,destino_tipo,destino_id,destino_nombre,id_sucursal,personas,telefonos,creado_por)
                 VALUES (?,?,?,?,?,?,?,?,?)',
                [$titulo, $cuerpo, $destino['tipo'], $destino['id'], mb_substr($destino['nombre'], 0, 160),
                 $this->identidad->idSucursal(), $personas, count($telefonos), $this->identidad->id()]
            );
            $ids = [];
            foreach ($telefonos as $t) {
                $ids[] = $bd->inserta(
                    'INSERT INTO notificacion (id_usuario,id_aviso,id_dispositivo,titulo,cuerpo,datos,creado_por) VALUES (?,?,?,?,?,?,?)',
                    [(int) $t['id_usuario'], $idAviso, (int) $t['id'], $titulo, $cuerpo,
                     json_encode(['id_aviso' => $idAviso], JSON_UNESCAPED_UNICODE), $this->identidad->id()]
                );
            }
            return [$idAviso, $ids];
        });

        $aceptados = 0;
        $fallidos = 0;
        foreach (array_chunk(array_keys($telefonos), self::TANDA) as $tanda) {
            $mensajes = array_map(static fn (int $i): array => [
                'to' => (string) $telefonos[$i]['token_push'], 'sound' => 'default',
                'title' => $titulo, 'body' => $cuerpo, 'data' => ['id_aviso' => $idAviso],
            ], $tanda);
            try {
                $respuesta = ($this->transportador ?? fn (array $m): array => $this->enviaExpo($m))($mensajes);
                $boletos = $respuesta['data'] ?? null;
                if (!is_array($boletos) || !array_is_list($boletos)) throw new ErrorHttp(503, 'Expo no contestó la tanda', 'push_no_disponible');
            } catch (Throwable $e) {
                $boletos = array_fill(0, count($tanda), ['status' => 'error', 'message' => 'El aviso no se envió. Intente de nuevo']);
            }
            foreach ($tanda as $posicion => $i) {
                $boleto = $boletos[$posicion] ?? null;
                if (is_array($boleto) && ($boleto['status'] ?? null) === 'ok') {
                    $this->bd->ejecuta('UPDATE notificacion SET enviado_en=NOW(),error=NULL WHERE id=?', [$notificaciones[$i]]);
                    $aceptados++;
                } else {
                    $motivo = is_array($boleto) ? (string) ($boleto['message'] ?? 'Expo rechazó el aviso') : 'Expo no contestó por este teléfono';
                    $this->bd->ejecuta('UPDATE notificacion SET error=? WHERE id=?', [mb_substr($motivo, 0, 255), $notificaciones[$i]]);
                    $fallidos++;
                }
            }
        }
        $this->bd->ejecuta('UPDATE aviso SET aceptados=?,fallidos=? WHERE id=?', [$aceptados, $fallidos, $idAviso]);
        $resumen = ['id' => $idAviso, 'telefonos' => count($telefonos), 'aceptados' => $aceptados, 'fallidos' => $fallidos];
        $this->bitacora->registra('notificaciones', 'envia_aviso', 'aviso', $idAviso,
            despues: ['destino' => $destino['tipo'] . ($destino['id'] === null ? '' : ':' . $destino['id'])] + $resumen,
            idUsuario: $this->identidad->id(), ip: $ip);
        return $resumen;
    }

    /**
     * El historial de avisos del periodo, dentro del alcance de sucursal.
     *
     * @return list<array<string,mixed>>
     */
    public function avisos(string $desde, string $hasta): array
    {
        foreach (['desde' => $desde, 'hasta' => $hasta] as $campo => $fecha) {
            if (\DateTimeImmutable::createFromFormat('!Y-m-d', $fecha) === false) throw Errores::datosInvalidos([$campo => 'Capture una fecha válida']);
        }
        if ($hasta < $desde) throw Errores::datosInvalidos(['hasta' => 'La fecha final no puede ser anterior']);
        $donde = 'a.creado_en >= ? AND a.creado_en < DATE_ADD(?, INTERVAL 1 DAY)';
        $params = [$desde, $hasta];
        if (($alcance = $this->identidad->idSucursal()) !== null) { $donde .= ' AND a.id_sucursal = ?'; $params[] = $alcance; }
        return $this->bd->filas(
            'SELECT a.*, TRIM(CONCAT(p.nombre, " ", p.apellido_paterno)) AS envio
             FROM aviso a JOIN usuario u ON u.id = a.creado_por JOIN personal p ON p.id = u.id_personal
             WHERE ' . $donde . ' ORDER BY a.creado_en DESC, a.id DESC LIMIT 500',
            $params
        );
    }

    /** @return array<string,mixed> Un aviso con el resultado de cada teléfono. */
    public function aviso(int $id): array
    {
        $aviso = $this->bd->fila(
            'SELECT a.*, TRIM(CONCAT(p.nombre, " ", p.apellido_paterno)) AS envio
             FROM aviso a JOIN usuario u ON u.id = a.creado_por JOIN personal p ON p.id = u.id_personal WHERE a.id = ?',
            [$id]
        );
        $alcance = $this->identidad->idSucursal();
        if ($aviso === null || ($alcance !== null && (int) $aviso['id_sucursal'] !== $alcance)) throw Errores::noEncontrado('El aviso no existe');
        $aviso['telefonos_detalle'] = $this->bd->filas(
            'SELECT n.enviado_en, n.error, d.nombre AS telefono,
                    TRIM(CONCAT(p.nombre, " ", p.apellido_paterno, " ", COALESCE(p.apellido_materno, ""))) AS persona
             FROM notificacion n JOIN usuario u ON u.id = n.id_usuario JOIN personal p ON p.id = u.id_personal
             LEFT JOIN dispositivo d ON d.id = n.id_dispositivo
             WHERE n.id_aviso = ? ORDER BY persona, n.id',
            [$id]
        );
        return $aviso;
    }

    /** @return list<array<string,mixed>> Teléfonos autorizados, con avisos y dentro del alcance. */
    private function telefonosListos(): array
    {
        $donde = '';
        $params = [];
        if (!$this->identidad->esAdministrador()) {
            $alcance = $this->identidad->sucursales();
            if ($alcance === []) return [];
            $donde = ' AND pe.id_sucursal IN (' . implode(',', array_fill(0, count($alcance), '?')) . ')';
            $params = $alcance;
        }
        return $this->bd->filas(
            'SELECT d.id, d.token_push, u.id AS id_usuario, pe.id_puesto, pu.nombre AS puesto, pe.id_sucursal, su.nombre AS sucursal,
                    TRIM(CONCAT(pe.nombre, " ", pe.apellido_paterno, " ", COALESCE(pe.apellido_materno, ""))) AS persona
             FROM dispositivo d JOIN usuario u ON u.id = d.id_usuario
             JOIN personal pe ON pe.id = u.id_personal JOIN puesto pu ON pu.id = pe.id_puesto
             LEFT JOIN sucursal su ON su.id = pe.id_sucursal
             WHERE d.autorizado = 1 AND d.token_push IS NOT NULL AND d.token_push <> ""
               AND u.id_estatus = 4 AND pe.id_estatus = 4' . $donde . '
             ORDER BY d.id',
            $params
        );
    }

    /**
     * Un mensaje o una tanda: Expo recibe un objeto o una lista de hasta 100.
     *
     * @param array<int|string,mixed> $mensaje @return array<string,mixed>
     */
    private function enviaExpo(array $mensaje):array
    {
        if(!function_exists('curl_init'))throw new ErrorHttp(503,'Avisos no disponibles. Intente más tarde','push_no_disponible');
        $curl=curl_init('https://exp.host/--/api/v2/push/send');
        if($curl===false)throw new ErrorHttp(503,'El aviso no se envió. Intente de nuevo','push_no_disponible');
        curl_setopt_array($curl,[
            CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,
            CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>12,
            CURLOPT_HTTPHEADER=>['Accept: application/json','Content-Type: application/json'],
            CURLOPT_POSTFIELDS=>json_encode($mensaje,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
        ]);
        $cuerpo=curl_exec($curl);$estado=(int)curl_getinfo($curl,CURLINFO_RESPONSE_CODE);curl_close($curl);
        $datos=is_string($cuerpo)?json_decode($cuerpo,true):null;
        if($estado!==200||!is_array($datos))throw new ErrorHttp(503,'El aviso no se envió. Intente de nuevo','push_no_disponible');
        return $datos;
    }
}
