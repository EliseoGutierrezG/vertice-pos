<?php
declare(strict_types=1);

namespace Servicios;

// Generado por guiones/genera-marca.mjs.
final class MarcaBase
{
    public const VALORES = [
        'nombre' => 'El Timón',
        'nombre_corto' => 'El Timón',
        'lema' => 'Mariscos frescos, servicio de puerto',
        'colores' => [
            'fondo' => '#F5F7F8',
            'superficie' => '#FFFFFF',
            'tinta' => '#0D1B3E',
            'primario' => '#1C3F94',
            'acento' => '#C8372D',
            'borde' => '#7D8799',
            'exito' => '#2B7A45',
            'aviso' => '#E9C24A',
            'secundario' => '#566175',
            'limon' => '#A6C83C',
        ],
        'logo' => null,
    ];
}
