<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\DatosRestaurante as Datos;
use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;

final class ImpresionRestaurante
{
    private const MAX_INTENTOS = 3;

    public function __construct(private BaseDatos $bd, private OperacionRestaurante $operacion)
    {
    }

    /**
     * Da de alta una impresora (`$id = 0`) o actualiza la que ya existe.
     *
     * Cada área de la sucursal tiene una sola impresora. Por eso el área se
     * decide al agregar y no cambia al actualizar: antes el guardado buscaba
     * por (sucursal, área) y, al elegir otra área, pisaba la impresora ajena.
     */
    public function registra(int $sucursal, int $id, array $datos): int
    {
        $nombre = Datos::texto($datos['nombre'] ?? '', 'nombre', 80);
        $ip = Datos::texto($datos['ip'] ?? '', 'ip', 45);
        // El impresor Android sólo puede alcanzar impresoras de su red privada.
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
            || preg_match('/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/', $ip) !== 1) {
            throw Errores::datosInvalidos(['ip' => 'Capture una dirección IPv4 privada de la sucursal']);
        }
        $ancho = Datos::opcion((string) ($datos['ancho'] ?? '80'), 'ancho', ['58','80']);
        $puerto = Datos::entero($datos['puerto'] ?? 9100, 'puerto', 1, 65535);
        $activa = Datos::entero($datos['activa'] ?? 1, 'activa', 0, 1);
        $destino = $id > 0 ? null : Datos::opcion($datos['destino'] ?? '', 'destino', ['caliente','fria','barra','caja']);

        return $this->bd->transaccion(function () use ($sucursal, $id, $nombre, $ip, $puerto, $ancho, $destino, $activa): int {
            $this->operacion->bloqueaCatalogo($sucursal);
            if ($id > 0) {
                $destino = $this->bd->valor(
                    'SELECT destino FROM impresora WHERE id = ? AND id_sucursal = ? FOR UPDATE', [$id, $sucursal]
                ) ?? throw Errores::noEncontrado('Impresora no disponible');
                $this->bd->ejecuta(
                    'UPDATE impresora SET nombre = ?, ip = ?, puerto = ?, ancho = ?, activa = ? WHERE id = ? AND id_sucursal = ?',
                    [$nombre, $ip, $puerto, $ancho, $activa, $id, $sucursal]
                );
            } else {
                if ($this->bd->valor('SELECT id FROM impresora WHERE id_sucursal = ? AND destino = ? FOR UPDATE',
                        [$sucursal, $destino]) !== null) {
                    throw Errores::datosInvalidos(['destino' => 'Esa área ya tiene impresora']);
                }
                $id = $this->bd->inserta(
                    'INSERT INTO impresora (id_sucursal, nombre, ip, puerto, ancho, destino, activa) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [$sucursal, $nombre, $ip, $puerto, $ancho, $destino, $activa]
                );
            }
            $this->operacion->registra($sucursal, 'impresora_configurada', $id, ['destino' => $destino, 'activa' => $activa]);

            return $id;
        });
    }

    public function lista(int $sucursal, ?int $id = null): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->filas('SELECT id, nombre, ip, puerto, ancho, destino, activa FROM impresora
            WHERE id_sucursal = ?' . ($id === null ? '' : ' AND id = ?') . ' ORDER BY destino',
            $id === null ? [$sucursal] : [$sucursal, $id]);
    }

    public function encola(int $sucursal, string $destino, string $tipo, int $id, array $lineas): void
    {
        $impresora = $this->bd->valor(
            'SELECT id FROM impresora WHERE id_sucursal = ? AND destino = ? AND activa = 1', [$sucursal, $destino]
        );
        if ($impresora === null) {
            return;
        }
        $contenido = implode("\n", array_map(static fn (string $linea) => preg_replace('/[[:cntrl:]]/u', ' ', $linea), $lineas));
        $trabajo = $this->bd->inserta(
            'INSERT INTO trabajo_impresion (id_sucursal, id_impresora, tipo, entidad, contenido) VALUES (?, ?, ?, ?, ?)',
            [$sucursal, $impresora, $tipo, $id, $contenido]
        );
        $this->operacion->registra($sucursal, 'impresion_pendiente', $trabajo, ['tipo' => $tipo, 'entidad' => $id]);
    }

    public function demora(int $sucursal): int
    {
        return (int) $this->bd->valor(
            "SELECT COUNT(*) FROM trabajo_impresion t WHERE t.id_sucursal = ? AND
             ((t.estado IN ('pendiente','enviado') AND t.creado_en < DATE_SUB(NOW(), INTERVAL 20 SECOND)) OR
              (t.estado = 'fallido' AND t.terminado_en > DATE_SUB(NOW(), INTERVAL 1 HOUR)))
              AND NOT EXISTS (SELECT 1 FROM trabajo_impresion copia WHERE copia.id_original = t.id AND copia.estado = 'impreso')",
            [$sucursal]
        );
    }

    public function trabajos(int $sucursal): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->filas(
            "SELECT t.id, t.tipo, t.estado, t.creado_en, i.nombre,
                    (t.estado IN ('impreso','fallido') OR (t.estado = 'enviado' AND t.arrendado_hasta <= NOW())) AS reimprimible
             FROM trabajo_impresion t JOIN impresora i ON i.id = t.id_impresora
             WHERE t.id_sucursal = ? ORDER BY t.id DESC LIMIT 50",
                    [$sucursal]
        );
    }

    public function toma(int $sucursal, int $equipo): ?array
    {
        // Habitualmente no hay trabajos: evita tomar el candado de escritura.
        if ($this->bd->valor("SELECT id FROM trabajo_impresion WHERE id_sucursal = ? AND estado = 'pendiente' LIMIT 1",
                    [$sucursal]) === null) {
            return null;
        }
        return $this->bd->transaccion(function () use ($sucursal, $equipo): ?array {
            $this->operacion->bloqueaSucursal($sucursal);
            $trabajo = $this->bd->fila(
                "SELECT t.id,t.contenido,t.intentos,i.ip,i.puerto,i.ancho FROM trabajo_impresion t
                 JOIN impresora i ON i.id = t.id_impresora AND i.activa = 1
                 WHERE t.id_sucursal = ? AND t.estado = 'pendiente' ORDER BY t.id LIMIT 1 FOR UPDATE",
                [$sucursal]
            );
            if ($trabajo === null) {
                return null;
            }
            $this->bd->ejecuta(
                "UPDATE trabajo_impresion SET estado = 'enviado', intentos = intentos + 1,
                   id_equipo = ?, arrendado_hasta = DATE_ADD(NOW(), INTERVAL 20 SECOND)
                 WHERE id = ?",
                    [$equipo, $trabajo['id']]
            );
            $this->operacion->registra($sucursal, 'impresion_enviada', (int) $trabajo['id']);
            $columnas = $trabajo['ancho'] === '58' ? 30 : 46;
            // Los equipos térmicos pueden usar distintas páginas de códigos.
            // Normaliza el español antes del texto ASCII para que el resultado
            // sea idéntico con iconv de macOS y del alojamiento.
            $contenido = strtr($trabajo['contenido'], [
                'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n',
                'Á' => 'A', 'É' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ú' => 'U', 'Ü' => 'U', 'Ñ' => 'N',
            ]);
            $texto = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $contenido);
            $binario = "\x1b@" . wordwrap($texto === false ? '' : $texto, $columnas, "\n", true) . "\n\n\n\x1dV\x00";
            return ['id' => $trabajo['id'], 'intento' => (int) $trabajo['intentos'] + 1,
                'ip' => $trabajo['ip'], 'puerto' => $trabajo['puerto'], 'bytes' => base64_encode($binario)];
        });
    }

    public function confirma(int $sucursal, int $equipo, int $id, bool $impreso, ?int $intento = null, bool $reintentable = false): void
    {
        $this->bd->transaccion(function () use ($sucursal, $equipo, $id, $impreso, $intento, $reintentable): void {
            $this->operacion->bloqueaSucursal($sucursal);
            $trabajo = $this->bd->fila(
                'SELECT estado, intentos FROM trabajo_impresion WHERE id = ? AND id_sucursal = ? AND id_equipo = ? FOR UPDATE',
                [$id, $sucursal, $equipo]
            ) ?? throw Errores::noEncontrado('Trabajo no disponible');
            $actual = (int) $trabajo['intentos'];
            if ($intento !== null && $intento < $actual) {
                return;
            }
            if (($intento !== null && $intento !== $actual) || ($intento === null && $actual > 1)) {
                throw Errores::conflicto('Ya cambió el intento de impresión');
            }
            // Solo se reintenta automáticamente un fallo antes de escribir en el socket.
            $estado = $impreso ? 'impreso'
                : ($reintentable && $intento !== null && $actual < self::MAX_INTENTOS ? 'pendiente' : 'fallido');
            if ($trabajo['estado'] === $estado) {
                return;
            }
            if ($trabajo['estado'] !== 'enviado') {
                throw Errores::conflicto('Ya cambió el estado de la impresión');
            }
            $this->bd->ejecuta(
                "UPDATE trabajo_impresion SET estado = ?, arrendado_hasta = NULL,
                  terminado_en = IF(? = 'pendiente', NULL, NOW()) WHERE id = ?",
                [$estado, $estado, $id]
            );
            $this->operacion->registra($sucursal, 'impresion_' . $estado, $id, ['intento' => $actual]);
        });
    }

    public function reimprime(int $sucursal, int $id, string $llave): array
    {
        return $this->operacion->unaVez($sucursal, $llave, 'impresion_copia', [$id], function () use ($sucursal, $id): array {
            $trabajo = $this->bd->fila(
                "SELECT id_impresora,tipo,entidad,contenido FROM trabajo_impresion WHERE id = ? AND id_sucursal = ? AND
                 (estado IN ('impreso','fallido') OR (estado = 'enviado' AND arrendado_hasta <= NOW())) FOR UPDATE",
                [$id, $sucursal]
            ) ?? throw Errores::conflicto('La impresión original todavía está en curso');
            $copia = $this->bd->inserta(
                'INSERT INTO trabajo_impresion (id_sucursal,id_impresora,tipo,entidad,contenido,id_original) VALUES (?, ?, ?, ?, ?, ?)',
                [$sucursal, $trabajo['id_impresora'], $trabajo['tipo'], $trabajo['entidad'], "REIMPRESION\n" . $trabajo['contenido'], $id]
            );
            $this->operacion->registra($sucursal, 'impresion_copia', $copia, ['original' => $id]);
            return ['id' => $copia];
        });
    }
}
