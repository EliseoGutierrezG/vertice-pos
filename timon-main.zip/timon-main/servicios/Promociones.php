<?php
declare(strict_types=1);

namespace Servicios;

use DateTimeImmutable;
use Dominio\DatosRestaurante as Datos;
use Dominio\Dinero;
use Dominio\Promocion;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;

/**
 * Las promociones de platillo: el alta del panel, cuáles aplican en este
 * momento y el recálculo de lo que rebajan en una cuenta.
 *
 * La promoción se fija al capturar el platillo (`cuenta_item.id_promocion`).
 * Lo que rebaja (`cuenta_item.descuento`) se recalcula cada vez que cambia el
 * contenido de la cuenta, porque un N×M depende de cuántas piezas hay.
 */
final class Promociones
{
    public const ESTADOS = ['vigente' => 'Vigente ahora', 'programada' => 'Programada', 'pausada' => 'Pausada', 'vencida' => 'Vencida'];

    public function __construct(
        private BaseDatos $bd,
        private Bitacora $bitacora,
        private Identidad $identidad
    ) {
    }

    /** @return list<array<string,mixed>> Las promociones al alcance, con su estado. */
    public function listado(array $filtros = []): array
    {
        $ahora = new DateTimeImmutable();
        $donde = ['p.baja = 0'];
        $valores = [];
        $alcance = $this->identidad->sucursales();
        if ($alcance !== []) {
            $donde[] = 'EXISTS (SELECT 1 FROM promocion_sucursal a WHERE a.id_promocion = p.id AND a.id_sucursal IN ('
                . implode(',', array_fill(0, count($alcance), '?')) . '))';
            array_push($valores, ...$alcance);
        }
        $sucursal = (int) ($filtros['sucursal'] ?? 0);
        if ($sucursal > 0) {
            $donde[] = 'EXISTS (SELECT 1 FROM promocion_sucursal b WHERE b.id_promocion = p.id AND b.id_sucursal = ?)';
            $valores[] = $sucursal;
        }
        $platillo = (int) ($filtros['platillo'] ?? 0);
        if ($platillo > 0) {
            $donde[] = 'EXISTS (SELECT 1 FROM promocion_platillo c WHERE c.id_promocion = p.id AND c.id_platillo = ?)';
            $valores[] = $platillo;
        }
        $filas = $this->bd->filas(
            'SELECT p.*, (SELECT GROUP_CONCAT(pl.nombre ORDER BY pl.nombre SEPARATOR \', \')
                          FROM promocion_platillo pp JOIN platillo pl ON pl.id = pp.id_platillo WHERE pp.id_promocion = p.id) AS platillos,
                         (SELECT GROUP_CONCAT(s.nombre ORDER BY s.nombre SEPARATOR \', \')
                          FROM promocion_sucursal ps JOIN sucursal s ON s.id = ps.id_sucursal WHERE ps.id_promocion = p.id) AS sucursales
             FROM promocion p WHERE ' . implode(' AND ', $donde) . ' ORDER BY p.activa DESC, p.desde DESC, p.id DESC',
            $valores
        );
        $estado = (string) ($filtros['estado'] ?? '');
        $salida = [];
        foreach ($filas as $fila) {
            $fila['estado'] = self::estado($fila, $ahora);
            $fila['etiqueta'] = Promocion::etiqueta($fila);
            $fila['horario'] = Promocion::horario($fila);
            if ($estado === '' || $estado === $fila['estado']) {
                $salida[] = $fila;
            }
        }
        return $salida;
    }

    public static function estado(array $p, DateTimeImmutable $ahora): string
    {
        return match (true) {
            (int) $p['activa'] === 0 => 'pausada',
            Promocion::vencida($p, $ahora) => 'vencida',
            Promocion::vigente($p, $ahora) => 'vigente',
            default => 'programada',
        };
    }

    public function ficha(int $id): array
    {
        $p = $this->bd->fila('SELECT * FROM promocion WHERE id = ? AND baja = 0', [$id])
            ?? throw Errores::noEncontrado('Promoción no disponible');
        $p['sucursales'] = array_map('intval', array_column($this->bd->filas(
            'SELECT id_sucursal FROM promocion_sucursal WHERE id_promocion = ? ORDER BY id_sucursal', [$id]), 'id_sucursal'));
        foreach ($p['sucursales'] as $sucursal) {
            if (!$this->identidad->alcanzaSucursal($sucursal)) {
                throw Errores::prohibido('Esa promoción incluye una sucursal fuera de su alcance');
            }
        }
        $p['platillos'] = $this->bd->filas(
            'SELECT pl.id, pl.nombre, c.nombre AS categoria FROM promocion_platillo pp
             JOIN platillo pl ON pl.id = pp.id_platillo JOIN categoria_menu c ON c.id = pl.id_categoria
             WHERE pp.id_promocion = ? ORDER BY c.orden, c.nombre, pl.orden, pl.nombre', [$id]);
        $p['nombres_sucursales'] = array_column($this->bd->filas(
            'SELECT s.nombre FROM promocion_sucursal ps JOIN sucursal s ON s.id = ps.id_sucursal
             WHERE ps.id_promocion = ? ORDER BY s.nombre', [$id]), 'nombre');
        $p['estado'] = self::estado($p, new DateTimeImmutable());
        $p['etiqueta'] = Promocion::etiqueta($p);
        $p['horario'] = Promocion::horario($p);
        $p['dias_lista'] = array_values(array_filter(array_keys(Promocion::DIAS),
            static fn (int $d): bool => ((int) $p['dias'] & Promocion::bitDia($d)) !== 0));
        return $p;
    }

    /**
     * Crea o actualiza. Devuelve el id y los avisos de empalme: otra promoción
     * con el mismo platillo, en la misma sucursal y en días que coinciden.
     *
     * @return array{id: int, avisos: list<string>}
     */
    public function guarda(int $id, array $datos): array
    {
        $limpio = Promocion::normaliza($datos);
        $platillos = $this->ids($datos['platillos'] ?? [], 'platillos', 'Seleccione al menos un platillo');
        $sucursales = $this->ids($datos['sucursales'] ?? [], 'sucursales', 'Seleccione al menos una sucursal');
        foreach ($sucursales as $sucursal) {
            $this->identidad->exigeSucursal($sucursal);
        }

        return $this->bd->transaccion(function () use ($id, $limpio, $platillos, $sucursales): array {
            $marcas = implode(',', array_fill(0, count($sucursales), '?'));
            if ((int) $this->bd->valor('SELECT COUNT(*) FROM sucursal WHERE id_estatus = 4 AND id IN (' . $marcas . ')', $sucursales) !== count($sucursales)) {
                throw Errores::datosInvalidos(['sucursales' => 'Seleccione sucursales activas']);
            }
            $marcas = implode(',', array_fill(0, count($platillos), '?'));
            if ((int) $this->bd->valor('SELECT COUNT(*) FROM platillo WHERE id IN (' . $marcas . ')', $platillos) !== count($platillos)) {
                throw Errores::datosInvalidos(['platillos' => 'Seleccione platillos de la carta']);
            }
            $antes = null;
            if ($id === 0) {
                $id = $this->bd->inserta(
                    'INSERT INTO promocion (nombre, tipo, valor, lleva, paga, desde, hasta, dias, hora_inicio, hora_fin, creado_por)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [...array_values($limpio), $this->identidad->id()]
                );
            } else {
                $antes = $this->ficha($id);
                foreach ($antes['sucursales'] as $previa) {
                    $this->identidad->exigeSucursal($previa);
                }
                $this->bd->ejecuta(
                    'UPDATE promocion SET nombre = ?, tipo = ?, valor = ?, lleva = ?, paga = ?, desde = ?, hasta = ?, dias = ?,
                     hora_inicio = ?, hora_fin = ? WHERE id = ?',
                    [...array_values($limpio), $id]
                );
                $this->bd->ejecuta('DELETE FROM promocion_platillo WHERE id_promocion = ?', [$id]);
                $this->bd->ejecuta('DELETE FROM promocion_sucursal WHERE id_promocion = ?', [$id]);
            }
            foreach ($platillos as $platillo) {
                $this->bd->ejecuta('INSERT INTO promocion_platillo (id_promocion, id_platillo) VALUES (?, ?)', [$id, $platillo]);
            }
            foreach ($sucursales as $sucursal) {
                $this->bd->ejecuta('INSERT INTO promocion_sucursal (id_promocion, id_sucursal) VALUES (?, ?)', [$id, $sucursal]);
            }
            $this->avisaEquipos(array_unique([...$sucursales, ...($antes['sucursales'] ?? [])]), $id);
            $this->bitacora->registra('restaurante', $antes === null ? 'promocion_creada' : 'promocion_cambiada', 'promocion', $id,
                antes: $antes === null ? null : array_intersect_key($antes, $limpio),
                despues: $limpio + ['platillos' => $platillos, 'sucursales' => $sucursales],
                idUsuario: $this->identidad->id());
            return ['id' => $id, 'avisos' => $this->empalmes($id, $limpio, $platillos, $sucursales)];
        });
    }

    /** Pausar, reanudar o dar de baja. */
    public function cambiaEstado(int $id, string $accion): void
    {
        $this->bd->transaccion(function () use ($id, $accion): void {
            $ficha = $this->ficha($id);
            [$campo, $valor, $sql] = match ($accion) {
                'pausar' => ['activa', 0, 'UPDATE promocion SET activa = ? WHERE id = ?'],
                'reanudar' => ['activa', 1, 'UPDATE promocion SET activa = ? WHERE id = ?'],
                'baja' => ['baja', 1, 'UPDATE promocion SET baja = ? WHERE id = ?'],
                default => throw Errores::datosInvalidos(['accion' => 'Acción no disponible']),
            };
            $this->bd->ejecuta($sql, [$valor, $id]);
            $this->avisaEquipos($ficha['sucursales'], $id);
            $this->bitacora->registra('restaurante', 'promocion_' . $accion, 'promocion', $id,
                antes: [$campo => $ficha[$campo] ?? null], despues: [$campo => $valor], idUsuario: $this->identidad->id());
        });
    }

    /**
     * Las promociones de la sucursal que no han vencido, con sus platillos.
     * Sirve para la carta impresa, que anuncia también las de otro día.
     *
     * @return list<array<string,mixed>>
     */
    public function vigentesOProgramadas(int $sucursal, DateTimeImmutable $ahora): array
    {
        $promos = $this->deSucursal($sucursal, $ahora->format('Y-m-d'), soloHoy: false);
        return array_values(array_filter($promos, static fn (array $p): bool => !Promocion::vencida($p, $ahora)));
    }

    /**
     * Las promociones que aplican en este momento, por platillo.
     *
     * @return array<int, list<array<string,mixed>>>
     */
    public function vigentesPara(int $sucursal, DateTimeImmutable $ahora): array
    {
        $porPlatillo = [];
        foreach ($this->deSucursal($sucursal, $ahora->format('Y-m-d'), soloHoy: true) as $p) {
            if (!Promocion::vigente($p, $ahora)) {
                continue;
            }
            foreach ($p['ids_platillos'] as $platillo) {
                $porPlatillo[$platillo][] = $p;
            }
        }
        return $porPlatillo;
    }

    /** La promoción que más rebaja a ese platillo, o null si ninguna rebaja. */
    public static function mejor(array $candidatas, Dinero $base, Dinero $suplementos): ?array
    {
        $mejor = null;
        $rebaja = 0;
        foreach ($candidatas as $p) {
            $estimada = Promocion::rebajaEstimada($p, $base, $suplementos);
            if ($estimada > $rebaja) {
                [$mejor, $rebaja] = [$p, $estimada];
            }
        }
        return $mejor;
    }

    /**
     * Vuelve a calcular lo que rebajan las promociones en una cuenta. Se llama
     * dentro de la transacción de cada operación que cambia sus renglones.
     */
    public function recalcula(int $cuenta): void
    {
        $items = $this->bd->filas(
            "SELECT id, id_platillo, id_promocion, cantidad, precio, modificadores, descuento, estado
             FROM cuenta_item WHERE id_cuenta = ? ORDER BY id FOR UPDATE",
            [$cuenta]
        );
        if ($items === []) {
            return;
        }
        $renglones = array_map(static fn (array $i): array => [
            'id' => $i['id'], 'id_platillo' => (int) $i['id_platillo'],
            'id_promocion' => $i['estado'] === 'cancelado' ? null : ($i['id_promocion'] === null ? null : (int) $i['id_promocion']),
            'cantidad' => (int) $i['cantidad'], 'precio' => Dinero::deCadena($i['precio']),
            'suplementos' => self::suplementos($i['modificadores']),
        ], $items);
        $descuentos = self::calculaDescuentos($renglones, $this->porId(array_column($renglones, 'id_promocion')));
        foreach ($items as $item) {
            $nuevo = $descuentos[$item['id']]->aPesos();
            if ($nuevo !== Dinero::deCadena($item['descuento'])->aPesos()) {
                $this->bd->ejecuta('UPDATE cuenta_item SET descuento = ? WHERE id = ?', [$nuevo, $item['id']]);
            }
        }
    }

    /**
     * Lo que rebaja cada renglón. El precio es el de lista con suplementos.
     *
     * @param list<array{id: int|string, id_platillo: int, id_promocion: ?int, cantidad: int, precio: Dinero, suplementos: Dinero}> $renglones
     * @param array<int, array<string,mixed>> $promos
     * @return array<int|string, Dinero>
     */
    public static function calculaDescuentos(array $renglones, array $promos): array
    {
        $descuentos = [];
        $grupos = [];
        foreach ($renglones as $r) {
            $descuentos[$r['id']] = Dinero::cero();
            $promo = $r['id_promocion'] === null ? null : ($promos[$r['id_promocion']] ?? null);
            if ($promo === null) {
                continue;
            }
            if ($promo['tipo'] === 'nxm') {
                $grupos[$r['id_promocion'] . ':' . $r['id_platillo']][] =
                    ['id' => $r['id'], 'precio' => $r['precio'], 'cantidad' => $r['cantidad']];
                continue;
            }
            $descuentos[$r['id']] = Promocion::descuentoUnitario($promo, $r['precio']->menos($r['suplementos']), $r['suplementos'])
                ->porEntero($r['cantidad']);
        }
        foreach ($grupos as $clave => $grupo) {
            $descuentos = array_replace($descuentos, Promocion::descuentosNxM($promos[(int) explode(':', $clave)[0]], $grupo));
        }
        return $descuentos;
    }

    /** Lo que se copia en el renglón: «2x1 Martes de aguachile». */
    public static function rotulo(?array $promocion): string
    {
        return $promocion === null ? '' : mb_substr(Promocion::etiqueta($promocion) . ' ' . $promocion['nombre'], 0, 80);
    }

    /** @param list<?int> $ids @return array<int, array<string,mixed>> */
    public function porId(array $ids): array
    {
        $ids = array_values(array_unique(array_filter($ids)));
        if ($ids === []) {
            return [];
        }
        $filas = $this->bd->filas('SELECT * FROM promocion WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', $ids);
        $salida = [];
        foreach ($filas as $fila) {
            $salida[(int) $fila['id']] = $fila;
        }
        return $salida;
    }

    public static function suplementos(string $modificadores): Dinero
    {
        $suma = Dinero::cero();
        foreach (json_decode($modificadores, true, flags: JSON_THROW_ON_ERROR) as $modificador) {
            $suma = $suma->mas(Dinero::deCadena((string) $modificador['suplemento']));
        }
        return $suma;
    }

    /** @return list<array<string,mixed>> */
    private function deSucursal(int $sucursal, string $hoy, bool $soloHoy): array
    {
        // Un horario que empezó ayer y cruza la medianoche sigue vigente hoy:
        // por eso se toma también la fecha de ayer al filtrar.
        $promos = $this->bd->filas(
            'SELECT p.* FROM promocion p JOIN promocion_sucursal s ON s.id_promocion = p.id AND s.id_sucursal = ?
             WHERE p.baja = 0 AND p.activa = 1 AND (p.hasta IS NULL OR p.hasta >= DATE_SUB(?, INTERVAL 1 DAY))'
            . ($soloHoy ? ' AND p.desde <= ?' : '') . ' ORDER BY p.desde, p.id',
            $soloHoy ? [$sucursal, $hoy, $hoy] : [$sucursal, $hoy]
        );
        if ($promos === []) {
            return [];
        }
        $ids = array_column($promos, 'id');
        $relacion = $this->bd->filas('SELECT id_promocion, id_platillo FROM promocion_platillo WHERE id_promocion IN ('
            . implode(',', array_fill(0, count($ids), '?')) . ')', $ids);
        $porPromo = [];
        foreach ($relacion as $fila) {
            $porPromo[$fila['id_promocion']][] = (int) $fila['id_platillo'];
        }
        foreach ($promos as &$p) {
            $p['ids_platillos'] = $porPromo[$p['id']] ?? [];
        }
        return $promos;
    }

    /** @return list<string> */
    private function empalmes(int $id, array $limpio, array $platillos, array $sucursales): array
    {
        $marcasP = implode(',', array_fill(0, count($platillos), '?'));
        $marcasS = implode(',', array_fill(0, count($sucursales), '?'));
        $otras = $this->bd->filas(
            "SELECT DISTINCT p.nombre, p.dias FROM promocion p
             JOIN promocion_platillo pp ON pp.id_promocion = p.id AND pp.id_platillo IN ($marcasP)
             JOIN promocion_sucursal ps ON ps.id_promocion = p.id AND ps.id_sucursal IN ($marcasS)
             WHERE p.id <> ? AND p.baja = 0 AND p.activa = 1
               AND (p.hasta IS NULL OR p.hasta >= ?) AND (? IS NULL OR p.desde <= ?)",
            [...$platillos, ...$sucursales, $id, $limpio['desde'], $limpio['hasta'], $limpio['hasta']]
        );
        $avisos = [];
        foreach ($otras as $otra) {
            if (((int) $otra['dias'] & $limpio['dias']) !== 0) {
                $avisos[] = 'Coincide con «' . $otra['nombre'] . '». Se aplica la de mayor rebaja.';
            }
        }
        return $avisos;
    }

    /** @param list<int> $sucursales */
    private function avisaEquipos(array $sucursales, int $id): void
    {
        // Los equipos recargan la carta con los eventos `menu_*`.
        foreach ($sucursales as $sucursal) {
            $this->bd->ejecuta("INSERT INTO evento_sucursal (id_sucursal, tipo, entidad) VALUES (?, 'menu_promocion', ?)",
                [$sucursal, $id]);
        }
    }

    /** @return list<int> */
    private function ids(mixed $crudos, string $campo, string $mensaje): array
    {
        if (!is_array($crudos) || $crudos === [] || count($crudos) > 500) {
            throw Errores::datosInvalidos([$campo => $mensaje]);
        }
        $ids = array_values(array_unique(array_map(static fn (mixed $v): int => Datos::entero($v, $campo), $crudos)));
        sort($ids);
        return $ids;
    }
}
