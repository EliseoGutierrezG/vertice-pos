<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;
use Nucleo\Exporta\Tabla;

final class ReportesRestaurante
{
    public const TIPOS = [
        'dia' => 'Ventas por día', 'hora' => 'Ventas por hora', 'platillo' => 'Ventas por platillo',
        'mesero' => 'Ventas por mesero', 'cocina' => 'Tiempos de cocina', 'cancelaciones' => 'Cancelaciones',
        'agotados' => 'Platillos agotados', 'consumo' => 'Consumo y mermas', 'gastos' => 'Gastos',
        'formas' => 'Formas de pago', 'descuentos' => 'Descuentos', 'promociones' => 'Promociones', 'propinas' => 'Propinas',
    ];

    public function __construct(
        private BaseDatos $bd,
        private OperacionRestaurante $operacion,
        private ImpresionRestaurante $impresion
    ) {
    }

    public function tabla(int $sucursal, string $tipo, string $desde, string $hasta): Tabla
    {
        $this->operacion->consultaSucursal($sucursal);
        $periodo = [$sucursal, $desde, $hasta];
        [$columnas, $sql, $parametros] = match ($tipo) {
            'dia', 'hora', 'mesero' => $this->ventas($tipo, $periodo),
            'formas' => [['Forma de pago', 'Cobros', 'Importe'], "SELECT CASE f.medio WHEN 'efectivo' THEN 'Efectivo'
                    WHEN 'tarjeta' THEN 'Tarjeta' ELSE 'Transferencia' END, COUNT(DISTINCT p.id), SUM(f.importe)
                FROM pago_cuenta p JOIN cuenta c ON c.id = p.id_cuenta JOIN pago_cuenta_forma f ON f.id_pago = p.id
                WHERE c.id_sucursal = ? AND p.pagado_en >= ? AND p.pagado_en < DATE_ADD(?, INTERVAL 1 DAY)
                GROUP BY f.medio ORDER BY f.medio", $periodo],
            'descuentos' => [['Fecha', 'Folio', 'Descuento', 'Motivo', 'Autorizó'], "SELECT p.pagado_en,
                    COALESCE(p.folio, CONCAT('#', p.id)), p.descuento, COALESCE(p.descuento_motivo, ''),
                    COALESCE(CONCAT_WS(' ', pe.nombre, pe.apellido_paterno), u.usuario, '')
                FROM pago_cuenta p JOIN cuenta c ON c.id = p.id_cuenta
                LEFT JOIN usuario u ON u.id = p.descuento_autorizado_por LEFT JOIN personal pe ON pe.id = u.id_personal
                WHERE c.id_sucursal = ? AND p.pagado_en >= ? AND p.pagado_en < DATE_ADD(?, INTERVAL 1 DAY) AND p.descuento > 0
                ORDER BY p.pagado_en DESC, p.id DESC", $periodo],
            'propinas' => [['Fecha', 'Folio', 'Mesero', 'Venta', 'Propina'], "SELECT p.pagado_en,
                    COALESCE(p.folio, CONCAT('#', p.id)), COALESCE(CONCAT_WS(' ', pe.nombre, pe.apellido_paterno), u.usuario),
                    p.total, p.propina
                FROM pago_cuenta p JOIN cuenta c ON c.id = p.id_cuenta
                JOIN usuario u ON u.id = c.id_mesero LEFT JOIN personal pe ON pe.id = u.id_personal
                WHERE c.id_sucursal = ? AND p.pagado_en >= ? AND p.pagado_en < DATE_ADD(?, INTERVAL 1 DAY) AND p.propina > 0
                ORDER BY p.pagado_en DESC, p.id DESC", $periodo],
            'promociones' => [['Promoción', 'Usos', 'Unidades', 'Rebaja'], "SELECT COALESCE(pr.nombre, i.promocion),
                    COUNT(DISTINCT c.id), SUM(i.cantidad), SUM(i.descuento)
                FROM pago_cuenta p JOIN cuenta c ON c.id = p.id_cuenta JOIN cuenta_item i ON i.id_cuenta = c.id
                LEFT JOIN promocion pr ON pr.id = i.id_promocion
                WHERE c.id_sucursal = ? AND p.pagado_en >= ? AND p.pagado_en < DATE_ADD(?, INTERVAL 1 DAY)
                AND i.estado <> 'cancelado' AND i.descuento > 0
                GROUP BY i.id_promocion, COALESCE(pr.nombre, i.promocion) ORDER BY SUM(i.descuento) DESC", $periodo],
            'platillo' => [['Platillo','Unidades','Consumo'], "SELECT i.platillo, SUM(i.cantidad), SUM(i.precio * i.cantidad - i.descuento)
                FROM pago_cuenta p JOIN cuenta c ON c.id = p.id_cuenta JOIN cuenta_item i ON i.id_cuenta = c.id
                WHERE c.id_sucursal = ? AND p.pagado_en >= ? AND p.pagado_en < DATE_ADD(?, INTERVAL 1 DAY)
                AND i.estado <> 'cancelado' GROUP BY i.platillo ORDER BY SUM(i.cantidad) DESC, i.platillo", $periodo],
            'cocina' => [['Área','Platillos listos','Minutos promedio'], "SELECT i.preparacion, COUNT(i.id),
                ROUND(AVG(TIMESTAMPDIFF(SECOND, r.enviada_en, i.listo_en)) / 60, 2)
                FROM cuenta c JOIN cuenta_item i ON i.id_cuenta = c.id JOIN ronda r ON r.id = i.id_ronda
                WHERE c.id_sucursal = ? AND r.enviada_en >= ? AND r.enviada_en < DATE_ADD(?, INTERVAL 1 DAY)
                AND i.listo_en IS NOT NULL GROUP BY i.preparacion ORDER BY i.preparacion", $periodo],
            'cancelaciones' => [['Cuenta','Platillo','Cantidad','Motivo','Fecha'], "SELECT c.id,i.platillo,i.cantidad,i.motivo,i.estado_en
                FROM cuenta c JOIN cuenta_item i ON i.id_cuenta = c.id
                WHERE c.id_sucursal = ? AND i.estado_en >= ? AND i.estado_en < DATE_ADD(?, INTERVAL 1 DAY)
                AND i.estado = 'cancelado' ORDER BY i.estado_en DESC,i.id", $periodo],
            'agotados' => [['Platillo','Categoría','Preparación'], 'SELECT p.nombre,cat.nombre,p.preparacion
                FROM platillo_sucursal s JOIN platillo p ON p.id = s.id_platillo JOIN categoria_menu cat ON cat.id = p.id_categoria
                WHERE s.id_sucursal = ? AND s.agotado = 1 AND p.activo = 1 ORDER BY p.nombre', [$sucursal]],
            'consumo' => [['Insumo','Unidad','Consumo según recetas','Merma','Ajuste de conteo'], "SELECT i.nombre,i.unidad,
                COALESCE(SUM(IF(k.tipo = 'consumo', -k.cantidad, 0)),0),
                COALESCE(SUM(IF(k.tipo = 'merma', -k.cantidad, 0)),0),COALESCE(SUM(IF(k.tipo = 'conteo', k.cantidad, 0)),0)
                FROM insumo i LEFT JOIN lote_insumo l ON l.id_insumo = i.id
                LEFT JOIN kardex_insumo k ON k.id_lote = l.id AND k.creado_en >= ? AND k.creado_en < DATE_ADD(?, INTERVAL 1 DAY)
                WHERE i.id_sucursal = ? GROUP BY i.id,i.nombre,i.unidad ORDER BY i.nombre", [$desde, $hasta, $sucursal]],
            'gastos' => [['Concepto','Proveedor','Importe','Fecha'], 'SELECT g.concepto,COALESCE(p.nombre, \'\'),g.importe,g.creado_en
                FROM gasto_sucursal g LEFT JOIN proveedor p ON p.id = g.id_proveedor
                WHERE g.id_sucursal = ? AND g.creado_en >= ? AND g.creado_en < DATE_ADD(?, INTERVAL 1 DAY) AND g.cancelado_en IS NULL
                ORDER BY g.creado_en DESC,g.id', $periodo],
        };
        $filas = array_map(
            static fn (array $fila): array => array_map(static fn (mixed $valor): string => (string) $valor, array_values($fila)),
            $this->bd->filas($sql, $parametros)
        );
        return new Tabla(self::TIPOS[$tipo], $columnas, $filas, subtitulo: $tipo === 'agotados' ? 'Disponibilidad actual' : "$desde a $hasta");
    }

    public function vivos(int $sucursal): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return [
            'cuentas' => (int) $this->bd->valor('SELECT COUNT(*) FROM cuenta WHERE id_sucursal = ? AND abierta = 1', [$sucursal]),
            'cocina' => (int) $this->bd->valor(
                "SELECT COALESCE(SUM(i.cantidad), 0) FROM cuenta c JOIN cuenta_item i ON i.id_cuenta = c.id
                 WHERE c.id_sucursal = ? AND (c.abierta = 1 OR c.estado = 'pagada') AND i.estado IN ('enviado','en_preparacion')", [$sucursal]),
            'mesas' => (int) $this->bd->valor('SELECT COUNT(*) FROM cuenta_mesa WHERE id_sucursal = ? AND abierta = 1', [$sucursal]),
            'atrasadas' => (int) $this->bd->valor(
                "SELECT COUNT(DISTINCT r.id) FROM cuenta c JOIN ronda r ON r.id_cuenta = c.id
                 JOIN cuenta_item i ON i.id_ronda = r.id
                 WHERE c.id_sucursal = ? AND (c.abierta = 1 OR c.estado = 'pagada')
                   AND i.estado IN ('enviado','en_preparacion') AND r.enviada_en <= DATE_SUB(NOW(), INTERVAL 20 MINUTE)", [$sucursal]),
            'impresiones' => $this->impresion->demora($sucursal),
            'faltantes' => (int) $this->bd->valor(
                'SELECT COUNT(*) FROM faltante_insumo WHERE id_sucursal = ? AND atendido_en IS NULL', [$sucursal]),
            'turno' => $this->bd->valor('SELECT id FROM turno_caja WHERE id_sucursal = ? AND abierto = 1', [$sucursal]) === null
                ? 'Cerrado' : 'Abierto',
            'reservaciones' => (int) $this->bd->valor(
                "SELECT COUNT(*) FROM reservacion WHERE id_sucursal = ? AND desde >= NOW() AND estado = 'solicitada'",
                [$sucursal]),
            'venta' => (string) $this->bd->valor(
                'SELECT COALESCE(SUM(p.total),0) FROM cuenta c JOIN pago_cuenta p ON p.id_cuenta = c.id
                 WHERE c.id_sucursal = ? AND p.pagado_en >= CURDATE() AND p.pagado_en < DATE_ADD(CURDATE(), INTERVAL 1 DAY)', [$sucursal]),
            'actualizado' => date('H:i:s'),
        ];
    }

    private function ventas(string $tipo, array $periodo): array
    {
        $grupo = match ($tipo) {
            'dia' => "DATE_FORMAT(p.pagado_en, '%Y-%m-%d')",
            'hora' => "DATE_FORMAT(p.pagado_en, '%H:00')",
            'mesero' => 'u.usuario',
        };
        return [
            [match ($tipo) { 'dia' => 'Día', 'hora' => 'Hora', 'mesero' => 'Mesero' }, 'Tickets', 'Venta', 'Propinas', 'Ticket promedio'],
            'SELECT ' . $grupo . ' AS agrupacion,COUNT(p.id),SUM(p.total),SUM(p.propina),ROUND(AVG(p.total),2)
             FROM pago_cuenta p JOIN cuenta c ON c.id = p.id_cuenta JOIN usuario u ON u.id = c.id_mesero
             WHERE c.id_sucursal = ? AND p.pagado_en >= ? AND p.pagado_en < DATE_ADD(?, INTERVAL 1 DAY)
             GROUP BY agrupacion ORDER BY agrupacion',
            $periodo,
        ];
    }
}
