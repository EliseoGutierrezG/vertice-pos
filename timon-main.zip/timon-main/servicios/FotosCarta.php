<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\Errores\Errores;
use RuntimeException;

final class FotosCarta
{
    private const LIMITE = 5 * 1024 * 1024;
    private const LADO = 1440;

    public function __construct(private string $carpeta)
    {
    }

    public function sube(?array $archivo): ?string
    {
        if ($archivo === null || $archivo['error'] === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if ($archivo['error'] !== UPLOAD_ERR_OK || $archivo['peso'] < 1 || $archivo['peso'] > self::LIMITE
            || !is_uploaded_file($archivo['ruta'])) {
            throw Errores::datosInvalidos(['imagen' => 'Use una imagen de hasta 5 MB']);
        }
        if (!function_exists('imagewebp')) {
            throw new RuntimeException('La instalación requiere GD con WebP');
        }
        $original = file_get_contents($archivo['ruta'], length: self::LIMITE + 1);
        $info = $original === false ? false : @getimagesizefromstring($original);
        if ($info === false || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)
            || $info[0] < 1 || $info[1] < 1 || $info[0] * $info[1] > 16_000_000) {
            throw Errores::datosInvalidos(['imagen' => 'Seleccione una foto JPG, PNG o WebP']);
        }
        $entrada = @imagecreatefromstring($original);
        if ($entrada === false) {
            throw Errores::datosInvalidos(['imagen' => 'No se pudo leer la foto']);
        }
        if (!is_dir($this->carpeta) && !mkdir($this->carpeta, 0750, true) && !is_dir($this->carpeta)) {
            throw new RuntimeException('No se pudo crear el almacenamiento de fotos');
        }
        $escala = min(1.0, self::LADO / max($info[0], $info[1]));
        $imagen = imagescale($entrada, max(1, (int) round($info[0] * $escala)), max(1, (int) round($info[1] * $escala)));
        if ($imagen === false) {
            throw new RuntimeException('No se pudo ajustar la foto');
        }
        imagepalettetotruecolor($imagen);
        $clave = bin2hex(random_bytes(16));
        $temporal = $this->carpeta . '/' . $clave . '.tmp';
        $destino = $this->carpeta . '/' . $clave . '.webp';
        try {
            if (!imagewebp($imagen, $temporal, 83) || !is_file($temporal) || filesize($temporal) === 0
                || !rename($temporal, $destino)) {
                throw new RuntimeException('No se pudo guardar la foto');
            }
        } finally {
            if (is_file($temporal)) {
                unlink($temporal);
            }
        }
        return '/fotos-menu/' . $clave . '.webp';
    }

    public function lee(string $clave): string
    {
        $archivo = $this->archivo($clave);
        if (!is_file($archivo) || ($foto = file_get_contents($archivo)) === false) {
            throw Errores::noEncontrado('Foto no disponible');
        }
        return $foto;
    }

    public function retiraRecienSubida(string $url): void
    {
        $archivo = $this->archivo(pathinfo($url, PATHINFO_FILENAME));
        if (is_file($archivo)) {
            unlink($archivo);
        }
    }

    private function archivo(string $clave): string
    {
        if (preg_match('/^[a-f0-9]{32}$/D', $clave) !== 1) {
            throw Errores::noEncontrado('Foto no disponible');
        }
        return $this->carpeta . '/' . $clave . '.webp';
    }
}
