<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\Cantidad;
use Dominio\DatosRestaurante as Datos;
use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;

final class InventarioRestaurante
{
    public function __construct(
        private BaseDatos $bd,
        private Identidad $identidad,
        private OperacionRestaurante $operacion
    ) {
    }

    public function datos(int $sucursal, string $tipo, array $historial = []): array
    {
        $this->operacion->consultaSucursal($sucursal);
        $consulta = match ($tipo) {
            'insumos' =>
                'SELECT i.id,i.nombre,i.unidad,COALESCE(SUM(l.saldo),0) AS saldo,
                 COALESCE(SUM(IF(l.vence < CURDATE(), l.saldo, 0)),0) AS vencido
                 FROM insumo i LEFT JOIN lote_insumo l ON l.id_insumo = i.id WHERE i.id_sucursal = ? AND i.activo = 1
                 GROUP BY i.id,i.nombre,i.unidad ORDER BY i.nombre, i.id',
            'lotes' =>
                'SELECT l.id,i.nombre,l.saldo,l.vence,l.costo FROM insumo i JOIN lote_insumo l ON l.id_insumo = i.id
                 WHERE i.id_sucursal = ? AND l.saldo > 0 ORDER BY l.vence IS NULL, l.vence, l.id',
            'compras', 'movimientos' => null,
            'proveedores' => 'SELECT id,nombre,contacto FROM proveedor WHERE id_sucursal = ? AND activo = 1 ORDER BY nombre, id',
            'recetas' =>
                'SELECT r.id_platillo,r.id_insumo,p.nombre AS platillo,i.nombre AS insumo,r.cantidad
                 FROM receta_insumo r JOIN platillo p ON p.id = r.id_platillo JOIN insumo i ON i.id = r.id_insumo
                 WHERE r.id_sucursal = ? ORDER BY p.nombre, i.nombre, r.id_platillo, r.id_insumo',
            default => throw Errores::noEncontrado(),
        };
        $resultado = [$tipo => $consulta === null ? $historial : $this->bd->filas($consulta, [$sucursal])];
        if (in_array($tipo, ['compras', 'recetas', 'movimientos', 'lotes'], true)) {
            $activos = $tipo === 'movimientos' ? '' : ' AND activo = 1';
            $resultado['insumos'] = $this->bd->filas('SELECT id,nombre FROM insumo WHERE id_sucursal = ?' . $activos . ' ORDER BY nombre, id',
                [$sucursal]);
            if ($tipo === 'compras') {
                $resultado['proveedores'] = $this->bd->filas('SELECT id,nombre FROM proveedor WHERE id_sucursal = ? AND activo = 1 ORDER BY nombre, id',
                    [$sucursal]);
            } elseif ($tipo === 'recetas') {
                $resultado['platillos'] = $this->bd->filas(
                    'SELECT p.id,p.nombre FROM platillo_sucursal ps JOIN platillo p ON ps.id_platillo = p.id
                     WHERE ps.id_sucursal = ? ORDER BY p.nombre, p.id', [$sucursal]
                );
            }
        }
        return $resultado;
    }

    public function guarda(int $sucursal, string $accion, array $datos): void
    {
        $this->bd->transaccion(function () use ($sucursal, $accion, $datos): void {
            $this->operacion->bloqueaSucursal($sucursal);
            $id = match ($accion) {
                'insumo' => $this->bd->inserta('INSERT INTO insumo (id_sucursal,nombre,unidad) VALUES (?, ?, ?)', [
                    $sucursal, Datos::texto($datos['nombre'] ?? '', 'nombre', 100), Datos::texto($datos['unidad'] ?? '', 'unidad', 20),
                ]),
                'proveedor' => $this->bd->inserta('INSERT INTO proveedor (id_sucursal,nombre,contacto) VALUES (?, ?, ?)', [
                    $sucursal, Datos::texto($datos['nombre'] ?? '', 'nombre', 100), Datos::texto($datos['contacto'] ?? '', 'contacto', 100, false),
                ]),
                'receta' => $this->receta($sucursal, $datos),
                'compra' => $this->compra($sucursal, $datos),
                'recibir' => $this->recibe($sucursal, Datos::entero($datos['id_compra'] ?? null, 'id_compra'), $datos['recibidas'] ?? null),
                'cancelar-compra' => $this->cancelaCompra($sucursal, Datos::entero($datos['id_compra'] ?? null, 'id_compra')),
                'existencia-inicial' => $this->inicial($sucursal, $datos),
                'merma', 'conteo' => $this->ajuste($sucursal, $accion, $datos),
                default => throw Errores::noEncontrado(),
            };
            $this->operacion->registra($sucursal, 'inventario_' . $accion, $id);
        });
    }

    public function faltantes(int $sucursal, string $estado): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->filas(
            'SELECT f.id, f.id_cuenta, f.cantidad, f.creado_en, f.atendido_en, f.nota,
                    i.nombre AS insumo, i.unidad, p.folio, u.usuario AS atendio
             FROM faltante_insumo f JOIN insumo i ON i.id = f.id_insumo
             LEFT JOIN pago_cuenta p ON p.id_cuenta = f.id_cuenta
             LEFT JOIN usuario u ON u.id = f.atendido_por
             WHERE f.id_sucursal = ?' . match ($estado) {
                 'pendientes' => ' AND f.atendido_en IS NULL', 'atendidos' => ' AND f.atendido_en IS NOT NULL', default => '',
             } . ' ORDER BY f.id DESC',
            [$sucursal]
        );
    }

    public function detalleCatalogo(int $sucursal, int $id, string $tipo): array
    {
        $this->operacion->consultaSucursal($sucursal);
        [$tabla, $campo] = $this->catalogo($tipo);
        return $this->bd->fila('SELECT id,nombre,' . $campo . ' FROM ' . $tabla . ' WHERE id_sucursal = ? AND id = ? AND activo = 1',
            [$sucursal, $id]) ?? throw Errores::noEncontrado('Registro no disponible');
    }

    public function cambiaCatalogo(int $sucursal, int $id, string $tipo, ?array $datos): void
    {
        [$tabla, $campo] = $this->catalogo($tipo);
        $this->bd->transaccion(function () use ($sucursal, $id, $tabla, $campo, $datos): void {
            $this->operacion->bloqueaSucursal($sucursal);
            $actual = $this->bd->valor('SELECT id FROM ' . $tabla . ' WHERE id_sucursal = ? AND id = ? AND activo = 1 FOR UPDATE',
                [$sucursal, $id]);
            if ($actual === null) {
                throw Errores::noEncontrado('Registro no disponible');
            }
            if ($datos === null) {
                $this->exigeBaja($sucursal, $tabla, $id);
                $this->bd->ejecuta('UPDATE ' . $tabla . ' SET activo = 0 WHERE id_sucursal = ? AND id = ?', [$sucursal, $id]);
                $this->operacion->registra($sucursal, 'inventario_' . $tabla . '_baja', $id);
            } else {
                $nombre = Datos::texto($datos['nombre'] ?? '', 'nombre', 100);
                $valor = Datos::texto($datos[$campo] ?? '', $campo, $tabla === 'insumo' ? 20 : 100, $tabla === 'insumo');
                $this->bd->ejecuta('UPDATE ' . $tabla . ' SET nombre = ?, ' . $campo . ' = ? WHERE id_sucursal = ? AND id = ?',
                    [$nombre, $valor, $sucursal, $id]);
                $this->operacion->registra($sucursal, 'inventario_' . $tabla . '_edita', $id, ['nombre' => $nombre, $campo => $valor]);
            }
        });
    }

    private function catalogo(string $tipo): array
    {
        return match ($tipo) {
            'insumos' => ['insumo', 'unidad'],
            'proveedores' => ['proveedor', 'contacto'],
            default => throw Errores::noEncontrado(),
        };
    }

    private function exigeBaja(int $sucursal, string $tabla, int $id): void
    {
        if ($tabla === 'proveedor') {
            if ($this->bd->valor(
                "SELECT id FROM compra_insumo WHERE id_proveedor = ? AND estado IN ('ordenada','parcial') LIMIT 1",
                [$id]
            ) !== null) {
                throw Errores::conflicto('El proveedor tiene compras pendientes');
            }
            return;
        }
        if ($this->bd->valor('SELECT id FROM lote_insumo WHERE id_insumo = ? AND saldo > 0 LIMIT 1', [$id]) !== null
            || $this->bd->valor('SELECT id_platillo FROM receta_insumo WHERE id_sucursal = ? AND id_insumo = ? LIMIT 1', [$sucursal, $id]) !== null
            || $this->bd->valor(
                "SELECT l.id FROM compra_insumo_linea l JOIN compra_insumo c ON c.id = l.id_compra
                 WHERE l.id_insumo = ? AND c.estado IN ('ordenada','parcial') AND l.recibido < l.cantidad LIMIT 1",
                [$id]
            ) !== null) {
            throw Errores::conflicto('El insumo tiene saldo, recetas o compras pendientes');
        }
    }

    public function atiendeFaltante(int $sucursal, int $id, mixed $valor): void
    {
        $nota = Datos::texto($valor, 'nota', 160, false);
        $this->bd->transaccion(function () use ($sucursal, $id, $nota): void {
            $this->operacion->bloqueaSucursal($sucursal);
            $fila = $this->bd->fila('SELECT atendido_en FROM faltante_insumo WHERE id_sucursal = ? AND id = ? FOR UPDATE',
                [$sucursal, $id]) ?? throw Errores::noEncontrado('Faltante no disponible');
            if ($fila['atendido_en'] !== null) {
                throw Errores::conflicto('El faltante ya fue atendido');
            }
            $this->bd->ejecuta('UPDATE faltante_insumo SET atendido_en = NOW(), atendido_por = ?, nota = ? WHERE id = ?',
                [$this->identidad->id(), $nota === '' ? null : $nota, $id]);
            $this->operacion->registra($sucursal, 'inventario_faltante_atendido', $id);
        });
    }

    /**
     * Descuenta del almacén lo que las recetas de la cuenta piden.
     *
     * **Nunca detiene el cobro.** Si un insumo no alcanza, descuenta lo que
     * haya y deja el resto en `faltante_insumo`, para que almacén lo atienda.
     *
     * @return list<array{insumo: string, cantidad: string}> Lo que faltó.
     */
    public function consumeCuenta(int $sucursal, int $cuenta): array
    {
        $faltantes = [];
        $requeridos = $this->bd->filas(
            "SELECT r.id_insumo, SUM(r.cantidad * i.cantidad) AS requerido
             FROM cuenta_item i JOIN receta_insumo r ON r.id_platillo = i.id_platillo AND r.id_sucursal = ?
             WHERE i.id_cuenta = ? AND i.estado <> 'cancelado' GROUP BY r.id_insumo ORDER BY r.id_insumo",
            [$sucursal, $cuenta]
        );
        foreach ($requeridos as $r) {
            $falta = Cantidad::deCadena($r['requerido']);
            $lotes = $this->bd->filas(
                'SELECT id,saldo FROM lote_insumo WHERE id_insumo = ? AND saldo > 0 AND (vence IS NULL OR vence >= CURDATE())
                 ORDER BY vence IS NULL, vence, id FOR UPDATE', [$r['id_insumo']]
            );
            foreach ($lotes as $lote) {
                $saldo = Cantidad::deCadena($lote['saldo']);
                $consume = $saldo->comparaCon($falta) < 0 ? $saldo : $falta;
                $this->mueve((int) $lote['id'], $saldo->menos($consume), Cantidad::cero()->menos($consume), 'consumo', '', $cuenta);
                $falta = $falta->menos($consume);
                if ($falta->esCero()) {
                    break;
                }
            }
            if (!$falta->esCero()) {
                $this->bd->inserta('INSERT INTO faltante_insumo (id_sucursal,id_insumo,id_cuenta,cantidad) VALUES (?, ?, ?, ?)',
                    [$sucursal, $r['id_insumo'], $cuenta, $falta->aCadena()]);
                $faltantes[] = [
                    'insumo' => (string) $this->bd->valor('SELECT nombre FROM insumo WHERE id = ?', [$r['id_insumo']]),
                    'cantidad' => $falta->aCadena(),
                ];
            }
        }
        if ($faltantes !== []) {
            $this->operacion->registra($sucursal, 'inventario_faltante', $cuenta, ['faltantes' => $faltantes], $cuenta);
        }
        return $faltantes;
    }

    private function receta(int $sucursal, array $datos): int
    {
        $platillo = Datos::entero($datos['id_platillo'] ?? null, 'id_platillo');
        $insumo = Datos::entero($datos['id_insumo'] ?? null, 'id_insumo');
        $cantidad = $this->cantidad($datos['cantidad'] ?? '', true);
        if ($this->bd->valor('SELECT id_platillo FROM platillo_sucursal WHERE id_sucursal = ? AND id_platillo = ?', [$sucursal, $platillo]) === null) {
            throw Errores::noEncontrado('El platillo no está en la sucursal');
        }
        if ($cantidad->esCero()) {
            $this->bd->ejecuta('DELETE FROM receta_insumo WHERE id_sucursal = ? AND id_platillo = ? AND id_insumo = ?',
                [$sucursal, $platillo, $insumo]);
        } else {
            if ($this->bd->valor('SELECT id FROM insumo WHERE id_sucursal = ? AND id = ? AND activo = 1', [$sucursal, $insumo]) === null) {
                throw Errores::noEncontrado('Insumo no disponible');
            }
            $this->bd->ejecuta(
                'INSERT INTO receta_insumo (id_sucursal,id_platillo,id_insumo,cantidad) VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE cantidad = VALUES(cantidad)', [$sucursal, $platillo, $insumo, $cantidad->aCadena()]
            );
        }
        return $platillo;
    }

    private function compra(int $sucursal, array $datos): int
    {
        $proveedor = Datos::entero($datos['id_proveedor'] ?? null, 'id_proveedor');
        if ($this->bd->valor('SELECT id FROM proveedor WHERE id_sucursal = ? AND id = ? AND activo = 1', [$sucursal, $proveedor]) === null) {
            throw Errores::noEncontrado('Proveedor no disponible');
        }
        $referencia = Datos::texto($datos['referencia'] ?? '', 'referencia', 80);
        $lineas = $datos['lineas'] ?? [$datos];
        if (!is_array($lineas) || !array_is_list($lineas) || count($lineas) < 1 || count($lineas) > 100) {
            throw Errores::datosInvalidos(['lineas' => 'Capture hasta 100 renglones']);
        }
        $compra = $this->bd->inserta('INSERT INTO compra_insumo (id_sucursal,id_proveedor,id_usuario,referencia) VALUES (?, ?, ?, ?)',
            [$sucursal, $proveedor, $this->identidad->id(), $referencia]);
        foreach ($lineas as $linea) {
            if (!is_array($linea)) {
                throw Errores::datosInvalidos(['lineas' => 'Revise los renglones de la compra']);
            }
            $insumo = Datos::entero($linea['id_insumo'] ?? null, 'id_insumo');
            $cantidad = $this->cantidad($linea['cantidad'] ?? '');
            $costo = Datos::precio($linea['costo'] ?? '', 'costo')->aPesos();
            $vence = Datos::texto($linea['vence'] ?? '', 'vence', 10, false);
            $vence = $this->caducidad($vence);
            if ($this->bd->valor('SELECT id FROM insumo WHERE id = ? AND id_sucursal = ? AND activo = 1', [$insumo, $sucursal]) === null) {
                throw Errores::noEncontrado('Insumo no disponible');
            }
            $this->bd->inserta('INSERT INTO compra_insumo_linea (id_compra,id_insumo,cantidad,costo,vence) VALUES (?, ?, ?, ?, ?)',
                [$compra, $insumo, $cantidad->aCadena(), $costo, $vence]);
        }
        return $compra;
    }

    public function detalleCompra(int $sucursal, int $id): array
    {
        $this->operacion->consultaSucursal($sucursal);
        $compra = $this->bd->fila(
            'SELECT c.id,c.referencia,c.estado,c.creada_en,p.nombre AS proveedor
             FROM compra_insumo c JOIN proveedor p ON p.id = c.id_proveedor WHERE c.id_sucursal = ? AND c.id = ?',
            [$sucursal, $id]
        ) ?? throw Errores::noEncontrado('Compra no disponible');
        $compra['lineas'] = $this->bd->filas(
            'SELECT l.id,i.nombre AS insumo,l.cantidad,l.recibido,l.cantidad - l.recibido AS pendiente,l.costo,l.vence
             FROM compra_insumo_linea l JOIN insumo i ON i.id = l.id_insumo WHERE l.id_compra = ? ORDER BY l.id', [$id]
        );
        return $compra;
    }

    private function recibe(int $sucursal, int $id, mixed $captura): int
    {
        $estado = $this->bd->valor('SELECT estado FROM compra_insumo WHERE id_sucursal = ? AND id = ? FOR UPDATE', [$sucursal, $id])
            ?? throw Errores::noEncontrado('Compra no disponible');
        if (!in_array($estado, ['ordenada', 'parcial'], true)) {
            throw Errores::conflicto('La orden no está pendiente');
        }
        $lineas = $this->bd->filas('SELECT id,id_insumo,cantidad,recibido,costo,vence FROM compra_insumo_linea WHERE id_compra = ? ORDER BY id', [$id]);
        if ($captura !== null && (!is_array($captura) || array_diff(array_keys($captura), array_column($lineas, 'id')) !== [])) {
            throw Errores::datosInvalidos(['recibidas' => 'Revise los renglones de la compra']);
        }
        $movidos = false;
        $queda = false;
        foreach ($lineas as $r) {
            $pendiente = Cantidad::deCadena($r['cantidad'])->menos(Cantidad::deCadena($r['recibido']));
            $valor = $captura[$r['id']] ?? '';
            $cantidad = $captura === null ? $pendiente : ($valor === '' ? Cantidad::cero() : $this->cantidad($valor, true));
            if ($cantidad->comparaCon($pendiente) > 0) {
                throw Errores::datosInvalidos(['recibidas[' . $r['id'] . ']' => 'La entrada supera lo pendiente']);
            }
            $queda = $queda || $cantidad->comparaCon($pendiente) < 0;
            if ($cantidad->esCero()) {
                continue;
            }
            $this->bd->ejecuta(
                'INSERT INTO lote_insumo (id_insumo,id_compra_linea,vence,saldo,costo) VALUES (?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE saldo = saldo + VALUES(saldo)',
                [$r['id_insumo'], $r['id'], $r['vence'], $cantidad->aCadena(), $r['costo']]
            );
            $lote = (int) $this->bd->valor('SELECT id FROM lote_insumo WHERE id_compra_linea = ?', [$r['id']]);
            $this->bd->ejecuta("INSERT INTO kardex_insumo (id_lote,id_usuario,tipo,cantidad) VALUES (?, ?, 'entrada', ?)",
                [$lote, $this->identidad->id(), $cantidad->aCadena()]);
            $this->bd->ejecuta('UPDATE compra_insumo_linea SET recibido = recibido + ? WHERE id = ?', [$cantidad->aCadena(), $r['id']]);
            $movidos = true;
        }
        if (!$movidos) {
            throw Errores::datosInvalidos(['recibidas' => 'Capture al menos una cantidad']);
        }
        $this->bd->ejecuta('UPDATE compra_insumo SET estado = ?, recibida_en = IF(?, NULL, NOW()) WHERE id = ?',
            [$queda ? 'parcial' : 'recibida', $queda ? 1 : 0, $id]);
        return $id;
    }

    private function cancelaCompra(int $sucursal, int $id): int
    {
        if ($this->bd->ejecuta("UPDATE compra_insumo SET estado = 'cancelada'
             WHERE id_sucursal = ? AND id = ? AND estado IN ('ordenada', 'parcial')", [$sucursal, $id]) !== 1) {
            throw Errores::conflicto('La orden no está pendiente');
        }
        return $id;
    }

    private function inicial(int $sucursal, array $datos): int
    {
        $insumo = Datos::entero($datos['id_insumo'] ?? null, 'id_insumo');
        $cantidad = $this->cantidad($datos['cantidad'] ?? '');
        $costo = Datos::precio($datos['costo'] ?? '', 'costo')->aPesos();
        $vence = $this->caducidad(Datos::texto($datos['vence'] ?? '', 'vence', 10, false));
        if ($this->bd->valor('SELECT id FROM insumo WHERE id = ? AND id_sucursal = ? AND activo = 1', [$insumo, $sucursal]) === null) {
            throw Errores::noEncontrado('Insumo no disponible');
        }
        $lote = $this->bd->inserta('INSERT INTO lote_insumo (id_insumo,vence,saldo,costo) VALUES (?, ?, ?, ?)',
            [$insumo, $vence, $cantidad->aCadena(), $costo]);
        $this->bd->ejecuta("INSERT INTO kardex_insumo (id_lote,id_usuario,tipo,cantidad,motivo) VALUES (?, ?, 'entrada', ?, 'Existencia inicial')",
            [$lote, $this->identidad->id(), $cantidad->aCadena()]);
        return $lote;
    }

    private function caducidad(string $vence): ?string
    {
        if ($vence === '') {
            return null;
        }
        $fecha = \DateTimeImmutable::createFromFormat('!Y-m-d', $vence);
        if ($fecha === false || $fecha->format('Y-m-d') !== $vence) {
            throw Errores::datosInvalidos(['vence' => 'Capture una fecha válida']);
        }
        return $vence;
    }

    private function ajuste(int $sucursal, string $accion, array $datos): int
    {
        $lote = Datos::entero($datos['id_lote'] ?? null, 'id_lote');
        $cantidad = $this->cantidad($datos['cantidad'] ?? '', $accion === 'conteo');
        $motivo = Datos::texto($datos['motivo'] ?? '', 'motivo', 160);
        $actual = $this->bd->valor(
            'SELECT l.saldo FROM lote_insumo l JOIN insumo i ON i.id = l.id_insumo
             WHERE l.id = ? AND i.id_sucursal = ? FOR UPDATE', [$lote, $sucursal]
        ) ?? throw Errores::noEncontrado('Lote no disponible');
        $antes = Cantidad::deCadena($actual);
        $despues = $accion === 'merma' ? $antes->menos($cantidad) : $cantidad;
        if ($despues->milesimas() < 0) {
            throw Errores::conflicto('La merma supera el saldo del lote');
        }
        $this->mueve($lote, $despues, $despues->menos($antes), $accion, $motivo);
        return $lote;
    }

    private function mueve(int $lote, Cantidad $saldo, Cantidad $cambio, string $tipo, string $motivo, ?int $cuenta = null): void
    {
        $this->bd->ejecuta('UPDATE lote_insumo SET saldo = ? WHERE id = ?', [$saldo->aCadena(), $lote]);
        $this->bd->inserta(
            'INSERT INTO kardex_insumo (id_lote,id_usuario,id_cuenta,tipo,cantidad,motivo) VALUES (?, ?, ?, ?, ?, ?)',
            [$lote, $this->identidad->id(), $cuenta, $tipo, $cambio->aCadena(), $motivo]
        );
    }

    private function cantidad(mixed $valor, bool $admiteCero = false): Cantidad
    {
        if (!(is_int($valor) || is_string($valor)) || !preg_match('/^\d{1,7}(?:\.\d{1,3})?$/D', (string) $valor)) {
            throw Errores::datosInvalidos(['cantidad' => 'Capture una cantidad con hasta tres decimales']);
        }
        $cantidad = Cantidad::deCadena((string) $valor);
        if (!$admiteCero && $cantidad->esCero()) {
            throw Errores::datosInvalidos(['cantidad' => 'Capture una cantidad mayor que cero']);
        }
        return $cantidad;
    }
}
