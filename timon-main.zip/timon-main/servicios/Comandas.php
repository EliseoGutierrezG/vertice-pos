<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\DatosRestaurante as Datos;
use Dominio\Dinero;
use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;

final class Comandas
{
    /** El importe de un renglón: lo que se cobra después de su promoción. */
    public const IMPORTE_SQL = 'cantidad * precio - descuento';

    public static function importe(array $item): Dinero
    {
        return Dinero::deCadena((string) $item['precio'])->porEntero((int) $item['cantidad'])
            ->menos(Dinero::deCadena((string) ($item['descuento'] ?? '0')));
    }

    public function __construct(
        private BaseDatos $bd,
        private OperacionRestaurante $operacion,
        private Identidad $identidad,
        private ImpresionRestaurante $impresion,
        private AutorizacionRestaurante $autorizacion,
        private Reservaciones $reservaciones,
        private Promociones $promociones
    ) {
    }

    public function plano(int $sucursal, ?int $mesa = null): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->transaccion(fn (): array => [
            'cursor' => (int) $this->bd->valor(
                'SELECT COALESCE(MAX(id), 0) FROM evento_sucursal WHERE id_sucursal = ?', [$sucursal]
            ),
            'areas' => $this->bd->filas('SELECT id, nombre FROM area WHERE id_sucursal = ? AND activa = 1 ORDER BY nombre', [$sucursal]),
            'mesas' => $this->bd->filas(
                "SELECT m.id, m.id_area, m.numero, m.capacidad, m.forma, m.x, m.y,
                        COALESCE(c.estado, IF(m.estado = 'libre' AND EXISTS (
                            SELECT 1 FROM reservacion r WHERE r.id_mesa = m.id AND r.estado = 'confirmada'
                            AND r.desde <= DATE_ADD(NOW(), INTERVAL ? MINUTE) AND r.hasta > NOW()
                        ), 'reservada', m.estado)) AS estado, c.id AS id_cuenta, c.version,
                        c.abierta_en, p.nombre AS mesero, TIMESTAMPDIFF(MINUTE, c.abierta_en, NOW()) AS minutos,
                        COALESCE((SELECT SUM(i.cantidad)
                         FROM cuenta familia JOIN cuenta_item i ON i.id_cuenta = familia.id
                         WHERE familia.id_sucursal = m.id_sucursal AND i.estado = 'listo'
                           AND (familia.id = COALESCE(c.id_cuenta_madre, c.id)
                             OR familia.id_cuenta_madre = COALESCE(c.id_cuenta_madre, c.id))), 0) AS listos
                 FROM mesa m
                 LEFT JOIN cuenta_mesa cm ON cm.id_mesa = m.id AND cm.abierta = 1
                 LEFT JOIN cuenta c ON c.id = cm.id_cuenta
                 LEFT JOIN usuario u ON u.id = c.id_mesero
                 LEFT JOIN personal p ON p.id = u.id_personal
                 WHERE m.id_sucursal = ? AND m.activa = 1" . ($mesa === null ? '' : ' AND m.id = ?') . ' ORDER BY m.id_area, m.numero',
                $mesa === null ? [Reservaciones::MINUTOS_ANTES, $sucursal] : [Reservaciones::MINUTOS_ANTES, $sucursal, $mesa]
            ),
        ]);
    }

    /**
     * Lo que pasó en la sucursal después de `$desde`. Sin `$desde` no devuelve
     * eventos, sólo el cursor de ahora: así empieza a escuchar un equipo que
     * no carga el plano, como el impresor.
     */
    public function cambios(int $sucursal, ?int $desde): array
    {
        $this->operacion->consultaSucursal($sucursal);
        if ($desde === null) {
            return ['eventos' => [], 'cursor' => $this->cursor($sucursal)];
        }
        $eventos = $this->bd->filas(
            'SELECT id, tipo, entidad, id_cuenta, creado_en FROM evento_sucursal
             WHERE id_sucursal = ? AND id > ? ORDER BY id LIMIT 200',
            [$sucursal, $desde]
        );
        return ['eventos' => $eventos, 'cursor' => (int) (end($eventos)['id'] ?? $desde)];
    }

    /** El último evento de la sucursal. Se lee **antes** que los datos, para no perder un cambio. */
    public function cursor(int $sucursal): int
    {
        return (int) $this->bd->valor('SELECT COALESCE(MAX(id), 0) FROM evento_sucursal WHERE id_sucursal = ?', [$sucursal]);
    }

    public function cuenta(int $sucursal, int $id): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->transaccion(function () use ($sucursal, $id): array {
            $cuenta = $this->buscaCuenta($sucursal, $id);
            $grupo = $cuenta['tipo'] === 'mesa' ? (int) ($cuenta['id_cuenta_madre'] ?? $id) : null;
            $cuenta['grupo'] = $grupo === null ? [] : $this->grupoAbierto($sucursal, $grupo);
            $titular = $id;
            foreach ($cuenta['grupo'] as $separada) {
                if ($separada['id_mesa'] !== null) {
                    $titular = (int) $separada['id'];
                    break;
                }
            }
            $cuenta['mesas'] = $this->bd->filas(
                'SELECT m.id, m.numero FROM cuenta_mesa cm JOIN mesa m ON m.id = cm.id_mesa
                 WHERE cm.id_cuenta = ? AND cm.abierta = 1 ORDER BY m.numero',
                [$titular]
            );
            $cuenta['items'] = $this->bd->filas(
                'SELECT id, id_platillo, id_ronda, platillo, cantidad, precio, descuento, promocion, modificadores, nota,
                        tiempo, asiento, estado, motivo
                 FROM cuenta_item WHERE id_cuenta = ? ORDER BY id',
                [$id]
            );
            $total = Dinero::cero();
            foreach ($cuenta['items'] as &$item) {
                $item['modificadores'] = json_decode($item['modificadores'], true, flags: JSON_THROW_ON_ERROR);
                if ($item['estado'] !== 'cancelado') {
                    $total = $total->mas(self::importe($item));
                }
            }
            $cuenta['consumo'] = $total->aPesos();
            $cuenta['total'] = $total->mas(Dinero::deCadena($cuenta['ajuste_reparto']))->aPesos();
            return $cuenta;
        });
    }

    public function abrir(int $sucursal, string $llave, array $datos): array
    {
        $tipo = Datos::opcion($datos['tipo'] ?? 'mesa', 'tipo', ['mesa', 'llevar', 'domicilio']);
        $mesa = $tipo === 'mesa' ? Datos::entero($datos['id_mesa'] ?? null, 'id_mesa') : null;
        $cliente = $tipo === 'mesa' ? null : Datos::texto($datos['cliente'] ?? '', 'cliente', 100);
        $telefono = $tipo === 'mesa' ? null : Datos::texto($datos['telefono'] ?? '', 'telefono', 25, $tipo === 'domicilio');
        $direccion = $tipo === 'domicilio' ? Datos::texto($datos['direccion'] ?? '', 'direccion', 250) : null;
        $comensales = in_array($datos['comensales'] ?? null, [null, ''], true)
            ? null : Datos::entero($datos['comensales'], 'comensales', 1, 99);

        return $this->operacion->unaVez($sucursal, $llave, 'cuenta_abierta', [$tipo, $mesa, $cliente, $telefono, $direccion, $comensales],
            function () use ($sucursal, $mesa, $tipo, $cliente, $telefono, $direccion, $comensales): array {
                if ($mesa !== null) {
                    $this->exigeMesaLibre($sucursal, $mesa);
                }
                $id = $this->bd->inserta(
                    'INSERT INTO cuenta (id_sucursal, id_mesa, id_mesero, tipo, cliente, telefono, direccion, comensales, entrega)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [$sucursal, $mesa, $this->identidad->id(), $tipo, $cliente, $telefono, $direccion, $comensales,
                        $tipo === 'mesa' ? null : 'recibido']
                );
                if ($mesa !== null) {
                    $this->asignaMesa($sucursal, $id, $mesa);
                }
                $this->operacion->registra($sucursal, 'cuenta_abierta', $id, ['mesa' => $mesa, 'tipo' => $tipo], $id);
                return ['id' => $id, 'version' => 1, 'estado' => 'ocupada'];
            }
        );
    }

    public function cambiarMesa(int $sucursal, int $id, int $version, int $mesa, string $llave): array
    {
        return $this->modifica($sucursal, $id, $version, $llave, 'mesa_cambiada', [$mesa],
            function (array $cuenta) use ($sucursal, $id, $mesa): array {
                if ($cuenta['tipo'] !== 'mesa' || $cuenta['id_mesa'] === null) {
                    throw Errores::conflicto('Esta cuenta no corresponde a una mesa');
                }
                $this->exigeMesaLibre($sucursal, $mesa);
                $anterior = (int) $cuenta['id_mesa'];
                $this->asignaMesa($sucursal, $id, $mesa);
                $this->bd->ejecuta('UPDATE cuenta_mesa SET abierta = NULL WHERE id_cuenta = ? AND id_mesa = ? AND abierta = 1', [$id, $anterior]);
                $this->bd->ejecuta('UPDATE cuenta SET id_mesa = ? WHERE id = ?', [$mesa, $id]);
                $this->bd->ejecuta("UPDATE mesa SET estado = 'por_limpiar' WHERE id = ?",
                    [$anterior]);
                return ['id_mesa' => $mesa];
            }
        );
    }

    public function unirMesa(int $sucursal, int $id, int $version, int $mesa, string $llave): array
    {
        return $this->modifica($sucursal, $id, $version, $llave, 'mesa_unida', [$mesa],
            function (array $cuenta) use ($sucursal, $id, $mesa): array {
                if ($cuenta['tipo'] !== 'mesa' || $cuenta['id_mesa'] === null) {
                    throw Errores::conflicto('Esta cuenta no corresponde a una mesa');
                }
                $this->exigeMesaLibre($sucursal, $mesa);
                $this->asignaMesa($sucursal, $id, $mesa);
                return ['id_mesa' => $mesa];
            }
        );
    }

    public function agregar(int $sucursal, int $id, string $llave, array $datos): array
    {
        $platillo = Datos::entero($datos['id_platillo'] ?? null, 'id_platillo');
        $cantidad = Datos::entero($datos['cantidad'] ?? 1, 'cantidad', 1, 99);
        $nota = Datos::texto($datos['nota'] ?? '', 'nota', 240, false);
        $tiempo = Datos::opcion($datos['tiempo'] ?? 'fuerte', 'tiempo', ['entrada', 'fuerte']);
        $asiento = isset($datos['asiento']) && $datos['asiento'] !== ''
            ? Datos::entero($datos['asiento'], 'asiento', 1, 99) : null;
        $ids = self::idsModificadores($datos['modificadores'] ?? []);

        return $this->modificaAbierta($sucursal, $id, $llave, 'item_capturado', [$platillo, $cantidad, $nota, $tiempo, $asiento, $ids],
            function (array $cuenta) use ($sucursal, $id, $platillo, $cantidad, $nota, $tiempo, $asiento, $ids): array {
                // Con platillos nuevos la precuenta impresa ya no vale: la
                // cuenta vuelve a «ocupada» y se puede pedir otra.
                if ($cuenta['estado'] === 'cuenta_pedida') {
                    $this->bd->ejecuta("UPDATE cuenta SET estado = 'ocupada' WHERE id = ?",
                        [$id]);
                }
                [$opcion, $base, $precio, $modificadores] = $this->precioCaptura($sucursal, $platillo, $ids, true);
                // La promoción se fija al capturar: si su horario termina con
                // la cuenta abierta, lo ya capturado la conserva.
                $promocion = Promociones::mejor(
                    $this->promociones->vigentesPara($sucursal, new \DateTimeImmutable())[$platillo] ?? [],
                    $base, $precio->menos($base)
                );
                $item = $this->bd->inserta(
                    'INSERT INTO cuenta_item (id_cuenta, id_platillo, platillo, preparacion, cantidad, precio, modificadores, nota, tiempo, asiento,
                        id_promocion, promocion)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [$id, $platillo, $opcion['nombre'], $opcion['preparacion'], $cantidad, $precio->aPesos(),
                        json_encode($modificadores, JSON_THROW_ON_ERROR), $nota, $tiempo, $asiento,
                        $promocion['id'] ?? null, Promociones::rotulo($promocion)]
                );
                return ['id_item' => $item, 'promocion' => $promocion['nombre'] ?? null];
            }
        );
    }

    /**
     * El precio de lista de una captura: el del platillo en la sucursal más los
     * suplementos de sus modificadores. Lo usan la captura y la cotización de
     * mostrador, para que las dos lleguen al mismo centavo.
     *
     * @param list<int> $ids
     * @return array{0: array<string,mixed>, 1: Dinero, 2: Dinero, 3: list<array<string,mixed>>}
     */
    public function precioCaptura(int $sucursal, int $platillo, array $ids, bool $bloquea): array
    {
        $candado = $bloquea ? ' FOR UPDATE' : '';
        $opcion = $this->bd->fila(
            'SELECT p.nombre, p.preparacion, ps.precio, ps.agotado
             FROM platillo p JOIN platillo_sucursal ps ON ps.id_platillo = p.id
             WHERE ps.id_sucursal = ? AND p.id = ? AND p.activo = 1' . $candado,
            [$sucursal, $platillo]
        );
        if ($opcion === null || (int) $opcion['agotado'] === 1) {
            throw Errores::conflicto('El platillo ya no está disponible');
        }
        $base = Dinero::deCadena($opcion['precio']);
        $precio = $base;
        $modificadores = [];
        foreach ($ids as $idModificador) {
            $modificador = $this->bd->fila(
                'SELECT id, nombre, suplemento FROM modificador_platillo
                 WHERE id_platillo = ? AND id = ? AND activo = 1' . $candado,
                [$platillo, $idModificador]
            );
            if ($modificador === null) {
                throw Errores::conflicto('Un modificador ya no está disponible');
            }
            $modificadores[] = $modificador;
            $precio = $precio->mas(Dinero::deCadena($modificador['suplemento']));
        }
        if ($precio->comparaCon(Dinero::deCadena('99999999.99')) > 0) {
            throw Errores::datosInvalidos(['modificadores' => 'El precio con modificadores supera el límite']);
        }
        return [$opcion, $base, $precio, $modificadores];
    }

    /** Los modificadores de una captura, validados y ordenados. @return list<int> */
    public static function idsModificadores(mixed $ids): array
    {
        if (!is_array($ids) || !array_is_list($ids) || count($ids) > 20) {
            throw Errores::datosInvalidos(['modificadores' => 'Seleccione hasta 20 modificadores']);
        }
        $ids = array_values(array_unique(array_map(fn ($v) => Datos::entero($v, 'modificadores'), $ids)));
        sort($ids);
        return $ids;
    }

    public function enviar(int $sucursal, int $id, string $llave): array
    {
        return $this->modificaAbierta($sucursal, $id, $llave, 'ronda_enviada', [],
            function (array $cuenta) use ($id, $sucursal): array {
                $ronda = $this->bd->inserta('INSERT INTO ronda (id_cuenta, id_usuario) VALUES (?, ?)',
                    [$id, $this->identidad->id()]);
                if ($this->bd->ejecuta(
                    "UPDATE cuenta_item SET id_ronda = ?, estado = 'enviado', estado_en = NOW()
                     WHERE id_cuenta = ? AND estado = 'capturado'",
                    [$ronda, $id]
                ) === 0) {
                    throw Errores::conflicto('Agregue platillos antes de enviar a cocina');
                }
                $porArea = [];
                $items = $this->bd->filas('SELECT preparacion, cantidad, platillo, asiento, nota, modificadores
                     FROM cuenta_item WHERE id_ronda = ? ORDER BY id', [$ronda]);
                foreach ($items as $item) {
                    $porArea[$item['preparacion']][] = $item['cantidad'] . ' x ' . $item['platillo']
                        . ($item['asiento'] === null ? '' : ' · Asiento ' . $item['asiento']);
                    foreach (json_decode($item['modificadores'], true, flags: JSON_THROW_ON_ERROR) as $modificador) {
                        $porArea[$item['preparacion']][] = '  ' . $modificador['nombre'];
                    }
                    if ($item['nota'] !== '') {
                        $porArea[$item['preparacion']][] = '  ' . $item['nota'];
                    }
                }
                $mesa = $this->numeroMesa($sucursal, $cuenta);
                $origen = match (true) {
                    $mesa !== null => 'Mesa ' . $mesa,
                    $cuenta['tipo'] === 'mostrador' => 'Mostrador #' . $id,
                    default => ucfirst($cuenta['tipo']) . ' #' . $id,
                };
                foreach ($porArea as $area => $lineas) {
                    $this->impresion->encola($sucursal, $area, 'comanda', $ronda, [
                        $origen . ' · Ronda #' . $ronda, MenuRestaurante::AREAS[$area], ...$lineas,
                    ]);
                }
                return ['id_ronda' => $ronda];
            },
            cambiaContenido: false
        );
    }

    /** Imprime la precuenta. Se puede pedir de nuevo: cada vez sale con lo que haya. */
    public function pedirCuenta(int $sucursal, int $id, string $llave): array
    {
        return $this->modificaAbierta($sucursal, $id, $llave, 'cuenta_pedida', [],
            function () use ($id, $sucursal): array {
                $this->bd->ejecuta("UPDATE cuenta SET estado = 'cuenta_pedida' WHERE id = ?",
                    [$id]);
                $ficha = $this->cuenta($sucursal, $id);
                $lineas = ['PRECUENTA #' . $id];
                foreach ($ficha['items'] as $item) {
                    if ($item['estado'] !== 'cancelado') {
                        $lineas[] = $item['cantidad'] . ' x ' . $item['platillo'] . ' $' . $item['precio'];
                        if (!Dinero::deCadena($item['descuento'])->esCero()) {
                            $lineas[] = '  ' . $item['promocion'] . ' -$' . $item['descuento'];
                        }
                    }
                }
                if (!Dinero::deCadena($ficha['ajuste_reparto'])->esCero()) {
                    $lineas[] = 'Ajuste por reparto: $' . $ficha['ajuste_reparto'];
                }
                $lineas[] = 'Total: $' . $ficha['total'];
                $this->impresion->encola($sucursal, 'caja', 'precuenta', $id, $lineas);
                return ['estado' => 'cuenta_pedida'];
            },
            cambiaContenido: false
        );
    }

    public function pedidos(int $sucursal): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->filas(
            "SELECT id, tipo, cliente, telefono, direccion, repartidor, entrega, estado, version, abierta_en
             FROM cuenta WHERE id_sucursal = ? AND tipo IN ('llevar','domicilio')
             AND (entrega NOT IN ('entregado','cancelado') OR abierta_en >= CURDATE()) ORDER BY id DESC LIMIT 200",
            [$sucursal]
        );
    }

    public function entrega(int $sucursal, int $id, string $llave, array $datos): array
    {
        $estado = Datos::opcion($datos['entrega'] ?? '', 'entrega', ['preparando','listo','en_camino','entregado','cancelado']);
        $repartidor = Datos::texto($datos['repartidor'] ?? '', 'repartidor', 100, $estado === 'en_camino');
        // El candado es la tabla de pasos: sólo se avanza desde el estado anterior.
        return $this->operacion->unaVez($sucursal, $llave, 'pedido_entrega', [$id, $estado, $repartidor],
            function () use ($sucursal, $id, $estado, $repartidor): array {
                $cuenta = $this->buscaCuenta($sucursal, $id, true);
                $permitidos = match ($cuenta['entrega']) {
                    'recibido' => ['preparando','cancelado'],
                    'preparando' => ['listo'],
                    'listo' => $cuenta['tipo'] === 'domicilio' ? ['en_camino'] : ['entregado'],
                    'en_camino' => ['entregado'],
                    default => [],
                };
                if (!in_array($estado, $permitidos, true)) {
                    throw Errores::conflicto('Cambió el estado del pedido')->conEstadoActual([
                        'id' => $id, 'version' => (int) $cuenta['version'], 'entrega' => $cuenta['entrega'],
                        'motivo' => 'estado',
                    ]);
                }
                if ($estado === 'cancelado') {
                    if ($this->bd->valor('SELECT id FROM cuenta_item WHERE id_cuenta = ? AND id_ronda IS NOT NULL LIMIT 1', [$id]) !== null
                        || $cuenta['abierta'] === null) {
                        throw Errores::conflicto('Cancele los platillos enviados con autorización de gerencia');
                    }
                    $this->bd->ejecuta("UPDATE cuenta SET abierta = NULL, estado = 'cancelada', cerrada_en = NOW() WHERE id = ?",
                    [$id]);
                }
                $this->bd->ejecuta('UPDATE cuenta SET entrega = ?, repartidor = COALESCE(?, repartidor) WHERE id = ?',
                    [$estado, $repartidor === '' ? null : $repartidor, $id]);
                $this->operacion->registra($sucursal, 'pedido_entrega', $id, ['entrega' => $estado], $id);
                return ['id' => $id, 'version' => (int) $cuenta['version'], 'entrega' => $estado];
            }
        );
    }

    public function cambiaItem(int $sucursal, int $id, string $llave, array $datos, string $ip): array
    {
        $item = Datos::entero($datos['id_item'] ?? null, 'id_item');
        $estado = Datos::opcion($datos['estado'] ?? null, 'estado', ['entregado','cancelado']);
        $motivo = Datos::texto($datos['motivo'] ?? '', 'motivo', 255, $estado === 'cancelado');
        return $this->modificaAbierta($sucursal, $id, $llave, 'item_' . $estado, [$item, $motivo],
            function () use ($sucursal, $id, $datos, $ip, $item, $estado, $motivo): array {
                $actual = $this->bd->valor('SELECT estado FROM cuenta_item WHERE id = ? AND id_cuenta = ? FOR UPDATE', [$item, $id])
                    ?? throw Errores::noEncontrado('Platillo no disponible');
                if ($actual === 'cancelado' || ($estado === 'entregado' && $actual !== 'listo')) {
                    throw Errores::conflicto('El platillo ya cambió de estado');
                }
                $firma = $estado === 'cancelado' && $actual !== 'capturado'
                    ? $this->autorizacion->valida($sucursal, 'cancela_platillo', $datos['autorizacion'] ?? null, $ip) : null;
                $this->bd->ejecuta(
                    'UPDATE cuenta_item SET estado = ?, estado_en = NOW(), cancelado_por = ?, motivo = ? WHERE id = ?',
                    [$estado, $firma, $motivo === '' ? null : $motivo, $item]
                );
                return ['id_item' => $item, 'estado_item' => $estado, 'gerente' => $firma, 'motivo' => $motivo];
            },
            // Entregar no cambia lo que se cobra; cancelar sí.
            cambiaContenido: $estado === 'cancelado'
        );
    }

    public function limpiaMesa(int $sucursal, int $mesa, string $llave): array
    {
        return $this->operacion->unaVez($sucursal, $llave, 'mesa_limpia', [$mesa], function () use ($sucursal, $mesa): array {
            if ($this->bd->ejecuta(
                "UPDATE mesa SET estado = 'libre' WHERE id = ? AND id_sucursal = ? AND estado = 'por_limpiar'",
                [$mesa, $sucursal]
            ) !== 1) {
                throw Errores::conflicto('La mesa ya cambió de estado');
            }
            $this->operacion->registra($sucursal, 'mesa_limpia', $mesa);
            return ['id' => $mesa, 'estado' => 'libre'];
        });
    }

    public function cancelaCuenta(int $sucursal, int $id, int $version, string $llave): array
    {
        return $this->modifica($sucursal, $id, $version, $llave, 'cuenta_cancelada', [],
            function (array $cuenta) use ($id, $sucursal): array {
                if (!Dinero::deCadena($cuenta['ajuste_reparto'])->esCero()) {
                    throw Errores::conflicto('La cuenta tiene un saldo de reparto');
                }
                if ($this->bd->valor("SELECT id FROM cuenta_item WHERE id_cuenta = ? AND estado <> 'cancelado' LIMIT 1",
                    [$id]) !== null) {
                    throw Errores::conflicto('Cancele los platillos antes de cerrar la cuenta');
                }
                $this->bd->ejecuta(
                    "UPDATE cuenta SET estado = 'cancelada', abierta = NULL, cerrada_en = NOW(),
                     entrega = IF(entrega IS NULL, NULL, 'cancelado') WHERE id = ?",
                    [$id]
                );
                $this->trasCerrar($sucursal, $cuenta);
                return ['estado' => 'cancelada'];
            }
        );
    }

    private function liberaMesas(int $cuenta): void
    {
        $this->bd->ejecuta(
            "UPDATE mesa m JOIN cuenta_mesa cm ON cm.id_mesa = m.id AND cm.abierta = 1
             SET m.estado = 'por_limpiar', cm.abierta = NULL WHERE cm.id_cuenta = ?",
            [$cuenta]
        );
    }

    public function grupoAbierto(int $sucursal, int $madre): array
    {
        return $this->bd->filas(
            'SELECT id, id_mesa, version, ajuste_reparto FROM cuenta
             WHERE id_sucursal = ? AND id_cuenta_madre = ? AND abierta = 1
             UNION ALL
             SELECT id, id_mesa, version, ajuste_reparto FROM cuenta
             WHERE id_sucursal = ? AND id = ? AND abierta = 1
             ORDER BY id',
            [$sucursal, $madre, $sucursal, $madre]
        );
    }

    public function trasCerrar(int $sucursal, array $cuenta): ?int
    {
        if ($cuenta['id_mesa'] === null) {
            return null;
        }
        $id = (int) $cuenta['id'];
        $abiertas = $this->grupoAbierto($sucursal, (int) ($cuenta['id_cuenta_madre'] ?? $id));
        if ($abiertas === []) {
            $this->liberaMesas($id);
            return null;
        }

        // La cuenta que se cerró conserva el historial. Las mesas siguen
        // ocupadas y pasan a la cuenta abierta más antigua del grupo.
        $siguiente = (int) $abiertas[0]['id'];
        $mesas = $this->bd->filas('SELECT id_mesa FROM cuenta_mesa WHERE id_cuenta = ? AND abierta = 1 FOR UPDATE', [$id]);
        $this->bd->ejecuta('UPDATE cuenta_mesa SET abierta = NULL WHERE id_cuenta = ? AND abierta = 1', [$id]);
        $this->bd->ejecuta('UPDATE cuenta SET id_mesa = ?, version = version + 1 WHERE id = ?', [$cuenta['id_mesa'], $siguiente]);
        foreach ($mesas as $mesa) {
            $this->asignaMesa($sucursal, $siguiente, (int) $mesa['id_mesa']);
        }
        $this->operacion->registra($sucursal, 'mesa_heredada', $siguiente, ['origen' => $id], $siguiente);
        return $siguiente;
    }

    public function iniciaMostrador(int $sucursal): int
    {
        $id = $this->bd->inserta(
            "INSERT INTO cuenta (id_sucursal, id_mesero, tipo) VALUES (?, ?, 'mostrador')",
            [$sucursal, $this->identidad->id()]
        );
        $this->operacion->registra($sucursal, 'cuenta_mostrador', $id, [], $id);
        return $id;
    }

    public function numeroMesa(int $sucursal, array $cuenta): ?string
    {
        $idMesa = $cuenta['id_mesa'];
        if ($idMesa === null && $cuenta['id_cuenta_madre'] !== null) {
            foreach ($this->grupoAbierto($sucursal, (int) $cuenta['id_cuenta_madre']) as $separada) {
                if ($separada['id_mesa'] !== null) {
                    $idMesa = $separada['id_mesa'];
                    break;
                }
            }
            $idMesa ??= $this->bd->valor('SELECT id_mesa FROM cuenta WHERE id = ? AND id_sucursal = ?',
                [$cuenta['id_cuenta_madre'], $sucursal]);
        }
        return $idMesa === null ? null : $this->bd->valor('SELECT numero FROM mesa WHERE id = ?', [$idMesa]);
    }

    private function exigeSaldoReparto(int $id, string $ajusteActual): void
    {
        $ajuste = Dinero::deCadena($ajusteActual);
        if (!$ajuste->esNegativo()) {
            return;
        }
        $consumo = $this->bd->valor(
            "SELECT COALESCE(SUM(" . self::IMPORTE_SQL . "), 0) FROM cuenta_item WHERE id_cuenta = ? AND estado <> 'cancelado'",
            [$id]
        );
        if (Dinero::deCadena($consumo)->mas($ajuste)->esNegativo()) {
            throw Errores::conflicto('Reúna el reparto antes de disminuir ese importe');
        }
    }

    public function transfiere(int $sucursal, int $cuenta, int $version, string $llave, array $datos): array
    {
        $item = Datos::entero($datos['id_item'] ?? null, 'id_item');
        $destino = Datos::entero($datos['id_destino'] ?? null, 'id_destino');
        if ($destino === $cuenta) {
            throw Errores::datosInvalidos(['id_destino' => 'Seleccione otra cuenta']);
        }
        return $this->modifica($sucursal, $cuenta, $version, $llave, 'item_transferido', [$item, $destino],
            function () use ($sucursal, $cuenta, $item, $destino): array {
                // Al destino sólo se le pide seguir abierto: recibir un
                // platillo no compite con lo que ahí se esté capturando.
                $otra = $this->buscaCuenta($sucursal, $destino, true);
                if ($otra['abierta'] === null) {
                    throw Errores::conflicto('La cuenta de destino ya está cerrada')->conEstadoActual([
                        'id' => $destino, 'version' => (int) $otra['version'], 'estado' => $otra['estado'],
                        'motivo' => 'cerrada',
                    ]);
                }
                $fila = $this->bd->fila(
                    "SELECT i.id_ronda,r.id_usuario,r.enviada_en
                     FROM cuenta_item i LEFT JOIN ronda r ON r.id = i.id_ronda
                     WHERE i.id = ? AND i.id_cuenta = ? AND i.estado <> 'cancelado' FOR UPDATE",
                    [$item, $cuenta]
                ) ?? throw Errores::noEncontrado('El platillo no está disponible');
                // Conserva su estado y hora de envío. Cocina lo ve ligado a la
                // cuenta de destino y no se vuelve a imprimir como una orden nueva.
                $ronda = $fila['id_ronda'] === null ? null : $this->bd->inserta(
                    'INSERT INTO ronda (id_cuenta, id_usuario, enviada_en) VALUES (?, ?, ?)',
                    [$destino, $fila['id_usuario'], $fila['enviada_en']]
                );
                $this->bd->ejecuta('UPDATE cuenta_item SET id_cuenta = ?, id_ronda = ? WHERE id = ?',
                    [$destino, $ronda, $item]);
                $this->promociones->recalcula($destino);
                $this->bd->ejecuta('UPDATE cuenta SET version = version + 1 WHERE id = ?', [$destino]);
                $this->operacion->registra($sucursal, 'item_recibido', $destino, ['item' => $item, 'origen' => $cuenta], $destino);
                return ['id_item' => $item, 'id_destino' => $destino, 'version_destino' => (int) $otra['version'] + 1];
            }
        );
    }

    /**
     * Una operación **exclusiva**: cobrar, cancelar, mover de mesa, transferir.
     *
     * Exige la versión exacta de la cuenta, porque quien la manda decidió con
     * un total o una ubicación que ya pudo cambiar. `estado_actual.motivo` dice
     * si la cuenta cambió (`version`) o ya se cerró (`cerrada`).
     */
    public function modifica(int $sucursal, int $id, int $version, string $llave, string $tipo, array $datos, callable $cambia): array
    {
        return $this->operacion->unaVez($sucursal, $llave, $tipo, [$id, $version, $datos],
            function () use ($sucursal, $id, $version, $tipo, $cambia): array {
                $cuenta = $this->buscaCuenta($sucursal, $id, true);
                if ($cuenta['abierta'] === null || (int) $cuenta['version'] !== $version) {
                    throw Errores::conflicto('La cuenta cambió. Revise el estado actual')->conEstadoActual([
                        'id' => $id, 'version' => (int) $cuenta['version'],
                        'estado' => $cuenta['estado'], 'id_mesa' => $cuenta['id_mesa'],
                        'motivo' => $cuenta['abierta'] === null ? 'cerrada' : 'version',
                    ]);
                }
                $cambios = $cambia($cuenta);
                $this->promociones->recalcula($id);
                $this->exigeSaldoReparto($id, $cambios['ajuste'] ?? $cuenta['ajuste_reparto']);
                $this->bd->ejecuta('UPDATE cuenta SET version = version + 1 WHERE id = ?', [$id]);
                $this->operacion->registra($sucursal, $tipo, $id, $cambios + ['version' => $version + 1], $id);
                return ['id' => $id, 'version' => $version + 1] + $cambios;
            }
        );
    }

    /**
     * Una operación **que no compite**: agregar o corregir un platillo, enviar
     * la ronda, pedir la precuenta, entregar.
     *
     * Sólo exige que la cuenta siga abierta. Dos equipos pueden hacerlas a la
     * vez sin estorbarse, y cocina puede avanzar mientras tanto. La huella no
     * lleva versión: reintentar con la misma llave siempre es la misma
     * operación. `$cambiaContenido` sube la versión cuando cambia lo que se
     * cobra, para que un cobro en curso se entere.
     */
    public function modificaAbierta(int $sucursal, int $id, string $llave, string $tipo, array $datos, callable $cambia, bool $cambiaContenido = true): array
    {
        return $this->operacion->unaVez($sucursal, $llave, $tipo, [$id, $datos],
            function () use ($sucursal, $id, $tipo, $cambia, $cambiaContenido): array {
                $cuenta = $this->buscaCuenta($sucursal, $id, true);
                if ($cuenta['abierta'] === null) {
                    throw Errores::conflicto('La cuenta ya está cerrada')->conEstadoActual([
                        'id' => $id, 'version' => (int) $cuenta['version'],
                        'estado' => $cuenta['estado'], 'id_mesa' => $cuenta['id_mesa'], 'motivo' => 'cerrada',
                    ]);
                }
                $cambios = $cambia($cuenta);
                $version = (int) $cuenta['version'] + ($cambiaContenido ? 1 : 0);
                if ($cambiaContenido) {
                    $this->promociones->recalcula($id);
                    $this->exigeSaldoReparto($id, $cuenta['ajuste_reparto']);
                    $this->bd->ejecuta('UPDATE cuenta SET version = version + 1 WHERE id = ?', [$id]);
                }
                $this->operacion->registra($sucursal, $tipo, $id, $cambios + ['version' => $version], $id);
                return ['id' => $id, 'version' => $version] + $cambios;
            }
        );
    }

    /** Corrige un platillo que todavía no se envía a cocina. */
    public function editaItem(int $sucursal, int $id, string $llave, array $datos): array
    {
        $item = Datos::entero($datos['id_item'] ?? null, 'id_item');
        $cantidad = Datos::entero($datos['cantidad'] ?? 1, 'cantidad', 1, 99);
        $nota = Datos::texto($datos['nota'] ?? '', 'nota', 240, false);
        $tiempo = Datos::opcion($datos['tiempo'] ?? 'fuerte', 'tiempo', ['entrada', 'fuerte']);
        $asiento = isset($datos['asiento']) && $datos['asiento'] !== ''
            ? Datos::entero($datos['asiento'], 'asiento', 1, 99) : null;

        return $this->modificaAbierta($sucursal, $id, $llave, 'item_corregido', [$item, $cantidad, $nota, $tiempo, $asiento],
            function () use ($id, $item, $cantidad, $nota, $tiempo, $asiento): array {
                $actual = $this->bd->valor('SELECT estado FROM cuenta_item WHERE id = ? AND id_cuenta = ? FOR UPDATE', [$item, $id])
                    ?? throw Errores::noEncontrado('Platillo no disponible');
                if ($actual !== 'capturado') {
                    throw Errores::conflicto('El platillo ya se envió a cocina');
                }
                $this->bd->ejecuta('UPDATE cuenta_item SET cantidad = ?, nota = ?, tiempo = ?, asiento = ? WHERE id = ?',
                    [$cantidad, $nota, $tiempo, $asiento, $item]);
                return ['id_item' => $item, 'cantidad' => $cantidad];
            }
        );
    }

    private function buscaCuenta(int $sucursal, int $id, bool $bloquea = false): array
    {
        $fila = $this->bd->fila(
            'SELECT id, id_sucursal, id_mesa, id_mesero, tipo, estado, abierta, version, abierta_en,
                    cerrada_en, cliente, telefono, direccion, repartidor, entrega, comensales, id_cuenta_madre, ajuste_reparto
             FROM cuenta WHERE id = ? AND id_sucursal = ?' . ($bloquea ? ' FOR UPDATE' : ''),
            [$id, $sucursal]
        );
        return $fila ?? throw Errores::noEncontrado('Cuenta no disponible');
    }

    private function exigeMesaLibre(int $sucursal, int $mesa): void
    {
        $fila = $this->bd->fila(
            "SELECT m.estado, cm.id_cuenta, c.version, c.estado AS estado_cuenta
             FROM mesa m LEFT JOIN cuenta_mesa cm ON cm.id_mesa = m.id AND cm.abierta = 1
             LEFT JOIN cuenta c ON c.id = cm.id_cuenta
             WHERE m.id = ? AND m.id_sucursal = ? AND m.activa = 1 FOR UPDATE",
                    [$mesa, $sucursal]
        );
        if ($fila === null) {
            throw Errores::noEncontrado('Mesa no disponible');
        }
        if ($fila['estado'] === 'libre' && $fila['id_cuenta'] === null && $this->reservaciones->bloqueaMesa($mesa)) {
            throw Errores::conflicto('La mesa está reservada')->conEstadoActual(['id_mesa' => $mesa, 'estado' => 'reservada']);
        }
        if ($fila['estado'] !== 'libre' || $fila['id_cuenta'] !== null) {
            throw Errores::conflicto('La mesa ya no está libre')->conEstadoActual([
                'id_mesa' => $mesa, 'estado' => $fila['estado_cuenta'] ?? $fila['estado'],
                'id_cuenta' => $fila['id_cuenta'], 'version' => $fila['version'],
            ]);
        }
    }

    private function asignaMesa(int $sucursal, int $id, int $mesa): void
    {
        $this->bd->ejecuta('INSERT INTO cuenta_mesa (id_sucursal, id_cuenta, id_mesa) VALUES (?, ?, ?)',
            [$sucursal, $id, $mesa]);
    }
}
