<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\DatosRestaurante as Datos;
use Dominio\Texto;
use Modelos\Dispositivos;
use Modelos\Usuarios;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Giro;
use Nucleo\Identidad;

/**
 * El personal, su usuario y sus equipos.
 *
 * Dos pasos: **primero la persona con su puesto, después su usuario**, que hereda los permisos del puesto. No hay otra
 * puerta para crear un usuario —la llave `usuario.id_personal` es obligatoria y
 * única—, así que no existe usuario sin personal.
 *
 * Las reglas que aquí se cuidan:
 *
 * - **La baja se bloquea** con personas activas a su cargo. Las fases del giro
 *   agregan aquí sus impedimentos (cuentas abiertas, turno de caja abierto).
 *   Al darse de baja pierde el acceso.
 * - **Nadie se da de baja, se bloquea el acceso ni se cambia el puesto a sí
 *   mismo**, y nadie restablece su propia contraseña: para eso está «Cambiar
 *   contraseña».
 * - **A un administrador sólo lo toca otro administrador.** Con la regla de
 *   arriba, eso basta para que **siempre quede uno con acceso**: quien le
 *   quita el acceso a un administrador es otro que lo conserva. No hace falta
 *   contar cuántos quedan.
 * - **La contraseña inicial es temporal y aleatoria**, se muestra una sola vez
 *   y obliga a cambiarla al entrar. La bitácora dice que se emitió, nunca cuál.
 * - **Un equipo sólo se autoriza a quien trabaja con la app** (`puesto.usa_app`).
 *
 * El alcance lo da la identidad: el administrador ve a todos; los demás, a la
 * gente de las sucursales que alcanzan. A un administrador sólo lo toca otro administrador.
 */
final class Personal
{
    public const ACTIVO   = 4;
    public const INACTIVO = 3;

    private const MODULO        = 'personal';
    private const ADMINISTRADOR = 'administrador';

    public function __construct(
        private BaseDatos $bd,
        private Bitacora $bitacora,
        private Identidad $identidad,
        private Usuarios $usuarios,
        private Dispositivos $dispositivos
    ) {
    }

    // =========================================================================
    // Lectura
    // =========================================================================

    /**
     * El personal del alcance, con su puesto, su sucursal y su acceso.
     *
     * @return list<array<string,mixed>>
     */
    public function personas(string $estatus = 'activas', ?int $idSucursal = null, ?int $idPuesto = null): array
    {
        $donde  = [];
        $params = [];

        if (($id = $this->estatusDe($estatus)) !== null) {
            $donde[]  = 'p.id_estatus = ?';
            $params[] = $id;
        }

        if ($idSucursal !== null && $idSucursal > 0) {
            $donde[]  = 'p.id_sucursal = ?';
            $params[] = $idSucursal;
        }

        if ($idPuesto !== null && $idPuesto > 0) {
            $donde[]  = 'p.id_puesto = ?';
            $params[] = $idPuesto;
        }

        if (!$this->identidad->esAdministrador()) {
            $alcance = $this->identidad->sucursales();
            if ($alcance === []) {
                return [];
            }
            $donde[] = 'p.id_sucursal IN (' . implode(',', array_fill(0, count($alcance), '?')) . ')';
            array_push($params, ...$alcance);
        }

        return $this->bd->filas(
            'SELECT p.id, p.nombre, p.apellido_paterno, p.apellido_materno, p.id_puesto, p.id_sucursal,
                    p.id_superior, p.telefono, p.correo, p.fecha_ingreso, p.fecha_baja, p.id_estatus,
                    pu.nombre AS puesto, pu.clave AS clave_puesto, b.nombre AS sucursal,
                    u.usuario, u.id_estatus AS estatus_usuario, u.cambiar_clave
             FROM personal p
             JOIN puesto pu     ON pu.id = p.id_puesto
             LEFT JOIN sucursal b ON b.id = p.id_sucursal
             LEFT JOIN usuario u ON u.id_personal = p.id'
            . ($donde === [] ? '' : ' WHERE ' . implode(' AND ', $donde))
            . ' ORDER BY p.id_estatus DESC, p.apellido_paterno, p.nombre, p.id DESC',
            $params
        );
    }

    /**
     * Una persona, con su usuario y su superior. 404 si no existe, 403 si no
     * es del alcance.
     *
     * @return array<string,mixed>
     */
    public function persona(int $id): array
    {
        $persona = $this->bd->fila(
            'SELECT p.*, pu.nombre AS puesto, pu.clave AS clave_puesto, pu.usa_app,
                    b.nombre AS sucursal, b.id_estatus AS estatus_sucursal,
                    TRIM(CONCAT(s.nombre, \' \', s.apellido_paterno)) AS superior,
                    u.id AS id_usuario, u.usuario, u.id_estatus AS estatus_usuario, u.cambiar_clave, u.ultimo_acceso,
                    u.totp_confirmado_en, (u.totp_secreto_cifrado IS NOT NULL) AS totp_iniciado
             FROM personal p
             JOIN puesto pu      ON pu.id = p.id_puesto
             LEFT JOIN sucursal b  ON b.id = p.id_sucursal
             LEFT JOIN personal s ON s.id = p.id_superior
             LEFT JOIN usuario u ON u.id_personal = p.id
             WHERE p.id = ?',
            [$id]
        );

        if ($persona === null) {
            throw Errores::noEncontrado('Esa persona no existe');
        }

        $this->exigeAlcance($persona);

        return $persona;
    }

    /**
     * Los teléfonos. `pendientes`, `autorizados` o `todos`; con `$idUsuario`,
     * los de esa persona.
     *
     * @return list<array<string,mixed>>
     */
    public function dispositivos(string $filtro = 'todos', ?int $idUsuario = null): array
    {
        $donde  = [];
        $params = [];

        if ($filtro === 'pendientes' || $filtro === 'autorizados') {
            $donde[]  = 'd.autorizado = ?';
            $params[] = $filtro === 'autorizados' ? 1 : 0;
        }

        if ($idUsuario !== null) {
            $donde[]  = 'd.id_usuario = ?';
            $params[] = $idUsuario;
        }

        if (!$this->identidad->esAdministrador()) {
            $alcance = $this->identidad->sucursales();
            if ($alcance === []) {
                return [];
            }
            $donde[] = 'p.id_sucursal IN (' . implode(',', array_fill(0, count($alcance), '?')) . ')';
            array_push($params, ...$alcance);
        }

        return $this->bd->filas(
            'SELECT d.id, d.id_usuario, d.identificador, d.nombre, d.plataforma, d.autorizado,
                    d.autorizado_en, d.ultimo_acceso,(d.token_push IS NOT NULL) AS push_listo,
                    u.usuario, u.id_estatus AS estatus_usuario, p.id AS id_personal,
                    TRIM(CONCAT(p.nombre, \' \', p.apellido_paterno)) AS persona,
                    pu.nombre AS puesto, pu.usa_app, b.nombre AS sucursal
             FROM dispositivo d
             JOIN usuario u     ON u.id = d.id_usuario
             JOIN personal p    ON p.id = u.id_personal
             JOIN puesto pu     ON pu.id = p.id_puesto
             LEFT JOIN sucursal b ON b.id = p.id_sucursal'
            . ($donde === [] ? '' : ' WHERE ' . implode(' AND ', $donde))
            . ' ORDER BY d.autorizado, d.ultimo_acceso DESC, d.id DESC',
            $params
        );
    }

    /**
     * Los puestos que quien captura puede dar. El de administrador, sólo otro
     * administrador.
     *
     * @return array<string,string>
     */
    public function opcionesPuesto(): array
    {
        $opciones = [];

        foreach ($this->bd->filas('SELECT id, clave, nombre FROM puesto WHERE id_estatus = 4 ORDER BY id') as $p) {
            if ($p['clave'] === self::ADMINISTRADOR && !$this->identidad->esAdministrador()) {
                continue;
            }
            $opciones[(string) $p['id']] = (string) $p['nombre'];
        }

        return $opciones;
    }

    /**
     * Quién puede ser superior: el personal activo del alcance.
     *
     * @return array<string,string>
     */
    public function opcionesSuperior(): array
    {
        $opciones = [];

        foreach ($this->personas('activas') as $p) {
            $opciones[(string) $p['id']] = trim($p['nombre'] . ' ' . $p['apellido_paterno']) . ' · ' . $p['puesto'];
        }

        return $opciones;
    }

    public function sugiereUsuario(array $persona): string
    {
        $base = self::sinAcentos(mb_substr((string) $persona['nombre'], 0, 1) . (string) $persona['apellido_paterno']);
        $base = substr($base !== '' ? $base : 'usuario', 0, 50);

        for ($n = 1; $n < 100; $n++) {
            $candidato = $n === 1 ? $base : $base . $n;
            if ($this->usuarios->porUsuario($candidato) === null) {
                return $candidato;
            }
        }

        return $base . random_int(100, 999);
    }

    // =========================================================================
    // Personal
    // =========================================================================

    /**
     * Da de alta a una persona o cambia sus datos. Devuelve su id.
     *
     * @param array<string,mixed> $datos
     */
    public function guardaPersona(?int $id, array $datos, string $ip): int
    {
        $limpio = $this->datosPersona($datos);

        return $this->bd->transaccion(function (BaseDatos $bd) use ($id, $limpio, $ip): int {
            $antes = null;

            if ($id !== null) {
                $antes = $this->bloquea($id);
                $this->exigeAlcance($antes);
            }

            $puesto = $this->puesto($limpio['id_puesto']);
            if ($puesto === null) {
                throw Errores::datosInvalidos(['id_puesto' => 'Ese puesto no existe']);
            }

            if ($puesto['clave'] === self::ADMINISTRADOR && !$this->identidad->esAdministrador()) {
                throw Errores::prohibido('Solo un administrador da el puesto de administrador');
            }

            // El administrador ve todas las sucursales: la suya es opcional. Los
            // demás trabajan en una, y su alcance sale de ahí.
            if ($limpio['id_sucursal'] === null && $puesto['clave'] !== self::ADMINISTRADOR) {
                throw Errores::datosInvalidos(['id_sucursal' => 'Cada persona trabaja en una sucursal: seleccione cuál']);
            }

            if ($limpio['id_sucursal'] !== null) {
                $sucursal = $bd->fila('SELECT id, id_estatus FROM sucursal WHERE id = ? FOR UPDATE', [$limpio['id_sucursal']]);

                if ($sucursal === null) {
                    throw Errores::datosInvalidos(['id_sucursal' => 'Esa sucursal no existe']);
                }

                $this->identidad->exigeSucursal($limpio['id_sucursal']);

                $cambiaSucursal = $antes === null || (int) ($antes['id_sucursal'] ?? 0) !== $limpio['id_sucursal'];
                if ($cambiaSucursal && (int) $sucursal['id_estatus'] !== self::ACTIVO) {
                    throw Errores::datosInvalidos(['id_sucursal' => 'Esa sucursal está dada de baja']);
                }
            }

            if ($antes !== null) {
                $this->revisaCambios($antes, $limpio, $puesto);
            }

            if ($limpio['id_superior'] !== null) {
                $this->exigeSuperiorValido($limpio['id_superior'], $id);
            }

            if ($id === null) {
                $id = $bd->inserta(
                    'INSERT INTO personal (nombre, apellido_paterno, apellido_materno, id_puesto, id_sucursal,
                                           id_superior, telefono, correo, fecha_ingreso, creado_por)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [...array_values($limpio), $this->identidad->id()]
                );
            } else {
                $bd->ejecuta(
                    'UPDATE personal SET nombre = ?, apellido_paterno = ?, apellido_materno = ?, id_puesto = ?,
                            id_sucursal = ?, id_superior = ?, telefono = ?, correo = ?, fecha_ingreso = ?
                     WHERE id = ?',
                    [...array_values($limpio), $id]
                );
            }

            $this->apunta(
                $antes === null ? 'crea_personal' : 'edita_personal',
                'personal',
                $id,
                $antes === null ? null : array_intersect_key($antes, $limpio),
                $limpio,
                $ip
            );

            return $id;
        });
    }

    public function cambiaEstatusPersona(int $id, bool $activa, string $ip): void
    {
        $this->bd->transaccion(function (BaseDatos $bd) use ($id, $activa, $ip): void {
            $persona = $this->bloquea($id);
            $this->exigeAlcance($persona);

            if ((int) $persona['id_estatus'] === ($activa ? self::ACTIVO : self::INACTIVO)) {
                return;
            }

            $usuario = $this->usuarios->porPersonal($id);

            if ($activa) {
                if ($persona['id_sucursal'] !== null) {
                    $sucursal = (int) $bd->valor('SELECT id_estatus FROM sucursal WHERE id = ?', [$persona['id_sucursal']]);
                    if ($sucursal !== self::ACTIVO) {
                        throw Errores::conflicto('Primero hay que reactivar su sucursal.');
                    }
                }

                $bd->ejecuta('UPDATE personal SET id_estatus = 4, fecha_baja = NULL WHERE id = ?', [$id]);
                // El acceso no vuelve solo: se reactiva aparte, con contraseña nueva.
                $this->apunta('reactiva_personal', 'personal', $id, ['id_estatus' => self::INACTIVO], ['id_estatus' => self::ACTIVO], $ip);

                return;
            }

            if ($id === $this->identidad->idPersonal()) {
                throw Errores::conflicto('No puede darse de baja a sí mismo.');
            }

            $impide = [];

            $aCargo = (int) $bd->valor('SELECT COUNT(*) FROM personal s WHERE s.id_superior = ? AND s.id_estatus = 4', [$id]);
            if ($aCargo > 0) {
                $impide[] = $aCargo === 1 ? 'una persona a su cargo' : $aCargo . ' personas a su cargo';
            }
            if ($usuario !== null && Giro::activo('restaurante')) {
                $operador = (int) $usuario['id'];
                if ($bd->valor('SELECT id FROM cuenta WHERE id_mesero = ? AND abierta = 1 LIMIT 1', [$operador]) !== null) {
                    $impide[] = 'cuentas abiertas';
                }
                if ($bd->valor('SELECT id FROM turno_caja WHERE id_cajero = ? AND abierto = 1 LIMIT 1', [$operador]) !== null) {
                    $impide[] = 'un turno de caja abierto';
                }
            }

            if ($impide !== []) {
                throw Errores::conflicto('No se puede dar de baja: tiene ' . self::enLista($impide) . '.');
            }

            $bd->ejecuta('UPDATE personal SET id_estatus = 3, fecha_baja = CURDATE() WHERE id = ?', [$id]);

            if ($usuario !== null && (int) $usuario['id_estatus'] === self::ACTIVO) {
                $this->usuarios->desactiva((int) $usuario['id']);
            }

            $this->apunta(
                'da_de_baja_personal',
                'personal',
                $id,
                ['id_estatus' => self::ACTIVO],
                ['id_estatus' => self::INACTIVO],
                $ip
            );
        });
    }

    public function sucursalesAsignadas(int $usuario): array
    {
        return array_map('intval', array_column($this->bd->filas(
            'SELECT id_sucursal FROM usuario_sucursal WHERE id_usuario = ? ORDER BY id_sucursal', [$usuario]
        ), 'id_sucursal'));
    }

    public function asignaSucursales(int $id, mixed $valor, string $ip): void
    {
        if (!is_array($valor) || !array_is_list($valor)) {
            throw Errores::datosInvalidos(['sucursales' => 'Seleccione sucursales válidas']);
        }
        $solicitadas = array_values(array_unique(array_map(
            static fn (mixed $sucursal): int => Datos::entero($sucursal, 'sucursales', 1, 65535), $valor
        )));
        sort($solicitadas);
        $this->bd->transaccion(function () use ($id, $solicitadas, $ip): void {
            $persona = $this->bloquea($id);
            $this->exigeAlcance($persona);
            if ($id === $this->identidad->idPersonal() || $persona['clave_puesto'] === self::ADMINISTRADOR
                || (int) $persona['id_estatus'] !== self::ACTIVO) {
                throw Errores::prohibido('Esta persona no admite cambios de sucursal');
            }
            $usuario = $this->usuarios->porPersonal($id) ?? throw Errores::noEncontrado('La persona no tiene usuario');
            $idUsuario = (int) $usuario['id'];
            $actuales = $this->sucursalesAsignadas($idUsuario);
            $principal = (int) $persona['id_sucursal'];
            $deseadas = array_values(array_diff($solicitadas, [$principal]));
            foreach ($deseadas as $sucursal) {
                $this->identidad->exigeSucursal($sucursal);
                if ($this->bd->valor('SELECT id FROM sucursal WHERE id = ? AND id_estatus = 4', [$sucursal]) === null) {
                    throw Errores::datosInvalidos(['sucursales' => 'Seleccione sucursales activas']);
                }
            }
            $retira = array_filter(array_diff($actuales, $deseadas), fn (int $s): bool => $this->identidad->alcanzaSucursal($s));
            $agrega = array_diff($deseadas, $actuales);
            if ($agrega === [] && $retira === []) {
                return;
            }
            foreach ($retira as $sucursal) {
                $this->bd->ejecuta('DELETE FROM usuario_sucursal WHERE id_usuario = ? AND id_sucursal = ?', [$idUsuario, $sucursal]);
            }
            foreach ($agrega as $sucursal) {
                $this->bd->ejecuta('INSERT INTO usuario_sucursal (id_usuario,id_sucursal,asignado_por) VALUES (?, ?, ?)',
                    [$idUsuario, $sucursal, $this->identidad->id()]);
            }
            $this->usuarios->revocaSesiones($idUsuario);
            if (Giro::activo('restaurante')) {
                $this->bd->ejecuta('DELETE FROM sesion_equipo WHERE id_usuario = ?', [$idUsuario]);
            }
            $this->apunta('asigna_sucursales', 'usuario', $idUsuario, ['sucursales' => $actuales],
                ['sucursales' => $this->sucursalesAsignadas($idUsuario)], $ip);
        });
    }

    // =========================================================================
    // Usuario
    // =========================================================================

    /**
     * Crea el usuario de una persona y devuelve su contraseña temporal, que se
     * muestra una vez y no se guarda en ningún lado.
     */
    public function creaUsuario(int $idPersonal, mixed $nombre, string $ip): string
    {
        $usuario = mb_strtolower(trim((string) $nombre));

        if (preg_match('/^[a-z0-9][a-z0-9._-]{2,59}$/', $usuario) !== 1) {
            throw Errores::datosInvalidos(['usuario' => 'De 3 a 60 letras sin acento o números']);
        }

        $clave = Usuarios::claveTemporal();

        $this->bd->transaccion(function (BaseDatos $bd) use ($idPersonal, $usuario, $clave, $ip): void {
            $persona = $this->bloquea($idPersonal);
            $this->exigeAlcance($persona);

            if ((int) $persona['id_estatus'] !== self::ACTIVO) {
                throw Errores::conflicto('La persona está dada de baja: primero hay que reactivarla.');
            }

            if ($this->usuarios->porPersonal($idPersonal) !== null) {
                throw Errores::conflicto('Esta persona ya tiene usuario.');
            }

            if ($this->usuarios->porUsuario($usuario) !== null) {
                throw Errores::datosInvalidos(['usuario' => 'Ese nombre de usuario ya existe']);
            }

            $id = $this->usuarios->crea($idPersonal, $usuario, $clave, temporal: true, creadoPor: $this->identidad->id());

            // La contraseña no entra a la bitácora: sólo que se emitió.
            $this->apunta('crea_usuario', 'usuario', $id, null, ['id_personal' => $idPersonal, 'usuario' => $usuario, 'clave' => 'temporal'], $ip);
        });

        return $clave;
    }

    /** Una contraseña temporal nueva; la anterior y sus tokens dejan de valer. */
    public function restableceClave(int $idPersonal, string $ip): string
    {
        $clave = Usuarios::claveTemporal();

        $this->bd->transaccion(function () use ($idPersonal, $clave, $ip): void {
            $usuario = $this->usuarioDe($idPersonal);

            if ((int) $usuario['id'] === $this->identidad->id()) {
                throw Errores::conflicto('Su propia contraseña se cambia desde «Cambiar contraseña».');
            }

            if ((int) $usuario['id_estatus'] !== self::ACTIVO) {
                throw Errores::conflicto('Acceso bloqueado. Al reactivarlo se crea otra contraseña.');
            }

            $this->usuarios->cambiaClave((int) $usuario['id'], $clave, temporal: true);
            $this->apunta('restablece_clave', 'usuario', (int) $usuario['id'], null, ['clave' => 'temporal'], $ip);
        });

        return $clave;
    }

    /**
     * Bloquea o reactiva el acceso. Al reactivar se emite una contraseña
     * temporal nueva —la que tenía la puede saber alguien más— y se devuelve.
     */
    public function cambiaEstatusUsuario(int $idPersonal, bool $activo, string $ip): ?string
    {
        $clave = $activo ? Usuarios::claveTemporal() : null;

        $this->bd->transaccion(function () use ($idPersonal, $activo, $clave, $ip): void {
            $usuario = $this->usuarioDe($idPersonal);

            if ((int) $usuario['id_estatus'] === ($activo ? self::ACTIVO : self::INACTIVO)) {
                throw Errores::conflicto($activo ? 'El acceso ya está activo.' : 'El acceso ya está bloqueado.');
            }

            if ($activo) {
                $persona = $this->bloquea($idPersonal);
                if ((int) $persona['id_estatus'] !== self::ACTIVO) {
                    throw Errores::conflicto('La persona está dada de baja: primero hay que reactivarla.');
                }

                $this->usuarios->cambiaClave((int) $usuario['id'], (string) $clave, temporal: true);
                $this->usuarios->activa((int) $usuario['id']);
                $this->apunta('reactiva_usuario', 'usuario', (int) $usuario['id'], ['id_estatus' => self::INACTIVO], ['id_estatus' => self::ACTIVO, 'clave' => 'temporal'], $ip);

                return;
            }

            if ((int) $usuario['id'] === $this->identidad->id()) {
                throw Errores::conflicto('No puede bloquear su propio acceso.');
            }

            $this->usuarios->desactiva((int) $usuario['id']);
            $this->apunta('bloquea_usuario', 'usuario', (int) $usuario['id'], ['id_estatus' => self::ACTIVO], ['id_estatus' => self::INACTIVO], $ip);
        });

        return $clave;
    }

    /**
     * Quien está en pantalla cambia su propia contraseña. Deja de ser temporal,
     * y los tokens de sus teléfonos se cortan: si la cambia porque alguien más
     * la supo, el teléfono de ese alguien tampoco sigue dentro.
     */
    public function cambiaClavePropia(mixed $actual, mixed $nueva, mixed $confirma, string $ip): void
    {
        $actual   = (string) $actual;
        $nueva    = (string) $nueva;
        $confirma = (string) $confirma;
        $usuario  = $this->usuarios->porUsuario((string) $this->identidad->usuario()['usuario']);

        if ($usuario === null) {
            throw Errores::noAutenticado();
        }

        $errores = [];

        if (!$this->usuarios->claveCorrecta($usuario, $actual)) {
            $errores['actual'] = 'No es su contraseña actual';
        }

        if (($queja = Usuarios::quejaDeClave($nueva, (string) $usuario['usuario'])) !== null) {
            $errores['nueva'] = $queja;
        } elseif (hash_equals($actual, $nueva)) {
            $errores['nueva'] = 'Tiene que ser distinta de la actual';
        }

        if (!isset($errores['nueva']) && !hash_equals($nueva, $confirma)) {
            $errores['confirma'] = 'No coincide con la nueva';
        }

        if ($errores !== []) {
            throw Errores::datosInvalidos($errores);
        }

        $this->bd->transaccion(function () use ($usuario, $nueva, $ip): void {
            $this->usuarios->cambiaClave((int) $usuario['id'], $nueva, temporal: false);
            $this->usuarios->revocaTokens((int) $usuario['id']);
            $this->apunta('cambia_clave', 'usuario', (int) $usuario['id'], null, ['clave' => 'propia'], $ip);
        });
    }

    // =========================================================================
    // Dispositivos
    // =========================================================================

    public function autorizaDispositivo(int $id, string $ip): void
    {
        $this->bd->transaccion(function () use ($id, $ip): void {
            $telefono = $this->dispositivoDelAlcance($id);

            if ((int) $telefono['autorizado'] === 1) {
                return;
            }

            if ((int) $telefono['usa_app'] !== 1) {
                throw Errores::conflicto('Su puesto no usa la app.');
            }

            if ((int) $telefono['estatus_usuario'] !== self::ACTIVO) {
                throw Errores::conflicto('Su acceso está bloqueado.');
            }

            $this->dispositivos->autoriza($id);
            $this->apunta('autoriza_dispositivo', 'dispositivo', $id, ['autorizado' => 0], ['autorizado' => 1], $ip);
        });
    }

    public function retiraDispositivo(int $id, string $ip): void
    {
        $this->bd->transaccion(function () use ($id, $ip): void {
            $telefono = $this->dispositivoDelAlcance($id);

            if ((int) $telefono['autorizado'] === 0) {
                return;
            }

            $this->dispositivos->retira($id);
            $this->apunta('retira_dispositivo', 'dispositivo', $id, ['autorizado' => 1], ['autorizado' => 0], $ip);
        });
    }

    // =========================================================================
    // Validación
    // =========================================================================

    /**
     * @param array<string,mixed> $datos
     * @return array{nombre:string,apellido_paterno:string,apellido_materno:?string,id_puesto:int,
     *               id_sucursal:?int,id_superior:?int,telefono:?string,correo:?string,fecha_ingreso:string}
     */
    private function datosPersona(array $datos): array
    {
        $errores = [];

        $nombre  = $this->texto($datos['nombre'] ?? '', 'nombre', 80, true, $errores);
        $paterno = $this->texto($datos['apellido_paterno'] ?? '', 'apellido_paterno', 60, true, $errores);
        $materno = $this->texto($datos['apellido_materno'] ?? '', 'apellido_materno', 60, false, $errores);

        $idPuesto = (int) ($datos['id_puesto'] ?? 0);
        if ($idPuesto <= 0) {
            $errores['id_puesto'] = 'Seleccione el puesto';
        }

        $idSucursal   = (int) ($datos['id_sucursal'] ?? 0);
        $idSuperior = (int) ($datos['id_superior'] ?? 0);

        $telefono = null;
        try {
            $telefono = Texto::telefono($datos['telefono'] ?? null);
        } catch (\InvalidArgumentException $e) {
            $errores['telefono'] = $e->getMessage();
        }

        $correo = Texto::opcional($datos['correo'] ?? null);
        if ($correo !== null) {
            $correo = mb_strtolower($correo);
            if (mb_strlen($correo) > 160 || filter_var($correo, FILTER_VALIDATE_EMAIL) === false) {
                $errores['correo'] = 'Capture un correo como nombre@dominio.com';
            }
        }

        $ingreso = trim((string) ($datos['fecha_ingreso'] ?? ''));
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $ingreso, $p) !== 1 || !checkdate((int) $p[2], (int) $p[3], (int) $p[1])) {
            $errores['fecha_ingreso'] = 'Capture la fecha como 2026-09-28';
        }

        if ($errores !== []) {
            throw Errores::datosInvalidos($errores);
        }

        return [
            'nombre'           => $nombre,
            'apellido_paterno' => $paterno,
            'apellido_materno' => $materno,
            'id_puesto'        => $idPuesto,
            'id_sucursal'        => $idSucursal > 0 ? $idSucursal : null,
            'id_superior'      => $idSuperior > 0 ? $idSuperior : null,
            'telefono'         => $telefono,
            'correo'           => $correo,
            'fecha_ingreso'    => $ingreso,
        ];
    }

    /** @param array<string,string> $errores */
    private function texto(mixed $valor, string $campo, int $tope, bool $obligatorio, array &$errores): ?string
    {
        $texto = Texto::limpio((string) $valor);

        if ($texto === '') {
            if ($obligatorio) {
                $errores[$campo] = 'Es obligatorio';
            }

            return $obligatorio ? '' : null;
        }

        if (mb_strlen($texto) > $tope) {
            $errores[$campo] = 'Hasta ' . $tope . ' caracteres';
        }

        return $texto;
    }

    /**
     * Lo que no puede cambiar en la edición de alguien que ya existe.
     *
     * @param array<string,mixed> $antes
     * @param array<string,mixed> $limpio
     * @param array<string,mixed> $puesto
     */
    private function revisaCambios(array $antes, array $limpio, array $puesto): void
    {
        $cambiaPuesto = (int) $antes['id_puesto'] !== $limpio['id_puesto'];
        $cambiaSucursal = (int) ($antes['id_sucursal'] ?? 0) !== (int) ($limpio['id_sucursal'] ?? 0);

        if (!$cambiaPuesto && !$cambiaSucursal) {
            return;
        }

        if ($cambiaPuesto && (int) $antes['id'] === $this->identidad->idPersonal()) {
            throw Errores::datosInvalidos(['id_puesto' => 'No puede cambiar su propio puesto']);
        }
    }

    /** El superior existe, está activo, es del alcance y no cierra un círculo. */
    private function exigeSuperiorValido(int $idSuperior, ?int $id): void
    {
        if ($idSuperior === $id) {
            throw Errores::datosInvalidos(['id_superior' => 'Nadie es su propio superior']);
        }

        $superior = $this->bd->fila('SELECT id, id_sucursal, id_superior, id_estatus FROM personal WHERE id = ?', [$idSuperior]);

        if ($superior === null || (int) $superior['id_estatus'] !== self::ACTIVO) {
            throw Errores::datosInvalidos(['id_superior' => 'Seleccione a una persona activa']);
        }

        $this->exigeAlcance($superior);

        // Subiendo por los superiores del elegido no se puede llegar a esta
        // persona: sería jefe de su jefe. El tope evita un ciclo viejo.
        $paso = $superior['id_superior'] === null ? null : (int) $superior['id_superior'];
        for ($i = 0; $paso !== null && $i < 50; $i++) {
            if ($paso === $id) {
                throw Errores::datosInvalidos(['id_superior' => 'Esa persona ya está a su cargo']);
            }
            $siguiente = $this->bd->valor('SELECT id_superior FROM personal WHERE id = ?', [$paso]);
            $paso = $siguiente === null ? null : (int) $siguiente;
        }
    }

    // =========================================================================
    // Piezas
    // =========================================================================

    /** @return array<string,mixed> */
    private function bloquea(int $id): array
    {
        $persona = $this->bd->fila(
            'SELECT p.*, pu.clave AS clave_puesto FROM personal p JOIN puesto pu ON pu.id = p.id_puesto WHERE p.id = ? FOR UPDATE',
            [$id]
        );

        if ($persona === null) {
            throw Errores::noEncontrado('Esa persona no existe');
        }

        return $persona;
    }

    /** @return array<string,mixed>|null */
    private function puesto(int $id): ?array
    {
        return $this->bd->fila('SELECT id, clave, nombre, usa_app FROM puesto WHERE id = ? AND id_estatus = 4', [$id]);
    }

    /** @return array<string,mixed> El usuario de una persona del alcance; 409 si no tiene. */
    private function usuarioDe(int $idPersonal): array
    {
        $persona = $this->bloquea($idPersonal);
        $this->exigeAlcance($persona);

        $usuario = $this->usuarios->porPersonal($idPersonal);
        if ($usuario === null) {
            throw Errores::conflicto('Esta persona aún no tiene usuario.');
        }

        return $usuario;
    }

    /** @return array<string,mixed> */
    private function dispositivoDelAlcance(int $id): array
    {
        $telefono = $this->bd->fila(
            'SELECT d.id, d.autorizado, u.id_estatus AS estatus_usuario, p.id_sucursal, pu.clave AS clave_puesto, pu.usa_app
             FROM dispositivo d
             JOIN usuario u  ON u.id = d.id_usuario
             JOIN personal p ON p.id = u.id_personal
             JOIN puesto pu  ON pu.id = p.id_puesto
             WHERE d.id = ? FOR UPDATE',
            [$id]
        );

        if ($telefono === null) {
            throw Errores::noEncontrado('Ese equipo no existe');
        }

        $this->exigeAlcance($telefono);

        return $telefono;
    }

    /**
     * Que la persona sea del alcance. Sin sucursal es un administrador, y a un
     * administrador sólo lo toca otro.
     *
     * @param array<string,mixed> $persona
     */
    private function exigeAlcance(array $persona): void
    {
        if ($persona['id_sucursal'] === null || ($persona['clave_puesto'] ?? '') === self::ADMINISTRADOR) {
            if (!$this->identidad->esAdministrador()) {
                throw Errores::prohibido('Esa persona no es de su alcance');
            }

            return;
        }

        $this->identidad->exigeSucursal((int) $persona['id_sucursal']);
    }

    private function estatusDe(string $estatus): ?int
    {
        return match ($estatus) {
            'inactivas' => self::INACTIVO,
            'todas'     => null,
            default     => self::ACTIVO,
        };
    }

    /**
     * @param array<string,mixed>|null $antes
     * @param array<string,mixed>|null $despues
     */
    private function apunta(string $accion, string $entidad, int $id, ?array $antes, ?array $despues, string $ip): void
    {
        $this->bitacora->registra(self::MODULO, $accion, $entidad, $id, $antes, $despues, $this->identidad->id(), $ip);
    }

    /** @param list<string> $partes */
    private static function enLista(array $partes): string
    {
        if (count($partes) === 1) {
            return $partes[0];
        }

        $ultima = array_pop($partes);

        return implode(', ', $partes) . ' y ' . $ultima;
    }

    private static function sinAcentos(string $texto): string
    {
        $texto = strtr(mb_strtolower($texto), [
            'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n',
            'à' => 'a', 'è' => 'e', 'ì' => 'i', 'ò' => 'o', 'ù' => 'u',
        ]);

        return (string) preg_replace('/[^a-z0-9]/', '', $texto);
    }
}
