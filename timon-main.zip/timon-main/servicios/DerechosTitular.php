<?php
declare(strict_types=1);

namespace Servicios;

use Modelos\Parametros;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;

/**
 * Lo que una persona puede pedir sobre sus datos: verlos, corregirlos o que se borren.
 *
 * Cancelar no borra renglones: anonimiza. Una venta sigue siendo una venta, y
 * los reportes deben cuadrar aunque ya no se sepa de quién era el nombre.
 * Tampoco toca la bitácora ya escrita, porque está sellada y es la evidencia de
 * integridad.
 *
 * Hoy los datos que se exportan y anonimizan son los del personal. Los de
 * clientes (domicilio y reservaciones) se agregan con la fase que los capture;
 * mientras tanto su solicitud se registra y se atiende a mano.
 */
final class DerechosTitular
{
    public const TIPOS = [
        'acceso' => 'Acceso',
        'rectificacion' => 'Rectificación',
        'cancelacion' => 'Cancelación',
        'oposicion' => 'Oposición',
    ];
    public const TITULARES = ['cliente' => 'Cliente', 'empleado' => 'Empleado', 'otro' => 'Otra persona'];

    private const INACTIVO = 3;
    private const ACTIVO = 4;

    public function __construct(
        private BaseDatos $bd,
        private Bitacora $bitacora,
        private Parametros $parametros
    ) {
    }

    /** @return list<array<string,mixed>> */
    public function solicitudes(): array
    {
        return $this->bd->filas(
            "SELECT s.*, u.usuario AS registrada_por_usuario, a.usuario AS atendida_por_usuario
             FROM solicitud_arco s
             JOIN usuario u ON u.id = s.registrada_por
             LEFT JOIN usuario a ON a.id = s.atendida_por
             ORDER BY s.estado = 'abierta' DESC, s.vence_en, s.id DESC
             LIMIT 200"
        );
    }

    /** @param array<string,mixed> $d */
    public function registra(array $d, int $idUsuario, string $ip): int
    {
        $tipo = (string) ($d['tipo'] ?? '');
        $titular = (string) ($d['titular_tipo'] ?? '');
        $solicitante = trim((string) ($d['solicitante'] ?? ''));
        $contacto = trim((string) ($d['contacto'] ?? ''));
        $detalle = trim((string) ($d['detalle'] ?? ''));
        $recibida = trim((string) ($d['recibida_en'] ?? ''));
        $idTitular = (int) ($d['id_titular'] ?? 0);

        $errores = [];
        if (!isset(self::TIPOS[$tipo])) $errores['tipo'] = 'Seleccione el derecho que se pide';
        if (!isset(self::TITULARES[$titular])) $errores['titular_tipo'] = 'Seleccione de quién son los datos';
        if ($solicitante === '' || mb_strlen($solicitante) > 160) $errores['solicitante'] = 'Capture quién lo pide';
        if (mb_strlen($contacto) > 160) $errores['contacto'] = 'Use hasta 160 caracteres';
        if ($detalle === '' || mb_strlen($detalle) > 500) $errores['detalle'] = 'Capture qué se pide, en menos de 500 caracteres';
        $fecha = \DateTimeImmutable::createFromFormat('!Y-m-d', $recibida);
        if ($fecha === false || $fecha->format('Y-m-d') !== $recibida || $recibida > date('Y-m-d')) {
            $errores['recibida_en'] = 'Capture cuándo se recibió';
        }
        if ($errores === [] && $titular === 'empleado' && !$this->existeTitular($titular, $idTitular)) {
            $errores['id_titular'] = 'No existe ese número de ' . mb_strtolower(self::TITULARES[$titular]);
        }
        if ($errores !== []) throw Errores::datosInvalidos($errores);

        $dias = max(1, $this->parametros->entero('dias_respuesta_arco', 20));
        $vence = date('Y-m-d', strtotime($recibida . ' +' . $dias . ' day'));

        return $this->bd->transaccion(function () use ($tipo, $titular, $idTitular, $solicitante, $contacto, $detalle, $recibida, $vence, $idUsuario, $ip): int {
            $id = $this->bd->inserta(
                'INSERT INTO solicitud_arco (tipo, titular_tipo, id_titular, solicitante, contacto, detalle, recibida_en, vence_en, registrada_por)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [$tipo, $titular, $titular === 'empleado' ? $idTitular : null, $solicitante, $contacto === '' ? null : $contacto, $detalle, $recibida, $vence, $idUsuario]
            );
            // Sin nombre ni contacto: la bitácora no se purga y ya están en la solicitud.
            $this->bitacora->registra('privacidad', 'registra_solicitud', 'solicitud_arco', $id, despues: ['tipo' => $tipo, 'titular_tipo' => $titular, 'vence_en' => $vence], idUsuario: $idUsuario, ip: $ip);

            return $id;
        });
    }

    public function cierra(int $id, string $estado, string $resolucion, int $idUsuario, string $ip): void
    {
        $resolucion = trim($resolucion);
        if (!in_array($estado, ['atendida', 'rechazada'], true)) {
            throw Errores::datosInvalidos(['estado' => 'Seleccione cómo se cierra']);
        }
        if (mb_strlen($resolucion) < 10 || mb_strlen($resolucion) > 500) {
            throw Errores::datosInvalidos(['resolucion' => 'Capture qué se contestó, entre 10 y 500 caracteres']);
        }

        $this->bd->transaccion(function (BaseDatos $bd) use ($id, $estado, $resolucion, $idUsuario, $ip): void {
            $fila = $bd->fila('SELECT estado FROM solicitud_arco WHERE id = ? FOR UPDATE', [$id]);
            if ($fila === null) throw Errores::noEncontrado('Esa solicitud no existe');
            if ($fila['estado'] !== 'abierta') throw Errores::conflicto('Esa solicitud ya está cerrada');
            $bd->ejecuta(
                'UPDATE solicitud_arco SET estado = ?, resolucion = ?, atendida_por = ?, atendida_en = NOW() WHERE id = ?',
                [$estado, $resolucion, $idUsuario, $id]
            );
            $this->bitacora->registra('privacidad', 'cierra_solicitud', 'solicitud_arco', $id, despues: ['estado' => $estado], idUsuario: $idUsuario, ip: $ip);
        });
    }

    /**
     * Los datos de un titular, para entregárselos. No incluye contraseñas, tokens
     * ni secretos, y de las selfies dice cuántas hay: se entregan aparte si las pide.
     *
     * @return array<string,mixed>
     */
    public function exporta(string $tipo, int $id, int $idUsuario, string $ip): array
    {
        if (!$this->existeTitular($tipo, $id)) throw Errores::noEncontrado('Ese titular no existe');
        $datos = $this->datosDeEmpleado($id);
        $this->bitacora->registra('lectura', 'exporta_titular', 'personal', $id, idUsuario: $idUsuario, ip: $ip);

        return ['generado_en' => date('Y-m-d H:i:s'), 'tipo' => $tipo] + $datos;
    }

    /** Sólo a quien ya está dado de baja. Lo llama también el mantenimiento diario. */
    public function anonimizaEmpleado(int $id, ?int $idUsuario, ?string $ip): void
    {
        $this->bd->transaccion(function (BaseDatos $bd) use ($id, $idUsuario, $ip): void {
            $persona = $bd->fila('SELECT id, id_estatus, anonimizado_en FROM personal WHERE id = ? FOR UPDATE', [$id]);
            if ($persona === null) throw Errores::noEncontrado('Esa persona no existe');
            if ($persona['anonimizado_en'] !== null) throw Errores::conflicto('Esa persona ya está anonimizada');
            if ((int) $persona['id_estatus'] === self::ACTIVO) throw Errores::conflicto('Primero dé de baja a esta persona en Personal');

            $bd->ejecuta(
                "UPDATE personal SET nombre = 'Ex empleado', apellido_paterno = ?, apellido_materno = NULL, telefono = NULL,
                        correo = NULL, anonimizado_en = NOW() WHERE id = ?",
                [(string) $id, $id]
            );

            $idUsuarioTitular = $bd->valor('SELECT id FROM usuario WHERE id_personal = ?', [$id]);
            if ($idUsuarioTitular !== null) {
                $idTitular = (int) $idUsuarioTitular;
                $bd->ejecuta(
                    'UPDATE usuario SET usuario = ?, clave_hash = ?, totp_secreto_cifrado = NULL, totp_confirmado_en = NULL,
                            acceso_motivo = NULL, id_estatus = ?, sesion_version = sesion_version + 1 WHERE id = ?',
                    ['anonimo.' . $id, password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT), self::INACTIVO, $idTitular]
                );
                $bd->ejecuta('UPDATE token_acceso SET revocado_en = NOW() WHERE id_usuario = ? AND revocado_en IS NULL', [$idTitular]);
                $bd->ejecuta(
                    "UPDATE dispositivo SET identificador = CONCAT('anonimo-', id), nombre = NULL, token_push = NULL, autorizado = 0 WHERE id_usuario = ?",
                    [$idTitular]
                );
            }
            $this->bitacora->registra('privacidad', 'anonimiza_empleado', 'personal', $id, idUsuario: $idUsuario, ip: $ip);
        });
    }

    private function existeTitular(string $tipo, int $id): bool
    {
        if ($id < 1) return false;

        return match ($tipo) {
            'empleado' => $this->bd->valor('SELECT 1 FROM personal WHERE id = ?', [$id]) !== null,
            default => false,
        };
    }

    /** @return array<string,mixed> */
    private function datosDeEmpleado(int $id): array
    {
        $idUsuario = $this->bd->valor('SELECT id FROM usuario WHERE id_personal = ?', [$id]);
        $datos = [
            'persona' => $this->bd->fila(
                'SELECT p.id, p.nombre, p.apellido_paterno, p.apellido_materno, p.telefono, p.correo, pu.nombre AS puesto,
                        b.nombre AS sucursal, p.fecha_ingreso, p.fecha_baja, p.anonimizado_en
                 FROM personal p JOIN puesto pu ON pu.id = p.id_puesto LEFT JOIN sucursal b ON b.id = p.id_sucursal WHERE p.id = ?',
                [$id]
            ),
        ];
        if ($idUsuario === null) return $datos;

        $idUsuario = (int) $idUsuario;

        return $datos + [
            'cuenta' => $this->bd->fila('SELECT usuario, creado_en, id_estatus FROM usuario WHERE id = ?', [$idUsuario]),
            'equipos' => $this->bd->filas('SELECT nombre, plataforma, autorizado_en, ultimo_acceso FROM dispositivo WHERE id_usuario = ?', [$idUsuario]),
        ];
    }
}
