<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;

final class OperacionRestaurante
{
    public function __construct(
        private BaseDatos $bd,
        private Bitacora $bitacora,
        private Identidad $identidad,
        private Instalaciones $instalaciones
    ) {
    }

    public function consultaSucursal(int $sucursal): void
    {
        $this->identidad->exigeSucursal($sucursal);
        if ($this->bd->valor('SELECT id FROM sucursal WHERE id = ? AND id_estatus = 4', [$sucursal]) === null) {
            throw Errores::noEncontrado('Sucursal no disponible');
        }
    }

    /**
     * El candado de la **operación** de la sucursal. Además falla si esa
     * operación no se escribe en este servidor (sucursal con servidor local).
     */
    public function bloqueaSucursal(int $sucursal): void
    {
        $this->instalaciones->exigeOperaAqui($sucursal);
        $this->identidad->exigeSucursal($sucursal);
        // Conserva el orden de confirmación de los eventos de la sucursal.
        // Primero se toma este renglón y después cualquier cuenta o mesa.
        if ($this->bd->valor('SELECT id FROM sucursal WHERE id = ? AND id_estatus = 4 FOR UPDATE', [$sucursal]) === null) {
            throw Errores::noEncontrado('Sucursal no disponible');
        }
    }

    /**
     * El mismo candado para el **catálogo** de la sucursal (plano, precios,
     * impresoras, datos públicos): se cambia en el central aunque la sucursal
     * opere con su servidor local, y nunca en el servidor de sucursal.
     */
    public function bloqueaCatalogo(int $sucursal): void
    {
        $this->instalaciones->exigeCatalogoAqui();
        $this->identidad->exigeSucursal($sucursal);
        if ($this->bd->valor('SELECT id FROM sucursal WHERE id = ? AND id_estatus = 4 FOR UPDATE', [$sucursal]) === null) {
            throw Errores::noEncontrado('Sucursal no disponible');
        }
    }

    /** Falla si la operación de la sucursal no se escribe en este servidor. */
    public function exigeOperaAqui(int $sucursal): void
    {
        $this->instalaciones->exigeOperaAqui($sucursal);
    }

    /** La sucursal escribe su operación en su servidor local (visto desde el central). */
    public function operaEnSuServidor(int $sucursal): bool
    {
        return $this->bd->valor('SELECT 1 FROM sucursal WHERE id = ? AND servidor = ?', [$sucursal, 'local']) !== null;
    }

    /**
     * Deja el evento que leen los equipos y el apunte de bitácora.
     *
     * `$cuenta` dice de qué cuenta es el cambio, cuando lo es de alguna: con
     * eso cada equipo recarga sólo esa cuenta.
     */
    public function registra(int $sucursal, string $tipo, int $entidad, array $cambios = [], ?int $cuenta = null): void
    {
        $this->bd->ejecuta(
            'INSERT INTO evento_sucursal (id_sucursal, tipo, entidad, id_cuenta) VALUES (?, ?, ?, ?)',
            [$sucursal, $tipo, $entidad, $cuenta]
        );
        $this->bitacora->registra(
            'restaurante', $tipo, $tipo, $entidad,
            despues: ['sucursal' => $sucursal] + $cambios,
            idUsuario: $this->identidad->id()
        );
    }

    public function unaVez(int $sucursal, string $llave, string $tipo, array $datos, callable $guarda): array
    {
        $this->consultaSucursal($sucursal);
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iD', $llave)) {
            throw Errores::datosInvalidos(['idempotencia' => 'Se requiere una llave UUID']);
        }

        $llave = strtolower($llave);
        $usuario = $this->identidad->id();
        $huella = hash('sha256', json_encode([$sucursal, $tipo, self::ordena($datos)], JSON_THROW_ON_ERROR));
        $busca = function () use ($llave, $usuario, $huella): ?array {
            $fila = $this->bd->fila(
                'SELECT id_usuario, huella, respuesta FROM operacion_sincronizada WHERE llave_idempotencia = ?',
                [$llave]
            );
            if ($fila === null) {
                return null;
            }
            if ((int) $fila['id_usuario'] !== $usuario || !hash_equals($huella, (string) $fila['huella'])) {
                throw Errores::conflicto('Esa llave ya corresponde a otra operación');
            }
            return json_decode((string) $fila['respuesta'], true, flags: JSON_THROW_ON_ERROR);
        };

        return $this->bd->guardaUnaSolaVez($busca, function () use ($sucursal, $llave, $tipo, $usuario, $huella, $guarda): array {
            $this->bloqueaSucursal($sucursal);
            $this->bd->ejecuta(
                'INSERT INTO operacion_sincronizada (llave_idempotencia, id_usuario, tipo, huella) VALUES (?, ?, ?, ?)',
                [$llave, $usuario, $tipo, $huella]
            );
            $respuesta = $guarda();
            $this->bd->ejecuta(
                'UPDATE operacion_sincronizada SET id_resultado = ?, respuesta = ? WHERE llave_idempotencia = ?',
                [$respuesta['id'], json_encode($respuesta, JSON_THROW_ON_ERROR), $llave]
            );
            return $respuesta;
        });
    }

    private static function ordena(array $datos): array
    {
        if (!array_is_list($datos)) {
            ksort($datos);
        }
        foreach ($datos as &$valor) {
            if (is_array($valor)) {
                $valor = self::ordena($valor);
            }
        }
        return $datos;
    }
}
