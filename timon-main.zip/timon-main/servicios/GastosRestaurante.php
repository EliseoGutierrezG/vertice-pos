<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\DatosRestaurante as Datos;
use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;

final class GastosRestaurante
{
    public function __construct(
        private BaseDatos $bd,
        private Identidad $identidad,
        private OperacionRestaurante $operacion,
        private CajaRestaurante $caja
    ) {
    }

    public function proveedores(int $sucursal): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->filas('SELECT id,nombre FROM proveedor WHERE id_sucursal = ? AND activo = 1 ORDER BY nombre, id', [$sucursal]);
    }

    public function registra(int $sucursal, array $datos): void
    {
        [$concepto, $importe, $comprobante, $proveedor, $caja] = $this->captura($datos);
        $this->bd->transaccion(function () use ($sucursal, $concepto, $importe, $comprobante, $proveedor, $caja): void {
            $this->operacion->bloqueaSucursal($sucursal);
            $this->validaCaja($caja);
            $this->validaProveedor($sucursal, $proveedor);
            $asiento = $caja ? $this->caja->asienta($sucursal, $concepto, $importe->negado()->aPesos()) : null;
            $id = $this->bd->inserta(
                'INSERT INTO gasto_sucursal (id_sucursal,id_proveedor,id_usuario,id_asiento,concepto,importe,comprobante)
                 VALUES (?, ?, ?, ?, ?, ?, ?)',
                [$sucursal, $proveedor, $this->identidad->id(), $asiento, $concepto, $importe->aPesos(), $comprobante]
            );
            $this->operacion->registra($sucursal, 'gasto_registrado', $id, ['importe' => $importe->aPesos(), 'asiento' => $asiento]);
        });
    }

    public function detalle(int $sucursal, int $id): array
    {
        $this->operacion->consultaSucursal($sucursal);
        $gasto = $this->gasto($sucursal, $id, false);
        $gasto['caja'] = $gasto['id_asiento'] === null ? 0 : 1;
        $gasto['proveedor'] = $gasto['id_proveedor'] === null ? null
            : $this->bd->valor('SELECT nombre FROM proveedor WHERE id_sucursal = ? AND id = ?', [$sucursal, $gasto['id_proveedor']]);
        return $gasto;
    }

    public function corrige(int $sucursal, int $id, int $version, array $datos): void
    {
        [$concepto, $importe, $comprobante, $proveedor, $caja] = $this->captura($datos);
        $this->bd->transaccion(function () use ($sucursal, $id, $version, $concepto, $importe, $comprobante, $proveedor, $caja): void {
            $this->operacion->bloqueaSucursal($sucursal);
            $anterior = $this->gasto($sucursal, $id, true);
            $this->exigeVigente($anterior, $version);
            if ($proveedor !== $anterior['id_proveedor']) {
                $this->validaProveedor($sucursal, $proveedor);
            }
            $teniaAsiento = $anterior['id_asiento'] !== null;
            $asiento = $anterior['id_asiento'];
            $nuevoImporte = $importe->aPesos();
            $reversion = null;
            if ($teniaAsiento !== $caja || ($caja && $nuevoImporte !== $anterior['importe'])) {
                $this->validaCaja(true);
                $reversion = $teniaAsiento ? $this->caja->asienta($sucursal, 'Reverso de gasto #' . $id, $anterior['importe']) : null;
                $asiento = $caja ? $this->caja->asienta($sucursal, $concepto, $importe->negado()->aPesos()) : null;
            }
            $this->bd->ejecuta(
                'UPDATE gasto_sucursal SET concepto = ?, importe = ?, comprobante = ?, id_proveedor = ?, id_asiento = ?,
                    version = version + 1 WHERE id = ?',
                [$concepto, $nuevoImporte, $comprobante, $proveedor, $asiento, $id]
            );
            $this->operacion->registra($sucursal, 'gasto_corregido', $id,
                ['antes' => $anterior, 'importe' => $nuevoImporte, 'asiento' => $asiento, 'reverso' => $reversion]);
        });
    }

    public function cancela(int $sucursal, int $id, int $version, mixed $valor): void
    {
        $motivo = Datos::texto($valor, 'motivo', 160);
        $this->bd->transaccion(function () use ($sucursal, $id, $version, $motivo): void {
            $this->operacion->bloqueaSucursal($sucursal);
            $gasto = $this->gasto($sucursal, $id, true);
            $this->exigeVigente($gasto, $version);
            $this->validaCaja($gasto['id_asiento'] !== null);
            $reversion = $gasto['id_asiento'] === null ? null : $this->caja->asienta($sucursal, 'Reverso de gasto #' . $id, $gasto['importe']);
            $this->bd->ejecuta('UPDATE gasto_sucursal SET cancelado_en = NOW(), motivo_cancelacion = ?, version = version + 1 WHERE id = ?',
                [$motivo, $id]);
            $this->operacion->registra($sucursal, 'gasto_cancelado', $id, ['motivo' => $motivo, 'reverso' => $reversion]);
        });
    }

    private function gasto(int $sucursal, int $id, bool $bloquea): array
    {
        return $this->bd->fila(
            'SELECT id,version,concepto,importe,comprobante,id_proveedor,id_asiento,creado_en,cancelado_en,motivo_cancelacion
             FROM gasto_sucursal WHERE id_sucursal = ? AND id = ?' . ($bloquea ? ' FOR UPDATE' : ''),
            [$sucursal, $id]
        ) ?? throw Errores::noEncontrado('Gasto no disponible');
    }

    private function exigeVigente(array $gasto, int $version): void
    {
        if ($gasto['cancelado_en'] !== null || (int) $gasto['version'] !== $version) {
            throw Errores::conflicto('El gasto cambió. Vuelva a abrirlo');
        }
    }

    private function captura(array $datos): array
    {
        $concepto = Datos::texto($datos['concepto'] ?? '', 'concepto', 120);
        $importe = Datos::precio($datos['importe'] ?? '', 'importe');
        if ($importe->esCero()) {
            throw Errores::datosInvalidos(['importe' => 'Capture un importe mayor que cero']);
        }
        $comprobante = Datos::texto($datos['comprobante'] ?? '', 'comprobante', 200, false);
        $proveedor = ($datos['id_proveedor'] ?? '') === '' ? null : Datos::entero($datos['id_proveedor'], 'id_proveedor');
        $caja = Datos::entero($datos['caja'] ?? '0', 'caja', 0, 1) === 1;
        return [$concepto, $importe, $comprobante, $proveedor, $caja];
    }

    private function validaCaja(bool $efectivo): void
    {
        if ($efectivo && !$this->identidad->puede('comanda_cobra')) {
            throw Errores::prohibido('Su puesto no puede ajustar caja');
        }
    }

    private function validaProveedor(int $sucursal, ?int $proveedor): void
    {
        if ($proveedor !== null
            && $this->bd->valor('SELECT id FROM proveedor WHERE id_sucursal = ? AND id = ? AND activo = 1', [$sucursal, $proveedor]) === null) {
            throw Errores::noEncontrado('Proveedor no disponible');
        }
    }
}
