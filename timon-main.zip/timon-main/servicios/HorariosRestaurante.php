<?php
declare(strict_types=1);

namespace Servicios;

use DateTimeImmutable;
use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;

final class HorariosRestaurante
{
    public const DIAS = [1 => 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

    public function __construct(private BaseDatos $bd)
    {
    }

    public function de(int $sucursal): array
    {
        return $this->bd->filas(
            'SELECT dia, TIME_FORMAT(abre, \'%H:%i\') AS abre, TIME_FORMAT(cierra, \'%H:%i\') AS cierra
             FROM sucursal_horario WHERE id_sucursal = ? ORDER BY dia',
            [$sucursal]
        );
    }

    /** Se guarda con los datos públicos, bajo el mismo candado de sucursal. */
    public function guarda(int $sucursal, array $abre, array $cierra): void
    {
        $horarios = [];
        foreach (self::DIAS as $dia => $nombre) {
            $inicio = $abre[$dia] ?? '';
            $fin = $cierra[$dia] ?? '';
            if ($inicio === '' && $fin === '') {
                continue;
            }
            if (!is_string($inicio) || !is_string($fin) || $inicio === $fin
                || !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/D', $inicio)
                || !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/D', $fin)) {
                throw Errores::datosInvalidos(['abre[' . $dia . ']' => 'Capture dos horas distintas']);
            }
            $horarios[] = [$dia, $inicio, $fin];
        }

        $this->bd->ejecuta('DELETE FROM sucursal_horario WHERE id_sucursal = ?', [$sucursal]);
        foreach ($horarios as [$dia, $inicio, $fin]) {
            $this->bd->ejecuta('INSERT INTO sucursal_horario (id_sucursal,dia,abre,cierra) VALUES (?, ?, ?, ?)',
                [$sucursal, $dia, $inicio, $fin]);
        }
    }

    /** Devuelve el cierre del turno que contiene la hora, incluso si empezó ayer. */
    public static function cierre(array $horarios, DateTimeImmutable $momento): ?DateTimeImmutable
    {
        $dias = array_column($horarios, null, 'dia');
        foreach ([$momento, $momento->modify('-1 day')] as $fecha) {
            $turno = $dias[(int) $fecha->format('N')] ?? null;
            if ($turno === null) {
                continue;
            }
            $inicio = new DateTimeImmutable($fecha->format('Y-m-d') . ' ' . $turno['abre'], $momento->getTimezone());
            $fin = new DateTimeImmutable($fecha->format('Y-m-d') . ' ' . $turno['cierra'], $momento->getTimezone());
            if ($fin <= $inicio) {
                $fin = $fin->modify('+1 day');
            }
            if ($momento >= $inicio && $momento < $fin) {
                return $fin;
            }
        }
        return null;
    }
}
