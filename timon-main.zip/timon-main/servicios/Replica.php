<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;

/**
 * La réplica entre el central y los servidores de sucursal.
 *
 * - **Bajada** (central → sucursal): el catálogo que se edita en el central
 *   (menú, precios, promociones, personal, plano, impresoras, parámetros) y
 *   las reservaciones nuevas del sitio público. Se manda completo, con una
 *   huella para no mandarlo si no cambió.
 * - **Subida** (sucursal → central): la operación, que en una sucursal
 *   `local` solo se escribe en su servidor. La anotan disparadores en
 *   `cambio_replica` (`guiones/disparadores-replica.php`) y se manda la foto
 *   actual de cada fila.
 * - **Arranque**: una sola vez, al instalar el servidor, baja lo que la
 *   sucursal ya tenía de operación viva (inventario, reservaciones futuras,
 *   estado de mesas, agotados y folios).
 *
 * Los ids no chocan porque cada instalación los reparte con su
 * desplazamiento (`Configuracion::instalacion`). Las tablas y columnas se
 * validan contra estas listas y contra el esquema: nada que llegue por la
 * red se escribe en un nombre que no esté aquí.
 */
final class Replica
{
    /**
     * Lo que baja, en orden de llaves foráneas.
     * `locales`: columnas que conserva la sucursal (las escribe ella).
     * `reemplaza`: la sucursal borra lo que ya no llegó (tablas de enlace).
     * `solo_nuevas`: se insertan y después son de la sucursal.
     */
    public const BAJADA = [
        'sucursal' => ['llave' => ['id']],
        'personal' => ['llave' => ['id']],
        'usuario' => ['llave' => ['id'], 'locales' => ['totp_ultimo_periodo', 'ultimo_acceso']],
        'usuario_sucursal' => ['llave' => ['id_usuario', 'id_sucursal'], 'reemplaza' => true],
        'totp_codigo_recuperacion' => ['llave' => ['id'], 'locales' => ['usado_en']],
        'parametro' => ['llave' => ['clave', 'vigente_desde']],
        'sucursal_horario' => ['llave' => ['id_sucursal', 'dia'], 'reemplaza' => true],
        'area' => ['llave' => ['id']],
        'mesa' => ['llave' => ['id'], 'locales' => ['estado']],
        'categoria_menu' => ['llave' => ['id']],
        'platillo' => ['llave' => ['id']],
        'platillo_sucursal' => ['llave' => ['id_sucursal', 'id_platillo'], 'locales' => ['agotado']],
        'modificador_platillo' => ['llave' => ['id']],
        'promocion' => ['llave' => ['id']],
        'promocion_sucursal' => ['llave' => ['id_promocion', 'id_sucursal'], 'reemplaza' => true],
        'promocion_platillo' => ['llave' => ['id_promocion', 'id_platillo'], 'reemplaza' => true],
        'impresora' => ['llave' => ['id']],
        'reservacion' => ['llave' => ['id'], 'solo_nuevas' => true],
    ];

    /**
     * Lo que sube, en orden de llaves foráneas. Cada fila se comprueba de la
     * sucursal de la instalación: directo (`sucursal`), por su padre
     * (`padre`), por la serie (`serie`) o por el alcance de usuarios.
     * `solo`: tabla del catálogo de la que la sucursal solo manda esas columnas.
     */
    public const SUBIDA = [
        'proveedor' => ['llave' => ['id'], 'sucursal' => 'id_sucursal'],
        'insumo' => ['llave' => ['id'], 'sucursal' => 'id_sucursal'],
        'receta_insumo' => ['llave' => ['id_sucursal', 'id_platillo', 'id_insumo'], 'sucursal' => 'id_sucursal'],
        'turno_caja' => ['llave' => ['id'], 'sucursal' => 'id_sucursal'],
        'asiento_caja' => ['llave' => ['id'], 'padre' => ['id_turno', 'turno_caja']],
        'cuenta' => ['llave' => ['id'], 'sucursal' => 'id_sucursal'],
        'cuenta_mesa' => ['llave' => ['id'], 'sucursal' => 'id_sucursal'],
        'ronda' => ['llave' => ['id'], 'padre' => ['id_cuenta', 'cuenta']],
        'cuenta_item' => ['llave' => ['id'], 'padre' => ['id_cuenta', 'cuenta']],
        'pago_cuenta' => ['llave' => ['id'], 'padre' => ['id_cuenta', 'cuenta']],
        'pago_cuenta_forma' => ['llave' => ['id'], 'padre' => ['id_pago', 'pago_cuenta']],
        'compra_insumo' => ['llave' => ['id'], 'sucursal' => 'id_sucursal'],
        'compra_insumo_linea' => ['llave' => ['id'], 'padre' => ['id_compra', 'compra_insumo']],
        'lote_insumo' => ['llave' => ['id'], 'padre' => ['id_insumo', 'insumo']],
        'kardex_insumo' => ['llave' => ['id'], 'padre' => ['id_lote', 'lote_insumo']],
        'gasto_sucursal' => ['llave' => ['id'], 'sucursal' => 'id_sucursal'],
        'faltante_insumo' => ['llave' => ['id'], 'sucursal' => 'id_sucursal'],
        'reservacion' => ['llave' => ['id'], 'sucursal' => 'id_sucursal'],
        'folio_serie' => ['llave' => ['serie'], 'serie' => true],
        'mesa' => ['llave' => ['id'], 'sucursal' => 'id_sucursal', 'solo' => ['estado']],
        'platillo_sucursal' => ['llave' => ['id_sucursal', 'id_platillo'], 'sucursal' => 'id_sucursal', 'solo' => ['agotado']],
        'usuario' => ['llave' => ['id'], 'usuarios' => 'id', 'solo' => ['totp_ultimo_periodo']],
        'totp_codigo_recuperacion' => ['llave' => ['id'], 'usuarios' => 'id_usuario', 'solo' => ['usado_en']],
    ];

    /** Lo que baja una sola vez, al instalar, en orden de llaves foráneas. */
    public const ARRANQUE = [
        'proveedor', 'insumo', 'receta_insumo', 'compra_insumo', 'compra_insumo_linea', 'lote_insumo',
        'reservacion', 'folio_serie', 'mesa', 'platillo_sucursal',
    ];

    /** Filas por lote de subida. */
    public const LOTE = 500;

    /** Cambios que se leen por vuelta para ordenar el lote; cubre un día de corte. */
    private const PENDIENTES_POR_VUELTA = 100000;

    /** @var array<string, list<string>> */
    private array $columnas = [];

    public function __construct(private BaseDatos $bd, private Bitacora $bitacora)
    {
    }

    // --- Central: bajada ------------------------------------------------------

    /**
     * El catálogo de la sucursal, con su huella.
     *
     * @return array{huella:string, tablas:array<string, list<array<string,mixed>>>}
     */
    public function catalogo(int $sucursal): array
    {
        $usuarios = $this->usuariosDe($sucursal);
        $enUsuarios = $this->lista($usuarios);
        $personal = array_map('intval', array_column($this->bd->filas(
            'SELECT DISTINCT p.id FROM personal p LEFT JOIN usuario u ON u.id_personal = p.id
              WHERE p.id_sucursal = ? OR u.id IN (' . $enUsuarios . ')', [$sucursal, ...$usuarios]), 'id'));
        $enPersonal = $this->lista($personal);
        $promociones = array_map('intval', array_column($this->bd->filas(
            'SELECT id_promocion FROM promocion_sucursal WHERE id_sucursal = ?', [$sucursal]), 'id_promocion'));
        $enPromociones = $this->lista($promociones);

        $tablas = [
            'sucursal' => $this->bd->filas('SELECT * FROM sucursal ORDER BY id'),
            'personal' => $this->bd->filas('SELECT * FROM personal WHERE id IN (' . $enPersonal . ') ORDER BY id', $personal),
            'usuario' => $this->bd->filas('SELECT * FROM usuario WHERE id IN (' . $enUsuarios . ') ORDER BY id', $usuarios),
            'usuario_sucursal' => $this->bd->filas('SELECT * FROM usuario_sucursal WHERE id_usuario IN (' . $enUsuarios . ') ORDER BY id_usuario, id_sucursal', $usuarios),
            'totp_codigo_recuperacion' => $this->bd->filas('SELECT * FROM totp_codigo_recuperacion WHERE id_usuario IN (' . $enUsuarios . ') ORDER BY id', $usuarios),
            'parametro' => $this->bd->filas('SELECT * FROM parametro ORDER BY clave, vigente_desde'),
            'sucursal_horario' => $this->bd->filas('SELECT * FROM sucursal_horario WHERE id_sucursal = ? ORDER BY dia', [$sucursal]),
            'area' => $this->bd->filas('SELECT * FROM area WHERE id_sucursal = ? ORDER BY id', [$sucursal]),
            'mesa' => $this->bd->filas('SELECT * FROM mesa WHERE id_sucursal = ? ORDER BY id', [$sucursal]),
            'categoria_menu' => $this->bd->filas('SELECT * FROM categoria_menu ORDER BY id'),
            'platillo' => $this->bd->filas('SELECT * FROM platillo ORDER BY id'),
            'platillo_sucursal' => $this->bd->filas('SELECT * FROM platillo_sucursal WHERE id_sucursal = ? ORDER BY id_platillo', [$sucursal]),
            'modificador_platillo' => $this->bd->filas('SELECT * FROM modificador_platillo ORDER BY id'),
            'promocion' => $this->bd->filas('SELECT * FROM promocion WHERE id IN (' . $enPromociones . ') ORDER BY id', $promociones),
            'promocion_sucursal' => $this->bd->filas('SELECT * FROM promocion_sucursal WHERE id_sucursal = ? ORDER BY id_promocion', [$sucursal]),
            'promocion_platillo' => $this->bd->filas('SELECT * FROM promocion_platillo WHERE id_promocion IN (' . $enPromociones . ') ORDER BY id_promocion, id_platillo', $promociones),
            'impresora' => $this->bd->filas('SELECT * FROM impresora WHERE id_sucursal = ? ORDER BY id', [$sucursal]),
            // Solo las que nacieron en el central (desplazamiento 1) y siguen por venir.
            'reservacion' => $this->bd->filas(
                'SELECT * FROM reservacion WHERE id_sucursal = ? AND MOD(id, ?) = 1 AND desde >= NOW() - INTERVAL 1 DAY ORDER BY id',
                [$sucursal, \Nucleo\Configuracion::INCREMENTO_IDS]),
        ];

        // Lo que apunta a alguien fuera del alcance de la sucursal se manda vacío:
        // la sucursal no tiene esa fila y la llave foránea no entraría.
        $tablas['personal'] = array_map(static fn (array $f): array => in_array((int) $f['id_superior'], $personal, true)
            ? $f : ['id_superior' => null] + $f, $tablas['personal']);
        $tablas['promocion'] = array_map(static fn (array $f): array => in_array((int) $f['creado_por'], $usuarios, true)
            ? $f : ['creado_por' => null] + $f, $tablas['promocion']);
        $tablas['reservacion'] = array_map(fn (array $f): array => $f['id_mesa'] === null
            || in_array((int) $f['id_mesa'], array_map('intval', array_column($tablas['mesa'], 'id')), true)
            ? $f : ['id_mesa' => null] + $f, $tablas['reservacion']);

        // Las columnas locales viajan para la fila nueva, pero no cuentan en la
        // huella: cambian con cada subida y harían bajar todo a cada rato.
        $sinLocales = [];
        foreach ($tablas as $tabla => $filas) {
            $locales = array_flip(self::BAJADA[$tabla]['locales'] ?? []);
            $sinLocales[$tabla] = $locales === [] ? $filas : array_map(static fn (array $f): array => array_diff_key($f, $locales), $filas);
        }

        return ['huella' => hash('sha256', json_encode($sinLocales, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)), 'tablas' => $tablas];
    }

    /**
     * Lo que la sucursal ya tenía de operación viva, para arrancar su servidor.
     *
     * @return array<string, list<array<string,mixed>>>
     */
    public function arranque(int $sucursal): array
    {
        $compras = 'SELECT id FROM compra_insumo WHERE id_sucursal = ?';
        $insumos = 'SELECT id FROM insumo WHERE id_sucursal = ?';

        return [
            'proveedor' => $this->bd->filas('SELECT * FROM proveedor WHERE id_sucursal = ? ORDER BY id', [$sucursal]),
            'insumo' => $this->bd->filas('SELECT * FROM insumo WHERE id_sucursal = ? ORDER BY id', [$sucursal]),
            'receta_insumo' => $this->bd->filas('SELECT * FROM receta_insumo WHERE id_sucursal = ?', [$sucursal]),
            'compra_insumo' => $this->bd->filas('SELECT * FROM compra_insumo WHERE id_sucursal = ? ORDER BY id', [$sucursal]),
            'compra_insumo_linea' => $this->bd->filas('SELECT * FROM compra_insumo_linea WHERE id_compra IN (' . $compras . ') ORDER BY id', [$sucursal]),
            'lote_insumo' => $this->bd->filas('SELECT * FROM lote_insumo WHERE id_insumo IN (' . $insumos . ') ORDER BY id', [$sucursal]),
            'reservacion' => $this->bd->filas('SELECT * FROM reservacion WHERE id_sucursal = ? AND desde >= NOW() - INTERVAL 1 DAY ORDER BY id', [$sucursal]),
            'folio_serie' => $this->bd->filas('SELECT * FROM folio_serie WHERE serie IN (?, ?)', ['ticket:' . $sucursal, 'reservaciones:' . $sucursal]),
            'mesa' => $this->bd->filas('SELECT id, estado FROM mesa WHERE id_sucursal = ? ORDER BY id', [$sucursal]),
            'platillo_sucursal' => $this->bd->filas('SELECT id_sucursal, id_platillo, agotado FROM platillo_sucursal WHERE id_sucursal = ?', [$sucursal]),
        ];
    }

    // --- Sucursal: aplicar la bajada -------------------------------------------

    /**
     * Aplica el catálogo que mandó el central. Devuelve cuántas filas cambió.
     *
     * @param array<string, list<array<string,mixed>>> $tablas
     */
    public function aplicaCatalogo(int $sucursal, array $tablas): int
    {
        return $this->bd->transaccion(function () use ($sucursal, $tablas): int {
            $this->bd->ejecuta('SET @replica_bajando = 1');
            try {
                $cambios = 0;
                foreach (self::BAJADA as $tabla => $definicion) {
                    $filas = $tablas[$tabla] ?? null;
                    if (!is_array($filas)) {
                        throw Errores::conflicto('El central no mandó la tabla ' . $tabla . '. ¿Tienen la misma versión?');
                    }
                    $cambios += $this->aplicaFilas($tabla, $definicion['llave'], $filas, $definicion['locales'] ?? [],
                        (bool) ($definicion['solo_nuevas'] ?? false));
                    if ($definicion['reemplaza'] ?? false) {
                        $cambios += $this->quitaLoQueNoLlego($tabla, $definicion['llave'], $filas);
                    }
                }
                if ($cambios > 0) {
                    // Un tipo de evento que la app no conoce la hace releer todo.
                    $this->bd->valor('SELECT id FROM sucursal WHERE id = ? FOR UPDATE', [$sucursal]);
                    $this->bd->ejecuta('INSERT INTO evento_sucursal (id_sucursal, tipo, entidad) VALUES (?, ?, ?)', [$sucursal, 'replica_catalogo', 0]);
                    $this->bitacora->registra('replica', 'bajada_catalogo', 'sucursal', $sucursal, despues: ['filas' => $cambios]);
                }
                return $cambios;
            } finally {
                $this->bd->ejecuta('SET @replica_bajando = NULL');
            }
        });
    }

    /** @param array<string, list<array<string,mixed>>> $tablas */
    public function aplicaArranque(int $sucursal, array $tablas): int
    {
        if ($this->bd->valor('SELECT id FROM cuenta LIMIT 1') !== null) {
            throw Errores::conflicto('Esta base ya tiene cuentas.');
        }

        return $this->bd->transaccion(function () use ($sucursal, $tablas): int {
            $this->bd->ejecuta('SET @replica_bajando = 1');
            try {
                $filas = 0;
                foreach (self::ARRANQUE as $tabla) {
                    $llave = (self::SUBIDA[$tabla] ?? self::BAJADA[$tabla])['llave'];
                    $datos = $tablas[$tabla] ?? [];
                    if (in_array($tabla, ['mesa', 'platillo_sucursal'], true)) {
                        // Del catálogo solo se toma lo que la sucursal escribe.
                        $filas += $this->actualizaColumnas($tabla, $llave, $datos);
                        continue;
                    }
                    $filas += $this->aplicaFilas($tabla, $llave, $datos, [], false);
                }
                $this->bitacora->registra('replica', 'arranque', 'sucursal', $sucursal, despues: ['filas' => $filas]);
                return $filas;
            } finally {
                $this->bd->ejecuta('SET @replica_bajando = NULL');
            }
        });
    }

    // --- Sucursal: armar la subida ---------------------------------------------

    /**
     * El siguiente lote por subir: los cambios anotados y la foto actual de
     * cada fila (null si ya no existe). Deja fuera lo de los últimos dos
     * segundos para no adelantarse a una transacción que todavía no termina.
     *
     * Las filas van en el orden de `SUBIDA` (padres antes que hijos) y no en
     * el de sus cambios: la foto es la de hoy, y un renglón anotado temprano
     * puede apuntar ya a un padre anotado después. Con más de un lote
     * pendiente —un corte largo—, ordenar por cambio mandaba al hijo antes que
     * a su padre, el central lo rechazaba y el mismo lote se atoraba.
     *
     * @return array{cambios:list<int>, filas:list<array{tabla:string,llave:array<string,mixed>,fila:?array<string,mixed>}>}
     */
    public function lotePendiente(): array
    {
        $orden = array_flip(array_keys(self::SUBIDA));
        $orden['bitacora'] = count($orden);
        $grupos = [];
        foreach ($this->bd->filas(
            'SELECT id, tabla, llave FROM cambio_replica
              WHERE enviado = 0 AND momento < NOW(3) - INTERVAL 2 SECOND ORDER BY id LIMIT ' . self::PENDIENTES_POR_VUELTA) as $cambio) {
            $tabla = (string) $cambio['tabla'];
            if (!isset($orden[$tabla])) {
                throw Errores::conflicto('Un cambio anotado es de una tabla que no sube: ' . $tabla);
            }
            $llave = json_decode((string) $cambio['llave'], true, 4, JSON_THROW_ON_ERROR);
            $firma = $tabla . ':' . json_encode($llave);
            $grupos[$firma] ??= ['tabla' => $tabla, 'llave' => $llave, 'primero' => (int) $cambio['id'], 'ids' => []];
            $grupos[$firma]['ids'][] = (int) $cambio['id'];
        }
        uasort($grupos, static fn (array $a, array $b): int => [$orden[$a['tabla']], $a['primero']] <=> [$orden[$b['tabla']], $b['primero']]);

        $cambios = [];
        $filas = [];
        foreach (array_slice($grupos, 0, self::LOTE) as $grupo) {
            $tabla = $grupo['tabla'];
            $columnas = $tabla === 'bitacora' ? ['id'] : self::SUBIDA[$tabla]['llave'];
            $fila = $this->bd->fila('SELECT * FROM ' . $tabla . ' WHERE ' . $this->dondeLlave($columnas),
                array_map(static fn (string $c): mixed => $grupo['llave'][$c] ?? null, $columnas));
            $filas[] = ['tabla' => $tabla, 'llave' => $grupo['llave'], 'fila' => $fila];
            array_push($cambios, ...$grupo['ids']);
        }

        return ['cambios' => $cambios, 'filas' => $filas];
    }

    /** El último guion de esquema aplicado en esta base. */
    public function esquema(): int
    {
        return (int) $this->bd->valor('SELECT COALESCE(MAX(numero), 0) FROM migracion_esquema');
    }

    /** Null significa que debe actualizarse antes de recibir este catálogo. */
    public function aplicaBajada(int $sucursal, array $catalogo): ?int
    {
        if ((int) ($catalogo['esquema'] ?? 0) > $this->esquema()) {
            return null;
        }
        return ($catalogo['cambio'] ?? false) === true
            ? $this->aplicaCatalogo($sucursal, $catalogo['tablas'] ?? []) : 0;
    }

    /** @param list<int> $cambios */
    public function marcaEnviados(array $cambios): void
    {
        if ($cambios === []) {
            return;
        }
        $this->bd->ejecuta('UPDATE cambio_replica SET enviado = 1 WHERE id IN (' . $this->lista($cambios) . ')', $cambios);
    }

    public function pendientes(): int
    {
        return (int) $this->bd->valor('SELECT COUNT(*) FROM cambio_replica WHERE enviado = 0');
    }

    /** Lo ya enviado de hace más de una semana sobra. */
    public function purga(): int
    {
        return $this->bd->ejecuta('DELETE FROM cambio_replica WHERE enviado = 1 AND momento < NOW() - INTERVAL 7 DAY');
    }

    // --- Central: aplicar la subida --------------------------------------------

    /**
     * Aplica un lote de una instalación. Todo o nada: si una fila no entra,
     * no entra ninguna y la sucursal lo vuelve a mandar.
     *
     * @param array{id:int,id_sucursal:int} $instalacion
     * @param list<array{tabla:string,llave:array<string,mixed>,fila:?array<string,mixed>}> $filas
     * @return array{filas:int, bitacora:int}
     */
    public function aplicaSubida(array $instalacion, array $filas): array
    {
        $sucursal = (int) $instalacion['id_sucursal'];

        return $this->bd->transaccion(function () use ($instalacion, $sucursal, $filas): array {
            $usuarios = $this->usuariosDe($sucursal);
            $porTabla = [];
            $bitacora = [];
            foreach ($filas as $i => $cambio) {
                $tabla = (string) ($cambio['tabla'] ?? '');
                if ($tabla === 'bitacora') {
                    if (is_array($cambio['fila'] ?? null)) {
                        $bitacora[] = $cambio['fila'];
                    }
                    continue;
                }
                if (!isset(self::SUBIDA[$tabla]) || !is_array($cambio['llave'] ?? null)) {
                    throw Errores::datosInvalidos(['filas' => 'La fila ' . $i . ' es de una tabla que no sube: ' . $tabla]);
                }
                $porTabla[$tabla][] = $cambio;
            }

            $aplicadas = 0;
            $borrados = [];
            foreach (self::SUBIDA as $tabla => $definicion) {
                foreach ($porTabla[$tabla] ?? [] as $cambio) {
                    if ($cambio['fila'] === null) {
                        $borrados[] = [$tabla, $definicion, $cambio['llave']];
                        continue;
                    }
                    $aplicadas += $this->subeFila($tabla, $definicion, $cambio['fila'], $sucursal, $usuarios);
                }
            }
            // Los borrados al revés: primero los hijos.
            foreach (array_reverse($borrados) as [$tabla, $definicion, $llave]) {
                if (isset($definicion['solo'])) {
                    continue;
                }
                $aplicadas += $this->borraFila($tabla, $definicion, $llave, $sucursal);
            }

            $apuntes = 0;
            foreach ($bitacora as $apunte) {
                $apuntes += $this->subeApunte((int) $instalacion['id'], $apunte);
            }

            $this->bitacora->registra('replica', 'subida', 'instalacion', (int) $instalacion['id'],
                despues: ['sucursal' => $sucursal, 'filas' => $aplicadas, 'bitacora' => $apuntes]);

            return ['filas' => $aplicadas, 'bitacora' => $apuntes];
        });
    }

    // --- Piezas ------------------------------------------------------------------

    /**
     * Los usuarios que pueden operar en la sucursal: los suyos, los que la
     * tienen asignada y los administradores (sin sucursal).
     *
     * @return list<int>
     */
    public function usuariosDe(int $sucursal): array
    {
        return array_map('intval', array_column($this->bd->filas(
            'SELECT u.id FROM usuario u JOIN personal p ON p.id = u.id_personal
              WHERE p.id_sucursal = ? OR p.id_sucursal IS NULL
                 OR u.id IN (SELECT id_usuario FROM usuario_sucursal WHERE id_sucursal = ?)
              ORDER BY u.id', [$sucursal, $sucursal]), 'id'));
    }

    /**
     * Inserta o actualiza por llave. Primero busca por la llave primaria: así
     * un choque con otra llave única falla en voz alta en lugar de pisar otra
     * fila, que es lo que haría `ON DUPLICATE KEY UPDATE`.
     *
     * @param list<string> $llave
     * @param list<array<string,mixed>> $filas
     * @param list<string> $locales
     */
    private function aplicaFilas(string $tabla, array $llave, array $filas, array $locales, bool $soloNuevas): int
    {
        $cambios = 0;
        foreach ($filas as $fila) {
            $fila = $this->validaColumnas($tabla, $fila, $llave);
            $valoresLlave = array_map(static fn (string $c): mixed => $fila[$c], $llave);
            $existe = $this->bd->valor('SELECT 1 FROM ' . $tabla . ' WHERE ' . $this->dondeLlave($llave) . ' FOR UPDATE', $valoresLlave) !== null;
            if (!$existe) {
                $this->bd->ejecuta('INSERT INTO ' . $tabla . ' (' . implode(', ', array_keys($fila)) . ') VALUES ('
                    . implode(', ', array_fill(0, count($fila), '?')) . ')', array_values($fila));
                $cambios++;
                continue;
            }
            if ($soloNuevas) {
                continue;
            }
            $campos = array_values(array_diff(array_keys($fila), $llave, $locales));
            if ($campos === []) {
                continue;
            }
            $cambios += $this->bd->ejecuta('UPDATE ' . $tabla . ' SET ' . implode(', ', array_map(static fn (string $c): string => $c . ' = ?', $campos))
                . ' WHERE ' . $this->dondeLlave($llave), [...array_map(static fn (string $c): mixed => $fila[$c], $campos), ...$valoresLlave]);
        }

        return $cambios;
    }

    /**
     * Solo actualiza las columnas que llegan, sin insertar.
     *
     * @param list<string> $llave
     * @param list<array<string,mixed>> $filas
     */
    private function actualizaColumnas(string $tabla, array $llave, array $filas): int
    {
        $cambios = 0;
        foreach ($filas as $fila) {
            $fila = $this->validaColumnas($tabla, $fila, $llave);
            $campos = array_values(array_diff(array_keys($fila), $llave));
            if ($campos === []) {
                continue;
            }
            $cambios += $this->bd->ejecuta('UPDATE ' . $tabla . ' SET ' . implode(', ', array_map(static fn (string $c): string => $c . ' = ?', $campos))
                . ' WHERE ' . $this->dondeLlave($llave),
                [...array_map(static fn (string $c): mixed => $fila[$c], $campos), ...array_map(static fn (string $c): mixed => $fila[$c], $llave)]);
        }

        return $cambios;
    }

    /**
     * @param list<string> $llave
     * @param list<array<string,mixed>> $filas
     */
    private function quitaLoQueNoLlego(string $tabla, array $llave, array $filas): int
    {
        $llegaron = [];
        foreach ($filas as $fila) {
            $llegaron[json_encode(array_map(static fn (string $c): string => (string) $fila[$c], $llave))] = true;
        }
        $borradas = 0;
        foreach ($this->bd->filas('SELECT ' . implode(', ', $llave) . ' FROM ' . $tabla) as $local) {
            $valores = array_map(static fn (string $c): string => (string) $local[$c], $llave);
            if (!isset($llegaron[json_encode($valores)])) {
                $borradas += $this->bd->ejecuta('DELETE FROM ' . $tabla . ' WHERE ' . $this->dondeLlave($llave), $valores);
            }
        }

        return $borradas;
    }

    /**
     * @param array<string,mixed> $definicion
     * @param array<string,mixed> $fila
     * @param list<int> $usuarios
     */
    private function subeFila(string $tabla, array $definicion, array $fila, int $sucursal, array $usuarios): int
    {
        $llave = $definicion['llave'];
        $fila = $this->validaColumnas($tabla, $fila, $llave);
        $valoresLlave = array_map(static fn (string $c): mixed => $fila[$c], $llave);

        if (isset($definicion['solo'])) {
            // Del catálogo, la sucursal solo escribe estas columnas.
            $this->exigeDeLaSucursal($tabla, $definicion, $fila, $sucursal, $usuarios);
            $cambios = 0;
            foreach ($definicion['solo'] as $columna) {
                if (!array_key_exists($columna, $fila)) {
                    continue;
                }
                $valor = $fila[$columna];
                if ($tabla . '.' . $columna === 'usuario.totp_ultimo_periodo' && $valor !== null) {
                    // Nunca más allá del periodo de ahora (con holgura de reloj): un
                    // periodo futuro dejaría al usuario sin poder entrar en el central.
                    $valor = min((int) $valor, intdiv(time(), 30) + 2);
                }
                $asigna = match ($tabla . '.' . $columna) {
                    // El periodo de segundo factor solo avanza: impide repetir un código.
                    'usuario.totp_ultimo_periodo' => 'totp_ultimo_periodo = GREATEST(COALESCE(totp_ultimo_periodo, 0), ?)',
                    // Un código de recuperación usado no vuelve a servir.
                    'totp_codigo_recuperacion.usado_en' => 'usado_en = COALESCE(usado_en, ?)',
                    default => $columna . ' = ?',
                };
                $cambios += $this->bd->ejecuta('UPDATE ' . $tabla . ' SET ' . $asigna . ' WHERE ' . $this->dondeLlave($llave),
                    [$valor, ...$valoresLlave]);
            }
            return $cambios;
        }

        $actual = $this->bd->fila('SELECT * FROM ' . $tabla . ' WHERE ' . $this->dondeLlave($llave) . ' FOR UPDATE', $valoresLlave);
        if ($actual !== null) {
            $this->exigeDeLaSucursal($tabla, $definicion, $actual, $sucursal, $usuarios);
        }
        $this->exigeDeLaSucursal($tabla, $definicion, $fila, $sucursal, $usuarios);

        if ($actual === null) {
            $this->bd->ejecuta('INSERT INTO ' . $tabla . ' (' . implode(', ', array_keys($fila)) . ') VALUES ('
                . implode(', ', array_fill(0, count($fila), '?')) . ')', array_values($fila));
            return 1;
        }
        $campos = array_values(array_diff(array_keys($fila), $llave));
        if ($campos === []) {
            return 0;
        }

        return $this->bd->ejecuta('UPDATE ' . $tabla . ' SET ' . implode(', ', array_map(static fn (string $c): string => $c . ' = ?', $campos))
            . ' WHERE ' . $this->dondeLlave($llave), [...array_map(static fn (string $c): mixed => $fila[$c], $campos), ...$valoresLlave]);
    }

    /**
     * @param array<string,mixed> $definicion
     * @param array<string,mixed> $llave
     */
    private function borraFila(string $tabla, array $definicion, array $llave, int $sucursal): int
    {
        $columnas = $definicion['llave'];
        $valores = array_map(static fn (string $c): mixed => $llave[$c] ?? null, $columnas);
        if (in_array(null, $valores, true)) {
            throw Errores::datosInvalidos(['filas' => 'Un borrado de ' . $tabla . ' no trae su llave completa']);
        }
        $actual = $this->bd->fila('SELECT * FROM ' . $tabla . ' WHERE ' . $this->dondeLlave($columnas) . ' FOR UPDATE', $valores);
        if ($actual === null) {
            return 0;
        }
        $this->exigeDeLaSucursal($tabla, $definicion, $actual, $sucursal, []);

        return $this->bd->ejecuta('DELETE FROM ' . $tabla . ' WHERE ' . $this->dondeLlave($columnas), $valores);
    }

    /**
     * El apunte de bitácora lo incorpora `Bitacora`, con id nuevo y su origen.
     *
     * @param array<string,mixed> $apunte
     */
    private function subeApunte(int $instalacion, array $apunte): int
    {
        $apunte = $this->validaColumnas('bitacora', $apunte, ['id']);
        // El dispositivo es de la base de la sucursal; aquí no existe.
        $apunte['id_dispositivo'] = null;

        return $this->bitacora->incorporaDeSucursal($instalacion, (int) $apunte['id'], $apunte);
    }

    /**
     * Comprueba que la fila es de la sucursal de la instalación.
     *
     * @param array<string,mixed> $definicion
     * @param array<string,mixed> $fila
     * @param list<int> $usuarios
     */
    private function exigeDeLaSucursal(string $tabla, array $definicion, array $fila, int $sucursal, array $usuarios): void
    {
        $de = match (true) {
            isset($definicion['sucursal']) => (int) ($fila[$definicion['sucursal']] ?? 0),
            isset($definicion['padre']) => $this->sucursalDelPadre($definicion['padre'], $fila),
            isset($definicion['serie']) => in_array($fila['serie'] ?? '', ['ticket:' . $sucursal, 'reservaciones:' . $sucursal], true) ? $sucursal : 0,
            isset($definicion['usuarios']) => in_array((int) ($fila[$definicion['usuarios']] ?? 0), $usuarios, true) ? $sucursal : 0,
            default => 0,
        };
        if ($de !== $sucursal) {
            throw Errores::prohibido('Una fila de ' . $tabla . ' no es de la sucursal de esta computadora');
        }
    }

    /**
     * @param array{0:string,1:string} $padre
     * @param array<string,mixed> $fila
     */
    private function sucursalDelPadre(array $padre, array $fila): int
    {
        [$columna, $tabla] = $padre;
        $definicion = self::SUBIDA[$tabla];
        $suya = $this->bd->fila('SELECT * FROM ' . $tabla . ' WHERE id = ?', [$fila[$columna] ?? 0]);
        if ($suya === null) {
            return 0;
        }

        return isset($definicion['sucursal'])
            ? (int) $suya[$definicion['sucursal']]
            : $this->sucursalDelPadre($definicion['padre'], $suya);
    }

    /**
     * Solo columnas que existen en el esquema de esta base, y la llave completa.
     *
     * @param array<string,mixed> $fila
     * @param list<string> $llave
     * @return array<string,mixed>
     */
    private function validaColumnas(string $tabla, array $fila, array $llave): array
    {
        $conocidas = $this->columnas[$tabla] ??= array_column($this->bd->filas(
            'SELECT COLUMN_NAME, EXTRA FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', [$tabla]),
            'EXTRA', 'COLUMN_NAME');
        if ($conocidas === []) {
            throw Errores::conflicto('La tabla ' . $tabla . ' no existe en esta base');
        }
        // Las columnas calculadas (`nombre_activo`, …) las llena cada base: no se escriben.
        foreach ($conocidas as $columna => $extra) {
            if (stripos((string) $extra, 'GENERATED') !== false) {
                unset($fila[$columna]);
            }
        }
        $extra = array_diff(array_keys($fila), array_keys($conocidas));
        if ($extra !== []) {
            throw Errores::conflicto('Las bases no tienen la misma versión: ' . $tabla . ' no tiene ' . implode(', ', $extra));
        }
        foreach ($llave as $columna) {
            if (!array_key_exists($columna, $fila) || $fila[$columna] === null) {
                throw Errores::datosInvalidos(['filas' => 'Una fila de ' . $tabla . ' no trae ' . $columna]);
            }
        }

        return $fila;
    }

    /** @param list<string> $columnas */
    private function dondeLlave(array $columnas): string
    {
        return implode(' AND ', array_map(static fn (string $c): string => $c . ' = ?', $columnas));
    }

    /** Marcadores para un `IN`; con la lista vacía, uno que no coincide con nada. @param list<mixed> $valores */
    private function lista(array $valores): string
    {
        return $valores === [] ? 'NULL' : implode(', ', array_fill(0, count($valores), '?'));
    }
}
