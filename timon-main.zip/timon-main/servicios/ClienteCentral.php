<?php
declare(strict_types=1);

namespace Servicios;

use Closure;
use DomainException;
use Nucleo\Instalacion;
use RuntimeException;

/**
 * Cómo habla la computadora de sucursal con el central: la réplica
 * (`guiones/sincroniza.php`) y las actualizaciones (`guiones/actualiza.php`).
 *
 * Toda llamada lleva la llave de la computadora (`X-Instalacion`), la versión
 * instalada y cuánto queda por subir. Sin internet lanza un error cuyo mensaje
 * empieza con `sin_conexion`: quien llama lo trata como algo normal.
 */
final class ClienteCentral
{
    /** @param Closure():int $pendientes */
    public function __construct(
        private Instalacion $instalacion,
        private string $version,
        private Closure $pendientes
    ) {
    }

    /**
     * Una llamada a `/api/v1/replica…`. Devuelve los datos o lanza con el
     * mensaje del central.
     *
     * @param array<string,mixed>|null $cuerpo
     * @return array<string,mixed>
     */
    public function llama(string $metodo, string $ruta, ?array $cuerpo = null): array
    {
        $curl = $this->abre($ruta);
        $cabeceras = $this->cabeceras(['Accept: application/json']);
        if ($cuerpo !== null) {
            $cabeceras[] = 'Content-Type: application/json';
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($cuerpo, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
        }
        curl_setopt_array($curl, [
            CURLOPT_CUSTOMREQUEST => $metodo, CURLOPT_HTTPHEADER => $cabeceras, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 60,
        ]);
        $respuesta = curl_exec($curl);
        $codigo = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        $falla = curl_error($curl);
        curl_close($curl);
        if ($respuesta === false || $codigo === 0) {
            throw new RuntimeException('sin_conexion: ' . $falla);
        }
        $json = json_decode((string) $respuesta, true);
        if ($codigo !== 200 || !is_array($json) || ($json['ok'] ?? false) !== true) {
            throw new DomainException('El central respondió ' . $codigo . ': ' . (string) ($json['error']['mensaje'] ?? 'sin detalle'));
        }

        return is_array($json['datos'] ?? null) ? $json['datos'] : [];
    }

    /**
     * Baja un archivo a `$destino`. Si ya hay una parte bajada
     * (`$destino.parcial`), sigue desde donde se quedó: con internet que se
     * corta, cada intento avanza. Devuelve true cuando el archivo quedó completo.
     */
    public function descarga(string $ruta, string $destino, int $peso): bool
    {
        $parcial = $destino . '.parcial';
        $desde = is_file($parcial) ? (int) filesize($parcial) : 0;
        if ($desde > $peso) {
            unlink($parcial);
            $desde = 0;
        }
        if ($desde < $peso) {
            $archivo = fopen($parcial, $desde > 0 ? 'ab' : 'wb');
            if ($archivo === false) {
                throw new RuntimeException('No se pudo escribir la descarga');
            }
            $curl = $this->abre($ruta);
            curl_setopt_array($curl, [
                CURLOPT_HTTPHEADER => $this->cabeceras($desde > 0 ? ['Range: bytes=' . $desde . '-'] : []),
                CURLOPT_FILE => $archivo, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 1800,
                CURLOPT_LOW_SPEED_LIMIT => 1024, CURLOPT_LOW_SPEED_TIME => 60,
            ]);
            $bien = curl_exec($curl);
            $codigo = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            $falla = curl_error($curl);
            curl_close($curl);
            fclose($archivo);
            if ($codigo === 0) {
                throw new RuntimeException('sin_conexion: ' . $falla);
            }
            if (!in_array($codigo, $desde > 0 ? [206] : [200], true)) {
                // Lo bajado no es parte del paquete (un error del central): se tira.
                unlink($parcial);
                throw new DomainException('El central respondió ' . $codigo . ' al bajar el paquete');
            }
            if ($bien === false) {
                return false;
            }
            clearstatcache(true, $parcial);
        }
        if ((int) filesize($parcial) !== $peso) {
            return false;
        }

        return rename($parcial, $destino);
    }

    /** @return \CurlHandle */
    private function abre(string $ruta): \CurlHandle
    {
        $curl = curl_init($this->instalacion->urlCentral() . '/api/v1/replica' . $ruta);
        if ($curl === false) {
            throw new RuntimeException('No se pudo preparar la llamada al central');
        }
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);

        return $curl;
    }

    /**
     * @param list<string> $mas
     * @return list<string>
     */
    private function cabeceras(array $mas): array
    {
        return [...$mas, 'X-Instalacion: ' . $this->instalacion->secreto(),
            'X-Version: ' . $this->version, 'X-Pendientes: ' . ($this->pendientes)()];
    }
}
