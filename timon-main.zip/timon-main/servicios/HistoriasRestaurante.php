<?php
declare(strict_types=1);

namespace Servicios;

use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;
use Nucleo\Exporta\Xlsx;

final class HistoriasRestaurante
{
    public const ESTADOS_COMPRA = ['ordenada' => 'Ordenada', 'parcial' => 'Parcial', 'recibida' => 'Recibida', 'cancelada' => 'Cancelada'];
    public const MOVIMIENTOS = ['entrada' => 'Entrada', 'consumo' => 'Consumo', 'merma' => 'Merma', 'conteo' => 'Conteo'];
    public const ESTADOS_GASTO = ['vigente' => 'Vigente', 'cancelado' => 'Cancelado'];
    public const TITULOS = ['compras' => 'Compras', 'movimientos' => 'Kardex de insumos', 'gastos' => 'Gastos'];

    public function __construct(private BaseDatos $bd, private OperacionRestaurante $operacion)
    {
    }

    public function pagina(int $sucursal, string $tipo, array $filtros, int $pagina, int $tamano): array
    {
        $this->operacion->consultaSucursal($sucursal);
        [$campos, $desde, $orden, $parametros] = $this->consulta($sucursal, $tipo, $filtros);
        return $this->bd->transaccion(function () use ($campos, $desde, $orden, $parametros, $pagina, $tamano): array {
            $total = (int) $this->bd->valor('SELECT COUNT(*) ' . $desde, $parametros);
            $paginas = max(1, (int) ceil($total / $tamano));
            $pagina = min($pagina, $paginas);
            $filas = $this->bd->filas('SELECT ' . $campos . ' ' . $desde . ' ORDER BY ' . $orden . ' LIMIT ? OFFSET ?',
                [...$parametros, $tamano, ($pagina - 1) * $tamano]);
            return compact('filas', 'total', 'pagina', 'paginas', 'tamano');
        });
    }

    public function exporta(int $sucursal, string $tipo, array $filtros): iterable
    {
        $this->operacion->consultaSucursal($sucursal);
        [$campos, $desde, $orden, $parametros] = $this->consulta($sucursal, $tipo, $filtros);
        foreach ($this->bd->porRenglon('SELECT ' . $campos . ' ' . $desde . ' ORDER BY ' . $orden, $parametros) as $fila) {
            yield match ($tipo) {
                'compras' => [$fila['referencia'], $fila['proveedor'], $fila['creada_en'], self::ESTADOS_COMPRA[$fila['estado']] ?? $fila['estado']],
                'movimientos' => [$fila['id_lote'], $fila['nombre'], self::MOVIMIENTOS[$fila['tipo']] ?? $fila['tipo'],
                    $fila['cantidad'], $fila['motivo'], $fila['creado_en']],
                'gastos' => [$fila['concepto'], $fila['proveedor'], $fila['importe'], $fila['comprobante'],
                    $fila['id_asiento'] === null ? 'No' : 'Sí', $fila['creado_en'],
                    $fila['cancelado_en'] === null ? 'Vigente' : 'Cancelado'],
            };
        }
    }

    public function columnas(string $tipo): array
    {
        $titulos = match ($tipo) {
            'compras' => ['Referencia', 'Proveedor', 'Fecha' => Xlsx::FECHAHORA, 'Estado'],
            'movimientos' => ['Lote' => Xlsx::ENTERO, 'Insumo', 'Movimiento', 'Cantidad' => Xlsx::DECIMAL, 'Motivo', 'Fecha' => Xlsx::FECHAHORA],
            'gastos' => ['Concepto', 'Proveedor', 'Importe' => Xlsx::IMPORTE, 'Comprobante', 'Pagado en caja', 'Fecha' => Xlsx::FECHAHORA, 'Estado'],
            default => throw Errores::noEncontrado(),
        };
        $columnas = [];
        foreach ($titulos as $clave => $dato) {
            $columnas[] = is_int($clave) ? ['titulo' => $dato] : ['titulo' => $clave, 'tipo' => $dato];
        }
        return $columnas;
    }

    private function consulta(int $sucursal, string $tipo, array $filtros): array
    {
        [$campos, $desde, $orden, $fecha, $busqueda, $selector, $estado] = match ($tipo) {
            'compras' => ['c.id,c.referencia,c.estado,c.creada_en,p.nombre AS proveedor',
                'FROM compra_insumo c JOIN proveedor p ON p.id = c.id_proveedor WHERE c.id_sucursal = ?',
                'c.creada_en DESC, c.id DESC', 'c.creada_en', "CONCAT_WS(' ', c.referencia, p.nombre)", 'c.id_proveedor', 'c.estado'],
            'movimientos' => ['k.id,i.nombre,k.id_lote,k.tipo,k.cantidad,k.motivo,k.creado_en',
                'FROM insumo i JOIN lote_insumo l ON l.id_insumo = i.id JOIN kardex_insumo k ON k.id_lote = l.id WHERE i.id_sucursal = ?',
                'k.creado_en DESC, k.id DESC', 'k.creado_en', "CONCAT_WS(' ', i.nombre, k.motivo, k.id_lote)", 'i.id', 'k.tipo'],
            'gastos' => ['g.id,g.version,g.concepto,g.importe,g.comprobante,g.creado_en,p.nombre AS proveedor,g.id_asiento,g.cancelado_en',
                'FROM gasto_sucursal g LEFT JOIN proveedor p ON p.id = g.id_proveedor WHERE g.id_sucursal = ?',
                'g.creado_en DESC, g.id DESC', 'g.creado_en', "CONCAT_WS(' ', g.concepto, p.nombre, g.comprobante)", 'g.id_proveedor', null],
            default => throw Errores::noEncontrado(),
        };
        $parametros = [$sucursal];
        foreach (['desde' => ' >= ?', 'hasta' => ' < DATE_ADD(?, INTERVAL 1 DAY)'] as $campo => $operador) {
            if ($filtros[$campo] !== '') {
                $desde .= ' AND ' . $fecha . $operador;
                $parametros[] = $filtros[$campo];
            }
        }
        if ($filtros['catalogo'] > 0) {
            $desde .= ' AND ' . $selector . ' = ?';
            $parametros[] = $filtros['catalogo'];
        }
        if ($estado !== null && $filtros['estado'] !== '') {
            $desde .= ' AND ' . $estado . ' = ?';
            $parametros[] = $filtros['estado'];
        }
        if ($tipo === 'gastos') {
            $desde .= match ($filtros['estado']) {
                'vigente' => ' AND g.cancelado_en IS NULL', 'cancelado' => ' AND g.cancelado_en IS NOT NULL', default => '',
            };
        }
        foreach (preg_split('/\s+/u', $filtros['buscar'], flags: PREG_SPLIT_NO_EMPTY) as $palabra) {
            $desde .= ' AND LOCATE(?, ' . $busqueda . ') > 0';
            $parametros[] = $palabra;
        }
        return [$campos, $desde, $orden, $parametros];
    }
}
