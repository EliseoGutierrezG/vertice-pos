<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\DatosRestaurante as Datos;
use Modelos\IntentosAcceso;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;

final class EquiposRestaurante
{
    public const TIPOS = [
        'mesero' => 'Mesero', 'caja' => 'Caja', 'cocina' => 'Cocina', 'barra' => 'Barra',
        'impresor' => 'Impresor', 'gerencia' => 'Gerencia',
    ];
    private const PUESTOS = [
        'mesero' => ['mesero', 'gerente', 'administrador'],
        'caja' => ['cajero', 'gerente', 'administrador'],
        'cocina' => ['cocina', 'gerente', 'administrador'],
        'barra' => ['barra', 'gerente', 'administrador'],
        'impresor' => ['gerente', 'administrador'],
        'gerencia' => ['gerente', 'administrador'],
    ];

    public function __construct(
        private BaseDatos $bd,
        private Bitacora $bitacora,
        private Identidad $identidad,
        private IntentosAcceso $intentos,
        private OperacionRestaurante $operacion
    ) {
    }

    public function alta(array $datos, string $ip): array
    {
        $nombre = Datos::texto($datos['nombre'] ?? '', 'nombre', 80);
        $plataforma = Datos::opcion($datos['plataforma'] ?? '', 'plataforma', ['android', 'ios', 'web']);
        $this->limite('registro_equipo', 'registro', $ip);
        $segundos = $this->intentos->falla('registro_equipo', 'registro', $ip);
        if ($segundos > 0) {
            throw Errores::demasiadosIntentos($segundos);
        }

        $secreto = bin2hex(random_bytes(32));
        $codigo = strtoupper(bin2hex(random_bytes(5)));
        $this->bd->transaccion(function () use ($nombre, $plataforma, $codigo, $secreto): void {
            $id = $this->bd->inserta(
                'INSERT INTO equipo (nombre, plataforma, codigo, identificador_hash) VALUES (?, ?, ?, ?)',
                [$nombre, $plataforma, $codigo, hash('sha256', $secreto)]
            );
            $this->bitacora->registra('restaurante', 'equipo_solicitado', 'equipo', $id);
        });
        return ['codigo' => $codigo, 'secreto' => $secreto];
    }

    public function estado(string $secreto): array
    {
        $equipo = $this->busca($secreto);
        return [
            'codigo' => $equipo['codigo'], 'nombre' => $equipo['nombre'],
            'autorizado' => (int) $equipo['autorizado'] === 1,
            'tipo' => $equipo['tipo'],
        ];
    }

    public function lista(int $sucursal): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return $this->bd->filas(
            'SELECT id, nombre, tipo, plataforma, autorizado, autorizado_en FROM equipo
             WHERE id_sucursal = ? ORDER BY nombre', [$sucursal]
        );
    }

    public function pendientes(): array
    {
        return $this->bd->filas(
            'SELECT id,nombre,tipo,plataforma,autorizado,autorizado_en FROM equipo
             WHERE id_sucursal IS NULL AND creado_en >= DATE_SUB(NOW(), INTERVAL 1 DAY) ORDER BY creado_en DESC, id DESC'
        );
    }

    public function autoriza(int $sucursal, string $codigo, string $tipo): void
    {
        $this->vincula($sucursal, strtoupper(trim($codigo)), $tipo);
    }

    public function autorizaPendiente(int $sucursal, int $id, string $tipo): void
    {
        $this->vincula($sucursal, $id, $tipo);
    }

    private function vincula(int $sucursal, int|string $equipoBuscado, string $tipo): void
    {
        $tipo = Datos::opcion($tipo, 'tipo', array_keys(self::TIPOS));
        $this->bd->transaccion(function () use ($sucursal, $equipoBuscado, $tipo): void {
            $this->operacion->bloqueaSucursal($sucursal);
            $equipo = $this->bd->fila(
                'SELECT id, id_sucursal, plataforma FROM equipo WHERE ' . (is_int($equipoBuscado)
                    ? 'id = ? AND id_sucursal IS NULL AND creado_en >= DATE_SUB(NOW(), INTERVAL 1 DAY)'
                    : 'codigo = ? AND (id_sucursal IS NOT NULL OR creado_en >= DATE_SUB(NOW(), INTERVAL 1 DAY))')
                . ' FOR UPDATE',
                [$equipoBuscado]
            );
            if ($equipo === null) {
                throw Errores::noEncontrado('El código no existe o venció');
            }
            if ($equipo['id_sucursal'] !== null && (int) $equipo['id_sucursal'] !== $sucursal) {
                throw Errores::conflicto('El equipo pertenece a otra sucursal');
            }
            $this->validaModo($tipo, $equipo['plataforma']);
            $this->bd->ejecuta(
                'UPDATE equipo SET id_sucursal = ?, tipo = ?, autorizado = 1, autorizado_en = NOW() WHERE id = ?',
                [$sucursal, $tipo, $equipo['id']]
            );
            $this->bd->ejecuta('DELETE FROM sesion_equipo WHERE id_equipo = ?', [$equipo['id']]);
            $this->operacion->registra($sucursal, 'equipo_autorizado', (int) $equipo['id'], ['tipo' => $tipo]);
        });
    }

    public function actualiza(int $sucursal, int $id, array $datos): void
    {
        $nombre = Datos::texto($datos['nombre'] ?? '', 'nombre', 80);
        $tipo = Datos::opcion($datos['tipo'] ?? null, 'tipo', array_keys(self::TIPOS));
        $this->bd->transaccion(function () use ($sucursal, $id, $nombre, $tipo): void {
            $this->operacion->bloqueaSucursal($sucursal);
            $equipo = $this->bd->fila(
                'SELECT tipo, plataforma FROM equipo WHERE id_sucursal = ? AND id = ? AND autorizado = 1 FOR UPDATE',
                [$sucursal, $id]
            ) ?? throw Errores::noEncontrado('Equipo no disponible');
            $this->validaModo($tipo, $equipo['plataforma']);
            $this->bd->ejecuta('UPDATE equipo SET nombre = ?, tipo = ? WHERE id = ?', [$nombre, $tipo, $id]);
            if ($tipo !== $equipo['tipo']) {
                $this->bd->ejecuta('DELETE FROM sesion_equipo WHERE id_equipo = ?', [$id]);
            }
            $this->operacion->registra($sucursal, 'equipo_actualizado', $id, ['nombre' => $nombre, 'tipo' => $tipo]);
        });
    }

    private function validaModo(string $tipo, string $plataforma): void
    {
        if ($tipo === 'impresor' && $plataforma !== 'android') {
            throw Errores::datosInvalidos(['tipo' => 'El equipo impresor debe ser Android']);
        }
    }

    public function retira(int $sucursal, int $id): void
    {
        $this->bd->transaccion(function () use ($sucursal, $id): void {
            $this->operacion->bloqueaSucursal($sucursal);
            if ($this->bd->ejecuta('UPDATE equipo SET autorizado = 0 WHERE id = ? AND id_sucursal = ?', [$id, $sucursal]) === 0) {
                throw Errores::conflicto('El equipo no está autorizado en esta sucursal');
            }
            $this->bd->ejecuta('DELETE FROM sesion_equipo WHERE id_equipo = ?', [$id]);
            $this->operacion->registra($sucursal, 'equipo_retirado', $id);
        });
    }

    public function cambiaPin(string $pin, string $clave): void
    {
        if (!preg_match('/^\d{4,6}$/D', $pin)) {
            throw Errores::datosInvalidos(['pin' => 'Capture de 4 a 6 dígitos']);
        }
        $id = $this->identidad->id();
        $this->bd->transaccion(function () use ($id, $pin, $clave): void {
            $hash = $this->bd->valor('SELECT clave_hash FROM usuario WHERE id = ? FOR UPDATE', [$id]);
            if (!is_string($hash) || !password_verify($clave, $hash)) {
                throw Errores::datosInvalidos(['clave' => 'Verifique la contraseña']);
            }
            $this->bd->ejecuta('UPDATE usuario SET pin_hash = ? WHERE id = ?', [password_hash($pin, PASSWORD_DEFAULT), $id]);
            $this->bd->ejecuta('DELETE FROM sesion_equipo WHERE id_usuario = ?', [$id]);
            $this->bitacora->registra('restaurante', 'pin_actualizado', 'usuario', $id, idUsuario: $id);
        });
    }

    public function entrar(string $secreto, string $usuario, string $pin, string $ip): array
    {
        $equipo = $this->busca($secreto);
        if ((int) $equipo['autorizado'] !== 1) {
            throw Errores::prohibido('El equipo espera autorización');
        }
        $usuario = mb_strtolower(trim($usuario));
        $llave = $equipo['id'] . ':' . $usuario;
        $this->limite('pin_equipo', $llave, $ip);
        $ipEquipo = 'equipo:' . $equipo['id'];
        $this->limite('pin_dispositivo', (string) $equipo['id'], $ipEquipo);
        $cuenta = $this->bd->fila(
            'SELECT id, pin_hash, cambiar_clave, sesion_version FROM usuario
             WHERE usuario = ? AND id_estatus = 4 AND (acceso_hasta IS NULL OR acceso_hasta > NOW())', [$usuario]
        );
        if (!is_string($cuenta['pin_hash'] ?? null) || !password_verify($pin, $cuenta['pin_hash']) || (int) $cuenta['cambiar_clave'] === 1) {
            $segundos = max($this->intentos->falla('pin_equipo', $llave, $ip),
                $this->intentos->falla('pin_dispositivo', (string) $equipo['id'], $ipEquipo));
            throw $segundos > 0 ? Errores::demasiadosIntentos($segundos) : Errores::noAutenticado('Verifique el usuario y el PIN');
        }
        $idUsuario = (int) $cuenta['id'];
        $this->identidad->establece($idUsuario);
        $sucursal = (int) $equipo['id_sucursal'];
        $this->operacion->consultaSucursal($sucursal);
        $this->operacion->exigeOperaAqui($sucursal);
        if (!in_array($this->identidad->puesto(), self::PUESTOS[$equipo['tipo']], true)) {
            throw Errores::prohibido('Su puesto no opera este tipo de equipo');
        }
        $token = bin2hex(random_bytes(32));
        $this->bd->transaccion(function () use ($equipo, $idUsuario, $cuenta, $token): void {
            $actual = $this->bd->fila('SELECT autorizado, tipo FROM equipo WHERE id = ? FOR UPDATE', [$equipo['id']]);
            if ((int) $actual['autorizado'] !== 1 || $actual['tipo'] !== $equipo['tipo']) {
                throw Errores::prohibido('Cambió la autorización del equipo');
            }
            $pinActual = $this->bd->valor('SELECT pin_hash FROM usuario WHERE id = ? FOR UPDATE', [$idUsuario]);
            if ($pinActual !== $cuenta['pin_hash']) {
                throw Errores::noAutenticado('Cambió su PIN. Entre de nuevo');
            }
            $this->bd->ejecuta('DELETE FROM sesion_equipo WHERE id_equipo = ?', [$equipo['id']]);
            $this->bd->ejecuta(
                'INSERT INTO sesion_equipo (id_equipo, id_usuario, sesion_version, token_hash, expira_en)
                 VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 12 HOUR))',
                [$equipo['id'], $idUsuario, $cuenta['sesion_version'], hash('sha256', $token)]
            );
            $this->bitacora->registra('restaurante', 'equipo_entrada', 'equipo', (int) $equipo['id'], idUsuario: $idUsuario);
        });
        $this->intentos->acierta('pin_equipo', $llave, $ip);
        return ['token' => $token, 'tipo' => $equipo['tipo'], 'sucursal' => $sucursal, 'nombre' => $this->identidad->nombre()];
    }

    public function resuelve(string $token, bool $actividad): array
    {
        $hash = hash('sha256', $token);
        $acceso = $this->bd->fila(
            "SELECT e.id AS id_equipo, e.id_sucursal, e.tipo, e.config, se.id_usuario, se.sesion_version
             FROM sesion_equipo se JOIN equipo e ON e.id = se.id_equipo AND e.autorizado = 1
             JOIN sucursal s ON s.id = e.id_sucursal AND s.id_estatus = 4
             WHERE se.token_hash = ? AND se.expira_en > NOW()
             AND (e.tipo IN ('cocina','barra','impresor') OR se.actividad_en > DATE_SUB(NOW(), INTERVAL 15 MINUTE))",
            [$hash]
        );
        if ($acceso === null) {
            throw Errores::noAutenticado('Sesión vencida. Entre de nuevo');
        }
        $this->identidad->establece((int) $acceso['id_usuario']);
        if ($this->identidad->debeCambiarClave()
            || $this->identidad->sesionVersion() !== (int) $acceso['sesion_version']
            || !in_array($this->identidad->puesto(), self::PUESTOS[$acceso['tipo']], true)) {
            throw Errores::noAutenticado('Cambió el acceso. Entre de nuevo');
        }
        $this->identidad->exigeSucursal((int) $acceso['id_sucursal']);
        $this->operacion->exigeOperaAqui((int) $acceso['id_sucursal']);
        if ($actividad && !in_array($acceso['tipo'], ['cocina','barra','impresor'], true)) {
            $this->bd->ejecuta(
                'UPDATE sesion_equipo SET actividad_en = NOW() WHERE token_hash = ?
                 AND actividad_en < DATE_SUB(NOW(), INTERVAL 30 SECOND)', [$hash]
            );
        }
        return $acceso;
    }

    public function sale(string $token): void
    {
        $this->bd->transaccion(function () use ($token): void {
            $hash = hash('sha256', $token);
            $id = $this->bd->valor('SELECT id_equipo FROM sesion_equipo WHERE token_hash = ? FOR UPDATE', [$hash]);
            if ($id !== null) {
                $this->bd->ejecuta('DELETE FROM sesion_equipo WHERE token_hash = ?', [$hash]);
                $this->bitacora->registra('restaurante', 'equipo_salida', 'equipo', (int) $id, idUsuario: $this->identidad->id());
            }
        });
    }

    private function busca(string $secreto): array
    {
        if (!preg_match('/^[a-f0-9]{64}$/D', $secreto)) {
            throw Errores::noAutenticado('Registre el equipo');
        }
        return $this->bd->fila(
            'SELECT id, id_sucursal, nombre, codigo, autorizado, tipo FROM equipo WHERE identificador_hash = ?
             AND (id_sucursal IS NOT NULL OR creado_en >= DATE_SUB(NOW(), INTERVAL 1 DAY))',
            [hash('sha256', $secreto)]
        ) ?? throw Errores::noAutenticado('El registro del equipo venció');
    }

    private function limite(string $ambito, string $cuenta, string $ip): void
    {
        $segundos = $this->intentos->reintento($ambito, $cuenta, $ip);
        if ($segundos > 0) {
            throw Errores::demasiadosIntentos($segundos);
        }
    }
}
