<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\Texto;
use InvalidArgumentException;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\Errores;
use Nucleo\Giro;
use Nucleo\Identidad;

/**
 * Las sucursales del negocio.
 *
 * Una instalación es un negocio y el negocio tiene sucursales: el sitio físico
 * con su personal, sus equipos, su caja y su inventario. Cada fase del giro
 * cuelga lo suyo de aquí (áreas y mesas, impresoras, turnos de caja…).
 *
 * Reglas que el esquema no cuida solo:
 *
 * - **Nombre y clave únicos entre las activas**. La llave única vive en las
 *   columnas generadas; aquí se dice cuál chocó antes de que truene el índice.
 * - **No se da de baja una sucursal con personal activo**: se dice qué lo
 *   impide. Las fases siguientes agregan sus propios impedimentos aquí
 *   (cuentas abiertas, turnos de caja, existencias).
 *
 * Nada se borra: la baja es el estatus 3.
 *
 * El alcance lo da la identidad: el administrador ve todas; los demás, las que
 * alcanzan (su sucursal base y las asignadas).
 */
final class Organizacion
{
    public const ACTIVO   = 4;
    public const INACTIVO = 3;

    private const MODULO = 'organizacion';

    public function __construct(
        private BaseDatos $bd,
        private Bitacora $bitacora,
        private Identidad $identidad
    ) {
    }

    // =========================================================================
    // Lectura
    // =========================================================================

    /**
     * Las sucursales del alcance.
     *
     * @return list<array<string,mixed>>
     */
    public function sucursales(string $estatus = 'activas'): array
    {
        $donde  = [];
        $params = [];

        if (($id = $this->estatusDe($estatus)) !== null) {
            $donde[]  = 's.id_estatus = ?';
            $params[] = $id;
        }

        if (!$this->identidad->esAdministrador()) {
            $alcance = $this->identidad->sucursales();
            if ($alcance === []) {
                return [];
            }
            $donde[] = 's.id IN (' . implode(',', array_fill(0, count($alcance), '?')) . ')';
            array_push($params, ...$alcance);
        }

        return $this->bd->filas(
            'SELECT s.id, s.clave, s.nombre, s.calle, s.numero, s.colonia, s.cp, s.id_estado, s.telefono,
                    s.id_estatus, es.nombre AS estado,
                    (SELECT COUNT(*) FROM personal p WHERE p.id_sucursal = s.id AND p.id_estatus = 4) AS personas
             FROM sucursal s
             LEFT JOIN estado es ON es.id = s.id_estado'
            . ($donde === [] ? '' : ' WHERE ' . implode(' AND ', $donde))
            . ' ORDER BY s.id_estatus DESC, s.nombre, s.id DESC',
            $params
        );
    }

    /** @return array<string,mixed> */
    public function sucursal(int $id): array
    {
        $sucursal = $this->bd->fila(
            'SELECT s.*, es.nombre AS estado,
                    (SELECT COUNT(*) FROM personal p WHERE p.id_sucursal = s.id AND p.id_estatus = 4) AS personas
             FROM sucursal s
             LEFT JOIN estado es ON es.id = s.id_estado
             WHERE s.id = ?',
            [$id]
        );

        if ($sucursal === null) {
            throw Errores::noEncontrado('Esa sucursal no existe');
        }

        $this->identidad->exigeSucursal($id);

        return $sucursal;
    }

    /**
     * Para los `select` de las pantallas: id → nombre de lo activo del alcance.
     *
     * @return array<string,string>
     */
    public function opcionesSucursal(): array
    {
        return array_column($this->sucursales('activas'), 'nombre', 'id');
    }

    public function arranque(int $sucursal): array
    {
        $this->identidad->exigeSucursal($sucursal);
        return $this->bd->fila(
            'SELECT
                (SELECT COUNT(*) FROM area WHERE id_sucursal = ?) AS areas,
                (SELECT COUNT(*) FROM mesa WHERE id_sucursal = ?) AS mesas,
                (SELECT COUNT(*) FROM platillo_sucursal ps JOIN platillo p ON p.id = ps.id_platillo AND p.activo = 1
                    WHERE ps.id_sucursal = ?) AS platillos,
                (SELECT COUNT(*) FROM impresora WHERE id_sucursal = ? AND activa = 1) AS impresoras,
                (SELECT COUNT(*) FROM personal p JOIN usuario u ON u.id_personal = p.id AND u.id_estatus = 4
                    WHERE p.id_sucursal = ? AND p.id_estatus = 4 AND u.pin_hash IS NOT NULL) AS operadores,
                (SELECT COUNT(*) FROM equipo WHERE id_sucursal = ? AND autorizado = 1) AS equipos',
            array_fill(0, 6, $sucursal)
        ) ?? [];
    }

    /** @return array<string,string> Los 32 estados. */
    public function opcionesEstado(): array
    {
        return array_column(
            $this->bd->filas('SELECT id, nombre FROM estado ORDER BY nombre'),
            'nombre',
            'id'
        );
    }

    // =========================================================================
    // Escritura
    // =========================================================================

    /**
     * Da de alta una sucursal o cambia sus datos. Devuelve su id.
     *
     * @param array<string,mixed> $datos
     */
    public function guardaSucursal(?int $id, array $datos, string $ip): int
    {
        $limpio = $this->datosSucursal($datos);

        return $this->bd->transaccion(function (BaseDatos $bd) use ($id, $limpio, $ip): int {
            $antes = null;

            if ($id !== null) {
                $antes = $this->bloqueaSucursal($id);
            } elseif (!$this->identidad->esAdministrador()) {
                throw Errores::prohibido('Solo el administrador da de alta sucursales');
            }

            $this->exigeLibre('nombre', $limpio['nombre'], $id);
            if ($limpio['clave'] !== null) {
                $this->exigeLibre('clave', $limpio['clave'], $id);
            }

            if ($id === null) {
                $id = $bd->inserta(
                    'INSERT INTO sucursal (clave, nombre, calle, numero, colonia, cp, id_estado, telefono, creado_por)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [...array_values($limpio), $this->identidad->id()]
                );
            } else {
                $bd->ejecuta(
                    'UPDATE sucursal SET clave = ?, nombre = ?, calle = ?, numero = ?, colonia = ?, cp = ?, id_estado = ?, telefono = ?
                     WHERE id = ?',
                    [...array_values($limpio), $id]
                );
            }

            $this->apunta(
                $antes === null ? 'crea_sucursal' : 'edita_sucursal',
                $id,
                $antes === null ? null : array_intersect_key($antes, $limpio),
                $limpio,
                $ip
            );

            return $id;
        });
    }

    public function cambiaEstatusSucursal(int $id, bool $activa, string $ip): void
    {
        $this->bd->transaccion(function (BaseDatos $bd) use ($id, $activa, $ip): void {
            $sucursal = $this->bloqueaSucursal($id);
            $nuevo    = $activa ? self::ACTIVO : self::INACTIVO;

            if ((int) $sucursal['id_estatus'] === $nuevo) {
                return;
            }

            if ($activa) {
                $this->exigeLibre('nombre', (string) $sucursal['nombre'], $id);
                if ($sucursal['clave'] !== null) {
                    $this->exigeLibre('clave', (string) $sucursal['clave'], $id);
                }
            } else {
                if (Giro::activo('restaurante') && (
                    $bd->valor('SELECT id FROM cuenta WHERE id_sucursal = ? AND abierta = 1 LIMIT 1', [$id]) !== null
                    || $bd->valor('SELECT id FROM turno_caja WHERE id_sucursal = ? AND abierto = 1', [$id]) !== null
                )) {
                    throw Errores::conflicto('Cierre las cuentas y el turno de caja');
                }
                $personas = (int) $bd->valor('SELECT COUNT(*) FROM personal WHERE id_sucursal = ? AND id_estatus = 4', [$id]);
                if ($personas > 0) {
                    throw Errores::conflicto('La sucursal no se puede dar de baja: tiene '
                        . ($personas === 1 ? 'una persona del personal' : $personas . ' personas del personal') . ' activas.');
                }
            }

            $bd->ejecuta('UPDATE sucursal SET id_estatus = ? WHERE id = ?', [$nuevo, $id]);

            $this->apunta(
                $activa ? 'reactiva_sucursal' : 'da_de_baja_sucursal',
                $id,
                ['id_estatus' => (int) $sucursal['id_estatus']],
                ['id_estatus' => $nuevo],
                $ip
            );
        });
    }

    // =========================================================================
    // Validación
    // =========================================================================

    /**
     * @param array<string,mixed> $datos
     * @return array{clave:?string,nombre:string,calle:?string,numero:?string,colonia:?string,cp:?string,id_estado:?int,telefono:?string}
     */
    private function datosSucursal(array $datos): array
    {
        $errores = [];

        $nombre = Texto::limpio((string) ($datos['nombre'] ?? ''));
        if ($nombre === '') {
            $errores['nombre'] = 'Es obligatorio';
        } elseif (mb_strlen($nombre) > 80) {
            $errores['nombre'] = 'Use hasta 80 caracteres';
        }

        $clave = Texto::opcional($datos['clave'] ?? null);
        if ($clave !== null) {
            $clave = mb_strtoupper($clave);
            if (preg_match('/^[A-Z0-9]{2,8}$/', $clave) !== 1) {
                $errores['clave'] = 'De 2 a 8 letras o números, sin espacios';
            }
        }

        $largos = ['calle' => 120, 'numero' => 20, 'colonia' => 80];
        $textos = [];
        foreach ($largos as $campo => $tope) {
            $textos[$campo] = Texto::opcional($datos[$campo] ?? null);
            if ($textos[$campo] !== null && mb_strlen($textos[$campo]) > $tope) {
                $errores[$campo] = 'Hasta ' . $tope . ' caracteres';
            }
        }

        $cp       = $this->conQueja(fn () => Texto::codigoPostal($datos['cp'] ?? null), 'cp', $errores);
        $telefono = $this->conQueja(fn () => Texto::telefono($datos['telefono'] ?? null), 'telefono', $errores);

        $idEstado = (int) ($datos['id_estado'] ?? 0);
        if ($idEstado > 0 && $this->bd->valor('SELECT 1 FROM estado WHERE id = ?', [$idEstado]) === null) {
            $errores['id_estado'] = 'Ese estado no existe';
        }

        if ($errores !== []) {
            throw Errores::datosInvalidos($errores);
        }

        return [
            'clave'     => $clave,
            'nombre'    => $nombre,
            'calle'     => $textos['calle'],
            'numero'    => $textos['numero'],
            'colonia'   => $textos['colonia'],
            'cp'        => $cp,
            'id_estado' => $idEstado > 0 ? $idEstado : null,
            'telefono'  => $telefono,
        ];
    }

    /** @param array<string,string> $errores */
    private function conQueja(callable $limpia, string $campo, array &$errores): mixed
    {
        try {
            return $limpia();
        } catch (InvalidArgumentException $e) {
            $errores[$campo] = $e->getMessage();

            return null;
        }
    }

    // =========================================================================
    // Piezas
    // =========================================================================

    private function estatusDe(string $estatus): ?int
    {
        return match ($estatus) {
            'inactivas' => self::INACTIVO,
            'todas'     => null,
            default     => self::ACTIVO,
        };
    }

    /**
     * La sucursal, bloqueada hasta el final de la transacción y dentro del alcance.
     *
     * @return array<string,mixed>
     */
    private function bloqueaSucursal(int $id): array
    {
        $sucursal = $this->bd->fila('SELECT * FROM sucursal WHERE id = ? FOR UPDATE', [$id]);

        if ($sucursal === null) {
            throw Errores::noEncontrado('Esa sucursal no existe');
        }

        $this->identidad->exigeSucursal($id);

        return $sucursal;
    }

    /**
     * Que ninguna otra activa lleve ese nombre o esa clave.
     *
     * El `FOR UPDATE` sobre el índice bloquea también el hueco donde caería una
     * nueva: dos altas simultáneas con el mismo nombre se forman y la segunda
     * ve a la primera.
     */
    private function exigeLibre(string $campo, string $valor, ?int $id): void
    {
        $sql = $campo === 'clave'
            ? 'SELECT id FROM sucursal WHERE clave = ? AND id_estatus = 4 AND id <> ? FOR UPDATE'
            : 'SELECT id FROM sucursal WHERE nombre = ? AND id_estatus = 4 AND id <> ? FOR UPDATE';

        if ($this->bd->valor($sql, [$valor, $id ?? 0]) !== null) {
            throw Errores::datosInvalidos([$campo => 'Ya hay una sucursal activa con ' . ($campo === 'clave' ? 'esa clave' : 'ese nombre')]);
        }
    }

    /**
     * @param array<string,mixed>|null $antes
     * @param array<string,mixed>|null $despues
     */
    private function apunta(string $accion, int $id, ?array $antes, ?array $despues, string $ip): void
    {
        $this->bitacora->registra(self::MODULO, $accion, 'sucursal', $id, $antes, $despues, $this->identidad->id(), $ip);
    }
}
