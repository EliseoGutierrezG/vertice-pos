<?php
declare(strict_types=1);

namespace Servicios;

use Dominio\Cobro;
use Dominio\DatosRestaurante as Datos;
use Dominio\Dinero;
use Modelos\Folios;
use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;
use Nucleo\LlaveOperacion;

final class CajaRestaurante
{
    public function __construct(
        private BaseDatos $bd,
        private Identidad $identidad,
        private OperacionRestaurante $operacion,
        private Comandas $comandas,
        private AutorizacionRestaurante $autorizacion,
        private ImpresionRestaurante $impresion,
        private InventarioRestaurante $inventario,
        private Folios $folios,
        private Promociones $promociones
    ) {
    }

    public function estado(int $sucursal): array
    {
        $this->operacion->consultaSucursal($sucursal);
        return [
            'turno' => $this->bd->fila(
                'SELECT id, id_cajero, abierto_en FROM turno_caja WHERE id_sucursal = ? AND abierto = 1', [$sucursal]
            ),
            'impresiones_demoradas' => $this->impresion->demora($sucursal),
        ];
    }

    public function abre(int $sucursal, string $llave, mixed $importe): array
    {
        $fondo = Datos::precio($importe, 'fondo')->aPesos();
        return $this->operacion->unaVez($sucursal, $llave, 'turno_abierto', [$fondo], function () use ($sucursal, $fondo): array {
            $actual = $this->estado($sucursal)['turno'];
            if ($actual !== null) {
                throw Errores::conflicto('La sucursal ya tiene un turno abierto')->conEstadoActual($actual);
            }
            $id = $this->bd->inserta('INSERT INTO turno_caja (id_sucursal,id_cajero,fondo) VALUES (?, ?, ?)',
                [$sucursal, $this->identidad->id(), $fondo]);
            $this->operacion->registra($sucursal, 'turno_abierto', $id, ['fondo' => $fondo]);
            return ['id' => $id];
        });
    }

    public function cierra(int $sucursal, string $llave, int $id, mixed $importe): array
    {
        $declarado = Datos::precio($importe, 'efectivo')->aPesos();
        return $this->operacion->unaVez($sucursal, $llave, 'turno_cerrado', [$id, $declarado],
            function () use ($sucursal, $id, $declarado): array {
                $turno = $this->turno($sucursal);
                if ((int) $turno['id'] !== $id) {
                    throw Errores::conflicto('Cambió el turno de caja');
                }
                $resumen = $this->resumenTurno($sucursal, $id);
                $esperado = Dinero::deCadena($resumen['esperado']);
                $diferencia = Dinero::deCadena($declarado)->menos($esperado)->aPesos();
                $this->bd->ejecuta(
                    'UPDATE turno_caja SET abierto = NULL, cerrado_en = NOW(), efectivo_declarado = ?, efectivo_esperado = ? WHERE id = ?',
                    [$declarado, $esperado->aPesos(), $id]
                );
                $this->operacion->registra($sucursal, 'turno_cerrado', $id, ['diferencia' => $diferencia]);
                $this->impresion->encola($sucursal, 'caja', 'corte', $id, [
                    'CORTE #' . $id,
                    'Cobros: ' . $resumen['cobros'], 'Venta: $' . $resumen['venta'],
                    'Propinas: $' . $resumen['propinas'], 'Descuentos: $' . $resumen['descuentos'],
                    'Promociones: $' . $resumen['promociones'],
                    'Efectivo: $' . $resumen['formas']['efectivo'], 'Tarjeta: $' . $resumen['formas']['tarjeta'],
                    'Transferencia: $' . $resumen['formas']['transferencia'],
                    'Fondo: $' . $resumen['fondo'], 'Entradas: $' . $resumen['entradas'], 'Salidas: $' . $resumen['salidas'],
                    'Efectivo esperado: $' . $esperado->aPesos(), 'Efectivo contado: $' . $declarado,
                    'Diferencia: $' . $diferencia,
                ]);
                return ['id' => $id, 'declarado' => $declarado, 'esperado' => $esperado->aPesos(), 'diferencia' => $diferencia,
                    'resumen' => $resumen];
            }
        );
    }

    /**
     * Lo que pasó en un turno, desglosado por forma de pago.
     *
     * El efectivo esperado es fondo + cobros en efectivo + entradas − salidas.
     * Los cobros suman el importe aplicado, no lo recibido: el cambio ya salió.
     */
    public function resumenTurno(int $sucursal, int $turno): array
    {
        $this->operacion->consultaSucursal($sucursal);
        $fila = $this->bd->fila('SELECT fondo FROM turno_caja WHERE id = ? AND id_sucursal = ?', [$turno, $sucursal])
            ?? throw Errores::noEncontrado('Turno no disponible');
        $formas = array_fill_keys(Cobro::MEDIOS, '0.00');
        foreach ($this->bd->filas(
            'SELECT f.medio, SUM(f.importe) AS importe FROM pago_cuenta p JOIN pago_cuenta_forma f ON f.id_pago = p.id
             WHERE p.id_turno = ? GROUP BY f.medio', [$turno]
        ) as $forma) {
            $formas[$forma['medio']] = Dinero::deCadena($forma['importe'])->aPesos();
        }
        $totales = $this->bd->fila(
            'SELECT COUNT(*) AS cobros, COALESCE(SUM(total), 0) AS venta, COALESCE(SUM(propina), 0) AS propinas,
                    COALESCE(SUM(descuento), 0) AS descuentos FROM pago_cuenta WHERE id_turno = ?', [$turno]
        );
        $promociones = $this->bd->valor(
            "SELECT COALESCE(SUM(i.descuento), 0) FROM pago_cuenta p JOIN cuenta_item i ON i.id_cuenta = p.id_cuenta
             WHERE p.id_turno = ? AND i.estado <> 'cancelado'", [$turno]
        );
        $asientos = $this->bd->fila(
            'SELECT COALESCE(SUM(IF(importe > 0, importe, 0)), 0) AS entradas,
                    COALESCE(SUM(IF(importe < 0, -importe, 0)), 0) AS salidas FROM asiento_caja WHERE id_turno = ?', [$turno]
        );
        $esperado = Dinero::deCadena($fila['fondo'])->mas(Dinero::deCadena($formas['efectivo']))
            ->mas(Dinero::deCadena($asientos['entradas']))->menos(Dinero::deCadena($asientos['salidas']));
        return [
            'fondo' => Dinero::deCadena($fila['fondo'])->aPesos(), 'formas' => $formas,
            'cobros' => (int) $totales['cobros'], 'venta' => Dinero::deCadena($totales['venta'])->aPesos(),
            'propinas' => Dinero::deCadena($totales['propinas'])->aPesos(),
            'descuentos' => Dinero::deCadena($totales['descuentos'])->aPesos(),
            'promociones' => Dinero::deCadena((string) $promociones)->aPesos(),
            'entradas' => Dinero::deCadena($asientos['entradas'])->aPesos(),
            'salidas' => Dinero::deCadena($asientos['salidas'])->aPesos(),
            'esperado' => $esperado->aPesos(),
        ];
    }

    public function movimiento(int $sucursal, string $llave, array $datos): array
    {
        $concepto = Datos::texto($datos['concepto'] ?? '', 'concepto', 120);
        $tipo = Datos::opcion($datos['tipo'] ?? '', 'tipo', ['entrada','salida']);
        $importe = Datos::precio($datos['importe'] ?? '', 'importe');
        if ($importe->esCero()) {
            throw Errores::datosInvalidos(['importe' => 'Capture un importe mayor que cero']);
        }
        $cantidad = ($tipo === 'salida' ? $importe->negado() : $importe)->aPesos();
        return $this->operacion->unaVez($sucursal, $llave, 'caja_movimiento', [$concepto, $cantidad],
            function () use ($sucursal, $concepto, $cantidad): array {
                $id = $this->asienta($sucursal, $concepto, $cantidad);
                return ['id' => $id];
            }
        );
    }

    public function asienta(int $sucursal, string $concepto, string $importe): int
    {
        $turno = $this->turno($sucursal);
        $id = $this->bd->inserta('INSERT INTO asiento_caja (id_turno,id_usuario,concepto,importe) VALUES (?, ?, ?, ?)',
            [$turno['id'], $this->identidad->id(), $concepto, $importe]);
        $this->operacion->registra($sucursal, 'caja_movimiento', $id, ['concepto' => $concepto, 'importe' => $importe]);
        return $id;
    }

    /**
     * Cobra y cierra la cuenta.
     *
     * Es una operación exclusiva: exige la versión con la que la caja calculó
     * el total. El inventario no la detiene: lo que falte se registra y viaja
     * en `faltantes`.
     */
    public function cobra(int $sucursal, int $cuenta, int $version, string $llave, array $datos, string $ip): array
    {
        $formas = $this->formas($datos['formas'] ?? null);
        $propina = Datos::precio($datos['propina'] ?? '0', 'propina');
        $descuento = Datos::precio($datos['descuento'] ?? '0', 'descuento');
        $porcentaje = in_array($datos['descuento_porcentaje'] ?? null, [null, ''], true)
            ? null : Datos::entero($datos['descuento_porcentaje'], 'descuento_porcentaje', 1, 100);
        $motivo = Datos::texto($datos['descuento_motivo'] ?? '', 'descuento_motivo', 120, false);
        $autorizacion = $datos['autorizacion'] ?? null;
        return $this->comandas->modifica($sucursal, $cuenta, $version, $llave, 'cuenta_pagada',
            [$formas, $propina->aPesos(), $descuento->aPesos(), $porcentaje, $motivo],
            function (array $actual) use ($sucursal, $cuenta, $formas, $propina, $descuento, $porcentaje, $motivo, $autorizacion, $ip): array {
                $turno = $this->turno($sucursal);
                $ficha = $this->comandas->cuenta($sucursal, $cuenta);
                $items = array_filter($ficha['items'], static fn (array $i) => $i['estado'] !== 'cancelado');
                if (($items === [] && Dinero::deCadena($actual['ajuste_reparto'])->comparaCon(Dinero::cero()) <= 0) || array_filter($items, static fn (array $i) => $i['estado'] === 'capturado') !== []) {
                    throw Errores::conflicto('Envíe a cocina todos los platillos antes de cobrar');
                }
                $consumo = Dinero::deCadena($ficha['total']);
                $calculo = Cobro::calcula($consumo, $propina, $descuento, $porcentaje, array_map(static fn (array $forma): array => [
                    'medio' => $forma['medio'], 'referencia' => $forma['referencia'],
                    'importe' => Dinero::deCadena($forma['importe']),
                    'recibido' => $forma['recibido'] === null ? null : Dinero::deCadena($forma['recibido']),
                ], $formas));
                $rebaja = $calculo['descuento'];
                $venta = $calculo['venta'];
                $autoriza = $rebaja->esCero() ? null : $this->autorizacion->valida($sucursal, 'descuento_comanda', $autorizacion, $ip);
                $faltantes = $this->inventario->consumeCuenta($sucursal, $cuenta);
                $folio = $this->folios->siguiente('ticket:' . $sucursal, $this->prefijo($sucursal), 6);
                $token = bin2hex(random_bytes(16));
                $pago = $this->bd->inserta(
                    'INSERT INTO pago_cuenta (id_cuenta,id_turno,id_cajero,total,propina,descuento,descuento_autorizado_por,
                        descuento_motivo,folio,token_publico) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [$cuenta, $turno['id'], $this->identidad->id(), $venta->aPesos(), $propina->aPesos(), $rebaja->aPesos(),
                        $autoriza, $rebaja->esCero() || $motivo === '' ? null : $motivo, $folio, $token]
                );
                foreach ($calculo['formas'] as $forma) {
                    $this->bd->ejecuta('INSERT INTO pago_cuenta_forma (id_pago,medio,importe,referencia,recibido,cambio) VALUES (?, ?, ?, ?, ?, ?)',
                        [$pago, $forma['medio'], $forma['importe']->aPesos(), $forma['referencia'],
                            $forma['recibido']?->aPesos(), $forma['cambio']->aPesos()]);
                }
                $this->bd->ejecuta("UPDATE cuenta SET estado = 'pagada', abierta = NULL, cerrada_en = NOW() WHERE id = ?",
                    [$cuenta]);
                $siguiente = $this->comandas->trasCerrar($sucursal, $actual);
                $this->impresion->encola($sucursal, 'caja', 'ticket', $pago, $this->lineasTicket($this->ticket($token)));
                return ['id_pago' => $pago, 'folio' => $folio, 'total' => $venta->aPesos(), 'propina' => $propina->aPesos(),
                    'descuento' => $rebaja->aPesos(), 'pagado' => $calculo['total']->aPesos(), 'cambio' => $calculo['cambio']->aPesos(),
                    'faltantes' => $faltantes, 'id_siguiente' => $siguiente, 'autorizado_por' => $autoriza, 'estado' => 'pagada', 'ticket' => '/ticket/' . $token];
            }
        );
    }

    /**
     * Lo que costaría una venta de mostrador, con sus promociones, sin guardar
     * nada. La app cobra con este total: el mismo cálculo que hará la venta.
     */
    public function cotiza(int $sucursal, array $datos): array
    {
        $this->operacion->consultaSucursal($sucursal);
        $items = $datos['items'] ?? null;
        if (!is_array($items) || !array_is_list($items) || $items === [] || count($items) > 100) {
            throw Errores::datosInvalidos(['items' => 'Agregue de 1 a 100 platillos']);
        }
        $vigentes = $this->promociones->vigentesPara($sucursal, new \DateTimeImmutable());
        $renglones = [];
        $elegidas = [];
        foreach ($items as $n => $item) {
            if (!is_array($item)) {
                throw Errores::datosInvalidos(['items' => 'Revise los platillos de la venta']);
            }
            $platillo = Datos::entero($item['id_platillo'] ?? null, 'id_platillo');
            $cantidad = Datos::entero($item['cantidad'] ?? 1, 'cantidad', 1, 99);
            [, $base, $precio] = $this->comandas->precioCaptura($sucursal, $platillo, Comandas::idsModificadores($item['modificadores'] ?? []), false);
            $promocion = Promociones::mejor($vigentes[$platillo] ?? [], $base, $precio->menos($base));
            if ($promocion !== null) {
                $elegidas[(int) $promocion['id']] = $promocion;
            }
            $renglones[] = ['id' => $n, 'id_platillo' => $platillo, 'id_promocion' => $promocion === null ? null : (int) $promocion['id'],
                'cantidad' => $cantidad, 'precio' => $precio, 'suplementos' => $precio->menos($base)];
        }
        $descuentos = Promociones::calculaDescuentos($renglones, $elegidas);
        $total = Dinero::cero();
        $salida = [];
        foreach ($renglones as $r) {
            $importe = $r['precio']->porEntero($r['cantidad']);
            $total = $total->mas($importe)->menos($descuentos[$r['id']]);
            $salida[] = ['importe' => $importe->aPesos(), 'descuento' => $descuentos[$r['id']]->aPesos(),
                'promocion' => Promociones::rotulo($r['id_promocion'] === null ? null : $elegidas[$r['id_promocion']])];
        }
        return ['items' => $salida, 'total' => $total->aPesos()];
    }

    public function mostrador(int $sucursal, string $llave, array $datos, string $ip): array
    {
        $items = $datos['items'] ?? null;
        if (!is_array($items) || !array_is_list($items) || $items === [] || count($items) > 100) {
            throw Errores::datosInvalidos(['items' => 'Agregue de 1 a 100 platillos']);
        }
        foreach ($items as $item) {
            if (!is_array($item)) {
                throw Errores::datosInvalidos(['items' => 'Revise los platillos de la venta']);
            }
        }
        $huella = $datos;
        unset($huella['autorizacion']);
        return $this->operacion->unaVez($sucursal, $llave, 'venta_mostrador', $huella,
            function () use ($sucursal, $items, $datos, $ip): array {
                $this->turno($sucursal);
                $id = $this->comandas->iniciaMostrador($sucursal);
                foreach ($items as $item) {
                    $this->comandas->agregar($sucursal, $id, LlaveOperacion::nueva(), $item);
                }
                $envio = $this->comandas->enviar($sucursal, $id, LlaveOperacion::nueva());
                $cobro = $this->cobra($sucursal, $id, $envio['version'], LlaveOperacion::nueva(), $datos, $ip);
                $this->operacion->registra($sucursal, 'venta_mostrador', $id, ['pago' => $cobro['id_pago']], $id);
                return $cobro;
            }
        );
    }

    /** Lo que lleva el ticket, tanto el público como el que sale de la térmica. */
    public function ticket(string $token): array
    {
        $ticket = $this->bd->fila(
            "SELECT p.id,p.folio,p.id_cuenta,p.pagado_en,p.total,p.propina,p.descuento,s.nombre AS sucursal,
                    c.tipo,c.cliente,c.ajuste_reparto,c.id_mesa,c.id_sucursal,c.id_cuenta_madre,COALESCE(pm.nombre, um.usuario) AS mesero,COALESCE(pc.nombre, uc.usuario) AS cajero
             FROM pago_cuenta p JOIN cuenta c ON c.id = p.id_cuenta JOIN sucursal s ON s.id = c.id_sucursal
             JOIN usuario um ON um.id = c.id_mesero LEFT JOIN personal pm ON pm.id = um.id_personal
             JOIN usuario uc ON uc.id = p.id_cajero LEFT JOIN personal pc ON pc.id = uc.id_personal
             WHERE p.token_publico = ?", [$token]
        ) ?? throw Errores::noEncontrado('Ticket no disponible');
        $ticket['folio'] ??= '#' . $ticket['id'];
        $ticket['mesas'] = array_column($this->bd->filas(
            'SELECT DISTINCT m.numero FROM cuenta_mesa cm JOIN mesa m ON m.id = cm.id_mesa WHERE cm.id_cuenta = ? ORDER BY m.numero',
            [$ticket['id_cuenta']]
        ), 'numero');
        if ($ticket['tipo'] === 'mesa' && $ticket['mesas'] === []) {
            $numero = $this->comandas->numeroMesa((int) $ticket['id_sucursal'], $ticket);
            if ($numero !== null) {
                $ticket['mesas'][] = $numero;
            }
        }
        $ticket['items'] = $this->bd->filas(
            "SELECT platillo,cantidad,precio,cantidad * precio AS importe,descuento,promocion FROM cuenta_item
             WHERE id_cuenta = ? AND estado <> 'cancelado' ORDER BY id",
                    [$ticket['id_cuenta']]
        );
        $promociones = Dinero::cero();
        foreach ($ticket['items'] as $item) {
            $promociones = $promociones->mas(Dinero::deCadena($item['descuento']));
        }
        $ticket['promociones'] = $promociones->aPesos();
        $ticket['formas'] = $this->bd->filas('SELECT medio,importe,recibido,cambio FROM pago_cuenta_forma WHERE id_pago = ? ORDER BY id', [$ticket['id']]);
        $ticket['consumo'] = Dinero::deCadena($ticket['total'])->mas(Dinero::deCadena($ticket['descuento']))->aPesos();
        $ticket['platillos_total'] = Dinero::deCadena($ticket['consumo'])->menos(Dinero::deCadena($ticket['ajuste_reparto']))->aPesos();
        $ticket['pagado'] = Dinero::deCadena($ticket['total'])->mas(Dinero::deCadena($ticket['propina']))->aPesos();
        $ticket['origen'] = match ($ticket['tipo']) {
            'mesa' => $ticket['mesas'] === [] ? 'Mesa' : 'Mesa ' . implode(' + ', $ticket['mesas']),
            'llevar' => 'Para llevar', 'domicilio' => 'A domicilio', default => 'Mostrador',
        };
        return $ticket;
    }

    /** @return list<string> */
    private function lineasTicket(array $ticket): array
    {
        $lineas = ['TICKET ' . $ticket['folio'], $ticket['origen'] . ' · Atendió ' . $ticket['mesero']];
        foreach ($ticket['items'] as $item) {
            $lineas[] = $item['cantidad'] . ' x ' . $item['platillo'] . ' $' . Dinero::deCadena($item['importe'])->aPesos();
            if (!Dinero::deCadena($item['descuento'])->esCero()) {
                $lineas[] = '  ' . $item['promocion'] . ' -$' . Dinero::deCadena($item['descuento'])->aPesos();
            }
        }
        if (!Dinero::deCadena($ticket['ajuste_reparto'])->esCero()) {
            $lineas[] = 'Platillos: $' . $ticket['platillos_total'];
            $lineas[] = 'Ajuste por reparto: $' . $ticket['ajuste_reparto'];
        }
        $lineas[] = 'Consumo: $' . $ticket['consumo'];
        if (!Dinero::deCadena($ticket['descuento'])->esCero()) {
            $lineas[] = 'Descuento: -$' . $ticket['descuento'];
        }
        $lineas[] = 'Propina: $' . $ticket['propina'];
        $lineas[] = 'Total: $' . $ticket['pagado'];
        foreach ($ticket['formas'] as $forma) {
            $lineas[] = ucfirst($forma['medio']) . ': $' . $forma['importe'];
            if ($forma['recibido'] !== null) {
                $lineas[] = '  Recibido: $' . $forma['recibido'] . ' · Cambio: $' . $forma['cambio'];
            }
        }
        return $lineas;
    }

    /** La clave de la sucursal abre el folio: `CEN-000123`. */
    private function prefijo(int $sucursal): string
    {
        $clave = preg_replace('/[^A-Z0-9]/', '', strtoupper((string) $this->bd->valor('SELECT clave FROM sucursal WHERE id = ?', [$sucursal])));
        return $clave === '' || $clave === null ? 'S' . $sucursal : $clave;
    }

    private function turno(int $sucursal): array
    {
        return $this->bd->fila('SELECT id,fondo FROM turno_caja WHERE id_sucursal = ? AND abierto = 1 FOR UPDATE',
            [$sucursal]) ?? throw Errores::conflicto('Abra un turno de caja');
    }

    private function formas(mixed $datos): array
    {
        // Puede venir vacía: una cortesía completa no lleva pagos. `Cobro` decide si cuadra.
        if (!is_array($datos) || !array_is_list($datos) || count($datos) > 20) {
            throw Errores::datosInvalidos(['formas' => 'Capture hasta 20 formas de pago']);
        }
        return array_map(static function (mixed $forma): array {
            if (!is_array($forma)) {
                throw Errores::datosInvalidos(['formas' => 'Capture una forma de pago válida']);
            }
            $medio = Datos::opcion($forma['medio'] ?? '', 'medio', Cobro::MEDIOS);
            $recibido = $forma['recibido'] ?? null;
            return [
                'medio' => $medio,
                'importe' => Datos::precio($forma['importe'] ?? '', 'importe')->aPesos(),
                'referencia' => $medio === 'efectivo' ? null : Datos::texto($forma['referencia'] ?? '', 'referencia', 80),
                'recibido' => $recibido === null || $recibido === '' ? null : Datos::precio($recibido, 'recibido')->aPesos(),
            ];
        }, $datos);
    }
}
