SET NAMES utf8mb4;

ALTER TABLE trabajo_impresion
  ADD COLUMN IF NOT EXISTS intentos TINYINT UNSIGNED NOT NULL DEFAULT 0;

INSERT INTO permiso (clave, descripcion) VALUES ('menu_agota', 'Marcar y retirar agotados de la sucursal');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT puesto.id, permiso.id FROM puesto CROSS JOIN permiso
  WHERE permiso.clave = 'menu_agota' AND puesto.clave IN ('administrador','gerente','cocina','barra');
