SET NAMES utf8mb4;

CREATE TABLE sucursal_horario (
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  dia TINYINT UNSIGNED NOT NULL,
  abre TIME NOT NULL,
  cierra TIME NOT NULL,
  PRIMARY KEY (id_sucursal, dia),
  CONSTRAINT ck_horario_dia CHECK (dia BETWEEN 1 AND 7),
  CONSTRAINT ck_horario_turno CHECK (abre BETWEEN '00:00:00' AND '23:59:59'
    AND cierra BETWEEN '00:00:00' AND '23:59:59' AND abre <> cierra),
  CONSTRAINT fk_horario_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE reservacion
  MODIFY COLUMN estado ENUM('solicitada','confirmada','atendida','cancelada','ausente') NOT NULL DEFAULT 'solicitada',
  ADD COLUMN folio VARCHAR(28) DEFAULT NULL,
  ADD COLUMN nota VARCHAR(240) NOT NULL DEFAULT '',
  ADD COLUMN solicitante_hash CHAR(64) DEFAULT NULL,
  ADD UNIQUE KEY uq_reserva_folio (folio),
  ADD KEY ix_reserva_solicitante (id_sucursal, solicitante_hash, creada_en);
