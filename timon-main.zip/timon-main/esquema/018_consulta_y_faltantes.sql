SET NAMES utf8mb4;

INSERT INTO permiso (clave, descripcion) VALUES
  ('caja_consulta', 'Consultar turnos y cortes de caja'),
  ('faltantes_atiende', 'Atender faltantes de insumos registrados en caja');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe WHERE
    (p.clave IN ('administrador','gerente','cajero') AND pe.clave = 'caja_consulta')
    OR (p.clave IN ('administrador','gerente','almacen') AND pe.clave = 'faltantes_atiende');
