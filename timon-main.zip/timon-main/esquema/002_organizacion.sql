-- =============================================================================
-- Plantilla base — 002 · Organización
--
-- Una instalación es un negocio; el negocio tiene sucursales. La sucursal es
-- el sitio físico: tiene su personal, sus equipos, su caja y su inventario.
-- (En Distribuidora esto se llamaba `bodega`.)
-- =============================================================================

SET NAMES utf8mb4;

CREATE TABLE sucursal (
  id            SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  clave         VARCHAR(8)        DEFAULT NULL COMMENT 'Abreviatura corta para tickets y folios: CEN, NTE…',
  nombre        VARCHAR(80)       NOT NULL,
  calle         VARCHAR(120)      DEFAULT NULL,
  numero        VARCHAR(20)       DEFAULT NULL,
  colonia       VARCHAR(80)       DEFAULT NULL,
  cp            CHAR(5)           DEFAULT NULL,
  id_estado     TINYINT UNSIGNED  DEFAULT NULL,
  id_municipio  SMALLINT UNSIGNED DEFAULT NULL,
  telefono      VARCHAR(20)       DEFAULT NULL,
  latitud       DECIMAL(10,7)     DEFAULT NULL,
  longitud      DECIMAL(10,7)     DEFAULT NULL,
  id_estatus    TINYINT UNSIGNED  NOT NULL DEFAULT 4,
  creado_en     DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creado_por    INT UNSIGNED      DEFAULT NULL,
  nombre_activo VARCHAR(80) GENERATED ALWAYS AS (IF(id_estatus = 4, nombre, NULL)) STORED
                COMMENT 'El nombre si está activa; NULL si no. Solo para la llave única',
  clave_activa  VARCHAR(8)  GENERATED ALWAYS AS (IF(id_estatus = 4, clave, NULL)) STORED,
  PRIMARY KEY (id),
  UNIQUE KEY ux_sucursal_nombre_activo (nombre_activo),
  UNIQUE KEY ux_sucursal_clave_activa (clave_activa),
  KEY ix_sucursal_nombre (nombre),
  KEY ix_sucursal_estatus (id_estatus),
  CONSTRAINT fk_sucursal_estado    FOREIGN KEY (id_estado)    REFERENCES estado (id),
  CONSTRAINT fk_sucursal_estatus   FOREIGN KEY (id_estatus)   REFERENCES estatus (id),
  CONSTRAINT fk_sucursal_municipio FOREIGN KEY (id_municipio) REFERENCES municipio (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Sitio físico del negocio. Nombre y clave únicos entre las activas.';
