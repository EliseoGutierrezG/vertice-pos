SET NAMES utf8mb4;

-- Cada evento dice a qué cuenta pertenece, para que la app recargue sólo esa
-- cuenta y no todo el salón. Los eventos que no son de una cuenta (plano,
-- menú, impresión) lo dejan vacío.
ALTER TABLE evento_sucursal ADD COLUMN id_cuenta BIGINT UNSIGNED DEFAULT NULL;
