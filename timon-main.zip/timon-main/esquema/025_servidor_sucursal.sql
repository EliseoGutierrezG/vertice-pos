SET NAMES utf8mb4;

-- Servidor de sucursal: una copia del sistema en la red del restaurante que
-- sigue operando sin internet y se sincroniza con el central.
--
-- Una sucursal `local` escribe su operación solo en su servidor; el central
-- la recibe por réplica y rechaza escribirla por su cuenta.
ALTER TABLE sucursal
  ADD COLUMN servidor ENUM('central','local') NOT NULL DEFAULT 'central'
  COMMENT 'Dónde se escribe la operación de la sucursal';

-- Los servidores de sucursal que conoce el central. Cada uno se autentica con
-- su secreto (se guarda solo el SHA-256) y reparte ids con su desplazamiento:
-- todas las instalaciones usan incremento 100; el central, desplazamiento 1.
CREATE TABLE instalacion (
  id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(80) NOT NULL,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  desplazamiento TINYINT UNSIGNED NOT NULL,
  secreto_hash CHAR(64) NOT NULL,
  activa TINYINT UNSIGNED NOT NULL DEFAULT 1,
  version VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'Liberación que reportó el servidor',
  ultimo_cambio BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Último cambio aplicado de su subida',
  ultima_subida DATETIME DEFAULT NULL,
  ultima_bajada DATETIME DEFAULT NULL,
  pendientes INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Cambios por subir que reportó en su último contacto',
  ultimo_error VARCHAR(300) NOT NULL DEFAULT '',
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creado_por INT UNSIGNED DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_instalacion_sucursal (id_sucursal),
  UNIQUE KEY uq_instalacion_desplazamiento (desplazamiento),
  UNIQUE KEY uq_instalacion_secreto (secreto_hash),
  CONSTRAINT ck_instalacion_desplazamiento CHECK (desplazamiento BETWEEN 2 AND 99),
  CONSTRAINT fk_instalacion_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_instalacion_usuario FOREIGN KEY (creado_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lo que el servidor de sucursal tiene por subir. Lo llenan disparadores en la
-- misma transacción que el cambio; en el central queda vacía.
CREATE TABLE cambio_replica (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tabla VARCHAR(40) NOT NULL,
  llave VARCHAR(120) NOT NULL COMMENT 'Llave primaria de la fila, en JSON',
  momento DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  enviado TINYINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY ix_cambio_replica_pendiente (enviado, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La bitácora que sube de una sucursal recibe un id nuevo en el central (el
-- sello encadena por id) y guarda de dónde vino, para que reenviar no duplique.
ALTER TABLE bitacora
  ADD COLUMN origen_instalacion SMALLINT UNSIGNED DEFAULT NULL,
  ADD COLUMN origen_id BIGINT UNSIGNED DEFAULT NULL,
  ADD UNIQUE KEY uq_bitacora_origen (origen_instalacion, origen_id);

INSERT INTO permiso (clave, descripcion) VALUES
  ('servidor_admin', 'Registrar servidores de sucursal y revisar su sincronización');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe
  WHERE p.clave = 'administrador' AND pe.clave = 'servidor_admin';
