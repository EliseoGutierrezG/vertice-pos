SET NAMES utf8mb4;

ALTER TABLE compra_insumo
  MODIFY COLUMN estado ENUM('ordenada','parcial','recibida','cancelada') NOT NULL DEFAULT 'ordenada';

ALTER TABLE compra_insumo_linea
  ADD COLUMN recibido DECIMAL(12,3) UNSIGNED NOT NULL DEFAULT 0,
  ADD CONSTRAINT ck_compra_recibido CHECK (recibido <= cantidad);

UPDATE compra_insumo_linea l JOIN compra_insumo c ON c.id = l.id_compra
  SET l.recibido = l.cantidad WHERE c.estado = 'recibida';
