-- =============================================================================
-- Plantilla base — 001 · Catálogos
-- MariaDB · InnoDB · utf8mb4
--
-- Serie consolidada nueva (2026-11-14). Las tablas vienen de la capa base de
-- Distribuidora; aquí nacen limpias, sin el historial de sus 67 guiones.
--
-- Convenciones (valen para todos los guiones que siguen):
--   · Todo en español, snake_case.
--   · Toda tabla con ciclo de vida lleva `id_estatus` → `estatus`.
--   · Importes en DECIMAL, nunca en coma flotante: unitarios (12,4), totales
--     (14,2). El dominio (`dominio/Dinero.php`) cuenta en centavos.
--   · Nada se borra: baja lógica con el estatus 3.
--   · Lo que puede crecer es catálogo, no ENUM.
--   · Toda tabla operativa registra quién y cuándo.
--   · Un guion aplicado no se modifica: se agrega otro.
-- =============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE estatus (
  id            TINYINT UNSIGNED NOT NULL,
  nombre        VARCHAR(40)      NOT NULL,
  descripcion   VARCHAR(160)     NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Ciclo de vida común. Cada fase agrega los estatus que use.';

INSERT INTO estatus (id, nombre, descripcion) VALUES
  (1, 'Validado',  'Registro revisado y aprobado'),
  (2, 'Cancelado', 'Operación cancelada'),
  (3, 'Inactivo',  'Baja lógica'),
  (4, 'Activo',    'Vigente o aplicado'),
  (5, 'Pendiente', 'En espera de confirmación');

CREATE TABLE estado (
  id           TINYINT UNSIGNED NOT NULL COMMENT 'Clave INEGI de la entidad (01-32)',
  nombre       VARCHAR(40)      NOT NULL,
  abreviatura  VARCHAR(6)       NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE municipio (
  id         SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_estado  TINYINT UNSIGNED  NOT NULL,
  clave      SMALLINT UNSIGNED NOT NULL COMMENT 'Clave INEGI del municipio dentro de su estado (001-570)',
  nombre     VARCHAR(80)       NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_municipio_clave (id_estado, clave),
  KEY ix_municipio_nombre (id_estado, nombre),
  CONSTRAINT fk_municipio_estado FOREIGN KEY (id_estado) REFERENCES estado (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE dia (
  id           TINYINT UNSIGNED NOT NULL,
  nombre       VARCHAR(12)      NOT NULL,
  abreviatura  CHAR(3)          NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO dia (id, nombre, abreviatura) VALUES
  (1, 'Lunes', 'Lu'), (2, 'Martes', 'Ma'), (3, 'Miércoles', 'Mi'), (4, 'Jueves', 'Ju'),
  (5, 'Viernes', 'Vi'), (6, 'Sábado', 'Sa'), (7, 'Domingo', 'Do');

CREATE TABLE parametro (
  clave          VARCHAR(60)  NOT NULL,
  valor          VARCHAR(255) NOT NULL,
  descripcion    VARCHAR(255) DEFAULT NULL,
  vigente_desde  DATE         NOT NULL,
  vigente_hasta  DATE         DEFAULT NULL,
  PRIMARY KEY (clave, vigente_desde)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Reglas con vigencia. Ningún valor va en el código.';

CREATE TABLE folio_serie (
  serie   VARCHAR(40)  NOT NULL COMMENT 'cuenta, ticket, compra, entrada…',
  ultimo  INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'El último entregado',
  PRIMARY KEY (serie)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE migracion_esquema (
  numero       SMALLINT UNSIGNED NOT NULL,
  nombre       VARCHAR(120)      NOT NULL,
  sha256       CHAR(64)          NOT NULL,
  aplicada_en  DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (numero),
  UNIQUE KEY uq_migracion_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Guiones incrementales aplicados y su huella inmutable.';

SET FOREIGN_KEY_CHECKS = 1;
