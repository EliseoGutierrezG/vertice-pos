-- Cobro con cambio y folio por sucursal, comensales por cuenta y faltantes de
-- inventario. Toda columna nueva lleva DEFAULT: lo ya cobrado no se toca.
SET NAMES utf8mb4;

ALTER TABLE pago_cuenta
  ADD COLUMN folio VARCHAR(24) DEFAULT NULL,
  ADD COLUMN descuento_motivo VARCHAR(120) DEFAULT NULL,
  ADD UNIQUE KEY uq_pago_folio (folio);

-- `importe` sigue siendo lo que se aplica a la cuenta. `recibido` es lo que el
-- cliente entregó en efectivo y `cambio` lo que se le regresa: el corte no cambia.
ALTER TABLE pago_cuenta_forma
  ADD COLUMN recibido DECIMAL(12,2) UNSIGNED DEFAULT NULL,
  ADD COLUMN cambio DECIMAL(12,2) UNSIGNED NOT NULL DEFAULT 0;

ALTER TABLE cuenta ADD COLUMN comensales TINYINT UNSIGNED DEFAULT NULL;

-- Lo que una receta pedía y el almacén no tenía al cobrar. El cobro no se
-- detiene: el faltante queda aquí para que almacén lo atienda.
CREATE TABLE faltante_insumo (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_insumo INT UNSIGNED NOT NULL,
  id_cuenta BIGINT UNSIGNED NOT NULL,
  cantidad DECIMAL(12,3) UNSIGNED NOT NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atendido_en DATETIME DEFAULT NULL,
  atendido_por INT UNSIGNED DEFAULT NULL,
  nota VARCHAR(160) DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_faltante_pendiente (id_sucursal, atendido_en, id),
  KEY ix_faltante_cuenta (id_cuenta),
  CONSTRAINT fk_faltante_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_faltante_insumo FOREIGN KEY (id_insumo) REFERENCES insumo (id),
  CONSTRAINT fk_faltante_cuenta FOREIGN KEY (id_cuenta) REFERENCES cuenta (id),
  CONSTRAINT fk_faltante_atendio FOREIGN KEY (atendido_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
