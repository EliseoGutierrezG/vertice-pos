SET NAMES utf8mb4;

ALTER TABLE usuario ADD COLUMN pin_hash VARCHAR(255) DEFAULT NULL;

CREATE TABLE equipo (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED DEFAULT NULL,
  nombre VARCHAR(80) NOT NULL,
  tipo ENUM('mesero','caja','cocina','barra','impresor','gerencia') DEFAULT NULL,
  plataforma ENUM('android','ios','web') NOT NULL,
  codigo CHAR(10) NOT NULL,
  identificador_hash CHAR(64) NOT NULL,
  config JSON DEFAULT NULL,
  autorizado TINYINT(1) NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  autorizado_en DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_equipo_codigo (codigo),
  UNIQUE KEY uq_equipo_identificador (identificador_hash),
  KEY ix_equipo_sucursal (id_sucursal, autorizado),
  CONSTRAINT fk_equipo_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sesion_equipo (
  id_equipo INT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  sesion_version INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  actividad_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expira_en DATETIME NOT NULL,
  PRIMARY KEY (id_equipo),
  UNIQUE KEY uq_sesion_equipo_token (token_hash),
  KEY ix_sesion_equipo_usuario (id_usuario),
  CONSTRAINT fk_sesion_equipo_equipo FOREIGN KEY (id_equipo) REFERENCES equipo (id),
  CONSTRAINT fk_sesion_equipo_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permiso (clave, descripcion) VALUES
  ('equipo_admin', 'Autorizar equipos de comanda de la sucursal');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe
  WHERE p.clave IN ('administrador','gerente') AND pe.clave = 'equipo_admin';
