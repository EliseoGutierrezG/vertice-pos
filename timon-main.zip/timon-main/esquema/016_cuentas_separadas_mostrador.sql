SET NAMES utf8mb4;

ALTER TABLE cuenta
  DROP CONSTRAINT ck_cuenta_tipo,
  MODIFY COLUMN tipo ENUM('mesa','llevar','domicilio','mostrador') NOT NULL,
  ADD COLUMN id_cuenta_madre BIGINT UNSIGNED DEFAULT NULL,
  ADD COLUMN ajuste_reparto DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  ADD KEY ix_cuenta_madre_abierta (id_sucursal, id_cuenta_madre, abierta, id),
  ADD CONSTRAINT fk_cuenta_madre FOREIGN KEY (id_sucursal, id_cuenta_madre) REFERENCES cuenta (id_sucursal, id),
  ADD CONSTRAINT ck_cuenta_tipo CHECK (
    (tipo = 'mesa' AND (id_mesa IS NOT NULL OR id_cuenta_madre IS NOT NULL))
    OR (tipo <> 'mesa' AND id_mesa IS NULL AND id_cuenta_madre IS NULL)
  );
