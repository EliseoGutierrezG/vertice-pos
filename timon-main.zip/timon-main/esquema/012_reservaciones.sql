SET NAMES utf8mb4;

ALTER TABLE sucursal
  ADD COLUMN horario_publico VARCHAR(160) NOT NULL DEFAULT '',
  ADD COLUMN whatsapp_publico VARCHAR(20) NOT NULL DEFAULT '',
  ADD KEY ix_sucursal_clave (clave);

CREATE TABLE reservacion (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_mesa INT UNSIGNED DEFAULT NULL,
  cliente VARCHAR(100) NOT NULL,
  telefono VARCHAR(25) NOT NULL,
  personas TINYINT UNSIGNED NOT NULL,
  desde DATETIME NOT NULL,
  hasta DATETIME NOT NULL,
  estado ENUM('solicitada','confirmada','atendida','cancelada') NOT NULL DEFAULT 'solicitada',
  creada_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_reservacion_agenda (id_sucursal, desde, estado),
  KEY ix_reservacion_mesa (id_mesa, estado, desde, hasta),
  CONSTRAINT fk_reservacion_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_reservacion_mesa FOREIGN KEY (id_sucursal, id_mesa) REFERENCES mesa (id_sucursal, id),
  CONSTRAINT ck_reservacion_intervalo CHECK (hasta > desde AND personas > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permiso (clave, descripcion) VALUES
  ('reservaciones_opera', 'Administrar reservaciones de la sucursal'),
  ('reportes_restaurante', 'Consultar reportes del restaurante');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe
  WHERE p.clave IN ('administrador','gerente') AND pe.clave IN ('reservaciones_opera','reportes_restaurante');
