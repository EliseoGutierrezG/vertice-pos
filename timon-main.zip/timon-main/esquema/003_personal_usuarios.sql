-- =============================================================================
-- Plantilla base — 003 · Personal, usuarios, permisos y acceso
--
-- Todo usuario es una persona del personal con un puesto. Los permisos son los
-- del puesto; el alcance es su sucursal base más las que tenga asignadas en
-- `usuario_sucursal`. El administrador ve todas.
-- =============================================================================

SET NAMES utf8mb4;

CREATE TABLE puesto (
  id          TINYINT UNSIGNED NOT NULL,
  clave       VARCHAR(30)      NOT NULL,
  nombre      VARCHAR(60)      NOT NULL,
  usa_app     TINYINT(1)       NOT NULL DEFAULT 0 COMMENT '1 = opera con la app',
  id_estatus  TINYINT UNSIGNED NOT NULL DEFAULT 4,
  PRIMARY KEY (id),
  UNIQUE KEY uq_puesto_clave (clave),
  CONSTRAINT fk_puesto_estatus FOREIGN KEY (id_estatus) REFERENCES estatus (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE permiso (
  id           SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  clave        VARCHAR(60)       NOT NULL COMMENT 'modulo_accion, igual que el atributo #[Accion]',
  descripcion  VARCHAR(160)      NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_permiso_clave (clave)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE puesto_permiso (
  id_puesto   TINYINT UNSIGNED  NOT NULL,
  id_permiso  SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (id_puesto, id_permiso),
  KEY ix_puesto_permiso_permiso (id_permiso),
  CONSTRAINT fk_puesto_permiso_permiso FOREIGN KEY (id_permiso) REFERENCES permiso (id),
  CONSTRAINT fk_puesto_permiso_puesto  FOREIGN KEY (id_puesto)  REFERENCES puesto (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE personal (
  id                INT UNSIGNED      NOT NULL AUTO_INCREMENT,
  nombre            VARCHAR(80)       NOT NULL,
  apellido_paterno  VARCHAR(60)       NOT NULL,
  apellido_materno  VARCHAR(60)       DEFAULT NULL,
  id_puesto         TINYINT UNSIGNED  NOT NULL,
  id_sucursal       SMALLINT UNSIGNED DEFAULT NULL COMMENT 'Su sucursal base. NULL solo para el administrador, que ve todas',
  id_superior       INT UNSIGNED      DEFAULT NULL,
  telefono          VARCHAR(20)       DEFAULT NULL,
  correo            VARCHAR(160)      DEFAULT NULL,
  fecha_ingreso     DATE              NOT NULL,
  fecha_baja        DATE              DEFAULT NULL,
  id_estatus        TINYINT UNSIGNED  NOT NULL DEFAULT 4,
  creado_en         DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creado_por        INT UNSIGNED      DEFAULT NULL,
  anonimizado_en    DATETIME          DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_personal_puesto (id_puesto, id_estatus),
  KEY ix_personal_sucursal (id_sucursal, id_estatus),
  KEY ix_personal_superior (id_superior),
  KEY ix_personal_nombre (apellido_paterno, nombre),
  KEY ix_personal_estatus (id_estatus),
  CONSTRAINT fk_personal_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_personal_estatus  FOREIGN KEY (id_estatus)  REFERENCES estatus (id),
  CONSTRAINT fk_personal_puesto   FOREIGN KEY (id_puesto)   REFERENCES puesto (id),
  CONSTRAINT fk_personal_superior FOREIGN KEY (id_superior) REFERENCES personal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE usuario (
  id                    INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  id_personal           INT UNSIGNED     NOT NULL COMMENT 'Obligatorio y único: no hay usuario sin personal',
  usuario               VARCHAR(60)      NOT NULL,
  clave_hash            VARCHAR(255)     NOT NULL COMMENT 'password_hash(). Nunca en claro.',
  cambiar_clave         TINYINT(1)       NOT NULL DEFAULT 1 COMMENT 'La contraseña inicial es temporal: obliga a cambiarla',
  totp_secreto_cifrado  TEXT             DEFAULT NULL,
  totp_confirmado_en    DATETIME         DEFAULT NULL,
  totp_ultimo_periodo   BIGINT UNSIGNED  DEFAULT NULL,
  sesion_version        INT UNSIGNED     NOT NULL DEFAULT 1,
  id_estatus            TINYINT UNSIGNED NOT NULL DEFAULT 4,
  ultimo_acceso         DATETIME         DEFAULT NULL,
  creado_en             DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creado_por            INT UNSIGNED     DEFAULT NULL,
  acceso_hasta          DATETIME         DEFAULT NULL COMMENT 'Después de esta fecha la cuenta no entra. NULL: sin caducidad',
  acceso_motivo         VARCHAR(255)     DEFAULT NULL COMMENT 'Por qué se dio el acceso con caducidad',
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuario_usuario (usuario),
  UNIQUE KEY uq_usuario_personal (id_personal),
  KEY ix_usuario_estatus (id_estatus),
  CONSTRAINT fk_usuario_estatus  FOREIGN KEY (id_estatus)  REFERENCES estatus (id),
  CONSTRAINT fk_usuario_personal FOREIGN KEY (id_personal) REFERENCES personal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE usuario_sucursal (
  id_usuario   INT UNSIGNED      NOT NULL,
  id_sucursal  SMALLINT UNSIGNED NOT NULL,
  asignado_en  DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  asignado_por INT UNSIGNED      DEFAULT NULL,
  PRIMARY KEY (id_usuario, id_sucursal),
  KEY ix_usuario_sucursal_sucursal (id_sucursal),
  CONSTRAINT fk_usuario_sucursal_usuario  FOREIGN KEY (id_usuario)  REFERENCES usuario (id),
  CONSTRAINT fk_usuario_sucursal_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Sucursales adicionales que alcanza un usuario (gerentes de zona, cajeros que cubren otra).';

CREATE TABLE dispositivo (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario     INT UNSIGNED NOT NULL,
  identificador  VARCHAR(128) NOT NULL COMMENT 'Identificador que reporta la app',
  nombre         VARCHAR(80)  DEFAULT NULL,
  plataforma     VARCHAR(10)  DEFAULT NULL COMMENT 'android, ios o web',
  token_push     VARCHAR(255) DEFAULT NULL COMMENT 'Token de Expo Push; cambia cuando el equipo lo renueva',
  autorizado     TINYINT(1)   NOT NULL DEFAULT 0,
  autorizado_en  DATETIME     DEFAULT NULL,
  ultimo_acceso  DATETIME     DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_dispositivo_usuario_identificador (id_usuario, identificador),
  KEY ix_dispositivo_identificador (identificador),
  KEY ix_dispositivo_autorizado (autorizado),
  CONSTRAINT fk_dispositivo_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Pareja usuario-dispositivo. La fase 2 la convierte en equipos fijos por sucursal.';

CREATE TABLE token_acceso (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario      INT UNSIGNED NOT NULL,
  id_dispositivo  INT UNSIGNED NOT NULL,
  token_hash      CHAR(64)     NOT NULL COMMENT 'Se guarda el hash, jamás el token',
  creado_en       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expira_en       DATETIME     NOT NULL,
  revocado_en     DATETIME     DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_token_acceso_hash (token_hash),
  KEY ix_token_acceso_usuario (id_usuario),
  KEY ix_token_acceso_dispositivo (id_dispositivo),
  CONSTRAINT fk_token_acceso_dispositivo FOREIGN KEY (id_dispositivo) REFERENCES dispositivo (id),
  CONSTRAINT fk_token_acceso_usuario     FOREIGN KEY (id_usuario)     REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Autenticación de la app. La web usa sesión con CSRF.';

CREATE TABLE totp_codigo_recuperacion (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario   INT UNSIGNED    NOT NULL,
  codigo_hash  VARCHAR(255)    NOT NULL COMMENT 'password_hash(); el código en claro se muestra una vez',
  creado_en    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  usado_en     DATETIME        DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_totp_recuperacion_usuario (id_usuario, usado_en),
  CONSTRAINT fk_totp_recuperacion_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE intento_acceso (
  ambito           VARCHAR(24)       NOT NULL COMMENT 'entrada u otro límite',
  tipo             VARCHAR(16)       NOT NULL COMMENT 'cuenta_ip o ip',
  clave_hash       CHAR(64)          NOT NULL,
  ventana_desde    DATETIME          NOT NULL,
  intentos         SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  bloqueado_hasta  DATETIME          DEFAULT NULL,
  actualizado_en   DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (ambito, tipo, clave_hash),
  KEY ix_intento_acceso_purga (actualizado_en)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Límites de entrada sin identificadores en claro: solo hashes.';

CREATE TABLE revision_acceso (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  revisado_por  INT UNSIGNED NOT NULL,
  revisado_en   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  usuarios      INT UNSIGNED NOT NULL COMMENT 'Cuentas activas al revisar',
  conflictos    INT UNSIGNED NOT NULL COMMENT 'Separación de funciones al revisar',
  nota          VARCHAR(500) NOT NULL,
  PRIMARY KEY (id),
  KEY ix_revision_acceso_momento (revisado_en),
  CONSTRAINT fk_revision_acceso_usuario FOREIGN KEY (revisado_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
