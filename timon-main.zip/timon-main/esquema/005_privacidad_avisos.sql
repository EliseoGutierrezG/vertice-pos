-- =============================================================================
-- Plantilla base — 005 · Privacidad y avisos a equipos
-- =============================================================================

SET NAMES utf8mb4;

CREATE TABLE `solicitud_arco` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` varchar(15) NOT NULL,
  `titular_tipo` varchar(10) NOT NULL,
  `id_titular` int(10) unsigned DEFAULT NULL COMMENT 'cliente.id o personal.id; NULL si es otra persona',
  `solicitante` varchar(160) NOT NULL,
  `contacto` varchar(160) DEFAULT NULL,
  `detalle` varchar(500) NOT NULL,
  `recibida_en` date NOT NULL,
  `vence_en` date NOT NULL,
  `estado` varchar(10) NOT NULL DEFAULT 'abierta',
  `resolucion` varchar(500) DEFAULT NULL,
  `atendida_por` int(10) unsigned DEFAULT NULL,
  `atendida_en` datetime DEFAULT NULL,
  `registrada_por` int(10) unsigned NOT NULL,
  `registrada_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_solicitud_arco_estado` (`estado`,`vence_en`),
  KEY `fk_solicitud_arco_atendio` (`atendida_por`),
  KEY `fk_solicitud_arco_registro` (`registrada_por`),
  CONSTRAINT `fk_solicitud_arco_atendio` FOREIGN KEY (`atendida_por`) REFERENCES `usuario` (`id`),
  CONSTRAINT `fk_solicitud_arco_registro` FOREIGN KEY (`registrada_por`) REFERENCES `usuario` (`id`),
  CONSTRAINT `ck_solicitud_arco_tipo` CHECK (`tipo` in ('acceso','rectificacion','cancelacion','oposicion')),
  CONSTRAINT `ck_solicitud_arco_titular` CHECK (`titular_tipo` in ('cliente','empleado','otro')),
  CONSTRAINT `ck_solicitud_arco_estado` CHECK (`estado` in ('abierta','atendida','rechazada'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Solicitudes de derechos de acceso, rectificación, cancelación y oposición';

CREATE TABLE `aviso` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(80) NOT NULL,
  `cuerpo` varchar(255) NOT NULL,
  `destino_tipo` varchar(10) NOT NULL COMMENT 'persona, puesto, sucursal o todos',
  `destino_id` int(10) unsigned DEFAULT NULL,
  `destino_nombre` varchar(160) NOT NULL COMMENT 'Como se veía al enviar',
  `id_sucursal` smallint(5) unsigned DEFAULT NULL COMMENT 'Alcance de quien envió; NULL es todas',
  `personas` smallint(5) unsigned NOT NULL DEFAULT 0,
  `telefonos` smallint(5) unsigned NOT NULL DEFAULT 0,
  `aceptados` smallint(5) unsigned NOT NULL DEFAULT 0 COMMENT 'Los que Expo recibió',
  `fallidos` smallint(5) unsigned NOT NULL DEFAULT 0,
  `creado_por` int(10) unsigned NOT NULL,
  `creado_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_aviso_creado` (`creado_en`),
  KEY `ix_aviso_sucursal` (`id_sucursal`,`creado_en`),
  KEY `ix_aviso_usuario` (`creado_por`),
  CONSTRAINT `fk_aviso_sucursal` FOREIGN KEY (`id_sucursal`) REFERENCES `sucursal` (`id`),
  CONSTRAINT `fk_aviso_usuario` FOREIGN KEY (`creado_por`) REFERENCES `usuario` (`id`),
  CONSTRAINT `ck_aviso_destino` CHECK (`destino_tipo` in ('persona','puesto','sucursal','todos') and `destino_tipo` = 'todos' = (`destino_id` is null)),
  CONSTRAINT `ck_aviso_conteos` CHECK (`aceptados` + `fallidos` <= `telefonos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Un aviso del panel a varias personas. Cada teléfono tiene su notificacion.';

CREATE TABLE `notificacion` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(10) unsigned NOT NULL COMMENT 'Destinatario',
  `id_aviso` int(10) unsigned DEFAULT NULL,
  `id_dispositivo` int(10) unsigned DEFAULT NULL,
  `titulo` varchar(80) NOT NULL,
  `cuerpo` varchar(255) NOT NULL,
  `datos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`datos`)),
  `creado_en` datetime NOT NULL DEFAULT current_timestamp(),
  `creado_por` int(10) unsigned DEFAULT NULL,
  `enviado_en` datetime DEFAULT NULL,
  `error` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_notificacion_usuario` (`id_usuario`,`creado_en`),
  KEY `ix_notificacion_pendiente` (`enviado_en`,`id`),
  KEY `ix_notificacion_aviso` (`id_aviso`),
  KEY `ix_notificacion_dispositivo` (`id_dispositivo`),
  CONSTRAINT `fk_notificacion_aviso` FOREIGN KEY (`id_aviso`) REFERENCES `aviso` (`id`),
  CONSTRAINT `fk_notificacion_dispositivo` FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivo` (`id`),
  CONSTRAINT `fk_notificacion_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

