SET NAMES utf8mb4;

CREATE TABLE cuenta (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_mesa INT UNSIGNED DEFAULT NULL,
  id_mesero INT UNSIGNED NOT NULL,
  tipo ENUM('mesa','llevar','domicilio') NOT NULL,
  estado ENUM('ocupada','cuenta_pedida','pagada','cancelada','unida') NOT NULL DEFAULT 'ocupada',
  abierta TINYINT DEFAULT 1,
  version INT UNSIGNED NOT NULL DEFAULT 1,
  abierta_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cerrada_en DATETIME DEFAULT NULL,
  cliente VARCHAR(100) DEFAULT NULL,
  telefono VARCHAR(25) DEFAULT NULL,
  direccion VARCHAR(250) DEFAULT NULL,
  repartidor VARCHAR(100) DEFAULT NULL,
  entrega ENUM('recibido','preparando','listo','en_camino','entregado','cancelado') DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cuenta_mesa_abierta (id_mesa, abierta),
  UNIQUE KEY uq_cuenta_sucursal_id (id_sucursal, id),
  KEY ix_cuenta_sucursal_abierta (id_sucursal, abierta, id),
  CONSTRAINT fk_cuenta_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_cuenta_mesa FOREIGN KEY (id_sucursal, id_mesa) REFERENCES mesa (id_sucursal, id),
  CONSTRAINT fk_cuenta_mesero FOREIGN KEY (id_mesero) REFERENCES usuario (id),
  CONSTRAINT ck_cuenta_activa CHECK ((abierta = 1 AND estado IN ('ocupada','cuenta_pedida')) OR
    (abierta IS NULL AND estado IN ('pagada','cancelada','unida'))),
  CONSTRAINT ck_cuenta_tipo CHECK ((tipo = 'mesa') = (id_mesa IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Incluye la mesa principal. Así la unicidad también cubre la combinación
-- de mesa principal de una cuenta con mesa secundaria de otra.
CREATE TABLE cuenta_mesa (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_cuenta BIGINT UNSIGNED NOT NULL,
  id_mesa INT UNSIGNED NOT NULL,
  abierta TINYINT DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cuenta_mesa_activa (id_mesa, abierta),
  KEY ix_cuenta_mesa_cuenta (id_cuenta, abierta),
  CONSTRAINT fk_cuenta_mesa_cuenta FOREIGN KEY (id_sucursal, id_cuenta) REFERENCES cuenta (id_sucursal, id),
  CONSTRAINT fk_cuenta_mesa_mesa FOREIGN KEY (id_sucursal, id_mesa) REFERENCES mesa (id_sucursal, id),
  CONSTRAINT ck_cuenta_mesa_abierta CHECK (abierta IS NULL OR abierta = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ronda (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_cuenta BIGINT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  enviada_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_ronda_cuenta FOREIGN KEY (id_cuenta) REFERENCES cuenta (id),
  CONSTRAINT fk_ronda_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE cuenta_item (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_cuenta BIGINT UNSIGNED NOT NULL,
  id_ronda BIGINT UNSIGNED DEFAULT NULL,
  id_platillo INT UNSIGNED NOT NULL,
  platillo VARCHAR(100) NOT NULL,
  preparacion ENUM('caliente','fria','barra') NOT NULL,
  cantidad SMALLINT UNSIGNED NOT NULL,
  precio DECIMAL(10,2) UNSIGNED NOT NULL,
  modificadores JSON NOT NULL,
  nota VARCHAR(240) NOT NULL DEFAULT '',
  tiempo ENUM('entrada','fuerte') NOT NULL DEFAULT 'fuerte',
  asiento TINYINT UNSIGNED DEFAULT NULL,
  estado ENUM('capturado','enviado','en_preparacion','listo','entregado','cancelado') NOT NULL DEFAULT 'capturado',
  estado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  preparado_en DATETIME DEFAULT NULL,
  listo_en DATETIME DEFAULT NULL,
  cancelado_por INT UNSIGNED DEFAULT NULL,
  motivo VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_cuenta_item_cuenta (id_cuenta, estado),
  KEY ix_cuenta_item_ronda (id_ronda, preparacion, estado),
  CONSTRAINT fk_cuenta_item_cuenta FOREIGN KEY (id_cuenta) REFERENCES cuenta (id),
  CONSTRAINT fk_cuenta_item_ronda FOREIGN KEY (id_ronda) REFERENCES ronda (id),
  CONSTRAINT fk_cuenta_item_platillo FOREIGN KEY (id_platillo) REFERENCES platillo (id),
  CONSTRAINT fk_cuenta_item_cancela FOREIGN KEY (cancelado_por) REFERENCES usuario (id),
  CONSTRAINT ck_cuenta_item_cantidad CHECK (cantidad > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE evento_sucursal (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  tipo VARCHAR(32) NOT NULL,
  entidad BIGINT UNSIGNED NOT NULL,
  creado_en DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY ix_evento_sucursal_desde (id_sucursal, id),
  CONSTRAINT fk_evento_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE operacion_sincronizada
  ADD COLUMN huella CHAR(64) DEFAULT NULL,
  ADD COLUMN respuesta JSON DEFAULT NULL;
