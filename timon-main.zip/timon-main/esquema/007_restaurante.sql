-- Plano y catálogo. Las llaves compuestas impiden referencias a otra sucursal.
SET NAMES utf8mb4;

CREATE TABLE area (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_area_sucursal_nombre (id_sucursal, nombre),
  UNIQUE KEY uq_area_sucursal_id (id_sucursal, id),
  CONSTRAINT fk_area_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE mesa (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_area INT UNSIGNED NOT NULL,
  numero VARCHAR(20) NOT NULL,
  capacidad TINYINT UNSIGNED NOT NULL,
  forma ENUM('redonda','cuadrada','rectangular') NOT NULL DEFAULT 'cuadrada',
  x TINYINT UNSIGNED NOT NULL DEFAULT 0,
  y TINYINT UNSIGNED NOT NULL DEFAULT 0,
  estado ENUM('libre','por_limpiar','bloqueada') NOT NULL DEFAULT 'libre',
  PRIMARY KEY (id),
  UNIQUE KEY uq_mesa_sucursal_numero (id_sucursal, numero),
  UNIQUE KEY uq_mesa_sucursal_id (id_sucursal, id),
  CONSTRAINT fk_mesa_area FOREIGN KEY (id_sucursal, id_area) REFERENCES area (id_sucursal, id),
  CONSTRAINT ck_mesa_posicion CHECK (x <= 100 AND y <= 100 AND capacidad > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE categoria_menu (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(80) NOT NULL,
  orden SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_categoria_menu_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE platillo (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_categoria INT UNSIGNED NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  descripcion VARCHAR(400) NOT NULL DEFAULT '',
  foto VARCHAR(255) DEFAULT NULL,
  preparacion ENUM('caliente','fria','barra') NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  CONSTRAINT fk_platillo_categoria FOREIGN KEY (id_categoria) REFERENCES categoria_menu (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE platillo_sucursal (
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_platillo INT UNSIGNED NOT NULL,
  precio DECIMAL(10,2) UNSIGNED NOT NULL,
  agotado TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id_sucursal, id_platillo),
  CONSTRAINT fk_platillo_sucursal_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_platillo_sucursal_platillo FOREIGN KEY (id_platillo) REFERENCES platillo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE modificador_platillo (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_platillo INT UNSIGNED NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  suplemento DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_modificador_platillo_nombre (id_platillo, nombre),
  CONSTRAINT fk_modificador_platillo FOREIGN KEY (id_platillo) REFERENCES platillo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permiso (clave, descripcion) VALUES
  ('plano_ver', 'Ver el plano de mesas'),
  ('plano_admin', 'Administrar el plano de mesas'),
  ('menu_ver', 'Consultar platillos y disponibilidad'),
  ('menu_admin', 'Administrar el catálogo general de platillos'),
  ('menu_sucursal', 'Administrar los precios y agotados de la sucursal'),
  ('comanda_ver', 'Consultar las cuentas de la sucursal'),
  ('comanda_captura', 'Abrir cuentas y enviar comandas'),
  ('comanda_cobra', 'Cobrar cuentas y consultar caja'),
  ('cocina_opera', 'Operar la pantalla de cocina o barra');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT puesto.id, permiso.id FROM puesto CROSS JOIN permiso
  WHERE (
    (puesto.clave = 'administrador' AND permiso.clave IN
      ('plano_ver','plano_admin','menu_ver','menu_admin','menu_sucursal','comanda_ver','comanda_captura','comanda_cobra','cocina_opera'))
    OR (puesto.clave = 'gerente' AND permiso.clave IN
      ('plano_ver','plano_admin','menu_ver','menu_sucursal','comanda_ver','comanda_captura','comanda_cobra','cocina_opera'))
    OR (puesto.clave = 'mesero' AND permiso.clave IN ('plano_ver','menu_ver','comanda_ver','comanda_captura'))
    OR (puesto.clave = 'cajero' AND permiso.clave IN ('plano_ver','menu_ver','comanda_ver','comanda_captura','comanda_cobra'))
    OR (puesto.clave IN ('cocina','barra') AND permiso.clave IN ('menu_ver','cocina_opera'))
  );
