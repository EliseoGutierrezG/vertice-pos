-- =============================================================================
-- Plantilla base — 004 · Bitácora e idempotencia
--
-- La bitácora guarda qué había antes y qué quedó después; no se purga y se
-- sella por tramos. Las tres tablas de idempotencia evitan que un envío
-- repetido (doble clic, reintento por mala señal) se aplique dos veces.
-- =============================================================================

SET NAMES utf8mb4;

CREATE TABLE `bitacora` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `momento` datetime NOT NULL DEFAULT current_timestamp(),
  `modulo` varchar(40) NOT NULL,
  `accion` varchar(40) NOT NULL,
  `entidad` varchar(40) DEFAULT NULL,
  `id_entidad` bigint(20) unsigned DEFAULT NULL,
  `antes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`antes`)),
  `despues` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`despues`)),
  `ip` varchar(45) DEFAULT NULL,
  `canal` varchar(12) DEFAULT NULL COMMENT 'web, api, tarea o guion',
  `operacion` char(36) DEFAULT NULL COMMENT 'UUID compartida por todos los apuntes de la operación',
  `ruta` varchar(190) DEFAULT NULL,
  `accion_ruta` varchar(120) DEFAULT NULL,
  `id_dispositivo` int(10) unsigned DEFAULT NULL,
  `correlacion_hash` char(64) DEFAULT NULL COMMENT 'SHA-256 de la llave de idempotencia; nunca la llave en claro',
  PRIMARY KEY (`id`),
  KEY `ix_bitacora_momento` (`momento`),
  KEY `ix_bitacora_usuario` (`id_usuario`),
  KEY `ix_bitacora_entidad` (`entidad`,`id_entidad`),
  KEY `ix_bitacora_modulo` (`modulo`,`id`),
  KEY `ix_bitacora_canal` (`canal`,`id`),
  KEY `ix_bitacora_accion` (`accion`,`id`),
  KEY `ix_bitacora_operacion` (`operacion`,`id`),
  KEY `ix_bitacora_correlacion` (`correlacion_hash`),
  KEY `fk_bitacora_dispositivo` (`id_dispositivo`),
  CONSTRAINT `fk_bitacora_dispositivo` FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivo` (`id`),
  CONSTRAINT `fk_bitacora_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`),
  CONSTRAINT `ck_bitacora_canal` CHECK (`canal` is null or `canal` in ('web','api','tarea','guion'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Qué había antes y qué quedó después. No se purga.';

CREATE TABLE `bitacora_sello` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desde_id` bigint(20) unsigned NOT NULL,
  `hasta_id` bigint(20) unsigned NOT NULL,
  `renglones` int(10) unsigned NOT NULL,
  `huella` char(64) NOT NULL COMMENT 'HMAC-SHA256 del tramo, encadenado con el sello anterior',
  `huella_anterior` char(64) DEFAULT NULL,
  `sellado_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bitacora_sello_hasta` (`hasta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Un renglón por tramo sellado. Lo escribe y lo verifica guiones/mantenimiento.php.';

CREATE TABLE `operacion_panel` (
  `llave_idempotencia` char(36) NOT NULL,
  `tipo` varchar(30) NOT NULL COMMENT 'baja, arma o desarma',
  `id_usuario` int(10) unsigned NOT NULL,
  `resultado` varchar(40) NOT NULL COMMENT 'Lo que se devolvió: folio o id',
  `procesada_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`llave_idempotencia`),
  KEY `ix_operacion_panel_usuario` (`id_usuario`,`procesada_en`),
  CONSTRAINT `fk_operacion_panel_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Un envío del panel repetido no mueve el inventario dos veces.';

CREATE TABLE `envio_panel` (
  `llave` char(36) NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL,
  `ruta` varchar(190) NOT NULL COMMENT 'Método y ruta: POST /pedidos',
  `estado` enum('en_curso','hecho') NOT NULL DEFAULT 'en_curso',
  `codigo_http` smallint(5) unsigned DEFAULT NULL,
  `redirige` varchar(255) DEFAULT NULL COMMENT 'A dónde se mandó a la persona; NULL si no hubo destino',
  `aviso` varchar(255) DEFAULT NULL,
  `tono` varchar(12) DEFAULT NULL,
  `creada_en` datetime NOT NULL DEFAULT current_timestamp(),
  `terminada_en` datetime DEFAULT NULL,
  PRIMARY KEY (`llave`),
  KEY `ix_envio_panel_creada` (`creada_en`),
  KEY `ix_envio_panel_usuario` (`id_usuario`,`creada_en`),
  CONSTRAINT `fk_envio_panel_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Un envío del panel repetido se contesta igual y no se vuelve a hacer.';

CREATE TABLE `operacion_sincronizada` (
  `llave_idempotencia` char(36) NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL,
  `tipo` varchar(30) NOT NULL,
  `id_resultado` bigint(20) unsigned DEFAULT NULL COMMENT 'Id de lo que se creó, para devolver lo mismo si reintenta',
  `procesada_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`llave_idempotencia`),
  KEY `ix_operacion_usuario` (`id_usuario`,`procesada_en`),
  CONSTRAINT `fk_operacion_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Una operación reintentada no se aplica dos veces.';

