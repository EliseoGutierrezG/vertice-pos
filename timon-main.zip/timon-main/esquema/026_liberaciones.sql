SET NAMES utf8mb4;

-- Actualizaciones de las computadoras de sucursal (docs/servidor-sucursal.md).
--
-- El central guarda los paquetes firmados del sistema y a cuál debe llegar
-- cada computadora. La computadora lo pregunta, lo baja, comprueba la firma
-- con la llave pública que ya trae y lo instala cuando no hay cuentas ni turno
-- abiertos. El central nunca empuja nada: no necesita entrar al local.
CREATE TABLE liberacion (
  id VARCHAR(100) NOT NULL COMMENT 'El id de config/liberacion.php del paquete',
  esquema SMALLINT UNSIGNED NOT NULL COMMENT 'Último guion de esquema que trae',
  sha256 CHAR(64) NOT NULL,
  firma VARCHAR(100) NOT NULL COMMENT 'Ed25519 en base64 sobre id, esquema y sha256',
  peso BIGINT UNSIGNED NOT NULL,
  notas VARCHAR(300) NOT NULL DEFAULT '',
  creada_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creada_por INT UNSIGNED DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_liberacion_sha256 (sha256),
  CONSTRAINT fk_liberacion_usuario FOREIGN KEY (creada_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- `version` (guion 025) sigue siendo la liberación que la computadora reporta
-- en cada contacto; aquí va la que debe tener y cómo va su actualización.
ALTER TABLE instalacion
  ADD COLUMN liberacion_asignada VARCHAR(100) DEFAULT NULL COMMENT 'La versión que debe instalar; null es quedarse como está',
  ADD COLUMN actualizacion VARCHAR(200) NOT NULL DEFAULT '' COMMENT 'Lo último que reportó su actualizador',
  ADD COLUMN actualizacion_error TINYINT UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN actualizada_en DATETIME DEFAULT NULL,
  ADD CONSTRAINT fk_instalacion_liberacion FOREIGN KEY (liberacion_asignada) REFERENCES liberacion (id);
