SET NAMES utf8mb4;

CREATE TABLE impresora (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  puerto SMALLINT UNSIGNED NOT NULL DEFAULT 9100,
  ancho ENUM('58','80') NOT NULL DEFAULT '80',
  destino ENUM('caliente','fria','barra','caja') NOT NULL,
  activa TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_impresora_destino (id_sucursal, destino),
  UNIQUE KEY uq_impresora_sucursal_id (id_sucursal, id),
  CONSTRAINT fk_impresora_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE trabajo_impresion (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_impresora INT UNSIGNED NOT NULL,
  tipo ENUM('comanda','precuenta','ticket','corte') NOT NULL,
  entidad BIGINT UNSIGNED NOT NULL,
  contenido TEXT NOT NULL,
  estado ENUM('pendiente','enviado','impreso','fallido') NOT NULL DEFAULT 'pendiente',
  id_equipo INT UNSIGNED DEFAULT NULL,
  arrendado_hasta DATETIME DEFAULT NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  terminado_en DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_impresion_pendiente (id_sucursal, estado, id),
  CONSTRAINT fk_impresion_impresora FOREIGN KEY (id_sucursal, id_impresora) REFERENCES impresora (id_sucursal, id),
  CONSTRAINT fk_impresion_equipo FOREIGN KEY (id_equipo) REFERENCES equipo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE turno_caja (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_cajero INT UNSIGNED NOT NULL,
  abierto TINYINT DEFAULT 1,
  fondo DECIMAL(12,2) UNSIGNED NOT NULL,
  abierto_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cerrado_en DATETIME DEFAULT NULL,
  efectivo_declarado DECIMAL(12,2) UNSIGNED DEFAULT NULL,
  efectivo_esperado DECIMAL(12,2) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_turno_sucursal_abierto (id_sucursal, abierto),
  CONSTRAINT fk_turno_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_turno_cajero FOREIGN KEY (id_cajero) REFERENCES usuario (id),
  CONSTRAINT ck_turno_abierto CHECK (abierto IS NULL OR abierto = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE pago_cuenta (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_cuenta BIGINT UNSIGNED NOT NULL,
  id_turno BIGINT UNSIGNED NOT NULL,
  id_cajero INT UNSIGNED NOT NULL,
  total DECIMAL(12,2) UNSIGNED NOT NULL,
  propina DECIMAL(12,2) UNSIGNED NOT NULL,
  descuento DECIMAL(12,2) UNSIGNED NOT NULL DEFAULT 0,
  descuento_autorizado_por INT UNSIGNED DEFAULT NULL,
  token_publico CHAR(32) NOT NULL,
  pagado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_pago_cuenta (id_cuenta),
  UNIQUE KEY uq_pago_token (token_publico),
  KEY ix_pago_turno (id_turno),
  CONSTRAINT fk_pago_cuenta FOREIGN KEY (id_cuenta) REFERENCES cuenta (id),
  CONSTRAINT fk_pago_turno FOREIGN KEY (id_turno) REFERENCES turno_caja (id),
  CONSTRAINT fk_pago_cajero FOREIGN KEY (id_cajero) REFERENCES usuario (id),
  CONSTRAINT fk_pago_autoriza FOREIGN KEY (descuento_autorizado_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE pago_cuenta_forma (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_pago BIGINT UNSIGNED NOT NULL,
  medio ENUM('efectivo','tarjeta','transferencia') NOT NULL,
  importe DECIMAL(12,2) UNSIGNED NOT NULL,
  referencia VARCHAR(80) DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_pago_forma FOREIGN KEY (id_pago) REFERENCES pago_cuenta (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE asiento_caja (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_turno BIGINT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  concepto VARCHAR(120) NOT NULL,
  importe DECIMAL(12,2) NOT NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_asiento_turno FOREIGN KEY (id_turno) REFERENCES turno_caja (id),
  CONSTRAINT fk_asiento_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
