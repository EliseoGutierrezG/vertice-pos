SET NAMES utf8mb4;

ALTER TABLE pago_cuenta ADD KEY ix_pago_fecha (pagado_en, id_cuenta);
ALTER TABLE trabajo_impresion
  ADD COLUMN id_original BIGINT UNSIGNED DEFAULT NULL,
  ADD KEY ix_impresion_original (id_original, estado),
  ADD CONSTRAINT fk_impresion_original FOREIGN KEY (id_original) REFERENCES trabajo_impresion (id);
