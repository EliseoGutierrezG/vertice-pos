SET NAMES utf8mb4;

-- La carta impresa se arma con el panel: leyenda por categoría, porción y
-- orden de cada platillo (la carta no va en orden alfabético).
ALTER TABLE categoria_menu ADD COLUMN descripcion VARCHAR(300) NOT NULL DEFAULT '';
ALTER TABLE platillo
  ADD COLUMN porcion VARCHAR(40) NOT NULL DEFAULT '',
  ADD COLUMN orden SMALLINT UNSIGNED NOT NULL DEFAULT 0;

-- Promociones por platillo. Se aplican solas al capturar: porcentaje, precio
-- especial o N×M (lleva N, paga M), con fechas, días y horario.
CREATE TABLE promocion (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(80) NOT NULL,
  tipo ENUM('porcentaje','precio','nxm') NOT NULL,
  valor DECIMAL(10,2) UNSIGNED DEFAULT NULL COMMENT 'Porcentaje de 1 a 90 o precio especial',
  lleva TINYINT UNSIGNED DEFAULT NULL,
  paga TINYINT UNSIGNED DEFAULT NULL,
  desde DATE NOT NULL,
  hasta DATE DEFAULT NULL,
  dias TINYINT UNSIGNED NOT NULL DEFAULT 127 COMMENT 'Máscara: lunes = 1, martes = 2 … domingo = 64',
  hora_inicio TIME DEFAULT NULL,
  hora_fin TIME DEFAULT NULL,
  activa TINYINT UNSIGNED NOT NULL DEFAULT 1,
  baja TINYINT UNSIGNED NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creado_por INT UNSIGNED DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_promocion_vigencia (desde, hasta),
  CONSTRAINT ck_promocion_dias CHECK (dias BETWEEN 1 AND 127),
  CONSTRAINT ck_promocion_fechas CHECK (hasta IS NULL OR hasta >= desde),
  CONSTRAINT ck_promocion_nxm CHECK (tipo <> 'nxm' OR (lleva BETWEEN 2 AND 10 AND paga BETWEEN 1 AND lleva - 1)),
  CONSTRAINT ck_promocion_valor CHECK (tipo = 'nxm' OR valor > 0),
  CONSTRAINT ck_promocion_horario CHECK ((hora_inicio IS NULL) = (hora_fin IS NULL)),
  CONSTRAINT fk_promocion_usuario FOREIGN KEY (creado_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE promocion_sucursal (
  id_promocion INT UNSIGNED NOT NULL,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (id_promocion, id_sucursal),
  KEY ix_promocion_sucursal (id_sucursal),
  CONSTRAINT fk_promo_suc_promocion FOREIGN KEY (id_promocion) REFERENCES promocion (id),
  CONSTRAINT fk_promo_suc_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE promocion_platillo (
  id_promocion INT UNSIGNED NOT NULL,
  id_platillo INT UNSIGNED NOT NULL,
  PRIMARY KEY (id_promocion, id_platillo),
  KEY ix_promocion_platillo (id_platillo),
  CONSTRAINT fk_promo_pla_promocion FOREIGN KEY (id_promocion) REFERENCES promocion (id),
  CONSTRAINT fk_promo_pla_platillo FOREIGN KEY (id_platillo) REFERENCES platillo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- El renglón guarda la promoción con la que se capturó y lo que rebaja. El
-- precio sigue siendo el de lista más suplementos; el importe es
-- cantidad × precio − descuento.
ALTER TABLE cuenta_item
  ADD COLUMN id_promocion INT UNSIGNED DEFAULT NULL,
  ADD COLUMN promocion VARCHAR(80) NOT NULL DEFAULT '',
  ADD COLUMN descuento DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0,
  ADD KEY ix_cuenta_item_promocion (id_promocion),
  ADD CONSTRAINT fk_cuenta_item_promocion FOREIGN KEY (id_promocion) REFERENCES promocion (id);

INSERT INTO permiso (clave, descripcion) VALUES
  ('promocion_admin', 'Crear, pausar y dar de baja promociones de platillos');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe
  WHERE p.clave IN ('administrador','gerente') AND pe.clave = 'promocion_admin';

-- Los textos fijos de la carta impresa. Se cambian desde la pantalla Carta.
INSERT INTO parametro (clave, valor, descripcion, vigente_desde) VALUES
  ('carta_fundacion', '2020', 'Año de fundación que muestra la carta', '2026-01-01'),
  ('carta_sello', 'Sabor único', 'Frase destacada del encabezado de la carta', '2026-01-01'),
  ('carta_lema', 'Calidad • Calidez • Sabor • Frescura', 'Lema del pie de la carta', '2026-01-01'),
  ('carta_advertencia', 'Los alimentos crudos o poco cocidos incrementan el riesgo de intoxicaciones e infecciones en personas sensibles al consumo. Es responsabilidad de quien lo pide.', 'Advertencia sanitaria del pie de la carta', '2026-01-01'),
  ('carta_pagos', 'Aceptamos pagos en efectivo, tarjeta Visa, Mastercard y American Express.', 'Formas de pago del pie de la carta', '2026-01-01');
