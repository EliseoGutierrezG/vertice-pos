SET NAMES utf8mb4;

CREATE TABLE insumo (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  unidad VARCHAR(20) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_insumo_nombre (id_sucursal, nombre),
  UNIQUE KEY uq_insumo_sucursal_id (id_sucursal, id),
  CONSTRAINT fk_insumo_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE proveedor (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  contacto VARCHAR(100) NOT NULL DEFAULT '',
  PRIMARY KEY (id),
  UNIQUE KEY uq_proveedor_nombre (id_sucursal, nombre),
  UNIQUE KEY uq_proveedor_sucursal_id (id_sucursal, id),
  CONSTRAINT fk_proveedor_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE compra_insumo (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_proveedor INT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  referencia VARCHAR(80) NOT NULL,
  estado ENUM('ordenada','recibida','cancelada') NOT NULL DEFAULT 'ordenada',
  creada_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  recibida_en DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_compra_sucursal (id_sucursal, id),
  CONSTRAINT fk_compra_proveedor FOREIGN KEY (id_sucursal, id_proveedor) REFERENCES proveedor (id_sucursal, id),
  CONSTRAINT fk_compra_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE compra_insumo_linea (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_compra BIGINT UNSIGNED NOT NULL,
  id_insumo INT UNSIGNED NOT NULL,
  cantidad DECIMAL(12,3) UNSIGNED NOT NULL,
  costo DECIMAL(10,2) UNSIGNED NOT NULL,
  vence DATE DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_compra_linea_compra FOREIGN KEY (id_compra) REFERENCES compra_insumo (id),
  CONSTRAINT fk_compra_linea_insumo FOREIGN KEY (id_insumo) REFERENCES insumo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE lote_insumo (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_insumo INT UNSIGNED NOT NULL,
  id_compra_linea BIGINT UNSIGNED DEFAULT NULL,
  vence DATE DEFAULT NULL,
  saldo DECIMAL(12,3) UNSIGNED NOT NULL,
  costo DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_lote_compra_linea (id_compra_linea),
  KEY ix_lote_insumo_vence (id_insumo, vence, id),
  CONSTRAINT fk_lote_insumo FOREIGN KEY (id_insumo) REFERENCES insumo (id),
  CONSTRAINT fk_lote_compra_linea FOREIGN KEY (id_compra_linea) REFERENCES compra_insumo_linea (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE receta_insumo (
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_platillo INT UNSIGNED NOT NULL,
  id_insumo INT UNSIGNED NOT NULL,
  cantidad DECIMAL(10,3) UNSIGNED NOT NULL,
  PRIMARY KEY (id_sucursal, id_platillo, id_insumo),
  CONSTRAINT fk_receta_insumo FOREIGN KEY (id_sucursal, id_insumo) REFERENCES insumo (id_sucursal, id),
  CONSTRAINT fk_receta_platillo FOREIGN KEY (id_platillo) REFERENCES platillo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE kardex_insumo (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_lote BIGINT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  id_cuenta BIGINT UNSIGNED DEFAULT NULL,
  tipo ENUM('entrada','consumo','merma','conteo') NOT NULL,
  cantidad DECIMAL(12,3) NOT NULL,
  motivo VARCHAR(160) NOT NULL DEFAULT '',
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_kardex_fecha (creado_en, id),
  CONSTRAINT fk_kardex_lote FOREIGN KEY (id_lote) REFERENCES lote_insumo (id),
  CONSTRAINT fk_kardex_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id),
  CONSTRAINT fk_kardex_cuenta FOREIGN KEY (id_cuenta) REFERENCES cuenta (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE gasto_sucursal (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_proveedor INT UNSIGNED DEFAULT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  id_asiento BIGINT UNSIGNED DEFAULT NULL,
  concepto VARCHAR(120) NOT NULL,
  importe DECIMAL(10,2) UNSIGNED NOT NULL,
  comprobante VARCHAR(200) NOT NULL DEFAULT '',
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_gasto_sucursal_fecha (id_sucursal, creado_en),
  CONSTRAINT fk_gasto_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_gasto_proveedor FOREIGN KEY (id_sucursal, id_proveedor) REFERENCES proveedor (id_sucursal, id),
  CONSTRAINT fk_gasto_asiento FOREIGN KEY (id_asiento) REFERENCES asiento_caja (id),
  CONSTRAINT fk_gasto_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permiso (clave, descripcion) VALUES
  ('inventario_opera', 'Administrar insumos, compras, recetas y mermas'),
  ('gastos_opera', 'Registrar y consultar gastos');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe WHERE
    (p.clave IN ('administrador','gerente','almacen') AND pe.clave = 'inventario_opera')
    OR (p.clave IN ('administrador','gerente','cajero') AND pe.clave = 'gastos_opera');
