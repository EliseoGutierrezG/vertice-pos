SET NAMES utf8mb4;

-- La lista de liberaciones cuenta las computadoras que ya tienen cada versión.
-- Es aditivo: el código anterior sigue funcionando y permite regresar.
CREATE INDEX ix_instalacion_version_activa ON instalacion (version, activa);
