<?php
declare(strict_types=1);

namespace Modelos;

use Nucleo\BaseDatos;

/**
 * Los tokens de la app.
 *
 * Se guarda el **hash** del token, nunca el token. Si alguien se lleva la
 * tabla, no se lleva con qué entrar. El token en claro existe una sola vez,
 * en la respuesta al acceso, y de ahí sólo lo tiene el teléfono.
 */
final class Tokens
{
    /** Un mes. La app de campo no debería pedir contraseña todos los días. */
    private const DIAS_DE_VIDA = 14;

    /** Se renueva a lo más una vez al día: no hace falta una escritura por petición. */
    private const DIAS_ANTES_DE_RENOVAR = 13;

    public function __construct(private BaseDatos $bd)
    {
    }

    /** Devuelve el token en claro. Es la única vez que existe. */
    public function emite(int $idUsuario, int $idDispositivo): string
    {
        $token = bin2hex(random_bytes(32));

        $this->bd->inserta(
            'INSERT INTO token_acceso (id_usuario, id_dispositivo, token_hash, expira_en)
             VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? DAY))',
            [$idUsuario, $idDispositivo, $this->hash($token), self::DIAS_DE_VIDA]
        );

        return $token;
    }

    /**
     * Devuelve a quién pertenece el token, o null si no vale.
     *
     * Un token vencido o revocado no vale, y tampoco vale el de un usuario
     * que ya se desactivó: se comprueba aquí y no en tres sitios distintos.
     *
     * @return array<string,mixed>|null
     */
    public function resuelve(string $token): ?array
    {
        $acceso = $this->bd->fila(
            'SELECT t.id, t.id_usuario, t.id_dispositivo, t.expira_en,
                    d.autorizado, d.identificador
             FROM token_acceso t
             JOIN dispositivo d ON d.id = t.id_dispositivo AND d.id_usuario = t.id_usuario
             JOIN usuario u     ON u.id = t.id_usuario AND u.id_estatus = 4
             WHERE t.token_hash = ?
               AND t.revocado_en IS NULL
               AND t.expira_en > NOW()',
            [$this->hash($token)]
        );

        if ($acceso !== null) {
            // Dura 14 días desde el último uso: quien trabaja a diario no vuelve a
            // escribir su contraseña, y un teléfono olvidado deja de valer solo.
            // Un token emitido antes con más días no se acorta.
            $this->bd->ejecuta(
                'UPDATE token_acceso SET expira_en = DATE_ADD(NOW(), INTERVAL ? DAY)
                 WHERE id = ? AND expira_en < DATE_ADD(NOW(), INTERVAL ? DAY)',
                [self::DIAS_DE_VIDA, (int) $acceso['id'], self::DIAS_ANTES_DE_RENOVAR]
            );
        }

        return $acceso;
    }

    /**
     * Revoca el token y devuelve de quién era, para la bitácora. Un token
     * desconocido o ya revocado devuelve null.
     *
     * @return array{id_usuario:int,id_dispositivo:int}|null
     */
    public function revoca(string $token): ?array
    {
        $fila = $this->bd->fila(
            'SELECT id, id_usuario, id_dispositivo FROM token_acceso WHERE token_hash = ? AND revocado_en IS NULL FOR UPDATE',
            [$this->hash($token)]
        );
        if ($fila === null) return null;
        $this->bd->ejecuta('UPDATE token_acceso SET revocado_en = NOW() WHERE id = ?', [(int) $fila['id']]);
        return ['id_usuario' => (int) $fila['id_usuario'], 'id_dispositivo' => (int) $fila['id_dispositivo']];
    }

    /** Limpieza: los que ya no sirven no tienen por qué seguir ahí. */
    public function purga(): int
    {
        return $this->bd->ejecuta(
            'DELETE FROM token_acceso
             WHERE expira_en < DATE_SUB(NOW(), INTERVAL 30 DAY)
                OR revocado_en < DATE_SUB(NOW(), INTERVAL 30 DAY)'
        );
    }

    private function hash(string $token): string
    {
        return hash('sha256', $token);
    }
}
