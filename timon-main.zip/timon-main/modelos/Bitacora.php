<?php
declare(strict_types=1);

namespace Modelos;

use Nucleo\BaseDatos;

/**
 * La bitácora, para leerla.
 *
 * Quien la **escribe** es `Nucleo\Bitacora`, dentro de la transacción de cada
 * cambio. Aquí sólo se consulta: este archivo no tiene un solo `INSERT`, y es a
 * propósito. Una bitácora que se puede editar desde la aplicación no sirve para
 * contestar «¿quién movió esto?», que es lo único para lo que existe
 * (respuesta 9.3 del cuestionario).
 *
 * **Se pagina por id, no por `OFFSET`.** Es la tabla que crece con cada acción
 * de cada usuario: será la más grande del sistema mucho antes que `movimiento`.
 * `LIMIT 50 OFFSET 40000` obliga a la base a recorrer y tirar cuarenta mil
 * renglones cada vez que alguien pasa de página; `WHERE id < ?` entra por el
 * índice y lee cincuenta. Con la bitácora de un mes da igual; con la de tres
 * años, no.
 */
final class Bitacora
{
    /** Cuántos apuntes por página. */
    public const POR_PAGINA = 50;

    public function __construct(private BaseDatos $bd)
    {
    }

    /**
     * Los apuntes, del más reciente al más viejo.
     *
     * @param array<string,mixed> $filtros canal, modulo, accion, id_usuario, entidad,
     *        identificador, operacion, desde, hasta, antes_de
     * @return array{apuntes: list<array<string,mixed>>, hay_mas: bool, ultimo: int}
     */
    public function apuntes(array $filtros = [], int $porPagina = self::POR_PAGINA): array
    {
        [$donde, $valores] = $this->condiciones($filtros);
        // Una fila extra indica que existe otra página.
        $valores[] = $porPagina + 1;

        $filas = $this->bd->filas(
            'SELECT b.id, b.momento, b.modulo, b.accion, b.entidad, b.id_entidad,
                    b.antes, b.despues, b.ip, b.canal, b.operacion, b.ruta,
                    b.accion_ruta, b.id_dispositivo, b.correlacion_hash,
                    CONCAT(p.nombre, \' \', p.apellido_paterno) AS usuario
             FROM bitacora b
             LEFT JOIN usuario u  ON u.id = b.id_usuario
             LEFT JOIN personal p ON p.id = u.id_personal
             WHERE ' . implode(' AND ', $donde) . '
             ORDER BY b.id DESC
             LIMIT ?',
            $valores
        );

        $hayMas = count($filas) > $porPagina;
        $filas  = array_slice($filas, 0, $porPagina);

        return [
            'apuntes' => $filas,
            'hay_mas' => $hayMas,
            'ultimo'  => $filas === [] ? 0 : (int) $filas[count($filas) - 1]['id'],
        ];
    }

    public function total(array $filtros): int
    {
        unset($filtros['antes_de']);
        [$donde, $valores] = $this->condiciones($filtros);
        return (int) $this->bd->valor('SELECT COUNT(*) FROM bitacora b WHERE ' . implode(' AND ', $donde), $valores);
    }

    private function condiciones(array $filtros): array
    {
        $donde  = ['1 = 1'];
        $valores = [];

        if (($filtros['modulo'] ?? '') !== '') {
            $donde[]   = 'b.modulo = ?';
            $valores[] = (string) $filtros['modulo'];
        }

        if (($filtros['canal'] ?? '') !== '') {
            $donde[]   = 'b.canal = ?';
            $valores[] = (string) $filtros['canal'];
        }

        if (($filtros['accion'] ?? '') !== '') {
            $donde[]   = 'b.accion = ?';
            $valores[] = (string) $filtros['accion'];
        }

        if ((int) ($filtros['id_usuario'] ?? 0) > 0) {
            $donde[]   = 'b.id_usuario = ?';
            $valores[] = (int) $filtros['id_usuario'];
        }

        // El id sólo significa algo junto con su entidad: el pedido 15 y el
        // producto 15 no tienen nada que ver. Por eso se filtra en pareja, que
        // además es como entra el índice `(entidad, id_entidad)`; un id suelto
        // obligaría a leer la bitácora entera.
        if (($filtros['entidad'] ?? '') !== '' && (int) ($filtros['identificador'] ?? 0) > 0) {
            $donde[]   = 'b.entidad = ? AND b.id_entidad = ?';
            $valores[] = (string) $filtros['entidad'];
            $valores[] = (int) $filtros['identificador'];
        } elseif (($filtros['entidad'] ?? '') !== '') {
            $donde[]   = 'b.entidad = ?';
            $valores[] = (string) $filtros['entidad'];
        }

        if (($filtros['operacion'] ?? '') !== '') {
            $donde[]   = 'b.operacion = ?';
            $valores[] = (string) $filtros['operacion'];
        }

        if (($filtros['desde'] ?? '') !== '') {
            $donde[]   = 'b.momento >= ?';
            $valores[] = (string) $filtros['desde'] . ' 00:00:00';
        }

        if (($filtros['hasta'] ?? '') !== '') {
            $donde[]   = 'b.momento <= ?';
            $valores[] = (string) $filtros['hasta'] . ' 23:59:59';
        }

        // La llave de la paginación: «lo anterior a este apunte».
        if ((int) ($filtros['antes_de'] ?? 0) > 0) {
            $donde[]   = 'b.id < ?';
            $valores[] = (int) $filtros['antes_de'];
        }

        return [$donde, $valores];
    }

    /**
     * Recorre el resultado completo con paginación por llave, sin OFFSET ni
     * cargar toda la bitácora en memoria.
     *
     * @param array<string,mixed> $filtros
     * @return \Generator<int,array<string,mixed>>
     */
    public function recorre(array $filtros): \Generator
    {
        unset($filtros['antes_de']);
        do {
            $pagina = $this->apuntes($filtros, 500);
            foreach ($pagina['apuntes'] as $apunte) {
                yield $apunte;
            }
            $filtros['antes_de'] = $pagina['ultimo'];
        } while ($pagina['hay_mas']);
    }

    /** Un apunte completo, para su Ver (ficha 43). @return array<string,mixed>|null */
    public function apunte(int $id): ?array
    {
        return $this->bd->fila(
            'SELECT b.id, b.momento, b.modulo, b.accion, b.entidad, b.id_entidad,
                    b.antes, b.despues, b.ip, b.canal, b.operacion, b.ruta,
                    b.accion_ruta, b.id_dispositivo, b.correlacion_hash,
                    CONCAT(p.nombre, \' \', p.apellido_paterno) AS usuario
             FROM bitacora b
             LEFT JOIN usuario u  ON u.id = b.id_usuario
             LEFT JOIN personal p ON p.id = u.id_personal
             WHERE b.id = ?',
            [$id]
        );
    }

    /** Los módulos que han dejado apuntes, para el filtro. @return list<string> */
    public function modulos(): array
    {
        return array_map(
            static fn (array $f): string => (string) $f['modulo'],
            $this->bd->filas('SELECT DISTINCT modulo FROM bitacora ORDER BY modulo')
        );
    }

    /** @return list<string> */
    public function acciones(): array
    {
        return array_map(
            static fn (array $f): string => (string) $f['accion'],
            $this->bd->filas('SELECT DISTINCT accion FROM bitacora ORDER BY accion')
        );
    }

    /** @return list<string> */
    public function entidades(): array
    {
        return array_map(
            static fn (array $f): string => (string) $f['entidad'],
            $this->bd->filas('SELECT DISTINCT entidad FROM bitacora WHERE entidad IS NOT NULL ORDER BY entidad')
        );
    }

    /** Quiénes han dejado apuntes, para el filtro. @return list<array<string,mixed>> */
    public function quienes(): array
    {
        return $this->bd->filas(
            "SELECT DISTINCT u.id, CONCAT(p.nombre, ' ', p.apellido_paterno) AS nombre
             FROM bitacora b
             JOIN usuario u  ON u.id = b.id_usuario
             JOIN personal p ON p.id = u.id_personal
             ORDER BY nombre"
        );
    }

    /**
     * Todo lo que se hizo sobre una cosa, del principio al fin.
     *
     * Al revés que la lista: aquí se lee hacia adelante, porque lo que se quiere
     * es la historia de ese pedido o de ese producto.
     *
     * @return list<array<string,mixed>>
     */
    public function historiaDe(string $entidad, int $id): array
    {
        return $this->bd->filas(
            'SELECT b.id, b.momento, b.modulo, b.accion, b.antes, b.despues,
                    b.canal, b.operacion, b.ruta, b.accion_ruta, b.id_dispositivo,
                    CONCAT(p.nombre, \' \', p.apellido_paterno) AS usuario
             FROM bitacora b
             LEFT JOIN usuario u  ON u.id = b.id_usuario
             LEFT JOIN personal p ON p.id = u.id_personal
             WHERE b.entidad = ? AND b.id_entidad = ?
             ORDER BY b.id',
            [$entidad, $id]
        );
    }

    /**
     * Los nombres de los ids que traen los apuntes: una «Sucursal 3» o un
     * «Estatus 5» no le dicen nada a quien revisa.
     *
     * @param list<array<string,mixed>> $apuntes
     * @return array<string,array<int,string>> Por campo sin el `id_`, y por id.
     */
    public function nombresDe(array $apuntes): array
    {
        $fuentes = [
            'sucursal' => 'SELECT id, nombre FROM sucursal',
            'estatus' => 'SELECT id, nombre FROM estatus',
            'puesto' => 'SELECT id, nombre FROM puesto',
            'usuario' => 'SELECT id, usuario AS nombre FROM usuario',
        ];
        $ids = [];
        foreach ($apuntes as $apunte) {
            foreach (['antes', 'despues'] as $lado) {
                $datos = json_decode((string) ($apunte[$lado] ?? ''), true);
                if (!is_array($datos)) continue;
                foreach ($datos as $campo => $valor) {
                    $clave = preg_replace('/^id_/', '', (string) $campo);
                    if (isset($fuentes[$clave]) && is_numeric($valor)) $ids[$clave][(int) $valor] = (int) $valor;
                }
            }
        }
        $nombres = [];
        foreach ($ids as $clave => $lista) {
            $lista = array_values($lista);
            $marcas = implode(',', array_fill(0, count($lista), '?'));
            foreach ($this->bd->filas($fuentes[$clave] . ' WHERE id IN (' . $marcas . ')', $lista) as $fila) {
                $nombres[$clave][(int) $fila['id']] = (string) $fila['nombre'];
            }
        }
        return $nombres;
    }
}
