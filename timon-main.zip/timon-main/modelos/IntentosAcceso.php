<?php
declare(strict_types=1);

namespace Modelos;

use Nucleo\BaseDatos;

/** Límite persistente compartido por web, API y autorizaciones puntuales. */
final class IntentosAcceso
{
    private const VENTANA_MINUTOS = 15;
    private const ALTA_EQUIPOS_MAXIMO = 30;
    private const CUENTA_MAXIMO = 5;
    private const CUENTA_BLOQUEO_MINUTOS = 15;
    private const IP_MAXIMO = 30;
    private const IP_BLOQUEO_MINUTOS = 30;

    public function __construct(private BaseDatos $bd)
    {
    }

    /** Segundos que faltan para poder intentar, o cero si está permitido. */
    public function reintento(string $ambito, string $cuenta, string $ip): int
    {
        $filas = $this->bd->filas(
            'SELECT GREATEST(0, TIMESTAMPDIFF(SECOND, NOW(), bloqueado_hasta)) AS segundos
             FROM intento_acceso
             WHERE ambito = ?
               AND ((tipo = ? AND clave_hash = ?) OR (tipo = ? AND clave_hash = ?))
               AND bloqueado_hasta > NOW()',
            [
                $ambito,
                'cuenta_ip',
                $this->hashCuentaIp($cuenta, $ip),
                'ip',
                $this->hashIp($ip),
            ]
        );

        $segundos = 0;
        foreach ($filas as $fila) {
            $segundos = max($segundos, (int) $fila['segundos']);
        }

        return $segundos > 0 ? $segundos : 0;
    }

    /** Registra un rechazo y devuelve el bloqueo que acaba de quedar. */
    public function falla(string $ambito, string $cuenta, string $ip): int
    {
        // Una credencial inválida suele hacer que la transacción de negocio se
        // revierta. El contador de seguridad no puede desaparecer con ella.
        if ($this->bd->enTransaccion()) {
            return (new self($this->bd->independiente()))->falla($ambito, $cuenta, $ip);
        }

        $this->bd->transaccion(function () use ($ambito, $cuenta, $ip): void {
            $this->incrementa(
                $ambito,
                'cuenta_ip',
                $this->hashCuentaIp($cuenta, $ip),
                $ambito === 'registro_equipo' ? self::ALTA_EQUIPOS_MAXIMO : self::CUENTA_MAXIMO,
                self::CUENTA_BLOQUEO_MINUTOS
            );
            $this->incrementa(
                $ambito,
                'ip',
                $this->hashIp($ip),
                self::IP_MAXIMO,
                self::IP_BLOQUEO_MINUTOS
            );
        });

        return $this->reintento($ambito, $cuenta, $ip);
    }

    /** Un acierto limpia sólo la pareja cuenta-dirección. */
    public function acierta(string $ambito, string $cuenta, string $ip): void
    {
        $this->bd->ejecuta(
            'DELETE FROM intento_acceso WHERE ambito = ? AND tipo = ? AND clave_hash = ?',
            [$ambito, 'cuenta_ip', $this->hashCuentaIp($cuenta, $ip)]
        );
    }

    public function purga(): int
    {
        return $this->bd->ejecuta(
            'DELETE FROM intento_acceso WHERE actualizado_en < DATE_SUB(NOW(), INTERVAL 30 DAY)'
        );
    }

    public static function hashDireccion(string $ip): string
    {
        return hash('sha256', 'ip' . "\0" . trim($ip));
    }

    private function incrementa(string $ambito, string $tipo, string $hash, int $maximo, int $bloqueo): void
    {
        $this->bd->ejecuta(
            'INSERT IGNORE INTO intento_acceso
                (ambito, tipo, clave_hash, ventana_desde, intentos, bloqueado_hasta)
             VALUES (?, ?, ?, NOW(), 0, NULL)',
            [$ambito, $tipo, $hash]
        );

        $fila = $this->bd->fila(
            'SELECT ventana_desde, intentos
             FROM intento_acceso
             WHERE ambito = ? AND tipo = ? AND clave_hash = ?
             FOR UPDATE',
            [$ambito, $tipo, $hash]
        );

        $reinicia = $fila === null
            || strtotime((string) $fila['ventana_desde']) <= strtotime('-' . self::VENTANA_MINUTOS . ' minutes');
        $intentos = ($reinicia ? 0 : (int) ($fila['intentos'] ?? 0)) + 1;

        $this->bd->ejecuta(
            'UPDATE intento_acceso
             SET ventana_desde = IF(?, NOW(), ventana_desde),
                 intentos = ?,
                 bloqueado_hasta = IF(? >= ?, DATE_ADD(NOW(), INTERVAL ? MINUTE), NULL)
             WHERE ambito = ? AND tipo = ? AND clave_hash = ?',
            [$reinicia ? 1 : 0, $intentos, $intentos, $maximo, $bloqueo, $ambito, $tipo, $hash]
        );
    }

    private function hashCuentaIp(string $cuenta, string $ip): string
    {
        return hash('sha256', 'cuenta_ip' . "\0" . mb_strtolower(trim($cuenta)) . "\0" . trim($ip));
    }

    private function hashIp(string $ip): string
    {
        return self::hashDireccion($ip);
    }
}
