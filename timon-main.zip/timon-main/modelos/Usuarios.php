<?php
declare(strict_types=1);

namespace Modelos;

use Nucleo\BaseDatos;

/**
 * Los usuarios del sistema.
 *
 * La contraseña sólo existe aquí en forma de `password_hash()`. No hay un
 * método que devuelva una contraseña, porque no hay una contraseña que
 * devolver: lo guardado no se puede deshacer.
 */
final class Usuarios
{
    /**
     * Un hash de verdad, de una contraseña que no es de nadie.
     *
     * Está aquí para gastar el mismo tiempo cuando no hay usuario que
     * comprobar (ver `autentica()`). No abre nada: ninguna cuenta tiene esa
     * contraseña, y un hash de bcrypt no se deshace. Su **costo** tiene que ser
     * el mismo que el de los hashes guardados, o el tiempo vuelve a delatar;
     * eso lo vigila `pruebas/modelos/UsuariosPrueba.php`, que falla si
     * `PASSWORD_DEFAULT` cambia de costo. Se conservan los costos de las
     * versiones de PHP soportadas para que la comparación siga siendo pareja
     * en desarrollo (8.5) y en la ejecución oficial del proyecto (8.2).
     */
    private const HASH_DE_RELLENO_10 = '$2y$10$A/vOvlhkkAS1tLvk04WFIOYwA/ChO7mdfK2Y6KQi8S8MFCqlz8WdO';
    private const HASH_DE_RELLENO_12 = '$2y$12$/9j0Rx8SRsXlK2WbJTXO7ehbZ9YF62uUWmN5j4KkK4wreDuBhA6ZO';
    private static ?string $hashRellenoGenerado = null;

    /** El largo mínimo de una contraseña que escoge una persona. */
    public const LARGO_MINIMO = 12;

    /**
     * Las letras de una contraseña temporal: sin las que se confunden al
     * dictarlas o copiarlas de un papel (0 y O, 1, l e I).
     */
    private const LETRAS_TEMPORAL = 'abcdefghjkmnpqrstuvwxyz23456789';

    public function __construct(private BaseDatos $bd)
    {
    }

    /**
     * Una contraseña temporal: tres grupos de cuatro, `k7dm-q2wx-8hfp`.
     *
     * Aleatoria de verdad (`random_int`), y existe sólo en la respuesta que la
     * muestra una vez: aquí se guarda su hash. En el sistema de referencia la inicial era fija
     * en el código y quedaba en claro en la bitácora (alcance-v2 §4.20).
     */
    public static function claveTemporal(): string
    {
        $grupos = [];
        $tope   = strlen(self::LETRAS_TEMPORAL) - 1;

        for ($g = 0; $g < 3; $g++) {
            $grupo = '';
            for ($i = 0; $i < 4; $i++) {
                $grupo .= self::LETRAS_TEMPORAL[random_int(0, $tope)];
            }
            $grupos[] = $grupo;
        }

        return implode('-', $grupos);
    }

    /**
     * Lo que está mal de una contraseña nueva, o `null` si sirve.
     *
     * El largo, el nombre de usuario y las que todo el mundo prueba primero
     * (`ClavesComunes`). Las reglas de «una mayúscula y un símbolo» empujan a
     * `Timon2026!`, que es peor que una frase larga. No caduca: cambiarla a
     * fuerza lleva a `Clave1`, `Clave2`. Se aplica al elegir una contraseña; las
     * que ya existen siguen valiendo hasta que su dueño las cambie.
     */
    public static function quejaDeClave(string $clave, string $usuario): ?string
    {
        if (mb_strlen($clave) < self::LARGO_MINIMO) {
            return 'Al menos ' . self::LARGO_MINIMO . ' caracteres';
        }

        if ($usuario !== '' && mb_stripos($clave, $usuario) !== false) {
            return 'No puede contener su nombre de usuario';
        }

        if (\Nucleo\Seguridad\ClavesComunes::es($clave)) {
            return 'Contraseña muy común. Use otra';
        }

        return null;
    }

    /** @return array<string,mixed>|null */
    public function porUsuario(string $usuario): ?array
    {
        return $this->bd->fila(
            'SELECT id, id_personal, usuario, clave_hash, cambiar_clave, id_estatus, sesion_version,
                    totp_confirmado_en, (acceso_hasta IS NOT NULL AND acceso_hasta <= NOW()) AS acceso_vencido
             FROM usuario WHERE usuario = ?',
            [$usuario]
        );
    }

    /** @return array<string,mixed>|null */
    public function porId(int $id): ?array
    {
        return $this->bd->fila(
            'SELECT id, id_personal, usuario, cambiar_clave, id_estatus, ultimo_acceso, creado_en,
                    sesion_version, totp_confirmado_en
             FROM usuario WHERE id = ?',
            [$id]
        );
    }

    /**
     * El usuario de una persona del personal (D12: no hay usuario sin personal).
     *
     * Los permisos no se eligen aquí: son los del puesto de la persona. La
     * contraseña nace **temporal** —`cambiar_clave = 1`— salvo que quien la
     * crea diga lo contrario a propósito.
     */
    public function crea(
        int $idPersonal,
        string $usuario,
        string $claveEnClaro,
        bool $temporal = true,
        ?int $creadoPor = null
    ): int {
        return $this->bd->inserta(
            'INSERT INTO usuario (id_personal, usuario, clave_hash, cambiar_clave, creado_por)
             VALUES (?, ?, ?, ?, ?)',
            [
                $idPersonal,
                $usuario,
                password_hash($claveEnClaro, PASSWORD_DEFAULT),
                $temporal ? 1 : 0,
                $creadoPor,
            ]
        );
    }

    /** @return array<string,mixed>|null */
    public function porPersonal(int $idPersonal): ?array
    {
        return $this->bd->fila(
            'SELECT id, id_personal, usuario, cambiar_clave, id_estatus, ultimo_acceso, creado_en
             FROM usuario WHERE id_personal = ?',
            [$idPersonal]
        );
    }

    /**
     * Cambia la contraseña. La que pone la propia persona deja de ser temporal;
     * la que pone otro —un restablecimiento— nace temporal, y entonces se
     * cortan sus tokens: el teléfono que la tenía no sigue entrando con la vieja.
     */
    public function cambiaClave(int $idUsuario, string $claveEnClaro, bool $temporal = false): void
    {
        $this->bd->ejecuta(
            'UPDATE usuario SET clave_hash = ?, cambiar_clave = ?, sesion_version = sesion_version + 1 WHERE id = ?',
            [password_hash($claveEnClaro, PASSWORD_DEFAULT), $temporal ? 1 : 0, $idUsuario]
        );

        if ($temporal) {
            $this->revocaTokens($idUsuario);
        }
    }

    /** Todos sus tokens dejan de valer en el acto, sin esperar a que expiren. */
    public function revocaTokens(int $idUsuario): void
    {
        $this->bd->ejecuta(
            'UPDATE token_acceso SET revocado_en = NOW() WHERE id_usuario = ? AND revocado_en IS NULL',
            [$idUsuario]
        );
    }

    public function revocaSesiones(int $idUsuario): void
    {
        $this->bd->ejecuta('UPDATE usuario SET sesion_version=sesion_version+1 WHERE id=?', [$idUsuario]);
        $this->revocaTokens($idUsuario);
    }

    /** Baja lógica (estatus 3). Nunca física: la historia tiene que seguir cuadrando. */
    public function desactiva(int $idUsuario): void
    {
        $this->bd->ejecuta('UPDATE usuario SET id_estatus = 3, sesion_version=sesion_version+1 WHERE id = ?', [$idUsuario]);
        $this->revocaTokens($idUsuario);
    }

    public function activa(int $idUsuario): void
    {
        $this->bd->ejecuta('UPDATE usuario SET id_estatus = 4 WHERE id = ?', [$idUsuario]);
    }

    /**
     * Si *ese* usuario tiene un permiso, sin cargarle la identidad.
     *
     * `Nucleo\Identidad` contesta esto para quien está en pantalla. Esto es para
     * preguntarlo de **otra persona** —por ejemplo, si a quien se le asigna un
     * reparto de verdad es repartidor—, sin cargarle la identidad.
     */
    public function puede(int $idUsuario, string $permiso): bool
    {
        return (int) $this->bd->valor(
            'SELECT COUNT(*)
             FROM usuario u
             JOIN personal p        ON p.id = u.id_personal
             JOIN puesto_permiso pp ON pp.id_puesto = p.id_puesto
             JOIN permiso pe        ON pe.id = pp.id_permiso
             WHERE u.id = ? AND pe.clave = ?',
            [$idUsuario, $permiso]
        ) > 0;
    }

    /**
     * Lo que dice cada permiso en palabras («Ver clientes»), por su clave.
     * Mi perfil los muestra así y no con la clave interna.
     *
     * @param list<string> $claves
     * @return array<string,string>
     */
    public function descripcionesPermisos(array $claves): array
    {
        if ($claves === []) {
            return [];
        }
        $filas = $this->bd->filas(
            'SELECT clave, descripcion FROM permiso WHERE clave IN (' . implode(',', array_fill(0, count($claves), '?')) . ')',
            array_values($claves)
        );

        return array_column($filas, 'descripcion', 'clave');
    }

    /**
     * Usuario y contraseña, en tiempo parejo.
     *
     * Devuelve el renglón del usuario si los dos están bien, y `null` si no,
     * sin decir cuál de los dos falló: es el único camino de entrada, el de la
     * web y el de la app.
     *
     * ⚠️ **El tiempo también dice cosas.** Los dos controladores de entrada
     * cuidan dar «el mismo mensaje pase lo que pase», y el reloj lo desmentía:
     * medido contra `/api/v1/entrar`, un usuario que existe con la contraseña
     * mala tardaba **73 ms** y uno que no existe **6 ms**, doce veces menos,
     * porque sin renglón no había `password_verify` que hacer. Quien cronometre
     * las respuestas se lleva la lista de usuarios válidos, que es el primer
     * paso de todo lo demás —y por la API, donde no hay freno ni galleta—.
     *
     * Cuando no hay a quién comprobarle nada, se gasta el mismo bcrypt contra
     * un hash que no es de nadie. El usuario **inactivo** va por ahí también,
     * así que «existe pero está dado de baja» tampoco se distingue.
     *
     * @return array<string,mixed>|null
     */
    public function autentica(string $usuario, string $claveEnClaro): ?array
    {
        $registro = $usuario === '' ? null : $this->porUsuario($usuario);

        // Un acceso de soporte vencido cuesta lo mismo que una cuenta inexistente,
        // y contesta lo mismo: el reloj tampoco dice que la cuenta existió.
        if ($registro === null || (int) $registro['id_estatus'] !== 4 || (int) ($registro['acceso_vencido'] ?? 0) === 1) {
            password_verify($claveEnClaro, self::hashDeRelleno());

            return null;
        }

        return $this->claveCorrecta($registro, $claveEnClaro) ? $registro : null;
    }

    /**
     * Comprueba la contraseña, y de paso la rehace si el algoritmo envejeció.
     *
     * @param array<string,mixed> $usuario
     */
    public function claveCorrecta(array $usuario, string $claveEnClaro): bool
    {
        if (!password_verify($claveEnClaro, (string) $usuario['clave_hash'])) {
            return false;
        }

        if (password_needs_rehash((string) $usuario['clave_hash'], PASSWORD_DEFAULT)) {
            $this->rehaz((int) $usuario['id'], $claveEnClaro);
        }

        return true;
    }

    /** Un hash con el costo de `PASSWORD_DEFAULT` de la versión que ejecuta. */
    private static function hashDeRelleno(): string
    {
        return match (PASSWORD_BCRYPT_DEFAULT_COST) {
            10 => self::HASH_DE_RELLENO_10,
            12 => self::HASH_DE_RELLENO_12,
            default => self::$hashRellenoGenerado ??= password_hash('relleno-sin-cuenta', PASSWORD_DEFAULT),
        };
    }

    /** Rehace el hash sin tocar si la contraseña es temporal. */
    private function rehaz(int $idUsuario, string $claveEnClaro): void
    {
        $this->bd->ejecuta(
            'UPDATE usuario SET clave_hash = ? WHERE id = ?',
            [password_hash($claveEnClaro, PASSWORD_DEFAULT), $idUsuario]
        );
    }
}
