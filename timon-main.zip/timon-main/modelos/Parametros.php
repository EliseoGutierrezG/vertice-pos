<?php
declare(strict_types=1);

namespace Modelos;

use Nucleo\BaseDatos;

/**
 * Las reglas que cambian sin tocar código.
 *
 * El tope de descuento y el prefijo de folio viven aquí porque son decisiones
 * del negocio, no del programa: el día que el dueño quiera subir el tope al
 * 12 %, eso no debería necesitar un despliegue.
 *
 * **Con vigencia**, como los precios. Un pedido de marzo se explica con el tope
 * que estaba vigente en marzo, aunque hoy sea otro.
 */
final class Parametros
{
    /** @var array<string,string> Lo ya leído en esta petición */
    private array $leidos = [];

    public function __construct(private BaseDatos $bd)
    {
    }

    public function valor(string $clave, string $porOmision = '', ?string $fecha = null): string
    {
        $fecha = $fecha ?? date('Y-m-d');
        $cache = $clave . '|' . $fecha;

        if (isset($this->leidos[$cache])) {
            return $this->leidos[$cache];
        }

        $valor = $this->bd->valor(
            'SELECT valor FROM parametro
             WHERE clave = ? AND vigente_desde <= ? AND (vigente_hasta IS NULL OR vigente_hasta >= ?)
             ORDER BY vigente_desde DESC LIMIT 1',
            [$clave, $fecha, $fecha]
        );

        return $this->leidos[$cache] = $valor === null ? $porOmision : (string) $valor;
    }

    public function entero(string $clave, int $porOmision = 0, ?string $fecha = null): int
    {
        $valor = $this->valor($clave, (string) $porOmision, $fecha);

        return is_numeric($valor) ? (int) $valor : $porOmision;
    }

    /** @return list<array<string,mixed>> */
    public function vigentes(): array
    {
        return $this->bd->filas(
            'SELECT clave, valor, descripcion, vigente_desde
             FROM parametro
             WHERE vigente_desde <= CURDATE() AND (vigente_hasta IS NULL OR vigente_hasta >= CURDATE())
             ORDER BY clave'
        );
    }

    /**
     * Cambia un parámetro cerrando el anterior, nunca pisándolo.
     *
     * Igual que los precios: lo viejo sigue explicando lo viejo. Dos cambios el
     * mismo día corrigen el renglón de ese día, porque la llave es clave +
     * fecha. Sin descripción nueva, se conserva la que tenía. Devuelve el valor
     * que estaba abierto, o null si no había.
     */
    public function cambia(string $clave, string $valor, string $desde, ?string $descripcion = null): ?string
    {
        $antes = $this->bd->transaccion(function () use ($clave, $valor, $desde, $descripcion): ?string {
            // El renglón abierto se bloquea: dos cambios a la vez no dejan dos abiertos.
            $abierto = $this->bd->fila(
                'SELECT valor, descripcion FROM parametro
                 WHERE clave = ? AND vigente_hasta IS NULL
                 ORDER BY vigente_desde DESC LIMIT 1 FOR UPDATE',
                [$clave]
            );
            $descripcion ??= $abierto === null ? null : (string) $abierto['descripcion'];

            $this->bd->ejecuta(
                'UPDATE parametro SET vigente_hasta = DATE_SUB(?, INTERVAL 1 DAY)
                 WHERE clave = ? AND vigente_hasta IS NULL AND vigente_desde < ?',
                [$desde, $clave, $desde]
            );

            $this->bd->ejecuta(
                'INSERT INTO parametro (clave, valor, descripcion, vigente_desde)
                 VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE valor = VALUES(valor), descripcion = VALUES(descripcion), vigente_hasta = NULL',
                [$clave, $valor, $descripcion, $desde]
            );

            return $abierto === null ? null : (string) $abierto['valor'];
        });

        $this->leidos = [];

        return $antes;
    }

    /**
     * La historia de un parámetro, la más reciente primero.
     *
     * @return list<array{valor:string,vigente_desde:string,vigente_hasta:?string}>
     */
    public function historia(string $clave): array
    {
        return $this->bd->filas(
            'SELECT valor, vigente_desde, vigente_hasta FROM parametro WHERE clave = ? ORDER BY vigente_desde DESC',
            [$clave]
        );
    }
}
