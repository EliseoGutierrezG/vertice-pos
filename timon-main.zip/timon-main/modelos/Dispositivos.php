<?php
declare(strict_types=1);

namespace Modelos;

use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;

/**
 * Los teléfonos que la app puede usar.
 *
 * Un usuario y su contraseña no bastan para operar en campo: el teléfono
 * tiene que estar autorizado desde la web. Es el segundo factor que se
 * decidió en el alcance, y el que evita que una contraseña prestada se
 * convierta en pedidos levantados desde cualquier lado.
 */
final class Dispositivos
{
    public function __construct(private BaseDatos $bd)
    {
    }

    /**
     * Encuentra el dispositivo o lo registra, sin autorizar.
     *
     * Se devuelve siempre: la app necesita poder decirle al vendedor
     * "tu teléfono está esperando autorización", que es información útil,
     * en lugar de un rechazo mudo.
     *
     * @return array<string,mixed>
     */
    public function registraOEncuentra(int $idUsuario, string $identificador, ?string $nombre): array
    {
        $dispositivo = $this->porPareja($idUsuario, $identificador);

        if ($dispositivo === null) {
            $this->bd->inserta(
                'INSERT INTO dispositivo (id_usuario, identificador, nombre) VALUES (?, ?, ?)',
                [$idUsuario, $identificador, $nombre]
            );

            /** @var array<string,mixed> $dispositivo */
            $dispositivo = $this->porPareja($idUsuario, $identificador);
        }

        $this->bd->ejecuta('UPDATE dispositivo SET ultimo_acceso = NOW() WHERE id = ?', [$dispositivo['id']]);

        return $dispositivo;
    }

    /** @return array<string,mixed>|null */
    public function porIdentificador(string $identificador): ?array
    {
        return $this->bd->fila(
            'SELECT id, id_usuario, identificador, nombre, autorizado, autorizado_en, ultimo_acceso
             FROM dispositivo WHERE identificador = ? ORDER BY id DESC LIMIT 1',
            [$identificador]
        );
    }

    /** @return array<string,mixed>|null */
    public function porPareja(int $idUsuario, string $identificador): ?array
    {
        return $this->bd->fila(
            'SELECT id, id_usuario, identificador, nombre, autorizado, autorizado_en, ultimo_acceso
             FROM dispositivo WHERE id_usuario = ? AND identificador = ?',
            [$idUsuario, $identificador]
        );
    }

    /** @return list<array<string,mixed>> */
    public function todos(): array
    {
        return $this->bd->filas(
            'SELECT d.id, d.identificador, d.nombre, d.autorizado, d.autorizado_en, d.ultimo_acceso,
                    CONCAT(p.nombre, \' \', p.apellido_paterno) AS usuario
             FROM dispositivo d
             JOIN usuario u  ON u.id = d.id_usuario
             JOIN personal p ON p.id = u.id_personal
             ORDER BY d.autorizado, d.ultimo_acceso DESC'
        );
    }

    /** El token push pertenece a la pareja usuario-teléfono del token de acceso. */
    public function actualizaPush(int $id, int $idUsuario, string $token, string $plataforma): void
    {
        $token=trim($token);$plataforma=strtolower(trim($plataforma));
        if(preg_match('/^(?:Exponent|Expo)PushToken\[[A-Za-z0-9_-]+\]$/',$token)!==1||strlen($token)>255){
            throw Errores::datosInvalidos(['token_push'=>'No se pudo registrar el teléfono para avisos']);
        }
        if(!in_array($plataforma,['android','ios'],true)){
            throw Errores::datosInvalidos(['plataforma'=>'Teléfono no compatible']);
        }
        $existe=$this->bd->valor('SELECT 1 FROM dispositivo WHERE id=? AND id_usuario=?',[$id,$idUsuario]);
        if($existe===null)throw Errores::noEncontrado('El teléfono no existe');
        $this->bd->ejecuta(
            'UPDATE dispositivo SET token_push=?,plataforma=? WHERE id=? AND id_usuario=?',
            [$token,$plataforma,$id,$idUsuario]
        );
    }

    public function autoriza(int $id): void
    {
        $this->bd->ejecuta(
            'UPDATE dispositivo SET autorizado = 1, autorizado_en = NOW() WHERE id = ?',
            [$id]
        );
    }

    /** Se retira la autorización y se cortan sus tokens en el acto. */
    public function retira(int $id): void
    {
        $this->bd->transaccion(function (BaseDatos $bd) use ($id): void {
            $bd->ejecuta('UPDATE dispositivo SET autorizado = 0, autorizado_en = NULL WHERE id = ?', [$id]);
            $bd->ejecuta(
                'UPDATE token_acceso SET revocado_en = NOW()
                 WHERE id_dispositivo = ? AND revocado_en IS NULL',
                [$id]
            );
        });
    }
}
