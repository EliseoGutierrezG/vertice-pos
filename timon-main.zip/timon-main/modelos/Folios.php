<?php
declare(strict_types=1);

namespace Modelos;

use Nucleo\BaseDatos;
use Nucleo\Errores\Errores;

/**
 * Quien reparte los folios, uno a la vez.
 *
 * ⚠️ Antes cada servicio armaba el suyo con `MAX(folio) + 1`. Es lo que hace
 * cualquiera, y es lo que falla cuando dos suben al mismo tiempo: los dos leen
 * el mismo máximo, los dos arman el mismo folio y la llave única del folio
 * rechaza al segundo. **Medido con ocho pedidos simultáneos —lo que pasa cuando
 * varios vendedores recuperan señal al salir del mismo pueblo—: entró uno y
 * siete recibieron 409**, y un 409 es lo único que la app llama «rechazo», así
 * que marca la operación atorada y **detiene la cola del vendedor**. El defecto
 * no rompía datos: dejaba a la gente sin poder subir su día de trabajo.
 *
 * Aquí el folio se pide a un contador —la tabla `folio_serie`, un renglón por
 * serie— con un `INSERT ... ON DUPLICATE KEY UPDATE` que **bloquea ese
 * renglón**: los que llegan juntos se forman y cada uno se lleva el suyo. Sin
 * huecos, sin reintentos, y sin que el número dependa de cuántas filas haya en
 * la tabla del documento.
 */
final class Folios
{
    public function __construct(private BaseDatos $bd)
    {
    }

    /**
     * El siguiente folio de una serie: `PED-000123`.
     *
     * Se usa `LAST_INSERT_ID(...)` y no un `SELECT` después del `UPDATE` a
     * propósito: `LAST_INSERT_ID()` es **de esta conexión**, así que devuelve el
     * número que se llevó este proceso aunque otro incremente en medio. Un
     * `SELECT ultimo` sólo sería seguro dentro de una transacción, y este método
     * tiene que servir igual dentro y fuera.
     *
     * Si la serie no tiene renglón, se abre en 1. En la v2 eso es lo correcto
     * siempre: la base nace vacía y ninguna serie tiene documentos anteriores.
     * (El prototipo sí los tenía y los arrancaba en su máximo con
     * `esquema/historico-v1/008_folio_serie.sql`.)
     */
    public function siguiente(string $serie, string $prefijo, int $digitos): string
    {
        $this->bd->ejecuta(
            'INSERT INTO folio_serie (serie, ultimo) VALUES (?, LAST_INSERT_ID(1))
             ON DUPLICATE KEY UPDATE ultimo = LAST_INSERT_ID(ultimo + 1)',
            [$serie]
        );

        $numero = (int) $this->bd->valor('SELECT LAST_INSERT_ID()');

        if ($numero < 1) {
            throw Errores::conflicto('No se pudo asignar el folio de ' . $serie);
        }

        return sprintf('%s-%0' . $digitos . 'd', $prefijo, $numero);
    }

    /** Lo último que se repartió de una serie. Para mirar, no para decidir. */
    public function ultimo(string $serie): int
    {
        return (int) $this->bd->valor('SELECT ultimo FROM folio_serie WHERE serie = ?', [$serie]);
    }
}
