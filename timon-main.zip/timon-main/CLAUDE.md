# El Timón

Sistema de **comanda multisucursal** para **El Timón**, restaurante de mariscos: panel administrativo, app de comanda (teléfono, tableta y PC), pantalla de cocina, impresión térmica, landing y menú QR. **PHP 8.3 nativo + MariaDB en Hostinger compartido**; la app será **Expo universal** (nativa en Android/iPad y PWA en las PC con Windows).

Es además la **plantilla base** de los siguientes negocios: el código se separa en una capa base reutilizable y una capa de giro restaurante. Cómo se divide está en [`docs/plantilla.md`](docs/plantilla.md).

**Estado:** fases 0 a 11 cerradas el 2026-11-14 y revisión integral (comanda, cobro, panel homologado y sitio) el 2026-11-17, con `pruebas/todo.sh` en verde. El 2026-11-18 se agregaron la carta impresa que se arma sola (pantalla Carta), las promociones por platillo (guion 024) y la **operación sin internet** con una computadora en cada sucursal (guion 025, [guía](docs/servidor-sucursal.md)). La identidad aprobada es la «1A», [Timón y ola con la paleta Peltre](marca/marca.md). Falta el piloto en una sucursal según el [runbook](docs/salida.md); Android se prueba ahí, en dispositivos físicos. Las migraciones nuevas se verifican primero en `timon_pruebas` y después se aplican a `timon` con `guiones/migraciones.php`. El avance por fase está en [`docs/plan.md`](docs/plan.md).

## Cómo trabajamos

**Continuación 2026-11-20:** actualizaciones de sucursal por liberaciones Ed25519, guiones 026–027, instalación con candados y respaldo cifrado, salud por HTTP y regreso de código; ajustes OTA y versión mínima en la app. Validación local: `PB_ESQUEMA_AISLADO=1 APP_ENTORNO=pruebas pruebas/todo.sh` completo en verde (516 internas), tipos y exportación PWA. [Evidencia y límites](docs/validacion-actualizaciones-2026-11-20.md). El usuario pidió dejar preparada la instalación porque aún no tiene acceso por Tailscale: no se ha desplegado al central ni al equipo remoto, ni probado Docker/DSM o la distribución nativa real.

- **Todo en español**: documentación, código, nombres, mensajes y commits.
- **Una fase no está terminada si no se comprobó**: unitarias, humo y, si toca pantalla, en el navegador.
- **Commits y envíos solo cuando se pidan.** Antes de cada commit se revisa que no entren secretos ni `config/*.php`.
- **Distribuidora es de solo lectura** (`../Distribuidora/Distribuidora`): de ahí se toma código para portarlo, nunca se modifica.
- **Nunca reproduzcas secretos ni datos personales**: indica dónde están, no cuánto valen.

## Reglas del código

- **Un guion de `esquema/` aplicado no se modifica**: se agrega otro con el número siguiente. `guiones/aplica-esquema.php --acepto=<base>` recrea una base local desde cero y **borra lo que tenga**; en producción se usa `guiones/migraciones.php`.
- Toda ruta pasa por `ExigePermiso` y cada acción declara su permiso con `#[Accion]`: lo que no declara, falla cerrado. Las rutas viven en [`rutas/web.php`](rutas/web.php) y [`rutas/api.php`](rutas/api.php).
- Lo que escribe deja rastro en la bitácora; lo que se manda dos veces se protege con `ExigeEnvioUnico` (`#[Accion(unaVez: true)]`).
- **Todo dato de negocio cuelga de una sucursal** y se filtra por `Identidad::sucursales()` / `exigeSucursal()`. El administrador ve todas.
- Las pantallas se arman con las piezas `pb_*` de [`vistas/partes/piezas.php`](vistas/partes/piezas.php) y siguen la [guía de pantallas](docs/guia-pantallas.md). Los textos siguen la [guía de textos](docs/textos/guia-de-textos.md), que hace cumplir `pruebas/TextosPrueba.php`.
- Dinero en `DECIMAL`, nunca `FLOAT`; consultas siempre con parámetros.

## Entorno local

- **PHP 8.3**: `/opt/homebrew/opt/php@8.3/bin/php` (el `php` enlazado es otra versión).
- **MariaDB 10.11**: `/opt/homebrew/opt/mariadb@10.11/bin/mariadb`. Bases `timon` (cotidiana) y `timon_pruebas`, cada una con su usuario; las claves viven en `config/bd.php` y `config/bd.pruebas.php`, fuera de Git.
- **Node 24**: `export PATH="/opt/homebrew/opt/node@24/bin:$PATH"`. El `package.json` de la raíz es solo de herramientas (TypeScript para el candado de textos).
- Panel de todos los días: `guiones/servidor-local.sh` (8080). Pruebas: `guiones/servidor-pruebas.sh` (8081) y después `pruebas/todo.sh`. ⚠️ **`pruebas/todo.sh` nunca contra producción**: reconstruye la base.
- El administrador se crea con `guiones/crear-usuario.php`, que pide la contraseña sin mostrarla.

## Mapa

| Ruta | Qué es |
|---|---|
| [`README.md`](README.md) | Empezar aquí: qué es y cómo se arranca |
| [`docs/README.md`](docs/README.md) | Índice de la documentación |
| [`docs/plan.md`](docs/plan.md) | El plan por fases y la arquitectura de la comanda |
| [`docs/plantilla.md`](docs/plantilla.md) | Capa base contra capa de giro, y cómo se parte un negocio nuevo |
| [`docs/guia-pantallas.md`](docs/guia-pantallas.md) | **Léase antes de tocar una pantalla del panel** |
| [`design-system/plantilla/MASTER.md`](design-system/plantilla/MASTER.md) | El sistema visual del panel y su relación con la marca |
| [`docs/servidor-sucursal.md`](docs/servidor-sucursal.md) | La computadora de sucursal: operar sin internet y sincronizar con el central |
| [`esquema/`](esquema/001_catalogos.sql) | DDL incremental de MariaDB |
| `../Distribuidora/Distribuidora` | El sistema del que viene la capa base. Solo lectura |
