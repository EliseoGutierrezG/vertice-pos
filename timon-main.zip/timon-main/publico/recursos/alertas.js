/**
 * Los diálogos de El Timón (D25.2): SweetAlert2 con la disposición, los iconos,
 * los botones y el movimiento de la casa, en lugar de los de fábrica.
 *
 * Se carga justo después de `sweetalert2.min.js` y sustituye `window.Swal`
 * (y su alias `window.Sweetalert2`) por una clase que extiende un `mixin`. Los
 * estáticos que usan `plantilla/main.js` y `plantilla.js` —`isVisible`, `close`,
 * `getHtmlContainer`, `DismissReason`— se heredan, así que nadie cambia su
 * llamada. El aspecto vive en `tema.css`, bloque «Diálogos (D25.2)».
 *
 * Opciones propias que entiende `fire()`:
 *   - `tono: 'peligro'`: lo destructivo; icono de alerta y botón rojo.
 * Todo lo demás es de SweetAlert2.
 */
(function () {
    'use strict';

    const Base = window.Swal || window.Sweetalert2;
    if (!Base || typeof Base.mixin !== 'function') {
        return;
    }

    // La palomita se dibuja con CSS (`stroke-dashoffset`); el resto son glifos
    // de Bootstrap Icons, que el panel ya carga. Todo decorativo: el título dice lo que pasó.
    const PALOMITA = '<svg class="pb-alerta__palomita" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
        + '<path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
    const glifo = function (nombre) {
        return '<i class="bi ' + nombre + '" aria-hidden="true"></i>';
    };
    const TONOS = {
        success: { clase: 'exito', icono: PALOMITA },
        error: { clase: 'error', icono: glifo('bi-x-lg') },
        warning: { clase: 'aviso', icono: glifo('bi-exclamation-lg') },
        info: { clase: 'info', icono: glifo('bi-info-lg') },
        question: { clase: 'info', icono: glifo('bi-question-lg') },
        peligro: { clase: 'peligro', icono: glifo('bi-exclamation-octagon') }
    };

    const Mezcla = Base.mixin({
        buttonsStyling: false,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        denyButtonText: 'No',
        closeButtonAriaLabel: 'Cerrar',
        showClass: { popup: 'pb-alerta--entra', backdrop: 'pb-fondo--entra', icon: 'pb-icono--entra' },
        hideClass: { popup: 'pb-alerta--sale', backdrop: 'pb-fondo--sale', icon: 'pb-icono--sale' }
    });

    /** Une las clases propias con las que traiga la llamada, sin perder ninguna. */
    function clases(propias, ajenas) {
        const salida = Object.assign({}, propias);
        Object.keys(ajenas || {}).forEach(function (llave) {
            salida[llave] = [propias[llave], ajenas[llave]].filter(Boolean).join(' ');
        });
        return salida;
    }

    class SwalPlantilla extends Mezcla {
        static fire(...argumentos) {
            let opciones = argumentos[0];
            // La forma corta de SweetAlert2: fire(título, texto, icono).
            if (typeof opciones !== 'object' || opciones === null) {
                opciones = { title: argumentos[0], text: argumentos[1], icon: argumentos[2] };
            } else {
                opciones = Object.assign({}, opciones);
            }

            const peligro = opciones.tono === 'peligro';
            delete opciones.tono;
            if (peligro && !opciones.icon) {
                opciones.icon = 'warning';
            }
            const tono = TONOS[peligro ? 'peligro' : opciones.icon] || null;
            if (tono && !opciones.iconHtml) {
                opciones.iconHtml = tono.icono;
            }

            const popup = ['pb-alerta', tono ? 'pb-alerta--' + tono.clase : 'pb-alerta--sin-icono'];
            opciones.customClass = clases({
                popup: popup.join(' '),
                icon: 'pb-alerta__icono',
                title: 'pb-alerta__titulo',
                htmlContainer: 'pb-alerta__texto',
                actions: 'pb-alerta__acciones',
                confirmButton: peligro ? 'btn btn-danger' : 'btn btn-primary',
                denyButton: 'btn btn-outline-danger',
                cancelButton: 'btn btn-outline-secondary',
                closeButton: 'pb-alerta__cerrar',
                timerProgressBar: 'pb-alerta__tiempo'
            }, opciones.customClass);

            return super.fire(opciones);
        }
    }

    window.Swal = SwalPlantilla;
    window.Sweetalert2 = SwalPlantilla;
})();
