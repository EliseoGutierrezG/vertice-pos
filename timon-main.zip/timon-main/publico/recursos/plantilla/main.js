(function () {
    'use strict';

    if (window.__plantillaIniciada) {
        return;
    }

    window.__plantillaIniciada = true;

    let generatedFieldId = 0;
    let remoteSelectId = 0;

    function labelControls(label) {
        if (label.querySelector('input:not([type="hidden"]), select, textarea')) {
            return [];
        }

        const controls = [];
        const sibling = label.nextElementSibling;
        if (!sibling) {
            return controls;
        }

        if (sibling.matches('input:not([type="hidden"]), select, textarea')) {
            controls.push(sibling);
            return controls;
        }

        const nested = sibling.querySelectorAll?.('input:not([type="hidden"]), select, textarea') || [];
        if (nested.length > 0) {
            controls.push(...nested);
        }

        return controls;
    }

    function initializeLabelAssociations(root = document) {
        const labels = [];
        if (root.matches?.('label:not([for])')) {
            labels.push(root);
        }
        labels.push(...root.querySelectorAll('label:not([for])'));

        labels.forEach(function (label) {
            const controls = labelControls(label);
            if (controls.length === 0) {
                return;
            }

            if (controls.length === 1) {
                const control = controls[0];
                if (!control.id) {
                    generatedFieldId += 1;
                    control.id = `app-field-${generatedFieldId}`;
                }
                label.htmlFor = control.id;
                return;
            }

            const group = label.parentElement;
            if (!group) {
                return;
            }
            if (!label.id) {
                generatedFieldId += 1;
                label.id = `app-field-label-${generatedFieldId}`;
            }
            if (!group.hasAttribute('role')) {
                group.setAttribute('role', 'group');
            }
            if (!group.hasAttribute('aria-labelledby')) {
                group.setAttribute('aria-labelledby', label.id);
            }
        });
    }

    function initializeRequiredHints(root = document) {
        const fields = [];
        if (root.matches?.('input[required], select[required], textarea[required]')) {
            fields.push(root);
        }
        fields.push(...root.querySelectorAll('input[required], select[required], textarea[required]'));

        fields.forEach(function (field) {
            if (field.type === 'hidden') {
                return;
            }

            const container = field.closest('.form-grid > div, .row > div, .form-section, .mb-3, .p-3')
                || field.parentElement;

            const label = (field.id
                ? root.querySelector?.(`label[for="${CSS.escape(field.id)}"]`)
                    || document.querySelector(`label[for="${CSS.escape(field.id)}"]`)
                : null)
                || container?.querySelector('label.form-label, label');
            const markedElement = label?.querySelector('.required-hint, .text-danger, .required, [aria-hidden="true"]');
            const markedText = Array.from(label?.childNodes || []).some((node) => (
                node.nodeType === Node.TEXT_NODE && /\*\s*$/.test(node.textContent || '')
            ));
            if (!label || markedText || String(markedElement?.textContent || '').includes('*')) {
                return;
            }

            const hint = document.createElement('span');
            hint.className = 'required-hint';
            hint.textContent = '*';
            hint.setAttribute('aria-hidden', 'true');
            label.append(' ', hint);
        });
    }

    function initializeModalAccessibility(root = document) {
        const modals = [];
        if (root.matches?.('.modal')) {
            modals.push(root);
        }
        modals.push(...root.querySelectorAll('.modal'));

        modals.forEach(function (modal) {
            const title = modal.querySelector('.modal-title');
            if (!title || modal.hasAttribute('aria-label') || modal.hasAttribute('aria-labelledby')) {
                return;
            }

            if (!title.id) {
                generatedFieldId += 1;
                title.id = modal.id ? `${modal.id}Title` : `app-modal-title-${generatedFieldId}`;
            }
            modal.setAttribute('aria-labelledby', title.id);
        });
    }

    // Sin un control adentro, el teclado no podía desplazar la tabla (WCAG
    // 2.1.1, bitácora 107): la envoltura se vuelve una región enfocable con el
    // nombre de su tabla. Con controles adentro no hace falta otra parada.
    function makeScrollRegionFocusable(wrapper) {
        const table = wrapper.querySelector('table');
        if (!table || wrapper.hasAttribute('tabindex')
            || wrapper.querySelector('a[href], button, input, select, textarea, [tabindex]')) {
            return;
        }
        const name = table.getAttribute('aria-label') || table.querySelector('caption')?.textContent.trim() || 'Tabla';
        wrapper.setAttribute('tabindex', '0');
        wrapper.setAttribute('role', 'region');
        wrapper.setAttribute('aria-label', name);
    }

    function initializeResponsiveTableHints(root = document) {
        const wrappers = [];
        if (root.matches?.('.table-responsive')) {
            wrappers.push(root);
        }
        wrappers.push(...root.querySelectorAll('.table-responsive'));

        wrappers.forEach(function (wrapper) {
            if (!wrapper.querySelector('table') || wrapper.closest('.table-zone')) {
                return;
            }
            makeScrollRegionFocusable(wrapper);
            if (wrapper.previousElementSibling?.classList.contains('mobile-scroll-hint')) {
                return;
            }

            const hint = document.createElement('p');
            hint.className = 'mobile-scroll-hint';
            hint.innerHTML = '<i class="bi bi-arrow-left-right" aria-hidden="true"></i> Deslice horizontalmente para consultar toda la información.';
            wrapper.before(hint);
        });
    }

    function initializeTooltips(root = document) {
        if (!window.bootstrap?.Tooltip) {
            return;
        }

        root.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (element) {
            try {
                window.bootstrap.Tooltip.getOrCreateInstance(element);
            } catch (exception) {
                console.warn('No fue posible inicializar tooltip.', element, exception);
            }
        });
    }

    function initializeSelect2(root = document) {
        if (!window.jQuery || !window.jQuery.fn.select2) {
            return;
        }

        window.jQuery(root).find('select[data-app-select2], select[data-select2]').each(function () {
            const element = window.jQuery(this);
            if (element.hasClass('select2-hidden-accessible')) {
                return;
            }

            try {
                if (this.hasAttribute('data-select2')) {
                    this.removeAttribute('data-select2');
                    element.removeData('select2');
                }

                const modal = element.closest('.modal');
                element.select2({
                    theme: 'bootstrap-5',
                    language: 'es',
                    width: '100%',
                    dropdownParent: modal.length ? modal : window.jQuery(document.body)
                });
            } catch (exception) {
                console.warn('No fue posible inicializar Select2.', this, exception);
            }
        });
    }

    /** Conecta un selector remoto optativo; cada módulo conserva endpoint, contexto y etiquetas. */
    function bindRemoteSelect(select, options) {
        if (!select || !window.jQuery?.fn?.select2) return null;
        const element = window.jQuery(select);
        element.data('appRemoteSelect')?.destroy();
        if (element.hasClass('select2-hidden-accessible')) element.select2('destroy');
        if (select.hasAttribute?.('data-select2')) {
            select.removeAttribute('data-select2');
            element.removeData('select2');
        }
        const modal = element.closest('.modal');
        const key = 'remote-select:' + (++remoteSelectId);
        let version = 0;
        let term = null;
        function abortCurrent() {
            version++;
            window.service.cancelLatest(key);
        }
        function cancel() {
            term = null;
            abortCurrent();
        }
        function queryChanged(params) {
            abortCurrent();
            term = String(params.term || '').trim();
        }
        element.select2({
            theme: 'bootstrap-5',
            language: 'es',
            width: '100%',
            allowClear: options.allowClear !== false,
            placeholder: options.placeholder || 'Seleccione una opción',
            dropdownParent: options.dropdownParent || (modal.length ? modal : window.jQuery(document.body)),
            minimumInputLength: 2,
            ajax: {
                delay: 250,
                transport(params, success, failure) {
                    const searched = String(params.data.term || '').trim();
                    if (searched !== term || select.disabled) {
                        return { abort() {}, status: 0 };
                    }
                    const current = ++version;
                    const isCurrent = () => current === version && searched === term && !select.disabled;
                    Promise.resolve().then(() => {
                        if (!isCurrent()) return null;
                        if (Array.from(searched).length < 2) return { items: [], pagination: { more: false } };
                        return window.service.latest(key, options.controller, options.action, {
                            ...(options.args ? options.args() : {}),
                            q: searched,
                            pagina: params.data.page || 1
                        }, options.modulo);
                    }).then(data => {
                        if (!isCurrent()) return;
                        if (!data || !Array.isArray(data.items) || typeof data.pagination?.more !== 'boolean') {
                            throw new Error('La búsqueda no devolvió una página válida. Intente de nuevo.');
                        }
                        success(data);
                    }).catch(exception => {
                        if (!isCurrent() || exception?.name === 'AbortError') return;
                        failure(exception);
                    });
                    return { abort() { if (current === version) abortCurrent(); } };
                },
                processResults(data) {
                    return {
                        results: data.items.map(item => ({
                            ...item,
                            id: item.id,
                            text: options.label ? options.label(item) : String(item.nombre || '')
                        })),
                        pagination: { more: data.pagination.more }
                    };
                }
            }
        });
        const instance = element.data('select2');
        // Select2 emite query incluso cuando su mínimo evita el transporte; invalida también el debounce anterior.
        instance.on('query', queryChanged);
        instance.on('query:append', queryChanged);
        element.on('select2:closing.appRemoteSelect', cancel);
        modal[0]?.addEventListener('hide.bs.modal', cancel);
        const binding = {
            cancel,
            destroy() {
                cancel();
                element.off('.appRemoteSelect');
                modal[0]?.removeEventListener('hide.bs.modal', cancel);
                if (element.data('select2') === instance) element.select2('destroy');
                element.removeData('appRemoteSelect');
            }
        };
        element.data('appRemoteSelect', binding);
        return binding;
    }

    function formatFileSize(size) {
        if (!Number.isFinite(size)) {
            return '';
        }

        return `${(size / 1024 / 1024).toFixed(2)} MB`;
    }

    function fileUploadEmptyText(container) {
        return container?.dataset.emptyText || 'Ningún archivo seleccionado.';
    }

    function fileUploadInfo(container) {
        return container?.querySelector('[data-file-upload-info], [data-document-file-info]');
    }

    function resetFileUpload(container) {
        const upload = container?.matches?.('.file-upload, .document-upload')
            ? container
            : container?.querySelector?.('.file-upload, .document-upload');

        if (!upload) {
            return;
        }

        const input = upload.querySelector('input[type="file"]');
        const info = fileUploadInfo(upload);

        if (input) {
            input.value = '';
        }

        if (info) {
            info.textContent = fileUploadEmptyText(upload);
        }
    }

    function initializeFileUploads(root = document) {
        root.querySelectorAll('.file-upload input[type="file"], .document-upload input[type="file"]').forEach(function (input) {
            if (input.dataset.fileUploadInitialized === '1') {
                return;
            }

            input.dataset.fileUploadInitialized = '1';
            input.addEventListener('change', function () {
                const upload = input.closest('.file-upload, .document-upload');
                const info = fileUploadInfo(upload);
                const file = input.files?.[0];

                if (!info) {
                    return;
                }

                info.textContent = input.files && input.files.length > 1
                    ? `${input.files.length} archivos seleccionados`
                    : (file ? `${file.name} · ${formatFileSize(file.size)}` : fileUploadEmptyText(upload));
            });
        });
    }

    const flatpickrSpanish = {
        weekdays: {
            shorthand: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
            longhand: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado']
        },
        months: {
            shorthand: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
            longhand: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
        },
        rangeSeparator: ' - ',
        firstDayOfWeek: 1
    };

    function dateRangeInputs(input) {
        const form = input.closest('form') || document;
        return {
            start: form.querySelector(`[name="${input.dataset.startName || 'fecha_inicio'}"]`),
            end: form.querySelector(`[name="${input.dataset.endName || 'fecha_fin'}"]`)
        };
    }

    function syncDateRange(input) {
        if (input?.dataset.dateRangeDriver === 'daterangepicker') {
            syncCalendarRange(input);
            return;
        }
        const instance = input?._flatpickr;
        const fields = dateRangeInputs(input);

        if (!instance || !fields.start || !fields.end) {
            return;
        }

        if (instance.selectedDates.length === 2) {
            fields.start.value = instance.formatDate(instance.selectedDates[0], 'Y-m-d');
            fields.end.value = instance.formatDate(instance.selectedDates[1], 'Y-m-d');
            return;
        }

        if (input.value.includes(' - ')) {
            const dates = input.value.split(' - ').map((date) => instance.parseDate(date.trim(), 'd/m/Y')).filter(Boolean);
            if (dates.length === 2) {
                fields.start.value = instance.formatDate(dates[0], 'Y-m-d');
                fields.end.value = instance.formatDate(dates[1], 'Y-m-d');
                instance.setDate(dates, false);
                return;
            }
        }

        if (fields.start.value && fields.end.value) {
            instance.setDate([fields.start.value, fields.end.value], false, 'Y-m-d');
            return;
        }

        instance.clear();
    }

    function calendarRangeValue(input, fields) {
        const values = String(input.value || '').trim().split(' - ');
        const fromText = values.length === 2 && values.every(value => value.trim() !== '');
        if (input.value.trim() && !fromText) return null;
        const start = fromText ? window.moment(values[0].trim(), 'DD/MM/YYYY', true)
            : window.moment(fields.start.value, 'YYYY-MM-DD', true);
        const end = fromText ? window.moment(values[1].trim(), 'DD/MM/YYYY', true)
            : window.moment(fields.end.value, 'YYYY-MM-DD', true);
        return start.isValid() && end.isValid() && !end.isBefore(start, 'day') ? { start, end } : null;
    }

    function syncCalendarRange(input) {
        const fields = dateRangeInputs(input);
        const picker = window.jQuery(input).data('daterangepicker');
        if (!picker || !fields.start || !fields.end) return;
        const range = calendarRangeValue(input, fields);
        if (!range) {
            input.setCustomValidity(input.value.trim() ? 'Seleccione un rango de fechas válido.' : '');
            fields.start.value = '';
            fields.end.value = '';
            return;
        }
        picker.setStartDate(range.start);
        picker.setEndDate(range.end);
        fields.start.value = range.start.format('YYYY-MM-DD');
        fields.end.value = range.end.format('YYYY-MM-DD');
        input.value = `${range.start.format('DD/MM/YYYY')} - ${range.end.format('DD/MM/YYYY')}`;
        input.setCustomValidity('');
    }

    function initializeCalendarRange(input, fields) {
        if (!window.jQuery?.fn?.daterangepicker || !window.moment) return false;
        const range = calendarRangeValue(input, fields);
        const options = {
            opens: 'right',
            autoUpdateInput: false,
            autoApply: true,
            alwaysShowCalendars: true,
            locale: {
                format: 'DD/MM/YYYY', separator: ' - ', applyLabel: 'Aplicar', cancelLabel: 'Cancelar',
                customRangeLabel: 'Personalizado', firstDay: 1,
                daysOfWeek: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'],
                monthNames: flatpickrSpanish.months.longhand
            },
            ranges: {
                'Hoy': [window.moment(), window.moment()],
                'Ayer': [window.moment().subtract(1, 'days'), window.moment().subtract(1, 'days')],
                'Últimos 7 días': [window.moment().subtract(6, 'days'), window.moment()],
                'Últimos 30 días': [window.moment().subtract(29, 'days'), window.moment()],
                'Este mes': [window.moment().startOf('month'), window.moment().endOf('month')],
                'Mes pasado': [window.moment().subtract(1, 'month').startOf('month'), window.moment().subtract(1, 'month').endOf('month')]
            }
        };
        if (range) {
            options.startDate = range.start;
            options.endDate = range.end;
        }
        window.jQuery(input).daterangepicker(options);
        bindDateRange(input, function (selected) {
            input.value = `${selected.startDate.format('DD/MM/YYYY')} - ${selected.endDate.format('DD/MM/YYYY')}`;
            fields.start.value = selected.startDate.format('YYYY-MM-DD');
            fields.end.value = selected.endDate.format('YYYY-MM-DD');
            input.setCustomValidity('');
        });
        input.addEventListener('change', function () {
            if (!input.value.trim()) {
                fields.start.value = '';
                fields.end.value = '';
            }
            syncCalendarRange(input);
        });
        input.addEventListener('input', function () {
            if (!input.value.trim()) {
                fields.start.value = '';
                fields.end.value = '';
            }
            input.setCustomValidity(input.value.trim() && !calendarRangeValue(input, fields)
                ? 'Seleccione un rango de fechas válido.' : '');
        });
        return true;
    }

    function initializeDateRanges(root = document) {
        root.querySelectorAll('[data-app-date-range]').forEach(function (input) {
            if (input.dataset.dateRangeInitialized === '1') {
                syncDateRange(input);
                return;
            }

            const fields = dateRangeInputs(input);
            if (!fields.start || !fields.end) {
                return;
            }

            if (input.dataset.dateRangeDriver === 'daterangepicker') {
                if (!initializeCalendarRange(input, fields)) return;
            } else {
                if (!window.flatpickr) return;
                window.flatpickr(input, {
                    mode: 'range',
                    dateFormat: 'd/m/Y',
                    allowInput: true,
                    locale: flatpickrSpanish,
                    disableMobile: true,
                    onChange(selectedDates, _dateString, instance) {
                        if (selectedDates.length !== 2) {
                            fields.start.value = '';
                            fields.end.value = '';
                            return;
                        }

                        fields.start.value = instance.formatDate(selectedDates[0], 'Y-m-d');
                        fields.end.value = instance.formatDate(selectedDates[1], 'Y-m-d');
                        fields.start.dispatchEvent(new Event('change', { bubbles: true }));
                        fields.end.dispatchEvent(new Event('change', { bubbles: true }));
                    },
                    onClose(selectedDates) {
                        if (selectedDates.length === 1) {
                            fields.start.value = '';
                            fields.end.value = '';
                        }
                    }
                });
            }

            input.dataset.dateRangeInitialized = '1';
            syncDateRange(input);

            const form = input.closest('form');
            if (form && form.dataset.dateRangeResetBound !== '1') {
                form.dataset.dateRangeResetBound = '1';
                form.addEventListener('reset', function () {
                    window.setTimeout(function () {
                        form.querySelectorAll('[data-app-date-range]').forEach(syncDateRange);
                    }, 0);
                });
            }
        });
    }

    /** Reutiliza el calendario; el callback sólo sincroniza las fechas seleccionadas. */
    function bindDateRange(input, onSelect) {
        const control = window.jQuery(input);
        const picker = control.data('daterangepicker');
        if (!picker) {
            throw new Error('El selector de periodo debe estar inicializado.');
        }

        picker.autoApply = true;
        picker.alwaysShowCalendars = true;
        picker.container.addClass('auto-apply show-calendar app-date-range');
        control.off('.appAutoDateRange').off('.appDateRange')
            .on('focus.appDateRange click.appDateRange', function () {
                if (this.disabled) return;
                picker.show();
                picker.showCalendars();
            })
            .on('apply.daterangepicker.appDateRange', function (event, selected) {
                if (typeof onSelect === 'function') onSelect(selected);
            });
        return picker;
    }

    /** Compatibilidad para consumidores que todavía soliciten aplicación automática. */
    function bindAutoDateRange(input, onApply) {
        return bindDateRange(input, onApply);
    }

    function syncDate(input) {
        if (!input?._flatpickr) {
            return;
        }

        const value = String(input.value || '').trim();
        value === ''
            ? input._flatpickr.clear(false)
            : input._flatpickr.setDate(value, false, 'Y-m-d');
    }

    /** Flatpickr 4.6.2 sólo toma lo tecleado con Enter; al cerrar el calendario también se toma (GEN-051, RhToroV1). */
    function commitTypedDate(selectedDates, dateStr, instance) {
        const typed = String(instance.altInput?.value || '').trim();
        const current = selectedDates[0] ? instance.formatDate(selectedDates[0], 'd/m/Y') : '';
        if (typed === current) {
            return;
        }

        typed === ''
            ? instance.clear()
            : instance.setDate(typed, true, 'd/m/Y');
    }

    function initializeDates(root = document) {
        if (!window.flatpickr) {
            return;
        }

        root.querySelectorAll('[data-app-date]').forEach(function (input) {
            if (input.dataset.dateInitialized === '1') {
                syncDate(input);
                return;
            }

            input.dataset.dateInitialized = '1';
            window.flatpickr(input, {
                dateFormat: 'Y-m-d',
                altInput: true,
                altFormat: 'd/m/Y',
                allowInput: true,
                locale: flatpickrSpanish,
                disableMobile: true,
                onClose: commitTypedDate
            });
        });
    }

    function validationFieldSelector(name) {
        const escaped = CSS.escape(String(name || '').replace(/\[\]$/, ''));
        return `[name="${escaped}"], [name="${escaped}[]"]`;
    }

    function clearValidationErrors(form) {
        if (!form) {
            return;
        }

        form.querySelectorAll('.is-invalid').forEach(function (field) {
            field.classList.remove('is-invalid');
            field.removeAttribute('aria-invalid');
            const queja = field.dataset.appDescribedError;
            if (queja) {
                const resto = (field.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (id) { return id && id !== queja; });
                resto.length ? field.setAttribute('aria-describedby', resto.join(' ')) : field.removeAttribute('aria-describedby');
                delete field.dataset.appDescribedError;
            }
        });
        form.querySelectorAll('[data-error-for]').forEach(function (feedback) {
            feedback.textContent = '';
            feedback.style.display = 'none';
        });
        form.querySelectorAll('[data-app-validation-feedback="1"]').forEach(function (feedback) {
            feedback.remove();
        });
        form.querySelectorAll('[data-app-error-summary="1"]').forEach(function (summary) {
            summary.remove();
        });
    }

    function validationFeedbackAnchor(field) {
        return field.closest('.input-group, .file-upload, .document-upload, [role="group"]')
            || (field.nextElementSibling?.classList.contains('select2') ? field.nextElementSibling : null)
            || field;
    }

    function showValidationErrors(form, errors = {}) {
        clearValidationErrors(form);
        if (!form || !errors || typeof errors !== 'object') {
            return false;
        }

        let firstInvalid = null;
        const summaryItems = [];
        Object.entries(errors).forEach(function ([name, message]) {
            // `deposito_referencia.1` señala el segundo `deposito_referencia[]`:
            // así la queja de un renglón queda debajo de ese renglón.
            const renglon = /^(.+)\.(\d+)$/.exec(name);
            const todos = Array.from(form.querySelectorAll(validationFieldSelector(renglon ? renglon[1] : name)));
            const fields = renglon ? todos.slice(Number(renglon[2]), Number(renglon[2]) + 1) : todos;
            if (fields.length === 0) {
                summaryItems.push({ message: String(message || 'Revise este dato.'), field: null });
                return;
            }

            fields.forEach(function (field) {
                field.classList.add('is-invalid');
                field.setAttribute('aria-invalid', 'true');
            });
            firstInvalid ||= fields[0];

            let feedback = form.querySelector(`[data-error-for="${CSS.escape(name)}"]`);
            if (!feedback) {
                feedback = document.createElement('div');
                feedback.className = 'invalid-feedback';
                feedback.dataset.errorFor = name;
                feedback.dataset.appValidationFeedback = '1';
                validationFeedbackAnchor(fields[fields.length - 1]).after(feedback);
            }
            feedback.textContent = String(message || 'Revise este campo.');
            feedback.style.display = 'block';

            const field = fields[0];
            field.id ||= 'campo-' + Math.random().toString(36).slice(2, 10);
            const label = field.labels?.[0]?.textContent?.replace('*', '').trim()
                || field.getAttribute('aria-label')
                || field.getAttribute('placeholder')
                || 'Campo';
            // Un grupo de casillas no se llama como su primera casilla.
            const esGrupo = fields.length > 1 && field.type === 'checkbox';
            summaryItems.push({ message: esGrupo ? feedback.textContent : label + ': ' + feedback.textContent, field });

            // El lector de pantalla decía «no válido» sin decir por qué: la
            // queja se enlaza al campo para que se lea al enfocarlo (bitácora 107).
            feedback.id ||= 'queja-' + Math.random().toString(36).slice(2, 10);
            fields.forEach(function (field) {
                const ids = (field.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
                if (!ids.includes(feedback.id)) {
                    field.setAttribute('aria-describedby', ids.concat(feedback.id).join(' '));
                }
                field.dataset.appDescribedError = feedback.id;
            });
        });

        if (summaryItems.length > 0) {
            const summary = document.createElement('div');
            const title = document.createElement('h2');
            const list = document.createElement('ul');
            const titleId = 'resumen-errores-' + Math.random().toString(36).slice(2, 10);
            summary.className = 'alert alert-danger pb-error-summary';
            summary.dataset.appErrorSummary = '1';
            summary.setAttribute('role', 'alert');
            summary.setAttribute('tabindex', '-1');
            summary.setAttribute('aria-labelledby', titleId);
            title.id = titleId;
            title.textContent = summaryItems.length === 1 ? 'Hay un dato por corregir' : `Hay ${summaryItems.length} datos por corregir`;
            summaryItems.forEach(function ({ message, field }) {
                const item = document.createElement('li');
                if (field) {
                    const link = document.createElement('a');
                    link.href = '#' + field.id;
                    link.textContent = message;
                    link.addEventListener('click', function (event) {
                        event.preventDefault();
                        field.focus();
                        field.scrollIntoView({ block: 'center' });
                    });
                    item.append(link);
                } else {
                    item.textContent = message;
                }
                list.append(item);
            });
            summary.append(title, list);
            form.prepend(summary);
            summary.focus({ preventScroll: true });
            summary.scrollIntoView({ behavior: 'smooth', block: 'start' });
            return true;
        }
        return firstInvalid !== null;
    }

    function setNearestTableLoading(source, loading = true) {
        const card = source?.closest?.('.module-card');
        const tableZone = card?.querySelector?.('.table-zone');

        if (!tableZone) {
            return;
        }

        tableZone.classList.toggle('is-loading', Boolean(loading));
        tableZone.setAttribute('aria-busy', loading ? 'true' : 'false');
    }

    let pendingServiceTableLoads = 0;

    function setAllTablesLoading(loading = true) {
        document.querySelectorAll('.table-zone table').forEach(function (table) {
            if (window.AppDataTables?.setLoading) {
                window.AppDataTables.setLoading(table, loading);
                return;
            }

            const zone = table.closest('.table-zone');
            zone?.classList.toggle('is-loading', Boolean(loading));
            zone?.setAttribute('aria-busy', loading ? 'true' : 'false');
        });
    }

    window.alerts = {
        success(message, title = 'Operación correcta') {
            return (window.Swal || window.Sweetalert2).fire({
                icon: 'success',
                title,
                text: message
            });
        },
        error(message, title = 'Ocurrió un error') {
            if (window.service?.isPageExiting?.()) {
                return Promise.resolve({ isDismissed: true });
            }
            return (window.Swal || window.Sweetalert2).fire({
                icon: 'error',
                title,
                text: message
            });
        },
        warning(message, title = 'Atención') {
            return (window.Swal || window.Sweetalert2).fire({
                icon: 'warning',
                title,
                text: message
            });
        },
        /**
         * Aviso de trabajo para una descarga o un proceso largo (B6, GEN-032),
         * como en RhToroV1. Devuelve con qué actualizarlo, cancelarlo y cerrarlo.
         */
        loading(title = 'Preparando el archivo', detail = '') {
            const swal = window.Swal || window.Sweetalert2;
            const caja = document.createElement('div');
            caja.className = 'd-flex flex-column align-items-center gap-2';
            const rueda = document.createElement('div');
            rueda.className = 'spinner-border text-primary';
            rueda.setAttribute('role', 'status');
            rueda.setAttribute('aria-hidden', 'true');
            const texto = document.createElement('p');
            texto.className = 'mb-0';
            texto.textContent = String(detail || '');
            caja.append(rueda, texto);

            let cancelado = false;
            const cancelaciones = [];

            swal.fire({
                title,
                html: caja,
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                showCancelButton: true,
                cancelButtonText: 'Cancelar'
            }).then(function (result) {
                if (result.dismiss !== swal.DismissReason.cancel) {
                    return;
                }
                cancelado = true;
                cancelaciones.forEach(function (accion) {
                    accion();
                });
            });

            return {
                update(message) {
                    texto.textContent = String(message ?? '');
                },
                onCancel(accion) {
                    if (cancelado) {
                        accion();
                        return;
                    }
                    cancelaciones.push(accion);
                },
                // Cierra sólo si el aviso visible es el propio, nunca el modal de otro flujo.
                close() {
                    if (swal.isVisible() && swal.getHtmlContainer()?.contains(caja)) {
                        swal.close();
                    }
                }
            };
        },
        confirm(message, title = 'Confirmar acción') {
            return (window.Swal || window.Sweetalert2).fire({
                icon: 'question',
                title,
                text: message,
                showCancelButton: true,
                confirmButtonText: 'Confirmar',
                cancelButtonText: 'Cancelar',
                reverseButtons: true,
                // Lo que se confirma no se deshace (concluir carga, cerrar
                // caja, borrar): un Enter de más no debe hacerlo (bitácora 107).
                focusCancel: true
            });
        }
    };

    window.ui = {
        makeScrollRegionFocusable,
        bindRemoteSelect,
        bindDateRange,
        bindAutoDateRange,
        syncCalendarRange,
        initialize(root = document) {
            initializeTooltips(root);
            initializeLabelAssociations(root);
            initializeModalAccessibility(root);
            initializeResponsiveTableHints(root);
            initializeRequiredHints(root);
            initializeSelect2(root);
            initializeFileUploads(root);
            initializeDates(root);
            initializeDateRanges(root);
        },
        refreshSelect2(root = document) {
            if (!window.jQuery || !window.jQuery.fn.select2) {
                return;
            }

            window.jQuery(root)
                .find('select[data-app-select2], select[data-select2]')
                .addBack('select[data-app-select2], select[data-select2]')
                .trigger('change.select2');
        },
        setFormReadonly(form, readonly = false) {
            if (!form) {
                return;
            }

            form.querySelectorAll('input, select, textarea').forEach(function (field) {
                if (field.type === 'hidden') {
                    return;
                }

                field.disabled = readonly;
            });

            form.querySelectorAll('[type="submit"], [data-readonly-hide]').forEach(function (button) {
                button.classList.toggle('d-none', readonly);
                button.disabled = readonly;
            });

            form.querySelectorAll('[data-bs-dismiss], .btn-close, [data-readonly-keep]').forEach(function (button) {
                button.disabled = false;
                button.classList.remove('d-none');
            });

            this.refreshSelect2(form);
        },
        resetFileUpload,
        clearValidationErrors,
        showValidationErrors,
        setNearestTableLoading,
        syncDates(root = document) {
            root.querySelectorAll('[data-app-date]').forEach(syncDate);
        },
        syncDateRanges(root = document) {
            root.querySelectorAll('[data-app-date-range]').forEach(syncDateRange);
        }
    };

    window.fileUpload = {
        initialize: initializeFileUploads,
        reset: resetFileUpload
    };

    function initializeShell() {
        const shell = document.querySelector('.app-shell');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('appSidebar');
        const sidebarBackdrop = document.getElementById('sidebarBackdrop');
        const collapseToggle = document.getElementById('sidebarCollapseToggle');
        const userMenuToggle = document.getElementById('userMenuToggle');
        const userMenuDropdown = document.getElementById('userMenuDropdown');
        const collapsedKey = 'plantilla.sidebar.collapsed';
        const scrollKey = 'plantilla.sidebar.scrollTop';
        const desktopSidebar = window.matchMedia('(min-width: 992px)');

        if (!shell) {
            return;
        }

        if (shell.dataset.shellInitialized === '1') {
            return;
        }

        shell.dataset.shellInitialized = '1';

        function syncSidebarMode() {
            const collapsed = desktopSidebar.matches
                && localStorage.getItem(collapsedKey) === '1';
            shell.classList.toggle('is-sidebar-collapsed', collapsed);
            collapseToggle?.setAttribute('aria-pressed', collapsed ? 'true' : 'false');

            if (desktopSidebar.matches) {
                document.body.classList.remove('is-sidebar-open');
                sidebarToggle?.setAttribute('aria-expanded', 'false');
                if (sidebar) {
                    sidebar.inert = false;
                }
                return;
            }

            const abierto = document.body.classList.contains('is-sidebar-open');
            sidebarToggle?.setAttribute('aria-expanded', abierto ? 'true' : 'false');
            if (sidebar) {
                sidebar.inert = !abierto;
            }
        }

        function setSidebarOpen(abierto, devuelveFoco = false) {
            document.body.classList.toggle('is-sidebar-open', abierto);
            sidebarToggle?.setAttribute('aria-expanded', abierto ? 'true' : 'false');
            if (sidebar && !desktopSidebar.matches) {
                sidebar.inert = !abierto;
            }
            if (!abierto && devuelveFoco) {
                sidebarToggle?.focus();
            }
        }

        function closeSidebar(devuelveFoco = false) {
            setSidebarOpen(false, devuelveFoco);
        }

        function closeUserMenu() {
            userMenuDropdown?.setAttribute('hidden', '');
            userMenuToggle?.setAttribute('aria-expanded', 'false');
        }

        function toggleUserMenu() {
            const isHidden = userMenuDropdown?.hasAttribute('hidden');
            if (isHidden) {
                userMenuDropdown.removeAttribute('hidden');
                userMenuToggle.setAttribute('aria-expanded', 'true');
                return;
            }

            closeUserMenu();
        }

        function saveSidebarScroll() {
            if (!sidebar) {
                return;
            }

            localStorage.setItem(scrollKey, String(sidebar.scrollTop));
        }

        function restoreSidebarScroll() {
            if (!sidebar) {
                return;
            }

            const stored = Number.parseInt(localStorage.getItem(scrollKey) || '', 10);
            const activeElement = sidebar.querySelector('.app-menu a.is-active, .app-menu__toggle[aria-expanded="true"]');

            window.requestAnimationFrame(function () {
                if (Number.isFinite(stored) && stored > 0) {
                    sidebar.scrollTop = stored;
                    return;
                }

                activeElement?.scrollIntoView({ block: 'center' });
            });
        }

        function bindMediaChange(mediaQuery, callback) {
            if (typeof mediaQuery.addEventListener === 'function') {
                mediaQuery.addEventListener('change', callback);
                return;
            }

            if (typeof mediaQuery.addListener === 'function') {
                mediaQuery.addListener(callback);
            }
        }

        syncSidebarMode();
        restoreSidebarScroll();
        bindMediaChange(desktopSidebar, syncSidebarMode);
        sidebar?.addEventListener('scroll', saveSidebarScroll, { passive: true });
        window.addEventListener('beforeunload', saveSidebarScroll);

        sidebarToggle?.addEventListener('click', function (event) {
            event.stopPropagation();
            closeUserMenu();
            setSidebarOpen(!document.body.classList.contains('is-sidebar-open'));
        });

        sidebarBackdrop?.addEventListener('click', function () {
            closeSidebar(true);
        });

        collapseToggle?.addEventListener('click', function () {
            if (!desktopSidebar.matches) {
                return;
            }
            closeUserMenu();
            const collapsed = shell.classList.toggle('is-sidebar-collapsed');
            localStorage.setItem(collapsedKey, collapsed ? '1' : '0');
            collapseToggle.setAttribute('aria-pressed', collapsed ? 'true' : 'false');
        });

        document.querySelectorAll('.app-menu__toggle').forEach(function (toggle) {
            toggle.addEventListener('click', function (event) {
                if (desktopSidebar.matches && shell.classList.contains('is-sidebar-collapsed')) {
                    event.preventDefault();
                    event.stopPropagation();
                    shell.classList.remove('is-sidebar-collapsed');
                    localStorage.setItem(collapsedKey, '0');
                    collapseToggle?.setAttribute('aria-pressed', 'false');
                }
            });
        });

        document.querySelectorAll('.app-menu a').forEach(function (link) {
            link.addEventListener('click', function () {
                saveSidebarScroll();
                closeSidebar();
            });
        });

        userMenuToggle?.addEventListener('click', function (event) {
            event.stopPropagation();
            closeSidebar();
            toggleUserMenu();
        });

        document.addEventListener('click', function (event) {
            if (!event.target.closest('#userMenu')) {
                closeUserMenu();
            }
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                const lateralAbierto = document.body.classList.contains('is-sidebar-open');
                const cuentaAbierta = userMenuDropdown && !userMenuDropdown.hasAttribute('hidden');
                if (lateralAbierto) {
                    closeSidebar(true);
                }
                if (cuentaAbierta) {
                    closeUserMenu();
                    userMenuToggle?.focus();
                }
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        initializeShell();
        window.ui.initialize();
    });

    let validationForm = null;
    let validationFormAt = 0;

    function setValidationForm(form) {
        if (!form) {
            return;
        }
        validationForm = form;
        validationFormAt = Date.now();
        clearValidationErrors(form);
    }

    document.addEventListener('submit', function (event) {
        setValidationForm(event.target.closest('form'));
    }, true);

    function fieldValidationMessage(field) {
        const validity = field.validity;
        if (validity.valueMissing) return 'Este campo es obligatorio.';
        if (field.form?.dataset.appValidationLang !== 'es' || validity.customError) {
            return field.validationMessage || 'Revise este campo.';
        }
        if (validity.badInput) return 'Capture un número válido.';
        if (validity.typeMismatch) {
            return field.type === 'email' ? 'Capture un correo electrónico válido.' : 'Capture una dirección válida.';
        }
        if (validity.patternMismatch) return field.title || 'El formato de este campo no es válido.';
        if (validity.tooShort) return `Capture al menos ${field.minLength} caracteres.`;
        if (validity.tooLong) return `Capture como máximo ${field.maxLength} caracteres.`;
        if (validity.rangeUnderflow) return `El valor mínimo es ${field.min}.`;
        if (validity.rangeOverflow) return `El valor máximo es ${field.max}.`;
        if (validity.stepMismatch) return field.step === '1' ? 'Capture un número entero.' : `Capture un valor en incrementos de ${field.step}.`;
        return 'Revise este campo.';
    }

    document.addEventListener('invalid', function (event) {
        const field = event.target.closest('input, select, textarea');
        const form = field?.form;
        if (!field || !form || !field.name) {
            return;
        }

        event.preventDefault();
        setValidationForm(form);
        const errors = {};
        form.querySelectorAll('input:invalid, select:invalid, textarea:invalid').forEach(function (invalidField) {
            const name = String(invalidField.name || '').replace(/\[\]$/, '');
            if (!name) {
                return;
            }
            errors[name] = fieldValidationMessage(invalidField);
        });
        showValidationErrors(form, errors);
    }, true);

    document.addEventListener('click', function (event) {
        const button = event.target.closest('button, [role="button"]');
        if (!button) {
            return;
        }
        setValidationForm(button.form || button.closest('.modal')?.querySelector('form'));
    }, true);

    function clearFieldValidation(event) {
        const field = event.target.closest('input, select, textarea');
        if (!field?.form || !field.classList.contains('is-invalid')) {
            return;
        }
        field.classList.remove('is-invalid');
        field.removeAttribute('aria-invalid');
        const name = String(field.name || '').replace(/\[\]$/, '');
        const feedback = field.form.querySelector(`[data-error-for="${CSS.escape(name)}"]`);
        if (feedback) {
            feedback.textContent = '';
            feedback.style.display = 'none';
        }
    }

    document.addEventListener('input', clearFieldValidation, true);
    document.addEventListener('change', clearFieldValidation, true);

    document.addEventListener('app:service-error', function (event) {
        const errors = event.detail?.error?.errors;
        if (!errors || typeof errors !== 'object' || Object.keys(errors).length === 0) {
            return;
        }
        const activeModalForm = document.querySelector('.modal.show form');
        const recentForm = Date.now() - validationFormAt <= 15000 ? validationForm : null;
        showValidationErrors(activeModalForm || recentForm, errors);
    });

    document.addEventListener('submit', function (event) {
        const form = event.target.closest('.module-filters');
        if (!form) {
            return;
        }

        form.querySelectorAll('[data-app-date-range]').forEach(syncDateRange);
        setNearestTableLoading(form, true);
    }, true);

    document.addEventListener('click', function (event) {
        const button = event.target.closest('.module-filters .filter-actions button');
        if (!button) {
            return;
        }

        if (String(button.id || '').toLowerCase().includes('export')) {
            return;
        }

        const form = button.closest('.module-filters');
        if (form?.hasAttribute('data-app-period-manual') && button.type !== 'submit') {
            return;
        }
        form?.querySelectorAll('[data-app-date-range]').forEach(syncDateRange);
        setNearestTableLoading(button, true);
    }, true);

    document.addEventListener('app:service-start', function () {
        pendingServiceTableLoads += 1;
        setAllTablesLoading(true);
    });

    document.addEventListener('app:service-end', function () {
        pendingServiceTableLoads = Math.max(0, pendingServiceTableLoads - 1);
        if (pendingServiceTableLoads > 0) {
            return;
        }

        window.setTimeout(function () {
            if (pendingServiceTableLoads === 0) {
                setAllTablesLoading(false);
            }
        }, 150);
    });

    function openServiceLink(event) {
        if (event.type === 'auxclick' && event.button !== 1) return;
        const link = event.target.closest('a[href]');
        if (!link || event.defaultPrevented) return;
        const action = window.service.fileLinkAction(link.href);
        if (!action) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        if (action === 'download') window.service.downloadFile(link.href);
        else window.service.openReport(link.href);
    }

    document.addEventListener('click', openServiceLink, true);
    document.addEventListener('auxclick', openServiceLink, true);

    document.addEventListener('click', async function (event) {
        const logout = event.target.closest('[data-action="logout"]');
        if (!logout) {
            return;
        }

        event.preventDefault();

        try {
            const result = await window.alerts.confirm(
                'La sesión actual se cerrará.',
                '¿Cerrar sesión?'
            );
            if (!result.isConfirmed) {
                return;
            }
            await window.service.request('Auth', 'logout');
            window.location.href = logout.href;
        } catch (exception) {
            if (exception?.name !== 'AbortError' && !window.service.isPageExiting()) {
                window.alerts.error(exception.message);
            }
        }
    });
})();
