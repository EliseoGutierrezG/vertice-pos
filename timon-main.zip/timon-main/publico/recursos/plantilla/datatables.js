(function (window) {
    'use strict';

    const language = {
        processing: 'Cargando información…',
        search: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
        searchPlaceholder: 'Buscar',
        lengthMenu: 'Mostrar: _MENU_',
        info: 'Mostrando página _PAGE_ de _PAGES_',
        infoEmpty: 'Sin datos',
        infoFiltered: '(filtrado de _MAX_ registros)',
        loadingRecords: 'Cargando…',
        zeroRecords: 'Sin resultados',
        emptyTable: 'Sin datos',
        paginate: {
            first: 'Primera',
            previous: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-label="Anterior"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
            next: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-label="Siguiente"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>',
            last: 'Última'
        },
        aria: {
            sortAscending: ': ordenar ascendente',
            sortDescending: ': ordenar descendente'
        }
    };

    function available() {
        return Boolean(
            window.jQuery
            && window.jQuery.fn
            && window.jQuery.fn.DataTable
            && window.jQuery.fn.dataTable
        );
    }

    function resolveTable(table) {
        return typeof table === 'string' ? document.querySelector(table) : table;
    }

    function text(value) {
        const element = document.createElement('span');
        element.textContent = value ?? '';
        return element.innerHTML;
    }

    function actionLink(action, id, icon, label) {
        return `
            <a href="javascript:void(0);" class="label-default action-link"
                data-action="${text(action)}" data-id="${text(id)}" title="${text(label)}">
                <i class="fa ${text(icon)}"></i> ${text(label)}
            </a><br>
        `;
    }

    function fileExtension(fileName = '') {
        const extension = String(fileName).split('.').pop().toLowerCase();
        return extension === String(fileName).toLowerCase() ? '' : extension;
    }

    function fileTypeClass(fileName = '') {
        const extension = fileExtension(fileName);
        if (['xls', 'xlsx', 'csv'].includes(extension)) return 'app-file-icon--excel';
        if (['doc', 'docx'].includes(extension)) return 'app-file-icon--word';
        if (['jpg', 'jpeg', 'png', 'gif'].includes(extension)) return 'app-file-icon--image';
        if (['zip', 'rar'].includes(extension)) return 'app-file-icon--archive';
        if (extension === 'pdf') return 'app-file-icon--pdf';
        if (extension === 'xml') return 'app-file-icon--xml';
        return 'app-file-icon--default';
    }

    function fileIcon(fileName = '') {
        const extension = fileExtension(fileName);
        const icons = {
            pdf: 'fa-file-pdf-o',
            xls: 'fa-file-excel-o',
            xlsx: 'fa-file-excel-o',
            csv: 'fa-file-excel-o',
            doc: 'fa-file-word-o',
            docx: 'fa-file-word-o',
            jpg: 'fa-file-image-o',
            jpeg: 'fa-file-image-o',
            png: 'fa-file-image-o',
            gif: 'fa-file-image-o',
            zip: 'fa-file-archive-o',
            rar: 'fa-file-archive-o',
            xml: 'fa-code'
        };

        return icons[extension] || 'fa-file-o';
    }

    function fileLink(module, id, fileName = 'Archivo', options = {}) {
        if (!id) {
            return options.empty ?? '';
        }

        const label = fileName || 'Archivo';
        const classes = options.classes || `label-default action-link file-icon-link app-file-icon ${fileTypeClass(label)}`;
        const icon = options.icon || fileIcon(label);
        const url = window.service.fileUrl('download', module, { id });

        return `
            <a href="${url}" class="${text(classes)}" target="_blank" rel="noopener"
                title="${text(label)}" aria-label="${text(label)}">
                <i class="fa ${text(icon)}"></i>
            </a>
        `;
    }

    function fileActions(module, id, fileName = 'Archivo') {
        if (!id) return '';
        const name = text(fileName || 'Archivo').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        const preview = text(window.service.fileUrl('preview', module, { id }));
        const download = text(window.service.fileUrl('download', module, { id }));
        return `<span class="document-item__actions d-inline-flex flex-wrap gap-2">
            <a class="btn btn-sm btn-outline-secondary" href="${preview}" target="_blank" rel="noopener" aria-label="Ver ${name}"><i class="bi bi-eye" aria-hidden="true"></i> Ver</a>
            <a class="btn btn-sm btn-outline-primary" href="${download}" aria-label="Descargar ${name}"><i class="bi bi-download" aria-hidden="true"></i> Descargar</a>
        </span>`;
    }

    function fileIconOnly(fileName = 'Archivo', options = {}) {
        const label = fileName || 'Archivo';
        const classes = options.classes || `file-icon-link app-file-icon ${fileTypeClass(label)}`;
        const icon = options.icon || fileIcon(label);

        return `
            <span class="${text(classes)}" title="${text(label)}" aria-label="${text(label)}">
                <i class="fa ${text(icon)}"></i>
            </span>
        `;
    }

    function badge(label, classes = 'text-bg-secondary') {
        return `<span class="badge rounded-pill ${text(classes)}">${text(label)}</span>`;
    }

    function emptyCard(icon, title, message) {
        return `
            <article class="card record-card--empty">
                <div class="card-body text-center">
                    <i class="bi ${text(icon)}"></i>
                    <strong class="d-block">${text(title)}</strong>
                    <span>${text(message)}</span>
                </div>
            </article>
        `;
    }

    function destroy(table) {
        const element = resolveTable(table);
        if (!element || !available()) {
            return;
        }

        if (window.jQuery.fn.dataTable.isDataTable(element)) {
            window.jQuery(element).DataTable().destroy();
        }
    }

    function tableZone(instanceOrTable) {
        const element = instanceOrTable?.table
            ? instanceOrTable.table().node()
            : resolveTable(instanceOrTable);

        return element?.closest('.table-zone') || null;
    }

    function setLoading(instanceOrTable, loading = true) {
        const zone = tableZone(instanceOrTable);
        if (!zone) {
            return;
        }

        zone.classList.toggle('is-loading', Boolean(loading));
        zone.setAttribute('aria-busy', loading ? 'true' : 'false');
    }

    function mobileCardsForTable(element) {
        const zone = element?.closest('.table-zone');
        if (!zone) return null;

        let sibling = zone.nextElementSibling;
        while (sibling && sibling.matches('script, template')) {
            sibling = sibling.nextElementSibling;
        }
        return sibling?.classList.contains('record-cards') ? sibling : null;
    }

    function ensureMobilePagination(element, api) {
        const cards = mobileCardsForTable(element);
        if (!cards || !api) return;

        let pager = cards.nextElementSibling;
        if (!pager?.classList.contains('record-cards-pagination')) {
            pager = document.createElement('nav');
            pager.className = 'record-cards-pagination';
            pager.setAttribute('aria-label', `Paginación de ${element.getAttribute('aria-label') || 'registros'}`);
            pager.innerHTML = `
                <button class="btn btn-outline-secondary" type="button" data-mobile-page="previous">
                    <i class="bi bi-chevron-left" aria-hidden="true"></i> Anterior
                </button>
                <span data-mobile-page-status aria-live="polite">Página 1 de 1</span>
                <button class="btn btn-outline-secondary" type="button" data-mobile-page="next">
                    Siguiente <i class="bi bi-chevron-right" aria-hidden="true"></i>
                </button>
            `;
            cards.after(pager);
            pager.addEventListener('click', function (event) {
                const button = event.target.closest('[data-mobile-page]');
                if (!button || !available() || !window.jQuery.fn.dataTable.isDataTable(element)) return;
                window.jQuery(element).DataTable().page(button.dataset.mobilePage).draw('page');
            });
        }

        const info = api.page.info();
        const pageCount = Math.max(1, Number(info.pages || 0));
        const page = Math.min(Number(info.page || 0), pageCount - 1);
        const previous = pager.querySelector('[data-mobile-page="previous"]');
        const next = pager.querySelector('[data-mobile-page="next"]');
        const status = pager.querySelector('[data-mobile-page-status]');
        pager.hidden = Number(info.pages || 0) <= 1;
        previous.disabled = page <= 0;
        next.disabled = Number(info.pages || 0) === 0 || page >= pageCount - 1;
        status.textContent = `Página ${page + 1} de ${pageCount} · ${Number(info.recordsDisplay || 0)} registros`;
    }

    function create(options) {
        const element = resolveTable(options.table);
        if (!element) {
            throw new Error('No se encontró la tabla solicitada.');
        }
        if (!available()) {
            throw new Error('DataTables no está disponible.');
        }

        destroy(element);
        element.classList.add(
            'table',
            'table-striped',
            'table-bordered',
            'table-hover',
            'dataTable',
            'align-middle'
        );

        const onDraw = options.onDraw;
        element.__appDataTableOnDraw = onDraw;
        const config = {
            autoWidth: false,
            deferRender: true,
            processing: true,
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
            dom: "<'dt--top-section'<'row'<'col-sm-12 col-md-6 d-flex justify-content-md-start justify-content-center'l><'col-sm-12 col-md-6 d-flex justify-content-md-end justify-content-center mt-md-0 mt-3'f>>>" +
                "<'table-responsive'tr>" +
                "<'dt--bottom-section d-sm-flex justify-content-sm-between text-center'<'dt--pages-count mb-sm-0 mb-3'i><'dt--pagination'p>>",
            language,
            ...(options.config || {})
        };

        const originalDraw = config.drawCallback;
        config.drawCallback = function (settings) {
            if (typeof originalDraw === 'function') {
                originalDraw.call(this, settings);
            }
            if (typeof onDraw === 'function') {
                const api = this.api();
                onDraw(api.rows({ page: 'current' }).data().toArray(), api);
            }
            ensureMobilePagination(element, this.api());
        };

        const instance = window.jQuery(element).DataTable(config);
        setLoading(instance, true);
        return instance;
    }

    function replaceData(instance, items) {
        if (!instance) {
            return;
        }
        const element = instance.table().node();
        instance.clear();
        instance.rows.add(Array.isArray(items) ? items : []);
        instance.draw();
        setLoading(instance, false);

        const refreshCards = function () {
            if (!element?.isConnected || !available() || !window.jQuery.fn.dataTable.isDataTable(element)) {
                return;
            }
            const currentInstance = window.jQuery(element).DataTable();
            const onDraw = element?.__appDataTableOnDraw;
            if (typeof onDraw === 'function') {
                onDraw(currentInstance.rows({ page: 'current' }).data().toArray(), currentInstance);
            }
            ensureMobilePagination(element, currentInstance);
        };
        if (typeof window.queueMicrotask === 'function') {
            window.queueMicrotask(refreshCards);
        } else {
            Promise.resolve().then(refreshCards);
        }
    }

    window.AppDataTables = {
        available,
        create,
        destroy,
        replaceData,
        setLoading,
        text,
        actionLink,
        fileExtension,
        fileTypeClass,
        fileIcon,
        fileLink,
        fileActions,
        fileIconOnly,
        badge,
        emptyCard,
        language
    };

    if (available()) {
        window.jQuery(document).on('draw.dt.appMobilePagination', function (_event, settings) {
            const api = new window.jQuery.fn.dataTable.Api(settings);
            ensureMobilePagination(api.table().node(), api);
        });
    }
})(window);
