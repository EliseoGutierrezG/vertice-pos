'use strict';

for (const plano of document.querySelectorAll('.plano-editor')) {
    const estado = document.querySelector('[data-plano-estado]');
    const limita = numero => Math.min(100, Math.max(0, Math.round(numero)));
    const pinta = (boton, x, y) => {
        boton.style.left = `calc(35px + (100% - 70px) * ${x / 100})`;
        boton.style.top = `calc(35px + (100% - 70px) * ${y / 100})`;
    };
    for (const boton of plano.querySelectorAll('[data-mesa]')) {
        let x = Number(boton.dataset.x);
        let y = Number(boton.dataset.y);
        let puntero = null;
        let guardando = false;
        pinta(boton, x, y);
        if (boton.disabled) continue;

        async function guarda(nuevoX, nuevoY) {
            if (guardando || (x === nuevoX && y === nuevoY)) return;
            guardando = true;
            try {
                const respuesta = await fetch(`/mesas/${boton.dataset.mesa}/posicion`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Marca': plano.dataset.marca },
                    body: JSON.stringify({ sucursal: plano.dataset.sucursal, x: nuevoX, y: nuevoY }),
                });
                if (!respuesta.ok) throw new Error('No se pudo guardar la posición.');
                x = nuevoX;
                y = nuevoY;
                estado.textContent = `Mesa ${boton.querySelector('strong').textContent} guardada en ${x}%, ${y}%.`;
            } catch {
                estado.textContent = 'No se pudo guardar la posición. Intente de nuevo.';
            } finally {
                pinta(boton, x, y);
                guardando = false;
            }
        }

        const posicion = evento => {
            const rect = plano.getBoundingClientRect();
            return [
                limita(100 * (evento.clientX - rect.left - 35) / Math.max(1, rect.width - 70)),
                limita(100 * (evento.clientY - rect.top - 35) / Math.max(1, rect.height - 70)),
            ];
        };
        boton.addEventListener('pointerdown', evento => {
            if (guardando || evento.button !== 0) return;
            puntero = evento.pointerId;
            boton.setPointerCapture(puntero);
        });
        boton.addEventListener('pointermove', evento => {
            if (evento.pointerId === puntero) pinta(boton, ...posicion(evento));
        });
        boton.addEventListener('pointerup', evento => {
            if (evento.pointerId !== puntero) return;
            puntero = null;
            void guarda(...posicion(evento));
        });
        boton.addEventListener('pointercancel', () => { puntero = null; pinta(boton, x, y); });
        boton.addEventListener('keydown', evento => {
            const delta = { ArrowDown: [0, 5], ArrowUp: [0, -5], ArrowLeft: [-5, 0], ArrowRight: [5, 0] }[evento.key];
            if (!delta) return;
            evento.preventDefault();
            void guarda(limita(x + delta[0]), limita(y + delta[1]));
        });
    }
}
