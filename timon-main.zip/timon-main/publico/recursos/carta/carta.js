// La hoja de la carta.
//
// - Con `imprimir=1` se manda a imprimir sola, pero hasta que cargaron las
//   fuentes y las ilustraciones: si no, el PDF sale con la letra de respaldo.
// - Abierta en una pantalla angosta, se ve completa a escala. Dentro de la
//   pantalla Carta no hace falta: ahí la escala la pone el panel.
(function () {
  var cuerpo = document.body;
  var enMarco = window.self !== window.top;

  function escala() {
    if (enMarco) { return; }
    var hoja = document.querySelector('.hoja');
    if (!hoja) { return; }
    var disponible = document.documentElement.clientWidth - 16;
    var factor = Math.min(1, disponible / hoja.offsetWidth);
    cuerpo.style.zoom = factor < 1 ? String(factor) : '';
  }

  escala();
  window.addEventListener('resize', escala);

  if (cuerpo.hasAttribute('data-imprimir')) {
    window.addEventListener('load', function () {
      var listas = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
      listas.then(function () {
        cuerpo.style.zoom = '';
        window.print();
      });
    });
    window.addEventListener('afterprint', escala);
  }
})();
