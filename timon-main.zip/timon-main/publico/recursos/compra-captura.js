'use strict';
{
    const lista = document.querySelector('[data-compra-lineas]');
    const plantilla = document.querySelector('[data-compra-linea]');
    const agrega = document.querySelector('[data-compra-agrega]');
    let numero = 0;

    function ordena() {
        [...lista.children].forEach(function (linea, indice) {
            linea.querySelector('[data-compra-leyenda]').textContent = 'Renglón ' + (indice + 1);
            linea.querySelector('[data-compra-quita]').disabled = lista.children.length === 1;
            linea.querySelectorAll('[data-campo-compra]').forEach(function (campo) {
                campo.name = 'lineas[' + indice + '][' + campo.dataset.campoCompra + ']';
            });
        });
        agrega.disabled = lista.children.length >= 100;
    }

    function nueva(enfoca) {
        const linea = plantilla.content.firstElementChild.cloneNode(true);
        numero += 1;
        linea.querySelectorAll('[name]').forEach(function (campo) {
            campo.dataset.campoCompra = campo.name;
            const etiqueta = linea.querySelector('label[for="' + CSS.escape(campo.id) + '"]');
            campo.id += '-' + numero;
            if (etiqueta) etiqueta.htmlFor = campo.id;
        });
        linea.querySelector('[data-compra-quita]').addEventListener('click', function () {
            linea.remove();
            ordena();
            agrega.focus();
        });
        lista.append(linea);
        ordena();
        if (enfoca) linea.querySelector('select').focus();
    }

    if (lista && plantilla && agrega) {
        agrega.addEventListener('click', function () { nueva(true); });
        nueva(false);
    }
}
