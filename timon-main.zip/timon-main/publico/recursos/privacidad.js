/* Pone en la descarga y en la anonimización el número de titular que se escribió. */
(function () {
    'use strict';

    document.querySelectorAll('[data-pb-privacidad]').forEach(function (formulario) {
        const tipo = formulario.getAttribute('data-pb-privacidad');
        const numero = formulario.querySelector('[name="numero"]');
        const descarga = formulario.querySelector('[data-pb-privacidad-descarga]');
        const actualiza = function () {
            const id = parseInt(numero.value, 10);
            const valido = Number.isInteger(id) && id > 0;
            formulario.action = '/privacidad/' + tipo + '/' + (valido ? id : 0) + '/anonimizar';
            descarga.href = valido ? '/privacidad/' + tipo + '/' + id + '/datos' : '#';
            descarga.classList.toggle('disabled', !valido);
            descarga.setAttribute('aria-disabled', valido ? 'false' : 'true');
        };
        numero.addEventListener('input', actualiza);
        actualiza();
    });
}());
