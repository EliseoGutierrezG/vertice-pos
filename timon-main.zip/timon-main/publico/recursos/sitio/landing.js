'use strict';

const lista = document.getElementById('lista-sucursales');
const estadoSucursales = document.getElementById('estado-sucursales');
const formulario = document.getElementById('forma-reserva');
const opciones = document.getElementById('sucursal-reserva');
const aviso = document.getElementById('estado-reserva');
const enviar = formulario.querySelector('button[type=submit]');
const nodo = (tipo, texto, padre) => {
    const elemento = document.createElement(tipo);
    elemento.textContent = texto;
    padre.append(elemento);
    return elemento;
};
const enlace = (texto, href, padre, clase) => {
    const a = nodo('a', texto, padre);
    a.href = href;
    if (clase) a.className = clase;
    if (/^https?:/.test(href)) { a.target = '_blank'; a.rel = 'noopener'; }
    return a;
};

// Los trazos de los iconos. Se arman con el DOM: la CSP no deja meter HTML de
// cadenas.
const SVG = 'http://www.w3.org/2000/svg';
const trazos = {
    lugar: 'M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21Z M12 12.2a2.6 2.6 0 1 0 0-5.2 2.6 2.6 0 0 0 0 5.2Z',
    reloj: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z M12 7v5l3 2',
    telefono: 'M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z',
    mensaje: 'M4 20l1.4-4.2A8 8 0 1 1 8.6 19L4 20Z',
};
function icono(trazo, padre) {
    const svg = document.createElementNS(SVG, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    const camino = document.createElementNS(SVG, 'path');
    camino.setAttribute('d', trazos[trazo]);
    svg.append(camino);
    padre.append(svg);
    return svg;
}
function dato(trazo, titulo, padre) {
    const fila = nodo('div', '', padre);
    fila.className = 'dato';
    icono(trazo, fila);
    const cuerpo = nodo('div', '', fila);
    nodo('small', titulo, cuerpo);
    return cuerpo;
}

const DIAS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
// 1 = lunes … 7 = domingo, como `sucursal_horario`.
const hoy = ((new Date().getDay() + 6) % 7) + 1;
const telefonoVisible = t => /^\d{10}$/.test(t) ? t.replace(/(\d{3})(\d{3})(\d{4})/, '$1 $2 $3') : t;
const whatsappDe = s => /^\d{10,15}$/.test(s.whatsapp_publico ?? '') ? s.whatsapp_publico : '';
const direccionDe = s => [[s.calle, s.numero].filter(Boolean).join(' '), s.colonia, s.cp ? 'C. P. ' + s.cp : '', s.estado]
    .filter(Boolean).join(', ');
const mapaDe = s => 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(
    s.latitud !== null && s.longitud !== null ? s.latitud + ',' + s.longitud : 'El Timón ' + direccionDe(s));
const estadoDe = s => s.abierta === null ? '' : s.abierta ? 'Abierto ahora · cierra ' + s.cierra : 'Cerrado ahora';

function tarjetaSucursal(sucursal) {
    const tarjeta = nodo('article', '', lista);
    tarjeta.className = 'sucursal';
    tarjeta.id = 'sucursal-' + sucursal.clave.toLowerCase();
    const columna = nodo('div', '', tarjeta);
    columna.className = 'sucursal-datos';
    const encabezado = nodo('div', '', columna);
    encabezado.className = 'sucursal-encabezado';
    nodo('h3', sucursal.nombre, encabezado);
    const estado = estadoDe(sucursal);
    if (estado) nodo('span', estado, encabezado).className = 'insignia-abierto' + (sucursal.abierta ? ' abierta' : '');

    const direccion = direccionDe(sucursal);
    nodo('span', direccion || 'Consulte la dirección por teléfono', dato('lugar', 'Dirección', columna));
    if (sucursal.telefono) enlace(telefonoVisible(sucursal.telefono), 'tel:' + sucursal.telefono.replace(/\D/g, ''), dato('telefono', 'Teléfono', columna));
    const whatsapp = whatsappDe(sucursal);
    if (whatsapp) enlace('Pedidos y reservaciones', 'https://wa.me/' + whatsapp, dato('mensaje', 'WhatsApp', columna));

    const panel = nodo('div', '', tarjeta);
    panel.className = 'sucursal-horario';
    const titulo = nodo('p', '', panel);
    titulo.className = 'horario-titulo';
    icono('reloj', titulo);
    titulo.append('Horario');
    if (sucursal.horarios?.length) {
        const dias = new Map(sucursal.horarios.map(h => [Number(h.dia), h]));
        const tabla = nodo('dl', '', panel);
        tabla.className = 'horario';
        DIAS.forEach((nombre, i) => {
            const turno = dias.get(i + 1);
            const fila = nodo('div', '', tabla);
            if (i + 1 === hoy) { fila.className = 'hoy'; fila.setAttribute('aria-current', 'date'); }
            nodo('dt', nombre + (i + 1 === hoy ? ' (hoy)' : ''), fila);
            nodo('dd', turno ? turno.abre + ' – ' + turno.cierra : 'Cerrado', fila);
        });
    } else {
        nodo('p', sucursal.horario_publico || 'Consulte el horario por teléfono.', panel).className = 'horario-libre';
    }
    const acciones = nodo('div', '', panel);
    acciones.className = 'sucursal-acciones';
    enlace('Cómo llegar', mapaDe(sucursal), acciones, 'boton boton-chico');
    enlace('Ver menú', '/menu/' + encodeURIComponent(sucursal.clave), acciones, 'boton boton-chico boton-claro');
    const reservar = enlace('Reservar aquí', '#reservar', acciones, 'boton boton-chico boton-claro');
    reservar.addEventListener('click', () => {
        opciones.value = sucursal.clave;
        setTimeout(() => formulario.elements.cliente.focus({ preventScroll: true }), 450);
    });
}

// El pie lleva las direcciones y teléfonos de todas las sucursales.
function pieSucursales(sucursales) {
    const pie = document.getElementById('pie-sucursales');
    for (const sucursal of sucursales) {
        const bloque = nodo('div', '', pie);
        bloque.className = 'pie-sucursal';
        nodo('strong', sucursal.nombre, bloque);
        const direccion = direccionDe(sucursal);
        if (direccion) nodo('span', direccion, bloque);
        if (sucursal.telefono) enlace(telefonoVisible(sucursal.telefono), 'tel:' + sucursal.telefono.replace(/\D/g, ''), bloque);
    }
    pie.hidden = !sucursales.length;
}

// Para buscadores: un Restaurant por sucursal, con su dirección y horario.
function datosEstructurados(sucursales) {
    const dia = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const grafo = sucursales.map(s => ({
        '@type': 'Restaurant',
        name: 'El Timón ' + s.nombre,
        servesCuisine: 'Mariscos',
        acceptsReservations: 'True',
        menu: location.origin + '/menu/' + s.clave,
        telephone: s.telefono || undefined,
        address: { '@type': 'PostalAddress', streetAddress: [s.calle, s.numero].filter(Boolean).join(' ') || undefined,
            addressLocality: s.colonia || undefined, postalCode: s.cp || undefined, addressRegion: s.estado || undefined, addressCountry: 'MX' },
        geo: s.latitud !== null && s.longitud !== null ? { '@type': 'GeoCoordinates', latitude: s.latitud, longitude: s.longitud } : undefined,
        openingHoursSpecification: (s.horarios ?? []).map(h => ({ '@type': 'OpeningHoursSpecification',
            dayOfWeek: dia[Number(h.dia) - 1], opens: h.abre, closes: h.cierra })),
    }));
    const guion = document.createElement('script');
    guion.type = 'application/ld+json';
    guion.textContent = JSON.stringify({ '@context': 'https://schema.org', '@graph': grafo });
    document.head.append(guion);
}

// El héroe dice si hay una sucursal abierta en este momento.
function estadoHeroe(sucursales) {
    const conHorario = sucursales.filter(s => s.abierta !== null);
    if (!conHorario.length) return;
    const abiertas = conHorario.filter(s => s.abierta);
    const texto = document.getElementById('estado-abierto-texto');
    if (!abiertas.length) texto.textContent = sucursales.length === 1 ? 'Cerrado ahora' : 'Todas las sucursales cerradas ahora';
    else if (sucursales.length === 1) texto.textContent = 'Abierto ahora · cierra ' + abiertas[0].cierra;
    else texto.textContent = abiertas.length === 1 ? 'Abierto ahora en ' + abiertas[0].nombre : abiertas.length + ' sucursales abiertas ahora';
    document.getElementById('estado-abierto').classList.toggle('abierto', abiertas.length > 0);
}

// Para llevar y la barra del celular usan el WhatsApp y el teléfono publicados.
function contacto(sucursales) {
    const conWhatsapp = sucursales.filter(whatsappDe);
    const conTelefono = sucursales.find(s => s.telefono);
    const llamar = document.getElementById('movil-llamar');
    if (conTelefono) llamar.href = 'tel:' + conTelefono.telefono.replace(/\D/g, '');
    if (!conWhatsapp.length) return;
    const pedido = s => 'https://wa.me/' + whatsappDe(s) + '?text=' + encodeURIComponent('Hola, quiero hacer un pedido para llevar en El Timón ' + s.nombre + '.');
    const boton = document.getElementById('enlace-llevar');
    const elige = document.getElementById('sucursal-llevar');
    const pon = clave => {
        const s = conWhatsapp.find(x => x.clave === clave) ?? conWhatsapp[0];
        boton.href = pedido(s);
        boton.target = '_blank';
    };
    for (const s of conWhatsapp) nodo('option', s.nombre, elige).value = s.clave;
    document.getElementById('llevar-sucursal').hidden = conWhatsapp.length < 2;
    elige.addEventListener('change', () => pon(elige.value));
    pon(conWhatsapp[0].clave);
    document.getElementById('para-llevar').hidden = false;

    const flotante = document.getElementById('whatsapp-flotante');
    const movil = document.getElementById('movil-whatsapp');
    flotante.href = movil.href = 'https://wa.me/' + whatsappDe(conWhatsapp[0]);
    flotante.target = movil.target = '_blank';
    flotante.hidden = movil.hidden = false;
}

async function carga() {
    try {
        const respuesta = await fetch('/api/v1/sucursales-publicas');
        const datos = await respuesta.json();
        if (!respuesta.ok || !Array.isArray(datos.datos)) throw new Error();
        const sucursales = datos.datos;
        estadoSucursales.textContent = sucursales.length ? '' : 'Pronto podrá consultar las sucursales.';
        if (sucursales.length) {
            document.getElementById('cifra-sucursales').textContent = String(sucursales.length);
            document.getElementById('cifra-sucursales-texto').textContent = sucursales.length === 1 ? 'Sucursal' : 'Sucursales';
        }
        for (const sucursal of sucursales) {
            tarjetaSucursal(sucursal);
            nodo('option', sucursal.nombre, opciones).value = sucursal.clave;
        }
        if (sucursales.length === 1) opciones.value = sucursales[0].clave;
        enviar.disabled = !sucursales.length;
        estadoHeroe(sucursales);
        contacto(sucursales);
        pieSucursales(sucursales);
        if (sucursales.length) datosEstructurados(sucursales);
        preparaMenu(sucursales);
    } catch {
        estadoSucursales.textContent = 'No pudimos cargar las sucursales. Recargue la página.';
        avisoMenu('No pudimos cargar el menú. Recargue la página.');
    }
}

// El menú completo de una sucursal, con un filtro por categoría. Los precios
// cambian por sucursal, así que con más de una se elige de cuál.
const carta = document.getElementById('carta-portada');
const filtros = document.getElementById('filtros-menu');
const estadoMenu = document.getElementById('estado-menu');
// El aviso del menú: con giro mientras carga, solo texto si algo falta, y se
// esconde cuando ya hay platillos.
function avisoMenu(texto, girando = false) {
    estadoMenu.hidden = texto === '';
    document.getElementById('giro-menu').hidden = !girando;
    document.getElementById('estado-menu-texto').textContent = texto;
}
const eligeSucursal = document.getElementById('sucursal-menu');
const enlaceMenu = document.getElementById('enlace-menu');
const pesos = n => '$' + (Number.isInteger(n) ? n.toLocaleString('es-MX') : n.toLocaleString('es-MX', { minimumFractionDigits: 2 }));
// Mientras un platillo no tenga foto propia, se usa una de muestra del mismo
// tipo de plato; si ninguna se parece, va el nombre de la categoría.
const muestras = [
    [/aguachile/i, 'aguachile-verde'], [/diabla/i, 'camarones-diabla'], [/c[oó]ctel|campechana/i, 'coctel-camaron'],
    [/ceviche/i, 'ceviche-cebolla'], [/tostada/i, 'tostada-atun'], [/osti[oó]n/i, 'ostiones'], [/pulpo/i, 'pulpo-brasa'],
    [/zarandeado|pescado|filete|huachinango|mojarra/i, 'pescado-zarandeado'], [/caldo|sopa|7 mares|siete mares/i, 'caldo-mariscos'],
    [/mariscada|parrillada/i, 'mariscada'], [/taco/i, 'tacos-pescado'], [/camar[oó]n/i, 'camarones-ajillo'],
    [/michelada|cerveza|clamato/i, 'michelada'], [/agua|jamaica|limonada|horchata/i, 'agua-jamaica'],
];
// Una muestra no se repite: si ya la usa otro platillo, mejor el nombre de la
// categoría que dos tarjetas con la misma foto.
function fotoDe(platillo, usadas) {
    if (platillo.foto) return platillo.foto;
    const muestra = muestras.find(([patron]) => patron.test(platillo.nombre));
    const ruta = muestra ? '/recursos/menu/' + muestra[1] + '.webp' : '';
    return usadas.has(ruta) ? '' : ruta;
}

function preparaMenu(sucursales) {
    if (!sucursales.length) {
        avisoMenu('Pronto publicaremos el menú.');
        return;
    }
    for (const sucursal of sucursales) nodo('option', sucursal.nombre, eligeSucursal).value = sucursal.clave;
    document.getElementById('menu-sucursal').hidden = sucursales.length < 2;
    eligeSucursal.addEventListener('change', () => cargaMenu(eligeSucursal.value));
    void cargaMenu(sucursales[0].clave);
}

async function cargaMenu(clave) {
    avisoMenu('Cargando el menú…', true);
    carta.replaceChildren();
    filtros.hidden = true;
    try {
        const respuesta = await fetch('/api/v1/menu-publico/' + encodeURIComponent(clave));
        const { datos } = await respuesta.json();
        if (!respuesta.ok || !Array.isArray(datos?.platillos)) throw new Error();
        pintaMenu(datos);
        especialidades(datos.platillos);
        if (datos.platillos.length) {
            document.getElementById('cifra-platillos').textContent = String(datos.platillos.length);
            document.getElementById('cifras').hidden = false;
        }
    } catch {
        avisoMenu('No pudimos cargar el menú. Recargue la página.');
    }
}

function pintaMenu({ sucursal, platillos }) {
    carta.replaceChildren();
    filtros.replaceChildren();
    enlaceMenu.href = '/menu/' + encodeURIComponent(sucursal.clave);
    enlaceMenu.textContent = 'Abrir el menú de ' + sucursal.nombre;
    avisoMenu(platillos.length ? '' : 'Esta sucursal aún no publica su menú.');
    filtros.hidden = !platillos.length;

    const categorias = [...new Set(platillos.map(p => p.categoria))];
    const botones = [];
    const filtra = categoria => {
        for (const boton of botones) boton.setAttribute('aria-pressed', String(boton.dataset.categoria === categoria));
        let orden = 0;
        for (const tarjeta of carta.children) {
            tarjeta.hidden = categoria !== '' && tarjeta.dataset.categoria !== categoria;
            if (tarjeta.hidden) continue;
            // Como en una carta impresa: una alta, dos bajas, dos altas.
            tarjeta.classList.toggle('alto', [0, 3, 4].includes(orden % 5));
            tarjeta.style.setProperty('--orden', String(Math.min(orden, 12)));
            orden++;
        }
    };
    for (const [nombre, valor] of [['Todos', ''], ...categorias.map(c => [c, c])]) {
        const boton = nodo('button', nombre, filtros);
        boton.type = 'button';
        boton.dataset.categoria = valor;
        nodo('small', String(valor === '' ? platillos.length : platillos.filter(p => p.categoria === valor).length), boton);
        boton.addEventListener('click', () => filtra(valor));
        botones.push(boton);
    }

    const usadas = new Set(platillos.map(p => p.foto).filter(Boolean));
    for (const platillo of platillos) {
        const tarjeta = nodo('article', '', carta);
        tarjeta.className = 'platillo' + (platillo.agotado ? ' esta-agotado' : '');
        tarjeta.dataset.categoria = platillo.categoria;
        const marco = nodo('figure', '', tarjeta);
        marco.className = 'platillo-foto';
        const foto = fotoDe(platillo, usadas);
        if (foto) {
            usadas.add(foto);
            const imagen = nodo('img', '', marco);
            Object.assign(imagen, { src: foto, alt: '', loading: 'lazy', decoding: 'async', width: 900, height: 675 });
        } else {
            const vacio = nodo('span', platillo.categoria, marco);
            vacio.className = 'platillo-vacio';
            vacio.setAttribute('aria-hidden', 'true');
        }
        const promo = platillo.agotado ? null : platillo.promocion;
        if (platillo.agotado) nodo('span', 'Agotado hoy', marco).className = 'platillo-agotado';
        else if (promo) nodo('span', promo.etiqueta, marco).className = 'platillo-casa platillo-promo';
        else if (platillo.especialidad) nodo('span', 'De la casa', marco).className = 'platillo-casa';
        const cuerpo = nodo('div', '', tarjeta);
        cuerpo.className = 'platillo-cuerpo';
        const texto = nodo('div', '', cuerpo);
        texto.className = 'platillo-texto';
        nodo('span', platillo.categoria, texto).className = 'platillo-categoria';
        nodo('h3', platillo.nombre + (platillo.porcion ? ' (' + platillo.porcion + ')' : ''), texto);
        if (platillo.descripcion) nodo('p', platillo.descripcion, texto);
        if (promo) nodo('p', promo.horario, texto).className = 'platillo-horario';
        const precio = nodo('strong', '', cuerpo);
        precio.className = 'platillo-precio';
        if (promo && promo.precio_promocion !== null) {
            const antes = nodo('s', pesos(Number(platillo.precio)), precio);
            antes.setAttribute('aria-label', 'Antes ' + pesos(Number(platillo.precio)));
            precio.append(' ' + pesos(Number(promo.precio_promocion)));
        } else {
            precio.textContent = pesos(Number(platillo.precio));
        }
    }
    filtra('');
    promocionesDeHoy(platillos);
}

// Las promociones vigentes de la sucursal, juntas arriba del menú.
function promocionesDeHoy(platillos) {
    const caja = document.getElementById('promos-hoy');
    const lista = document.getElementById('lista-promos');
    lista.replaceChildren();
    const porId = new Map();
    for (const p of platillos) {
        if (!p.promocion || p.agotado) continue;
        const actual = porId.get(p.promocion.id) ?? { ...p.promocion, platillos: [] };
        actual.platillos.push(p.nombre);
        porId.set(p.promocion.id, actual);
    }
    for (const promo of porId.values()) {
        const fila = nodo('li', '', lista);
        nodo('span', promo.etiqueta, fila).className = 'promos-etiqueta';
        nodo('strong', promo.nombre, fila);
        nodo('small', promo.horario + '. ' + promo.platillos.join(', ') + '.', fila);
    }
    caja.hidden = porId.size === 0;
}

// Las especialidades que marca el panel, en un carrusel que se desliza.
const carrusel = document.getElementById('carrusel-especialidades');
function especialidades(platillos) {
    const casa = platillos.filter(p => p.especialidad && !p.agotado);
    carrusel.replaceChildren();
    document.getElementById('especialidades').hidden = casa.length === 0;
    const usadas = new Set();
    for (const platillo of casa) {
        const tarjeta = nodo('li', '', carrusel);
        tarjeta.className = 'especialidad';
        const foto = fotoDe(platillo, usadas) || '/recursos/sitio/aguachile-720.webp';
        usadas.add(foto);
        const imagen = nodo('img', '', tarjeta);
        Object.assign(imagen, { src: foto, alt: '', loading: 'lazy', decoding: 'async', width: 640, height: 480 });
        const cuerpo = nodo('div', '', tarjeta);
        nodo('span', platillo.categoria, cuerpo).className = 'platillo-categoria';
        nodo('h3', platillo.nombre, cuerpo);
        if (platillo.descripcion) nodo('p', platillo.descripcion, cuerpo);
        nodo('strong', pesos(Number(platillo.precio)), cuerpo).className = 'especialidad-precio';
    }
    // Las flechas sobran si todas caben a la vista.
    const flechas = document.getElementById('flechas-especialidades');
    requestAnimationFrame(() => { flechas.hidden = carrusel.scrollWidth <= carrusel.clientWidth + 4; });
    const paso = () => (carrusel.firstElementChild?.getBoundingClientRect().width ?? 300) + 20;
    document.getElementById('especialidad-anterior').onclick = () => carrusel.scrollBy({ left: -paso(), behavior: 'smooth' });
    document.getElementById('especialidad-siguiente').onclick = () => carrusel.scrollBy({ left: paso(), behavior: 'smooth' });
}

// La reservación: no antes de ahora ni a más de 180 días, con el folio al final.
const fecha = document.getElementById('fecha-reserva');
const local = d => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
function limitesFecha() {
    const ahora = new Date();
    fecha.min = local(ahora);
    fecha.max = local(new Date(ahora.getTime() + 180 * 86400000));
}
limitesFecha();
formulario.addEventListener('submit', async evento => {
    evento.preventDefault();
    if (enviar.disabled) return;
    enviar.disabled = true;
    aviso.className = 'ancho aviso-reserva';
    aviso.textContent = 'Enviando solicitud…';
    try {
        const respuesta = await fetch('/api/v1/reservaciones', {
            method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(Object.fromEntries(new FormData(formulario))),
        });
        const datos = await respuesta.json();
        if (!respuesta.ok) throw new Error(Object.values(datos.error?.campos ?? {}).join('. ') || datos.error?.mensaje);
        const sucursal = opciones.value;
        formulario.reset();
        opciones.value = sucursal;
        limitesFecha();
        const folio = datos.datos?.folio;
        aviso.classList.add('exito');
        aviso.textContent = folio ? 'Solicitud recibida con folio ' + folio + '. La sucursal le llamará para confirmar.'
            : 'Solicitud recibida. La sucursal le llamará para confirmar.';
    } catch (error) {
        aviso.classList.add('error');
        aviso.textContent = error.message || 'No pudimos enviar la solicitud. Intente de nuevo.';
    } finally {
        enviar.disabled = false;
    }
});
document.getElementById('anio').textContent = String(new Date().getFullYear());
void carga();

async function cargaRedes() {
    try {
        const respuesta = await fetch('/api/v1/redes');
        const { datos } = await respuesta.json();
        if (!respuesta.ok || !Array.isArray(datos) || !datos.length) return;
        const redes = document.getElementById('redes');
        for (const red of datos) enlace(red.nombre, red.url, redes);
        redes.hidden = false;
    } catch {
        // El menú y la solicitud de reservación siguen disponibles.
    }
}
void cargaRedes();

// La barra se vuelve sólida en cuanto se baja un poco, y el
// botón flotante de reservar se esconde mientras el formulario está en pantalla.
const barra = document.getElementById('barra');
const flotante = document.querySelector('.reserva-flotante');
const botonMenu = barra.querySelector('.boton-menu');
const marcaBarra = () => barra.classList.toggle('solida', window.scrollY > 40 || barra.classList.contains('abierta'));
// En tableta y teléfono las secciones van en un menú que se abre con el botón.
const abreMenu = abierto => {
    barra.classList.toggle('abierta', abierto);
    botonMenu.setAttribute('aria-expanded', String(abierto));
    botonMenu.setAttribute('aria-label', abierto ? 'Cerrar el menú de secciones' : 'Abrir el menú de secciones');
    marcaBarra();
};
botonMenu.addEventListener('click', () => abreMenu(!barra.classList.contains('abierta')));
barra.querySelectorAll('.barra-enlaces a').forEach(a => a.addEventListener('click', () => abreMenu(false)));
document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && barra.classList.contains('abierta')) { abreMenu(false); botonMenu.focus(); }
});
window.addEventListener('scroll', marcaBarra, { passive: true });
marcaBarra();
if ('IntersectionObserver' in window) {
    // Se esconde mientras el formulario o el pie están en pantalla, para no taparlos.
    const tapados = new Set();
    const vigila = new IntersectionObserver(entradas => {
        for (const e of entradas) e.isIntersecting ? tapados.add(e.target) : tapados.delete(e.target);
        flotante.classList.toggle('oculta', tapados.size > 0);
    });
    vigila.observe(document.getElementById('reservar'));
    vigila.observe(document.querySelector('.pie-portada'));

    // Las secciones entran al aparecer, salvo que se pida reducir el movimiento.
    if (!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) {
        document.documentElement.classList.add('con-movimiento');
        const aparece = new IntersectionObserver(entradas => {
            for (const e of entradas) {
                if (!e.isIntersecting) continue;
                e.target.classList.add('visto');
                aparece.unobserve(e.target);
            }
        }, { rootMargin: '0px 0px -8% 0px' });
        document.querySelectorAll('.historia-texto, .historia-visual, .encabezado-centro, .encabezado-izq, .mosaico-galeria figure, .tarjeta-forma')
            .forEach(el => { el.dataset.aparece = ''; aparece.observe(el); });
    }
}
