// Se manda a imprimir solo: quien abre esta pestaña ya decidió imprimir.
//
// En los tickets el rollo se elige al imprimir (2026-11-08, C3). El equipo
// recuerda el último ancho que alguien eligió a propósito: si el ticket llega
// sin `ancho` en la dirección y ese equipo usa otro rollo, se abre en ese
// antes de imprimir. Es una comodidad del navegador, no una regla: sin
// almacenamiento (ventana privada, datos borrados) sale el de 58 mm.
(function () {
  var ANCHOS = ['58', '80', '76'];
  var LLAVE = 'app.ancho_ticket';
  var actual = document.body.getAttribute('data-ancho');

  if (ANCHOS.indexOf(actual) !== -1) {
    var url = new URL(window.location.href);
    var guardado = null;
    try { guardado = window.localStorage.getItem(LLAVE); } catch (e) { guardado = null; }

    if (!url.searchParams.has('ancho') && guardado && guardado !== actual && ANCHOS.indexOf(guardado) !== -1) {
      url.searchParams.set('ancho', guardado);
      window.location.replace(url.toString());
      return;
    }
    if (url.searchParams.has('ancho')) {
      try { window.localStorage.setItem(LLAVE, actual); } catch (e) { /* sin almacenamiento */ }
    }
  }

  window.addEventListener('load', function () { window.print(); });
})();
