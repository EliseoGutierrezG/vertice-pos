// La vista previa de la pantalla Carta.
//
// La hoja se muestra en un marco a escala. Cada 3 s, mientras la pestaña está
// a la vista, se pregunta al servidor la huella de la carta; si cambió (alguien
// guardó un platillo, una categoría o una promoción, aquí o en otra pestaña),
// la hoja nueva se carga detrás y reemplaza a la anterior sin parpadeo.
(function () {
  var raiz = document.querySelector('[data-carta-vista]');
  if (!raiz) { return; }

  var ANCHO_HOJA = 816;   // 8.5 in a 96 px por pulgada
  var ALTO_HOJA = 1056;   // 11 in
  var CADA = 3000;

  var previa = raiz.querySelector('[data-carta-previa]');
  var estado = raiz.querySelector('[data-carta-estado]');
  var imprimir = document.querySelector('[data-carta-imprimir]');
  var marco = raiz.querySelector('[data-carta-marco]');
  var huella = raiz.dataset.huella;
  var cargando = false;
  var opciones = { promociones: true, tamano: 'normal' };

  function consulta(base, extra) {
    var url = new URL(base, window.location.origin);
    if (!opciones.promociones) { url.searchParams.set('promociones', '0'); }
    if (opciones.tamano === 'compacta') { url.searchParams.set('tamano', 'compacta'); }
    Object.keys(extra || {}).forEach(function (k) { url.searchParams.set(k, extra[k]); });
    return url.pathname + url.search;
  }

  function dice(texto) { estado.textContent = texto; }

  function hojasDelMenu(doc) {
    var menu = doc.querySelector('.hoja-menu');
    return menu ? Math.max(1, Math.ceil(menu.offsetHeight / ALTO_HOJA - 0.02)) : 1;
  }

  function ajusta(cual) {
    var doc;
    try { doc = cual.contentDocument; } catch (e) { doc = null; }
    if (!doc || !doc.documentElement) { return; }
    var alto = doc.documentElement.scrollHeight;
    var escala = Math.min(1, previa.clientWidth / ANCHO_HOJA);
    cual.style.width = ANCHO_HOJA + 'px';
    cual.style.height = alto + 'px';
    cual.style.transform = 'scale(' + escala + ')';
    previa.style.height = Math.ceil(alto * escala) + 'px';
    return doc;
  }

  function informa(doc, cambio) {
    var hojas = hojasDelMenu(doc);
    var texto = hojas === 1
      ? 'El menú cabe en una hoja, más la portada.'
      : 'El menú ocupa ' + hojas + ' hojas. ' + (opciones.tamano === 'normal'
        ? 'Pruebe el tamaño compacto.'
        : 'Acorte leyendas o preparaciones.');
    if (cambio) {
      var hora = new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', hour12: false });
      texto = 'Actualizada a las ' + hora + '. ' + texto;
    }
    dice(texto);
    raiz.classList.toggle('carta-pantalla--excede', hojas > 1);
  }

  // Carga la hoja en un marco nuevo y cambia al terminar.
  function recarga(cambio) {
    if (cargando) { return; }
    cargando = true;
    var nuevo = marco.cloneNode(false);
    nuevo.removeAttribute('src');
    nuevo.classList.add('carta-marco-oculto');
    nuevo.addEventListener('load', function () {
      var doc = ajusta(nuevo);
      var fuentes = doc && doc.fonts && doc.fonts.ready ? doc.fonts.ready : Promise.resolve();
      fuentes.then(function () {
        doc = ajusta(nuevo);
        marco.remove();
        marco = nuevo;
        marco.classList.remove('carta-marco-oculto');
        if (doc) { informa(doc, cambio); }
        cargando = false;
      });
    }, { once: true });
    previa.appendChild(nuevo);
    nuevo.src = consulta(raiz.dataset.hoja, { v: String(Date.now()) });
  }

  function revisa() {
    if (document.hidden || cargando) { return; }
    fetch(consulta(raiz.dataset.huellaUrl), { credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (r) {
        var nueva = r && r.ok && r.datos ? r.datos.huella : null;
        if (nueva && nueva !== huella) {
          huella = nueva;
          recarga(true);
        }
      })
      .catch(function () { dice('Sin conexión. La vista previa puede no estar al día.'); });
  }

  raiz.querySelectorAll('[data-carta-opcion]').forEach(function (control) {
    control.addEventListener('change', function () {
      if (control.dataset.cartaOpcion === 'promociones') { opciones.promociones = control.checked; }
      if (control.dataset.cartaOpcion === 'tamano') { opciones.tamano = control.value; }
      if (imprimir) { imprimir.href = consulta(raiz.dataset.hoja, { imprimir: '1' }); }
      huella = null;
      recarga(false);
      // La huella cambia con las opciones: se pide de nuevo para no recargar dos veces.
      fetch(consulta(raiz.dataset.huellaUrl), { credentials: 'same-origin', headers: { Accept: 'application/json' } })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (r) { if (r && r.ok && r.datos) { huella = r.datos.huella; } })
        .catch(function () {});
    });
  });

  function primeraCarga() {
    var doc = ajusta(marco);
    var fuentes = doc && doc.fonts && doc.fonts.ready ? doc.fonts.ready : Promise.resolve();
    fuentes.then(function () { doc = ajusta(marco); if (doc) { informa(doc, false); } });
  }
  // El script es diferido: la hoja pudo terminar de cargar antes que él.
  var listo = false;
  try { listo = marco.contentDocument && marco.contentDocument.readyState === 'complete' && marco.contentDocument.querySelector('.hoja'); } catch (e) { listo = false; }
  if (listo) { primeraCarga(); } else { marco.addEventListener('load', primeraCarga, { once: true }); }

  window.addEventListener('resize', function () { ajusta(marco); });
  document.addEventListener('visibilitychange', revisa);
  window.setInterval(revisa, CADA);
})();
