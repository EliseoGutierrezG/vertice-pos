# Créditos de las fotos del sitio

Las fotos de `fotos/sitio/` y de `menu/` (salvo `menu/aguachile-verde.webp`, que es un recorte de `sitio/aguachile.jpg`) vienen de [Unsplash](https://unsplash.com) y se usan bajo la [licencia de Unsplash](https://unsplash.com/license): uso libre, también comercial, sin pedir permiso ni dar crédito. Aun así se anotan aquí para poder rastrearlas y reemplazarlas por fotos propias de El Timón.

Se descargaron el 2026-11-15 del CDN de Unsplash en WebP. **Son fotos de muestra**: no son platillos ni salones de El Timón y conviene cambiarlas por fotos reales antes de publicar.

| Archivo | Autor | Página |
|---|---|---|
| `fotos/sitio/salon-mar.webp` | — | https://unsplash.com/photos/plates-on-dining-tables-by-the-sea-Kzft6vrwRoM |
| `fotos/sitio/atardecer.webp` | — | https://unsplash.com/photos/people-dining-at-beachside-restaurant-during-sunset-hxpS_FXP60c |
| `fotos/sitio/producto.webp` | Tapan Kumar Choudhury | https://unsplash.com/photos/silver-and-red-fish-on-ice-gFrrHuHMpTw |
| `fotos/sitio/mesa-mariscos.webp` | Yuval Zukerman | https://unsplash.com/photos/a-table-full-of-seafood-ED-E7Uq-rAo |
| `fotos/sitio/cocina.webp` | Johnathan Macedo | https://unsplash.com/photos/man-in-white-chef-uniform-cooking-4NQEvxW2_4w |
| `fotos/sitio/lancha.webp` | — | https://unsplash.com/photos/mexico-flag-on-yellow-boat-haOaBVJ45pU |
| `menu/ceviche-cebolla.webp` | — | https://unsplash.com/photos/white-ceramic-bowl-with-onion-dish-7YXOqZDhhG0 |
| `menu/ceviche-camaron.webp` | — | https://unsplash.com/photos/sliced-vegetables-in-clear-glass-container-mFmI0dHyF7k |
| `menu/tostada-atun.webp` | — | https://unsplash.com/photos/tuna-tartare-with-mango-cucumber-and-lime-on-a-tostada-DBQYSAf0sak |
| `menu/pulpo-brasa.webp` | Tomi Saputra | https://unsplash.com/photos/grilled-octopus-tentacles-with-fresh-green-herbs-FrWT5qiCkWE |
| `menu/pescado-zarandeado.webp` | Ahmad Jaafar | https://unsplash.com/photos/roasted-fish-with-lime-on-board-k2lVXM5z1-o |
| `menu/pescado-hoja.webp` | Michael Lock | https://unsplash.com/photos/a-grilled-fish-sitting-on-top-of-a-banana-leaf-hVnClpnYUUk |
| `menu/coctel-camaron.webp` | Meg von Haartman | https://unsplash.com/photos/shrimp-cocktail-with-lemon-and-sauce-Lu-eFTitWA0 |
| `menu/camarones-ajillo.webp` | Farhad Ibrahimzade | https://unsplash.com/photos/cooked-food-on-black-ceramic-bowl-HNmcgpzPHag |
| `menu/camarones-diabla.webp` | joe boshra | https://unsplash.com/photos/cooked-shrimp-with-tomatoes-and-herbs-in-a-pan-uUrpTG9BHSs |
| `menu/caldo-mariscos.webp` | — | https://unsplash.com/photos/crab-soup-on-white-ceramic-bowl-vrX8M4Plu8U |
| `menu/mariscada.webp` | — | https://unsplash.com/photos/round-white-ceramic-bowl-with-seafoods-rmdo8r9iGfw |
| `menu/tacos-pescado.webp` | Vitalii Kyktov | https://unsplash.com/photos/three-tacos-with-pink-pickled-onions-and-lime-wedges--B_r_W-IEs0 |
| `menu/ostiones.webp` | Mitili Mitili | https://unsplash.com/photos/a-plate-of-oysters-with-lemon-wedges-and-a-box-of-oysters-TnZnJO4DSdQ |
| `menu/michelada.webp` | César Cabrera | https://unsplash.com/photos/a-drink-with-a-slice-of-lime-on-top-of-it-I2kx01uvF9A |
| `menu/agua-jamaica.webp` | Eiliv Aceron | https://unsplash.com/photos/a-glass-with-a-drink-in-it-kOoMCheZesE |

El autor marcado con «—» no apareció en la búsqueda; está en la página de la foto.
