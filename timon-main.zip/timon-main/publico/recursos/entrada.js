/*
 * Pantallas sin armazón (Entrar y segundo factor), D25.1.
 *
 * «Mostrar» la contraseña: el botón llega oculto en el HTML y aquí se
 * enciende, así que sin JavaScript no queda un botón que no hace nada. Va en
 * archivo propio porque la política de contenidos no deja scripts en línea.
 */
(function () {
    'use strict';

    document.querySelectorAll('[data-mostrar-clave]').forEach(function (boton) {
        var campo = document.getElementById(boton.getAttribute('data-mostrar-clave'));
        if (!campo) {
            return;
        }
        var icono = boton.querySelector('.bi');
        var texto = boton.querySelector('span');

        boton.hidden = false;
        boton.addEventListener('click', function () {
            var mostrar = campo.type === 'password';
            campo.type = mostrar ? 'text' : 'password';
            boton.setAttribute('aria-pressed', mostrar ? 'true' : 'false');
            if (texto) {
                texto.textContent = mostrar ? 'Ocultar' : 'Mostrar';
            }
            if (icono) {
                icono.className = mostrar ? 'bi bi-eye-slash' : 'bi bi-eye';
            }
            campo.focus();
        });

        // Al enviar, la contraseña vuelve a ocultarse: que no quede a la vista
        // si el navegador regresa a la página.
        if (campo.form) {
            campo.form.addEventListener('submit', function () {
                campo.type = 'password';
            });
        }
    });
})();
