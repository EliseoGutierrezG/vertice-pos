'use strict';
const resumen = document.querySelector('[data-restaurante-vivo]');
const campos = [...resumen.querySelectorAll('[data-resumen]')];
async function consulta() {
    if (document.visibilityState !== 'visible') return;
    try {
        const respuesta = await fetch('/reportes/vivo?sucursal=' + encodeURIComponent(resumen.dataset.restauranteVivo),
            { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(5000) });
        if (!respuesta.ok) return;
        const { datos } = await respuesta.json();
        for (const campo of campos) {
            const clave = campo.dataset.resumen;
            if (datos[clave] !== undefined) campo.textContent = (clave === 'venta' ? '$' : '') + datos[clave];
        }
    } catch {
        // Se conserva el último resumen disponible.
    }
}
setInterval(consulta, 10000);
document.addEventListener('visibilitychange', consulta);
