/*
 * Envío único para las pantallas sin `plantilla.js`: Entrar, el segundo factor
 * y los tickets (`vistas/plantilla/limpia.php` y `papel.php`).
 *
 * Un doble clic o un segundo Enter mandaba el formulario dos veces: en el
 * segundo factor eso gasta el código o un código de recuperación de una sola
 * vez. Aquí el primer envío bloquea el formulario y sus botones; el segundo no
 * sale. Si la página vuelve con «Atrás», se suelta.
 *
 * Cada envío lleva además `_envio`, la llave que reconoce el servidor
 * (`ExigeEnvioUnico`) donde hay sesión.
 */
(function (document, window) {
    'use strict';

    function nuevaLlave() {
        if (window.crypto && window.crypto.randomUUID) {
            return window.crypto.randomUUID();
        }
        var b = new Uint8Array(16);
        window.crypto.getRandomValues(b);
        b[6] = (b[6] & 0x0f) | 0x40;
        b[8] = (b[8] & 0x3f) | 0x80;
        var h = Array.prototype.map.call(b, function (x) { return ('0' + x.toString(16)).slice(-2); }).join('');
        return h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20);
    }

    function ponLlave(forma) {
        if (forma.querySelector('input[name="_envio"]')) {
            return;
        }
        var campo = document.createElement('input');
        campo.type = 'hidden';
        campo.name = '_envio';
        campo.value = nuevaLlave();
        forma.appendChild(campo);
    }

    document.addEventListener('submit', function (evento) {
        var forma = evento.target;
        if (!(forma instanceof HTMLFormElement) || (forma.method || '').toLowerCase() !== 'post') {
            return;
        }
        if (forma.target === '_blank') {
            // La página se queda (Compartir por WhatsApp): no se bloquea, pero
            // lleva una llave fija mientras viva. Un segundo clic abre el mismo
            // enlace en lugar de generar otro y revocar el primero.
            ponLlave(forma);
            return;
        }
        if (forma.dataset.pbEnviando === '1') {
            evento.preventDefault();
            return;
        }
        forma.dataset.pbEnviando = '1';
        ponLlave(forma);
        // Después de este turno: el botón pulsado tiene que viajar con su valor.
        window.setTimeout(function () {
            forma.setAttribute('aria-busy', 'true');
            forma.querySelectorAll('button, input[type="submit"]').forEach(function (b) {
                if (b.disabled) return;
                b.disabled = true;
                b.dataset.pbApagado = '1';
                if (b.tagName === 'BUTTON' && b.matches('[type="submit"], :not([type])') && b.textContent.trim() !== '') {
                    b.dataset.pbTexto = b.innerHTML;
                    b.insertAdjacentHTML('afterbegin', '<span class="spinner-border spinner-border-sm me-1" aria-hidden="true"></span>');
                }
            });
        }, 0);
    }, true);

    window.addEventListener('pageshow', function (evento) {
        if (!evento.persisted) {
            return;
        }
        document.querySelectorAll('form[data-pb-enviando]').forEach(function (forma) {
            delete forma.dataset.pbEnviando;
            forma.removeAttribute('aria-busy');
            forma.querySelectorAll('[data-pb-apagado]').forEach(function (b) {
                b.disabled = false;
                delete b.dataset.pbApagado;
                if (b.dataset.pbTexto !== undefined) {
                    b.innerHTML = b.dataset.pbTexto;
                    delete b.dataset.pbTexto;
                }
            });
        });
    });
})(document, window);
