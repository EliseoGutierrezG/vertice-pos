/*
 * `window.service` para el `main.js` de la plantilla base.
 *
 * En la plantilla base cada pantalla pide sus datos por AJAX a través de `service.js`.
 * Aquí las pantallas llegan pintadas desde el servidor, así que sólo hace falta
 * lo que `main.js` y `datatables.js` consultan: si la página se está yendo,
 * si un enlace es de archivo y la salida de la sesión. Carga en el mismo lugar
 * que `service.js` en la plantilla base: antes de `datatables.js` y de `main.js`.
 */
(function (window, document) {
    'use strict';

    let exiting = false;
    window.addEventListener('pagehide', function () { exiting = true; });
    window.addEventListener('beforeunload', function () { exiting = true; });

    function marca() {
        return document.querySelector('meta[name="csrf-token"]')?.content || '';
    }

    window.service = {
        isPageExiting() {
            return exiting;
        },
        // Ningún enlace del sistema se baja por AJAX: se sigue como enlace.
        fileLinkAction() {
            return null;
        },
        fileUrl() {
            return '';
        },
        downloadFile(href) {
            window.location.href = href;
        },
        openReport(href) {
            window.open(href, '_blank', 'noopener');
        },
        latest() {
            return Promise.resolve(null);
        },
        cancelLatest() {},
        /**
         * Sólo la salida pasa por aquí: `main.js` confirma con SweetAlert2 y
         * luego llama `request('Auth', 'logout')`. La salida es un POST con la
         * marca CSRF en la cabecera `X-Marca`, que el servidor acepta.
         */
        request(controller, action) {
            if (controller === 'Auth' && action === 'logout') {
                return fetch('/salir', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'X-Marca': marca() },
                    redirect: 'manual'
                });
            }

            return Promise.reject(new Error('Operación no disponible.'));
        }
    };
})(window, document);
