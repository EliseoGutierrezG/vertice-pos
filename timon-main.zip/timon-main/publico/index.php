<?php
declare(strict_types=1);

/**
 * El único punto de entrada.
 *
 * Todo lo demás vive fuera de publico/ y no es alcanzable por URL. Este
 * archivo no decide nada: carga el autocargador y le pasa el control a la
 * aplicación.
 */

$raiz = dirname(__DIR__);

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);

// Defensa equivalente a la de .htaccess para servidores que pasan directo al
// punto de entrada (y para el servidor integrado de revisión). No se confía en
// un Host arbitrario: sólo forma DNS, IPv4 local o localhost, con puerto.
// `10.0.2.2` es esta máquina vista desde el emulador de Android (bitácora 67).
$host=(string)($_SERVER['HTTP_HOST']??'');
$reenviado=strtolower(trim(explode(',',(string)($_SERVER['HTTP_X_FORWARDED_PROTO']??''))[0]??''));
$segura=((string)($_SERVER['HTTPS']??'')==='on')||$reenviado==='https';
$hostValido=preg_match('/^(?:[a-z0-9.-]+|\[[0-9a-f:]+\])(?::[0-9]+)?$/i',$host)===1;
$local=preg_match('/^(?:localhost|127\.0\.0\.1|\[::1\]|10\.0\.2\.2|[a-z0-9.-]+\.test)(?::[0-9]+)?$/i',$host)===1;
if($segura)header('Strict-Transport-Security: max-age=31536000');
if(!$segura&&!$local&&$hostValido){
    $uri=(string)($_SERVER['REQUEST_URI']??'/');if(!str_starts_with($uri,'/'))$uri='/';
    header('Location: https://'.$host.$uri,true,301);exit;
}

(new Nucleo\Aplicacion($raiz))->corre();
