import { useCallback, useEffect, useRef, useState } from 'react';
import * as Updates from 'expo-updates';
import configuracion from '../../app.json';

const CADA = 15 * 60000;

/**
 * Avisa cuando ya se bajó una versión nueva de la app.
 *
 * No se aplica sola: reiniciar a media captura sería peor que esperar. La
 * persona decide cuándo con «Actualizar».
 */
export function usaVersionNueva() {
    const [lista, ponLista] = useState(false);
    const [buscando, ponBuscando] = useState(false);
    const [mensaje, ponMensaje] = useState('');
    const enCurso = useRef(false);
    const vivo = useRef(true);
    const busca = useCallback(async (manual = true) => {
        if (enCurso.current) return;
        if (__DEV__ || !Updates.isEnabled) {
            if (manual) ponMensaje('Las actualizaciones están disponibles en la app instalada.');
            return;
        }
        enCurso.current = true;
        ponBuscando(true);
        if (manual) ponMensaje('Buscando actualización…');
        try {
            if ((await Updates.checkForUpdateAsync()).isAvailable) {
                const nueva = await Updates.fetchUpdateAsync();
                if (vivo.current) {
                    if (nueva.isNew) ponLista(true);
                    if (manual) ponMensaje(nueva.isNew ? 'Actualización lista. Aplíquela al terminar la captura.' : 'La app está al día.');
                }
            } else if (manual && vivo.current) ponMensaje('La app está al día.');
        } catch {
            if (manual && vivo.current) ponMensaje('No se pudo buscar. Revise la conexión e intente de nuevo.');
        } finally {
            enCurso.current = false;
            if (vivo.current) ponBuscando(false);
        }
    }, []);
    useEffect(() => {
        vivo.current = true;
        void busca(false);
        const reloj = setInterval(() => void busca(false), CADA);
        return () => { vivo.current = false; clearInterval(reloj); };
    }, [busca]);
    async function aplica() {
        try { await Updates.reloadAsync(); }
        catch { ponMensaje('No se aplicó. Reinicie la app al terminar.'); }
    }
    return { lista, aplica: () => void aplica(), busca, buscando, mensaje,
        numero: Updates.runtimeVersion ?? configuracion.expo.version,
        canal: Updates.channel ?? 'Sin canal', id: Updates.updateId ?? 'Incluida en la instalación' };
}
