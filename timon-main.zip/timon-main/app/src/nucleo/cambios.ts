/** Un renglón de `/cambios`: qué pasó en la sucursal y, si aplica, en qué cuenta. */
export type Evento = { id: number; tipo: string; entidad: number; id_cuenta: number | null };
export type Zona = 'plano' | 'cuenta' | 'pedidos' | 'carta' | 'caja';

export const todas: Zona[] = ['plano', 'cuenta', 'pedidos', 'carta', 'caja'];
/** Lo que se vuelve a leer en el repaso periódico. La carta no: cambia poco y pesa. */
export const vivas: Zona[] = ['plano', 'cuenta', 'pedidos', 'caja'];

const reglas: [RegExp, Zona[]][] = [
    [/^cuenta_(abierta|pagada|cancelada|pedida)$/, ['plano', 'pedidos']],
    [/^(cuenta_separada|cuenta_repartida|cuentas_reunidas|subcuenta_|mesa_heredada)/, ['plano', 'cuenta']],
    [/^(cuenta_mostrador|venta_mostrador)$/, ['caja']],
    [/^(mesa_|plano_|reserva_)/, ['plano']],
    [/^pedido_/, ['pedidos']],
    [/^menu_/, ['carta']],
    [/^(turno_|caja_|impresion_)/, ['caja']],
    [/^(cocina_avance|item_entregado|item_cancelado)$/, ['plano']],
    // Sólo le importan a la cuenta que los trae, y esa se resuelve abajo.
    [/^(item_|ronda_|cocina_)/, []],
    // Del panel: no cambian nada de lo que la comanda tiene en pantalla.
    [/^(equipo_|gasto_|inventario_|impresora_|sucursal_)/, []],
];

/**
 * Qué partes de la pantalla hay que volver a leer.
 *
 * Un tipo que no se conoce recarga todo: es mejor leer de más que quedarse
 * con un dato viejo cuando el servicio estrena un evento.
 */
export function zonasDe(eventos: Evento[], cuentaAbierta: number | null, grupo: readonly number[] = []): Set<Zona> {
    const zonas = new Set<Zona>();
    for (const evento of eventos) {
        if (evento.id_cuenta !== null && (evento.id_cuenta === cuentaAbierta || grupo.includes(evento.id_cuenta))) zonas.add('cuenta');
        const regla = reglas.find(([patron]) => patron.test(evento.tipo));
        for (const zona of regla ? regla[1] : todas) zonas.add(zona);
    }
    return zonas;
}

/** Lo que cocina y barra pueden ignorar. Lo demás, y lo desconocido, recarga las comandas. */
const ajenoACocina = /^(cuenta_abierta|cuenta_pedida|pedido_|menu_|turno_|caja_|plano_|reserva_|mesa_limpia|equipo_|gasto_|inventario_|impresora_|sucursal_)/;
export const tocaCocina = (eventos: Evento[]) => eventos.some(evento => !ajenoACocina.test(evento.tipo));
export const tocaImpresion = (eventos: Evento[]) => eventos.some(evento => evento.tipo.startsWith('impresion_'));
export type Cambios = { eventos: Evento[]; cursor: number };
