import { useRef, useState } from 'react';
import { api, ErrorApi, Sesion, uuid } from './api';

export type ResumenTurno = {
    fondo: string; cobros: number; venta: string; propinas: string; descuentos: string; entradas: string; salidas: string;
    esperado: string; formas: { efectivo: string; tarjeta: string; transferencia: string };
};
export type Resultado = {
    id?: number; version?: number; id_siguiente?: number | null; id_subcuenta?: number;
    ticket?: string; folio?: string; pagado?: string; cambio?: string; faltantes?: { insumo: string; cantidad: string }[];
    diferencia?: string; esperado?: string; declarado?: string; resumen?: ResumenTurno;
};
export type OpcionesMutacion = {
    /** Si la cuenta cambió, toma la versión nueva y lo intenta una vez más. Nunca para cobrar o cancelar. */
    reintentaVersion?: boolean;
};
export type Mutacion = (ruta: string, datos: object, opciones?: OpcionesMutacion) => Promise<Resultado | null>;

type Enlaces = {
    sinConexion: () => boolean;
    limpia: () => void;
    informa: (err: unknown) => void;
    /** Vuelve a leer lo que cambió. `conflicto` es cierto cuando el servicio rechazó la operación. */
    trasCambio: (conflicto: boolean) => Promise<void>;
};

/**
 * Las operaciones que necesitan respuesta en el momento: abrir, mover, cobrar.
 *
 * Una a la vez. Si la respuesta se pierde, repetir exactamente lo mismo usa la
 * misma llave y el servicio no lo aplica dos veces. La firma de gerencia no
 * entra en la comparación ni se conserva.
 */
export function usaMutacion(sesion: Sesion, enlaces: Enlaces) {
    const [ocupado, ponOcupado] = useState(false);
    const mutando = useRef(false);
    const perdida = useRef<{ firma: string; llave: string } | null>(null);

    const ejecuta: Mutacion = async (ruta, datos, opciones = {}) => {
        if (mutando.current) return null;
        if (enlaces.sinConexion()) {
            enlaces.informa(new Error('Necesita conexión para esta acción.'));
            return null;
        }
        mutando.current = true;
        ponOcupado(true);
        enlaces.limpia();
        try {
            let envio = datos;
            for (let intento = 0; ; intento++) {
                const firma = JSON.stringify([ruta, Object.fromEntries(Object.entries(envio).filter(([k]) => k !== 'autorizacion'))]);
                const llave = perdida.current?.firma === firma ? perdida.current.llave : uuid();
                perdida.current = { firma, llave };
                try {
                    const resultado = await api<Resultado>(ruta, { token: sesion.token, datos: envio, llave });
                    perdida.current = null;
                    await enlaces.trasCambio(false).catch(enlaces.informa);
                    return resultado;
                } catch (err) {
                    const actual = err instanceof ErrorApi && err.estado === 409 ? err.actual : undefined;
                    if (opciones.reintentaVersion && intento === 0 && actual?.motivo === 'version' && Number.isInteger(actual.version)) {
                        envio = { ...envio, version: actual.version };
                        continue;
                    }
                    enlaces.informa(err);
                    if (actual || (err instanceof ErrorApi && err.estado === 409)) await enlaces.trasCambio(true).catch(() => undefined);
                    return null;
                }
            }
        } finally {
            mutando.current = false;
            ponOcupado(false);
        }
    };
    return { ejecuta, ocupado };
}
