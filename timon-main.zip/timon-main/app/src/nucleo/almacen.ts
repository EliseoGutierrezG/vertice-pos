import * as Crypto from 'expo-crypto';
import * as SecureStore from 'expo-secure-store';
import { openDatabaseAsync } from 'expo-sqlite';

// El llavero falla con un error nativo en inglés (una compilación sin firma, un
// equipo restaurado); la pantalla enseña qué hacer, no la excepción.
const SIN_LLAVERO = 'Este equipo no pudo usar su llave segura. Reinstale la app.';
const seguro = <T,>(operacion: Promise<T>): Promise<T> =>
    operacion.catch(error => { console.warn(error); throw new Error(SIN_LLAVERO); });

export const leeEquipo = () => seguro(SecureStore.getItemAsync('equipo'));
export const guardaEquipo = (valor: string) => seguro(SecureStore.setItemAsync('equipo', valor));
export const borraEquipo = () => seguro(SecureStore.deleteItemAsync('equipo'));
/** El servidor de la sucursal que se eligió al registrar el equipo. */
export const leeServidor = () => seguro(SecureStore.getItemAsync('servidor'));
export const guardaServidor = (url: string) => seguro(SecureStore.setItemAsync('servidor', url));

async function abre() {
    let llave = await seguro(SecureStore.getItemAsync('clave_sqlite'));
    if (!llave) {
        const bytes = await Crypto.getRandomBytesAsync(32);
        llave = Array.from(bytes, n => n.toString(16).padStart(2, '0')).join('');
        await seguro(SecureStore.setItemAsync('clave_sqlite', llave));
    }
    const bd = await openDatabaseAsync('comandas.db');
    await bd.execAsync(`PRAGMA key = "x'${llave}'"`);
    const cifra = await bd.getFirstAsync('PRAGMA cipher_version');
    if (!cifra) throw new Error('La app requiere una compilación con almacenamiento cifrado.');
    await bd.execAsync('CREATE TABLE IF NOT EXISTS almacen (clave TEXT PRIMARY KEY, valor TEXT NOT NULL)');
    return bd;
}

let conexion: ReturnType<typeof abre> | undefined;
const base = () => conexion ??= abre().catch(error => { conexion = undefined; throw error; });

export async function leeLocal(clave: string): Promise<string | null> {
    const fila = await (await base()).getFirstAsync<{ valor: string }>('SELECT valor FROM almacen WHERE clave = ?', clave);
    return fila?.valor ?? null;
}
export async function guardaLocal(clave: string, valor: string) {
    await (await base()).runAsync('REPLACE INTO almacen (clave, valor) VALUES (?, ?)', clave, valor);
}
