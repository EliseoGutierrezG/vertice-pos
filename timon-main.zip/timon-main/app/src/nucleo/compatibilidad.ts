/** Compara las versiones de tres números publicadas por el servidor. */
export function versionAnterior(actual: string, requerida: string): boolean {
    if (!/^\d+\.\d+\.\d+$/.test(actual) || !/^\d+\.\d+\.\d+$/.test(requerida)) return false;
    const a = actual.split('.').map(Number), b = requerida.split('.').map(Number);
    for (let i = 0; i < 3; i++) {
        if (a[i] !== b[i]) return a[i] < b[i];
    }
    return false;
}
