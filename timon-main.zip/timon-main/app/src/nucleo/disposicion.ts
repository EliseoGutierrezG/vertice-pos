import { useWindowDimensions } from 'react-native';

export type Clase = 'telefono' | 'tableta' | 'escritorio';
/** Los dos únicos cortes de ancho de la app. Ninguna pantalla define otros. */
export const TABLETA = 740;
export const ESCRITORIO = 1200;

/**
 * Cómo se acomoda la pantalla según su ancho.
 *
 * Teléfono: una columna. Tableta y escritorio: dos paneles, la cuenta a la
 * izquierda y la carta o el cobro a la derecha. El escritorio además tiene
 * lugar para la caja junto al plano.
 */
export function usaDisposicion() {
    const { width } = useWindowDimensions();
    const clase: Clase = width >= ESCRITORIO ? 'escritorio' : width >= TABLETA ? 'tableta' : 'telefono';
    return { ancho: width, clase, dosPaneles: clase !== 'telefono', lateral: clase === 'escritorio' ? 440 : 348 };
}
