import { useEffect, useRef } from 'react';
import { AppState, Platform } from 'react-native';

let ultimoUso = Date.now();
/** Alguien tocó la pantalla o el teclado: el sondeo sigue al paso rápido. */
export const marcaActividad = () => { ultimoUso = Date.now(); };

/**
 * Llama a `consulta` mientras la pantalla esté a la vista: cada 2 s con uso
 * reciente y cada 10 s tras 3 minutos sin tocar nada. `siempreActivo` es para
 * las pantallas que nadie toca y no pueden atrasarse: cocina, barra e impresor.
 */
export function usaSondeo(consulta: (signal: AbortSignal) => Promise<void>, identidad: string, opciones: { siempreActivo?: boolean } = {}) {
    const siempre = opciones.siempreActivo === true;
    const actual = useRef(consulta);
    actual.current = consulta;
    useEffect(() => {
        let activo = true;
        let temporizador: ReturnType<typeof setTimeout> | undefined;
        let peticion: AbortController | undefined;
        const visible = () => AppState.currentState !== 'background' &&
            (Platform.OS !== 'web' || document.visibilityState === 'visible');

        async function consultaViva() {
            if (!activo || !visible() || peticion) return;
            peticion = new AbortController();
            try {
                await actual.current(peticion.signal);
            } finally {
                peticion = undefined;
                if (activo && visible()) {
                    temporizador = setTimeout(consultaViva, siempre || Date.now() - ultimoUso < 180000 ? 2000 : 10000);
                }
            }
        }
        function cambiaVisibilidad() {
            clearTimeout(temporizador);
            if (!visible()) peticion?.abort();
            else {
                actividad();
                void consultaViva();
            }
        }
        const actividad = marcaActividad;
        const suscripcion = AppState.addEventListener('change', cambiaVisibilidad);
        if (Platform.OS === 'web') {
            document.addEventListener('visibilitychange', cambiaVisibilidad);
            document.addEventListener('pointerdown', actividad);
            document.addEventListener('keydown', actividad);
            window.addEventListener('online', cambiaVisibilidad);
        }

        void consultaViva();
        return () => {
            activo = false;
            clearTimeout(temporizador);
            peticion?.abort();
            suscripcion.remove();
            if (Platform.OS === 'web') {
                document.removeEventListener('visibilitychange', cambiaVisibilidad);
                document.removeEventListener('pointerdown', actividad);
                document.removeEventListener('keydown', actividad);
                window.removeEventListener('online', cambiaVisibilidad);
            }
        };
    }, [identidad]);
}
