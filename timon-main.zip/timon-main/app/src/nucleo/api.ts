import { Platform } from 'react-native';
import { randomUUID } from 'expo-crypto';

export type Modo = 'mesero' | 'caja' | 'cocina' | 'barra' | 'impresor' | 'gerencia';
export type Sesion = { token: string; tipo: Modo; sucursal: number; nombre: string; operador: string };
export type Equipo = { secreto: string; codigo: string };
export type Area = { id: number; nombre: string };
export type Mesa = {
    id: number; id_area: number; numero: string; capacidad: number; forma: string;
    x: number; y: number; estado: string; id_cuenta: number | null; version: number | null;
    abierta_en: string | null; mesero: string | null; minutos: number | null; listos?: number | string;
};
export type Plano = { cursor: number; areas: Area[]; mesas: Mesa[] };
export type Modificador = { id: number; nombre: string; suplemento: string };
/** La promoción que aplica ahora a un platillo. El servidor la fija al capturar. */
export type PromocionCarta = {
    id: number; nombre: string; tipo: 'porcentaje' | 'precio' | 'nxm'; etiqueta: string;
    lleva: number | null; paga: number | null; precio_promocion: string | null; horario: string;
};
export type Platillo = {
    id: number; nombre: string; descripcion: string | null; categoria: string; precio: string; agotado: number;
    foto: string | null; modificadores: Modificador[]; preparacion?: 'caliente' | 'fria' | 'barra';
    porcion?: string; promocion?: PromocionCarta | null;
};
export type Item = {
    id: number; id_ronda: number | null; platillo: string; cantidad: number; precio: string; estado: string; asiento: number | null;
    nota: string; tiempo: string; modificadores: Modificador[]; descuento?: string; promocion?: string;
};
export type Pedido = {
    id: number; version: number; tipo: 'mesa' | 'llevar' | 'domicilio'; cliente: string | null;
    telefono: string | null; direccion: string | null; repartidor: string | null; entrega: string | null; estado: string;
};
export type EstadoCaja = { turno: { id: number } | null; impresiones_demoradas: number };
export type ParteCuenta = { id: number; id_mesa: number | null; version: number; ajuste_reparto: string };
export type Cuenta = Omit<Pedido, 'tipo'> & {
    tipo: Pedido['tipo'] | 'mostrador';
    id_mesa: number | null; abierta: number | null; comensales: number | null; total: string; items: Item[];
    mesas: { id: number; numero: string }[];
    ajuste_reparto?: string; grupo?: ParteCuenta[];
};

export class ErrorApi extends Error {
    constructor(public estado: number, mensaje: string, public actual?: Record<string, unknown>) {
        super(mensaje);
    }
}

/**
 * El servidor al que habla la app. En web es el mismo que sirvió la página.
 * En nativo lo elige quien registra el equipo (el servidor de la sucursal,
 * en la red del restaurante); `EXPO_PUBLIC_API_URL` solo es la sugerencia.
 */
export const origenSugerido = Platform.OS === 'web' ? '' : (process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, '') ?? '');
let origenActual = origenSugerido;
export const origen = () => origenActual;
export function fijaOrigen(url: string) {
    if (Platform.OS !== 'web') origenActual = url.replace(/\/$/, '');
}

/** La dirección escrita, ya normalizada, o null si no sirve: https, host o IPv4 y puerto opcional. */
export function validaServidor(texto: string): string | null {
    const limpio = texto.trim().replace(/\/+$/, '');
    const conEsquema = /^[a-z]+:\/\//i.test(limpio) ? limpio : 'https://' + limpio;
    const partes = /^https:\/\/([a-z0-9.-]+)(:(\d{1,5}))?$/i.exec(conEsquema);
    if (!partes) return null;
    const puerto = partes[3] ? Number(partes[3]) : 443;
    if (puerto < 1 || puerto > 65535) return null;
    return conEsquema.toLowerCase();
}

export const uuid = () => randomUUID();

type Opciones = { token?: string; secreto?: string; datos?: object; llave?: string; signal?: AbortSignal; huella?: string };
type Recibido = { estado: number; huella: string | null; datos: unknown };

/**
 * Una llamada al servicio.
 *
 * Distingue dos fallas que se atienden distinto: sin conexión (estado 0, la
 * app sigue capturando y reintenta sola) y una respuesta que no se entiende
 * (el equipo sí tiene red; se avisa y se vuelve a intentar).
 */
async function pide(ruta: string, opciones: Opciones): Promise<Recibido> {
    if (Platform.OS !== 'web' && !origenActual) throw new Error('Falta la dirección de El Timón en esta instalación.');
    const cabeceras: Record<string, string> = { Accept: 'application/json' };
    if (opciones.token) cabeceras.Authorization = 'Bearer ' + opciones.token;
    if (opciones.secreto) cabeceras['X-Equipo'] = opciones.secreto;
    if (opciones.llave) cabeceras['Idempotency-Key'] = opciones.llave;
    if (opciones.datos) cabeceras['Content-Type'] = 'application/json';
    if (opciones.huella) cabeceras['If-None-Match'] = opciones.huella;
    const control = new AbortController();
    const cancela = () => control.abort();
    const limite = setTimeout(cancela, 8500);
    opciones.signal?.addEventListener('abort', cancela, { once: true });
    if (opciones.signal?.aborted) cancela();
    try {
        let respuesta: Response;
        try {
            respuesta = await fetch(origenActual + '/api/v1' + ruta, {
                method: opciones.datos ? 'POST' : 'GET',
                headers: cabeceras, body: opciones.datos ? JSON.stringify(opciones.datos) : undefined,
                signal: control.signal,
            });
        } catch {
            throw new ErrorApi(0, 'Se perdió la conexión.');
        }
        const huella = respuesta.headers.get('ETag');
        if (respuesta.status === 304) return { estado: 304, huella, datos: null };
        let json: { ok?: boolean; datos?: unknown; error?: { mensaje?: string; campos?: Record<string, string>; estado_actual?: Record<string, unknown> } };
        try {
            json = await respuesta.json();
        } catch {
            if (control.signal.aborted) throw new ErrorApi(0, 'Se perdió la conexión.');
            throw new ErrorApi(respuesta.ok ? 502 : respuesta.status, 'No pudimos completar la acción. Intente de nuevo.');
        }
        if (!respuesta.ok || !json.ok) {
            const errores = json.error?.campos ? Object.values(json.error.campos).join('. ') : '';
            throw new ErrorApi(respuesta.status, errores || json.error?.mensaje || 'No pudimos completar la acción.', json.error?.estado_actual);
        }
        return { estado: respuesta.status, huella, datos: json.datos };
    } finally {
        clearTimeout(limite);
        opciones.signal?.removeEventListener('abort', cancela);
    }
}

export async function api<T>(ruta: string, opciones: Opciones = {}): Promise<T> {
    return (await pide(ruta, opciones)).datos as T;
}

/** Como `api`, pero manda la huella de lo que ya se tiene. Nulo si no cambió. */
export async function apiConHuella<T>(ruta: string, opciones: Opciones): Promise<{ huella: string | null; datos: T } | null> {
    const recibido = await pide(ruta, opciones);
    return recibido.estado === 304 ? null : { huella: recibido.huella, datos: recibido.datos as T };
}

export const dinero = (valor: string | number) => new Intl.NumberFormat('es-MX', {
    style: 'currency', currency: 'MXN',
}).format(Number(valor));
export const estadoMesa: Record<string, string> = {
    libre: 'Libre', ocupada: 'Ocupada', cuenta_pedida: 'Cuenta pedida', por_limpiar: 'Por limpiar', reservada: 'Reservada', bloqueada: 'Bloqueada',
};
export const estadoItem: Record<string, string> = {
    capturado: 'Sin enviar', enviado: 'Enviado a cocina', en_preparacion: 'En preparación',
    listo: 'Listo', entregado: 'Entregado', cancelado: 'Cancelado',
};
