import { useEffect, useRef, useState } from 'react';
import configuracion from '../../app.json';

const CADA = 15 * 60000;

/**
 * Registra el servicio de la app instalada y avisa cuando llega una versión
 * nueva. El servicio nuevo toma el control solo, pero la pantalla sigue con el
 * código anterior hasta recargar: eso lo decide la persona con «Actualizar».
 */
export function usaVersionNueva() {
    const [lista, ponLista] = useState(false);
    const [buscando, ponBuscando] = useState(false);
    const [mensaje, ponMensaje] = useState('');
    const registro = useRef<ServiceWorkerRegistration | undefined>(undefined);
    useEffect(() => {
        if (!('serviceWorker' in navigator)) return;
        let vivo = true;
        // En la primera instalación también cambia el control, y ahí no hay nada que avisar.
        const habia = navigator.serviceWorker.controller !== null;
        const cambia = () => { if (vivo && habia) ponLista(true); };
        navigator.serviceWorker.addEventListener('controllerchange', cambia);
        void navigator.serviceWorker.register('/app/servicio.js', { scope: '/app/' })
            .then(r => { registro.current = r; }).catch(() => undefined);
        const reloj = setInterval(() => void registro.current?.update().catch(() => undefined), CADA);
        return () => {
            vivo = false;
            clearInterval(reloj);
            navigator.serviceWorker.removeEventListener('controllerchange', cambia);
        };
    }, []);
    async function busca() {
        if (buscando) return;
        ponBuscando(true);
        try {
            if (!registro.current) throw new Error('sin servicio');
            await registro.current.update();
            ponMensaje('Búsqueda terminada. Espere el aviso si hay una actualización.');
        } catch { ponMensaje('No se pudo buscar. Revise la conexión e intente de nuevo.'); }
        finally { ponBuscando(false); }
    }
    return { lista, aplica: () => window.location.reload(), busca, buscando, mensaje,
        numero: configuracion.expo.version, canal: 'Web', id: 'Se actualiza con la computadora de sucursal' };
}
