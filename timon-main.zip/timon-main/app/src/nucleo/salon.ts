import { useEffect, useRef, useState } from 'react';
import { guardaLocal, leeLocal } from './almacen';
import { api, apiConHuella, Cuenta, ErrorApi, EstadoCaja, Mesa, Pedido, Plano, Platillo, Sesion } from './api';
import { Cambios, todas, vivas, Zona, zonasDe } from './cambios';
import { usaCola } from './cola';
import { usaMutacion } from './mutacion';
import { usaSondeo } from './sondeo';

/** Operaciones que compiten: llevan la versión de la cuenta. */
const exclusivas = ['cambia-mesa', 'une-mesa', 'transfiere', 'cancelar', 'separa', 'reparte', 'reune'];
/** De esas, las que pueden tomar la versión nueva y repetirse una vez sin preguntar. */
const repetibles = ['cambia-mesa', 'une-mesa', 'transfiere'];
const REPASO = 30000;
const REPASO_CAJA = 10000;
const REPASO_CARTA = 60000;
const AVISO = 8000;
type CartaLocal = { huella: string | null; platillos: Platillo[] };

/**
 * El estado del salón: plano, carta, pedidos, la cuenta abierta y la caja.
 *
 * Cada parte es una «zona» que se vuelve a leer sólo cuando un evento la toca.
 * Capturar platillos nunca espera a esa lectura: va por la cola.
 */
export function usaSalon(sesion: Sesion, vence: () => void) {
    const caja = ['caja', 'gerencia'].includes(sesion.tipo);
    const [plano, ponPlano] = useState<Plano>();
    const [carta, ponCarta] = useState<Platillo[]>([]);
    const [pedidos, ponPedidos] = useState<Pedido[]>([]);
    const [elegida, ponElegida] = useState<number | null>(null);
    const [cuenta, ponCuenta] = useState<Cuenta | null>(null);
    const [estadoCaja, ponCaja] = useState<EstadoCaja>();
    const [error, ponError] = useState('');
    const [sinConexion, ponConexion] = useState(false);
    const cartaLocal = useRef<CartaLocal | null>(null);
    const claveCarta = `carta:${sesion.sucursal}`;
    const seleccion = useRef<number | null>(null);
    const grupo = useRef<number[]>([]);
    const cursor = useRef<number | null>(null);
    const desconectado = useRef(false);
    const sucias = useRef(new Set<Zona>(todas));
    const leida = useRef<Record<string, number>>({});
    const serie = useRef<Record<string, number>>({});
    const sondeando = useRef(false);

    function informa(err: unknown) {
        if (err instanceof ErrorApi) {
            if (err.estado === 401) vence();
            if (err.estado === 0) {
                // El aviso de «Sin conexión» ya lo dice: no hace falta repetirlo como error.
                desconectado.current = true;
                ponConexion(true);
                return;
            }
        }
        ponError((err as Error).message);
    }

    /** Lee una zona. Si mientras tanto salió otra lectura de la misma, gana la más nueva. */
    async function lee(zona: Zona, signal?: AbortSignal) {
        const turno = serie.current[zona] = (serie.current[zona] ?? 0) + 1;
        const vigente = () => !signal?.aborted && serie.current[zona] === turno;
        const pide = <T,>(ruta: string) => api<T>(ruta, { token: sesion.token, signal });
        if (zona === 'plano') {
            const nuevo = await pide<Plano>('/plano');
            if (!vigente()) return;
            cursor.current ??= nuevo.cursor;
            ponPlano(nuevo);
        } else if (zona === 'carta') {
            // Primero la carta guardada: la pantalla sirve aunque el equipo arranque sin red.
            if (cartaLocal.current === null) {
                const guardada = await leeLocal(claveCarta).catch(() => null);
                cartaLocal.current = guardada ? JSON.parse(guardada) as CartaLocal : { huella: null, platillos: [] };
                if (cartaLocal.current.platillos.length) ponCarta(cartaLocal.current.platillos);
            }
            const nueva = await apiConHuella<Platillo[]>('/carta', { token: sesion.token, signal, huella: cartaLocal.current.huella ?? undefined });
            if (!vigente()) return;
            if (nueva) {
                cartaLocal.current = { huella: nueva.huella, platillos: nueva.datos };
                ponCarta(nueva.datos);
                void guardaLocal(claveCarta, JSON.stringify(cartaLocal.current)).catch(() => undefined);
            }
        } else if (zona === 'pedidos') {
            const nuevos = await pide<Pedido[]>('/pedidos');
            if (vigente()) ponPedidos(nuevos);
        } else if (zona === 'caja') {
            if (caja) {
                const nueva = await pide<EstadoCaja>('/caja');
                if (vigente()) ponCaja(nueva);
            }
        } else if (seleccion.current !== null) {
            const id = seleccion.current;
            const detalle = await pide<Cuenta>('/cuentas/' + id);
            if (vigente() && seleccion.current === id) {
                grupo.current = detalle.grupo?.map(parte => parte.id) ?? [];
                ponCuenta(detalle);
            }
        }
        if (vigente()) {
            sucias.current.delete(zona);
            leida.current[zona] = Date.now();
        }
    }

    async function recarga(zonas: Iterable<Zona>, signal?: AbortSignal) {
        for (const zona of zonas) sucias.current.add(zona);
        await Promise.all([...sucias.current].map(zona => lee(zona, signal)));
    }

    const cola = usaCola(sesion, {
        enviado: id => { if (seleccion.current === id) void lee('cuenta').catch(() => undefined); },
        error: informa,
    });

    usaSondeo(async signal => {
        if (sondeando.current) return;
        sondeando.current = true;
        try {
            if (cursor.current !== null) {
                const cambios = await api<Cambios>(`/cambios?desde=${cursor.current}`, { token: sesion.token, signal });
                // El tope del servicio son 200 renglones: si llegó lleno, pudo quedar algo fuera.
                const zonas = cambios.eventos.length >= 200 ? todas : zonasDe(cambios.eventos, seleccion.current, grupo.current);
                for (const zona of zonas) sucias.current.add(zona);
                cursor.current = cambios.cursor;
            }
            const ahora = Date.now();
            const vencida = (zona: Zona, plazo: number) => ahora - (leida.current[zona] ?? 0) > plazo;
            if (desconectado.current || vencida('plano', REPASO)) vivas.forEach(zona => sucias.current.add(zona));
            if (caja && vencida('caja', REPASO_CAJA)) sucias.current.add('caja');
            if (vencida('carta', REPASO_CARTA)) sucias.current.add('carta');
            await recarga([], signal);
            if (signal.aborted) return;
            desconectado.current = false;
            ponConexion(false);
            await cola.vacia();
        } catch (err) {
            if (!signal.aborted) informa(err);
        } finally {
            sondeando.current = false;
        }
    }, sesion.token);

    // Un aviso de error no se queda pegado: se retira solo.
    useEffect(() => {
        if (error === '') return;
        const retiro = setTimeout(() => ponError(''), AVISO);
        return () => clearTimeout(retiro);
    }, [error]);

    const { ejecuta, ocupado } = usaMutacion(sesion, {
        sinConexion: () => desconectado.current,
        limpia: () => ponError(''),
        informa,
        trasCambio: () => recarga(vivas),
    });

    async function selecciona(id: number) {
        seleccion.current = id;
        grupo.current = [];
        ponElegida(id);
        ponCuenta(null);
        try {
            await lee('cuenta');
        } catch (err) {
            cierra();
            informa(err);
        }
    }

    function cierra() {
        seleccion.current = null;
        grupo.current = [];
        ponElegida(null);
        ponCuenta(null);
    }

    /** Abre la cuenta de una mesa libre y la deja en pantalla. */
    async function abreMesa(mesa: Mesa, comensales: number) {
        const respuesta = await ejecuta('/cuentas', { id_mesa: mesa.id, comensales });
        if (!respuesta?.id) return false;
        await selecciona(respuesta.id);
        return true;
    }

    const limpiaMesa = async (mesa: Mesa) => (await ejecuta('/mesas/' + mesa.id + '/limpia', {})) !== null;

    /** Captura un platillo. Funciona sin conexión: sale en cuanto vuelve. */
    async function agrega(platillo: Platillo, captura: object) {
        if (!cuenta || cuenta.abierta === null) return false;
        return cola.agrega(cuenta.id, platillo.nombre, { id_platillo: platillo.id, ...captura });
    }

    function cambiaCuenta(accion: string, datos: object = {}) {
        if (!cuenta) return Promise.resolve(null);
        return ejecuta(`/cuentas/${cuenta.id}/${accion}`,
            exclusivas.includes(accion) ? { version: cuenta.version, ...datos } : datos,
            { reintentaVersion: repetibles.includes(accion) });
    }

    /** Lo que costaría una venta de mostrador con las promociones de este momento. No guarda nada. */
    const cotiza = (items: object[], signal?: AbortSignal) =>
        api<Cotizacion>('/mostrador/cotiza', { token: sesion.token, datos: { items }, signal });

    return {
        cotiza,
        caja, plano, carta, pedidos, elegida, cuenta, estadoCaja, error, sinConexion, ocupado,
        pendientes: cola.pendientes, descarta: cola.descarta, reintenta: cola.reintenta,
        ponError, ejecuta, selecciona, cierra, abreMesa, limpiaMesa, agrega, cambiaCuenta,
    };
}
export type EstadoSalon = ReturnType<typeof usaSalon>;
export type Cotizacion = { total: string; items: { importe: string; descuento: string; promocion: string }[] };
