import { useEffect, useRef, useState } from 'react';
import { api, ErrorApi, Sesion, uuid } from './api';
import { guardaLocal, leeLocal } from './almacen';

/**
 * Un platillo capturado que todavía no llega al servicio.
 *
 * La llave nace con el renglón y **nunca se regenera**: reintentar es mandar
 * la misma operación, y el servicio la reconoce. Los datos no llevan versión,
 * porque agregar un platillo no compite con nadie.
 */
export type Pendiente = {
    llave: string; cuenta: number; nombre: string; datos: object;
    creado: number; intentos: number; rechazo?: string;
};
export type FinCola = 'vacia' | 'sin_conexion' | 'falla';

type Avisos = { enviado: (cuenta: number) => void; error: (err: unknown) => void };

/** Lee lo guardado por una versión anterior: quita la versión y completa lo que falte. */
function normaliza(crudo: string | null): Pendiente[] {
    if (!crudo) return [];
    const filas = JSON.parse(crudo) as Partial<Pendiente>[];
    return filas.filter(f => f.llave && f.cuenta && f.datos).map(f => {
        const { version: _vieja, ...datos } = f.datos as Record<string, unknown>;
        return {
            llave: f.llave!, cuenta: f.cuenta!, nombre: f.nombre ?? 'Platillo', datos,
            creado: f.creado ?? Date.now(), intentos: f.intentos ?? 0, rechazo: f.rechazo,
        };
    });
}

export function usaCola(sesion: Sesion, avisos: Avisos) {
    const [pendientes, ponPendientes] = useState<Pendiente[]>([]);
    const filas = useRef<Pendiente[] | null>(null);
    const carga = useRef<Promise<void> | null>(null);
    const escritura = useRef<Promise<void>>(Promise.resolve());
    const envio = useRef<Promise<FinCola> | null>(null);
    const actuales = useRef(avisos);
    actuales.current = avisos;
    const clave = `cola:${sesion.sucursal}:${sesion.operador}`;

    /** Cambia la cola en memoria de una vez y guarda siempre la foto más reciente. */
    function pon(nueva: Pendiente[]) {
        filas.current = nueva;
        ponPendientes(nueva);
        escritura.current = escritura.current.catch(() => undefined)
            .then(() => guardaLocal(clave, JSON.stringify(filas.current ?? [])));
        return escritura.current;
    }
    const cambia = (llave: string, campos: Partial<Pendiente>) =>
        pon((filas.current ?? []).map(f => f.llave === llave ? { ...f, ...campos } : f));

    function prepara() {
        return carga.current ??= leeLocal(clave).then(crudo => {
            filas.current = normaliza(crudo);
            ponPendientes(filas.current);
        }).catch(err => { carga.current = null; throw err; });
    }

    /** Manda lo pendiente en orden. Un renglón rechazado se marca y los demás siguen. */
    function vacia(): Promise<FinCola> {
        return envio.current ??= (async (): Promise<FinCola> => {
            try {
                await prepara();
                for (;;) {
                    const p = filas.current?.find(f => !f.rechazo);
                    if (!p) return 'vacia';
                    try {
                        await api(`/cuentas/${p.cuenta}/items`, { token: sesion.token, llave: p.llave, datos: p.datos });
                        void pon((filas.current ?? []).filter(f => f.llave !== p.llave)).catch(() => undefined);
                        actuales.current.enviado(p.cuenta);
                    } catch (err) {
                        const estado = err instanceof ErrorApi ? err.estado : -1;
                        if ([404, 409, 422].includes(estado)) {
                            void cambia(p.llave, { rechazo: (err as Error).message }).catch(() => undefined);
                            actuales.current.enviado(p.cuenta);
                            continue;
                        }
                        void cambia(p.llave, { intentos: p.intentos + 1 }).catch(() => undefined);
                        actuales.current.error(err);
                        return estado === 0 ? 'sin_conexion' : 'falla';
                    }
                }
            } finally {
                envio.current = null;
            }
        })();
    }

    /** Guarda el platillo y lo manda de inmediato. Falso si no se pudo guardar en el equipo. */
    async function agrega(cuenta: number, nombre: string, datos: object) {
        const p: Pendiente = { llave: uuid(), cuenta, nombre, datos, creado: Date.now(), intentos: 0 };
        try {
            await prepara();
            await pon([...(filas.current ?? []), p]);
        } catch (err) {
            if (filas.current) void pon(filas.current.filter(f => f.llave !== p.llave)).catch(() => undefined);
            actuales.current.error(err);
            return false;
        }
        // Si un envío iba de salida cuando entró este renglón, se da otra vuelta.
        void vacia().then(fin => { if (fin === 'vacia' && filas.current?.some(f => !f.rechazo)) void vacia(); })
            .catch(() => undefined);
        return true;
    }

    const descarta = (llave: string) => pon((filas.current ?? []).filter(f => f.llave !== llave))
        .catch(err => actuales.current.error(err));
    const reintenta = (llave: string) => cambia(llave, { rechazo: undefined })
        .then(() => vacia()).catch(err => actuales.current.error(err));

    useEffect(() => { void prepara().catch(err => actuales.current.error(err)); }, [clave]);

    return { pendientes, agrega, vacia, descarta, reintenta };
}
