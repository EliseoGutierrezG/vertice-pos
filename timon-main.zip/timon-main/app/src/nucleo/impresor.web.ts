export type TrabajoImpresion = { id: number; ip: string; puerto: number; bytes: string; intento?: number };
export async function imprimeTrabajo(_trabajo: TrabajoImpresion) {
    return { impreso: false, reintentable: false, mensaje: 'La impresión de cocina requiere un equipo Android.' };
}
