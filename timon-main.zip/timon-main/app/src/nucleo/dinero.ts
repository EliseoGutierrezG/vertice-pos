/**
 * Dinero en centavos enteros, igual que el servicio.
 *
 * Las cuentas del cobro se hacen aquí y no con decimales de máquina: la suma
 * de los pagos tiene que dar el mismo centavo que calcula el servicio.
 */

/** `"125.5"` → `12550`. `NaN` si no es un importe con hasta dos decimales. */
export function aCentavos(texto: string | number): number {
    const limpio = String(texto).trim();
    if (!/^\d{1,8}(\.\d{1,2})?$/.test(limpio)) return NaN;
    const [enteros, decimales = ''] = limpio.split('.');
    return Number(enteros) * 100 + Number(decimales.padEnd(2, '0'));
}

/** `12550` → `"125.50"`, como lo espera el servicio. */
export const aPesos = (centavos: number) => `${Math.floor(centavos / 100)}.${String(centavos % 100).padStart(2, '0')}`;

/** El porcentaje de un importe, con el medio centavo hacia arriba. Igual que `Dominio\Cobro::porcentaje`. */
export const porcentaje = (centavos: number, tanto: number) => Math.floor((centavos * tanto + 50) / 100);

/** Los billetes con los que alguien pagaría ese importe: el siguiente múltiplo de cada denominación. */
export function billetes(centavos: number): number[] {
    const sugeridos = [5000, 10000, 20000, 50000, 100000]
        .map(billete => Math.ceil(centavos / billete) * billete)
        .filter(valor => valor > centavos);
    return [...new Set(sugeridos)].slice(0, 3);
}
