const prefijo = 'el-timon:';
export async function leeEquipo() { return localStorage.getItem(prefijo + 'equipo'); }
export async function guardaEquipo(valor: string) { localStorage.setItem(prefijo + 'equipo', valor); }
export async function borraEquipo() { localStorage.removeItem(prefijo + 'equipo'); }
export async function leeLocal(clave: string) { return localStorage.getItem(prefijo + clave); }
export async function guardaLocal(clave: string, valor: string) { localStorage.setItem(prefijo + clave, valor); }
// En web el servidor es el que sirvió la página: no se elige ni se guarda.
export async function leeServidor(): Promise<string | null> { return null; }
export async function guardaServidor(_url: string) { /* nada */ }
