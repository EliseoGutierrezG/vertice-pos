import TcpSocket from 'react-native-tcp-socket';

export type TrabajoImpresion = { id: number; ip: string; puerto: number; bytes: string; intento?: number };

export function imprimeTrabajo(trabajo: TrabajoImpresion): Promise<{ impreso: boolean; reintentable?: boolean; mensaje?: string }> {
    return new Promise(resuelve => {
        let terminado = false;
        let escrituraIniciada = false;
        const socket = TcpSocket.createConnection({ host: trabajo.ip, port: trabajo.puerto }, () => {
            if (terminado) return;
            escrituraIniciada = true;
            socket.write(trabajo.bytes, 'base64', error => {
                if (error) {
                    falla(error);
                    return;
                }
                if (terminado) return;
                // El callback confirma la escritura TCP. La impresora no
                // tiene que responder ni cerrar la conexión para recibirla.
                terminado = true;
                clearTimeout(limite);
                socket.end();
                resuelve({ impreso: true });
            });
        });
        const limite = setTimeout(() => falla(new Error('La impresora no respondió.')), 8000);
        function falla(error: Error) {
            if (terminado) return;
            terminado = true;
            clearTimeout(limite);
            socket.destroy();
            resuelve({ impreso: false, reintentable: !escrituraIniciada, mensaje: error.message });
        }
        socket.on('error', falla);
        socket.on('close', () => falla(new Error('La impresión no se pudo confirmar.')));
    });
}
