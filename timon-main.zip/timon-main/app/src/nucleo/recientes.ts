import { guardaLocal, leeLocal } from './almacen';

/** Quién ha entrado en este equipo. Sólo usuario y nombre: el PIN nunca se guarda. */
export type Reciente = { usuario: string; nombre: string };
const CLAVE = 'recientes';
const TOPE = 4;

export async function leeRecientes(): Promise<Reciente[]> {
    try {
        const crudo = await leeLocal(CLAVE);
        const lista = crudo ? JSON.parse(crudo) as Reciente[] : [];
        return lista.filter(r => typeof r.usuario === 'string' && typeof r.nombre === 'string').slice(0, TOPE);
    } catch {
        return [];
    }
}

/** Pone a la persona al frente de la lista y la devuelve ya recortada. */
export async function recuerda(nueva: Reciente): Promise<Reciente[]> {
    const lista = [nueva, ...(await leeRecientes()).filter(r => r.usuario !== nueva.usuario)].slice(0, TOPE);
    await guardaLocal(CLAVE, JSON.stringify(lista)).catch(() => undefined);
    return lista;
}
