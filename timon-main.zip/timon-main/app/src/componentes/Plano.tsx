import { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { estadoMesa, Mesa, Plano as Estado } from '../nucleo/api';
import { usaDisposicion } from '../nucleo/disposicion';
import { Boton, c, estilos as e, Pestanas } from './ui';

const color: Record<string, [string, string]> = {
    libre: [c.exito, c.superficie], ocupada: [c.primario, c.superficie],
    cuenta_pedida: [c.aviso, c.tinta], por_limpiar: [c.superficie, c.tinta],
    reservada: [c.superficie, c.primario], bloqueada: [c.tinta, c.superficie],
};
export function Plano({ plano, elige }: { plano: Estado; elige: (mesa: Mesa) => void }) {
    const { dosPaneles } = usaDisposicion();
    const [lista, ponLista] = useState(false);
    const [area, ponArea] = useState<number | null>(null);
    const planoVisible = dosPaneles && !lista;
    const areas = plano.areas.filter(a => area === null || a.id === area);
    return <View style={{ gap: 14 }}>
        <View style={[e.entre, { flexWrap: 'wrap' }]}>
            {plano.areas.length > 1 && <Pestanas etiqueta="Áreas" actual={area} elige={ponArea}
                opciones={[{ clave: null, texto: 'Todas las áreas' }, ...plano.areas.map(a => ({ clave: a.id, texto: a.nombre }))]} />}
            {dosPaneles && <Boton texto={lista ? 'Ver plano' : 'Ver lista'} tipo="secundario" alPulsar={() => ponLista(!lista)} />}
        </View>
        {plano.mesas.length === 0 && <Text style={e.texto}>Aún no hay mesas. Configure el plano en el panel.</Text>}
        {areas.map(a => <View key={a.id} style={e.panel}>
            <Text style={e.h2} accessibilityRole="header">{a.nombre}</Text>
            <View style={planoVisible ? { minHeight: 380, backgroundColor: c.fondo, borderRadius: 8, position: 'relative' } : { gap: 8 }}>
                {plano.mesas.filter(m => m.id_area === a.id).map(m => {
                    const [fondo, tinta] = color[m.estado] ?? color.bloqueada;
                    const listos = Number(m.listos ?? 0);
                    return <Pressable key={m.id} onPress={() => elige(m)} accessibilityRole="button"
                        accessibilityLabel={`Mesa ${m.numero}, ${estadoMesa[m.estado]}${listos > 0 ? `, ${listos} listos` : ''}`}
                        style={({ pressed }) => [
                            { backgroundColor: fondo, borderColor: tinta === c.superficie ? fondo : c.primario, borderWidth: 1,
                                minHeight: 56, padding: 8, borderRadius: m.forma === 'redonda' ? 20 : 10, opacity: pressed ? .8 : 1,
                                gap: 3, justifyContent: 'center' },
                            planoVisible ? { position: 'absolute', width: 110, height: 72, alignItems: 'center',
                                left: `${10 + m.x * .8}%`, top: `${10 + m.y * .8}%`, transform: [{ translateX: -55 }, { translateY: -36 }] }
                                : { paddingHorizontal: 12 },
                        ]}>
                        <Text style={[e.h3, { color: tinta }]}>{planoVisible ? m.numero : `Mesa ${m.numero} · ${m.capacidad} lugares`}</Text>
                        <Text style={{ color: tinta, fontSize: 13 }}>{estadoMesa[m.estado]}</Text>
                        {listos > 0 ? <Text style={{ color: tinta, fontSize: 13, fontWeight: '800' }}>{listos} {listos === 1 ? 'listo' : 'listos'}</Text>
                            : m.mesero && <Text style={{ color: tinta, fontSize: 12 }} numberOfLines={1}>{m.mesero} · {m.minutos ?? 0} min</Text>}
                    </Pressable>;
                })}
            </View>
        </View>)}
    </View>;
}
