import { useState } from 'react';
import type { ReactNode } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { dinero, estadoItem, Item } from '../nucleo/api';
import type { Pendiente } from '../nucleo/cola';
import type { Resultado } from '../nucleo/mutacion';
import type { EstadoSalon } from '../nucleo/salon';
import { Firma } from './Caja';
import { Boton, c, Campo, Cargando, Contador, Dialogo, estilos as e, Insignia, Pestanas, tintes } from './ui';
import type { Tono } from './ui';

export const estadoPedido: Record<string, string> = {
    recibido: 'Recibido', preparando: 'En preparación', listo: 'Listo',
    en_camino: 'En camino', entregado: 'Entregado', cancelado: 'Cancelado',
};
const pasosPedido: Record<string, [string, string]> = {
    recibido: ['preparando', 'En preparación'], preparando: ['listo', 'Marcar listo'],
    listo: ['entregado', 'Marcar entregado'], en_camino: ['entregado', 'Marcar entregado'],
};
const tonoItem: Record<string, Tono> = {
    capturado: 'aviso', enviado: 'primario', en_preparacion: 'primario', listo: 'exito', entregado: 'neutro', cancelado: 'riesgo',
};
export const tiempos = [{ clave: 'entrada', texto: 'Entrada' }, { clave: 'fuerte', texto: 'Fuerte' }];
/** Quitar un platillo que no ha salido a cocina es corregir la captura: no pide motivo ni firma. */
const CORRECCION = 'Captura corregida';

type Paso = { tipo: 'mueve'; accion: 'cambia-mesa' | 'une-mesa' } | { tipo: 'transfiere' | 'cancela' | 'edita'; item: Item };

const propios = StyleSheet.create({
    renglon: { paddingVertical: 10, gap: 8, borderBottomWidth: 1, borderBottomColor: tintes.neutro },
    cabeza: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, minHeight: 44 },
    cantidad: { minWidth: 30, color: c.primario, fontSize: 17, fontWeight: '900', fontVariant: ['tabular-nums'] },
    importe: { color: c.tinta, fontSize: 16, fontWeight: '700', fontVariant: ['tabular-nums'] },
    tachado: { textDecorationLine: 'line-through', color: c.secundario },
    acciones: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingLeft: 40 },
    pie: { padding: 14, gap: 10, borderTopWidth: 1, borderTopColor: tintes.neutro, backgroundColor: c.superficie },
});

/**
 * La cuenta abierta: sus platillos y lo que se puede hacer con ella.
 *
 * Ocupa todo el alto que le den. Los platillos se desplazan y las acciones
 * se quedan abajo, siempre a la mano. Lo que necesita más datos (corregir,
 * cancelar, mover) se resuelve en un diálogo.
 */
export function FichaCuenta({ salon: s, cobrar, cobrando, divide }: {
    salon: EstadoSalon; cobrar: () => void; cobrando: boolean; divide: () => void;
}) {
    const [repartidor, ponRepartidor] = useState('');
    const [paso, ponPaso] = useState<Paso | null>(null);
    const [abierto, ponAbierto] = useState<number | null>(null);
    const cuenta = s.cuenta;
    if (!cuenta) return <Cargando texto="Cargando cuenta…" />;
    const { ocupado, sinConexion } = s;
    const viva = cuenta.abierta !== null;
    const enCola = s.pendientes.filter(p => p.cuenta === cuenta.id);
    // Lo que se quitó antes de salir a cocina nunca existió para el comensal: no se lista.
    const visibles = cuenta.items.filter(i => !(i.estado === 'cancelado' && i.id_ronda === null));
    const cobrables = cuenta.items.filter(i => i.estado !== 'cancelado');
    const piezas = cobrables.reduce((suma, i) => suma + Number(i.cantidad), 0);
    const repartida = Number(cuenta.ajuste_reparto ?? '0') !== 0;
    const porEnviar = cuenta.items.some(i => i.estado === 'capturado');
    const entrega = cuenta.entrega ? pasosPedido[cuenta.entrega] : null;
    const envioDomicilio = cuenta.entrega === 'listo' && cuenta.tipo === 'domicilio';
    const cierra = () => ponPaso(null);
    const termina = (r: Resultado | null) => { if (r) { ponPaso(null); ponAbierto(null); } };
    const cambiaItem = (item: Item, datos: object) => s.cambiaCuenta('estado-item', { id_item: item.id, ...datos });

    return <View style={{ flex: 1, backgroundColor: c.superficie }}>
        <ScrollView contentContainerStyle={{ padding: 14, gap: 12 }} keyboardShouldPersistTaps="handled">
            {cuenta.tipo !== 'mesa' && <View style={e.panel}>
                <View style={e.entre}>
                    <Text style={[e.h3, { flexShrink: 1 }]}>{cuenta.cliente}</Text>
                    <Insignia texto={estadoPedido[cuenta.entrega ?? 'recibido']} tono="primario" />
                </View>
                <Text style={e.ayuda}>{[cuenta.tipo === 'domicilio' ? 'A domicilio' : 'Para llevar', cuenta.telefono, cuenta.direccion, cuenta.repartidor]
                    .filter(Boolean).join(' · ')}</Text>
                {envioDomicilio && <Campo etiqueta="Repartidor" value={repartidor} onChangeText={ponRepartidor} maxLength={100} />}
                {viva && entrega && <Boton texto={envioDomicilio ? 'Enviar a domicilio' : entrega[1]} tipo="secundario" alPulsar={() => void s.cambiaCuenta('entrega', {
                    entrega: envioDomicilio ? 'en_camino' : entrega[0], repartidor,
                })} ocupado={ocupado} inactivo={sinConexion} />}
            </View>}

            <View>
                {visibles.length === 0 && enCola.length === 0 && <Text style={[e.texto, { paddingVertical: 12 }]}>
                    {repartida ? 'Saldo del reparto de la mesa.' : viva ? 'Aún no hay platillos. Agréguelos de la carta.' : 'La cuenta se cerró sin platillos.'}</Text>}
                {visibles.map(i => {
                    const activo = viva && i.estado !== 'cancelado';
                    return <Renglon key={i.id} item={i} abierto={abierto === i.id} alterna={activo ? () => ponAbierto(abierto === i.id ? null : i.id) : undefined}
                        fijo={activo && i.estado === 'listo' && <Boton texto="Entregado" inactivo={sinConexion || ocupado}
                            etiqueta={`Entregado, ${i.platillo}`} alPulsar={() => void cambiaItem(i, { estado: 'entregado' })} />}>
                        {i.estado === 'capturado' ? <>
                            <Boton texto="Corregir" tipo="secundario" inactivo={sinConexion || ocupado} alPulsar={() => ponPaso({ tipo: 'edita', item: i })} />
                            <Boton texto="Quitar" tipo="secundario" inactivo={sinConexion || ocupado}
                                alPulsar={() => void cambiaItem(i, { estado: 'cancelado', motivo: CORRECCION }).then(termina)} />
                        </> : <Boton texto="Cancelar platillo" tipo="secundario" inactivo={sinConexion || ocupado}
                            alPulsar={() => ponPaso({ tipo: 'cancela', item: i })} />}
                        <Boton texto="Transferir" tipo="secundario" inactivo={sinConexion || ocupado} alPulsar={() => ponPaso({ tipo: 'transfiere', item: i })} />
                    </Renglon>;
                })}
                {enCola.map(p => <EnCola key={p.llave} pendiente={p} sinConexion={sinConexion}
                    reintenta={() => void s.reintenta(p.llave)} descarta={() => void s.descarta(p.llave)} />)}
            </View>
        </ScrollView>

        <View style={propios.pie}>
            <View style={e.entre}>
                <Text style={e.ayuda}>{piezas === 1 ? '1 platillo' : `${piezas} platillos`}</Text>
                <Text style={e.cifra} accessibilityLabel={`Total ${dinero(cuenta.total)}`}>{dinero(cuenta.total)}</Text>
            </View>
            {repartida && <Text style={e.ayuda}>Ajuste del reparto · {dinero(cuenta.ajuste_reparto ?? '0')}</Text>}
            {viva && <>
                <View style={e.fila}>
                    <Boton texto="Enviar a cocina" tipo={porEnviar || enCola.length > 0 ? 'primario' : 'secundario'} estilo={{ flexGrow: 1 }}
                        ocupado={ocupado} inactivo={sinConexion || enCola.length > 0 || !porEnviar} alPulsar={() => void s.cambiaCuenta('rondas')} />
                    {s.caja && !cobrando && <Boton texto="Cobrar" tipo={porEnviar || enCola.length > 0 ? 'secundario' : 'primario'} estilo={{ flexGrow: 1 }}
                        alPulsar={cobrar} inactivo={ocupado} />}
                </View>
                <View style={e.fila}>
                    <Boton texto="Pedir precuenta" tipo="secundario" inactivo={sinConexion || ocupado || enCola.length > 0}
                        alPulsar={() => void s.cambiaCuenta('precuenta')} />
                    {cuenta.tipo === 'mesa' && <Boton texto="Dividir cuenta" tipo="secundario" inactivo={sinConexion || ocupado} alPulsar={divide} />}
                    {cuenta.tipo === 'mesa' && cuenta.id_mesa !== null && <>
                        <Boton texto="Cambiar mesa" tipo="secundario" inactivo={sinConexion || ocupado} alPulsar={() => ponPaso({ tipo: 'mueve', accion: 'cambia-mesa' })} />
                        <Boton texto="Unir mesa" tipo="secundario" inactivo={sinConexion || ocupado} alPulsar={() => ponPaso({ tipo: 'mueve', accion: 'une-mesa' })} />
                    </>}
                    {cobrables.length === 0 && !repartida && <Boton texto="Cerrar cuenta vacía" tipo="secundario" inactivo={sinConexion || ocupado || enCola.length > 0}
                        alPulsar={() => void s.cambiaCuenta('cancelar')} />}
                </View>
            </>}
        </View>

        {paso?.tipo === 'edita' && <Corrige item={paso.item} salon={s} cierra={cierra} termina={termina} />}
        {paso?.tipo === 'cancela' && <Cancela item={paso.item} salon={s} cierra={cierra} termina={termina} />}
        {paso?.tipo === 'transfiere' && <Dialogo titulo="Transferir platillo" cierra={cierra} error={s.error}>
            <Text style={e.texto}>{paso.item.cantidad} × {paso.item.platillo}</Text>
            <Mesas salon={s} vacio="No hay otra cuenta abierta." filtra={m => m.id_cuenta !== null && m.id_cuenta !== cuenta.id}
                elige={m => void s.cambiaCuenta('transfiere', { id_item: paso.item.id, id_destino: m.id_cuenta }).then(termina)} />
        </Dialogo>}
        {paso?.tipo === 'mueve' && <Dialogo titulo={paso.accion === 'une-mesa' ? 'Unir otra mesa' : 'Cambiar de mesa'} cierra={cierra} error={s.error}>
            <Mesas salon={s} vacio="No hay mesas libres." filtra={m => m.estado === 'libre'}
                elige={m => void s.cambiaCuenta(paso.accion, { id_mesa: m.id }).then(termina)} />
        </Dialogo>}
    </View>;
}

/** Un platillo de la cuenta. Tocarlo descubre lo que se puede hacer con él. */
function Renglon({ item, abierto, alterna, fijo, children }: {
    item: Item; abierto: boolean; alterna?: () => void; fijo?: ReactNode; children: ReactNode;
}) {
    const cancelado = item.estado === 'cancelado';
    const detalle = [...item.modificadores.map(m => m.nombre), item.nota, item.tiempo === 'entrada' ? 'Entrada' : '',
        item.asiento ? 'Asiento ' + item.asiento : ''].filter(Boolean).join(' · ');
    return <View style={propios.renglon}>
        <Pressable disabled={!alterna} onPress={alterna} accessibilityRole={alterna ? 'button' : 'text'} accessibilityState={alterna ? { expanded: abierto } : undefined} aria-expanded={alterna ? abierto : undefined}
            accessibilityLabel={`${item.cantidad} ${item.platillo}, ${estadoItem[item.estado]}`}
            style={({ pressed }) => [propios.cabeza, pressed && e.presionado]}>
            <Text style={[propios.cantidad, cancelado && propios.tachado]}>{item.cantidad}×</Text>
            <View style={{ flex: 1, gap: 4 }}>
                <Text style={[e.h3, cancelado && propios.tachado]}>{item.platillo}</Text>
                {detalle !== '' && <Text style={e.ayuda}>{detalle}</Text>}
                {!cancelado && Number(item.descuento ?? 0) > 0 && <Text style={e.ayuda}>{item.promocion} −{dinero(item.descuento ?? 0)}</Text>}
                <Insignia texto={estadoItem[item.estado]} tono={tonoItem[item.estado] ?? 'neutro'} />
            </View>
            <Text style={[propios.importe, cancelado && propios.tachado]}>{dinero(item.cantidad * Number(item.precio) - (cancelado ? 0 : Number(item.descuento ?? 0)))}</Text>
        </Pressable>
        {(abierto || !!fijo) && <View style={propios.acciones}>{fijo}{abierto && children}</View>}
    </View>;
}

/** Un platillo capturado que aún no llega al servicio. */
function EnCola({ pendiente: p, sinConexion, reintenta, descarta }: {
    pendiente: Pendiente; sinConexion: boolean; reintenta: () => void; descarta: () => void;
}) {
    return <View style={propios.renglon}>
        <View style={propios.cabeza}>
            <Text style={propios.cantidad}>{(p.datos as { cantidad?: number }).cantidad ?? 1}×</Text>
            <View style={{ flex: 1, gap: 4 }}>
                <Text style={e.h3}>{p.nombre}</Text>
                {p.rechazo ? <Text style={[e.ayuda, { color: c.acento }]}>{p.rechazo}</Text> : null}
                <Insignia texto={p.rechazo ? 'No se guardó' : 'Por guardar'} tono={p.rechazo ? 'riesgo' : 'aviso'} />
            </View>
        </View>
        {!!p.rechazo && <View style={propios.acciones}>
            <Boton texto="Reintentar" tipo="secundario" inactivo={sinConexion} alPulsar={reintenta} />
            <Boton texto="Descartar" tipo="riesgo" alPulsar={descarta} />
        </View>}
    </View>;
}

function Mesas({ salon: s, filtra, elige, vacio }: {
    salon: EstadoSalon; filtra: (mesa: NonNullable<EstadoSalon['plano']>['mesas'][number]) => boolean;
    elige: (mesa: NonNullable<EstadoSalon['plano']>['mesas'][number]) => void; vacio: string;
}) {
    // Una cuenta con mesas unidas aparece una sola vez.
    const mesas = (s.plano?.mesas ?? []).filter(filtra).filter((m, i, todas) =>
        m.id_cuenta === null || todas.findIndex(o => o.id_cuenta === m.id_cuenta) === i);
    if (mesas.length === 0) return <Text style={e.texto}>{vacio}</Text>;
    return <View style={e.fila}>
        {mesas.map(m => <Boton key={m.id} texto={`Mesa ${m.numero}`} tipo="secundario" inactivo={s.sinConexion} ocupado={s.ocupado} alPulsar={() => elige(m)} />)}
    </View>;
}

/** Corrige un platillo que todavía no sale a cocina. */
function Corrige({ item, salon: s, cierra, termina }: { item: Item; salon: EstadoSalon; cierra: () => void; termina: (r: Resultado | null) => void }) {
    const [cantidad, ponCantidad] = useState(item.cantidad);
    const [tiempo, ponTiempo] = useState(item.tiempo);
    const [asiento, ponAsiento] = useState(item.asiento ? String(item.asiento) : '');
    const [nota, ponNota] = useState(item.nota ?? '');
    return <Dialogo titulo={item.platillo} cierra={cierra} error={s.error}>
        <Contador etiqueta="Cantidad" valor={cantidad} cambia={ponCantidad} />
        <Pestanas etiqueta="Tiempo" opciones={tiempos} actual={tiempo} elige={ponTiempo} />
        <Campo etiqueta="Asiento (opcional)" value={asiento} onChangeText={ponAsiento} keyboardType="number-pad" maxLength={2} />
        <Campo etiqueta="Nota (opcional)" value={nota} onChangeText={ponNota} maxLength={240} />
        <Boton texto="Guardar cambios" ocupado={s.ocupado} inactivo={s.sinConexion || (asiento !== '' && !/^[1-9]\d?$/.test(asiento))}
            alPulsar={() => void s.cambiaCuenta('edita-item', { id_item: item.id, cantidad, tiempo, nota, asiento: asiento || undefined }).then(termina)} />
    </Dialogo>;
}

/** Cancela un platillo que ya salió a cocina: pide motivo y la firma de gerencia. */
function Cancela({ item, salon: s, cierra, termina }: { item: Item; salon: EstadoSalon; cierra: () => void; termina: (r: Resultado | null) => void }) {
    const [motivo, ponMotivo] = useState('');
    const [firma, ponFirma] = useState({ usuario: '', clave: '', codigo: '' });
    return <Dialogo titulo="Cancelar platillo" cierra={cierra} error={s.error}>
        <Text style={e.texto}>{item.cantidad} × {item.platillo}</Text>
        <Campo etiqueta="Motivo de cancelación" value={motivo} onChangeText={ponMotivo} maxLength={255} />
        <Firma datos={firma} cambia={ponFirma} />
        <Boton texto="Confirmar cancelación" tipo="riesgo" ocupado={s.ocupado} inactivo={s.sinConexion || !motivo.trim()}
            alPulsar={() => void s.cambiaCuenta('estado-item', { id_item: item.id, estado: 'cancelado', motivo, autorizacion: firma }).then(termina)} />
    </Dialogo>;
}
