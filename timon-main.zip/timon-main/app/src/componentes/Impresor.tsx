import { useRef, useState } from 'react';
import { useKeepAwake } from 'expo-keep-awake';
import { View, Text } from 'react-native';
import { api, ErrorApi, Sesion } from '../nucleo/api';
import { Cambios, tocaImpresion } from '../nucleo/cambios';
import { imprimeTrabajo, TrabajoImpresion } from '../nucleo/impresor';
import { usaSondeo } from '../nucleo/sondeo';
import { Aviso, estilos as e } from './ui';

const REPASO = 15000;

export function Impresor({ sesion, vence }: { sesion: Sesion; vence: () => void }) {
    useKeepAwake('impresor');
    const [mensaje, ponMensaje] = useState('En espera de trabajos.');
    const [error, ponError] = useState('');
    const pendiente = useRef<{ id: number; intento?: number; impreso: boolean; reintentable?: boolean } | null>(null);
    const cursor = useRef<number | null>(null);
    const hay = useRef(true);
    const revisado = useRef(0);
    usaSondeo(async signal => {
        try {
            if (pendiente.current === null) {
                // Pregunta por trabajos cuando un evento avisa que hay, y cada 15 s por si acaso.
                const cambios = await api<Cambios>(cursor.current === null ? '/cambios' : `/cambios?desde=${cursor.current}`,
                    { token: sesion.token, signal });
                cursor.current = cambios.cursor;
                if (cambios.eventos.length >= 200 || tocaImpresion(cambios.eventos)) hay.current = true;
                if (!hay.current && Date.now() - revisado.current < REPASO) return;
                const trabajo = await api<TrabajoImpresion | null>('/impresiones/tomar', {
                    token: sesion.token, datos: {}, signal,
                });
                revisado.current = Date.now();
                if (!trabajo) {
                    hay.current = false;
                    return;
                }
                ponMensaje('Enviando a la impresora…');
                try {
                    const { mensaje, ...resultado } = await imprimeTrabajo(trabajo);
                    ponError(mensaje ?? '');
                    pendiente.current = { id: trabajo.id, intento: trabajo.intento, ...resultado };
                } catch (err) {
                    ponError((err as Error).message);
                    pendiente.current = { id: trabajo.id, intento: trabajo.intento, impreso: false };
                }
            }
            const { id, intento, impreso, reintentable } = pendiente.current;
            await api(`/impresiones/${id}/confirmar`, { token: sesion.token, datos: { impreso, intento, reintentable } });
            pendiente.current = null;
            ponMensaje(impreso ? `Trabajo ${id} enviado. En espera.` : `Trabajo ${id} con error. En espera.`);
        } catch (err) {
            if (signal.aborted) return;
            if (err instanceof ErrorApi && err.estado === 401) vence();
            else {
                if (err instanceof ErrorApi && [404, 409].includes(err.estado)) pendiente.current = null;
                ponError((err as Error).message);
            }
        }
    }, sesion.token, { siempreActivo: true });

    return <View style={e.pagina}><Text style={e.h1} accessibilityRole="header">Impresión térmica</Text>
        <Text style={e.texto} accessibilityLiveRegion="polite">{mensaje}</Text>
        {error !== '' && <Aviso error>{error}</Aviso>}
        <Text style={e.ayuda}>Mantenga el equipo conectado y con esta pantalla abierta.</Text>
    </View>;
}
