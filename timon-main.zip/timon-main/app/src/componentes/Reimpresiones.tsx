import { useState } from 'react';
import { Text, View } from 'react-native';
import { api, Sesion, uuid } from '../nucleo/api';
import { Aviso, Boton, estilos as e } from './ui';

type Trabajo = { id: number; tipo: string; estado: string; nombre: string; creado_en: string; reimprimible: boolean };
const tipos: Record<string, string> = { comanda: 'Comanda', precuenta: 'Precuenta', ticket: 'Ticket', corte: 'Corte' };
const estados: Record<string, string> = { pendiente: 'Pendiente', enviado: 'Enviado', impreso: 'Impreso', fallido: 'Fallido' };

export function Reimpresiones({ sesion }: { sesion: Sesion }) {
    const [trabajos, ponTrabajos] = useState<Trabajo[] | null>(null);
    const [aviso, ponAviso] = useState('');
    const [ocupado, ponOcupado] = useState(false);
    async function abre() {
        ponOcupado(true);
        try {
            ponTrabajos(await api<Trabajo[]>('/impresiones', { token: sesion.token }));
        } catch (error) {
            ponAviso((error as Error).message);
        } finally {
            ponOcupado(false);
        }
    }
    async function copia(id: number) {
        ponOcupado(true);
        try {
            await api(`/impresiones/${id}/reimprimir`, { token: sesion.token, datos: {}, llave: uuid() });
            ponAviso('Reimpresión enviada a la cola.');
            await abre();
        } catch (error) {
            ponAviso((error as Error).message);
        } finally {
            ponOcupado(false);
        }
    }
    return <View style={e.panel}>
        <Boton texto={trabajos ? 'Cerrar impresiones' : 'Ver impresiones'} tipo="secundario" ocupado={ocupado}
            alPulsar={() => { ponAviso(''); if (trabajos) ponTrabajos(null); else void abre(); }} />
        {aviso !== '' && <Aviso>{aviso}</Aviso>}
        {trabajos?.length === 0 && <Text style={e.texto}>Sin impresiones.</Text>}
        {trabajos?.map(t => <View key={t.id} style={e.fila}>
            <Text style={e.ayuda}>{tipos[t.tipo]} {t.id} · {t.nombre} · {estados[t.estado]}</Text>
            {Boolean(t.reimprimible) && <Boton texto={`Reimprimir ${t.id}`} tipo="secundario" inactivo={ocupado} alPulsar={() => void copia(t.id)} />}
        </View>)}
    </View>;
}
