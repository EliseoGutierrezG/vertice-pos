import { useEffect, useRef, useState } from 'react';
import { useAudioPlayer } from 'expo-audio';
import { useKeepAwake } from 'expo-keep-awake';
import { ScrollView, Text, useWindowDimensions, View } from 'react-native';
import { api, ErrorApi, estadoItem, Sesion, uuid } from '../nucleo/api';
import type { Platillo } from '../nucleo/api';
import { Cambios, tocaCocina } from '../nucleo/cambios';
import { usaSondeo } from '../nucleo/sondeo';
import { Reimpresiones } from './Reimpresiones';
import { Aviso, Boton, Campo, Dialogo, estilos as e, Insignia } from './ui';

type Area = 'caliente' | 'fria' | 'barra';
type Linea = {
    id: number; id_ronda: number; platillo: string; cantidad: number; nota: string; tiempo: string; asiento: number | null;
    preparacion: Area; estado: string; segundos: number; origen: string; tipo: string; modificadores: { nombre: string }[];
};
type Tablero = { cursor: number; items: Linea[]; impresiones_demoradas: number };
const REPASO = 30000;
const nombres = { caliente: 'Cocina caliente', fria: 'Cocina fría', barra: 'Barra' };
const origenes: Record<string, string> = { mesa: 'Mesa', llevar: 'Para llevar', domicilio: 'Domicilio', mostrador: 'Mostrador' };
const acciones: Record<string, [string, string]> = {
    enviado: ['preparar', 'En preparación'], en_preparacion: ['listo', 'Listo'], listo: ['despachar', 'Despachar'],
};

export function Cocina({ sesion, vence }: { sesion: Sesion; vence: () => void }) {
    useKeepAwake('cocina', { suppressDeactivateWarnings: true });
    const aviso = useAudioPlayer(require('../../assets/aviso-cocina.mp3'));
    const [tablero, ponTablero] = useState<Tablero>();
    const [error, ponError] = useState('');
    const [ocupado, ponOcupado] = useState('');
    const [filtro, ponFiltro] = useState<Area | 'todas'>('todas');
    const [sonido, ponSonido] = useState(false);
    const [menu, ponMenu] = useState(false);
    const [ahora, ponAhora] = useState(Date.now);
    const { width } = useWindowDimensions();

    const cursor = useRef<number | null>(null);
    const leido = useRef(0);
    const sucio = useRef(true);
    const conocidas = useRef<Set<number> | null>(null);

    function suena() {
        return aviso.seekTo(0).then(() => aviso.play()).catch(() => undefined);
    }

    useEffect(() => {
        const intervalo = setInterval(() => ponAhora(Date.now()), 15000);
        return () => clearInterval(intervalo);
    }, []);

    /** Vuelve a leer las comandas sólo si algo las tocó, o cada medio minuto por si acaso. */
    async function actualiza(signal?: AbortSignal, forzado = false) {
        try {
            if (cursor.current !== null && !forzado) {
                const cambios = await api<Cambios>(`/cambios?desde=${cursor.current}`, { token: sesion.token, signal });
                cursor.current = cambios.cursor;
                if (cambios.eventos.length >= 200 || tocaCocina(cambios.eventos)) sucio.current = true;
                if (!sucio.current && Date.now() - leido.current < REPASO) return;
            }
            const nuevo = await api<Tablero>('/cocina', { token: sesion.token, signal });
            if (signal?.aborted) return;
            cursor.current = nuevo.cursor;
            leido.current = Date.now();
            sucio.current = false;
            const rondas = new Set(nuevo.items.map(i => i.id_ronda));
            const previas = conocidas.current;
            if (sonido && previas && nuevo.items.some(i => i.estado === 'enviado' && !previas.has(i.id_ronda))) void suena();
            conocidas.current = rondas;
            ponAhora(leido.current);
            ponTablero(nuevo);
        } catch (err) {
            if (signal?.aborted) return;
            if (err instanceof ErrorApi && err.estado === 401) vence();
            else ponError((err as Error).message);
        }
    }
    usaSondeo(actualiza, sesion.token, { siempreActivo: true });

    const grupos = new Map<string, Linea[]>();
    for (const item of tablero?.items ?? []) {
        if (filtro !== 'todas' && item.preparacion !== filtro) continue;
        const clave = `${item.id_ronda}:${item.preparacion}:${item.estado}`;
        grupos.set(clave, [...(grupos.get(clave) ?? []), item]);
    }
    async function avanza(clave: string, item: Linea, accion: string) {
        ponOcupado(clave);
        ponError('');
        try {
            await api(`/cocina/${item.id_ronda}/${accion}`, { token: sesion.token, llave: uuid(), datos: { area: item.preparacion } });
        } catch (err) {
            ponError((err as Error).message);
        } finally {
            await actualiza(undefined, true);
            ponOcupado('');
        }
    }
    return <ScrollView style={e.fondo} contentContainerStyle={e.pagina}>
        <Text accessibilityRole="header" style={e.h1}>{sesion.tipo === 'barra' ? 'Barra' : 'Cocina'}</Text>
        <View style={e.fila}>
            <Boton texto={sonido ? 'Silenciar avisos' : 'Activar sonido'} tipo="secundario" alPulsar={() => {
                if (!sonido) void suena();
                ponSonido(!sonido);
            }} />
            <Boton texto="Disponibilidad de carta" tipo="secundario" alPulsar={() => ponMenu(true)} />
        </View>
        {sesion.tipo === 'cocina' && <View style={e.fila}>
            <Boton texto="Todas las áreas" tipo={filtro === 'todas' ? 'primario' : 'secundario'} alPulsar={() => ponFiltro('todas')} />
            {(['caliente', 'fria'] as const).map(area => <Boton key={area} texto={nombres[area]}
                tipo={filtro === area ? 'primario' : 'secundario'} alPulsar={() => ponFiltro(area)} />)}
        </View>}
        {error !== '' && <Aviso error>{error}</Aviso>}
        {!!tablero?.impresiones_demoradas && <Aviso>{tablero.impresiones_demoradas === 1 ? '1 impresión pendiente o fallida.' : `${tablero.impresiones_demoradas} impresiones pendientes o fallidas.`} Revise el equipo impresor.</Aviso>}
        {grupos.size === 0 && <Text style={e.texto}>{tablero ? 'Sin comandas en esta área.' : 'Cargando comandas…'}</Text>}
        <View style={e.cuadricula}>{[...grupos.entries()].map(([clave, items]) => {
            const item = items[0];
            const [accion, texto] = acciones[item.estado];
            const minutos = Math.max(0, Math.floor((Number(item.segundos) + Math.max(0, ahora - leido.current) / 1000) / 60));
            const tiempo = minutos >= 20 ? 'riesgo' : minutos >= 10 ? 'aviso' : 'exito';
            return <View key={clave} style={[e.panel, { width: width >= 1050 ? '32%' : width >= 720 ? '48.5%' : '100%' }]}>
                <View style={e.fila}>
                    <Text style={e.h2}>{origenes[item.tipo] ?? 'Pedido'} {item.origen}</Text>
                    <Insignia texto={`${minutos} min`} tono={tiempo} />
                </View>
                <Text style={e.ayuda}>{nombres[item.preparacion]} · {estadoItem[item.estado]} · Ronda {item.id_ronda}</Text>
                {items.map(i => <View key={i.id}>
                    <Text style={e.h3}>{i.cantidad} × {i.platillo}</Text>
                    <Text style={e.ayuda}>{[i.tiempo === 'entrada' ? 'Entrada' : 'Fuerte', i.asiento ? 'Asiento ' + i.asiento : '',
                        ...i.modificadores.map(m => m.nombre), i.nota].filter(Boolean).join(' · ')}</Text>
                </View>)}
                <View style={e.fila}>
                    <Boton texto={texto} ocupado={ocupado === clave} inactivo={ocupado !== ''} alPulsar={() => void avanza(clave, item, accion)} />
                    {item.estado === 'listo' && <Boton texto="Retomar" tipo="secundario" inactivo={ocupado !== ''}
                        alPulsar={() => void avanza(clave, item, 'retomar')} />}
                </View>
            </View>;
        })}</View>
        <Reimpresiones sesion={sesion} />
        {menu && <Disponibilidad sesion={sesion} vence={vence} cierra={() => ponMenu(false)} />}
    </ScrollView>;
}

function Disponibilidad({ sesion, vence, cierra }: { sesion: Sesion; vence: () => void; cierra: () => void }) {
    const [carta, ponCarta] = useState<Platillo[] | null>(null);
    const [error, ponError] = useState('');
    const [ocupado, ponOcupado] = useState<number | null>(null);
    const [busqueda, ponBusqueda] = useState('');

    function fallo(err: unknown) {
        if (err instanceof ErrorApi && err.estado === 401) vence();
        else ponError((err as Error).message);
    }
    useEffect(() => {
        const peticion = new AbortController();
        void api<Platillo[]>('/carta', { token: sesion.token, signal: peticion.signal }).then(ponCarta)
            .catch(err => { if (!peticion.signal.aborted) fallo(err); });
        return () => peticion.abort();
    }, [sesion.token]);

    async function cambia(platillo: Platillo) {
        if (ocupado !== null) return;
        ponError('');
        ponOcupado(platillo.id);
        const agotado = platillo.agotado ? 0 : 1;
        try {
            await api(`/carta/${platillo.id}/agotado`, { token: sesion.token, llave: uuid(), datos: { agotado } });
            ponCarta(actual => actual?.map(p => p.id === platillo.id ? { ...p, agotado } : p) ?? null);
        } catch (err) {
            fallo(err);
        } finally {
            ponOcupado(null);
        }
    }
    const lista = carta?.filter(p => (p.preparacion === 'barra') === (sesion.tipo === 'barra')
        && p.nombre.toLocaleLowerCase('es-MX').includes(busqueda.trim().toLocaleLowerCase('es-MX')));
    return <Dialogo titulo="Disponibilidad de carta" cierra={cierra} error={error}>
        <Campo etiqueta="Buscar platillo" value={busqueda} onChangeText={ponBusqueda} />
        {!lista && error === '' && <Text style={e.ayuda}>Cargando carta…</Text>}
        {lista?.length === 0 && <Text style={e.ayuda}>Sin platillos con esa búsqueda.</Text>}
        {lista?.map(p => <View style={e.entre} key={p.id}>
            <Text style={[e.texto, { flex: 1 }]}>{p.nombre}</Text>
            <Boton texto={p.agotado ? 'Marcar disponible' : 'Marcar agotado'} tipo="secundario" ocupado={ocupado === p.id}
                inactivo={ocupado !== null} alPulsar={() => void cambia(p)} />
        </View>)}
    </Dialogo>;
}
