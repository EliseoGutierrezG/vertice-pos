import type { ReactNode } from 'react';
import { Image, ImageBackground, Platform, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import type { ViewStyle } from 'react-native';
import { marca } from '../nucleo/marca';
import { c } from './ui';

// La pantalla de acceso, como la de Barrica: una foto del giro con un velo de
// tinta que se oscurece hacia donde va el texto, y el formulario en una hoja
// blanca. En teléfono la foto va arriba; en tableta horizontal y en la PC va
// al lado, igual que la entrada del panel. La foto es decorativa.
const FOTO = require('../../assets/entrar.jpg');
const PLACA = require('../../assets/placa.png');

// El degradado va de transparente a casi tinta. `backgroundColor` queda debajo
// por si la plataforma no pinta degradados.
function velo(direccion: 'abajo' | 'izquierda'): ViewStyle {
    const hacia = direccion === 'abajo' ? '180deg' : '90deg';
    const degradado = `linear-gradient(${hacia}, rgba(13,27,62,0.15) 0%, rgba(13,27,62,0.10) 35%, rgba(13,27,62,0.82) 70%, rgba(13,27,62,0.95) 100%)`;
    return Platform.OS === 'web'
        ? ({ backgroundImage: degradado } as unknown as ViewStyle)
        : { backgroundColor: 'rgba(13,27,62,0.25)', experimental_backgroundImage: degradado };
}

export function Acceso({ titulo, detalle, children }: { titulo: string; detalle?: string; children: ReactNode }) {
    const { width, fontScale } = useWindowDimensions();
    const ancho = width >= 900;

    const encabezado = <View style={e.vidrio}>
        <Image accessible={false} source={PLACA} style={e.placa} />
        <View style={{ flexShrink: 1 }}>
            <Text style={e.antetitulo} maxFontSizeMultiplier={1.6}>Comanda de la sucursal</Text>
            <Text style={e.nombre} maxFontSizeMultiplier={1.6} accessibilityRole="header">{marca.nombre}</Text>
        </View>
    </View>;

    const hoja = <View style={[e.hoja, ancho && e.hojaAncha]}>
        <View style={{ gap: 6 }}>
            <Text style={e.titulo} accessibilityRole="header">{titulo}</Text>
            {detalle ? <Text style={e.detalle}>{detalle}</Text> : null}
        </View>
        {children}
        <Text style={e.pie}>{marca.lema}</Text>
    </View>;

    if (ancho) {
        return <View style={e.filaAncha}>
            <View style={e.columnaForma}>{hoja}</View>
            <ImageBackground accessible={false} source={FOTO} resizeMode="cover" style={e.fotoLado}>
                <View style={[e.veloLado, velo('abajo')]}>
                    {encabezado}
                    <Text style={e.titular}>Mesas, cocina y caja de cada sucursal en un lugar.</Text>
                </View>
            </ImageBackground>
        </View>;
    }

    return <View style={{ flexGrow: 1 }}>
        <ImageBackground accessible={false} source={FOTO} resizeMode="cover"
            style={[e.foto, fontScale >= 1.6 && e.fotoCorta]}>
            <View style={[e.velo, velo('abajo')]}>{encabezado}</View>
        </ImageBackground>
        {hoja}
    </View>;
}

const RADIO = 28;
const e = StyleSheet.create({
    foto: { height: 300, backgroundColor: c.tinta, overflow: 'hidden' },
    fotoCorta: { height: 210 },
    velo: { flex: 1, justifyContent: 'flex-end', paddingHorizontal: 24, paddingBottom: 24 + RADIO },
    vidrio: {
        flexDirection: 'row', alignItems: 'center', gap: 14, alignSelf: 'flex-start', maxWidth: '100%',
        padding: 12, paddingRight: 20, borderRadius: 22,
        backgroundColor: 'rgba(255,255,255,0.10)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.22)',
    },
    placa: { width: 52, height: 52, borderRadius: 14, borderWidth: 1, borderColor: 'rgba(255,255,255,0.22)' },
    antetitulo: { color: c.limon, fontSize: 12, fontWeight: '800', letterSpacing: 0.6, textTransform: 'uppercase' },
    nombre: { color: c.superficie, fontSize: 30, lineHeight: 36, fontWeight: '900', letterSpacing: -0.8 },
    hoja: {
        flexGrow: 1, marginTop: -RADIO, backgroundColor: c.superficie,
        borderTopLeftRadius: RADIO, borderTopRightRadius: RADIO,
        paddingHorizontal: 24, paddingTop: 30, paddingBottom: 28, gap: 16,
        width: '100%', maxWidth: 560, alignSelf: 'center',
    },
    hojaAncha: { marginTop: 0, borderRadius: 0, flexGrow: 0, maxWidth: 440, paddingHorizontal: 8 },
    titulo: { color: c.tinta, fontSize: 28, lineHeight: 33, fontWeight: '900', letterSpacing: -0.8 },
    detalle: { color: c.secundario, fontSize: 15, lineHeight: 21 },
    pie: { marginTop: 8, paddingTop: 14, borderTopWidth: 1, borderTopColor: '#E3E7EC', color: c.secundario, fontSize: 13, textAlign: 'center' },
    filaAncha: { flex: 1, flexDirection: 'row', backgroundColor: c.superficie },
    columnaForma: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
    fotoLado: { flex: 1.1, backgroundColor: c.tinta },
    veloLado: { flex: 1, justifyContent: 'flex-end', padding: 44, gap: 22 },
    titular: { color: c.superficie, fontSize: 34, lineHeight: 40, fontWeight: '900', letterSpacing: -0.9, maxWidth: 460 },
});
