import { useState } from 'react';
import { Text, View } from 'react-native';
import { dinero } from '../nucleo/api';
import { aCentavos, aPesos, billetes, porcentaje } from '../nucleo/dinero';
import type { Mutacion } from '../nucleo/mutacion';
import { Firma } from './Caja';
import { Aviso, Boton, c, Campo, estilos as e } from './ui';

const medios = ['efectivo', 'tarjeta', 'transferencia'] as const;
type Medio = typeof medios[number];
const nombres: Record<Medio, string> = { efectivo: 'Efectivo', tarjeta: 'Tarjeta', transferencia: 'Transferencia' };
/** `importe` vacío en el único pago quiere decir «todo el total»: lo sigue si cambian propina o descuento. */
type Forma = { medio: Medio; importe: string; recibido: string; referencia: string };
const nueva = (importe = ''): Forma => ({ medio: 'efectivo', importe, recibido: '', referencia: '' });
const pesos = (centavos: number) => dinero(centavos / 100);

/**
 * El cobro de una cuenta.
 *
 *   consumo − descuento = venta;  venta + propina = total;  recibido − importe = cambio
 *
 * `motivos` son las razones por las que todavía no se puede cobrar. Con
 * alguna, la pantalla las explica en vez de dejar el botón apagado sin decir por qué.
 */
export function Cobro({ ruta, totalCuenta, datosCuenta, ejecuta, ocupado, motivos, cancela }: {
    ruta: string; totalCuenta: string; datosCuenta: object;
    ejecuta: Mutacion; ocupado: boolean; motivos: string[]; cancela: () => void;
}) {
    const [formas, ponFormas] = useState<Forma[]>([nueva()]);
    const [tantoPropina, ponTantoPropina] = useState<number | null>(0);
    const [propinaLibre, ponPropinaLibre] = useState('');
    const [modoDescuento, ponModoDescuento] = useState<'porcentaje' | 'importe' | null>(null);
    const [valorDescuento, ponValorDescuento] = useState('');
    const [motivo, ponMotivo] = useState('');
    const [firma, ponFirma] = useState({ usuario: '', clave: '', codigo: '' });

    const consumo = aCentavos(totalCuenta);
    const tanto = /^([1-9]\d?|100)$/.test(valorDescuento) ? Number(valorDescuento) : 0;
    const descuento = modoDescuento === 'porcentaje' ? porcentaje(consumo, tanto)
        : modoDescuento === 'importe' ? aCentavos(valorDescuento) || 0 : 0;
    const venta = consumo - descuento;
    const propina = tantoPropina !== null ? porcentaje(venta, tantoPropina) : aCentavos(propinaLibre) || 0;
    const total = venta + propina;

    const unico = formas.length === 1 && formas[0].importe === '';
    const importeDe = (forma: Forma) => unico ? total : aCentavos(forma.importe) || 0;
    const pagado = formas.reduce((suma, forma) => suma + importeDe(forma), 0);
    const resta = total - pagado;
    const cambioDe = (forma: Forma) => {
        const recibido = aCentavos(forma.recibido);
        return forma.medio === 'efectivo' && recibido >= importeDe(forma) ? recibido - importeDe(forma) : 0;
    };
    const cambio = formas.reduce((suma, forma) => suma + cambioDe(forma), 0);
    const define = (indice: number, campos: Partial<Forma>) =>
        ponFormas(formas.map((forma, i) => i === indice ? { ...forma, ...campos } : forma));

    const faltas = [
        descuento > consumo ? 'El descuento supera el consumo.' : '',
        modoDescuento && descuento === 0 ? 'Capture el descuento.' : '',
        descuento > 0 && !motivo.trim() ? 'Escriba el motivo del descuento.' : '',
        descuento > 0 && !(firma.usuario && firma.clave) ? 'Falta la autorización de gerencia.' : '',
        tantoPropina === null && propinaLibre !== '' && Number.isNaN(aCentavos(propinaLibre)) ? 'Revise la propina.' : '',
        total > 0 && resta > 0 ? `Faltan ${pesos(resta)} por pagar.` : '',
        resta < 0 ? `Sobran ${pesos(-resta)} en los pagos.` : '',
        total > 0 && formas.some(forma => importeDe(forma) <= 0) ? 'Cada pago lleva un importe.' : '',
        formas.some(forma => forma.medio === 'efectivo' && forma.recibido !== '' && !(aCentavos(forma.recibido) >= importeDe(forma)))
            ? 'Lo recibido no cubre el efectivo.' : '',
        total > 0 && formas.some(forma => forma.medio !== 'efectivo' && !forma.referencia.trim()) ? 'Escriba la referencia del pago.' : '',
    ].filter(Boolean);

    function confirma() {
        void ejecuta(ruta, {
            ...datosCuenta,
            formas: total === 0 ? [] : formas.map(forma => ({
                medio: forma.medio, importe: aPesos(importeDe(forma)),
                referencia: forma.medio === 'efectivo' ? undefined : forma.referencia.trim(),
                recibido: forma.medio === 'efectivo' && forma.recibido !== '' ? aPesos(aCentavos(forma.recibido)) : undefined,
            })),
            propina: aPesos(propina),
            ...(modoDescuento === 'porcentaje' ? { descuento_porcentaje: tanto } : { descuento: aPesos(descuento) }),
            descuento_motivo: descuento > 0 ? motivo.trim() : undefined,
            autorizacion: descuento > 0 ? firma : undefined,
        });
    }

    const renglon = (titulo: string, valor: string, fuerte = false) => <View style={[e.fila, { justifyContent: 'space-between' }]}>
        <Text style={fuerte ? e.h2 : e.texto}>{titulo}</Text><Text style={fuerte ? e.h2 : e.texto}>{valor}</Text>
    </View>;

    return <View style={e.panel}>
        <Text style={e.h2} accessibilityRole="header">Cobro</Text>
        {motivos.length > 0 && <Aviso>{motivos.join(' ')}</Aviso>}
        <View style={{ gap: 4 }}>
            {renglon('Consumo', pesos(consumo))}
            {descuento > 0 && renglon('Descuento', '−' + pesos(descuento))}
            {propina > 0 && renglon('Propina', pesos(propina))}
            {renglon('Total a cobrar', pesos(total), true)}
        </View>

        <Text style={e.h3}>Propina</Text>
        <View style={e.fila}>
            {[0, 10, 15, 20].map(t => <Boton key={t} texto={t === 0 ? 'Sin propina' : `${t} %`}
                tipo={tantoPropina === t ? 'primario' : 'secundario'} alPulsar={() => ponTantoPropina(t)} />)}
            <Boton texto="Otra" tipo={tantoPropina === null ? 'primario' : 'secundario'} alPulsar={() => ponTantoPropina(null)} />
        </View>
        {tantoPropina === null && <Campo etiqueta="Importe de la propina" value={propinaLibre} onChangeText={ponPropinaLibre} keyboardType="decimal-pad" />}

        <Text style={e.h3}>Descuento</Text>
        <View style={e.fila}>
            <Boton texto="Sin descuento" tipo={modoDescuento === null ? 'primario' : 'secundario'} alPulsar={() => ponModoDescuento(null)} />
            <Boton texto="En porcentaje" tipo={modoDescuento === 'porcentaje' ? 'primario' : 'secundario'}
                alPulsar={() => { ponModoDescuento('porcentaje'); ponValorDescuento(''); }} />
            <Boton texto="En importe" tipo={modoDescuento === 'importe' ? 'primario' : 'secundario'}
                alPulsar={() => { ponModoDescuento('importe'); ponValorDescuento(''); }} />
        </View>
        {modoDescuento && <>
            <Campo etiqueta={modoDescuento === 'porcentaje' ? 'Porcentaje, de 1 a 100' : 'Importe del descuento'} value={valorDescuento}
                onChangeText={ponValorDescuento} keyboardType={modoDescuento === 'porcentaje' ? 'number-pad' : 'decimal-pad'} maxLength={modoDescuento === 'porcentaje' ? 3 : 11} />
            <Campo etiqueta="Motivo del descuento" value={motivo} onChangeText={ponMotivo} maxLength={120} />
            <Firma datos={firma} cambia={ponFirma} />
        </>}

        {total > 0 && formas.map((forma, i) => <View style={e.panel} key={i}>
            <Text style={e.h3}>{formas.length === 1 ? 'Forma de pago' : `Pago ${i + 1}`}</Text>
            <View style={e.fila}>{medios.map(medio => <Boton key={medio} texto={nombres[medio]}
                tipo={forma.medio === medio ? 'primario' : 'secundario'} alPulsar={() => define(i, { medio, referencia: '', recibido: '' })} />)}</View>
            {formas.length > 1 && <Campo etiqueta={`Importe del pago ${i + 1}`} value={forma.importe} keyboardType="decimal-pad"
                onChangeText={importe => define(i, { importe })} />}
            {forma.medio === 'efectivo' ? <>
                <Campo etiqueta="Recibido" value={forma.recibido} keyboardType="decimal-pad" onChangeText={recibido => define(i, { recibido })} />
                <View style={e.fila}>
                    <Boton texto="Exacto" tipo="secundario" alPulsar={() => define(i, { recibido: aPesos(importeDe(forma)) })} />
                    {billetes(importeDe(forma)).map(billete => <Boton key={billete} texto={pesos(billete)} tipo="secundario"
                        alPulsar={() => define(i, { recibido: aPesos(billete) })} />)}
                </View>
                {cambioDe(forma) > 0 && <Text style={[e.h2, { color: c.exito }]} accessibilityLiveRegion="polite">Cambio {pesos(cambioDe(forma))}</Text>}
            </> : <Campo etiqueta="Referencia de pago" value={forma.referencia} maxLength={80} onChangeText={referencia => define(i, { referencia })} />}
            {formas.length > 1 && <Boton texto={`Quitar pago ${i + 1}`} tipo="secundario"
                alPulsar={() => ponFormas(formas.length === 2 ? [{ ...formas[1 - i], importe: '' }] : formas.filter((_, j) => i !== j))} />}
        </View>)}
        {total > 0 && formas.length < 20 && <Boton texto="Dividir el pago" tipo="secundario" alPulsar={() => ponFormas(unico
            ? [{ ...formas[0], importe: aPesos(total) }, nueva('')]
            : [...formas, nueva(resta > 0 ? aPesos(resta) : '')])} />}

        {formas.length > 1 && cambio > 0 && <Text style={[e.h3, { color: c.exito }]}>Cambio total {pesos(cambio)}</Text>}
        {faltas.length > 0 && motivos.length === 0 && <Text style={e.ayuda} accessibilityLiveRegion="polite">{faltas[0]}</Text>}
        <View style={e.fila}>
            <Boton texto={`Cobrar ${pesos(total)}`} alPulsar={confirma} ocupado={ocupado} inactivo={motivos.length > 0 || faltas.length > 0} />
            <Boton texto="Cancelar" tipo="secundario" alPulsar={cancela} inactivo={ocupado} />
        </View>
    </View>;
}
