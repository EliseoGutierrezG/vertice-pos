import { useState } from 'react';
import { Text, View } from 'react-native';
import { dinero } from '../nucleo/api';
import { aCentavos } from '../nucleo/dinero';
import type { EstadoSalon } from '../nucleo/salon';
import { Aviso, Boton, Contador, Dialogo, estilos as e, Pestanas } from './ui';

const modos = [
    { clave: 'asiento', texto: 'Por asiento' },
    { clave: 'platillos', texto: 'Por platillos' },
    { clave: 'partes', texto: 'Partes iguales' },
    { clave: 'reune', texto: 'Reunir cuentas' },
] as const;

export function Separa({ salon: s, cierra, enPanel = false }: { salon: EstadoSalon; cierra: () => void; enPanel?: boolean }) {
    const [modo, ponModo] = useState<typeof modos[number]['clave']>('asiento');
    const [asiento, ponAsiento] = useState<number | null>(null);
    const [seleccion, ponSeleccion] = useState<number[]>([]);
    const [partes, ponPartes] = useState(2);
    const cuenta = s.cuenta;
    if (!cuenta) return null;

    const grupo = cuenta.grupo ?? [];
    const otras = grupo.filter(p => p.id !== cuenta.id);
    const items = cuenta.items.filter(i => i.estado !== 'cancelado');
    const asientos = [...new Set(items.flatMap(i => i.asiento ? [i.asiento] : []))].sort((a, b) => a - b);
    const elegidos = items.filter(i => modo === 'asiento' ? i.asiento === asiento : seleccion.includes(i.id));
    const importe = elegidos.reduce((total, i) => total + aCentavos(i.precio) * i.cantidad, 0);
    const total = aCentavos(cuenta.total);
    const base = Math.floor(total / partes);
    const resto = total % partes;
    const hayPendientes = s.pendientes.some(p => p.cuenta === cuenta.id || grupo.some(g => g.id === p.cuenta));
    const ajustada = Number(cuenta.ajuste_reparto ?? '0') !== 0;
    const bloqueoSeparar = ajustada ? 'La cuenta ya tiene un reparto.' : elegidos.length === items.length && items.length > 0
        ? 'Deje un platillo en la cuenta de origen.' : '';
    const bloqueoRepartir = otras.length > 0 || ajustada ? 'Reúna las cuentas antes de repartir.'
        : items.some(i => i.estado === 'capturado') ? 'Envíe a cocina los platillos pendientes.' : '';

    async function confirma() {
        if (modo === 'reune') {
            const versiones = Object.fromEntries(otras.map(p => [p.id, p.version]));
            if (await s.cambiaCuenta('reune', { versiones })) cierra();
        } else if (modo === 'partes') {
            if (await s.cambiaCuenta('reparte', { partes })) cierra();
        } else {
            const datos = modo === 'asiento' ? { modo, asiento } : { modo, items: elegidos.map(i => i.id) };
            if (await s.cambiaCuenta('separa', datos)) cierra();
        }
    }

    const formulario = <>
        <Pestanas etiqueta="Forma de dividir" opciones={modos.filter(op => op.clave !== 'reune' || (otras.length > 0 && cuenta.id_mesa !== null))}
            actual={modo} elige={ponModo} />
        {modo === 'asiento' && (asientos.length > 0
            ? <Pestanas etiqueta="Asiento" opciones={asientos.map(a => ({ clave: a, texto: `Asiento ${a}` }))} actual={asiento} elige={ponAsiento} />
            : <Aviso>Ningún platillo tiene asiento asignado.</Aviso>)}
        {modo === 'platillos' && <View style={{ gap: 8 }}>
            {items.map(i => <Boton key={i.id} texto={`${i.cantidad} × ${i.platillo} · ${dinero(i.cantidad * Number(i.precio))}`}
                tipo={seleccion.includes(i.id) ? 'primario' : 'secundario'}
                alPulsar={() => ponSeleccion(actual => actual.includes(i.id) ? actual.filter(id => id !== i.id) : [...actual, i.id])} />)}
        </View>}
        {(modo === 'asiento' || modo === 'platillos') && <>
            {bloqueoSeparar ? <Aviso>{bloqueoSeparar}</Aviso> : elegidos.length > 0 &&
                <Text style={e.texto}>Nueva cuenta · {dinero(importe / 100)}</Text>}
            <Boton texto="Crear cuenta separada" ocupado={s.ocupado} inactivo={s.sinConexion || hayPendientes || !!bloqueoSeparar || elegidos.length === 0}
                alPulsar={() => void confirma()} />
        </>}
        {modo === 'partes' && <>
            <Contador etiqueta="Número de cuentas" valor={partes} cambia={ponPartes} minimo={2} maximo={20} />
            {bloqueoRepartir ? <Aviso>{bloqueoRepartir}</Aviso> : base > 0 && <Text style={e.texto}>
                {resto ? `${resto} de ${dinero((base + 1) / 100)} y ${partes - resto} de ${dinero(base / 100)}` : `${partes} de ${dinero(base / 100)}`}
            </Text>}
            <Boton texto="Repartir saldo" ocupado={s.ocupado} inactivo={s.sinConexion || hayPendientes || !!bloqueoRepartir || base < 1}
                alPulsar={() => void confirma()} />
        </>}
        {modo === 'reune' && <>
            <Text style={e.texto}>Los platillos y saldos de las {otras.length + 1} cuentas abiertas se reunirán en esta cuenta.</Text>
            <Boton texto="Reunir cuentas abiertas" ocupado={s.ocupado}
                inactivo={s.sinConexion || hayPendientes || otras.length === 0 || cuenta.id_mesa === null}
                alPulsar={() => void confirma()} />
        </>}
        {hayPendientes && <Aviso>Espere a que se guarden los platillos pendientes.</Aviso>}
    </>;
    if (!enPanel) return <Dialogo titulo="Dividir cuenta" cierra={cierra} error={s.error}>{formulario}</Dialogo>;
    return <View style={e.panel}>
        <View style={e.entre}>
            <Text accessibilityRole="header" style={e.h2}>Dividir cuenta</Text>
            <Boton texto="Volver a la carta" tipo="secundario" alPulsar={cierra} inactivo={s.ocupado} />
        </View>
        {s.error !== '' && <Aviso error>{s.error}</Aviso>}
        {formulario}
    </View>;
}
