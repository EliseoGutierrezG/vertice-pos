import { useMemo, useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { dinero, origen, Platillo } from '../nucleo/api';
import { aCentavos } from '../nucleo/dinero';
import { tiempos } from './Cuenta';
import { Boton, c, Campo, Contador, Dialogo, estilos as e, Insignia, Pestanas, tintes } from './ui';

const propios = StyleSheet.create({
    ficha: { flexGrow: 1, flexBasis: 150, maxWidth: 240, minHeight: 76, backgroundColor: c.superficie, borderRadius: 12,
        borderWidth: 1, borderColor: tintes.neutro, overflow: 'hidden' },
    foto: { width: '100%', height: 96, backgroundColor: tintes.neutro },
    sinFoto: { height: 96, backgroundColor: tintes.primario, alignItems: 'center', justifyContent: 'center' },
    inicial: { color: c.primario, fontSize: 34, fontWeight: '900' },
    precio: { color: c.primario, fontSize: 15, fontWeight: '800', fontVariant: ['tabular-nums'] },
    antes: { color: c.secundario, fontSize: 13, textDecorationLine: 'line-through', fontVariant: ['tabular-nums'] },
});

/** Precio de la ficha: el de promoción, si la hay, con el de lista tachado. */
function Precio({ p }: { p: Platillo }) {
    const promo = p.promocion;
    if (!promo?.precio_promocion) return <Text style={propios.precio}>{dinero(p.precio)}</Text>;
    return <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 6, flexWrap: 'wrap' }}>
        <Text style={propios.precio}>{dinero(promo.precio_promocion)}</Text>
        <Text style={propios.antes} accessibilityLabel={`Antes ${dinero(p.precio)}`}>{dinero(p.precio)}</Text>
    </View>;
}
/** «camaron» encuentra «Camarón»: en servicio nadie escribe acentos. */
const llano = (texto: string) => texto.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

/**
 * La carta para capturar: se busca o se recorre por categoría, y un toque
 * abre el platillo con su cantidad, sus modificadores y su nota.
 */
export type CapturaCarta = { cantidad: number; nota: string; tiempo: string; asiento?: string; modificadores: number[] };
type Agrega = (platillo: Platillo, captura: CapturaCarta) => Promise<boolean>;

export function Carta({ carta, agrega, mostrador = false }: { carta: Platillo[]; agrega: Agrega; mostrador?: boolean }) {
    const [busqueda, ponBusqueda] = useState('');
    const [categoria, ponCategoria] = useState<string | null>(null);
    const [platillo, ponPlatillo] = useState<Platillo | null>(null);
    const categorias = useMemo(() => [...new Set(carta.map(p => p.categoria))], [carta]);
    const buscado = llano(busqueda.trim());
    // Buscar recorre toda la carta, sin importar la categoría que esté elegida.
    const lista = carta.filter(p => buscado !== '' ? llano(p.categoria + ' ' + p.nombre).includes(buscado)
        : categoria === null || p.categoria === categoria);
    const conFoto = lista.some(p => p.foto);

    if (carta.length === 0) return <Text style={e.texto}>La sucursal todavía no tiene platillos disponibles.</Text>;
    return <View style={{ gap: 14 }}>
        <Campo etiqueta="Buscar platillo" value={busqueda} onChangeText={ponBusqueda} autoCorrect={false} returnKeyType="search" />
        {buscado === '' && categorias.length > 1 && <Pestanas etiqueta="Categorías" actual={categoria} elige={ponCategoria}
            opciones={[{ clave: null, texto: 'Toda la carta' }, ...categorias.map(nombre => ({ clave: nombre, texto: nombre }))]} />}
        {lista.length === 0 && <Text style={e.texto}>Ningún platillo coincide.</Text>}
        {categorias.filter(nombre => lista.some(p => p.categoria === nombre)).map(nombre => <View key={nombre} style={{ gap: 10 }}>
            <Text accessibilityRole="header" style={e.h3}>{nombre}</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
                {lista.filter(p => p.categoria === nombre).map(p => <Pressable key={p.id} disabled={Boolean(p.agotado)} onPress={() => ponPlatillo(p)}
                    accessibilityRole="button" accessibilityState={{ disabled: Boolean(p.agotado) }}
                    accessibilityLabel={`${p.nombre}, ${dinero(p.promocion?.precio_promocion ?? p.precio)}${p.promocion ? ', promoción ' + p.promocion.etiqueta : ''}${p.agotado ? ', agotado' : ''}`}
                    style={({ pressed }) => [propios.ficha, pressed && e.presionado, Boolean(p.agotado) && e.inactivo]}>
                    {conFoto && (p.foto
                        ? <Image source={{ uri: origen() + p.foto }} style={propios.foto} resizeMode="cover" accessible={false} />
                        : <View style={propios.sinFoto}><Text style={propios.inicial}>{p.nombre.charAt(0)}</Text></View>)}
                    <View style={{ padding: 10, gap: 6, flex: 1, justifyContent: 'space-between' }}>
                        <Text style={[e.h3, { fontSize: 16 }]} numberOfLines={2}>{p.nombre}</Text>
                        <View style={e.entre}>
                            <Precio p={p} />
                            {Boolean(p.agotado) ? <Insignia texto="Agotado" tono="riesgo" />
                                : p.promocion && <Insignia texto={p.promocion.etiqueta} tono="exito" />}
                        </View>
                    </View>
                </Pressable>)}
            </View>
        </View>)}
        {platillo && <Captura key={platillo.id} platillo={platillo} agrega={agrega} mostrador={mostrador} cierra={() => ponPlatillo(null)} />}
    </View>;
}

function Captura({ platillo, agrega, mostrador, cierra }: {
    platillo: Platillo; agrega: Agrega; mostrador: boolean; cierra: () => void;
}) {
    const [cantidad, ponCantidad] = useState(1);
    const [modificadores, ponModificadores] = useState<number[]>([]);
    const [tiempo, ponTiempo] = useState('fuerte');
    const [asiento, ponAsiento] = useState('');
    const [nota, ponNota] = useState('');
    const unitario = aCentavos(platillo.precio) + platillo.modificadores.filter(m => modificadores.includes(m.id))
        .reduce((suma, m) => suma + (aCentavos(m.suplemento) || 0), 0);
    return <Dialogo titulo={platillo.nombre} cierra={cierra}>
        {!!platillo.descripcion && <Text style={e.ayuda}>{platillo.descripcion}</Text>}
        {platillo.promocion && <Text style={e.ayuda}>{platillo.promocion.etiqueta} · {platillo.promocion.nombre}. Se aplica al agregar.</Text>}
        <Contador etiqueta="Cantidad" valor={cantidad} cambia={ponCantidad} />
        {platillo.modificadores.length > 0 && <View style={e.campo}>
            <Text style={e.h3}>Modificadores</Text>
            <View style={e.fila}>{platillo.modificadores.map(m => {
                const puesto = modificadores.includes(m.id);
                return <Boton key={m.id} texto={m.nombre + (Number(m.suplemento) > 0 ? ' +' + dinero(m.suplemento) : '')}
                    tipo={puesto ? 'primario' : 'secundario'}
                    alPulsar={() => ponModificadores(puesto ? modificadores.filter(id => id !== m.id) : [...modificadores, m.id])} />;
            })}</View>
        </View>}
        {!mostrador && <>
            <Pestanas etiqueta="Tiempo" opciones={tiempos} actual={tiempo} elige={ponTiempo} />
            <Campo etiqueta="Asiento (opcional)" value={asiento} onChangeText={ponAsiento} keyboardType="number-pad" maxLength={2} />
        </>}
        <Campo etiqueta="Nota (opcional)" value={nota} onChangeText={ponNota} maxLength={240} />
        <Boton texto={`Agregar ${dinero(unitario * cantidad / 100)}`} inactivo={asiento !== '' && !/^[1-9]\d?$/.test(asiento)}
            alPulsar={() => void agrega(platillo, { cantidad, nota, tiempo, asiento: asiento || undefined, modificadores })
                .then(ok => { if (ok) cierra(); })} />
    </Dialogo>;
}
