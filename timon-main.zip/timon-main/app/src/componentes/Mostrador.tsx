import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { dinero } from '../nucleo/api';
import type { Platillo } from '../nucleo/api';
import { aCentavos, aPesos } from '../nucleo/dinero';
import type { Mutacion } from '../nucleo/mutacion';
import type { Cotizacion, EstadoSalon } from '../nucleo/salon';
import { Turno } from './Caja';
import { Carta } from './Carta';
import type { CapturaCarta } from './Carta';
import { Cobro } from './Cobro';
import { Aviso, Boton, DosPaneles, estilos as e } from './ui';

type Renglon = { clave: number; platillo: Platillo; captura: CapturaCarta; importe: number };

export function Mostrador({ salon: s, ejecuta, ancho }: { salon: EstadoSalon; ejecuta: Mutacion; ancho: number | null }) {
    const [items, ponItems] = useState<Renglon[]>([]);
    const [serie, ponSerie] = useState(0);
    const [cobrando, ponCobrando] = useState(false);
    // El servicio calcula las promociones; el cobro usa ese total para que
    // cuadre al centavo con lo que guardará la venta.
    const [cotizacion, ponCotizacion] = useState<Cotizacion | null>(null);
    const [sinCotizar, ponSinCotizar] = useState(false);
    const datosVenta = items.map(i => ({ id_platillo: i.platillo.id, ...i.captura }));
    const firma = JSON.stringify(datosVenta);
    useEffect(() => {
        ponCotizacion(null);
        ponSinCotizar(false);
        if (items.length === 0) return;
        const control = new AbortController();
        const espera = setTimeout(() => {
            s.cotiza(datosVenta, control.signal).then(ponCotizacion).catch(() => {
                if (!control.signal.aborted) ponSinCotizar(true);
            });
        }, 250);
        return () => { clearTimeout(espera); control.abort(); };
    }, [firma]);
    const total = cotizacion ? aCentavos(cotizacion.total) : items.reduce((suma, item) => suma + item.importe, 0);
    const motivos = [
        s.sinConexion ? 'Necesita conexión para cobrar.' : '',
        !s.estadoCaja?.turno ? 'Abra un turno de caja.' : '',
        items.length === 0 ? 'Agregue platillos a la venta.' : '',
        items.length > 0 && !cotizacion ? 'Calculando el total con promociones.' : '',
    ].filter(Boolean);

    async function agrega(platillo: Platillo, captura: CapturaCarta) {
        if (items.length >= 100 || cobrando || s.ocupado) return false;
        const suplemento = platillo.modificadores.filter(m => captura.modificadores.includes(m.id))
            .reduce((suma, m) => suma + aCentavos(m.suplemento), 0);
        const importe = captura.cantidad * (aCentavos(platillo.precio) + suplemento);
        ponItems([...items, { clave: serie, platillo, captura, importe }]);
        ponSerie(serie + 1);
        return true;
    }

    const cobra: Mutacion = async (ruta, datos) => {
        const resultado = await ejecuta(ruta, datos);
        if (resultado?.ticket) {
            ponItems([]);
            ponCobrando(false);
        }
        return resultado;
    };

    const venta = <View style={e.panel}>
        <Text accessibilityRole="header" style={e.h2}>Venta actual</Text>
        {items.length === 0 && <Text style={e.ayuda}>Agregue platillos de la carta.</Text>}
        {items.map(({ clave, platillo, captura, importe }, n) => <View key={clave} style={e.entre}>
            <View style={{ flex: 1 }}>
                <Text style={e.texto}>{captura.cantidad} × {platillo.nombre}</Text>
                <Text style={e.ayuda}>{[...platillo.modificadores.filter(m => captura.modificadores.includes(m.id)).map(m => m.nombre), captura.nota]
                    .filter(Boolean).join(' · ')}</Text>
                {cotizacion && Number(cotizacion.items[n]?.descuento ?? 0) > 0 &&
                    <Text style={e.ayuda}>{cotizacion.items[n].promocion} −{dinero(cotizacion.items[n].descuento)}</Text>}
            </View>
            <Text style={e.texto}>{dinero(importe / 100)}</Text>
            {!cobrando && <Boton texto="Quitar" etiqueta={`Quitar ${platillo.nombre}`} tipo="secundario"
                alPulsar={() => ponItems(actual => actual.filter(i => i.clave !== clave))} />}
        </View>)}
        <View style={e.entre}><Text style={e.h3}>Total</Text><Text style={e.cifra}>{dinero(total / 100)}</Text></View>
        {sinCotizar && <Aviso>No pudimos calcular el total. Revise la conexión.</Aviso>}
        {!cobrando && <Boton texto="Ir al cobro" inactivo={items.length === 0 || !cotizacion} alPulsar={() => ponCobrando(true)} />}
        {items.length >= 100 && <Aviso>La venta admite hasta 100 renglones.</Aviso>}
    </View>;
    const trabajo = cobrando
        ? <Cobro ruta="/mostrador" totalCuenta={aPesos(total)} datosCuenta={{ items: datosVenta }}
            ejecuta={cobra} ocupado={s.ocupado} motivos={motivos} cancela={() => ponCobrando(false)} />
        : <Carta mostrador carta={s.carta} agrega={agrega} />;
    const hoja = (contenido: ReactNode) => <ScrollView style={e.fondo} contentContainerStyle={e.hoja}
        keyboardShouldPersistTaps="handled">{contenido}</ScrollView>;
    const turno = s.estadoCaja && !s.estadoCaja.turno && <Turno estado={s.estadoCaja} ejecuta={s.ejecuta}
        ocupado={s.ocupado} sinConexion={s.sinConexion} />;

    return ancho === null ? hoja(<>{turno}{venta}{trabajo}</>)
        : <DosPaneles fijo="derecha" ancho={ancho} izquierda={hoja(cobrando ? <Carta mostrador carta={s.carta} agrega={agrega} /> : trabajo)}
            derecha={hoja(<>{turno}{venta}{cobrando && trabajo}</>)} />;
}
