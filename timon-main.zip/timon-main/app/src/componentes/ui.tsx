import type { ReactNode } from 'react';
import { ActivityIndicator, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import type { StyleProp, TextInputProps, ViewStyle } from 'react-native';
import { marca } from '../nucleo/marca';

export const c = marca.colores;
/** Fondos suaves de la paleta Peltre para insignias y avisos. El texto encima siempre va en tinta. */
export const tintes = { neutro: '#E9EDF1', primario: '#DDE5F7', exito: '#DDEFE3', aviso: '#FBF1CC', riesgo: '#F9DDDA' } as const;
export type Tono = keyof typeof tintes;
export const estilos = StyleSheet.create({
    fondo: { flex: 1, backgroundColor: c.fondo },
    barra: { backgroundColor: c.tinta, paddingHorizontal: 20, paddingVertical: 15, flexDirection: 'row', gap: 12, alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap' },
    marca: { color: c.superficie, fontWeight: '900', fontSize: 23, letterSpacing: -.8 },
    barraTexto: { color: c.superficie, fontSize: 14 },
    pagina: { padding: 16, gap: 16, width: '100%', maxWidth: 1360, alignSelf: 'center' },
    acceso: { padding: 24, width: '100%', maxWidth: 480, alignSelf: 'center', gap: 16, paddingTop: 60 },
    panel: { backgroundColor: c.superficie, borderRadius: 14, borderWidth: 1, borderColor: c.borde, padding: 16, gap: 10 },
    h1: { color: c.tinta, fontSize: 30, fontWeight: '900', letterSpacing: -.9 },
    h2: { color: c.tinta, fontSize: 22, fontWeight: '800' },
    h3: { color: c.tinta, fontSize: 17, fontWeight: '800' },
    texto: { color: c.tinta, fontSize: 16, lineHeight: 23 },
    ayuda: { color: c.secundario, fontSize: 14, lineHeight: 20 },
    fila: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 10 },
    campo: { gap: 5 },
    entrada: { color: c.tinta, backgroundColor: c.superficie, paddingHorizontal: 12, paddingVertical: 10, minHeight: 44, borderWidth: 1, borderColor: c.borde, borderRadius: 8, fontSize: 16 },
    boton: { backgroundColor: c.primario, minHeight: 46, paddingVertical: 10, paddingHorizontal: 15, justifyContent: 'center', alignItems: 'center', borderRadius: 8 },
    botonSecundario: { backgroundColor: c.superficie, borderWidth: 1, borderColor: c.primario },
    botonRiesgo: { backgroundColor: c.acento },
    botonTexto: { color: c.superficie, fontSize: 15, fontWeight: '800' },
    botonTextoSecundario: { color: c.primario },
    presionado: { opacity: .8 },
    inactivo: { opacity: .5 },
    aviso: { padding: 12, borderRadius: 8, backgroundColor: c.aviso },
    error: { padding: 12, borderRadius: 8, backgroundColor: c.acento },
    cuadricula: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, alignItems: 'flex-start' },
    hoja: { padding: 16, gap: 16 },
    entre: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
    insignia: { alignSelf: 'flex-start', paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999 },
    insigniaTexto: { color: c.tinta, fontSize: 13, fontWeight: '700' },
    pestana: { minHeight: 44, paddingHorizontal: 16, borderRadius: 999, borderWidth: 1, borderColor: c.borde, backgroundColor: c.superficie,
        flexDirection: 'row', alignItems: 'center', gap: 8 },
    pestanaActiva: { backgroundColor: c.tinta, borderColor: c.tinta },
    pestanaTexto: { color: c.tinta, fontSize: 15, fontWeight: '700' },
    globo: { minWidth: 22, height: 22, paddingHorizontal: 6, borderRadius: 11, backgroundColor: c.acento, alignItems: 'center', justifyContent: 'center' },
    globoTexto: { color: c.superficie, fontSize: 13, fontWeight: '800' },
    paso: { width: 48, height: 48, borderRadius: 8, borderWidth: 1, borderColor: c.primario, backgroundColor: c.superficie,
        alignItems: 'center', justifyContent: 'center' },
    pasoTexto: { color: c.primario, fontSize: 26, fontWeight: '700', lineHeight: 30 },
    conteo: { minWidth: 64, textAlign: 'center', color: c.tinta, fontSize: 26, fontWeight: '900', fontVariant: ['tabular-nums'] },
    velo: { flex: 1, backgroundColor: 'rgba(13, 27, 62, .55)', alignItems: 'center', justifyContent: 'center', padding: 16 },
    dialogo: { width: '100%', maxWidth: 520, maxHeight: '92%', backgroundColor: c.superficie, borderRadius: 16, padding: 18, gap: 14 },
    tostada: { position: 'absolute', left: 16, right: 16, bottom: 16, alignItems: 'center', pointerEvents: 'none' },
    tostadaCaja: { maxWidth: 520, paddingHorizontal: 16, paddingVertical: 12, borderRadius: 10, backgroundColor: c.acento },
    cifra: { color: c.tinta, fontSize: 28, fontWeight: '900', letterSpacing: -.6, fontVariant: ['tabular-nums'] },
});

export function Boton({ texto, alPulsar, tipo = 'primario', inactivo, ocupado, estilo, etiqueta }: {
    texto: string; alPulsar: () => void; tipo?: 'primario' | 'secundario' | 'riesgo'; inactivo?: boolean; ocupado?: boolean;
    estilo?: StyleProp<ViewStyle>; etiqueta?: string;
}) {
    return <Pressable accessibilityRole="button" accessibilityLabel={etiqueta ?? texto} disabled={inactivo || ocupado}
        accessibilityState={{ disabled: inactivo, busy: ocupado }} onPress={alPulsar}
        style={({ pressed }) => [estilos.boton, tipo === 'secundario' && estilos.botonSecundario,
            tipo === 'riesgo' && estilos.botonRiesgo, pressed && estilos.presionado, (inactivo || ocupado) && estilos.inactivo, estilo]}>
        {ocupado ? <ActivityIndicator color={tipo === 'secundario' ? c.primario : c.superficie} /> :
            <Text style={[estilos.botonTexto, tipo === 'secundario' && estilos.botonTextoSecundario]}>{texto}</Text>}
    </Pressable>;
}
export function Campo({ etiqueta, ...props }: TextInputProps & { etiqueta: string }) {
    return <View style={estilos.campo}><Text style={estilos.h3}>{etiqueta}</Text>
        <TextInput accessibilityLabel={etiqueta} placeholderTextColor={c.secundario} style={estilos.entrada} {...props} />
    </View>;
}
export function Aviso({ children, error = false }: { children: ReactNode; error?: boolean }) {
    return <View accessibilityRole="alert" accessibilityLiveRegion="polite" style={error ? estilos.error : estilos.aviso}>
        <Text style={[estilos.texto, error && { color: c.superficie }]}>{children}</Text>
    </View>;
}

/** Un estado en pocas palabras. El color acompaña; lo que informa es el texto. */
export function Insignia({ texto, tono = 'neutro' }: { texto: string; tono?: Tono }) {
    return <View style={[estilos.insignia, { backgroundColor: tintes[tono] }]}><Text style={estilos.insigniaTexto}>{texto}</Text></View>;
}

export type Pestana<T> = { clave: T; texto: string; cuenta?: number };
/** Opciones que se excluyen entre sí: áreas, categorías, cuenta o carta. Se deslizan si no caben. */
export function Pestanas<T extends string | number | null>({ opciones, actual, elige, etiqueta }: {
    opciones: Pestana<T>[]; actual: T; elige: (clave: T) => void; etiqueta: string;
}) {
    return <ScrollView horizontal showsHorizontalScrollIndicator={false} accessibilityRole="tablist" accessibilityLabel={etiqueta}
        style={{ flexGrow: 0, flexShrink: 0 }} contentContainerStyle={{ gap: 8 }} keyboardShouldPersistTaps="handled">
        {opciones.map(o => {
            const activa = o.clave === actual;
            return <Pressable key={String(o.clave)} accessibilityRole="tab" accessibilityState={{ selected: activa }} aria-selected={activa}
                accessibilityLabel={o.cuenta ? `${o.texto}, ${o.cuenta}` : o.texto} onPress={() => elige(o.clave)}
                style={({ pressed }) => [estilos.pestana, activa && estilos.pestanaActiva, pressed && estilos.presionado]}>
                <Text style={[estilos.pestanaTexto, activa && { color: c.superficie }]}>{o.texto}</Text>
                {!!o.cuenta && <View style={estilos.globo}><Text style={estilos.globoTexto}>{o.cuenta}</Text></View>}
            </Pressable>;
        })}
    </ScrollView>;
}

/** Una cantidad que se sube y se baja con el dedo, sin teclado. */
export function Contador({ etiqueta, valor, cambia, minimo = 1, maximo = 99 }: {
    etiqueta: string; valor: number; cambia: (valor: number) => void; minimo?: number; maximo?: number;
}) {
    const paso = (texto: string, nombre: string, destino: number) => <Pressable accessibilityRole="button"
        accessibilityLabel={`${nombre} ${etiqueta.toLowerCase()}`} disabled={destino < minimo || destino > maximo} onPress={() => cambia(destino)}
        style={({ pressed }) => [estilos.paso, pressed && estilos.presionado, (destino < minimo || destino > maximo) && estilos.inactivo]}>
        <Text style={estilos.pasoTexto}>{texto}</Text>
    </Pressable>;
    return <View style={estilos.campo}>
        <Text style={estilos.h3}>{etiqueta}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            {paso('−', 'Menos', valor - 1)}
            <Text style={estilos.conteo} accessibilityLiveRegion="polite">{valor}</Text>
            {paso('+', 'Más', valor + 1)}
        </View>
    </View>;
}

/**
 * Una decisión que se toma sin perder de vista la pantalla.
 *
 * Sólo se cierra con su botón o con «atrás»: tocar fuera no descarta lo
 * que ya se escribió. El error de la operación se muestra aquí dentro,
 * porque el diálogo tapa el resto de la pantalla.
 */
export function Dialogo({ titulo, cierra, error, children }: { titulo: string; cierra: () => void; error?: string; children: ReactNode }) {
    return <Modal transparent animationType="fade" onRequestClose={cierra} statusBarTranslucent>
        <KeyboardAvoidingView style={estilos.velo} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            <View style={estilos.dialogo} accessibilityViewIsModal>
                <View style={estilos.entre}>
                    <Text accessibilityRole="header" style={[estilos.h2, { flexShrink: 1 }]}>{titulo}</Text>
                    <Boton texto="Cerrar" tipo="secundario" alPulsar={cierra} />
                </View>
                <ScrollView contentContainerStyle={{ gap: 12 }} keyboardShouldPersistTaps="handled">
                    {!!error && <Aviso error>{error}</Aviso>}
                    {children}
                </ScrollView>
            </View>
        </KeyboardAvoidingView>
    </Modal>;
}

export function Cargando({ texto }: { texto: string }) {
    return <View style={{ padding: 28, alignItems: 'center', gap: 10 }} accessibilityLiveRegion="polite">
        <ActivityIndicator color={c.primario} />
        <Text style={estilos.ayuda}>{texto}</Text>
    </View>;
}

/** Un error que aparece sobre la pantalla sin mover lo que hay en ella. Se retira solo. */
export function Tostada({ texto }: { texto: string }) {
    if (texto === '') return null;
    return <View style={estilos.tostada}>
        <View style={estilos.tostadaCaja} accessibilityRole="alert" accessibilityLiveRegion="assertive">
            <Text style={[estilos.texto, { color: c.superficie }]}>{texto}</Text>
        </View>
    </View>;
}

/** Dos columnas que se desplazan por separado. Una tiene ancho fijo y la otra toma el resto. */
export function DosPaneles({ izquierda, derecha, ancho, fijo = 'izquierda' }: {
    izquierda: ReactNode; derecha: ReactNode; ancho: number; fijo?: 'izquierda' | 'derecha';
}) {
    const borde = { borderColor: tintes.neutro, backgroundColor: c.superficie };
    return <View style={{ flex: 1, flexDirection: 'row' }}>
        <View style={fijo === 'izquierda' ? [{ width: ancho, borderRightWidth: 1 }, borde] : { flex: 1 }}>{izquierda}</View>
        <View style={fijo === 'derecha' ? [{ width: ancho, borderLeftWidth: 1 }, borde] : { flex: 1 }}>{derecha}</View>
    </View>;
}
