import { useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, Text, View } from 'react-native';
import { dinero, estadoMesa } from '../nucleo/api';
import type { Mesa, Sesion } from '../nucleo/api';
import { usaDisposicion } from '../nucleo/disposicion';
import type { Mutacion, Resultado } from '../nucleo/mutacion';
import { usaSalon } from '../nucleo/salon';
import { abreTicket, Turno } from './Caja';
import { Carta } from './Carta';
import { Cobro } from './Cobro';
import { FichaCuenta } from './Cuenta';
import { Mostrador } from './Mostrador';
import { Pedidos } from './Pedidos';
import { Plano } from './Plano';
import { Reimpresiones } from './Reimpresiones';
import { Separa } from './Separa';
import { Aviso, Boton, c, Cargando, Contador, Dialogo, DosPaneles, estilos as e, Insignia, Pestanas, Tostada } from './ui';

/**
 * La pantalla de mesero, caja y gerencia.
 *
 * Aquí sólo se decide qué se muestra y dónde. El estado vive en `usaSalon`
 * y cada parte de la pantalla es su propia pieza.
 *
 *   Teléfono             Tableta y escritorio
 *   ┌──────────────┐     ┌──────────┬─────────────────┐
 *   │ Cuenta│Carta │     │  Cuenta  │  Carta o cobro  │
 *   │ (una a la    │     │          │                 │
 *   │  vez)        │     │ acciones │                 │
 *   └──────────────┘     └──────────┴─────────────────┘
 */
export function Salon({ sesion, vence }: { sesion: Sesion; vence: () => void }) {
    const s = usaSalon(sesion, vence);
    const d = usaDisposicion();
    const [pantalla, ponPantalla] = useState<'mesas' | 'pedidos' | 'mostrador'>('mesas');
    const [vista, ponVista] = useState<'cuenta' | 'carta'>('cuenta');
    const [cobro, ponCobro] = useState(false);
    const [dividiendo, ponDividiendo] = useState(false);
    const [cobrado, ponCobrado] = useState<Resultado | null>(null);
    const [mesa, ponMesa] = useState<Mesa | null>(null);
    const [comensales, ponComensales] = useState(2);
    const { cuenta, pendientes } = s;
    // Lo pendiente de la cuenta en pantalla se ve dentro de ella; aquí va lo de las demás.
    const ajenos = pendientes.filter(p => p.cuenta !== s.elegida);
    const rechazados = ajenos.filter(p => p.rechazo);
    const porEnviar = cuenta ? cuenta.items.filter(i => i.estado === 'capturado').length + pendientes.filter(p => p.cuenta === cuenta.id).length : 0;

    // En teléfono, una cuenta recién abierta empieza en la carta; una con platillos, en la cuenta.
    useEffect(() => {
        if (cuenta) ponVista(cuenta.items.length > 0 || Number(cuenta.ajuste_reparto) > 0 ? 'cuenta' : 'carta');
    }, [cuenta?.id]);

    const conTicket: Mutacion = async (ruta, datos, opciones) => {
        const resultado = await s.ejecuta(ruta, datos, opciones);
        if (resultado?.ticket) {
            ponCobrado(resultado);
            ponCobro(false);
            const otra = resultado.id_siguiente ?? cuenta?.grupo?.find(parte => parte.id !== cuenta.id)?.id;
            if (otra) void s.selecciona(otra);
            else s.cierra();
        }
        return resultado;
    };
    // Por qué todavía no se puede cobrar. Se explica en la pantalla del cobro.
    const motivos = cuenta ? [
        s.sinConexion ? 'Necesita conexión para cobrar.' : '',
        !s.estadoCaja?.turno ? 'Abra un turno de caja.' : '',
        !cuenta.items.some(i => i.estado !== 'cancelado') && !(Number(cuenta.ajuste_reparto) > 0) ? 'La cuenta no tiene platillos.' : '',
        cuenta.items.some(i => i.estado === 'capturado') ? 'Envíe a cocina los platillos pendientes.' : '',
        pendientes.some(p => p.cuenta === cuenta.id) ? 'Hay platillos por guardar.' : '',
    ].filter(Boolean) : [];

    function vuelve() {
        s.cierra();
        ponCobro(false);
        ponDividiendo(false);
    }
    function alElegir(m: Mesa) {
        s.ponError('');
        if (m.id_cuenta !== null) void s.selecciona(m.id_cuenta);
        else if (m.estado === 'libre' || m.estado === 'por_limpiar') {
            ponComensales(Math.max(1, Math.min(2, m.capacidad)));
            ponMesa(m);
        } else s.ponError(`Mesa ${m.numero} · ${estadoMesa[m.estado]}`);
    }
    async function confirmaMesa() {
        if (!mesa) return;
        const hecho = mesa.estado === 'por_limpiar' ? await s.limpiaMesa(mesa) : await s.abreMesa(mesa, comensales);
        if (hecho) ponMesa(null);
    }

    const titulo = s.elegida === null ? (pantalla === 'mesas' ? 'Mesas' : pantalla === 'mostrador' ? 'Mostrador' : 'Pedidos')
        : !cuenta ? 'Cuenta'
        : cuenta.tipo === 'mesa' ? 'Mesa ' + (cuenta.mesas.map(m => m.numero).join(' + ') || '· Cuenta ' + cuenta.id)
        : 'Pedido #' + cuenta.id;

    const inicio = pantalla === 'pedidos' ? <Pedidos salon={s} />
        : s.plano ? <Plano plano={s.plano} elige={alElegir} /> : <Cargando texto="Cargando mesas…" />;
    const lateral = s.caja && s.estadoCaja ? <>
        <Turno estado={s.estadoCaja} ejecuta={s.ejecuta} ocupado={s.ocupado} sinConexion={s.sinConexion} />
        <Reimpresiones sesion={sesion} />
    </> : null;

    // Ficha y cobro pueden quedar como hermanos: sus llaves no deben coincidir.
    const ficha = <FichaCuenta key={`ficha-${s.elegida}`} salon={s}
        cobrar={() => { ponDividiendo(false); ponCobro(true); }} cobrando={cobro}
        divide={() => { s.ponError(''); ponCobro(false); ponDividiendo(true); }} />;
    const cobrando = cobro && cuenta !== null && cuenta.abierta !== null;
    const trabajo = !cuenta ? null
        : cuenta.abierta === null ? <Aviso>Esta cuenta ya se cerró.</Aviso>
        : cobro ? <Cobro key={`cobro-${cuenta.id}`} ruta={`/cuentas/${cuenta.id}/cobro`} totalCuenta={cuenta.total}
            datosCuenta={{ version: cuenta.version }} ejecuta={conTicket} ocupado={s.ocupado} motivos={motivos} cancela={() => ponCobro(false)} />
        : dividiendo && d.dosPaneles ? <Separa salon={s} enPanel cierra={() => ponDividiendo(false)} />
        : <Carta carta={s.carta} agrega={s.agrega} />;
    const hoja = (contenido: ReactNode) =>
        <ScrollView style={e.fondo} contentContainerStyle={e.hoja} keyboardShouldPersistTaps="handled">{contenido}</ScrollView>;

    return <KeyboardAvoidingView style={e.fondo} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={{ paddingHorizontal: 16, paddingTop: 12, paddingBottom: 10, gap: 10 }}>
            <View style={[e.entre, { flexWrap: 'wrap' }]}>
                <View style={[e.fila, { flexShrink: 1 }]}>
                    {s.elegida !== null && <Boton texto={pantalla === 'mesas' ? 'Volver a mesas' : 'Volver a pedidos'} tipo="secundario" alPulsar={vuelve} />}
                    <Text accessibilityRole="header" style={d.dosPaneles ? e.h1 : e.h2}>{titulo}</Text>
                    {!!cuenta?.comensales && <Insignia texto={cuenta.comensales === 1 ? '1 comensal' : `${cuenta.comensales} comensales`} />}
                </View>
                {s.elegida === null && <Pestanas<'mesas' | 'pedidos' | 'mostrador'> etiqueta="Servicio" actual={pantalla} elige={ponPantalla}
                    opciones={[{ clave: 'mesas', texto: 'Mesas' }, { clave: 'pedidos', texto: 'Para llevar y domicilio' },
                        ...(s.caja ? [{ clave: 'mostrador' as const, texto: 'Mostrador' }] : [])]} />}
            </View>
            {s.sinConexion && <Aviso>Sin conexión con la sucursal. Puede agregar a cuentas abiertas.</Aviso>}
            {ajenos.length > 0 && <View style={e.panel}>
                <Text style={e.h3}>{ajenos.length === 1 ? '1 platillo por guardar' : `${ajenos.length} platillos por guardar`}</Text>
                {rechazados.map(p => <View key={p.llave} style={{ gap: 8 }}>
                    <Aviso error>{p.nombre}. {p.rechazo}</Aviso>
                    <View style={e.fila}>
                        <Boton texto="Reintentar" tipo="secundario" inactivo={s.sinConexion} alPulsar={() => void s.reintenta(p.llave)} />
                        <Boton texto="Descartar" tipo="riesgo" alPulsar={() => void s.descarta(p.llave)} />
                    </View>
                </View>)}
            </View>}
            {s.elegida !== null && !d.dosPaneles && !cobrando && <Pestanas etiqueta="Cuenta o carta" actual={vista} elige={ponVista}
                opciones={[{ clave: 'cuenta', texto: 'Cuenta', cuenta: porEnviar }, { clave: 'carta', texto: 'Carta' }]} />}
            {cuenta?.grupo && cuenta.grupo.length > 1 && <Pestanas etiqueta="Cuentas de esta mesa"
                opciones={cuenta.grupo.map((p, i) => ({ clave: p.id, texto: p.id_mesa === null ? `Cuenta ${i + 1}` : 'Cuenta principal' }))}
                actual={cuenta.id} elige={id => {
                    if (!s.ocupado && id !== cuenta.id) { ponCobro(false); ponDividiendo(false); void s.selecciona(id); }
                }} />}
        </View>

        <View style={{ flex: 1, borderTopWidth: 1, borderTopColor: c.fondo }}>
            {s.elegida === null
                ? pantalla === 'mostrador' && s.caja ? <Mostrador salon={s} ejecuta={conTicket} ancho={d.dosPaneles ? d.lateral : null} />
                    : d.clase === 'escritorio' && lateral
                    ? <DosPaneles fijo="derecha" ancho={420} izquierda={hoja(inicio)} derecha={hoja(lateral)} />
                    : hoja(<>{inicio}{lateral}</>)
                : d.dosPaneles ? <DosPaneles ancho={d.lateral} izquierda={ficha} derecha={hoja(trabajo)} />
                    : cobrando || vista === 'carta' ? hoja(trabajo) : ficha}
        </View>

        <Tostada texto={mesa || cobrado || dividiendo ? '' : s.error} />
        {dividiendo && cuenta && !d.dosPaneles && <Separa salon={s} cierra={() => ponDividiendo(false)} />}

        {mesa && <Dialogo titulo={`Mesa ${mesa.numero}`} cierra={() => ponMesa(null)} error={s.error}>
            {mesa.estado === 'por_limpiar' ? <>
                <Text style={e.texto}>Confirme que la mesa ya quedó limpia.</Text>
                <Boton texto="Marcar limpia" ocupado={s.ocupado} inactivo={s.sinConexion} alPulsar={() => void confirmaMesa()} />
            </> : <>
                <Text style={e.ayuda}>{mesa.capacidad === 1 ? '1 lugar' : `${mesa.capacidad} lugares`}</Text>
                <Contador etiqueta="Comensales" valor={comensales} cambia={ponComensales} />
                <Boton texto="Abrir mesa" ocupado={s.ocupado} inactivo={s.sinConexion} alPulsar={() => void confirmaMesa()} />
            </>}
        </Dialogo>}

        {cobrado && <Dialogo titulo="Cobro registrado" cierra={() => ponCobrado(null)}>
            <Text style={e.texto}>Folio {cobrado.folio} · Pagado {dinero(cobrado.pagado ?? '0')}</Text>
            {Number(cobrado.cambio) > 0 && <View style={[e.panel, { alignItems: 'center', borderColor: c.exito }]}>
                <Text style={e.ayuda}>Cambio</Text>
                <Text style={[e.cifra, { fontSize: 40, color: c.exito }]}>{dinero(cobrado.cambio ?? '0')}</Text>
            </View>}
            {!!cobrado.faltantes?.length && <Aviso>Se cobró sin existencia de {cobrado.faltantes.map(f => f.insumo).join(', ')}.</Aviso>}
            <Boton texto="Abrir ticket" alPulsar={() => abreTicket(cobrado.ticket ?? '')} />
        </Dialogo>}
    </KeyboardAvoidingView>;
}
