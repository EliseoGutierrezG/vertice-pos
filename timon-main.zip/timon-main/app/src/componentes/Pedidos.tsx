import { useState } from 'react';
import { Text, View } from 'react-native';
import type { EstadoSalon } from '../nucleo/salon';
import { estadoPedido } from './Cuenta';
import { Boton, Campo, estilos as e } from './ui';

/** Pedidos para llevar y a domicilio: alta y lista de los activos. */
export function Pedidos({ salon: s }: { salon: EstadoSalon }) {
    const [alta, ponAlta] = useState<'llevar' | 'domicilio' | null>(null);
    const [cliente, ponCliente] = useState('');
    const [telefono, ponTelefono] = useState('');
    const [direccion, ponDireccion] = useState('');
    async function abre() {
        const resultado = await s.ejecuta('/cuentas', { tipo: alta, cliente, telefono, direccion });
        if (resultado?.id) {
            ponAlta(null);
            ponCliente('');
            ponTelefono('');
            ponDireccion('');
            await s.selecciona(resultado.id);
        }
    }
    return <>
        <View style={e.fila}>
            <Boton texto="Para llevar" alPulsar={() => ponAlta('llevar')} inactivo={s.sinConexion} />
            <Boton texto="A domicilio" alPulsar={() => ponAlta('domicilio')} inactivo={s.sinConexion} />
        </View>
        {alta && <View style={e.panel}>
            <Text style={e.h2}>{alta === 'llevar' ? 'Nuevo pedido para llevar' : 'Nuevo pedido a domicilio'}</Text>
            <Campo etiqueta="Cliente" value={cliente} onChangeText={ponCliente} maxLength={100} />
            <Campo etiqueta="Teléfono" value={telefono} onChangeText={ponTelefono} keyboardType="phone-pad" maxLength={25} />
            {alta === 'domicilio' && <Campo etiqueta="Dirección de entrega" value={direccion} onChangeText={ponDireccion} maxLength={250} multiline />}
            <View style={e.fila}>
                <Boton texto="Crear pedido" ocupado={s.ocupado} inactivo={s.sinConexion} alPulsar={() => void abre()} />
                <Boton texto="Cancelar" tipo="secundario" alPulsar={() => ponAlta(null)} />
            </View>
        </View>}
        {s.pedidos.length === 0 && <Text style={e.texto}>Sin pedidos activos.</Text>}
        {s.pedidos.map(p => <View key={p.id} style={e.panel}><Text style={e.h3}>#{p.id} · {p.cliente}</Text>
            <Text style={e.texto}>{p.tipo === 'domicilio' ? 'Domicilio' : 'Para llevar'} · {estadoPedido[p.entrega ?? 'recibido']}</Text>
            <Boton texto={`Ver pedido ${p.id}`} tipo="secundario" alPulsar={() => void s.selecciona(p.id)} />
        </View>)}
    </>;
}
