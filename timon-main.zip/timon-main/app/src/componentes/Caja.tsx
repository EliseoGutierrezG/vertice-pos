import { useState } from 'react';
import { Linking, Platform, Text, View } from 'react-native';
import { dinero, EstadoCaja, origen } from '../nucleo/api';
import type { Mutacion, Resultado } from '../nucleo/mutacion';
import { Aviso, Boton, Campo, estilos as e } from './ui';


export function Turno({ estado, ejecuta, ocupado, sinConexion }: {
    estado: EstadoCaja; ejecuta: Mutacion; ocupado: boolean; sinConexion: boolean;
}) {
    const [importe, ponImporte] = useState('');
    const [accion, ponAccion] = useState<'abrir' | 'cerrar' | 'entrada' | 'salida' | null>(null);
    const [concepto, ponConcepto] = useState('');
    const [corte, ponCorte] = useState<Resultado | null>(null);
    const turno = estado.turno;
    async function confirma() {
        const ruta = accion === 'entrada' || accion === 'salida' ? 'movimiento' : accion;
        const datos = ruta === 'movimiento' ? { tipo: accion, concepto, importe } :
            accion === 'abrir' ? { fondo: importe } : { efectivo: importe, id_turno: turno?.id };
        const resultado = await ejecuta('/caja/' + ruta, datos);
        if (!resultado) return;
        if (accion === 'cerrar') ponCorte(resultado);
        if (accion === 'abrir') ponCorte(null);
        ponAccion(null);
        ponImporte('');
        ponConcepto('');
    }
    return <View style={e.panel}>
        <Text accessibilityRole="header" style={e.h2}>Turno de caja</Text>
        <Text style={e.texto}>{turno ? `Turno ${turno.id} abierto` : 'Sin turno abierto'}</Text>
        {!!estado.impresiones_demoradas && <Aviso>{estado.impresiones_demoradas === 1 ? '1 impresión pendiente o fallida.'
            : `${estado.impresiones_demoradas} impresiones pendientes o fallidas.`}</Aviso>}
        {corte?.diferencia !== undefined && <View style={{ gap: 4 }}>
            <Text style={e.h3}>Corte registrado</Text>
            {corte.resumen && <>
                <Text style={e.texto}>{corte.resumen.cobros} cobros · Venta {dinero(corte.resumen.venta)} · Propinas {dinero(corte.resumen.propinas)}</Text>
                <Text style={e.texto}>Efectivo {dinero(corte.resumen.formas.efectivo)} · Tarjeta {dinero(corte.resumen.formas.tarjeta)} · Transferencia {dinero(corte.resumen.formas.transferencia)}</Text>
            </>}
            <Text style={e.texto}>Esperado {dinero(corte.esperado ?? '0')} · Contado {dinero(corte.declarado ?? '0')} · Diferencia {dinero(corte.diferencia)}</Text>
        </View>}
        <View style={e.fila}>
            {(turno ? ['cerrar', 'entrada', 'salida'] as const : ['abrir'] as const).map(a =>
                <Boton key={a} tipo="secundario" texto={{ cerrar: 'Cierre ciego', abrir: 'Abrir turno', entrada: 'Entrada de efectivo', salida: 'Salida de efectivo' }[a]}
                    alPulsar={() => { ponAccion(a); ponImporte(''); }} inactivo={sinConexion} />)}
        </View>
        {accion && <>
            <Campo etiqueta={accion === 'abrir' ? 'Fondo inicial' : accion === 'cerrar' ? 'Efectivo contado' : 'Importe'}
                value={importe} onChangeText={ponImporte} keyboardType="decimal-pad" />
            {(accion === 'entrada' || accion === 'salida') && <Campo etiqueta="Concepto" value={concepto} onChangeText={ponConcepto} maxLength={120} />}
            <View style={e.fila}>
                <Boton texto="Confirmar" alPulsar={() => void confirma()} ocupado={ocupado} inactivo={!importe || sinConexion} />
                <Boton texto="Cancelar" tipo="secundario" alPulsar={() => ponAccion(null)} inactivo={ocupado} />
            </View>
        </>}
    </View>;
}

type DatosFirma = { usuario: string; clave: string; codigo: string };

export function Firma({ datos, cambia }: { datos: DatosFirma; cambia: (datos: DatosFirma) => void }) {
    return <View style={e.panel}>
        <Text style={e.h3}>Autorización de gerencia</Text>
        <Campo etiqueta="Usuario de gerencia" value={datos.usuario} autoCapitalize="none" onChangeText={usuario => cambia({ ...datos, usuario })} />
        <Campo etiqueta="Contraseña de gerencia" value={datos.clave} secureTextEntry onChangeText={clave => cambia({ ...datos, clave })} />
        <Campo etiqueta="Código de verificación" value={datos.codigo} maxLength={20} onChangeText={codigo => cambia({ ...datos, codigo })} />
    </View>;
}

export function abreTicket(ruta: string) {
    if (Platform.OS === 'web') window.open(ruta, '_blank', 'noopener,noreferrer');
    else void Linking.openURL(origen() + ruta);
}
