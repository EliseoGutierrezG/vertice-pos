import { useEffect, useRef, useState } from 'react';
import { AppState, KeyboardAvoidingView, Linking, Platform, ScrollView, StatusBar, Text, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { api, Equipo, ErrorApi, fijaOrigen, origenSugerido, Sesion, validaServidor } from './nucleo/api';
import { borraEquipo, guardaEquipo, guardaServidor, leeEquipo, leeServidor } from './nucleo/almacen';
import { marca } from './nucleo/marca';
import { leeRecientes, Reciente, recuerda } from './nucleo/recientes';
import { marcaActividad } from './nucleo/sondeo';
import { usaVersionNueva } from './nucleo/version';
import { versionAnterior } from './nucleo/compatibilidad';
import { Cocina } from './componentes/Cocina';
import { Salon } from './componentes/Salon';
import { Impresor } from './componentes/Impresor';
import { Aviso, Boton, Campo, Dialogo, c, estilos as e } from './componentes/ui';
import { Acceso } from './componentes/Acceso';

const modos = { mesero: 'Mesero', caja: 'Caja', cocina: 'Cocina', barra: 'Barra', impresor: 'Impresor', gerencia: 'Gerencia' };
type SaludApp = { app_minima?: string; app_version?: string; apk?: string | null;
    central?: { alcanzable: boolean; pendientes: number; espera_actualizacion?: boolean } };

function Aplicacion() {
    const [equipo, ponEquipo] = useState<Equipo | null>(null);
    const [autorizado, ponAutorizado] = useState(false);
    const [cargado, ponCargado] = useState(false);
    const [sesion, ponSesion] = useState<Sesion | null>(null);
    const [usuario, ponUsuario] = useState('');
    const [pin, ponPin] = useState('');
    const [nombre, ponNombre] = useState('');
    const [error, ponError] = useState('');
    const [ocupado, ponOcupado] = useState(false);
    const [sinRed, ponSinRed] = useState(false);
    const [intento, ponIntento] = useState(0);
    const [recientes, ponRecientes] = useState<Reciente[]>([]);
    const [servidor, ponServidor] = useState(origenSugerido.replace(/^https:\/\//, ''));
    const [central, ponCentral] = useState<SaludApp['central'] | null>(null);
    const [saludApp, ponSaludApp] = useState<SaludApp | null>(null);
    const [ajustes, ponAjustes] = useState(false);
    const [errorDescarga, ponErrorDescarga] = useState('');
    const nativo = Platform.OS !== 'web';
    const actividadEnviada = useRef(0);
    const version = usaVersionNueva();
    const obligatoria = nativo && versionAnterior(version.numero, saludApp?.app_minima ?? version.numero);
    const nuevaApp = nativo && versionAnterior(version.numero, saludApp?.app_version ?? version.numero);

    async function descargaApp() {
        ponErrorDescarga('');
        try {
            // La dirección la construye el cliente con su servidor registrado;
            // no se abre una dirección externa enviada por la API.
            const base = validaServidor(servidor);
            if (Platform.OS !== 'android' || !base || saludApp?.apk !== '/api/v1/app/apk') return;
            await Linking.openURL(base + '/api/v1/app/apk');
        } catch { ponErrorDescarga('No se pudo abrir la descarga. Intente de nuevo.'); }
    }

    useEffect(() => {
        let vivo = true;
        // Primero el servidor: el equipo guardado es de ese servidor.
        void leeServidor().then(url => {
            if (url && vivo) { fijaOrigen(url); ponServidor(url.replace(/^https:\/\//, '')); }
            return leeEquipo();
        }).then(valor => {
            if (valor && vivo) ponEquipo(JSON.parse(valor));
        }).catch(err => { if (vivo) ponError((err as Error).message); })
            .finally(() => { if (vivo) ponCargado(true); });
        void leeRecientes().then(lista => { if (vivo) ponRecientes(lista); });
        return () => { vivo = false; };
    }, []);

    useEffect(() => {
        if (!equipo || sesion || autorizado) return;
        const control = new AbortController();
        let timer: ReturnType<typeof setTimeout>;
        async function estado() {
            try {
                const resp = await api<{ autorizado: boolean }>('/equipo', { secreto: equipo?.secreto, signal: control.signal });
                if (control.signal.aborted) return;
                ponSinRed(false);
                ponAutorizado(resp.autorizado);
            } catch (err) {
                if (control.signal.aborted) return;
                if (err instanceof ErrorApi && err.estado === 401) {
                    // El código venció o el equipo se retiró: guardarlo sólo estorba.
                    void olvidaEquipo(err.message);
                } else {
                    ponSinRed(true);
                }
            } finally {
                if (!control.signal.aborted) timer = setTimeout(estado, 4000);
            }
        }
        void estado();
        return () => { control.abort(); clearTimeout(timer); };
    }, [equipo, autorizado, sesion, intento]);

    // En el servidor de sucursal, la salud dice si alcanza al central y
    // cuánto falta por subir: sin internet, la sucursal sigue operando.
    useEffect(() => {
        if (!cargado) return;
        const control = new AbortController();
        let timer: ReturnType<typeof setTimeout>;
        async function revisa() {
            try {
                const salud = await api<SaludApp>('/salud', { signal: control.signal });
                if (!control.signal.aborted) { ponCentral(salud.central ?? null); ponSaludApp(salud); }
            } catch {
                // Sin servidor lo dicen las pantallas de la comanda.
            } finally {
                if (!control.signal.aborted) timer = setTimeout(revisa, 30000);
            }
        }
        void revisa();
        return () => { control.abort(); clearTimeout(timer); };
    }, [cargado, sesion, equipo]);

    async function olvidaEquipo(aviso = '') {
        await borraEquipo().catch(() => undefined);
        ponEquipo(null);
        ponAutorizado(false);
        ponSinRed(false);
        ponNombre('');
        ponError(aviso);
    }

    const vence = () => {
        ponSesion(null);
        ponPin('');
        ponError('La sesión terminó. Entre con su PIN.');
    };

    function actividad() {
        marcaActividad();
        if (!sesion || ['cocina','barra','impresor'].includes(sesion.tipo) || Date.now() - actividadEnviada.current < 60000) return;
        actividadEnviada.current = Date.now();
        void api('/equipo/actividad', { token: sesion.token, datos: {} }).catch(err => {
            if (err instanceof ErrorApi && err.estado === 401) vence();
        });
    }

    useEffect(() => {
        if (!sesion) return;
        const suscripcion = AppState.addEventListener('change', estado => {
            if (estado === 'active') actividad();
        });
        if (Platform.OS === 'web') {
            window.addEventListener('keydown', actividad);
            window.addEventListener('pointerdown', actividad);
        }
        return () => {
            suscripcion.remove();
            if (Platform.OS === 'web') {
                window.removeEventListener('keydown', actividad);
                window.removeEventListener('pointerdown', actividad);
            }
        };
    }, [sesion]);

    async function registra() {
        if (!nombre.trim() || ocupado) return;
        const url = nativo ? validaServidor(servidor) : '';
        if (url === null) {
            ponError('Escriba la dirección de la computadora, por ejemplo 192.168.1.50.');
            return;
        }
        ponOcupado(true);
        ponError('');
        try {
            if (nativo) {
                fijaOrigen(url);
                try {
                    await api('/salud');
                } catch (err) {
                    throw new Error(err instanceof ErrorApi && err.estado === 0
                        ? 'No encuentro la computadora de la sucursal. Revise el WiFi.' : (err as Error).message);
                }
                await guardaServidor(url);
            }
            const alta = await api<Equipo>('/equipo', { datos: { nombre, plataforma: Platform.OS } });
            await guardaEquipo(JSON.stringify(alta));
            ponEquipo(alta);
        } catch (err) {
            ponError((err as Error).message);
        } finally {
            ponOcupado(false);
        }
    }

    async function entra() {
        if (!equipo || ocupado || obligatoria || !usuario.trim() || !/^\d{4,6}$/.test(pin)) return;
        ponOcupado(true);
        ponError('');
        try {
            const salud = await api<SaludApp>('/salud');
            ponSaludApp(salud);
            if (nativo && versionAnterior(version.numero, salud.app_minima ?? version.numero)) return;
            const sesionNueva = await api<Omit<Sesion, 'operador'>>('/equipo/entrar', { secreto: equipo.secreto, datos: { usuario, pin } });
            actividadEnviada.current = Date.now();
            const operador = usuario.trim().toLowerCase();
            ponSesion({ ...sesionNueva, operador });
            void recuerda({ usuario: operador, nombre: sesionNueva.nombre }).then(ponRecientes);
        } catch (err) {
            ponError((err as Error).message);
            if (err instanceof ErrorApi && err.estado === 401 && /equipo/i.test(err.message)) void olvidaEquipo(err.message);
            // Un 403 puede ser el puesto de la persona o el equipo: sólo el
            // segundo regresa a la pantalla del código.
            if (err instanceof ErrorApi && err.estado === 403) {
                void api<{ autorizado: boolean }>('/equipo', { secreto: equipo.secreto })
                    .then(resp => ponAutorizado(resp.autorizado)).catch(() => undefined);
            }
        } finally {
            ponPin('');
            ponOcupado(false);
        }
    }

    async function sale() {
        if (!sesion || ocupado) return;
        ponOcupado(true);
        try {
            await api('/equipo/salir', { token: sesion.token, datos: {} });
        } catch (err) {
            if (!(err instanceof ErrorApi) || err.estado !== 401) {
                ponError((err as Error).message);
                return;
            }
        } finally {
            ponOcupado(false);
        }
        ponSesion(null);
        ponError('');
    }

    return <SafeAreaView style={[e.fondo, !sesion && { backgroundColor: c.superficie }]} edges={sesion ? ['top', 'bottom', 'left', 'right'] : ['bottom', 'left', 'right']} onTouchStart={actividad}>
        <StatusBar barStyle={sesion ? 'dark-content' : 'light-content'} backgroundColor={sesion ? c.fondo : c.tinta} />
        {sesion && <View style={e.barra}>
            <Text style={e.marca}>{marca.nombre}</Text>
            {sesion && <View style={[e.fila, { maxWidth: '100%', flexShrink: 1 }]}>
                <Text style={[e.barraTexto, { flexShrink: 1 }]}>{sesion.nombre} · {modos[sesion.tipo]}</Text>
                <Boton texto="Ajustes" tipo="secundario" alPulsar={() => ponAjustes(true)} />
                <Boton texto="Cambiar de usuario" tipo="secundario" ocupado={ocupado} alPulsar={() => void sale()} />
            </View>}
        </View>}
        {version.lista && <View style={[e.fila, e.aviso, { justifyContent: 'space-between', borderRadius: 0 }]}>
            <Text style={[e.texto, { flexShrink: 1 }]}>Hay una versión nueva de la app.</Text>
            <Boton texto="Actualizar" tipo="secundario" alPulsar={version.aplica} />
        </View>}
        {obligatoria ? <ScrollView contentContainerStyle={e.pagina}>
            <Text style={e.h1} accessibilityRole="header">Actualice la app para continuar</Text>
            <Aviso>Esta computadora necesita la versión {saludApp?.app_minima} o posterior. Este equipo tiene la {version.numero}.</Aviso>
            <Text style={e.texto}>{Platform.OS === 'android'
                ? 'Actualice desde Google Play o descargue el APK local.'
                : 'Instale la versión nueva desde TestFlight o App Store.'}</Text>
            {Platform.OS === 'android' && saludApp?.apk && <Boton texto="Descargar APK" alPulsar={() => void descargaApp()} />}
            {errorDescarga !== '' && <Aviso error>{errorDescarga}</Aviso>}
            <Boton texto="Ajustes" tipo="secundario" alPulsar={() => ponAjustes(true)} />
        </ScrollView> : sesion ? <>
            {central && !central.alcanzable && <Aviso>
                {central.pendientes > 0 ? `Sin internet: todo funciona. ${central.pendientes} cambios por subir.` : 'Sin internet: todo funciona.'}
            </Aviso>}
            {central?.espera_actualizacion && <Aviso>Esperando actualización. El catálogo se pondrá al día después.</Aviso>}
            {error !== '' && <Aviso error>{error}</Aviso>}
            {sesion.tipo === 'cocina' || sesion.tipo === 'barra'
                ? <Cocina key={sesion.token} sesion={sesion} vence={vence} />
                : sesion.tipo === 'impresor'
                    ? <Impresor key={sesion.token} sesion={sesion} vence={vence} />
                    : <Salon key={sesion.token} sesion={sesion} vence={vence} />}
        </> : <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
                <Acceso
                    titulo={!cargado ? 'Cargando…' : !equipo ? 'Registrar equipo' : autorizado ? 'Entrar a la comanda' : 'Autorizar equipo'}
                    detalle={!cargado ? undefined : !equipo ? (nativo ? 'Escriba la dirección y un nombre reconocible.' : 'Asigne un nombre que la gerencia pueda reconocer.')
                        : autorizado ? 'Use su usuario y su PIN.' : 'Comparta este código con su gerencia.'}>
                    {error !== '' && <Aviso error>{error}</Aviso>}
                    <Boton texto="Ajustes" tipo="secundario" alPulsar={() => ponAjustes(true)} />
                    {cargado && (!equipo ? <>
                        {nativo && <Campo etiqueta="Computadora de la sucursal" value={servidor} onChangeText={ponServidor} maxLength={120}
                            autoCapitalize="none" autoCorrect={false} keyboardType="url" />}
                        <Campo etiqueta="Nombre del equipo" value={nombre} onChangeText={ponNombre} maxLength={80} onSubmitEditing={() => void registra()} />
                        <Boton texto="Obtener código" inactivo={!nombre.trim()} ocupado={ocupado} alPulsar={() => void registra()} />
                    </> : autorizado ? <>
                        {recientes.length > 0 && <View style={e.fila} accessibilityLabel="Usuarios recientes">
                            {recientes.map(r => <Boton key={r.usuario} texto={r.nombre} tipo={usuario.trim().toLowerCase() === r.usuario ? 'primario' : 'secundario'}
                                alPulsar={() => { ponUsuario(r.usuario); ponPin(''); }} />)}
                        </View>}
                        <Campo etiqueta="Usuario" value={usuario} onChangeText={ponUsuario} maxLength={60} autoCapitalize="none" autoCorrect={false} />
                        <Campo etiqueta="PIN" value={pin} onChangeText={ponPin} maxLength={6} secureTextEntry
                            keyboardType="number-pad" onSubmitEditing={() => void entra()} />
                        <Boton texto="Entrar" inactivo={!usuario.trim() || !/^\d{4,6}$/.test(pin)} ocupado={ocupado} alPulsar={() => void entra()} />
                    </> : <>
                        <View style={e.panel}><Text style={[e.h2, { letterSpacing: 3 }]} selectable>{equipo.codigo}</Text></View>
                        {sinRed ? <Aviso>Sin conexión. Se vuelve a intentar solo.</Aviso>
                            : <Text style={e.ayuda} accessibilityLiveRegion="polite">Esperando autorización…</Text>}
                        <View style={e.fila}>
                            <Boton texto="Reintentar" tipo="secundario" alPulsar={() => ponIntento(intento + 1)} />
                            <Boton texto="Registrar de nuevo" tipo="secundario" alPulsar={() => void olvidaEquipo()} />
                        </View>
                    </>)}
                </Acceso>
            </ScrollView>
        </KeyboardAvoidingView>}
        {ajustes && <Dialogo titulo="Ajustes de la app" cierra={() => ponAjustes(false)} error={errorDescarga}>
            <Text style={e.texto}>Versión {version.numero} · {version.canal}</Text>
            <Text style={e.ayuda} selectable>Actualización: {version.id}</Text>
            <Text style={e.ayuda}>Computadora: {Platform.OS === 'web' ? window.location.host : servidor}</Text>
            <Boton texto="Buscar actualización" ocupado={version.buscando} alPulsar={() => void version.busca()} />
            {version.mensaje !== '' && <Aviso>{version.mensaje}</Aviso>}
            {version.lista && <>
                <Text style={e.ayuda}>Termine de capturar y enviar antes de actualizar.</Text>
                <Boton texto="Aplicar actualización" alPulsar={version.aplica} />
            </>}
            {nuevaApp && <Aviso>Hay una versión nueva para instalar: {saludApp?.app_version}.</Aviso>}
            {Platform.OS === 'android' && saludApp?.apk && <>
                <Boton texto="Descargar APK" tipo="secundario" alPulsar={() => void descargaApp()} />
                <Text style={e.ayuda}>Abra el archivo descargado y acepte la instalación.</Text>
                <Text style={e.ayuda}>Android puede pedir permiso para instalar desde este navegador.</Text>
            </>}
        </Dialogo>}
    </SafeAreaView>;
}

export default function App() {
    return <SafeAreaProvider><Aplicacion /></SafeAreaProvider>;
}
