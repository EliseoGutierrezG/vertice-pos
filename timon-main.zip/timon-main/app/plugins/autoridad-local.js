/**
 * La app habla con el servidor de la sucursal por HTTPS, con un certificado
 * firmado por la autoridad propia de esa instalación
 * (`guiones/instala-sucursal.sh`, `docs/servidor-sucursal.md`).
 *
 * Android, desde la versión 7, no confía en las autoridades que instala el
 * usuario a menos que la app lo declare. Este plugin agrega
 * `network_security_config.xml` para confiar en las del sistema **y** en las
 * del usuario. HTTP sin cifrar sigue prohibido.
 *
 * iOS: la autoridad se instala como perfil y se activa en Ajustes > General >
 * Información > Confianza en certificados. No hace falta tocar la app.
 */
const fs = require('fs');
const path = require('path');
const { withAndroidManifest, withDangerousMod } = require('expo/config-plugins');

const XML = `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
            <certificates src="user" />
        </trust-anchors>
    </base-config>
</network-security-config>
`;

function conArchivo(config) {
    return withDangerousMod(config, ['android', async propia => {
        const carpeta = path.join(propia.modRequest.platformProjectRoot, 'app', 'src', 'main', 'res', 'xml');
        fs.mkdirSync(carpeta, { recursive: true });
        fs.writeFileSync(path.join(carpeta, 'network_security_config.xml'), XML);
        return propia;
    }]);
}

function conManifiesto(config) {
    return withAndroidManifest(config, propia => {
        const aplicacion = propia.modResults.manifest.application?.[0];
        if (aplicacion) aplicacion.$['android:networkSecurityConfig'] = '@xml/network_security_config';
        return propia;
    });
}

module.exports = function autoridadLocal(config) {
    return conManifiesto(conArchivo(config));
};
