# Corrección de la confirmación de reservaciones

Se corrige un archivo PHP. La ficha devolvía `estado=solicitada` y el llenado
del modal reemplazaba el destino fijo `confirmada`; el servidor rechazaba el
envío con 422. Ahora solo se precarga la mesa y la ficha Ver sigue mostrando
el estado vigente.

## Subida y aplicación

1. Sube el contenido de esta carpeta por SFTP a
   `.app/correccion-reservaciones/` del staging.
2. Ejecuta en SSH:

```bash
cd ~/domains/staging-timon.verticesoftware.com.mx/public_html
bash .app/correccion-reservaciones/aplica.sh
```

El guion verifica que el controlador instalado coincida con el candidato
auditado, revisa la sintaxis del nuevo archivo, guarda un respaldo y lo
reemplaza de forma atómica. Si la primera huella no coincide, se detiene:
no sobrescribas un controlador que tenga otros cambios sin compararlo.

No toca la base, la configuración privada, la regla `.htaccess` ni datos
persistentes. Tampoco cambia el identificador de liberación del candidato:
es un parche puntual registrado por su huella. La liberación completa debe
volver a empaquetarse antes de otro despliegue integral.

Reabre Reservaciones y repite la confirmación de la prueba `RES-000001` en S1;
después cancélala. El código corregido ya completó ambos pasos en el navegador
integrado con una sucursal temporal de `timon_pruebas`, retirada al terminar.

## Reversión

El guion imprime el nombre exacto del respaldo. Para restaurarlo, usa esa ruta:

```bash
cp -p .app/controladores/Web/Restaurante.php.antes-reservas-FECHA-PID.bak .app/controladores/Web/Restaurante.php.revertir
mv .app/controladores/Web/Restaurante.php.revertir .app/controladores/Web/Restaurante.php
```
