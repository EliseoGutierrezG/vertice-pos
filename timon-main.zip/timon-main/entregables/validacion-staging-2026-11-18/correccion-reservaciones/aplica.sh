#!/usr/bin/env bash
set -euo pipefail

PARCHE="$(cd "$(dirname "$0")" && pwd)"
case "$(pwd -P)" in
  */domains/staging-timon.verticesoftware.com.mx/public_html) ;;
  *) echo 'Ejecuta desde public_html del sitio staging-timon.verticesoftware.com.mx.' >&2; exit 2 ;;
esac
php -r 'exit(version_compare(PHP_VERSION,"8.3.0",">=") ? 0 : 1);' || {
  echo 'Se requiere PHP 8.3 o posterior.' >&2; exit 2;
}

verifica() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum -c "$1"
  else
    shasum -a 256 -c "$1"
  fi
}

ACTUAL='.app/controladores/Web/Restaurante.php'
verifica "$PARCHE/ANTES-SHA256.txt"
php -l "$PARCHE/Restaurante.php"
RESPALDO="$ACTUAL.antes-reservas-$(date +%Y%m%d-%H%M%S)-$$.bak"
NUEVO=$(mktemp "$ACTUAL.nuevo.XXXXXX")
trap 'rm -f "$NUEVO"' EXIT
cp "$PARCHE/Restaurante.php" "$NUEVO"
chmod "$(php -r 'printf("%o",fileperms($argv[1]) & 0777);' "$ACTUAL")" "$NUEVO"
cp -p "$ACTUAL" "$RESPALDO"
mv "$NUEVO" "$ACTUAL"
verifica "$PARCHE/DESPUES-SHA256.txt"
printf 'Corrección aplicada. Respaldo: %s\n' "$RESPALDO"
printf 'Reabre Reservaciones antes de repetir la confirmación de RES-000001.\n'
