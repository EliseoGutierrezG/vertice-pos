# Candidato firmado para el piloto de actualizaciones

Actualizado localmente el 21 de noviembre de 2026. No está instalado en staging ni en el servidor remoto.

- Versión: **20261121T060551Z-5582dbf09319**. El id usa UTC; la fecha local de preparación es 21 de noviembre.
- Esquema: **27**.
- Tamaño: **6,432,035 bytes** (6.1 MiB).
- [Paquete firmado](paquetes/timon-20261121T060551Z-5582dbf09319.tar.gz).
- [Descriptor de firma](paquetes/timon-20261121T060551Z-5582dbf09319.firma.json).
- [Llave pública](../../config/firma-liberaciones.pub). La privada está fuera del repositorio; no se incluye.
- SHA-256 del paquete: `35217a9535a05e4cf91da718c9e4325988c4eabcb78825dee96f49b4e61eb0d4`.

Incluye panel/API, PWA compilada, migraciones, guiones de réplica/actualización y preparación Docker/Synology. Corrige el reconocimiento para admitir el PHP 8.2 validado del NAS, sin cambiar el estándar PHP 8.3 del central. **No incluye un APK real, credenciales ni configuración privada**. La instalación y la firma se comprobaron en una carpeta temporal; el manifiesto coincide archivo por archivo.

## Cómo continuar cuando esté el acceso

1. Reconocer el equipo siguiendo [Synology](../../despliegue/synology/README.md), si corresponde. No cambiar `/vertice-pos/` ni ocupar puertos de otros sistemas.
2. Preparar el central de **staging** con el código, la pública y las migraciones incrementales pendientes. No importar el esquema consolidado sobre una base existente. La base local cotidiana no fue migrada por esta entrega.
3. Registrar la computadora contra staging, preparar su base/usuario propios y seguir la [instalación de sucursal](../../docs/servidor-sucursal.md#instalación). Verificar la llave pública por un canal independiente antes de confiar en la primera copia.
4. Probar operación sin internet, asignación de N+1, espera con cuenta/turno abiertos y regreso de una versión defectuosa. Confirmar salud y estado del central antes de ampliar el piloto.
5. Construir el APK real de staging o piloto con su firma Android. Para incluirlo y preparar una liberación nueva, usar el segundo argumento de `guiones/prepara-liberacion-sucursal.sh`. No elevar la mínima sin un binario compatible disponible.

La privada de firma se generó en `~/.timon/firma-liberaciones.llave`, con permisos 0600. Resguardar una copia fuera de esta Mac antes de usar la actualización remota en operación.

## Evidencia local

La [validación](../../docs/validacion-actualizaciones-2026-11-20.md) documenta la suite integral en verde (516 internas y todas las tandas), tipos, exportación PWA, actualización y regreso por HTTP. Docker/DSM y dispositivos reales siguen pendientes.

- [Ajustes a 375 px](ajustes-375.jpg), [horizontal](ajustes-horizontal.jpg), [escritorio](ajustes-escritorio.jpg).
- [Subir versión](subir-version-375.jpg) y [asignar versión](asignar-version-375.jpg): plantilla real con datos ficticios, sin enviar formularios.

No se hicieron commits ni publicaciones remotas.
