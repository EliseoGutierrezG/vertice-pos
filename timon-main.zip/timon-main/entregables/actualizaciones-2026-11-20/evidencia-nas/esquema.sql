-- El Timón - esquema consolidado para instalación nueva
-- Fuentes: 27 guiones numerados
-- Tablas declaradas: 63
-- IMPORTANTE: usar exclusivamente sobre una base VACIA.
-- No contiene CREATE DATABASE, USE, DROP DATABASE ni DROP TABLE, salvo las
-- tablas de trabajo appNNN_* que su propio guion crea y borra.
-- No contiene DEFINER, GRANT, procedimientos, funciones, eventos ni triggers.
-- Seleccione la base al invocar mysql: mysql ... NOMBRE_BASE < este-archivo.sql

SET NAMES utf8mb4;
SET time_zone = '-06:00';

-- ============================================================================
-- INICIO 001_catalogos.sql
-- ============================================================================
-- =============================================================================
-- Plantilla base — 001 · Catálogos
-- MariaDB · InnoDB · utf8mb4
--
-- Serie consolidada nueva (2026-11-14). Las tablas vienen de la capa base de
-- Distribuidora; aquí nacen limpias, sin el historial de sus 67 guiones.
--
-- Convenciones (valen para todos los guiones que siguen):
--   · Todo en español, snake_case.
--   · Toda tabla con ciclo de vida lleva `id_estatus` → `estatus`.
--   · Importes en DECIMAL, nunca en coma flotante: unitarios (12,4), totales
--     (14,2). El dominio (`dominio/Dinero.php`) cuenta en centavos.
--   · Nada se borra: baja lógica con el estatus 3.
--   · Lo que puede crecer es catálogo, no ENUM.
--   · Toda tabla operativa registra quién y cuándo.
--   · Un guion aplicado no se modifica: se agrega otro.
-- =============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE estatus (
  id            TINYINT UNSIGNED NOT NULL,
  nombre        VARCHAR(40)      NOT NULL,
  descripcion   VARCHAR(160)     NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Ciclo de vida común. Cada fase agrega los estatus que use.';

INSERT INTO estatus (id, nombre, descripcion) VALUES
  (1, 'Validado',  'Registro revisado y aprobado'),
  (2, 'Cancelado', 'Operación cancelada'),
  (3, 'Inactivo',  'Baja lógica'),
  (4, 'Activo',    'Vigente o aplicado'),
  (5, 'Pendiente', 'En espera de confirmación');

CREATE TABLE estado (
  id           TINYINT UNSIGNED NOT NULL COMMENT 'Clave INEGI de la entidad (01-32)',
  nombre       VARCHAR(40)      NOT NULL,
  abreviatura  VARCHAR(6)       NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE municipio (
  id         SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_estado  TINYINT UNSIGNED  NOT NULL,
  clave      SMALLINT UNSIGNED NOT NULL COMMENT 'Clave INEGI del municipio dentro de su estado (001-570)',
  nombre     VARCHAR(80)       NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_municipio_clave (id_estado, clave),
  KEY ix_municipio_nombre (id_estado, nombre),
  CONSTRAINT fk_municipio_estado FOREIGN KEY (id_estado) REFERENCES estado (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE dia (
  id           TINYINT UNSIGNED NOT NULL,
  nombre       VARCHAR(12)      NOT NULL,
  abreviatura  CHAR(3)          NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO dia (id, nombre, abreviatura) VALUES
  (1, 'Lunes', 'Lu'), (2, 'Martes', 'Ma'), (3, 'Miércoles', 'Mi'), (4, 'Jueves', 'Ju'),
  (5, 'Viernes', 'Vi'), (6, 'Sábado', 'Sa'), (7, 'Domingo', 'Do');

CREATE TABLE parametro (
  clave          VARCHAR(60)  NOT NULL,
  valor          VARCHAR(255) NOT NULL,
  descripcion    VARCHAR(255) DEFAULT NULL,
  vigente_desde  DATE         NOT NULL,
  vigente_hasta  DATE         DEFAULT NULL,
  PRIMARY KEY (clave, vigente_desde)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Reglas con vigencia. Ningún valor va en el código.';

CREATE TABLE folio_serie (
  serie   VARCHAR(40)  NOT NULL COMMENT 'cuenta, ticket, compra, entrada…',
  ultimo  INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'El último entregado',
  PRIMARY KEY (serie)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE migracion_esquema (
  numero       SMALLINT UNSIGNED NOT NULL,
  nombre       VARCHAR(120)      NOT NULL,
  sha256       CHAR(64)          NOT NULL,
  aplicada_en  DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (numero),
  UNIQUE KEY uq_migracion_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Guiones incrementales aplicados y su huella inmutable.';

SET FOREIGN_KEY_CHECKS = 1;
-- FIN 001_catalogos.sql

-- ============================================================================
-- INICIO 002_organizacion.sql
-- ============================================================================
-- =============================================================================
-- Plantilla base — 002 · Organización
--
-- Una instalación es un negocio; el negocio tiene sucursales. La sucursal es
-- el sitio físico: tiene su personal, sus equipos, su caja y su inventario.
-- (En Distribuidora esto se llamaba `bodega`.)
-- =============================================================================

SET NAMES utf8mb4;

CREATE TABLE sucursal (
  id            SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  clave         VARCHAR(8)        DEFAULT NULL COMMENT 'Abreviatura corta para tickets y folios: CEN, NTE…',
  nombre        VARCHAR(80)       NOT NULL,
  calle         VARCHAR(120)      DEFAULT NULL,
  numero        VARCHAR(20)       DEFAULT NULL,
  colonia       VARCHAR(80)       DEFAULT NULL,
  cp            CHAR(5)           DEFAULT NULL,
  id_estado     TINYINT UNSIGNED  DEFAULT NULL,
  id_municipio  SMALLINT UNSIGNED DEFAULT NULL,
  telefono      VARCHAR(20)       DEFAULT NULL,
  latitud       DECIMAL(10,7)     DEFAULT NULL,
  longitud      DECIMAL(10,7)     DEFAULT NULL,
  id_estatus    TINYINT UNSIGNED  NOT NULL DEFAULT 4,
  creado_en     DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creado_por    INT UNSIGNED      DEFAULT NULL,
  nombre_activo VARCHAR(80) GENERATED ALWAYS AS (IF(id_estatus = 4, nombre, NULL)) STORED
                COMMENT 'El nombre si está activa; NULL si no. Solo para la llave única',
  clave_activa  VARCHAR(8)  GENERATED ALWAYS AS (IF(id_estatus = 4, clave, NULL)) STORED,
  PRIMARY KEY (id),
  UNIQUE KEY ux_sucursal_nombre_activo (nombre_activo),
  UNIQUE KEY ux_sucursal_clave_activa (clave_activa),
  KEY ix_sucursal_nombre (nombre),
  KEY ix_sucursal_estatus (id_estatus),
  CONSTRAINT fk_sucursal_estado    FOREIGN KEY (id_estado)    REFERENCES estado (id),
  CONSTRAINT fk_sucursal_estatus   FOREIGN KEY (id_estatus)   REFERENCES estatus (id),
  CONSTRAINT fk_sucursal_municipio FOREIGN KEY (id_municipio) REFERENCES municipio (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Sitio físico del negocio. Nombre y clave únicos entre las activas.';
-- FIN 002_organizacion.sql

-- ============================================================================
-- INICIO 003_personal_usuarios.sql
-- ============================================================================
-- =============================================================================
-- Plantilla base — 003 · Personal, usuarios, permisos y acceso
--
-- Todo usuario es una persona del personal con un puesto. Los permisos son los
-- del puesto; el alcance es su sucursal base más las que tenga asignadas en
-- `usuario_sucursal`. El administrador ve todas.
-- =============================================================================

SET NAMES utf8mb4;

CREATE TABLE puesto (
  id          TINYINT UNSIGNED NOT NULL,
  clave       VARCHAR(30)      NOT NULL,
  nombre      VARCHAR(60)      NOT NULL,
  usa_app     TINYINT(1)       NOT NULL DEFAULT 0 COMMENT '1 = opera con la app',
  id_estatus  TINYINT UNSIGNED NOT NULL DEFAULT 4,
  PRIMARY KEY (id),
  UNIQUE KEY uq_puesto_clave (clave),
  CONSTRAINT fk_puesto_estatus FOREIGN KEY (id_estatus) REFERENCES estatus (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE permiso (
  id           SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  clave        VARCHAR(60)       NOT NULL COMMENT 'modulo_accion, igual que el atributo #[Accion]',
  descripcion  VARCHAR(160)      NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_permiso_clave (clave)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE puesto_permiso (
  id_puesto   TINYINT UNSIGNED  NOT NULL,
  id_permiso  SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (id_puesto, id_permiso),
  KEY ix_puesto_permiso_permiso (id_permiso),
  CONSTRAINT fk_puesto_permiso_permiso FOREIGN KEY (id_permiso) REFERENCES permiso (id),
  CONSTRAINT fk_puesto_permiso_puesto  FOREIGN KEY (id_puesto)  REFERENCES puesto (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE personal (
  id                INT UNSIGNED      NOT NULL AUTO_INCREMENT,
  nombre            VARCHAR(80)       NOT NULL,
  apellido_paterno  VARCHAR(60)       NOT NULL,
  apellido_materno  VARCHAR(60)       DEFAULT NULL,
  id_puesto         TINYINT UNSIGNED  NOT NULL,
  id_sucursal       SMALLINT UNSIGNED DEFAULT NULL COMMENT 'Su sucursal base. NULL solo para el administrador, que ve todas',
  id_superior       INT UNSIGNED      DEFAULT NULL,
  telefono          VARCHAR(20)       DEFAULT NULL,
  correo            VARCHAR(160)      DEFAULT NULL,
  fecha_ingreso     DATE              NOT NULL,
  fecha_baja        DATE              DEFAULT NULL,
  id_estatus        TINYINT UNSIGNED  NOT NULL DEFAULT 4,
  creado_en         DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creado_por        INT UNSIGNED      DEFAULT NULL,
  anonimizado_en    DATETIME          DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_personal_puesto (id_puesto, id_estatus),
  KEY ix_personal_sucursal (id_sucursal, id_estatus),
  KEY ix_personal_superior (id_superior),
  KEY ix_personal_nombre (apellido_paterno, nombre),
  KEY ix_personal_estatus (id_estatus),
  CONSTRAINT fk_personal_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_personal_estatus  FOREIGN KEY (id_estatus)  REFERENCES estatus (id),
  CONSTRAINT fk_personal_puesto   FOREIGN KEY (id_puesto)   REFERENCES puesto (id),
  CONSTRAINT fk_personal_superior FOREIGN KEY (id_superior) REFERENCES personal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE usuario (
  id                    INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  id_personal           INT UNSIGNED     NOT NULL COMMENT 'Obligatorio y único: no hay usuario sin personal',
  usuario               VARCHAR(60)      NOT NULL,
  clave_hash            VARCHAR(255)     NOT NULL COMMENT 'password_hash(). Nunca en claro.',
  cambiar_clave         TINYINT(1)       NOT NULL DEFAULT 1 COMMENT 'La contraseña inicial es temporal: obliga a cambiarla',
  totp_secreto_cifrado  TEXT             DEFAULT NULL,
  totp_confirmado_en    DATETIME         DEFAULT NULL,
  totp_ultimo_periodo   BIGINT UNSIGNED  DEFAULT NULL,
  sesion_version        INT UNSIGNED     NOT NULL DEFAULT 1,
  id_estatus            TINYINT UNSIGNED NOT NULL DEFAULT 4,
  ultimo_acceso         DATETIME         DEFAULT NULL,
  creado_en             DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creado_por            INT UNSIGNED     DEFAULT NULL,
  acceso_hasta          DATETIME         DEFAULT NULL COMMENT 'Después de esta fecha la cuenta no entra. NULL: sin caducidad',
  acceso_motivo         VARCHAR(255)     DEFAULT NULL COMMENT 'Por qué se dio el acceso con caducidad',
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuario_usuario (usuario),
  UNIQUE KEY uq_usuario_personal (id_personal),
  KEY ix_usuario_estatus (id_estatus),
  CONSTRAINT fk_usuario_estatus  FOREIGN KEY (id_estatus)  REFERENCES estatus (id),
  CONSTRAINT fk_usuario_personal FOREIGN KEY (id_personal) REFERENCES personal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE usuario_sucursal (
  id_usuario   INT UNSIGNED      NOT NULL,
  id_sucursal  SMALLINT UNSIGNED NOT NULL,
  asignado_en  DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  asignado_por INT UNSIGNED      DEFAULT NULL,
  PRIMARY KEY (id_usuario, id_sucursal),
  KEY ix_usuario_sucursal_sucursal (id_sucursal),
  CONSTRAINT fk_usuario_sucursal_usuario  FOREIGN KEY (id_usuario)  REFERENCES usuario (id),
  CONSTRAINT fk_usuario_sucursal_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Sucursales adicionales que alcanza un usuario (gerentes de zona, cajeros que cubren otra).';

CREATE TABLE dispositivo (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario     INT UNSIGNED NOT NULL,
  identificador  VARCHAR(128) NOT NULL COMMENT 'Identificador que reporta la app',
  nombre         VARCHAR(80)  DEFAULT NULL,
  plataforma     VARCHAR(10)  DEFAULT NULL COMMENT 'android, ios o web',
  token_push     VARCHAR(255) DEFAULT NULL COMMENT 'Token de Expo Push; cambia cuando el equipo lo renueva',
  autorizado     TINYINT(1)   NOT NULL DEFAULT 0,
  autorizado_en  DATETIME     DEFAULT NULL,
  ultimo_acceso  DATETIME     DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_dispositivo_usuario_identificador (id_usuario, identificador),
  KEY ix_dispositivo_identificador (identificador),
  KEY ix_dispositivo_autorizado (autorizado),
  CONSTRAINT fk_dispositivo_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Pareja usuario-dispositivo. La fase 2 la convierte en equipos fijos por sucursal.';

CREATE TABLE token_acceso (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario      INT UNSIGNED NOT NULL,
  id_dispositivo  INT UNSIGNED NOT NULL,
  token_hash      CHAR(64)     NOT NULL COMMENT 'Se guarda el hash, jamás el token',
  creado_en       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expira_en       DATETIME     NOT NULL,
  revocado_en     DATETIME     DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_token_acceso_hash (token_hash),
  KEY ix_token_acceso_usuario (id_usuario),
  KEY ix_token_acceso_dispositivo (id_dispositivo),
  CONSTRAINT fk_token_acceso_dispositivo FOREIGN KEY (id_dispositivo) REFERENCES dispositivo (id),
  CONSTRAINT fk_token_acceso_usuario     FOREIGN KEY (id_usuario)     REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Autenticación de la app. La web usa sesión con CSRF.';

CREATE TABLE totp_codigo_recuperacion (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_usuario   INT UNSIGNED    NOT NULL,
  codigo_hash  VARCHAR(255)    NOT NULL COMMENT 'password_hash(); el código en claro se muestra una vez',
  creado_en    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  usado_en     DATETIME        DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_totp_recuperacion_usuario (id_usuario, usado_en),
  CONSTRAINT fk_totp_recuperacion_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE intento_acceso (
  ambito           VARCHAR(24)       NOT NULL COMMENT 'entrada u otro límite',
  tipo             VARCHAR(16)       NOT NULL COMMENT 'cuenta_ip o ip',
  clave_hash       CHAR(64)          NOT NULL,
  ventana_desde    DATETIME          NOT NULL,
  intentos         SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  bloqueado_hasta  DATETIME          DEFAULT NULL,
  actualizado_en   DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (ambito, tipo, clave_hash),
  KEY ix_intento_acceso_purga (actualizado_en)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Límites de entrada sin identificadores en claro: solo hashes.';

CREATE TABLE revision_acceso (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  revisado_por  INT UNSIGNED NOT NULL,
  revisado_en   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  usuarios      INT UNSIGNED NOT NULL COMMENT 'Cuentas activas al revisar',
  conflictos    INT UNSIGNED NOT NULL COMMENT 'Separación de funciones al revisar',
  nota          VARCHAR(500) NOT NULL,
  PRIMARY KEY (id),
  KEY ix_revision_acceso_momento (revisado_en),
  CONSTRAINT fk_revision_acceso_usuario FOREIGN KEY (revisado_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- FIN 003_personal_usuarios.sql

-- ============================================================================
-- INICIO 004_bitacora_idempotencia.sql
-- ============================================================================
-- =============================================================================
-- Plantilla base — 004 · Bitácora e idempotencia
--
-- La bitácora guarda qué había antes y qué quedó después; no se purga y se
-- sella por tramos. Las tres tablas de idempotencia evitan que un envío
-- repetido (doble clic, reintento por mala señal) se aplique dos veces.
-- =============================================================================

SET NAMES utf8mb4;

CREATE TABLE `bitacora` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `momento` datetime NOT NULL DEFAULT current_timestamp(),
  `modulo` varchar(40) NOT NULL,
  `accion` varchar(40) NOT NULL,
  `entidad` varchar(40) DEFAULT NULL,
  `id_entidad` bigint(20) unsigned DEFAULT NULL,
  `antes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`antes`)),
  `despues` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`despues`)),
  `ip` varchar(45) DEFAULT NULL,
  `canal` varchar(12) DEFAULT NULL COMMENT 'web, api, tarea o guion',
  `operacion` char(36) DEFAULT NULL COMMENT 'UUID compartida por todos los apuntes de la operación',
  `ruta` varchar(190) DEFAULT NULL,
  `accion_ruta` varchar(120) DEFAULT NULL,
  `id_dispositivo` int(10) unsigned DEFAULT NULL,
  `correlacion_hash` char(64) DEFAULT NULL COMMENT 'SHA-256 de la llave de idempotencia; nunca la llave en claro',
  PRIMARY KEY (`id`),
  KEY `ix_bitacora_momento` (`momento`),
  KEY `ix_bitacora_usuario` (`id_usuario`),
  KEY `ix_bitacora_entidad` (`entidad`,`id_entidad`),
  KEY `ix_bitacora_modulo` (`modulo`,`id`),
  KEY `ix_bitacora_canal` (`canal`,`id`),
  KEY `ix_bitacora_accion` (`accion`,`id`),
  KEY `ix_bitacora_operacion` (`operacion`,`id`),
  KEY `ix_bitacora_correlacion` (`correlacion_hash`),
  KEY `fk_bitacora_dispositivo` (`id_dispositivo`),
  CONSTRAINT `fk_bitacora_dispositivo` FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivo` (`id`),
  CONSTRAINT `fk_bitacora_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`),
  CONSTRAINT `ck_bitacora_canal` CHECK (`canal` is null or `canal` in ('web','api','tarea','guion'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Qué había antes y qué quedó después. No se purga.';

CREATE TABLE `bitacora_sello` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desde_id` bigint(20) unsigned NOT NULL,
  `hasta_id` bigint(20) unsigned NOT NULL,
  `renglones` int(10) unsigned NOT NULL,
  `huella` char(64) NOT NULL COMMENT 'HMAC-SHA256 del tramo, encadenado con el sello anterior',
  `huella_anterior` char(64) DEFAULT NULL,
  `sellado_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bitacora_sello_hasta` (`hasta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Un renglón por tramo sellado. Lo escribe y lo verifica guiones/mantenimiento.php.';

CREATE TABLE `operacion_panel` (
  `llave_idempotencia` char(36) NOT NULL,
  `tipo` varchar(30) NOT NULL COMMENT 'baja, arma o desarma',
  `id_usuario` int(10) unsigned NOT NULL,
  `resultado` varchar(40) NOT NULL COMMENT 'Lo que se devolvió: folio o id',
  `procesada_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`llave_idempotencia`),
  KEY `ix_operacion_panel_usuario` (`id_usuario`,`procesada_en`),
  CONSTRAINT `fk_operacion_panel_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Un envío del panel repetido no mueve el inventario dos veces.';

CREATE TABLE `envio_panel` (
  `llave` char(36) NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL,
  `ruta` varchar(190) NOT NULL COMMENT 'Método y ruta: POST /pedidos',
  `estado` enum('en_curso','hecho') NOT NULL DEFAULT 'en_curso',
  `codigo_http` smallint(5) unsigned DEFAULT NULL,
  `redirige` varchar(255) DEFAULT NULL COMMENT 'A dónde se mandó a la persona; NULL si no hubo destino',
  `aviso` varchar(255) DEFAULT NULL,
  `tono` varchar(12) DEFAULT NULL,
  `creada_en` datetime NOT NULL DEFAULT current_timestamp(),
  `terminada_en` datetime DEFAULT NULL,
  PRIMARY KEY (`llave`),
  KEY `ix_envio_panel_creada` (`creada_en`),
  KEY `ix_envio_panel_usuario` (`id_usuario`,`creada_en`),
  CONSTRAINT `fk_envio_panel_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Un envío del panel repetido se contesta igual y no se vuelve a hacer.';

CREATE TABLE `operacion_sincronizada` (
  `llave_idempotencia` char(36) NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL,
  `tipo` varchar(30) NOT NULL,
  `id_resultado` bigint(20) unsigned DEFAULT NULL COMMENT 'Id de lo que se creó, para devolver lo mismo si reintenta',
  `procesada_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`llave_idempotencia`),
  KEY `ix_operacion_usuario` (`id_usuario`,`procesada_en`),
  CONSTRAINT `fk_operacion_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Una operación reintentada no se aplica dos veces.';
-- FIN 004_bitacora_idempotencia.sql

-- ============================================================================
-- INICIO 005_privacidad_avisos.sql
-- ============================================================================
-- =============================================================================
-- Plantilla base — 005 · Privacidad y avisos a equipos
-- =============================================================================

SET NAMES utf8mb4;

CREATE TABLE `solicitud_arco` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` varchar(15) NOT NULL,
  `titular_tipo` varchar(10) NOT NULL,
  `id_titular` int(10) unsigned DEFAULT NULL COMMENT 'cliente.id o personal.id; NULL si es otra persona',
  `solicitante` varchar(160) NOT NULL,
  `contacto` varchar(160) DEFAULT NULL,
  `detalle` varchar(500) NOT NULL,
  `recibida_en` date NOT NULL,
  `vence_en` date NOT NULL,
  `estado` varchar(10) NOT NULL DEFAULT 'abierta',
  `resolucion` varchar(500) DEFAULT NULL,
  `atendida_por` int(10) unsigned DEFAULT NULL,
  `atendida_en` datetime DEFAULT NULL,
  `registrada_por` int(10) unsigned NOT NULL,
  `registrada_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_solicitud_arco_estado` (`estado`,`vence_en`),
  KEY `fk_solicitud_arco_atendio` (`atendida_por`),
  KEY `fk_solicitud_arco_registro` (`registrada_por`),
  CONSTRAINT `fk_solicitud_arco_atendio` FOREIGN KEY (`atendida_por`) REFERENCES `usuario` (`id`),
  CONSTRAINT `fk_solicitud_arco_registro` FOREIGN KEY (`registrada_por`) REFERENCES `usuario` (`id`),
  CONSTRAINT `ck_solicitud_arco_tipo` CHECK (`tipo` in ('acceso','rectificacion','cancelacion','oposicion')),
  CONSTRAINT `ck_solicitud_arco_titular` CHECK (`titular_tipo` in ('cliente','empleado','otro')),
  CONSTRAINT `ck_solicitud_arco_estado` CHECK (`estado` in ('abierta','atendida','rechazada'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Solicitudes de derechos de acceso, rectificación, cancelación y oposición';

CREATE TABLE `aviso` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(80) NOT NULL,
  `cuerpo` varchar(255) NOT NULL,
  `destino_tipo` varchar(10) NOT NULL COMMENT 'persona, puesto, sucursal o todos',
  `destino_id` int(10) unsigned DEFAULT NULL,
  `destino_nombre` varchar(160) NOT NULL COMMENT 'Como se veía al enviar',
  `id_sucursal` smallint(5) unsigned DEFAULT NULL COMMENT 'Alcance de quien envió; NULL es todas',
  `personas` smallint(5) unsigned NOT NULL DEFAULT 0,
  `telefonos` smallint(5) unsigned NOT NULL DEFAULT 0,
  `aceptados` smallint(5) unsigned NOT NULL DEFAULT 0 COMMENT 'Los que Expo recibió',
  `fallidos` smallint(5) unsigned NOT NULL DEFAULT 0,
  `creado_por` int(10) unsigned NOT NULL,
  `creado_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_aviso_creado` (`creado_en`),
  KEY `ix_aviso_sucursal` (`id_sucursal`,`creado_en`),
  KEY `ix_aviso_usuario` (`creado_por`),
  CONSTRAINT `fk_aviso_sucursal` FOREIGN KEY (`id_sucursal`) REFERENCES `sucursal` (`id`),
  CONSTRAINT `fk_aviso_usuario` FOREIGN KEY (`creado_por`) REFERENCES `usuario` (`id`),
  CONSTRAINT `ck_aviso_destino` CHECK (`destino_tipo` in ('persona','puesto','sucursal','todos') and `destino_tipo` = 'todos' = (`destino_id` is null)),
  CONSTRAINT `ck_aviso_conteos` CHECK (`aceptados` + `fallidos` <= `telefonos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Un aviso del panel a varias personas. Cada teléfono tiene su notificacion.';

CREATE TABLE `notificacion` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(10) unsigned NOT NULL COMMENT 'Destinatario',
  `id_aviso` int(10) unsigned DEFAULT NULL,
  `id_dispositivo` int(10) unsigned DEFAULT NULL,
  `titulo` varchar(80) NOT NULL,
  `cuerpo` varchar(255) NOT NULL,
  `datos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`datos`)),
  `creado_en` datetime NOT NULL DEFAULT current_timestamp(),
  `creado_por` int(10) unsigned DEFAULT NULL,
  `enviado_en` datetime DEFAULT NULL,
  `error` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_notificacion_usuario` (`id_usuario`,`creado_en`),
  KEY `ix_notificacion_pendiente` (`enviado_en`,`id`),
  KEY `ix_notificacion_aviso` (`id_aviso`),
  KEY `ix_notificacion_dispositivo` (`id_dispositivo`),
  CONSTRAINT `fk_notificacion_aviso` FOREIGN KEY (`id_aviso`) REFERENCES `aviso` (`id`),
  CONSTRAINT `fk_notificacion_dispositivo` FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivo` (`id`),
  CONSTRAINT `fk_notificacion_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- FIN 005_privacidad_avisos.sql

-- ============================================================================
-- INICIO 006_datos_base.sql
-- ============================================================================
-- =============================================================================
-- Plantilla base — 006 · Datos base
--
-- Entidades y municipios del INEGI, parámetros, puestos y permisos de la capa
-- base. Cada fase agrega sus permisos y los asigna a los puestos en su propio
-- guion.
--
-- Puestos del giro restaurante. Para otro giro se cambia este guion antes de
-- instalar (docs/plantilla/nuevo-negocio.md).
-- =============================================================================

SET NAMES utf8mb4;

INSERT INTO `estado` VALUES (1,'Aguascalientes','Ags.');
INSERT INTO `estado` VALUES (2,'Baja California','BC');
INSERT INTO `estado` VALUES (3,'Baja California Sur','BCS');
INSERT INTO `estado` VALUES (4,'Campeche','Camp.');
INSERT INTO `estado` VALUES (5,'Coahuila de Zaragoza','Coah.');
INSERT INTO `estado` VALUES (6,'Colima','Col.');
INSERT INTO `estado` VALUES (7,'Chiapas','Chis.');
INSERT INTO `estado` VALUES (8,'Chihuahua','Chih.');
INSERT INTO `estado` VALUES (9,'Ciudad de México','CDMX');
INSERT INTO `estado` VALUES (10,'Durango','Dgo.');
INSERT INTO `estado` VALUES (11,'Guanajuato','Gto.');
INSERT INTO `estado` VALUES (12,'Guerrero','Gro.');
INSERT INTO `estado` VALUES (13,'Hidalgo','Hgo.');
INSERT INTO `estado` VALUES (14,'Jalisco','Jal.');
INSERT INTO `estado` VALUES (15,'México','Mex.');
INSERT INTO `estado` VALUES (16,'Michoacán de Ocampo','Mich.');
INSERT INTO `estado` VALUES (17,'Morelos','Mor.');
INSERT INTO `estado` VALUES (18,'Nayarit','Nay.');
INSERT INTO `estado` VALUES (19,'Nuevo León','NL');
INSERT INTO `estado` VALUES (20,'Oaxaca','Oax.');
INSERT INTO `estado` VALUES (21,'Puebla','Pue.');
INSERT INTO `estado` VALUES (22,'Querétaro','Qro.');
INSERT INTO `estado` VALUES (23,'Quintana Roo','Q. Roo');
INSERT INTO `estado` VALUES (24,'San Luis Potosí','SLP');
INSERT INTO `estado` VALUES (25,'Sinaloa','Sin.');
INSERT INTO `estado` VALUES (26,'Sonora','Son.');
INSERT INTO `estado` VALUES (27,'Tabasco','Tab.');
INSERT INTO `estado` VALUES (28,'Tamaulipas','Tamps.');
INSERT INTO `estado` VALUES (29,'Tlaxcala','Tlax.');
INSERT INTO `estado` VALUES (30,'Veracruz de Ignacio de la Llave','Ver.');
INSERT INTO `estado` VALUES (31,'Yucatán','Yuc.');
INSERT INTO `estado` VALUES (32,'Zacatecas','Zac.');
INSERT INTO `municipio` VALUES (1,1,1,'Aguascalientes');
INSERT INTO `municipio` VALUES (2,1,2,'Asientos');
INSERT INTO `municipio` VALUES (3,1,3,'Calvillo');
INSERT INTO `municipio` VALUES (4,1,4,'Cosío');
INSERT INTO `municipio` VALUES (5,1,5,'Jesús María');
INSERT INTO `municipio` VALUES (6,1,6,'Pabellón de Arteaga');
INSERT INTO `municipio` VALUES (7,1,7,'Rincón de Romos');
INSERT INTO `municipio` VALUES (8,1,8,'San José de Gracia');
INSERT INTO `municipio` VALUES (9,1,9,'Tepezalá');
INSERT INTO `municipio` VALUES (10,1,10,'El Llano');
INSERT INTO `municipio` VALUES (11,1,11,'San Francisco de los Romo');
INSERT INTO `municipio` VALUES (12,2,1,'Ensenada');
INSERT INTO `municipio` VALUES (13,2,2,'Mexicali');
INSERT INTO `municipio` VALUES (14,2,3,'Tecate');
INSERT INTO `municipio` VALUES (15,2,4,'Tijuana');
INSERT INTO `municipio` VALUES (16,2,5,'Playas de Rosarito');
INSERT INTO `municipio` VALUES (17,2,6,'San Quintín');
INSERT INTO `municipio` VALUES (18,2,7,'San Felipe');
INSERT INTO `municipio` VALUES (19,3,1,'Comondú');
INSERT INTO `municipio` VALUES (20,3,2,'Mulegé');
INSERT INTO `municipio` VALUES (21,3,3,'La Paz');
INSERT INTO `municipio` VALUES (22,3,8,'Los Cabos');
INSERT INTO `municipio` VALUES (23,3,9,'Loreto');
INSERT INTO `municipio` VALUES (24,4,1,'Calkiní');
INSERT INTO `municipio` VALUES (25,4,2,'Campeche');
INSERT INTO `municipio` VALUES (26,4,3,'Carmen');
INSERT INTO `municipio` VALUES (27,4,4,'Champotón');
INSERT INTO `municipio` VALUES (28,4,5,'Hecelchakán');
INSERT INTO `municipio` VALUES (29,4,6,'Hopelchén');
INSERT INTO `municipio` VALUES (30,4,7,'Palizada');
INSERT INTO `municipio` VALUES (31,4,8,'Tenabo');
INSERT INTO `municipio` VALUES (32,4,9,'Escárcega');
INSERT INTO `municipio` VALUES (33,4,10,'Calakmul');
INSERT INTO `municipio` VALUES (34,4,11,'Candelaria');
INSERT INTO `municipio` VALUES (35,4,12,'Seybaplaya');
INSERT INTO `municipio` VALUES (36,4,13,'Dzitbalché');
INSERT INTO `municipio` VALUES (37,5,1,'Abasolo');
INSERT INTO `municipio` VALUES (38,5,2,'Acuña');
INSERT INTO `municipio` VALUES (39,5,3,'Allende');
INSERT INTO `municipio` VALUES (40,5,4,'Arteaga');
INSERT INTO `municipio` VALUES (41,5,5,'Candela');
INSERT INTO `municipio` VALUES (42,5,6,'Castaños');
INSERT INTO `municipio` VALUES (43,5,7,'Cuatro Ciénegas');
INSERT INTO `municipio` VALUES (44,5,8,'Escobedo');
INSERT INTO `municipio` VALUES (45,5,9,'Francisco I. Madero');
INSERT INTO `municipio` VALUES (46,5,10,'Frontera');
INSERT INTO `municipio` VALUES (47,5,11,'General Cepeda');
INSERT INTO `municipio` VALUES (48,5,12,'Guerrero');
INSERT INTO `municipio` VALUES (49,5,13,'Hidalgo');
INSERT INTO `municipio` VALUES (50,5,14,'Jiménez');
INSERT INTO `municipio` VALUES (51,5,15,'Juárez');
INSERT INTO `municipio` VALUES (52,5,16,'Lamadrid');
INSERT INTO `municipio` VALUES (53,5,17,'Matamoros');
INSERT INTO `municipio` VALUES (54,5,18,'Monclova');
INSERT INTO `municipio` VALUES (55,5,19,'Morelos');
INSERT INTO `municipio` VALUES (56,5,20,'Múzquiz');
INSERT INTO `municipio` VALUES (57,5,21,'Nadadores');
INSERT INTO `municipio` VALUES (58,5,22,'Nava');
INSERT INTO `municipio` VALUES (59,5,23,'Ocampo');
INSERT INTO `municipio` VALUES (60,5,24,'Parras');
INSERT INTO `municipio` VALUES (61,5,25,'Piedras Negras');
INSERT INTO `municipio` VALUES (62,5,26,'Progreso');
INSERT INTO `municipio` VALUES (63,5,27,'Ramos Arizpe');
INSERT INTO `municipio` VALUES (64,5,28,'Sabinas');
INSERT INTO `municipio` VALUES (65,5,29,'Sacramento');
INSERT INTO `municipio` VALUES (66,5,30,'Saltillo');
INSERT INTO `municipio` VALUES (67,5,31,'San Buenaventura');
INSERT INTO `municipio` VALUES (68,5,32,'San Juan de Sabinas');
INSERT INTO `municipio` VALUES (69,5,33,'San Pedro');
INSERT INTO `municipio` VALUES (70,5,34,'Sierra Mojada');
INSERT INTO `municipio` VALUES (71,5,35,'Torreón');
INSERT INTO `municipio` VALUES (72,5,36,'Viesca');
INSERT INTO `municipio` VALUES (73,5,37,'Villa Unión');
INSERT INTO `municipio` VALUES (74,5,38,'Zaragoza');
INSERT INTO `municipio` VALUES (75,6,1,'Armería');
INSERT INTO `municipio` VALUES (76,6,2,'Colima');
INSERT INTO `municipio` VALUES (77,6,3,'Comala');
INSERT INTO `municipio` VALUES (78,6,4,'Coquimatlán');
INSERT INTO `municipio` VALUES (79,6,5,'Cuauhtémoc');
INSERT INTO `municipio` VALUES (80,6,6,'Ixtlahuacán');
INSERT INTO `municipio` VALUES (81,6,7,'Manzanillo');
INSERT INTO `municipio` VALUES (82,6,8,'Minatitlán');
INSERT INTO `municipio` VALUES (83,6,9,'Tecomán');
INSERT INTO `municipio` VALUES (84,6,10,'Villa de Álvarez');
INSERT INTO `municipio` VALUES (85,7,1,'Acacoyagua');
INSERT INTO `municipio` VALUES (86,7,2,'Acala');
INSERT INTO `municipio` VALUES (87,7,3,'Acapetahua');
INSERT INTO `municipio` VALUES (88,7,4,'Altamirano');
INSERT INTO `municipio` VALUES (89,7,5,'Amatán');
INSERT INTO `municipio` VALUES (90,7,6,'Amatenango de la Frontera');
INSERT INTO `municipio` VALUES (91,7,7,'Amatenango del Valle');
INSERT INTO `municipio` VALUES (92,7,8,'Ángel Albino Corzo');
INSERT INTO `municipio` VALUES (93,7,9,'Arriaga');
INSERT INTO `municipio` VALUES (94,7,10,'Bejucal de Ocampo');
INSERT INTO `municipio` VALUES (95,7,11,'Bella Vista');
INSERT INTO `municipio` VALUES (96,7,12,'Berriozábal');
INSERT INTO `municipio` VALUES (97,7,13,'Bochil');
INSERT INTO `municipio` VALUES (98,7,14,'El Bosque');
INSERT INTO `municipio` VALUES (99,7,15,'Cacahoatán');
INSERT INTO `municipio` VALUES (100,7,16,'Catazajá');
INSERT INTO `municipio` VALUES (101,7,17,'Cintalapa de Figueroa');
INSERT INTO `municipio` VALUES (102,7,18,'Coapilla');
INSERT INTO `municipio` VALUES (103,7,19,'Comitán de Domínguez');
INSERT INTO `municipio` VALUES (104,7,20,'La Concordia');
INSERT INTO `municipio` VALUES (105,7,21,'Copainalá');
INSERT INTO `municipio` VALUES (106,7,22,'Chalchihuitán');
INSERT INTO `municipio` VALUES (107,7,23,'Chamula');
INSERT INTO `municipio` VALUES (108,7,24,'Chanal');
INSERT INTO `municipio` VALUES (109,7,25,'Chapultenango');
INSERT INTO `municipio` VALUES (110,7,26,'Chenalhó');
INSERT INTO `municipio` VALUES (111,7,27,'Chiapa de Corzo');
INSERT INTO `municipio` VALUES (112,7,28,'Chiapilla');
INSERT INTO `municipio` VALUES (113,7,29,'Chicoasén');
INSERT INTO `municipio` VALUES (114,7,30,'Chicomuselo');
INSERT INTO `municipio` VALUES (115,7,31,'Chilón');
INSERT INTO `municipio` VALUES (116,7,32,'Escuintla');
INSERT INTO `municipio` VALUES (117,7,33,'Francisco León');
INSERT INTO `municipio` VALUES (118,7,34,'Frontera Comalapa');
INSERT INTO `municipio` VALUES (119,7,35,'Frontera Hidalgo');
INSERT INTO `municipio` VALUES (120,7,36,'La Grandeza');
INSERT INTO `municipio` VALUES (121,7,37,'Huehuetán');
INSERT INTO `municipio` VALUES (122,7,38,'Huixtán');
INSERT INTO `municipio` VALUES (123,7,39,'Huitiupán');
INSERT INTO `municipio` VALUES (124,7,40,'Huixtla');
INSERT INTO `municipio` VALUES (125,7,41,'La Independencia');
INSERT INTO `municipio` VALUES (126,7,42,'Ixhuatán');
INSERT INTO `municipio` VALUES (127,7,43,'Ixtacomitán');
INSERT INTO `municipio` VALUES (128,7,44,'Ixtapa');
INSERT INTO `municipio` VALUES (129,7,45,'Ixtapangajoya');
INSERT INTO `municipio` VALUES (130,7,46,'Jiquipilas');
INSERT INTO `municipio` VALUES (131,7,47,'Jitotol');
INSERT INTO `municipio` VALUES (132,7,48,'Juárez');
INSERT INTO `municipio` VALUES (133,7,49,'Larráinzar');
INSERT INTO `municipio` VALUES (134,7,50,'La Libertad');
INSERT INTO `municipio` VALUES (135,7,51,'Mapastepec');
INSERT INTO `municipio` VALUES (136,7,52,'Las Margaritas');
INSERT INTO `municipio` VALUES (137,7,53,'Mazapa de Madero');
INSERT INTO `municipio` VALUES (138,7,54,'Mazatán');
INSERT INTO `municipio` VALUES (139,7,55,'Metapa');
INSERT INTO `municipio` VALUES (140,7,56,'Mitontic');
INSERT INTO `municipio` VALUES (141,7,57,'Motozintla');
INSERT INTO `municipio` VALUES (142,7,58,'Nicolás Ruíz');
INSERT INTO `municipio` VALUES (143,7,59,'Ocosingo');
INSERT INTO `municipio` VALUES (144,7,60,'Ocotepec');
INSERT INTO `municipio` VALUES (145,7,61,'Ocozocoautla de Espinosa');
INSERT INTO `municipio` VALUES (146,7,62,'Ostuacán');
INSERT INTO `municipio` VALUES (147,7,63,'Osumacinta');
INSERT INTO `municipio` VALUES (148,7,64,'Oxchuc');
INSERT INTO `municipio` VALUES (149,7,65,'Palenque');
INSERT INTO `municipio` VALUES (150,7,66,'Pantelhó');
INSERT INTO `municipio` VALUES (151,7,67,'Pantepec');
INSERT INTO `municipio` VALUES (152,7,68,'Pichucalco');
INSERT INTO `municipio` VALUES (153,7,69,'Pijijiapan');
INSERT INTO `municipio` VALUES (154,7,70,'El Porvenir');
INSERT INTO `municipio` VALUES (155,7,71,'Villa Comaltitlán');
INSERT INTO `municipio` VALUES (156,7,72,'Pueblo Nuevo Solistahuacán');
INSERT INTO `municipio` VALUES (157,7,73,'Rayón');
INSERT INTO `municipio` VALUES (158,7,74,'Reforma');
INSERT INTO `municipio` VALUES (159,7,75,'Las Rosas');
INSERT INTO `municipio` VALUES (160,7,76,'Sabanilla');
INSERT INTO `municipio` VALUES (161,7,77,'Salto de Agua');
INSERT INTO `municipio` VALUES (162,7,78,'San Cristóbal de las Casas');
INSERT INTO `municipio` VALUES (163,7,79,'San Fernando');
INSERT INTO `municipio` VALUES (164,7,80,'Siltepec');
INSERT INTO `municipio` VALUES (165,7,81,'Simojovel');
INSERT INTO `municipio` VALUES (166,7,82,'Sitalá');
INSERT INTO `municipio` VALUES (167,7,83,'Socoltenango');
INSERT INTO `municipio` VALUES (168,7,84,'Solosuchiapa');
INSERT INTO `municipio` VALUES (169,7,85,'Soyaló');
INSERT INTO `municipio` VALUES (170,7,86,'Suchiapa');
INSERT INTO `municipio` VALUES (171,7,87,'Suchiate');
INSERT INTO `municipio` VALUES (172,7,88,'Sunuapa');
INSERT INTO `municipio` VALUES (173,7,89,'Tapachula');
INSERT INTO `municipio` VALUES (174,7,90,'Tapalapa');
INSERT INTO `municipio` VALUES (175,7,91,'Tapilula');
INSERT INTO `municipio` VALUES (176,7,92,'Tecpatán');
INSERT INTO `municipio` VALUES (177,7,93,'Tenejapa');
INSERT INTO `municipio` VALUES (178,7,94,'Teopisca');
INSERT INTO `municipio` VALUES (179,7,96,'Tila');
INSERT INTO `municipio` VALUES (180,7,97,'Tonalá');
INSERT INTO `municipio` VALUES (181,7,98,'Totolapa');
INSERT INTO `municipio` VALUES (182,7,99,'La Trinitaria');
INSERT INTO `municipio` VALUES (183,7,100,'Tumbalá');
INSERT INTO `municipio` VALUES (184,7,101,'Tuxtla Gutiérrez');
INSERT INTO `municipio` VALUES (185,7,102,'Tuxtla Chico');
INSERT INTO `municipio` VALUES (186,7,103,'Tuzantán');
INSERT INTO `municipio` VALUES (187,7,104,'Tzimol');
INSERT INTO `municipio` VALUES (188,7,105,'Unión Juárez');
INSERT INTO `municipio` VALUES (189,7,106,'Venustiano Carranza');
INSERT INTO `municipio` VALUES (190,7,107,'Villa Corzo');
INSERT INTO `municipio` VALUES (191,7,108,'Villaflores');
INSERT INTO `municipio` VALUES (192,7,109,'Yajalón');
INSERT INTO `municipio` VALUES (193,7,110,'San Lucas');
INSERT INTO `municipio` VALUES (194,7,111,'Zinacantán');
INSERT INTO `municipio` VALUES (195,7,112,'San Juan Cancuc');
INSERT INTO `municipio` VALUES (196,7,113,'Aldama');
INSERT INTO `municipio` VALUES (197,7,114,'Benemérito de las Américas');
INSERT INTO `municipio` VALUES (198,7,115,'Maravilla Tenejapa');
INSERT INTO `municipio` VALUES (199,7,116,'Marqués de Comillas');
INSERT INTO `municipio` VALUES (200,7,117,'Montecristo de Guerrero');
INSERT INTO `municipio` VALUES (201,7,118,'San Andrés Duraznal');
INSERT INTO `municipio` VALUES (202,7,119,'Santiago el Pinar');
INSERT INTO `municipio` VALUES (203,7,120,'Capitán Luis Ángel Vidal');
INSERT INTO `municipio` VALUES (204,7,121,'Rincón Chamula San Pedro');
INSERT INTO `municipio` VALUES (205,7,122,'El Parral');
INSERT INTO `municipio` VALUES (206,7,123,'Emiliano Zapata');
INSERT INTO `municipio` VALUES (207,7,124,'Mezcalapa');
INSERT INTO `municipio` VALUES (208,7,125,'Honduras de la Sierra');
INSERT INTO `municipio` VALUES (209,8,1,'Ahumada');
INSERT INTO `municipio` VALUES (210,8,2,'Aldama');
INSERT INTO `municipio` VALUES (211,8,3,'Allende');
INSERT INTO `municipio` VALUES (212,8,4,'Aquiles Serdán');
INSERT INTO `municipio` VALUES (213,8,5,'Ascensión');
INSERT INTO `municipio` VALUES (214,8,6,'Bachíniva');
INSERT INTO `municipio` VALUES (215,8,7,'Balleza');
INSERT INTO `municipio` VALUES (216,8,8,'Batopilas de Manuel Gómez Morín');
INSERT INTO `municipio` VALUES (217,8,9,'Bocoyna');
INSERT INTO `municipio` VALUES (218,8,10,'Buenaventura');
INSERT INTO `municipio` VALUES (219,8,11,'Camargo');
INSERT INTO `municipio` VALUES (220,8,12,'Carichí');
INSERT INTO `municipio` VALUES (221,8,13,'Casas Grandes');
INSERT INTO `municipio` VALUES (222,8,14,'Coronado');
INSERT INTO `municipio` VALUES (223,8,15,'Coyame del Sotol');
INSERT INTO `municipio` VALUES (224,8,16,'La Cruz');
INSERT INTO `municipio` VALUES (225,8,17,'Cuauhtémoc');
INSERT INTO `municipio` VALUES (226,8,18,'Cusihuiriachi');
INSERT INTO `municipio` VALUES (227,8,19,'Chihuahua');
INSERT INTO `municipio` VALUES (228,8,20,'Chínipas');
INSERT INTO `municipio` VALUES (229,8,21,'Delicias');
INSERT INTO `municipio` VALUES (230,8,22,'Dr. Belisario Domínguez');
INSERT INTO `municipio` VALUES (231,8,23,'Galeana');
INSERT INTO `municipio` VALUES (232,8,24,'Santa Isabel');
INSERT INTO `municipio` VALUES (233,8,25,'Gómez Farías');
INSERT INTO `municipio` VALUES (234,8,26,'Gran Morelos');
INSERT INTO `municipio` VALUES (235,8,27,'Guachochi');
INSERT INTO `municipio` VALUES (236,8,28,'Guadalupe');
INSERT INTO `municipio` VALUES (237,8,29,'Guadalupe y Calvo');
INSERT INTO `municipio` VALUES (238,8,30,'Guazapares');
INSERT INTO `municipio` VALUES (239,8,31,'Guerrero');
INSERT INTO `municipio` VALUES (240,8,32,'Hidalgo del Parral');
INSERT INTO `municipio` VALUES (241,8,33,'Huejotitán');
INSERT INTO `municipio` VALUES (242,8,34,'Ignacio Zaragoza');
INSERT INTO `municipio` VALUES (243,8,35,'Janos');
INSERT INTO `municipio` VALUES (244,8,36,'Jiménez');
INSERT INTO `municipio` VALUES (245,8,37,'Juárez');
INSERT INTO `municipio` VALUES (246,8,38,'Julimes');
INSERT INTO `municipio` VALUES (247,8,39,'López');
INSERT INTO `municipio` VALUES (248,8,40,'Madera');
INSERT INTO `municipio` VALUES (249,8,41,'Maguarichi');
INSERT INTO `municipio` VALUES (250,8,42,'Manuel Benavides');
INSERT INTO `municipio` VALUES (251,8,43,'Matachí');
INSERT INTO `municipio` VALUES (252,8,44,'Matamoros');
INSERT INTO `municipio` VALUES (253,8,45,'Meoqui');
INSERT INTO `municipio` VALUES (254,8,46,'Morelos');
INSERT INTO `municipio` VALUES (255,8,47,'Moris');
INSERT INTO `municipio` VALUES (256,8,48,'Namiquipa');
INSERT INTO `municipio` VALUES (257,8,49,'Nonoava');
INSERT INTO `municipio` VALUES (258,8,50,'Nuevo Casas Grandes');
INSERT INTO `municipio` VALUES (259,8,51,'Ocampo');
INSERT INTO `municipio` VALUES (260,8,52,'Ojinaga');
INSERT INTO `municipio` VALUES (261,8,53,'Praxedis G. Guerrero');
INSERT INTO `municipio` VALUES (262,8,54,'Riva Palacio');
INSERT INTO `municipio` VALUES (263,8,55,'Rosales');
INSERT INTO `municipio` VALUES (264,8,56,'Valle del Rosario');
INSERT INTO `municipio` VALUES (265,8,57,'San Francisco de Borja');
INSERT INTO `municipio` VALUES (266,8,58,'San Francisco de Conchos');
INSERT INTO `municipio` VALUES (267,8,59,'San Francisco del Oro');
INSERT INTO `municipio` VALUES (268,8,60,'Santa Bárbara');
INSERT INTO `municipio` VALUES (269,8,61,'Satevó');
INSERT INTO `municipio` VALUES (270,8,62,'Saucillo');
INSERT INTO `municipio` VALUES (271,8,63,'Temósachic');
INSERT INTO `municipio` VALUES (272,8,64,'El Tule');
INSERT INTO `municipio` VALUES (273,8,65,'Urique');
INSERT INTO `municipio` VALUES (274,8,66,'Uruachi');
INSERT INTO `municipio` VALUES (275,8,67,'Valle de Zaragoza');
INSERT INTO `municipio` VALUES (276,9,2,'Azcapotzalco');
INSERT INTO `municipio` VALUES (277,9,3,'Coyoacán');
INSERT INTO `municipio` VALUES (278,9,4,'Cuajimalpa de Morelos');
INSERT INTO `municipio` VALUES (279,9,5,'Gustavo A. Madero');
INSERT INTO `municipio` VALUES (280,9,6,'Iztacalco');
INSERT INTO `municipio` VALUES (281,9,7,'Iztapalapa');
INSERT INTO `municipio` VALUES (282,9,8,'La Magdalena Contreras');
INSERT INTO `municipio` VALUES (283,9,9,'Milpa Alta');
INSERT INTO `municipio` VALUES (284,9,10,'Álvaro Obregón');
INSERT INTO `municipio` VALUES (285,9,11,'Tláhuac');
INSERT INTO `municipio` VALUES (286,9,12,'Tlalpan');
INSERT INTO `municipio` VALUES (287,9,13,'Xochimilco');
INSERT INTO `municipio` VALUES (288,9,14,'Benito Juárez');
INSERT INTO `municipio` VALUES (289,9,15,'Cuauhtémoc');
INSERT INTO `municipio` VALUES (290,9,16,'Miguel Hidalgo');
INSERT INTO `municipio` VALUES (291,9,17,'Venustiano Carranza');
INSERT INTO `municipio` VALUES (292,10,1,'Canatlán');
INSERT INTO `municipio` VALUES (293,10,2,'Canelas');
INSERT INTO `municipio` VALUES (294,10,3,'Coneto de Comonfort');
INSERT INTO `municipio` VALUES (295,10,4,'Cuencamé');
INSERT INTO `municipio` VALUES (296,10,5,'Durango');
INSERT INTO `municipio` VALUES (297,10,6,'General Simón Bolívar');
INSERT INTO `municipio` VALUES (298,10,7,'Gómez Palacio');
INSERT INTO `municipio` VALUES (299,10,8,'Guadalupe Victoria');
INSERT INTO `municipio` VALUES (300,10,9,'Guanaceví');
INSERT INTO `municipio` VALUES (301,10,10,'Hidalgo');
INSERT INTO `municipio` VALUES (302,10,11,'Indé');
INSERT INTO `municipio` VALUES (303,10,12,'Lerdo');
INSERT INTO `municipio` VALUES (304,10,13,'Mapimí');
INSERT INTO `municipio` VALUES (305,10,14,'Mezquital');
INSERT INTO `municipio` VALUES (306,10,15,'Nazas');
INSERT INTO `municipio` VALUES (307,10,16,'Nombre de Dios');
INSERT INTO `municipio` VALUES (308,10,17,'Ocampo');
INSERT INTO `municipio` VALUES (309,10,18,'El Oro');
INSERT INTO `municipio` VALUES (310,10,19,'Otáez');
INSERT INTO `municipio` VALUES (311,10,20,'Pánuco de Coronado');
INSERT INTO `municipio` VALUES (312,10,21,'Peñón Blanco');
INSERT INTO `municipio` VALUES (313,10,22,'Poanas');
INSERT INTO `municipio` VALUES (314,10,23,'Pueblo Nuevo');
INSERT INTO `municipio` VALUES (315,10,24,'Rodeo');
INSERT INTO `municipio` VALUES (316,10,25,'San Bernardo');
INSERT INTO `municipio` VALUES (317,10,26,'San Dimas');
INSERT INTO `municipio` VALUES (318,10,27,'San Juan de Guadalupe');
INSERT INTO `municipio` VALUES (319,10,28,'San Juan del Río');
INSERT INTO `municipio` VALUES (320,10,29,'San Luis del Cordero');
INSERT INTO `municipio` VALUES (321,10,30,'San Pedro del Gallo');
INSERT INTO `municipio` VALUES (322,10,31,'Santa Clara');
INSERT INTO `municipio` VALUES (323,10,32,'Santiago Papasquiaro');
INSERT INTO `municipio` VALUES (324,10,33,'Súchil');
INSERT INTO `municipio` VALUES (325,10,34,'Tamazula');
INSERT INTO `municipio` VALUES (326,10,35,'Tepehuanes');
INSERT INTO `municipio` VALUES (327,10,36,'Tlahualilo');
INSERT INTO `municipio` VALUES (328,10,37,'Topia');
INSERT INTO `municipio` VALUES (329,10,38,'Vicente Guerrero');
INSERT INTO `municipio` VALUES (330,10,39,'Nuevo Ideal');
INSERT INTO `municipio` VALUES (331,11,1,'Abasolo');
INSERT INTO `municipio` VALUES (332,11,2,'Acámbaro');
INSERT INTO `municipio` VALUES (333,11,3,'San Miguel de Allende');
INSERT INTO `municipio` VALUES (334,11,4,'Apaseo el Alto');
INSERT INTO `municipio` VALUES (335,11,5,'Apaseo el Grande');
INSERT INTO `municipio` VALUES (336,11,6,'Atarjea');
INSERT INTO `municipio` VALUES (337,11,7,'Celaya');
INSERT INTO `municipio` VALUES (338,11,8,'Manuel Doblado');
INSERT INTO `municipio` VALUES (339,11,9,'Comonfort');
INSERT INTO `municipio` VALUES (340,11,10,'Coroneo');
INSERT INTO `municipio` VALUES (341,11,11,'Cortazar');
INSERT INTO `municipio` VALUES (342,11,12,'Cuerámaro');
INSERT INTO `municipio` VALUES (343,11,13,'Doctor Mora');
INSERT INTO `municipio` VALUES (344,11,14,'Dolores Hidalgo Cuna de la Independencia Nacional');
INSERT INTO `municipio` VALUES (345,11,15,'Guanajuato');
INSERT INTO `municipio` VALUES (346,11,16,'Huanímaro');
INSERT INTO `municipio` VALUES (347,11,17,'Irapuato');
INSERT INTO `municipio` VALUES (348,11,18,'Jaral del Progreso');
INSERT INTO `municipio` VALUES (349,11,19,'Jerécuaro');
INSERT INTO `municipio` VALUES (350,11,20,'León');
INSERT INTO `municipio` VALUES (351,11,21,'Moroleón');
INSERT INTO `municipio` VALUES (352,11,22,'Ocampo');
INSERT INTO `municipio` VALUES (353,11,23,'Pénjamo');
INSERT INTO `municipio` VALUES (354,11,24,'Pueblo Nuevo');
INSERT INTO `municipio` VALUES (355,11,25,'Purísima del Rincón');
INSERT INTO `municipio` VALUES (356,11,26,'Romita');
INSERT INTO `municipio` VALUES (357,11,27,'Salamanca');
INSERT INTO `municipio` VALUES (358,11,28,'Salvatierra');
INSERT INTO `municipio` VALUES (359,11,29,'San Diego de la Unión');
INSERT INTO `municipio` VALUES (360,11,30,'San Felipe');
INSERT INTO `municipio` VALUES (361,11,31,'San Francisco del Rincón');
INSERT INTO `municipio` VALUES (362,11,32,'San José de Iturbide');
INSERT INTO `municipio` VALUES (363,11,33,'San Luis de la Paz');
INSERT INTO `municipio` VALUES (364,11,34,'Santa Catarina');
INSERT INTO `municipio` VALUES (365,11,35,'Santa Cruz de Juventino Rosas');
INSERT INTO `municipio` VALUES (366,11,36,'Santiago Maravatío');
INSERT INTO `municipio` VALUES (367,11,37,'Silao de la Victoria');
INSERT INTO `municipio` VALUES (368,11,38,'Tarandacuao');
INSERT INTO `municipio` VALUES (369,11,39,'Tarimoro');
INSERT INTO `municipio` VALUES (370,11,40,'Tierra Blanca');
INSERT INTO `municipio` VALUES (371,11,41,'Uriangato');
INSERT INTO `municipio` VALUES (372,11,42,'Valle de Santiago');
INSERT INTO `municipio` VALUES (373,11,43,'Victoria');
INSERT INTO `municipio` VALUES (374,11,44,'Villagrán');
INSERT INTO `municipio` VALUES (375,11,45,'Xichú');
INSERT INTO `municipio` VALUES (376,11,46,'Yuriria');
INSERT INTO `municipio` VALUES (377,12,1,'Acapulco de Juárez');
INSERT INTO `municipio` VALUES (378,12,2,'Ahuacuotzingo');
INSERT INTO `municipio` VALUES (379,12,3,'Ajuchitlán del Progreso');
INSERT INTO `municipio` VALUES (380,12,4,'Alcozauca de Guerrero');
INSERT INTO `municipio` VALUES (381,12,5,'Alpoyeca');
INSERT INTO `municipio` VALUES (382,12,6,'Apaxtla de Castrejón');
INSERT INTO `municipio` VALUES (383,12,7,'Arcelia');
INSERT INTO `municipio` VALUES (384,12,8,'Atenango del Río');
INSERT INTO `municipio` VALUES (385,12,9,'Atlamajalcingo del Monte');
INSERT INTO `municipio` VALUES (386,12,10,'Atlixtac');
INSERT INTO `municipio` VALUES (387,12,11,'Atoyac de Álvarez');
INSERT INTO `municipio` VALUES (388,12,12,'Ayutla de los Libres');
INSERT INTO `municipio` VALUES (389,12,13,'Azoyú');
INSERT INTO `municipio` VALUES (390,12,14,'Benito Juárez');
INSERT INTO `municipio` VALUES (391,12,15,'Buenavista de Cuéllar');
INSERT INTO `municipio` VALUES (392,12,16,'Coahuayutla de José María Izazaga');
INSERT INTO `municipio` VALUES (393,12,17,'Cocula');
INSERT INTO `municipio` VALUES (394,12,18,'Copala');
INSERT INTO `municipio` VALUES (395,12,19,'Copalillo');
INSERT INTO `municipio` VALUES (396,12,20,'Copanatoyac');
INSERT INTO `municipio` VALUES (397,12,21,'Coyuca de Benítez');
INSERT INTO `municipio` VALUES (398,12,22,'Coyuca de Catalán');
INSERT INTO `municipio` VALUES (399,12,23,'Cuajinicuilapa');
INSERT INTO `municipio` VALUES (400,12,24,'Cualác');
INSERT INTO `municipio` VALUES (401,12,25,'Cuautepec');
INSERT INTO `municipio` VALUES (402,12,26,'Cuetzala del Progreso');
INSERT INTO `municipio` VALUES (403,12,27,'Cutzamala de Pinzón');
INSERT INTO `municipio` VALUES (404,12,28,'Chilapa de Álvarez');
INSERT INTO `municipio` VALUES (405,12,29,'Chilpancingo de los Bravo');
INSERT INTO `municipio` VALUES (406,12,30,'Florencio Villarreal');
INSERT INTO `municipio` VALUES (407,12,31,'General Canuto A. Neri');
INSERT INTO `municipio` VALUES (408,12,32,'General Heliodoro Castillo');
INSERT INTO `municipio` VALUES (409,12,33,'Huamuxtitlán');
INSERT INTO `municipio` VALUES (410,12,34,'Huitzuco de los Figueroa');
INSERT INTO `municipio` VALUES (411,12,35,'Iguala de la Independencia');
INSERT INTO `municipio` VALUES (412,12,36,'Igualapa');
INSERT INTO `municipio` VALUES (413,12,37,'Ixcateopan de Cuauhtémoc');
INSERT INTO `municipio` VALUES (414,12,38,'Zihuatanejo de Azueta');
INSERT INTO `municipio` VALUES (415,12,39,'Juan R. Escudero');
INSERT INTO `municipio` VALUES (416,12,40,'Leonardo Bravo');
INSERT INTO `municipio` VALUES (417,12,41,'Malinaltepec');
INSERT INTO `municipio` VALUES (418,12,42,'Mártir de Cuilapan');
INSERT INTO `municipio` VALUES (419,12,43,'Metlatónoc');
INSERT INTO `municipio` VALUES (420,12,44,'Mochitlán');
INSERT INTO `municipio` VALUES (421,12,45,'Olinalá');
INSERT INTO `municipio` VALUES (422,12,46,'Ometepec');
INSERT INTO `municipio` VALUES (423,12,47,'Pedro Ascencio Alquisiras');
INSERT INTO `municipio` VALUES (424,12,48,'Petatlán');
INSERT INTO `municipio` VALUES (425,12,49,'Pilcaya');
INSERT INTO `municipio` VALUES (426,12,50,'Pungarabato');
INSERT INTO `municipio` VALUES (427,12,51,'Quechultenango');
INSERT INTO `municipio` VALUES (428,12,52,'San Luis Acatlán');
INSERT INTO `municipio` VALUES (429,12,53,'San Marcos');
INSERT INTO `municipio` VALUES (430,12,54,'San Miguel Totolapan');
INSERT INTO `municipio` VALUES (431,12,55,'Taxco de Alarcón');
INSERT INTO `municipio` VALUES (432,12,56,'Tecoanapa');
INSERT INTO `municipio` VALUES (433,12,57,'Técpan de Galeana');
INSERT INTO `municipio` VALUES (434,12,58,'Teloloapan');
INSERT INTO `municipio` VALUES (435,12,59,'Tepecoacuilco de Trujano');
INSERT INTO `municipio` VALUES (436,12,60,'Tetipac');
INSERT INTO `municipio` VALUES (437,12,61,'Tixtla de Guerrero');
INSERT INTO `municipio` VALUES (438,12,62,'Tlacoachistlahuaca');
INSERT INTO `municipio` VALUES (439,12,63,'Tlacoapa');
INSERT INTO `municipio` VALUES (440,12,64,'Tlalchapa');
INSERT INTO `municipio` VALUES (441,12,65,'Tlalixtaquilla de Maldonado');
INSERT INTO `municipio` VALUES (442,12,66,'Tlapa de Comonfort');
INSERT INTO `municipio` VALUES (443,12,67,'Tlapehuala');
INSERT INTO `municipio` VALUES (444,12,68,'La Unión de Isidoro Montes de Oca');
INSERT INTO `municipio` VALUES (445,12,69,'Xalpatláhuac');
INSERT INTO `municipio` VALUES (446,12,70,'Xochihuehuetlán');
INSERT INTO `municipio` VALUES (447,12,71,'Xochistlahuaca');
INSERT INTO `municipio` VALUES (448,12,72,'Zapotitlán Tablas');
INSERT INTO `municipio` VALUES (449,12,73,'Zirándaro');
INSERT INTO `municipio` VALUES (450,12,74,'Zitlala');
INSERT INTO `municipio` VALUES (451,12,75,'Eduardo Neri');
INSERT INTO `municipio` VALUES (452,12,76,'Acatepec');
INSERT INTO `municipio` VALUES (453,12,77,'Marquelia');
INSERT INTO `municipio` VALUES (454,12,78,'Cochoapa el Grande');
INSERT INTO `municipio` VALUES (455,12,79,'José Joaquín de Herrera');
INSERT INTO `municipio` VALUES (456,12,80,'Juchitán');
INSERT INTO `municipio` VALUES (457,12,81,'Iliatenco');
INSERT INTO `municipio` VALUES (458,12,82,'Las Vigas');
INSERT INTO `municipio` VALUES (459,12,83,'Ñuu Savi');
INSERT INTO `municipio` VALUES (460,12,84,'Santa Cruz del Rincón');
INSERT INTO `municipio` VALUES (461,12,85,'San Nicolás');
INSERT INTO `municipio` VALUES (462,13,1,'Acatlán');
INSERT INTO `municipio` VALUES (463,13,2,'Acaxochitlán');
INSERT INTO `municipio` VALUES (464,13,3,'Actopan');
INSERT INTO `municipio` VALUES (465,13,4,'Agua Blanca de Iturbide');
INSERT INTO `municipio` VALUES (466,13,5,'Ajacuba');
INSERT INTO `municipio` VALUES (467,13,6,'Alfajayucan');
INSERT INTO `municipio` VALUES (468,13,7,'Almoloya');
INSERT INTO `municipio` VALUES (469,13,8,'Apan');
INSERT INTO `municipio` VALUES (470,13,9,'El Arenal');
INSERT INTO `municipio` VALUES (471,13,10,'Atitalaquia');
INSERT INTO `municipio` VALUES (472,13,11,'Atlapexco');
INSERT INTO `municipio` VALUES (473,13,12,'Atotonilco el Grande');
INSERT INTO `municipio` VALUES (474,13,13,'Atotonilco de Tula');
INSERT INTO `municipio` VALUES (475,13,14,'Calnali');
INSERT INTO `municipio` VALUES (476,13,15,'Cardonal');
INSERT INTO `municipio` VALUES (477,13,16,'Cuautepec de Hinojosa');
INSERT INTO `municipio` VALUES (478,13,17,'Chapantongo');
INSERT INTO `municipio` VALUES (479,13,18,'Chapulhuacán');
INSERT INTO `municipio` VALUES (480,13,19,'Chilcuautla');
INSERT INTO `municipio` VALUES (481,13,20,'Eloxochitlán');
INSERT INTO `municipio` VALUES (482,13,21,'Emiliano Zapata');
INSERT INTO `municipio` VALUES (483,13,22,'Epazoyucan');
INSERT INTO `municipio` VALUES (484,13,23,'Francisco I. Madero');
INSERT INTO `municipio` VALUES (485,13,24,'Huasca de Ocampo');
INSERT INTO `municipio` VALUES (486,13,25,'Huautla');
INSERT INTO `municipio` VALUES (487,13,26,'Huazalingo');
INSERT INTO `municipio` VALUES (488,13,27,'Huehuetla');
INSERT INTO `municipio` VALUES (489,13,28,'Huejutla de Reyes');
INSERT INTO `municipio` VALUES (490,13,29,'Huichapan');
INSERT INTO `municipio` VALUES (491,13,30,'Ixmiquilpan');
INSERT INTO `municipio` VALUES (492,13,31,'Jacala de Ledezma');
INSERT INTO `municipio` VALUES (493,13,32,'Jaltocán');
INSERT INTO `municipio` VALUES (494,13,33,'Juárez Hidalgo');
INSERT INTO `municipio` VALUES (495,13,34,'Lolotla');
INSERT INTO `municipio` VALUES (496,13,35,'Metepec');
INSERT INTO `municipio` VALUES (497,13,36,'San Agustín Metzquititlán');
INSERT INTO `municipio` VALUES (498,13,37,'Metztitlán');
INSERT INTO `municipio` VALUES (499,13,38,'Mineral del Chico');
INSERT INTO `municipio` VALUES (500,13,39,'Mineral del Monte');
INSERT INTO `municipio` VALUES (501,13,40,'La Misión');
INSERT INTO `municipio` VALUES (502,13,41,'Mixquiahuala de Juárez');
INSERT INTO `municipio` VALUES (503,13,42,'Molango de Escamilla');
INSERT INTO `municipio` VALUES (504,13,43,'Nicolás Flores');
INSERT INTO `municipio` VALUES (505,13,44,'Nopala de Villagrán');
INSERT INTO `municipio` VALUES (506,13,45,'Omitlán de Juárez');
INSERT INTO `municipio` VALUES (507,13,46,'San Felipe Orizatlán');
INSERT INTO `municipio` VALUES (508,13,47,'Pacula');
INSERT INTO `municipio` VALUES (509,13,48,'Pachuca de Soto');
INSERT INTO `municipio` VALUES (510,13,49,'Pisaflores');
INSERT INTO `municipio` VALUES (511,13,50,'Progreso de Obregón');
INSERT INTO `municipio` VALUES (512,13,51,'Mineral de la Reforma');
INSERT INTO `municipio` VALUES (513,13,52,'San Agustín Tlaxiaca');
INSERT INTO `municipio` VALUES (514,13,53,'San Bartolo Tutotepec');
INSERT INTO `municipio` VALUES (515,13,54,'San Salvador');
INSERT INTO `municipio` VALUES (516,13,55,'Santiago de Anaya');
INSERT INTO `municipio` VALUES (517,13,56,'Santiago Tulantepec de Lugo Guerrero');
INSERT INTO `municipio` VALUES (518,13,57,'Singuilucan');
INSERT INTO `municipio` VALUES (519,13,58,'Tasquillo');
INSERT INTO `municipio` VALUES (520,13,59,'Tecozautla');
INSERT INTO `municipio` VALUES (521,13,60,'Tenango de Doria');
INSERT INTO `municipio` VALUES (522,13,61,'Tepeapulco');
INSERT INTO `municipio` VALUES (523,13,62,'Tepehuacán de Guerrero');
INSERT INTO `municipio` VALUES (524,13,63,'Tepeji del Río de Ocampo');
INSERT INTO `municipio` VALUES (525,13,64,'Tepetitlán');
INSERT INTO `municipio` VALUES (526,13,65,'Tetepango');
INSERT INTO `municipio` VALUES (527,13,66,'Villa de Tezontepec');
INSERT INTO `municipio` VALUES (528,13,67,'Tezontepec de Aldama');
INSERT INTO `municipio` VALUES (529,13,68,'Tianguistengo');
INSERT INTO `municipio` VALUES (530,13,69,'Tizayuca');
INSERT INTO `municipio` VALUES (531,13,70,'Tlahuelilpan');
INSERT INTO `municipio` VALUES (532,13,71,'Tlahuiltepa');
INSERT INTO `municipio` VALUES (533,13,72,'Tlanalapa');
INSERT INTO `municipio` VALUES (534,13,73,'Tlanchinol');
INSERT INTO `municipio` VALUES (535,13,74,'Tlaxcoapan');
INSERT INTO `municipio` VALUES (536,13,75,'Tolcayuca');
INSERT INTO `municipio` VALUES (537,13,76,'Tula de Allende');
INSERT INTO `municipio` VALUES (538,13,77,'Tulancingo de Bravo');
INSERT INTO `municipio` VALUES (539,13,78,'Xochiatipan');
INSERT INTO `municipio` VALUES (540,13,79,'Xochicoatlán');
INSERT INTO `municipio` VALUES (541,13,80,'Yahualica');
INSERT INTO `municipio` VALUES (542,13,81,'Zacualtipán de Ángeles');
INSERT INTO `municipio` VALUES (543,13,82,'Zapotlán de Juárez');
INSERT INTO `municipio` VALUES (544,13,83,'Zempoala');
INSERT INTO `municipio` VALUES (545,13,84,'Zimapán');
INSERT INTO `municipio` VALUES (546,14,1,'Acatic');
INSERT INTO `municipio` VALUES (547,14,2,'Acatlán de Juárez');
INSERT INTO `municipio` VALUES (548,14,3,'Ahualulco de Mercado');
INSERT INTO `municipio` VALUES (549,14,4,'Amacueca');
INSERT INTO `municipio` VALUES (550,14,5,'Amatitán');
INSERT INTO `municipio` VALUES (551,14,6,'Ameca');
INSERT INTO `municipio` VALUES (552,14,7,'San Juanito de Escobedo');
INSERT INTO `municipio` VALUES (553,14,8,'Arandas');
INSERT INTO `municipio` VALUES (554,14,9,'El Arenal');
INSERT INTO `municipio` VALUES (555,14,10,'Atemajac de Brizuela');
INSERT INTO `municipio` VALUES (556,14,11,'Atengo');
INSERT INTO `municipio` VALUES (557,14,12,'Atenguillo');
INSERT INTO `municipio` VALUES (558,14,13,'Atotonilco el Alto');
INSERT INTO `municipio` VALUES (559,14,14,'Atoyac');
INSERT INTO `municipio` VALUES (560,14,15,'Autlán de Navarro');
INSERT INTO `municipio` VALUES (561,14,16,'Ayotlán');
INSERT INTO `municipio` VALUES (562,14,17,'Ayutla');
INSERT INTO `municipio` VALUES (563,14,18,'La Barca');
INSERT INTO `municipio` VALUES (564,14,19,'Bolaños');
INSERT INTO `municipio` VALUES (565,14,20,'Cabo Corrientes');
INSERT INTO `municipio` VALUES (566,14,21,'Casimiro Castillo');
INSERT INTO `municipio` VALUES (567,14,22,'Cihuatlán');
INSERT INTO `municipio` VALUES (568,14,23,'Zapotlán el Grande');
INSERT INTO `municipio` VALUES (569,14,24,'Cocula');
INSERT INTO `municipio` VALUES (570,14,25,'Colotlán');
INSERT INTO `municipio` VALUES (571,14,26,'Concepción de Buenos Aires');
INSERT INTO `municipio` VALUES (572,14,27,'Cuautitlán de García Barragán');
INSERT INTO `municipio` VALUES (573,14,28,'Cuautla');
INSERT INTO `municipio` VALUES (574,14,29,'Cuquío');
INSERT INTO `municipio` VALUES (575,14,30,'Chapala');
INSERT INTO `municipio` VALUES (576,14,31,'Chimaltitán');
INSERT INTO `municipio` VALUES (577,14,32,'Chiquilistlán');
INSERT INTO `municipio` VALUES (578,14,33,'Degollado');
INSERT INTO `municipio` VALUES (579,14,34,'Ejutla');
INSERT INTO `municipio` VALUES (580,14,35,'Encarnación de Díaz');
INSERT INTO `municipio` VALUES (581,14,36,'Etzatlán');
INSERT INTO `municipio` VALUES (582,14,37,'El Grullo');
INSERT INTO `municipio` VALUES (583,14,38,'Guachinango');
INSERT INTO `municipio` VALUES (584,14,39,'Guadalajara');
INSERT INTO `municipio` VALUES (585,14,40,'Hostotipaquillo');
INSERT INTO `municipio` VALUES (586,14,41,'Huejúcar');
INSERT INTO `municipio` VALUES (587,14,42,'Huejuquilla el Alto');
INSERT INTO `municipio` VALUES (588,14,43,'La Huerta');
INSERT INTO `municipio` VALUES (589,14,44,'Ixtlahuacán de los Membrillos');
INSERT INTO `municipio` VALUES (590,14,45,'Ixtlahuacán del Río');
INSERT INTO `municipio` VALUES (591,14,46,'Jalostotitlán');
INSERT INTO `municipio` VALUES (592,14,47,'Jamay');
INSERT INTO `municipio` VALUES (593,14,48,'Jesús María');
INSERT INTO `municipio` VALUES (594,14,49,'Jilotlán de los Dolores');
INSERT INTO `municipio` VALUES (595,14,50,'Jocotepec');
INSERT INTO `municipio` VALUES (596,14,51,'Juanacatlán');
INSERT INTO `municipio` VALUES (597,14,52,'Juchitlán');
INSERT INTO `municipio` VALUES (598,14,53,'Lagos de Moreno');
INSERT INTO `municipio` VALUES (599,14,54,'El Limón');
INSERT INTO `municipio` VALUES (600,14,55,'Magdalena');
INSERT INTO `municipio` VALUES (601,14,56,'Santa María del Oro');
INSERT INTO `municipio` VALUES (602,14,57,'La Manzanilla de la Paz');
INSERT INTO `municipio` VALUES (603,14,58,'Mascota');
INSERT INTO `municipio` VALUES (604,14,59,'Mazamitla');
INSERT INTO `municipio` VALUES (605,14,60,'Mexticacán');
INSERT INTO `municipio` VALUES (606,14,61,'Mezquitic');
INSERT INTO `municipio` VALUES (607,14,62,'Mixtlán');
INSERT INTO `municipio` VALUES (608,14,63,'Ocotlán');
INSERT INTO `municipio` VALUES (609,14,64,'Ojuelos de Jalisco');
INSERT INTO `municipio` VALUES (610,14,65,'Pihuamo');
INSERT INTO `municipio` VALUES (611,14,66,'Poncitlán');
INSERT INTO `municipio` VALUES (612,14,67,'Puerto Vallarta');
INSERT INTO `municipio` VALUES (613,14,68,'Villa Purificación');
INSERT INTO `municipio` VALUES (614,14,69,'Quitupan');
INSERT INTO `municipio` VALUES (615,14,70,'El Salto');
INSERT INTO `municipio` VALUES (616,14,71,'San Cristóbal de la Barranca');
INSERT INTO `municipio` VALUES (617,14,72,'San Diego de Alejandría');
INSERT INTO `municipio` VALUES (618,14,73,'San Juan de los Lagos');
INSERT INTO `municipio` VALUES (619,14,74,'San Julián');
INSERT INTO `municipio` VALUES (620,14,75,'San Marcos');
INSERT INTO `municipio` VALUES (621,14,76,'San Martín de Bolaños');
INSERT INTO `municipio` VALUES (622,14,77,'San Martín Hidalgo');
INSERT INTO `municipio` VALUES (623,14,78,'San Miguel el Alto');
INSERT INTO `municipio` VALUES (624,14,79,'Gómez Farías');
INSERT INTO `municipio` VALUES (625,14,80,'San Sebastián del Oeste');
INSERT INTO `municipio` VALUES (626,14,81,'Santa María de los Ángeles');
INSERT INTO `municipio` VALUES (627,14,82,'Sayula');
INSERT INTO `municipio` VALUES (628,14,83,'Tala');
INSERT INTO `municipio` VALUES (629,14,84,'Talpa de Allende');
INSERT INTO `municipio` VALUES (630,14,85,'Tamazula de Gordiano');
INSERT INTO `municipio` VALUES (631,14,86,'Tapalpa');
INSERT INTO `municipio` VALUES (632,14,87,'Tecalitlán');
INSERT INTO `municipio` VALUES (633,14,88,'Tecolotlán');
INSERT INTO `municipio` VALUES (634,14,89,'Techaluta de Montenegro');
INSERT INTO `municipio` VALUES (635,14,90,'Tenamaxtlán');
INSERT INTO `municipio` VALUES (636,14,91,'Teocaltiche');
INSERT INTO `municipio` VALUES (637,14,92,'Teocuitatlán de Corona');
INSERT INTO `municipio` VALUES (638,14,93,'Tepatitlán de Morelos');
INSERT INTO `municipio` VALUES (639,14,94,'Tequila');
INSERT INTO `municipio` VALUES (640,14,95,'Teuchitlán');
INSERT INTO `municipio` VALUES (641,14,96,'Tizapán el Alto');
INSERT INTO `municipio` VALUES (642,14,97,'Tlajomulco de Zúñiga');
INSERT INTO `municipio` VALUES (643,14,98,'San Pedro Tlaquepaque');
INSERT INTO `municipio` VALUES (644,14,99,'Tolimán');
INSERT INTO `municipio` VALUES (645,14,100,'Tomatlán');
INSERT INTO `municipio` VALUES (646,14,101,'Tonalá');
INSERT INTO `municipio` VALUES (647,14,102,'Tonaya');
INSERT INTO `municipio` VALUES (648,14,103,'Tonila');
INSERT INTO `municipio` VALUES (649,14,104,'Totatiche');
INSERT INTO `municipio` VALUES (650,14,105,'Tototlán');
INSERT INTO `municipio` VALUES (651,14,106,'Tuxcacuesco');
INSERT INTO `municipio` VALUES (652,14,107,'Tuxcueca');
INSERT INTO `municipio` VALUES (653,14,108,'Tuxpan');
INSERT INTO `municipio` VALUES (654,14,109,'Unión de San Antonio');
INSERT INTO `municipio` VALUES (655,14,110,'Unión de Tula');
INSERT INTO `municipio` VALUES (656,14,111,'Valle de Guadalupe');
INSERT INTO `municipio` VALUES (657,14,112,'Valle de Juárez');
INSERT INTO `municipio` VALUES (658,14,113,'San Gabriel');
INSERT INTO `municipio` VALUES (659,14,114,'Villa Corona');
INSERT INTO `municipio` VALUES (660,14,115,'Villa Guerrero');
INSERT INTO `municipio` VALUES (661,14,116,'Villa Hidalgo');
INSERT INTO `municipio` VALUES (662,14,117,'Cañadas de Obregón');
INSERT INTO `municipio` VALUES (663,14,118,'Yahualica de González Gallo');
INSERT INTO `municipio` VALUES (664,14,119,'Zacoalco de Torres');
INSERT INTO `municipio` VALUES (665,14,120,'Zapopan');
INSERT INTO `municipio` VALUES (666,14,121,'Zapotiltic');
INSERT INTO `municipio` VALUES (667,14,122,'Zapotitlán de Vadillo');
INSERT INTO `municipio` VALUES (668,14,123,'Zapotlán del Rey');
INSERT INTO `municipio` VALUES (669,14,124,'Zapotlanejo');
INSERT INTO `municipio` VALUES (670,14,125,'San Ignacio Cerro Gordo');
INSERT INTO `municipio` VALUES (671,15,1,'Acambay de Ruíz Castañeda');
INSERT INTO `municipio` VALUES (672,15,2,'Acolman');
INSERT INTO `municipio` VALUES (673,15,3,'Aculco');
INSERT INTO `municipio` VALUES (674,15,4,'Almoloya de Alquisiras');
INSERT INTO `municipio` VALUES (675,15,5,'Almoloya de Juárez');
INSERT INTO `municipio` VALUES (676,15,6,'Almoloya del Río');
INSERT INTO `municipio` VALUES (677,15,7,'Amanalco');
INSERT INTO `municipio` VALUES (678,15,8,'Amatepec');
INSERT INTO `municipio` VALUES (679,15,9,'Amecameca');
INSERT INTO `municipio` VALUES (680,15,10,'Apaxco');
INSERT INTO `municipio` VALUES (681,15,11,'Atenco');
INSERT INTO `municipio` VALUES (682,15,12,'Atizapán');
INSERT INTO `municipio` VALUES (683,15,13,'Atizapán de Zaragoza');
INSERT INTO `municipio` VALUES (684,15,14,'Atlacomulco');
INSERT INTO `municipio` VALUES (685,15,15,'Atlautla');
INSERT INTO `municipio` VALUES (686,15,16,'Axapusco');
INSERT INTO `municipio` VALUES (687,15,17,'Ayapango');
INSERT INTO `municipio` VALUES (688,15,18,'Calimaya');
INSERT INTO `municipio` VALUES (689,15,19,'Capulhuac');
INSERT INTO `municipio` VALUES (690,15,20,'Coacalco de Berriozábal');
INSERT INTO `municipio` VALUES (691,15,21,'Coatepec Harinas');
INSERT INTO `municipio` VALUES (692,15,22,'Cocotitlán');
INSERT INTO `municipio` VALUES (693,15,23,'Coyotepec');
INSERT INTO `municipio` VALUES (694,15,24,'Cuautitlán');
INSERT INTO `municipio` VALUES (695,15,25,'Chalco');
INSERT INTO `municipio` VALUES (696,15,26,'Chapa de Mota');
INSERT INTO `municipio` VALUES (697,15,27,'Chapultepec');
INSERT INTO `municipio` VALUES (698,15,28,'Chiautla');
INSERT INTO `municipio` VALUES (699,15,29,'Chicoloapan');
INSERT INTO `municipio` VALUES (700,15,30,'Chiconcuac');
INSERT INTO `municipio` VALUES (701,15,31,'Chimalhuacán');
INSERT INTO `municipio` VALUES (702,15,32,'Donato Guerra');
INSERT INTO `municipio` VALUES (703,15,33,'Ecatepec de Morelos');
INSERT INTO `municipio` VALUES (704,15,34,'Ecatzingo');
INSERT INTO `municipio` VALUES (705,15,35,'Huehuetoca');
INSERT INTO `municipio` VALUES (706,15,36,'Hueypoxtla');
INSERT INTO `municipio` VALUES (707,15,37,'Huixquilucan');
INSERT INTO `municipio` VALUES (708,15,38,'Isidro Fabela');
INSERT INTO `municipio` VALUES (709,15,39,'Ixtapaluca');
INSERT INTO `municipio` VALUES (710,15,40,'Ixtapan de la Sal');
INSERT INTO `municipio` VALUES (711,15,41,'Ixtapan del Oro');
INSERT INTO `municipio` VALUES (712,15,42,'Ixtlahuaca');
INSERT INTO `municipio` VALUES (713,15,43,'Xalatlaco');
INSERT INTO `municipio` VALUES (714,15,44,'Jaltenco');
INSERT INTO `municipio` VALUES (715,15,45,'Jilotepec');
INSERT INTO `municipio` VALUES (716,15,46,'Jilotzingo');
INSERT INTO `municipio` VALUES (717,15,47,'Jiquipilco');
INSERT INTO `municipio` VALUES (718,15,48,'Jocotitlán');
INSERT INTO `municipio` VALUES (719,15,49,'Joquicingo');
INSERT INTO `municipio` VALUES (720,15,50,'Juchitepec');
INSERT INTO `municipio` VALUES (721,15,51,'Lerma');
INSERT INTO `municipio` VALUES (722,15,52,'Malinalco');
INSERT INTO `municipio` VALUES (723,15,53,'Melchor Ocampo');
INSERT INTO `municipio` VALUES (724,15,54,'Metepec');
INSERT INTO `municipio` VALUES (725,15,55,'Mexicaltzingo');
INSERT INTO `municipio` VALUES (726,15,56,'Morelos');
INSERT INTO `municipio` VALUES (727,15,57,'Naucalpan de Juárez');
INSERT INTO `municipio` VALUES (728,15,58,'Nezahualcóyotl');
INSERT INTO `municipio` VALUES (729,15,59,'Nextlalpan');
INSERT INTO `municipio` VALUES (730,15,60,'Nicolás Romero');
INSERT INTO `municipio` VALUES (731,15,61,'Nopaltepec');
INSERT INTO `municipio` VALUES (732,15,62,'Ocoyoacac');
INSERT INTO `municipio` VALUES (733,15,63,'Ocuilan');
INSERT INTO `municipio` VALUES (734,15,64,'El Oro');
INSERT INTO `municipio` VALUES (735,15,65,'Otumba');
INSERT INTO `municipio` VALUES (736,15,66,'Otzoloapan');
INSERT INTO `municipio` VALUES (737,15,67,'Otzolotepec');
INSERT INTO `municipio` VALUES (738,15,68,'Ozumba');
INSERT INTO `municipio` VALUES (739,15,69,'Papalotla');
INSERT INTO `municipio` VALUES (740,15,70,'La Paz');
INSERT INTO `municipio` VALUES (741,15,71,'Polotitlán');
INSERT INTO `municipio` VALUES (742,15,72,'Rayón');
INSERT INTO `municipio` VALUES (743,15,73,'San Antonio la Isla');
INSERT INTO `municipio` VALUES (744,15,74,'San Felipe del Progreso');
INSERT INTO `municipio` VALUES (745,15,75,'San Martín de las Pirámides');
INSERT INTO `municipio` VALUES (746,15,76,'San Mateo Atenco');
INSERT INTO `municipio` VALUES (747,15,77,'San Simón de Guerrero');
INSERT INTO `municipio` VALUES (748,15,78,'Santo Tomás');
INSERT INTO `municipio` VALUES (749,15,79,'Soyaniquilpan de Juárez');
INSERT INTO `municipio` VALUES (750,15,80,'Sultepec');
INSERT INTO `municipio` VALUES (751,15,81,'Tecámac');
INSERT INTO `municipio` VALUES (752,15,82,'Tejupilco');
INSERT INTO `municipio` VALUES (753,15,83,'Temamatla');
INSERT INTO `municipio` VALUES (754,15,84,'Temascalapa');
INSERT INTO `municipio` VALUES (755,15,85,'Temascalcingo');
INSERT INTO `municipio` VALUES (756,15,86,'Temascaltepec');
INSERT INTO `municipio` VALUES (757,15,87,'Temoaya');
INSERT INTO `municipio` VALUES (758,15,88,'Tenancingo');
INSERT INTO `municipio` VALUES (759,15,89,'Tenango del Aire');
INSERT INTO `municipio` VALUES (760,15,90,'Tenango del Valle');
INSERT INTO `municipio` VALUES (761,15,91,'Teoloyucan');
INSERT INTO `municipio` VALUES (762,15,92,'Teotihuacán');
INSERT INTO `municipio` VALUES (763,15,93,'Tepetlaoxtoc');
INSERT INTO `municipio` VALUES (764,15,94,'Tepetlixpa');
INSERT INTO `municipio` VALUES (765,15,95,'Tepotzotlán');
INSERT INTO `municipio` VALUES (766,15,96,'Tequixquiac');
INSERT INTO `municipio` VALUES (767,15,97,'Texcaltitlán');
INSERT INTO `municipio` VALUES (768,15,98,'Texcalyacac');
INSERT INTO `municipio` VALUES (769,15,99,'Texcoco');
INSERT INTO `municipio` VALUES (770,15,100,'Tezoyuca');
INSERT INTO `municipio` VALUES (771,15,101,'Tianguistenco');
INSERT INTO `municipio` VALUES (772,15,102,'Timilpan');
INSERT INTO `municipio` VALUES (773,15,103,'Tlalmanalco');
INSERT INTO `municipio` VALUES (774,15,104,'Tlalnepantla de Baz');
INSERT INTO `municipio` VALUES (775,15,105,'Tlatlaya');
INSERT INTO `municipio` VALUES (776,15,106,'Toluca');
INSERT INTO `municipio` VALUES (777,15,107,'Tonatico');
INSERT INTO `municipio` VALUES (778,15,108,'Tultepec');
INSERT INTO `municipio` VALUES (779,15,109,'Tultitlán');
INSERT INTO `municipio` VALUES (780,15,110,'Valle de Bravo');
INSERT INTO `municipio` VALUES (781,15,111,'Villa de Allende');
INSERT INTO `municipio` VALUES (782,15,112,'Villa del Carbón');
INSERT INTO `municipio` VALUES (783,15,113,'Villa Guerrero');
INSERT INTO `municipio` VALUES (784,15,114,'Villa Victoria');
INSERT INTO `municipio` VALUES (785,15,115,'Xonacatlán');
INSERT INTO `municipio` VALUES (786,15,116,'Zacazonapan');
INSERT INTO `municipio` VALUES (787,15,117,'Zacualpan');
INSERT INTO `municipio` VALUES (788,15,118,'Zinacantepec');
INSERT INTO `municipio` VALUES (789,15,119,'Zumpahuacán');
INSERT INTO `municipio` VALUES (790,15,120,'Zumpango');
INSERT INTO `municipio` VALUES (791,15,121,'Cuautitlán Izcalli');
INSERT INTO `municipio` VALUES (792,15,122,'Valle de Chalco Solidaridad');
INSERT INTO `municipio` VALUES (793,15,123,'Luvianos');
INSERT INTO `municipio` VALUES (794,15,124,'San José del Rincón');
INSERT INTO `municipio` VALUES (795,15,125,'Tonanitla');
INSERT INTO `municipio` VALUES (796,16,1,'Acuitzio');
INSERT INTO `municipio` VALUES (797,16,2,'Aguililla');
INSERT INTO `municipio` VALUES (798,16,3,'Álvaro Obregón');
INSERT INTO `municipio` VALUES (799,16,4,'Angamacutiro');
INSERT INTO `municipio` VALUES (800,16,5,'Angangueo');
INSERT INTO `municipio` VALUES (801,16,6,'Apatzingán');
INSERT INTO `municipio` VALUES (802,16,7,'Aporo');
INSERT INTO `municipio` VALUES (803,16,8,'Aquila');
INSERT INTO `municipio` VALUES (804,16,9,'Ario');
INSERT INTO `municipio` VALUES (805,16,10,'Arteaga');
INSERT INTO `municipio` VALUES (806,16,11,'Briseñas');
INSERT INTO `municipio` VALUES (807,16,12,'Buenavista');
INSERT INTO `municipio` VALUES (808,16,13,'Carácuaro');
INSERT INTO `municipio` VALUES (809,16,14,'Coahuayana');
INSERT INTO `municipio` VALUES (810,16,15,'Coalcomán de Vázquez Pallares');
INSERT INTO `municipio` VALUES (811,16,16,'Coeneo');
INSERT INTO `municipio` VALUES (812,16,17,'Contepec');
INSERT INTO `municipio` VALUES (813,16,18,'Copándaro');
INSERT INTO `municipio` VALUES (814,16,19,'Cotija');
INSERT INTO `municipio` VALUES (815,16,20,'Cuitzeo');
INSERT INTO `municipio` VALUES (816,16,21,'Charapan');
INSERT INTO `municipio` VALUES (817,16,22,'Charo');
INSERT INTO `municipio` VALUES (818,16,23,'Chavinda');
INSERT INTO `municipio` VALUES (819,16,24,'Cherán');
INSERT INTO `municipio` VALUES (820,16,25,'Chilchota');
INSERT INTO `municipio` VALUES (821,16,26,'Chinicuila');
INSERT INTO `municipio` VALUES (822,16,27,'Chucándiro');
INSERT INTO `municipio` VALUES (823,16,28,'Churintzio');
INSERT INTO `municipio` VALUES (824,16,29,'Churumuco');
INSERT INTO `municipio` VALUES (825,16,30,'Ecuandureo');
INSERT INTO `municipio` VALUES (826,16,31,'Epitacio Huerta');
INSERT INTO `municipio` VALUES (827,16,32,'Erongarícuaro');
INSERT INTO `municipio` VALUES (828,16,33,'Gabriel Zamora');
INSERT INTO `municipio` VALUES (829,16,34,'Hidalgo');
INSERT INTO `municipio` VALUES (830,16,35,'La Huacana');
INSERT INTO `municipio` VALUES (831,16,36,'Huandacareo');
INSERT INTO `municipio` VALUES (832,16,37,'Huaniqueo');
INSERT INTO `municipio` VALUES (833,16,38,'Huetamo');
INSERT INTO `municipio` VALUES (834,16,39,'Huiramba');
INSERT INTO `municipio` VALUES (835,16,40,'Indaparapeo');
INSERT INTO `municipio` VALUES (836,16,41,'Irimbo');
INSERT INTO `municipio` VALUES (837,16,42,'Ixtlán');
INSERT INTO `municipio` VALUES (838,16,43,'Jacona');
INSERT INTO `municipio` VALUES (839,16,44,'Jiménez');
INSERT INTO `municipio` VALUES (840,16,45,'Jiquilpan');
INSERT INTO `municipio` VALUES (841,16,46,'Juárez');
INSERT INTO `municipio` VALUES (842,16,47,'Jungapeo');
INSERT INTO `municipio` VALUES (843,16,48,'Lagunillas');
INSERT INTO `municipio` VALUES (844,16,49,'Madero');
INSERT INTO `municipio` VALUES (845,16,50,'Maravatío');
INSERT INTO `municipio` VALUES (846,16,51,'Marcos Castellanos');
INSERT INTO `municipio` VALUES (847,16,52,'Lázaro Cárdenas');
INSERT INTO `municipio` VALUES (848,16,53,'Morelia');
INSERT INTO `municipio` VALUES (849,16,54,'Morelos');
INSERT INTO `municipio` VALUES (850,16,55,'Múgica');
INSERT INTO `municipio` VALUES (851,16,56,'Nahuatzen');
INSERT INTO `municipio` VALUES (852,16,57,'Nocupétaro');
INSERT INTO `municipio` VALUES (853,16,58,'Nuevo Parangaricutiro');
INSERT INTO `municipio` VALUES (854,16,59,'Nuevo Urecho');
INSERT INTO `municipio` VALUES (855,16,60,'Numarán');
INSERT INTO `municipio` VALUES (856,16,61,'Ocampo');
INSERT INTO `municipio` VALUES (857,16,62,'Pajacuarán');
INSERT INTO `municipio` VALUES (858,16,63,'Panindícuaro');
INSERT INTO `municipio` VALUES (859,16,64,'Parácuaro');
INSERT INTO `municipio` VALUES (860,16,65,'Paracho');
INSERT INTO `municipio` VALUES (861,16,66,'Pátzcuaro');
INSERT INTO `municipio` VALUES (862,16,67,'Penjamillo');
INSERT INTO `municipio` VALUES (863,16,68,'Peribán');
INSERT INTO `municipio` VALUES (864,16,69,'La Piedad');
INSERT INTO `municipio` VALUES (865,16,70,'Purépero');
INSERT INTO `municipio` VALUES (866,16,71,'Puruándiro');
INSERT INTO `municipio` VALUES (867,16,72,'Queréndaro');
INSERT INTO `municipio` VALUES (868,16,73,'Quiroga');
INSERT INTO `municipio` VALUES (869,16,74,'Cojumatlán de Régules');
INSERT INTO `municipio` VALUES (870,16,75,'Los Reyes');
INSERT INTO `municipio` VALUES (871,16,76,'Sahuayo');
INSERT INTO `municipio` VALUES (872,16,77,'San Lucas');
INSERT INTO `municipio` VALUES (873,16,78,'Santa Ana Maya');
INSERT INTO `municipio` VALUES (874,16,79,'Salvador Escalante');
INSERT INTO `municipio` VALUES (875,16,80,'Senguio');
INSERT INTO `municipio` VALUES (876,16,81,'Susupuato');
INSERT INTO `municipio` VALUES (877,16,82,'Tacámbaro');
INSERT INTO `municipio` VALUES (878,16,83,'Tancítaro');
INSERT INTO `municipio` VALUES (879,16,84,'Tangamandapio');
INSERT INTO `municipio` VALUES (880,16,85,'Tangancícuaro');
INSERT INTO `municipio` VALUES (881,16,86,'Tanhuato');
INSERT INTO `municipio` VALUES (882,16,87,'Taretan');
INSERT INTO `municipio` VALUES (883,16,88,'Tarímbaro');
INSERT INTO `municipio` VALUES (884,16,89,'Tepalcatepec');
INSERT INTO `municipio` VALUES (885,16,90,'Tingambato');
INSERT INTO `municipio` VALUES (886,16,91,'Tingüindín');
INSERT INTO `municipio` VALUES (887,16,92,'Tiquicheo de Nicolás Romero');
INSERT INTO `municipio` VALUES (888,16,93,'Tlalpujahua');
INSERT INTO `municipio` VALUES (889,16,94,'Tlazazalca');
INSERT INTO `municipio` VALUES (890,16,95,'Tocumbo');
INSERT INTO `municipio` VALUES (891,16,96,'Tumbiscatío');
INSERT INTO `municipio` VALUES (892,16,97,'Turicato');
INSERT INTO `municipio` VALUES (893,16,98,'Tuxpan');
INSERT INTO `municipio` VALUES (894,16,99,'Tuzantla');
INSERT INTO `municipio` VALUES (895,16,100,'Tzintzuntzan');
INSERT INTO `municipio` VALUES (896,16,101,'Tzitzio');
INSERT INTO `municipio` VALUES (897,16,102,'Uruapan');
INSERT INTO `municipio` VALUES (898,16,103,'Venustiano Carranza');
INSERT INTO `municipio` VALUES (899,16,104,'Villamar');
INSERT INTO `municipio` VALUES (900,16,105,'Vista Hermosa');
INSERT INTO `municipio` VALUES (901,16,106,'Yurécuaro');
INSERT INTO `municipio` VALUES (902,16,107,'Zacapu');
INSERT INTO `municipio` VALUES (903,16,108,'Zamora');
INSERT INTO `municipio` VALUES (904,16,109,'Zináparo');
INSERT INTO `municipio` VALUES (905,16,110,'Zinapécuaro');
INSERT INTO `municipio` VALUES (906,16,111,'Ziracuaretiro');
INSERT INTO `municipio` VALUES (907,16,112,'Zitácuaro');
INSERT INTO `municipio` VALUES (908,16,113,'José Sixto Verduzco');
INSERT INTO `municipio` VALUES (909,17,1,'Amacuzac');
INSERT INTO `municipio` VALUES (910,17,2,'Atlatlahucan');
INSERT INTO `municipio` VALUES (911,17,3,'Axochiapan');
INSERT INTO `municipio` VALUES (912,17,4,'Ayala');
INSERT INTO `municipio` VALUES (913,17,5,'Coatlán del Río');
INSERT INTO `municipio` VALUES (914,17,6,'Cuautla');
INSERT INTO `municipio` VALUES (915,17,7,'Cuernavaca');
INSERT INTO `municipio` VALUES (916,17,8,'Emiliano Zapata');
INSERT INTO `municipio` VALUES (917,17,9,'Huitzilac');
INSERT INTO `municipio` VALUES (918,17,10,'Jantetelco');
INSERT INTO `municipio` VALUES (919,17,11,'Jiutepec');
INSERT INTO `municipio` VALUES (920,17,12,'Jojutla');
INSERT INTO `municipio` VALUES (921,17,13,'Jonacatepec de Leandro Valle');
INSERT INTO `municipio` VALUES (922,17,14,'Mazatepec');
INSERT INTO `municipio` VALUES (923,17,15,'Miacatlán');
INSERT INTO `municipio` VALUES (924,17,16,'Ocuituco');
INSERT INTO `municipio` VALUES (925,17,17,'Puente de Ixtla');
INSERT INTO `municipio` VALUES (926,17,18,'Temixco');
INSERT INTO `municipio` VALUES (927,17,19,'Tepalcingo');
INSERT INTO `municipio` VALUES (928,17,20,'Tepoztlán');
INSERT INTO `municipio` VALUES (929,17,21,'Tetecala');
INSERT INTO `municipio` VALUES (930,17,22,'Tetela del Volcán');
INSERT INTO `municipio` VALUES (931,17,23,'Tlalnepantla');
INSERT INTO `municipio` VALUES (932,17,24,'Tlaltizapán de Zapata');
INSERT INTO `municipio` VALUES (933,17,25,'Tlaquiltenango');
INSERT INTO `municipio` VALUES (934,17,26,'Tlayacapan');
INSERT INTO `municipio` VALUES (935,17,27,'Totolapan');
INSERT INTO `municipio` VALUES (936,17,28,'Xochitepec');
INSERT INTO `municipio` VALUES (937,17,29,'Yautepec');
INSERT INTO `municipio` VALUES (938,17,30,'Yecapixtla');
INSERT INTO `municipio` VALUES (939,17,31,'Zacatepec');
INSERT INTO `municipio` VALUES (940,17,32,'Zacualpan de Amilpas');
INSERT INTO `municipio` VALUES (941,17,33,'Temoac');
INSERT INTO `municipio` VALUES (942,17,34,'Coatetelco');
INSERT INTO `municipio` VALUES (943,17,35,'Xoxocotla');
INSERT INTO `municipio` VALUES (944,17,36,'Hueyapan');
INSERT INTO `municipio` VALUES (945,18,1,'Acaponeta');
INSERT INTO `municipio` VALUES (946,18,2,'Ahuacatlán');
INSERT INTO `municipio` VALUES (947,18,3,'Amatlán de Cañas');
INSERT INTO `municipio` VALUES (948,18,4,'Compostela');
INSERT INTO `municipio` VALUES (949,18,5,'Huajicori');
INSERT INTO `municipio` VALUES (950,18,6,'Ixtlán del Río');
INSERT INTO `municipio` VALUES (951,18,7,'Jala');
INSERT INTO `municipio` VALUES (952,18,8,'Xalisco');
INSERT INTO `municipio` VALUES (953,18,9,'Del Nayar');
INSERT INTO `municipio` VALUES (954,18,10,'Rosamorada');
INSERT INTO `municipio` VALUES (955,18,11,'Ruiz');
INSERT INTO `municipio` VALUES (956,18,12,'San Blas');
INSERT INTO `municipio` VALUES (957,18,13,'San Pedro Lagunillas');
INSERT INTO `municipio` VALUES (958,18,14,'Santa María del Oro');
INSERT INTO `municipio` VALUES (959,18,15,'Santiago Ixcuintla');
INSERT INTO `municipio` VALUES (960,18,16,'Tecuala');
INSERT INTO `municipio` VALUES (961,18,17,'Tepic');
INSERT INTO `municipio` VALUES (962,18,18,'Tuxpan');
INSERT INTO `municipio` VALUES (963,18,19,'La Yesca');
INSERT INTO `municipio` VALUES (964,18,20,'Bahía de Banderas');
INSERT INTO `municipio` VALUES (965,19,1,'Abasolo');
INSERT INTO `municipio` VALUES (966,19,2,'Agualeguas');
INSERT INTO `municipio` VALUES (967,19,3,'Los Aldamas');
INSERT INTO `municipio` VALUES (968,19,4,'Allende');
INSERT INTO `municipio` VALUES (969,19,5,'Anáhuac');
INSERT INTO `municipio` VALUES (970,19,6,'Apodaca');
INSERT INTO `municipio` VALUES (971,19,7,'Aramberri');
INSERT INTO `municipio` VALUES (972,19,8,'Bustamante');
INSERT INTO `municipio` VALUES (973,19,9,'Cadereyta Jiménez');
INSERT INTO `municipio` VALUES (974,19,10,'El Carmen');
INSERT INTO `municipio` VALUES (975,19,11,'Cerralvo');
INSERT INTO `municipio` VALUES (976,19,12,'Ciénega de Flores');
INSERT INTO `municipio` VALUES (977,19,13,'China');
INSERT INTO `municipio` VALUES (978,19,14,'Doctor Arroyo');
INSERT INTO `municipio` VALUES (979,19,15,'Doctor Coss');
INSERT INTO `municipio` VALUES (980,19,16,'Doctor González');
INSERT INTO `municipio` VALUES (981,19,17,'Galeana');
INSERT INTO `municipio` VALUES (982,19,18,'García');
INSERT INTO `municipio` VALUES (983,19,19,'San Pedro Garza García');
INSERT INTO `municipio` VALUES (984,19,20,'General Bravo');
INSERT INTO `municipio` VALUES (985,19,21,'General Escobedo');
INSERT INTO `municipio` VALUES (986,19,22,'General Terán');
INSERT INTO `municipio` VALUES (987,19,23,'General Treviño');
INSERT INTO `municipio` VALUES (988,19,24,'General Zaragoza');
INSERT INTO `municipio` VALUES (989,19,25,'General Zuazua');
INSERT INTO `municipio` VALUES (990,19,26,'Guadalupe');
INSERT INTO `municipio` VALUES (991,19,27,'Los Herreras');
INSERT INTO `municipio` VALUES (992,19,28,'Higueras');
INSERT INTO `municipio` VALUES (993,19,29,'Hualahuises');
INSERT INTO `municipio` VALUES (994,19,30,'Iturbide');
INSERT INTO `municipio` VALUES (995,19,31,'Juárez');
INSERT INTO `municipio` VALUES (996,19,32,'Lampazos de Naranjo');
INSERT INTO `municipio` VALUES (997,19,33,'Linares');
INSERT INTO `municipio` VALUES (998,19,34,'Marín');
INSERT INTO `municipio` VALUES (999,19,35,'Melchor Ocampo');
INSERT INTO `municipio` VALUES (1000,19,36,'Mier y Noriega');
INSERT INTO `municipio` VALUES (1001,19,37,'Mina');
INSERT INTO `municipio` VALUES (1002,19,38,'Montemorelos');
INSERT INTO `municipio` VALUES (1003,19,39,'Monterrey');
INSERT INTO `municipio` VALUES (1004,19,40,'Parás');
INSERT INTO `municipio` VALUES (1005,19,41,'Pesquería');
INSERT INTO `municipio` VALUES (1006,19,42,'Los Ramones');
INSERT INTO `municipio` VALUES (1007,19,43,'Rayones');
INSERT INTO `municipio` VALUES (1008,19,44,'Sabinas Hidalgo');
INSERT INTO `municipio` VALUES (1009,19,45,'Salinas Victoria');
INSERT INTO `municipio` VALUES (1010,19,46,'San Nicolás de los Garza');
INSERT INTO `municipio` VALUES (1011,19,47,'Hidalgo');
INSERT INTO `municipio` VALUES (1012,19,48,'Santa Catarina');
INSERT INTO `municipio` VALUES (1013,19,49,'Santiago');
INSERT INTO `municipio` VALUES (1014,19,50,'Vallecillo');
INSERT INTO `municipio` VALUES (1015,19,51,'Villaldama');
INSERT INTO `municipio` VALUES (1016,20,1,'Abejones');
INSERT INTO `municipio` VALUES (1017,20,2,'Acatlán de Pérez Figueroa');
INSERT INTO `municipio` VALUES (1018,20,3,'Asunción Cacalotepec');
INSERT INTO `municipio` VALUES (1019,20,4,'Asunción Cuyotepeji');
INSERT INTO `municipio` VALUES (1020,20,5,'Asunción Ixtaltepec');
INSERT INTO `municipio` VALUES (1021,20,6,'Asunción Nochixtlán');
INSERT INTO `municipio` VALUES (1022,20,7,'Asunción Ocotlán');
INSERT INTO `municipio` VALUES (1023,20,8,'Asunción Tlacolulita');
INSERT INTO `municipio` VALUES (1024,20,9,'Ayotzintepec');
INSERT INTO `municipio` VALUES (1025,20,10,'El Barrio de la Soledad');
INSERT INTO `municipio` VALUES (1026,20,11,'Calihualá');
INSERT INTO `municipio` VALUES (1027,20,12,'Candelaria Loxicha');
INSERT INTO `municipio` VALUES (1028,20,13,'Ciénega de Zimatlán');
INSERT INTO `municipio` VALUES (1029,20,14,'Ciudad Ixtepec');
INSERT INTO `municipio` VALUES (1030,20,15,'Coatecas Altas');
INSERT INTO `municipio` VALUES (1031,20,16,'Coicoyán de las Flores');
INSERT INTO `municipio` VALUES (1032,20,17,'La Compañía');
INSERT INTO `municipio` VALUES (1033,20,18,'Concepción Buenavista');
INSERT INTO `municipio` VALUES (1034,20,19,'Concepción Pápalo');
INSERT INTO `municipio` VALUES (1035,20,20,'Constancia del Rosario');
INSERT INTO `municipio` VALUES (1036,20,21,'Cosolapa');
INSERT INTO `municipio` VALUES (1037,20,22,'Cosoltepec');
INSERT INTO `municipio` VALUES (1038,20,23,'Cuilápam de Guerrero');
INSERT INTO `municipio` VALUES (1039,20,24,'Cuyamecalco Villa de Zaragoza');
INSERT INTO `municipio` VALUES (1040,20,25,'Chahuites');
INSERT INTO `municipio` VALUES (1041,20,26,'Chalcatongo de Hidalgo');
INSERT INTO `municipio` VALUES (1042,20,27,'Chiquihuitlán de Benito Juárez');
INSERT INTO `municipio` VALUES (1043,20,28,'Heroica Ciudad de Ejutla de Crespo');
INSERT INTO `municipio` VALUES (1044,20,29,'Eloxochitlán de Flores Magón');
INSERT INTO `municipio` VALUES (1045,20,30,'El Espinal');
INSERT INTO `municipio` VALUES (1046,20,31,'Tamazulápam del Espíritu Santo');
INSERT INTO `municipio` VALUES (1047,20,32,'Fresnillo de Trujano');
INSERT INTO `municipio` VALUES (1048,20,33,'Guadalupe Etla');
INSERT INTO `municipio` VALUES (1049,20,34,'Guadalupe de Ramírez');
INSERT INTO `municipio` VALUES (1050,20,35,'Guelatao de Juárez');
INSERT INTO `municipio` VALUES (1051,20,36,'Guevea de Humboldt');
INSERT INTO `municipio` VALUES (1052,20,37,'Mesones Hidalgo');
INSERT INTO `municipio` VALUES (1053,20,38,'Villa Hidalgo Yalálag');
INSERT INTO `municipio` VALUES (1054,20,39,'Heroica Ciudad de Huajuapan de León');
INSERT INTO `municipio` VALUES (1055,20,40,'Huautepec');
INSERT INTO `municipio` VALUES (1056,20,41,'Huautla de Jiménez');
INSERT INTO `municipio` VALUES (1057,20,42,'Ixtlán de Juárez');
INSERT INTO `municipio` VALUES (1058,20,43,'Heroica Ciudad de Juchitán de Zaragoza');
INSERT INTO `municipio` VALUES (1059,20,44,'Loma Bonita');
INSERT INTO `municipio` VALUES (1060,20,45,'Magdalena Apazco');
INSERT INTO `municipio` VALUES (1061,20,46,'Magdalena Jaltepec');
INSERT INTO `municipio` VALUES (1062,20,47,'Santa Magdalena Jicotlán');
INSERT INTO `municipio` VALUES (1063,20,48,'Magdalena Mixtepec');
INSERT INTO `municipio` VALUES (1064,20,49,'Magdalena Ocotlán');
INSERT INTO `municipio` VALUES (1065,20,50,'Magdalena Peñasco');
INSERT INTO `municipio` VALUES (1066,20,51,'Magdalena Teitipac');
INSERT INTO `municipio` VALUES (1067,20,52,'Magdalena Tequisistlán');
INSERT INTO `municipio` VALUES (1068,20,53,'Magdalena Tlacotepec');
INSERT INTO `municipio` VALUES (1069,20,54,'Magdalena Zahuatlán');
INSERT INTO `municipio` VALUES (1070,20,55,'Mariscala de Juárez');
INSERT INTO `municipio` VALUES (1071,20,56,'Mártires de Tacubaya');
INSERT INTO `municipio` VALUES (1072,20,57,'Matías Romero Avendaño');
INSERT INTO `municipio` VALUES (1073,20,58,'Mazatlán Villa de Flores');
INSERT INTO `municipio` VALUES (1074,20,59,'Heroica Ciudad de Miahuatlán de Porfirio Díaz');
INSERT INTO `municipio` VALUES (1075,20,60,'Mixistlán de la Reforma');
INSERT INTO `municipio` VALUES (1076,20,61,'Monjas');
INSERT INTO `municipio` VALUES (1077,20,62,'Natividad');
INSERT INTO `municipio` VALUES (1078,20,63,'Nazareno Etla');
INSERT INTO `municipio` VALUES (1079,20,64,'Nejapa de Madero');
INSERT INTO `municipio` VALUES (1080,20,65,'Ixpantepec Nieves');
INSERT INTO `municipio` VALUES (1081,20,66,'Santiago Niltepec');
INSERT INTO `municipio` VALUES (1082,20,67,'Oaxaca de Juárez');
INSERT INTO `municipio` VALUES (1083,20,68,'Ocotlán de Morelos');
INSERT INTO `municipio` VALUES (1084,20,69,'La Pe');
INSERT INTO `municipio` VALUES (1085,20,70,'Pinotepa de Don Luis');
INSERT INTO `municipio` VALUES (1086,20,71,'Pluma Hidalgo');
INSERT INTO `municipio` VALUES (1087,20,72,'San José del Progreso');
INSERT INTO `municipio` VALUES (1088,20,73,'Putla Villa de Guerrero');
INSERT INTO `municipio` VALUES (1089,20,74,'Santa Catarina Quioquitani');
INSERT INTO `municipio` VALUES (1090,20,75,'Reforma de Pineda');
INSERT INTO `municipio` VALUES (1091,20,76,'La Reforma');
INSERT INTO `municipio` VALUES (1092,20,77,'Reyes Etla');
INSERT INTO `municipio` VALUES (1093,20,78,'Rojas de Cuauhtémoc');
INSERT INTO `municipio` VALUES (1094,20,79,'Salina Cruz');
INSERT INTO `municipio` VALUES (1095,20,80,'San Agustín Amatengo');
INSERT INTO `municipio` VALUES (1096,20,81,'San Agustín Atenango');
INSERT INTO `municipio` VALUES (1097,20,82,'San Agustín Chayuco');
INSERT INTO `municipio` VALUES (1098,20,83,'San Agustín de las Juntas');
INSERT INTO `municipio` VALUES (1099,20,84,'San Agustín Etla');
INSERT INTO `municipio` VALUES (1100,20,85,'San Agustín Loxicha');
INSERT INTO `municipio` VALUES (1101,20,86,'San Agustín Tlacotepec');
INSERT INTO `municipio` VALUES (1102,20,87,'San Agustín Yatareni');
INSERT INTO `municipio` VALUES (1103,20,88,'San Andrés Cabecera Nueva');
INSERT INTO `municipio` VALUES (1104,20,89,'San Andrés Dinicuiti');
INSERT INTO `municipio` VALUES (1105,20,90,'San Andrés Huaxpaltepec');
INSERT INTO `municipio` VALUES (1106,20,91,'San Andrés Huayápam');
INSERT INTO `municipio` VALUES (1107,20,92,'San Andrés Ixtlahuaca');
INSERT INTO `municipio` VALUES (1108,20,93,'San Andrés Lagunas');
INSERT INTO `municipio` VALUES (1109,20,94,'San Andrés Nuxiño');
INSERT INTO `municipio` VALUES (1110,20,95,'San Andrés Paxtlán');
INSERT INTO `municipio` VALUES (1111,20,96,'San Andrés Sinaxtla');
INSERT INTO `municipio` VALUES (1112,20,97,'San Andrés Solaga');
INSERT INTO `municipio` VALUES (1113,20,98,'San Andrés Teotilálpam');
INSERT INTO `municipio` VALUES (1114,20,99,'San Andrés Tepetlapa');
INSERT INTO `municipio` VALUES (1115,20,100,'San Andrés Yaá');
INSERT INTO `municipio` VALUES (1116,20,101,'San Andrés Zabache');
INSERT INTO `municipio` VALUES (1117,20,102,'San Andrés Zautla');
INSERT INTO `municipio` VALUES (1118,20,103,'San Antonino Castillo Velasco');
INSERT INTO `municipio` VALUES (1119,20,104,'San Antonino el Alto');
INSERT INTO `municipio` VALUES (1120,20,105,'San Antonino Monte Verde');
INSERT INTO `municipio` VALUES (1121,20,106,'San Antonio Acutla');
INSERT INTO `municipio` VALUES (1122,20,107,'San Antonio de la Cal');
INSERT INTO `municipio` VALUES (1123,20,108,'San Antonio Huitepec');
INSERT INTO `municipio` VALUES (1124,20,109,'San Antonio Nanahuatípam');
INSERT INTO `municipio` VALUES (1125,20,110,'San Antonio Sinicahua');
INSERT INTO `municipio` VALUES (1126,20,111,'San Antonio Tepetlapa');
INSERT INTO `municipio` VALUES (1127,20,112,'San Baltazar Chichicápam');
INSERT INTO `municipio` VALUES (1128,20,113,'San Baltazar Loxicha');
INSERT INTO `municipio` VALUES (1129,20,114,'San Baltazar Yatzachi el Bajo');
INSERT INTO `municipio` VALUES (1130,20,115,'San Bartolo Coyotepec');
INSERT INTO `municipio` VALUES (1131,20,116,'San Bartolomé Ayautla');
INSERT INTO `municipio` VALUES (1132,20,117,'San Bartolomé Loxicha');
INSERT INTO `municipio` VALUES (1133,20,118,'San Bartolomé Quialana');
INSERT INTO `municipio` VALUES (1134,20,119,'San Bartolomé Yucuañe');
INSERT INTO `municipio` VALUES (1135,20,120,'San Bartolomé Zoogocho');
INSERT INTO `municipio` VALUES (1136,20,121,'San Bartolo Soyaltepec');
INSERT INTO `municipio` VALUES (1137,20,122,'San Bartolo Yautepec');
INSERT INTO `municipio` VALUES (1138,20,123,'San Bernardo Mixtepec');
INSERT INTO `municipio` VALUES (1139,20,124,'Heroica Villa de San Blas Atempa');
INSERT INTO `municipio` VALUES (1140,20,125,'San Carlos Yautepec');
INSERT INTO `municipio` VALUES (1141,20,126,'San Cristóbal Amatlán');
INSERT INTO `municipio` VALUES (1142,20,127,'San Cristóbal Amoltepec');
INSERT INTO `municipio` VALUES (1143,20,128,'San Cristóbal Lachirioag');
INSERT INTO `municipio` VALUES (1144,20,129,'San Cristóbal Suchixtlahuaca');
INSERT INTO `municipio` VALUES (1145,20,130,'San Dionisio del Mar');
INSERT INTO `municipio` VALUES (1146,20,131,'San Dionisio Ocotepec');
INSERT INTO `municipio` VALUES (1147,20,132,'San Dionisio Ocotlán');
INSERT INTO `municipio` VALUES (1148,20,133,'San Esteban Atatlahuca');
INSERT INTO `municipio` VALUES (1149,20,134,'San Felipe Jalapa de Díaz');
INSERT INTO `municipio` VALUES (1150,20,135,'San Felipe Tejalápam');
INSERT INTO `municipio` VALUES (1151,20,136,'San Felipe Usila');
INSERT INTO `municipio` VALUES (1152,20,137,'San Francisco Cahuacuá');
INSERT INTO `municipio` VALUES (1153,20,138,'San Francisco Cajonos');
INSERT INTO `municipio` VALUES (1154,20,139,'San Francisco Chapulapa');
INSERT INTO `municipio` VALUES (1155,20,140,'San Francisco Chindúa');
INSERT INTO `municipio` VALUES (1156,20,141,'San Francisco del Mar');
INSERT INTO `municipio` VALUES (1157,20,142,'San Francisco Huehuetlán');
INSERT INTO `municipio` VALUES (1158,20,143,'San Francisco Ixhuatán');
INSERT INTO `municipio` VALUES (1159,20,144,'San Francisco Jaltepetongo');
INSERT INTO `municipio` VALUES (1160,20,145,'San Francisco Lachigoló');
INSERT INTO `municipio` VALUES (1161,20,146,'San Francisco Logueche');
INSERT INTO `municipio` VALUES (1162,20,147,'San Francisco Nuxaño');
INSERT INTO `municipio` VALUES (1163,20,148,'San Francisco Ozolotepec');
INSERT INTO `municipio` VALUES (1164,20,149,'San Francisco Sola');
INSERT INTO `municipio` VALUES (1165,20,150,'San Francisco Telixtlahuaca');
INSERT INTO `municipio` VALUES (1166,20,151,'San Francisco Teopan');
INSERT INTO `municipio` VALUES (1167,20,152,'San Francisco Tlapancingo');
INSERT INTO `municipio` VALUES (1168,20,153,'San Gabriel Mixtepec');
INSERT INTO `municipio` VALUES (1169,20,154,'San Ildefonso Amatlán');
INSERT INTO `municipio` VALUES (1170,20,155,'San Ildefonso Sola');
INSERT INTO `municipio` VALUES (1171,20,156,'San Ildefonso Villa Alta');
INSERT INTO `municipio` VALUES (1172,20,157,'San Jacinto Amilpas');
INSERT INTO `municipio` VALUES (1173,20,158,'San Jacinto Tlacotepec');
INSERT INTO `municipio` VALUES (1174,20,159,'San Jerónimo Coatlán');
INSERT INTO `municipio` VALUES (1175,20,160,'San Jerónimo Silacayoapilla');
INSERT INTO `municipio` VALUES (1176,20,161,'San Jerónimo Sosola');
INSERT INTO `municipio` VALUES (1177,20,162,'San Jerónimo Taviche');
INSERT INTO `municipio` VALUES (1178,20,163,'San Jerónimo Tecóatl');
INSERT INTO `municipio` VALUES (1179,20,164,'San Jorge Nuchita');
INSERT INTO `municipio` VALUES (1180,20,165,'San José Ayuquila');
INSERT INTO `municipio` VALUES (1181,20,166,'San José Chiltepec');
INSERT INTO `municipio` VALUES (1182,20,167,'San José del Peñasco');
INSERT INTO `municipio` VALUES (1183,20,168,'San José Estancia Grande');
INSERT INTO `municipio` VALUES (1184,20,169,'San José Independencia');
INSERT INTO `municipio` VALUES (1185,20,170,'San José Lachiguiri');
INSERT INTO `municipio` VALUES (1186,20,171,'San José Tenango');
INSERT INTO `municipio` VALUES (1187,20,172,'San Juan Achiutla');
INSERT INTO `municipio` VALUES (1188,20,173,'San Juan Atepec');
INSERT INTO `municipio` VALUES (1189,20,174,'Ánimas Trujano');
INSERT INTO `municipio` VALUES (1190,20,175,'San Juan Bautista Atatlahuca');
INSERT INTO `municipio` VALUES (1191,20,176,'San Juan Bautista Coixtlahuaca');
INSERT INTO `municipio` VALUES (1192,20,177,'San Juan Bautista Cuicatlán');
INSERT INTO `municipio` VALUES (1193,20,178,'San Juan Bautista Guelache');
INSERT INTO `municipio` VALUES (1194,20,179,'San Juan Bautista Jayacatlán');
INSERT INTO `municipio` VALUES (1195,20,180,'San Juan Bautista Lo de Soto');
INSERT INTO `municipio` VALUES (1196,20,181,'San Juan Bautista Suchitepec');
INSERT INTO `municipio` VALUES (1197,20,182,'San Juan Bautista Tlacoatzintepec');
INSERT INTO `municipio` VALUES (1198,20,183,'San Juan Bautista Tlachichilco');
INSERT INTO `municipio` VALUES (1199,20,184,'San Juan Bautista Tuxtepec');
INSERT INTO `municipio` VALUES (1200,20,185,'San Juan Cacahuatepec');
INSERT INTO `municipio` VALUES (1201,20,186,'San Juan Cieneguilla');
INSERT INTO `municipio` VALUES (1202,20,187,'San Juan Coatzóspam');
INSERT INTO `municipio` VALUES (1203,20,188,'San Juan Colorado');
INSERT INTO `municipio` VALUES (1204,20,189,'San Juan Comaltepec');
INSERT INTO `municipio` VALUES (1205,20,190,'San Juan Cotzocón');
INSERT INTO `municipio` VALUES (1206,20,191,'San Juan Chicomezúchil');
INSERT INTO `municipio` VALUES (1207,20,192,'San Juan Chilateca');
INSERT INTO `municipio` VALUES (1208,20,193,'San Juan del Estado');
INSERT INTO `municipio` VALUES (1209,20,194,'San Juan del Río');
INSERT INTO `municipio` VALUES (1210,20,195,'San Juan Diuxi');
INSERT INTO `municipio` VALUES (1211,20,196,'San Juan Evangelista Analco');
INSERT INTO `municipio` VALUES (1212,20,197,'San Juan Guelavía');
INSERT INTO `municipio` VALUES (1213,20,198,'San Juan Guichicovi');
INSERT INTO `municipio` VALUES (1214,20,199,'San Juan Ihualtepec');
INSERT INTO `municipio` VALUES (1215,20,200,'San Juan Juquila Mixes');
INSERT INTO `municipio` VALUES (1216,20,201,'San Juan Juquila Vijanos');
INSERT INTO `municipio` VALUES (1217,20,202,'San Juan Lachao');
INSERT INTO `municipio` VALUES (1218,20,203,'San Juan Lachigalla');
INSERT INTO `municipio` VALUES (1219,20,204,'San Juan Lajarcia');
INSERT INTO `municipio` VALUES (1220,20,205,'San Juan Lalana');
INSERT INTO `municipio` VALUES (1221,20,206,'San Juan de los Cués');
INSERT INTO `municipio` VALUES (1222,20,207,'San Juan Mazatlán');
INSERT INTO `municipio` VALUES (1223,20,208,'San Juan Mixtepec');
INSERT INTO `municipio` VALUES (1224,20,209,'San Juan Mixtepec');
INSERT INTO `municipio` VALUES (1225,20,210,'San Juan Ñumí');
INSERT INTO `municipio` VALUES (1226,20,211,'San Juan Ozolotepec');
INSERT INTO `municipio` VALUES (1227,20,212,'San Juan Petlapa');
INSERT INTO `municipio` VALUES (1228,20,213,'San Juan Quiahije');
INSERT INTO `municipio` VALUES (1229,20,214,'San Juan Quiotepec');
INSERT INTO `municipio` VALUES (1230,20,215,'San Juan Sayultepec');
INSERT INTO `municipio` VALUES (1231,20,216,'San Juan Tabaá');
INSERT INTO `municipio` VALUES (1232,20,217,'San Juan Tamazola');
INSERT INTO `municipio` VALUES (1233,20,218,'San Juan Teita');
INSERT INTO `municipio` VALUES (1234,20,219,'San Juan Teitipac');
INSERT INTO `municipio` VALUES (1235,20,220,'San Juan Tepeuxila');
INSERT INTO `municipio` VALUES (1236,20,221,'San Juan Teposcolula');
INSERT INTO `municipio` VALUES (1237,20,222,'San Juan Yaeé');
INSERT INTO `municipio` VALUES (1238,20,223,'San Juan Yatzona');
INSERT INTO `municipio` VALUES (1239,20,224,'San Juan Yucuita');
INSERT INTO `municipio` VALUES (1240,20,225,'San Lorenzo');
INSERT INTO `municipio` VALUES (1241,20,226,'San Lorenzo Albarradas');
INSERT INTO `municipio` VALUES (1242,20,227,'San Lorenzo Cacaotepec');
INSERT INTO `municipio` VALUES (1243,20,228,'San Lorenzo Cuaunecuiltitla');
INSERT INTO `municipio` VALUES (1244,20,229,'San Lorenzo Texmelúcan');
INSERT INTO `municipio` VALUES (1245,20,230,'San Lorenzo Victoria');
INSERT INTO `municipio` VALUES (1246,20,231,'San Lucas Camotlán');
INSERT INTO `municipio` VALUES (1247,20,232,'San Lucas Ojitlán');
INSERT INTO `municipio` VALUES (1248,20,233,'San Lucas Quiaviní');
INSERT INTO `municipio` VALUES (1249,20,234,'San Lucas Zoquiápam');
INSERT INTO `municipio` VALUES (1250,20,235,'San Luis Amatlán');
INSERT INTO `municipio` VALUES (1251,20,236,'San Marcial Ozolotepec');
INSERT INTO `municipio` VALUES (1252,20,237,'San Marcos Arteaga');
INSERT INTO `municipio` VALUES (1253,20,238,'Heroico San Martín de los Cansecos');
INSERT INTO `municipio` VALUES (1254,20,239,'San Martín Huamelúlpam');
INSERT INTO `municipio` VALUES (1255,20,240,'San Martín Itunyoso');
INSERT INTO `municipio` VALUES (1256,20,241,'San Martín Lachilá');
INSERT INTO `municipio` VALUES (1257,20,242,'San Martín Peras');
INSERT INTO `municipio` VALUES (1258,20,243,'San Martín Tilcajete');
INSERT INTO `municipio` VALUES (1259,20,244,'San Martín Toxpalan');
INSERT INTO `municipio` VALUES (1260,20,245,'San Martín Zacatepec');
INSERT INTO `municipio` VALUES (1261,20,246,'San Mateo Cajonos');
INSERT INTO `municipio` VALUES (1262,20,247,'Capulálpam de Méndez');
INSERT INTO `municipio` VALUES (1263,20,248,'San Mateo del Mar');
INSERT INTO `municipio` VALUES (1264,20,249,'San Mateo Yoloxochitlán');
INSERT INTO `municipio` VALUES (1265,20,250,'San Mateo Etlatongo');
INSERT INTO `municipio` VALUES (1266,20,251,'San Mateo Nejápam');
INSERT INTO `municipio` VALUES (1267,20,252,'San Mateo Peñasco');
INSERT INTO `municipio` VALUES (1268,20,253,'San Mateo Piñas');
INSERT INTO `municipio` VALUES (1269,20,254,'San Mateo Río Hondo');
INSERT INTO `municipio` VALUES (1270,20,255,'San Mateo Sindihui');
INSERT INTO `municipio` VALUES (1271,20,256,'San Mateo Tlapiltepec');
INSERT INTO `municipio` VALUES (1272,20,257,'San Melchor Betaza');
INSERT INTO `municipio` VALUES (1273,20,258,'San Miguel Achiutla');
INSERT INTO `municipio` VALUES (1274,20,259,'San Miguel Ahuehuetitlán');
INSERT INTO `municipio` VALUES (1275,20,260,'San Miguel Aloápam');
INSERT INTO `municipio` VALUES (1276,20,261,'San Miguel Amatitlán');
INSERT INTO `municipio` VALUES (1277,20,262,'San Miguel Amatlán');
INSERT INTO `municipio` VALUES (1278,20,263,'San Miguel Coatlán');
INSERT INTO `municipio` VALUES (1279,20,264,'San Miguel Chicahua');
INSERT INTO `municipio` VALUES (1280,20,265,'San Miguel Chimalapa');
INSERT INTO `municipio` VALUES (1281,20,266,'San Miguel del Puerto');
INSERT INTO `municipio` VALUES (1282,20,267,'San Miguel del Río');
INSERT INTO `municipio` VALUES (1283,20,268,'San Miguel Ejutla');
INSERT INTO `municipio` VALUES (1284,20,269,'San Miguel el Grande');
INSERT INTO `municipio` VALUES (1285,20,270,'San Miguel Huautla');
INSERT INTO `municipio` VALUES (1286,20,271,'San Miguel Mixtepec');
INSERT INTO `municipio` VALUES (1287,20,272,'San Miguel Panixtlahuaca');
INSERT INTO `municipio` VALUES (1288,20,273,'San Miguel Peras');
INSERT INTO `municipio` VALUES (1289,20,274,'San Miguel Piedras');
INSERT INTO `municipio` VALUES (1290,20,275,'San Miguel Quetzaltepec');
INSERT INTO `municipio` VALUES (1291,20,276,'San Miguel Santa Flor');
INSERT INTO `municipio` VALUES (1292,20,277,'Villa Sola de Vega');
INSERT INTO `municipio` VALUES (1293,20,278,'San Miguel Soyaltepec');
INSERT INTO `municipio` VALUES (1294,20,279,'San Miguel Suchixtepec');
INSERT INTO `municipio` VALUES (1295,20,280,'Villa Talea de Castro');
INSERT INTO `municipio` VALUES (1296,20,281,'San Miguel Tecomatlán');
INSERT INTO `municipio` VALUES (1297,20,282,'San Miguel Tenango');
INSERT INTO `municipio` VALUES (1298,20,283,'San Miguel Tequixtepec');
INSERT INTO `municipio` VALUES (1299,20,284,'San Miguel Tilquiápam');
INSERT INTO `municipio` VALUES (1300,20,285,'San Miguel Tlacamama');
INSERT INTO `municipio` VALUES (1301,20,286,'San Miguel Tlacotepec');
INSERT INTO `municipio` VALUES (1302,20,287,'San Miguel Tulancingo');
INSERT INTO `municipio` VALUES (1303,20,288,'San Miguel Yotao');
INSERT INTO `municipio` VALUES (1304,20,289,'San Nicolás');
INSERT INTO `municipio` VALUES (1305,20,290,'San Nicolás Hidalgo');
INSERT INTO `municipio` VALUES (1306,20,291,'San Pablo Coatlán');
INSERT INTO `municipio` VALUES (1307,20,292,'San Pablo Cuatro Venados');
INSERT INTO `municipio` VALUES (1308,20,293,'San Pablo Etla');
INSERT INTO `municipio` VALUES (1309,20,294,'San Pablo Huitzo');
INSERT INTO `municipio` VALUES (1310,20,295,'San Pablo Huixtepec');
INSERT INTO `municipio` VALUES (1311,20,296,'San Pablo Macuiltianguis');
INSERT INTO `municipio` VALUES (1312,20,297,'San Pablo Tijaltepec');
INSERT INTO `municipio` VALUES (1313,20,298,'San Pablo Villa de Mitla');
INSERT INTO `municipio` VALUES (1314,20,299,'San Pablo Yaganiza');
INSERT INTO `municipio` VALUES (1315,20,300,'San Pedro Amuzgos');
INSERT INTO `municipio` VALUES (1316,20,301,'San Pedro Apóstol');
INSERT INTO `municipio` VALUES (1317,20,302,'San Pedro Atoyac');
INSERT INTO `municipio` VALUES (1318,20,303,'San Pedro Cajonos');
INSERT INTO `municipio` VALUES (1319,20,304,'San Pedro Coxcaltepec Cántaros');
INSERT INTO `municipio` VALUES (1320,20,305,'San Pedro Comitancillo');
INSERT INTO `municipio` VALUES (1321,20,306,'San Pedro el Alto');
INSERT INTO `municipio` VALUES (1322,20,307,'San Pedro Huamelula');
INSERT INTO `municipio` VALUES (1323,20,308,'San Pedro Huilotepec');
INSERT INTO `municipio` VALUES (1324,20,309,'San Pedro Ixcatlán');
INSERT INTO `municipio` VALUES (1325,20,310,'San Pedro Ixtlahuaca');
INSERT INTO `municipio` VALUES (1326,20,311,'San Pedro Jaltepetongo');
INSERT INTO `municipio` VALUES (1327,20,312,'San Pedro Jicayán');
INSERT INTO `municipio` VALUES (1328,20,313,'San Pedro Jocotipac');
INSERT INTO `municipio` VALUES (1329,20,314,'San Pedro Juchatengo');
INSERT INTO `municipio` VALUES (1330,20,315,'San Pedro Mártir');
INSERT INTO `municipio` VALUES (1331,20,316,'San Pedro Mártir Quiechapa');
INSERT INTO `municipio` VALUES (1332,20,317,'San Pedro Mártir Yucuxaco');
INSERT INTO `municipio` VALUES (1333,20,318,'San Pedro Mixtepec');
INSERT INTO `municipio` VALUES (1334,20,319,'San Pedro Mixtepec');
INSERT INTO `municipio` VALUES (1335,20,320,'San Pedro Molinos');
INSERT INTO `municipio` VALUES (1336,20,321,'San Pedro Nopala');
INSERT INTO `municipio` VALUES (1337,20,322,'San Pedro Ocopetatillo');
INSERT INTO `municipio` VALUES (1338,20,323,'San Pedro Ocotepec');
INSERT INTO `municipio` VALUES (1339,20,324,'San Pedro Pochutla');
INSERT INTO `municipio` VALUES (1340,20,325,'San Pedro Quiatoni');
INSERT INTO `municipio` VALUES (1341,20,326,'San Pedro Sochiápam');
INSERT INTO `municipio` VALUES (1342,20,327,'San Pedro Tapanatepec');
INSERT INTO `municipio` VALUES (1343,20,328,'San Pedro Taviche');
INSERT INTO `municipio` VALUES (1344,20,329,'San Pedro Teozacoalco');
INSERT INTO `municipio` VALUES (1345,20,330,'San Pedro Teutila');
INSERT INTO `municipio` VALUES (1346,20,331,'San Pedro Tidaá');
INSERT INTO `municipio` VALUES (1347,20,332,'San Pedro Topiltepec');
INSERT INTO `municipio` VALUES (1348,20,333,'San Pedro Totolápam');
INSERT INTO `municipio` VALUES (1349,20,334,'Villa de Tututepec');
INSERT INTO `municipio` VALUES (1350,20,335,'San Pedro Yaneri');
INSERT INTO `municipio` VALUES (1351,20,336,'San Pedro Yólox');
INSERT INTO `municipio` VALUES (1352,20,337,'San Pedro y San Pablo Ayutla');
INSERT INTO `municipio` VALUES (1353,20,338,'Villa de Etla');
INSERT INTO `municipio` VALUES (1354,20,339,'San Pedro y San Pablo Teposcolula');
INSERT INTO `municipio` VALUES (1355,20,340,'San Pedro y San Pablo Tequixtepec');
INSERT INTO `municipio` VALUES (1356,20,341,'San Pedro Yucunama');
INSERT INTO `municipio` VALUES (1357,20,342,'San Raymundo Jalpan');
INSERT INTO `municipio` VALUES (1358,20,343,'San Sebastián Abasolo');
INSERT INTO `municipio` VALUES (1359,20,344,'San Sebastián Coatlán');
INSERT INTO `municipio` VALUES (1360,20,345,'San Sebastián Ixcapa');
INSERT INTO `municipio` VALUES (1361,20,346,'San Sebastián Nicananduta');
INSERT INTO `municipio` VALUES (1362,20,347,'San Sebastián Río Hondo');
INSERT INTO `municipio` VALUES (1363,20,348,'San Sebastián Tecomaxtlahuaca');
INSERT INTO `municipio` VALUES (1364,20,349,'San Sebastián Teitipac');
INSERT INTO `municipio` VALUES (1365,20,350,'San Sebastián Tutla');
INSERT INTO `municipio` VALUES (1366,20,351,'San Simón Almolongas');
INSERT INTO `municipio` VALUES (1367,20,352,'San Simón Zahuatlán');
INSERT INTO `municipio` VALUES (1368,20,353,'Santa Ana');
INSERT INTO `municipio` VALUES (1369,20,354,'Santa Ana Ateixtlahuaca');
INSERT INTO `municipio` VALUES (1370,20,355,'Santa Ana Cuauhtémoc');
INSERT INTO `municipio` VALUES (1371,20,356,'Santa Ana del Valle');
INSERT INTO `municipio` VALUES (1372,20,357,'Santa Ana Tavela');
INSERT INTO `municipio` VALUES (1373,20,358,'Santa Ana Tlapacoyan');
INSERT INTO `municipio` VALUES (1374,20,359,'Santa Ana Yareni');
INSERT INTO `municipio` VALUES (1375,20,360,'Santa Ana Zegache');
INSERT INTO `municipio` VALUES (1376,20,361,'Santa Catalina Quierí');
INSERT INTO `municipio` VALUES (1377,20,362,'Santa Catarina Cuixtla');
INSERT INTO `municipio` VALUES (1378,20,363,'Santa Catarina Ixtepeji');
INSERT INTO `municipio` VALUES (1379,20,364,'Santa Catarina Juquila');
INSERT INTO `municipio` VALUES (1380,20,365,'Santa Catarina Lachatao');
INSERT INTO `municipio` VALUES (1381,20,366,'Santa Catarina Loxicha');
INSERT INTO `municipio` VALUES (1382,20,367,'Santa Catarina Mechoacán');
INSERT INTO `municipio` VALUES (1383,20,368,'Santa Catarina Minas');
INSERT INTO `municipio` VALUES (1384,20,369,'Santa Catarina Quiané');
INSERT INTO `municipio` VALUES (1385,20,370,'Santa Catarina Tayata');
INSERT INTO `municipio` VALUES (1386,20,371,'Santa Catarina Ticuá');
INSERT INTO `municipio` VALUES (1387,20,372,'Santa Catarina Yosonotú');
INSERT INTO `municipio` VALUES (1388,20,373,'Santa Catarina Zapoquila');
INSERT INTO `municipio` VALUES (1389,20,374,'Santa Cruz Acatepec');
INSERT INTO `municipio` VALUES (1390,20,375,'Santa Cruz Amilpas');
INSERT INTO `municipio` VALUES (1391,20,376,'Santa Cruz de Bravo');
INSERT INTO `municipio` VALUES (1392,20,377,'Santa Cruz Itundujia');
INSERT INTO `municipio` VALUES (1393,20,378,'Santa Cruz Mixtepec');
INSERT INTO `municipio` VALUES (1394,20,379,'Santa Cruz Nundaco');
INSERT INTO `municipio` VALUES (1395,20,380,'Santa Cruz Papalutla');
INSERT INTO `municipio` VALUES (1396,20,381,'Santa Cruz Tacache de Mina');
INSERT INTO `municipio` VALUES (1397,20,382,'Santa Cruz Tacahua');
INSERT INTO `municipio` VALUES (1398,20,383,'Santa Cruz Tayata');
INSERT INTO `municipio` VALUES (1399,20,384,'Santa Cruz Xitla');
INSERT INTO `municipio` VALUES (1400,20,385,'Santa Cruz Xoxocotlán');
INSERT INTO `municipio` VALUES (1401,20,386,'Santa Cruz Zenzontepec');
INSERT INTO `municipio` VALUES (1402,20,387,'Santa Gertrudis');
INSERT INTO `municipio` VALUES (1403,20,388,'Santa Inés del Monte');
INSERT INTO `municipio` VALUES (1404,20,389,'Santa Inés Yatzeche');
INSERT INTO `municipio` VALUES (1405,20,390,'Santa Lucía del Camino');
INSERT INTO `municipio` VALUES (1406,20,391,'Santa Lucía Miahuatlán');
INSERT INTO `municipio` VALUES (1407,20,392,'Santa Lucía Monteverde');
INSERT INTO `municipio` VALUES (1408,20,393,'Santa Lucía Ocotlán');
INSERT INTO `municipio` VALUES (1409,20,394,'Santa María Alotepec');
INSERT INTO `municipio` VALUES (1410,20,395,'Santa María Apazco');
INSERT INTO `municipio` VALUES (1411,20,396,'Santa María la Asunción');
INSERT INTO `municipio` VALUES (1412,20,397,'Heroica Ciudad de Tlaxiaco');
INSERT INTO `municipio` VALUES (1413,20,398,'Ayoquezco de Aldama');
INSERT INTO `municipio` VALUES (1414,20,399,'Santa María Atzompa');
INSERT INTO `municipio` VALUES (1415,20,400,'Santa María Camotlán');
INSERT INTO `municipio` VALUES (1416,20,401,'Santa María Colotepec');
INSERT INTO `municipio` VALUES (1417,20,402,'Santa María Cortijo');
INSERT INTO `municipio` VALUES (1418,20,403,'Santa María Coyotepec');
INSERT INTO `municipio` VALUES (1419,20,404,'Santa María Chachoápam');
INSERT INTO `municipio` VALUES (1420,20,405,'Villa de Chilapa de Díaz');
INSERT INTO `municipio` VALUES (1421,20,406,'Santa María Chilchotla');
INSERT INTO `municipio` VALUES (1422,20,407,'Santa María Chimalapa');
INSERT INTO `municipio` VALUES (1423,20,408,'Santa María del Rosario');
INSERT INTO `municipio` VALUES (1424,20,409,'Santa María del Tule');
INSERT INTO `municipio` VALUES (1425,20,410,'Santa María Ecatepec');
INSERT INTO `municipio` VALUES (1426,20,411,'Santa María Guelacé');
INSERT INTO `municipio` VALUES (1427,20,412,'Santa María Guienagati');
INSERT INTO `municipio` VALUES (1428,20,413,'Santa María Huatulco');
INSERT INTO `municipio` VALUES (1429,20,414,'Santa María Huazolotitlán');
INSERT INTO `municipio` VALUES (1430,20,415,'Santa María Ipalapa');
INSERT INTO `municipio` VALUES (1431,20,416,'Santa María Ixcatlán');
INSERT INTO `municipio` VALUES (1432,20,417,'Santa María Jacatepec');
INSERT INTO `municipio` VALUES (1433,20,418,'Santa María Jalapa del Marqués');
INSERT INTO `municipio` VALUES (1434,20,419,'Santa María Jaltianguis');
INSERT INTO `municipio` VALUES (1435,20,420,'Santa María Lachixío');
INSERT INTO `municipio` VALUES (1436,20,421,'Santa María Mixtequilla');
INSERT INTO `municipio` VALUES (1437,20,422,'Santa María Nativitas');
INSERT INTO `municipio` VALUES (1438,20,423,'Santa María Nduayaco');
INSERT INTO `municipio` VALUES (1439,20,424,'Santa María Ozolotepec');
INSERT INTO `municipio` VALUES (1440,20,425,'Santa María Pápalo');
INSERT INTO `municipio` VALUES (1441,20,426,'Santa María Peñoles');
INSERT INTO `municipio` VALUES (1442,20,427,'Santa María Petapa');
INSERT INTO `municipio` VALUES (1443,20,428,'Santa María Quiegolani');
INSERT INTO `municipio` VALUES (1444,20,429,'Santa María Sola');
INSERT INTO `municipio` VALUES (1445,20,430,'Santa María Tataltepec');
INSERT INTO `municipio` VALUES (1446,20,431,'Santa María Tecomavaca');
INSERT INTO `municipio` VALUES (1447,20,432,'Santa María Temaxcalapa');
INSERT INTO `municipio` VALUES (1448,20,433,'Santa María Temaxcaltepec');
INSERT INTO `municipio` VALUES (1449,20,434,'Santa María Teopoxco');
INSERT INTO `municipio` VALUES (1450,20,435,'Santa María Tepantlali');
INSERT INTO `municipio` VALUES (1451,20,436,'Santa María Texcatitlán');
INSERT INTO `municipio` VALUES (1452,20,437,'Santa María Tlahuitoltepec');
INSERT INTO `municipio` VALUES (1453,20,438,'Santa María Tlalixtac');
INSERT INTO `municipio` VALUES (1454,20,439,'Santa María Tonameca');
INSERT INTO `municipio` VALUES (1455,20,440,'Santa María Totolapilla');
INSERT INTO `municipio` VALUES (1456,20,441,'Santa María Xadani');
INSERT INTO `municipio` VALUES (1457,20,442,'Santa María Yalina');
INSERT INTO `municipio` VALUES (1458,20,443,'Santa María Yavesía');
INSERT INTO `municipio` VALUES (1459,20,444,'Santa María Yolotepec');
INSERT INTO `municipio` VALUES (1460,20,445,'Santa María Yosoyúa');
INSERT INTO `municipio` VALUES (1461,20,446,'Santa María Yucuhiti');
INSERT INTO `municipio` VALUES (1462,20,447,'Santa María Zacatepec');
INSERT INTO `municipio` VALUES (1463,20,448,'Santa María Zaniza');
INSERT INTO `municipio` VALUES (1464,20,449,'Santa María Zoquitlán');
INSERT INTO `municipio` VALUES (1465,20,450,'Santiago Amoltepec');
INSERT INTO `municipio` VALUES (1466,20,451,'Santiago Apoala');
INSERT INTO `municipio` VALUES (1467,20,452,'Santiago Apóstol');
INSERT INTO `municipio` VALUES (1468,20,453,'Santiago Astata');
INSERT INTO `municipio` VALUES (1469,20,454,'Santiago Atitlán');
INSERT INTO `municipio` VALUES (1470,20,455,'Santiago Ayuquililla');
INSERT INTO `municipio` VALUES (1471,20,456,'Santiago Cacaloxtepec');
INSERT INTO `municipio` VALUES (1472,20,457,'Santiago Camotlán');
INSERT INTO `municipio` VALUES (1473,20,458,'Santiago Comaltepec');
INSERT INTO `municipio` VALUES (1474,20,459,'Villa de Santiago Chazumba');
INSERT INTO `municipio` VALUES (1475,20,460,'Santiago Choápam');
INSERT INTO `municipio` VALUES (1476,20,461,'Santiago del Río');
INSERT INTO `municipio` VALUES (1477,20,462,'Santiago Huajolotitlán');
INSERT INTO `municipio` VALUES (1478,20,463,'Santiago Huauclilla');
INSERT INTO `municipio` VALUES (1479,20,464,'Santiago Ihuitlán Plumas');
INSERT INTO `municipio` VALUES (1480,20,465,'Santiago Ixcuintepec');
INSERT INTO `municipio` VALUES (1481,20,466,'Santiago Ixtayutla');
INSERT INTO `municipio` VALUES (1482,20,467,'Santiago Jamiltepec');
INSERT INTO `municipio` VALUES (1483,20,468,'Santiago Jocotepec');
INSERT INTO `municipio` VALUES (1484,20,469,'Santiago Juxtlahuaca');
INSERT INTO `municipio` VALUES (1485,20,470,'Santiago Lachiguiri');
INSERT INTO `municipio` VALUES (1486,20,471,'Santiago Lalopa');
INSERT INTO `municipio` VALUES (1487,20,472,'Santiago Laollaga');
INSERT INTO `municipio` VALUES (1488,20,473,'Santiago Laxopa');
INSERT INTO `municipio` VALUES (1489,20,474,'Santiago Llano Grande');
INSERT INTO `municipio` VALUES (1490,20,475,'Santiago Matatlán');
INSERT INTO `municipio` VALUES (1491,20,476,'Santiago Miltepec');
INSERT INTO `municipio` VALUES (1492,20,477,'Santiago Minas');
INSERT INTO `municipio` VALUES (1493,20,478,'Santiago Nacaltepec');
INSERT INTO `municipio` VALUES (1494,20,479,'Santiago Nejapilla');
INSERT INTO `municipio` VALUES (1495,20,480,'Santiago Nundiche');
INSERT INTO `municipio` VALUES (1496,20,481,'Santiago Nuyoó');
INSERT INTO `municipio` VALUES (1497,20,482,'Santiago Pinotepa Nacional');
INSERT INTO `municipio` VALUES (1498,20,483,'Santiago Suchilquitongo');
INSERT INTO `municipio` VALUES (1499,20,484,'Santiago Tamazola');
INSERT INTO `municipio` VALUES (1500,20,485,'Santiago Tapextla');
INSERT INTO `municipio` VALUES (1501,20,486,'Villa Tejúpam de la Unión');
INSERT INTO `municipio` VALUES (1502,20,487,'Santiago Tenango');
INSERT INTO `municipio` VALUES (1503,20,488,'Santiago Tepetlapa');
INSERT INTO `municipio` VALUES (1504,20,489,'Santiago Tetepec');
INSERT INTO `municipio` VALUES (1505,20,490,'Santiago Texcalcingo');
INSERT INTO `municipio` VALUES (1506,20,491,'Santiago Textitlán');
INSERT INTO `municipio` VALUES (1507,20,492,'Santiago Tilantongo');
INSERT INTO `municipio` VALUES (1508,20,493,'Santiago Tillo');
INSERT INTO `municipio` VALUES (1509,20,494,'Santiago Tlazoyaltepec');
INSERT INTO `municipio` VALUES (1510,20,495,'Santiago Xanica');
INSERT INTO `municipio` VALUES (1511,20,496,'Santiago Xiacuí');
INSERT INTO `municipio` VALUES (1512,20,497,'Santiago Yaitepec');
INSERT INTO `municipio` VALUES (1513,20,498,'Santiago Yaveo');
INSERT INTO `municipio` VALUES (1514,20,499,'Santiago Yolomécatl');
INSERT INTO `municipio` VALUES (1515,20,500,'Santiago Yosondúa');
INSERT INTO `municipio` VALUES (1516,20,501,'Santiago Yucuyachi');
INSERT INTO `municipio` VALUES (1517,20,502,'Santiago Zacatepec');
INSERT INTO `municipio` VALUES (1518,20,503,'Santiago Zoochila');
INSERT INTO `municipio` VALUES (1519,20,504,'Nuevo Zoquiápam');
INSERT INTO `municipio` VALUES (1520,20,505,'Santo Domingo Ingenio');
INSERT INTO `municipio` VALUES (1521,20,506,'Santo Domingo Albarradas');
INSERT INTO `municipio` VALUES (1522,20,507,'Santo Domingo Armenta');
INSERT INTO `municipio` VALUES (1523,20,508,'Santo Domingo Chihuitán');
INSERT INTO `municipio` VALUES (1524,20,509,'Santo Domingo de Morelos');
INSERT INTO `municipio` VALUES (1525,20,510,'Santo Domingo Ixcatlán');
INSERT INTO `municipio` VALUES (1526,20,511,'Santo Domingo Nuxaá');
INSERT INTO `municipio` VALUES (1527,20,512,'Santo Domingo Ozolotepec');
INSERT INTO `municipio` VALUES (1528,20,513,'Santo Domingo Petapa');
INSERT INTO `municipio` VALUES (1529,20,514,'Santo Domingo Roayaga');
INSERT INTO `municipio` VALUES (1530,20,515,'Santo Domingo Tehuantepec');
INSERT INTO `municipio` VALUES (1531,20,516,'Santo Domingo Teojomulco');
INSERT INTO `municipio` VALUES (1532,20,517,'Santo Domingo Tepuxtepec');
INSERT INTO `municipio` VALUES (1533,20,518,'Santo Domingo Tlatayápam');
INSERT INTO `municipio` VALUES (1534,20,519,'Santo Domingo Tomaltepec');
INSERT INTO `municipio` VALUES (1535,20,520,'Santo Domingo Tonalá');
INSERT INTO `municipio` VALUES (1536,20,521,'Santo Domingo Tonaltepec');
INSERT INTO `municipio` VALUES (1537,20,522,'Santo Domingo Xagacía');
INSERT INTO `municipio` VALUES (1538,20,523,'Santo Domingo Yanhuitlán');
INSERT INTO `municipio` VALUES (1539,20,524,'Santo Domingo Yodohino');
INSERT INTO `municipio` VALUES (1540,20,525,'Santo Domingo Zanatepec');
INSERT INTO `municipio` VALUES (1541,20,526,'Santos Reyes Nopala');
INSERT INTO `municipio` VALUES (1542,20,527,'Santos Reyes Pápalo');
INSERT INTO `municipio` VALUES (1543,20,528,'Santos Reyes Tepejillo');
INSERT INTO `municipio` VALUES (1544,20,529,'Santos Reyes Yucuná');
INSERT INTO `municipio` VALUES (1545,20,530,'Santo Tomás Jalieza');
INSERT INTO `municipio` VALUES (1546,20,531,'Santo Tomás Mazaltepec');
INSERT INTO `municipio` VALUES (1547,20,532,'Santo Tomás Ocotepec');
INSERT INTO `municipio` VALUES (1548,20,533,'Santo Tomás Tamazulapan');
INSERT INTO `municipio` VALUES (1549,20,534,'San Vicente Coatlán');
INSERT INTO `municipio` VALUES (1550,20,535,'San Vicente Lachixío');
INSERT INTO `municipio` VALUES (1551,20,536,'San Vicente Nuñú');
INSERT INTO `municipio` VALUES (1552,20,537,'Silacayoápam');
INSERT INTO `municipio` VALUES (1553,20,538,'Sitio de Xitlapehua');
INSERT INTO `municipio` VALUES (1554,20,539,'Soledad Etla');
INSERT INTO `municipio` VALUES (1555,20,540,'Villa de Tamazulápam del Progreso');
INSERT INTO `municipio` VALUES (1556,20,541,'Tanetze de Zaragoza');
INSERT INTO `municipio` VALUES (1557,20,542,'Taniche');
INSERT INTO `municipio` VALUES (1558,20,543,'Tataltepec de Valdés');
INSERT INTO `municipio` VALUES (1559,20,544,'Teococuilco de Marcos Pérez');
INSERT INTO `municipio` VALUES (1560,20,545,'Teotitlán de Flores Magón');
INSERT INTO `municipio` VALUES (1561,20,546,'Teotitlán del Valle');
INSERT INTO `municipio` VALUES (1562,20,547,'Teotongo');
INSERT INTO `municipio` VALUES (1563,20,548,'Tepelmeme Villa de Morelos');
INSERT INTO `municipio` VALUES (1564,20,549,'Heroica Villa Tezoatlán de Segura y Luna, Cuna de la Independencia de Oaxaca');
INSERT INTO `municipio` VALUES (1565,20,550,'San Jerónimo Tlacochahuaya');
INSERT INTO `municipio` VALUES (1566,20,551,'Tlacolula de Matamoros');
INSERT INTO `municipio` VALUES (1567,20,552,'Tlacotepec Plumas');
INSERT INTO `municipio` VALUES (1568,20,553,'Tlalixtac de Cabrera');
INSERT INTO `municipio` VALUES (1569,20,554,'Totontepec Villa de Morelos');
INSERT INTO `municipio` VALUES (1570,20,555,'Trinidad Zaachila');
INSERT INTO `municipio` VALUES (1571,20,556,'La Trinidad Vista Hermosa');
INSERT INTO `municipio` VALUES (1572,20,557,'Unión Hidalgo');
INSERT INTO `municipio` VALUES (1573,20,558,'Valerio Trujano');
INSERT INTO `municipio` VALUES (1574,20,559,'San Juan Bautista Valle Nacional');
INSERT INTO `municipio` VALUES (1575,20,560,'Villa Díaz Ordaz');
INSERT INTO `municipio` VALUES (1576,20,561,'Yaxe');
INSERT INTO `municipio` VALUES (1577,20,562,'Magdalena Yodocono de Porfirio Díaz');
INSERT INTO `municipio` VALUES (1578,20,563,'Yogana');
INSERT INTO `municipio` VALUES (1579,20,564,'Yutanduchi de Guerrero');
INSERT INTO `municipio` VALUES (1580,20,565,'Villa de Zaachila');
INSERT INTO `municipio` VALUES (1581,20,566,'San Mateo Yucutindoo');
INSERT INTO `municipio` VALUES (1582,20,567,'Zapotitlán Lagunas');
INSERT INTO `municipio` VALUES (1583,20,568,'Zapotitlán Palmas');
INSERT INTO `municipio` VALUES (1584,20,569,'Santa Inés de Zaragoza');
INSERT INTO `municipio` VALUES (1585,20,570,'Zimatlán de Álvarez');
INSERT INTO `municipio` VALUES (1586,21,1,'Acajete');
INSERT INTO `municipio` VALUES (1587,21,2,'Acateno');
INSERT INTO `municipio` VALUES (1588,21,3,'Acatlán');
INSERT INTO `municipio` VALUES (1589,21,4,'Acatzingo');
INSERT INTO `municipio` VALUES (1590,21,5,'Acteopan');
INSERT INTO `municipio` VALUES (1591,21,6,'Ahuacatlán');
INSERT INTO `municipio` VALUES (1592,21,7,'Ahuatlán');
INSERT INTO `municipio` VALUES (1593,21,8,'Ahuazotepec');
INSERT INTO `municipio` VALUES (1594,21,9,'Ahuehuetitla');
INSERT INTO `municipio` VALUES (1595,21,10,'Ajalpan');
INSERT INTO `municipio` VALUES (1596,21,11,'Albino Zertuche');
INSERT INTO `municipio` VALUES (1597,21,12,'Aljojuca');
INSERT INTO `municipio` VALUES (1598,21,13,'Altepexi');
INSERT INTO `municipio` VALUES (1599,21,14,'Amixtlán');
INSERT INTO `municipio` VALUES (1600,21,15,'Amozoc');
INSERT INTO `municipio` VALUES (1601,21,16,'Aquixtla');
INSERT INTO `municipio` VALUES (1602,21,17,'Atempan');
INSERT INTO `municipio` VALUES (1603,21,18,'Atexcal');
INSERT INTO `municipio` VALUES (1604,21,19,'Atlixco');
INSERT INTO `municipio` VALUES (1605,21,20,'Atoyatempan');
INSERT INTO `municipio` VALUES (1606,21,21,'Atzala');
INSERT INTO `municipio` VALUES (1607,21,22,'Atzitzihuacán');
INSERT INTO `municipio` VALUES (1608,21,23,'Atzitzintla');
INSERT INTO `municipio` VALUES (1609,21,24,'Axutla');
INSERT INTO `municipio` VALUES (1610,21,25,'Ayotoxco de Guerrero');
INSERT INTO `municipio` VALUES (1611,21,26,'Calpan');
INSERT INTO `municipio` VALUES (1612,21,27,'Caltepec');
INSERT INTO `municipio` VALUES (1613,21,28,'Camocuautla');
INSERT INTO `municipio` VALUES (1614,21,29,'Caxhuacan');
INSERT INTO `municipio` VALUES (1615,21,30,'Coatepec');
INSERT INTO `municipio` VALUES (1616,21,31,'Coatzingo');
INSERT INTO `municipio` VALUES (1617,21,32,'Cohetzala');
INSERT INTO `municipio` VALUES (1618,21,33,'Cohuecan');
INSERT INTO `municipio` VALUES (1619,21,34,'Coronango');
INSERT INTO `municipio` VALUES (1620,21,35,'Coxcatlán');
INSERT INTO `municipio` VALUES (1621,21,36,'Coyomeapan');
INSERT INTO `municipio` VALUES (1622,21,37,'Coyotepec');
INSERT INTO `municipio` VALUES (1623,21,38,'Cuapiaxtla de Madero');
INSERT INTO `municipio` VALUES (1624,21,39,'Cuautempan');
INSERT INTO `municipio` VALUES (1625,21,40,'Cuautinchán');
INSERT INTO `municipio` VALUES (1626,21,41,'Cuautlancingo');
INSERT INTO `municipio` VALUES (1627,21,42,'Cuayuca de Andrade');
INSERT INTO `municipio` VALUES (1628,21,43,'Cuetzalan del Progreso');
INSERT INTO `municipio` VALUES (1629,21,44,'Cuyoaco');
INSERT INTO `municipio` VALUES (1630,21,45,'Chalchicomula de Sesma');
INSERT INTO `municipio` VALUES (1631,21,46,'Chapulco');
INSERT INTO `municipio` VALUES (1632,21,47,'Chiautla');
INSERT INTO `municipio` VALUES (1633,21,48,'Chiautzingo');
INSERT INTO `municipio` VALUES (1634,21,49,'Chiconcuautla');
INSERT INTO `municipio` VALUES (1635,21,50,'Chichiquila');
INSERT INTO `municipio` VALUES (1636,21,51,'Chietla');
INSERT INTO `municipio` VALUES (1637,21,52,'Chigmecatitlán');
INSERT INTO `municipio` VALUES (1638,21,53,'Chignahuapan');
INSERT INTO `municipio` VALUES (1639,21,54,'Chignautla');
INSERT INTO `municipio` VALUES (1640,21,55,'Chila');
INSERT INTO `municipio` VALUES (1641,21,56,'Chila de la Sal');
INSERT INTO `municipio` VALUES (1642,21,57,'Honey');
INSERT INTO `municipio` VALUES (1643,21,58,'Chilchotla');
INSERT INTO `municipio` VALUES (1644,21,59,'Chinantla');
INSERT INTO `municipio` VALUES (1645,21,60,'Domingo Arenas');
INSERT INTO `municipio` VALUES (1646,21,61,'Eloxochitlán');
INSERT INTO `municipio` VALUES (1647,21,62,'Epatlán');
INSERT INTO `municipio` VALUES (1648,21,63,'Esperanza');
INSERT INTO `municipio` VALUES (1649,21,64,'Francisco Z. Mena');
INSERT INTO `municipio` VALUES (1650,21,65,'General Felipe Ángeles');
INSERT INTO `municipio` VALUES (1651,21,66,'Guadalupe');
INSERT INTO `municipio` VALUES (1652,21,67,'Guadalupe Victoria');
INSERT INTO `municipio` VALUES (1653,21,68,'Hermenegildo Galeana');
INSERT INTO `municipio` VALUES (1654,21,69,'Huaquechula');
INSERT INTO `municipio` VALUES (1655,21,70,'Huatlatlauca');
INSERT INTO `municipio` VALUES (1656,21,71,'Huauchinango');
INSERT INTO `municipio` VALUES (1657,21,72,'Huehuetla');
INSERT INTO `municipio` VALUES (1658,21,73,'Huehuetlán el Chico');
INSERT INTO `municipio` VALUES (1659,21,74,'Huejotzingo');
INSERT INTO `municipio` VALUES (1660,21,75,'Hueyapan');
INSERT INTO `municipio` VALUES (1661,21,76,'Hueytamalco');
INSERT INTO `municipio` VALUES (1662,21,77,'Hueytlalpan');
INSERT INTO `municipio` VALUES (1663,21,78,'Huitzilan de Serdán');
INSERT INTO `municipio` VALUES (1664,21,79,'Huitziltepec');
INSERT INTO `municipio` VALUES (1665,21,80,'Atlequizayan');
INSERT INTO `municipio` VALUES (1666,21,81,'Ixcamilpa de Guerrero');
INSERT INTO `municipio` VALUES (1667,21,82,'Ixcaquixtla');
INSERT INTO `municipio` VALUES (1668,21,83,'Ixtacamaxtitlán');
INSERT INTO `municipio` VALUES (1669,21,84,'Ixtepec');
INSERT INTO `municipio` VALUES (1670,21,85,'Izúcar de Matamoros');
INSERT INTO `municipio` VALUES (1671,21,86,'Jalpan');
INSERT INTO `municipio` VALUES (1672,21,87,'Jolalpan');
INSERT INTO `municipio` VALUES (1673,21,88,'Jonotla');
INSERT INTO `municipio` VALUES (1674,21,89,'Jopala');
INSERT INTO `municipio` VALUES (1675,21,90,'Juan C. Bonilla');
INSERT INTO `municipio` VALUES (1676,21,91,'Juan Galindo');
INSERT INTO `municipio` VALUES (1677,21,92,'Juan N. Méndez');
INSERT INTO `municipio` VALUES (1678,21,93,'Lafragua');
INSERT INTO `municipio` VALUES (1679,21,94,'Libres');
INSERT INTO `municipio` VALUES (1680,21,95,'La Magdalena Tlatlauquitepec');
INSERT INTO `municipio` VALUES (1681,21,96,'Mazapiltepec de Juárez');
INSERT INTO `municipio` VALUES (1682,21,97,'Mixtla');
INSERT INTO `municipio` VALUES (1683,21,98,'Molcaxac');
INSERT INTO `municipio` VALUES (1684,21,99,'Cañada Morelos');
INSERT INTO `municipio` VALUES (1685,21,100,'Naupan');
INSERT INTO `municipio` VALUES (1686,21,101,'Nauzontla');
INSERT INTO `municipio` VALUES (1687,21,102,'Nealtican');
INSERT INTO `municipio` VALUES (1688,21,103,'Nicolás Bravo');
INSERT INTO `municipio` VALUES (1689,21,104,'Nopalucan');
INSERT INTO `municipio` VALUES (1690,21,105,'Ocotepec');
INSERT INTO `municipio` VALUES (1691,21,106,'Ocoyucan');
INSERT INTO `municipio` VALUES (1692,21,107,'Olintla');
INSERT INTO `municipio` VALUES (1693,21,108,'Oriental');
INSERT INTO `municipio` VALUES (1694,21,109,'Pahuatlán');
INSERT INTO `municipio` VALUES (1695,21,110,'Palmar de Bravo');
INSERT INTO `municipio` VALUES (1696,21,111,'Pantepec');
INSERT INTO `municipio` VALUES (1697,21,112,'Petlalcingo');
INSERT INTO `municipio` VALUES (1698,21,113,'Piaxtla');
INSERT INTO `municipio` VALUES (1699,21,114,'Puebla');
INSERT INTO `municipio` VALUES (1700,21,115,'Quecholac');
INSERT INTO `municipio` VALUES (1701,21,116,'Quimixtlán');
INSERT INTO `municipio` VALUES (1702,21,117,'Rafael Lara Grajales');
INSERT INTO `municipio` VALUES (1703,21,118,'Los Reyes de Juárez');
INSERT INTO `municipio` VALUES (1704,21,119,'San Andrés Cholula');
INSERT INTO `municipio` VALUES (1705,21,120,'San Antonio Cañada');
INSERT INTO `municipio` VALUES (1706,21,121,'San Diego la Mesa Tochimiltzingo');
INSERT INTO `municipio` VALUES (1707,21,122,'San Felipe Teotlalcingo');
INSERT INTO `municipio` VALUES (1708,21,123,'San Felipe Tepatlán');
INSERT INTO `municipio` VALUES (1709,21,124,'San Gabriel Chilac');
INSERT INTO `municipio` VALUES (1710,21,125,'San Gregorio Atzompa');
INSERT INTO `municipio` VALUES (1711,21,126,'San Jerónimo Tecuanipan');
INSERT INTO `municipio` VALUES (1712,21,127,'San Jerónimo Xayacatlán');
INSERT INTO `municipio` VALUES (1713,21,128,'San José Chiapa');
INSERT INTO `municipio` VALUES (1714,21,129,'San José Miahuatlán');
INSERT INTO `municipio` VALUES (1715,21,130,'San Juan Atenco');
INSERT INTO `municipio` VALUES (1716,21,131,'San Juan Atzompa');
INSERT INTO `municipio` VALUES (1717,21,132,'San Martín Texmelucan');
INSERT INTO `municipio` VALUES (1718,21,133,'San Martín Totoltepec');
INSERT INTO `municipio` VALUES (1719,21,134,'San Matías Tlalancaleca');
INSERT INTO `municipio` VALUES (1720,21,135,'San Miguel Ixitlán');
INSERT INTO `municipio` VALUES (1721,21,136,'San Miguel Xoxtla');
INSERT INTO `municipio` VALUES (1722,21,137,'San Nicolás Buenos Aires');
INSERT INTO `municipio` VALUES (1723,21,138,'San Nicolás de los Ranchos');
INSERT INTO `municipio` VALUES (1724,21,139,'San Pablo Anicano');
INSERT INTO `municipio` VALUES (1725,21,140,'San Pedro Cholula');
INSERT INTO `municipio` VALUES (1726,21,141,'San Pedro Yeloixtlahuaca');
INSERT INTO `municipio` VALUES (1727,21,142,'San Salvador el Seco');
INSERT INTO `municipio` VALUES (1728,21,143,'San Salvador el Verde');
INSERT INTO `municipio` VALUES (1729,21,144,'San Salvador Huixcolotla');
INSERT INTO `municipio` VALUES (1730,21,145,'San Sebastián Tlacotepec');
INSERT INTO `municipio` VALUES (1731,21,146,'Santa Catarina Tlaltempan');
INSERT INTO `municipio` VALUES (1732,21,147,'Santa Inés Ahuatempan');
INSERT INTO `municipio` VALUES (1733,21,148,'Santa Isabel Cholula');
INSERT INTO `municipio` VALUES (1734,21,149,'Santiago Miahuatlán');
INSERT INTO `municipio` VALUES (1735,21,150,'Huehuetlán el Grande');
INSERT INTO `municipio` VALUES (1736,21,151,'Santo Tomás Hueyotlipan');
INSERT INTO `municipio` VALUES (1737,21,152,'Soltepec');
INSERT INTO `municipio` VALUES (1738,21,153,'Tecali de Herrera');
INSERT INTO `municipio` VALUES (1739,21,154,'Tecamachalco');
INSERT INTO `municipio` VALUES (1740,21,155,'Tecomatlán');
INSERT INTO `municipio` VALUES (1741,21,156,'Tehuacán');
INSERT INTO `municipio` VALUES (1742,21,157,'Tehuitzingo');
INSERT INTO `municipio` VALUES (1743,21,158,'Tenampulco');
INSERT INTO `municipio` VALUES (1744,21,159,'Teopantlán');
INSERT INTO `municipio` VALUES (1745,21,160,'Teotlalco');
INSERT INTO `municipio` VALUES (1746,21,161,'Tepanco de López');
INSERT INTO `municipio` VALUES (1747,21,162,'Tepango de Rodríguez');
INSERT INTO `municipio` VALUES (1748,21,163,'Tepatlaxco de Hidalgo');
INSERT INTO `municipio` VALUES (1749,21,164,'Tepeaca');
INSERT INTO `municipio` VALUES (1750,21,165,'Tepemaxalco');
INSERT INTO `municipio` VALUES (1751,21,166,'Tepeojuma');
INSERT INTO `municipio` VALUES (1752,21,167,'Tepetzintla');
INSERT INTO `municipio` VALUES (1753,21,168,'Tepexco');
INSERT INTO `municipio` VALUES (1754,21,169,'Tepexi de Rodríguez');
INSERT INTO `municipio` VALUES (1755,21,170,'Tepeyahualco');
INSERT INTO `municipio` VALUES (1756,21,171,'Tepeyahualco de Cuauhtémoc');
INSERT INTO `municipio` VALUES (1757,21,172,'Tetela de Ocampo');
INSERT INTO `municipio` VALUES (1758,21,173,'Teteles de Ávila Castillo');
INSERT INTO `municipio` VALUES (1759,21,174,'Teziutlán');
INSERT INTO `municipio` VALUES (1760,21,175,'Tianguismanalco');
INSERT INTO `municipio` VALUES (1761,21,176,'Tilapa');
INSERT INTO `municipio` VALUES (1762,21,177,'Tlacotepec de Benito Juárez');
INSERT INTO `municipio` VALUES (1763,21,178,'Tlacuilotepec');
INSERT INTO `municipio` VALUES (1764,21,179,'Tlachichuca');
INSERT INTO `municipio` VALUES (1765,21,180,'Tlahuapan');
INSERT INTO `municipio` VALUES (1766,21,181,'Tlaltenango');
INSERT INTO `municipio` VALUES (1767,21,182,'Tlanepantla');
INSERT INTO `municipio` VALUES (1768,21,183,'Tlaola');
INSERT INTO `municipio` VALUES (1769,21,184,'Tlapacoya');
INSERT INTO `municipio` VALUES (1770,21,185,'Tlapanalá');
INSERT INTO `municipio` VALUES (1771,21,186,'Tlatlauquitepec');
INSERT INTO `municipio` VALUES (1772,21,187,'Tlaxco');
INSERT INTO `municipio` VALUES (1773,21,188,'Tochimilco');
INSERT INTO `municipio` VALUES (1774,21,189,'Tochtepec');
INSERT INTO `municipio` VALUES (1775,21,190,'Totoltepec de Guerrero');
INSERT INTO `municipio` VALUES (1776,21,191,'Tulcingo');
INSERT INTO `municipio` VALUES (1777,21,192,'Tuzamapan de Galeana');
INSERT INTO `municipio` VALUES (1778,21,193,'Tzicatlacoyan');
INSERT INTO `municipio` VALUES (1779,21,194,'Venustiano Carranza');
INSERT INTO `municipio` VALUES (1780,21,195,'Vicente Guerrero');
INSERT INTO `municipio` VALUES (1781,21,196,'Xayacatlán de Bravo');
INSERT INTO `municipio` VALUES (1782,21,197,'Xicotepec');
INSERT INTO `municipio` VALUES (1783,21,198,'Xicotlán');
INSERT INTO `municipio` VALUES (1784,21,199,'Xiutetelco');
INSERT INTO `municipio` VALUES (1785,21,200,'Xochiapulco');
INSERT INTO `municipio` VALUES (1786,21,201,'Xochiltepec');
INSERT INTO `municipio` VALUES (1787,21,202,'Xochitlán de Vicente Suárez');
INSERT INTO `municipio` VALUES (1788,21,203,'Xochitlán Todos Santos');
INSERT INTO `municipio` VALUES (1789,21,204,'Yaonáhuac');
INSERT INTO `municipio` VALUES (1790,21,205,'Yehualtepec');
INSERT INTO `municipio` VALUES (1791,21,206,'Zacapala');
INSERT INTO `municipio` VALUES (1792,21,207,'Zacapoaxtla');
INSERT INTO `municipio` VALUES (1793,21,208,'Zacatlán');
INSERT INTO `municipio` VALUES (1794,21,209,'Zapotitlán');
INSERT INTO `municipio` VALUES (1795,21,210,'Zapotitlán de Méndez');
INSERT INTO `municipio` VALUES (1796,21,211,'Zaragoza');
INSERT INTO `municipio` VALUES (1797,21,212,'Zautla');
INSERT INTO `municipio` VALUES (1798,21,213,'Zihuateutla');
INSERT INTO `municipio` VALUES (1799,21,214,'Zinacatepec');
INSERT INTO `municipio` VALUES (1800,21,215,'Zongozotla');
INSERT INTO `municipio` VALUES (1801,21,216,'Zoquiapan');
INSERT INTO `municipio` VALUES (1802,21,217,'Zoquitlán');
INSERT INTO `municipio` VALUES (1803,22,1,'Amealco de Bonfil');
INSERT INTO `municipio` VALUES (1804,22,2,'Pinal de Amoles');
INSERT INTO `municipio` VALUES (1805,22,3,'Arroyo Seco');
INSERT INTO `municipio` VALUES (1806,22,4,'Cadereyta de Montes');
INSERT INTO `municipio` VALUES (1807,22,5,'Colón');
INSERT INTO `municipio` VALUES (1808,22,6,'Corregidora');
INSERT INTO `municipio` VALUES (1809,22,7,'Ezequiel Montes');
INSERT INTO `municipio` VALUES (1810,22,8,'Huimilpan');
INSERT INTO `municipio` VALUES (1811,22,9,'Jalpan de Serra');
INSERT INTO `municipio` VALUES (1812,22,10,'Landa de Matamoros');
INSERT INTO `municipio` VALUES (1813,22,11,'El Marqués');
INSERT INTO `municipio` VALUES (1814,22,12,'Pedro Escobedo');
INSERT INTO `municipio` VALUES (1815,22,13,'Peñamiller');
INSERT INTO `municipio` VALUES (1816,22,14,'Querétaro');
INSERT INTO `municipio` VALUES (1817,22,15,'San Joaquín');
INSERT INTO `municipio` VALUES (1818,22,16,'San Juan del Río');
INSERT INTO `municipio` VALUES (1819,22,17,'Tequisquiapan');
INSERT INTO `municipio` VALUES (1820,22,18,'Tolimán');
INSERT INTO `municipio` VALUES (1821,23,1,'Cozumel');
INSERT INTO `municipio` VALUES (1822,23,2,'Felipe Carrillo Puerto');
INSERT INTO `municipio` VALUES (1823,23,3,'Isla Mujeres');
INSERT INTO `municipio` VALUES (1824,23,4,'Othón P. Blanco');
INSERT INTO `municipio` VALUES (1825,23,5,'Benito Juárez');
INSERT INTO `municipio` VALUES (1826,23,6,'José María Morelos');
INSERT INTO `municipio` VALUES (1827,23,7,'Lázaro Cárdenas');
INSERT INTO `municipio` VALUES (1828,23,8,'Playa del Carmen');
INSERT INTO `municipio` VALUES (1829,23,9,'Tulum');
INSERT INTO `municipio` VALUES (1830,23,10,'Bacalar');
INSERT INTO `municipio` VALUES (1831,23,11,'Puerto Morelos');
INSERT INTO `municipio` VALUES (1832,24,1,'Ahualulco del Sonido 13');
INSERT INTO `municipio` VALUES (1833,24,2,'Alaquines');
INSERT INTO `municipio` VALUES (1834,24,3,'Aquismón');
INSERT INTO `municipio` VALUES (1835,24,4,'Armadillo de los Infante');
INSERT INTO `municipio` VALUES (1836,24,5,'Cárdenas');
INSERT INTO `municipio` VALUES (1837,24,6,'Catorce');
INSERT INTO `municipio` VALUES (1838,24,7,'Cedral');
INSERT INTO `municipio` VALUES (1839,24,8,'Cerritos');
INSERT INTO `municipio` VALUES (1840,24,9,'Cerro de San Pedro');
INSERT INTO `municipio` VALUES (1841,24,10,'Ciudad del Maíz');
INSERT INTO `municipio` VALUES (1842,24,11,'Ciudad Fernández');
INSERT INTO `municipio` VALUES (1843,24,12,'Tancanhuitz');
INSERT INTO `municipio` VALUES (1844,24,13,'Ciudad Valles');
INSERT INTO `municipio` VALUES (1845,24,14,'Coxcatlán');
INSERT INTO `municipio` VALUES (1846,24,15,'Charcas');
INSERT INTO `municipio` VALUES (1847,24,16,'Ebano');
INSERT INTO `municipio` VALUES (1848,24,17,'Guadalcázar');
INSERT INTO `municipio` VALUES (1849,24,18,'Huehuetlán');
INSERT INTO `municipio` VALUES (1850,24,19,'Lagunillas');
INSERT INTO `municipio` VALUES (1851,24,20,'Matehuala');
INSERT INTO `municipio` VALUES (1852,24,21,'Mexquitic de Carmona');
INSERT INTO `municipio` VALUES (1853,24,22,'Moctezuma');
INSERT INTO `municipio` VALUES (1854,24,23,'Rayón');
INSERT INTO `municipio` VALUES (1855,24,24,'Rioverde');
INSERT INTO `municipio` VALUES (1856,24,25,'Salinas');
INSERT INTO `municipio` VALUES (1857,24,26,'San Antonio');
INSERT INTO `municipio` VALUES (1858,24,27,'San Ciro de Acosta');
INSERT INTO `municipio` VALUES (1859,24,28,'San Luis Potosí');
INSERT INTO `municipio` VALUES (1860,24,29,'San Martín Chalchicuautla');
INSERT INTO `municipio` VALUES (1861,24,30,'San Nicolás Tolentino');
INSERT INTO `municipio` VALUES (1862,24,31,'Santa Catarina');
INSERT INTO `municipio` VALUES (1863,24,32,'Santa María del Río');
INSERT INTO `municipio` VALUES (1864,24,33,'Santo Domingo');
INSERT INTO `municipio` VALUES (1865,24,34,'San Vicente Tancuayalab');
INSERT INTO `municipio` VALUES (1866,24,35,'Soledad de Graciano Sánchez');
INSERT INTO `municipio` VALUES (1867,24,36,'Tamasopo');
INSERT INTO `municipio` VALUES (1868,24,37,'Tamazunchale');
INSERT INTO `municipio` VALUES (1869,24,38,'Tampacán');
INSERT INTO `municipio` VALUES (1870,24,39,'Tampamolón Corona');
INSERT INTO `municipio` VALUES (1871,24,40,'Tamuín');
INSERT INTO `municipio` VALUES (1872,24,41,'Tanlajás');
INSERT INTO `municipio` VALUES (1873,24,42,'Tanquián de Escobedo');
INSERT INTO `municipio` VALUES (1874,24,43,'Tierra Nueva');
INSERT INTO `municipio` VALUES (1875,24,44,'Vanegas');
INSERT INTO `municipio` VALUES (1876,24,45,'Venado');
INSERT INTO `municipio` VALUES (1877,24,46,'Villa de Arriaga');
INSERT INTO `municipio` VALUES (1878,24,47,'Villa de Guadalupe');
INSERT INTO `municipio` VALUES (1879,24,48,'Villa de la Paz');
INSERT INTO `municipio` VALUES (1880,24,49,'Villa de Ramos');
INSERT INTO `municipio` VALUES (1881,24,50,'Villa de Reyes');
INSERT INTO `municipio` VALUES (1882,24,51,'Villa Hidalgo');
INSERT INTO `municipio` VALUES (1883,24,52,'Villa Juárez');
INSERT INTO `municipio` VALUES (1884,24,53,'Axtla de Terrazas');
INSERT INTO `municipio` VALUES (1885,24,54,'Xilitla');
INSERT INTO `municipio` VALUES (1886,24,55,'Zaragoza');
INSERT INTO `municipio` VALUES (1887,24,56,'Villa de Arista');
INSERT INTO `municipio` VALUES (1888,24,57,'Matlapa');
INSERT INTO `municipio` VALUES (1889,24,58,'El Naranjo');
INSERT INTO `municipio` VALUES (1890,24,59,'Villa de Pozos');
INSERT INTO `municipio` VALUES (1891,25,1,'Ahome');
INSERT INTO `municipio` VALUES (1892,25,2,'Angostura');
INSERT INTO `municipio` VALUES (1893,25,3,'Badiraguato');
INSERT INTO `municipio` VALUES (1894,25,4,'Concordia');
INSERT INTO `municipio` VALUES (1895,25,5,'Cosalá');
INSERT INTO `municipio` VALUES (1896,25,6,'Culiacán');
INSERT INTO `municipio` VALUES (1897,25,7,'Choix');
INSERT INTO `municipio` VALUES (1898,25,8,'Elota');
INSERT INTO `municipio` VALUES (1899,25,9,'Escuinapa');
INSERT INTO `municipio` VALUES (1900,25,10,'El Fuerte');
INSERT INTO `municipio` VALUES (1901,25,11,'Guasave');
INSERT INTO `municipio` VALUES (1902,25,12,'Mazatlán');
INSERT INTO `municipio` VALUES (1903,25,13,'Mocorito');
INSERT INTO `municipio` VALUES (1904,25,14,'Rosario');
INSERT INTO `municipio` VALUES (1905,25,15,'Salvador Alvarado');
INSERT INTO `municipio` VALUES (1906,25,16,'San Ignacio');
INSERT INTO `municipio` VALUES (1907,25,17,'Sinaloa');
INSERT INTO `municipio` VALUES (1908,25,18,'Navolato');
INSERT INTO `municipio` VALUES (1909,25,19,'Eldorado');
INSERT INTO `municipio` VALUES (1910,25,20,'Juan José Ríos');
INSERT INTO `municipio` VALUES (1911,26,1,'Aconchi');
INSERT INTO `municipio` VALUES (1912,26,2,'Agua Prieta');
INSERT INTO `municipio` VALUES (1913,26,3,'Álamos');
INSERT INTO `municipio` VALUES (1914,26,4,'Altar');
INSERT INTO `municipio` VALUES (1915,26,5,'Arivechi');
INSERT INTO `municipio` VALUES (1916,26,6,'Arizpe');
INSERT INTO `municipio` VALUES (1917,26,7,'Atil');
INSERT INTO `municipio` VALUES (1918,26,8,'Bacadéhuachi');
INSERT INTO `municipio` VALUES (1919,26,9,'Bacanora');
INSERT INTO `municipio` VALUES (1920,26,10,'Bacerac');
INSERT INTO `municipio` VALUES (1921,26,11,'Bacoachi');
INSERT INTO `municipio` VALUES (1922,26,12,'Bácum');
INSERT INTO `municipio` VALUES (1923,26,13,'Banámichi');
INSERT INTO `municipio` VALUES (1924,26,14,'Baviácora');
INSERT INTO `municipio` VALUES (1925,26,15,'Bavispe');
INSERT INTO `municipio` VALUES (1926,26,16,'Benjamín Hill');
INSERT INTO `municipio` VALUES (1927,26,17,'Caborca');
INSERT INTO `municipio` VALUES (1928,26,18,'Cajeme');
INSERT INTO `municipio` VALUES (1929,26,19,'Cananea');
INSERT INTO `municipio` VALUES (1930,26,20,'Carbó');
INSERT INTO `municipio` VALUES (1931,26,21,'La Colorada');
INSERT INTO `municipio` VALUES (1932,26,22,'Cucurpe');
INSERT INTO `municipio` VALUES (1933,26,23,'Cumpas');
INSERT INTO `municipio` VALUES (1934,26,24,'Divisaderos');
INSERT INTO `municipio` VALUES (1935,26,25,'Empalme');
INSERT INTO `municipio` VALUES (1936,26,26,'Etchojoa');
INSERT INTO `municipio` VALUES (1937,26,27,'Fronteras');
INSERT INTO `municipio` VALUES (1938,26,28,'Granados');
INSERT INTO `municipio` VALUES (1939,26,29,'Guaymas');
INSERT INTO `municipio` VALUES (1940,26,30,'Hermosillo');
INSERT INTO `municipio` VALUES (1941,26,31,'Huachinera');
INSERT INTO `municipio` VALUES (1942,26,32,'Huásabas');
INSERT INTO `municipio` VALUES (1943,26,33,'Huatabampo');
INSERT INTO `municipio` VALUES (1944,26,34,'Huépac');
INSERT INTO `municipio` VALUES (1945,26,35,'Imuris');
INSERT INTO `municipio` VALUES (1946,26,36,'Magdalena');
INSERT INTO `municipio` VALUES (1947,26,37,'Mazatán');
INSERT INTO `municipio` VALUES (1948,26,38,'Moctezuma');
INSERT INTO `municipio` VALUES (1949,26,39,'Naco');
INSERT INTO `municipio` VALUES (1950,26,40,'Nácori Chico');
INSERT INTO `municipio` VALUES (1951,26,41,'Nacozari de García');
INSERT INTO `municipio` VALUES (1952,26,42,'Navojoa');
INSERT INTO `municipio` VALUES (1953,26,43,'Nogales');
INSERT INTO `municipio` VALUES (1954,26,44,'Ónavas');
INSERT INTO `municipio` VALUES (1955,26,45,'Opodepe');
INSERT INTO `municipio` VALUES (1956,26,46,'Oquitoa');
INSERT INTO `municipio` VALUES (1957,26,47,'Pitiquito');
INSERT INTO `municipio` VALUES (1958,26,48,'Puerto Peñasco');
INSERT INTO `municipio` VALUES (1959,26,49,'Quiriego');
INSERT INTO `municipio` VALUES (1960,26,50,'Rayón');
INSERT INTO `municipio` VALUES (1961,26,51,'Rosario');
INSERT INTO `municipio` VALUES (1962,26,52,'Sahuaripa');
INSERT INTO `municipio` VALUES (1963,26,53,'San Felipe de Jesús');
INSERT INTO `municipio` VALUES (1964,26,54,'San Javier');
INSERT INTO `municipio` VALUES (1965,26,55,'San Luis Río Colorado');
INSERT INTO `municipio` VALUES (1966,26,56,'San Miguel de Horcasitas');
INSERT INTO `municipio` VALUES (1967,26,57,'San Pedro de la Cueva');
INSERT INTO `municipio` VALUES (1968,26,58,'Santa Ana');
INSERT INTO `municipio` VALUES (1969,26,59,'Santa Cruz');
INSERT INTO `municipio` VALUES (1970,26,60,'Sáric');
INSERT INTO `municipio` VALUES (1971,26,61,'Soyopa');
INSERT INTO `municipio` VALUES (1972,26,62,'Suaqui Grande');
INSERT INTO `municipio` VALUES (1973,26,63,'Tepache');
INSERT INTO `municipio` VALUES (1974,26,64,'Trincheras');
INSERT INTO `municipio` VALUES (1975,26,65,'Tubutama');
INSERT INTO `municipio` VALUES (1976,26,66,'Ures');
INSERT INTO `municipio` VALUES (1977,26,67,'Villa Hidalgo');
INSERT INTO `municipio` VALUES (1978,26,68,'Villa Pesqueira');
INSERT INTO `municipio` VALUES (1979,26,69,'Yécora');
INSERT INTO `municipio` VALUES (1980,26,70,'General Plutarco Elías Calles');
INSERT INTO `municipio` VALUES (1981,26,71,'Benito Juárez');
INSERT INTO `municipio` VALUES (1982,26,72,'San Ignacio Río Muerto');
INSERT INTO `municipio` VALUES (1983,27,1,'Balancán');
INSERT INTO `municipio` VALUES (1984,27,2,'Cárdenas');
INSERT INTO `municipio` VALUES (1985,27,3,'Centla');
INSERT INTO `municipio` VALUES (1986,27,4,'Centro');
INSERT INTO `municipio` VALUES (1987,27,5,'Comalcalco');
INSERT INTO `municipio` VALUES (1988,27,6,'Cunduacán');
INSERT INTO `municipio` VALUES (1989,27,7,'Emiliano Zapata');
INSERT INTO `municipio` VALUES (1990,27,8,'Huimanguillo');
INSERT INTO `municipio` VALUES (1991,27,9,'Jalapa');
INSERT INTO `municipio` VALUES (1992,27,10,'Jalpa de Méndez');
INSERT INTO `municipio` VALUES (1993,27,11,'Jonuta');
INSERT INTO `municipio` VALUES (1994,27,12,'Macuspana');
INSERT INTO `municipio` VALUES (1995,27,13,'Nacajuca');
INSERT INTO `municipio` VALUES (1996,27,14,'Paraíso');
INSERT INTO `municipio` VALUES (1997,27,15,'Tacotalpa');
INSERT INTO `municipio` VALUES (1998,27,16,'Teapa');
INSERT INTO `municipio` VALUES (1999,27,17,'Tenosique');
INSERT INTO `municipio` VALUES (2000,28,1,'Abasolo');
INSERT INTO `municipio` VALUES (2001,28,2,'Aldama');
INSERT INTO `municipio` VALUES (2002,28,3,'Altamira');
INSERT INTO `municipio` VALUES (2003,28,4,'Antiguo Morelos');
INSERT INTO `municipio` VALUES (2004,28,5,'Burgos');
INSERT INTO `municipio` VALUES (2005,28,6,'Bustamante');
INSERT INTO `municipio` VALUES (2006,28,7,'Camargo');
INSERT INTO `municipio` VALUES (2007,28,8,'Casas');
INSERT INTO `municipio` VALUES (2008,28,9,'Ciudad Madero');
INSERT INTO `municipio` VALUES (2009,28,10,'Cruillas');
INSERT INTO `municipio` VALUES (2010,28,11,'Gómez Farías');
INSERT INTO `municipio` VALUES (2011,28,12,'González');
INSERT INTO `municipio` VALUES (2012,28,13,'Güémez');
INSERT INTO `municipio` VALUES (2013,28,14,'Guerrero');
INSERT INTO `municipio` VALUES (2014,28,15,'Gustavo Díaz Ordaz');
INSERT INTO `municipio` VALUES (2015,28,16,'Hidalgo');
INSERT INTO `municipio` VALUES (2016,28,17,'Jaumave');
INSERT INTO `municipio` VALUES (2017,28,18,'Jiménez');
INSERT INTO `municipio` VALUES (2018,28,19,'Llera');
INSERT INTO `municipio` VALUES (2019,28,20,'Mainero');
INSERT INTO `municipio` VALUES (2020,28,21,'El Mante');
INSERT INTO `municipio` VALUES (2021,28,22,'Matamoros');
INSERT INTO `municipio` VALUES (2022,28,23,'Méndez');
INSERT INTO `municipio` VALUES (2023,28,24,'Mier');
INSERT INTO `municipio` VALUES (2024,28,25,'Miguel Alemán');
INSERT INTO `municipio` VALUES (2025,28,26,'Miquihuana');
INSERT INTO `municipio` VALUES (2026,28,27,'Nuevo Laredo');
INSERT INTO `municipio` VALUES (2027,28,28,'Nuevo Morelos');
INSERT INTO `municipio` VALUES (2028,28,29,'Ocampo');
INSERT INTO `municipio` VALUES (2029,28,30,'Padilla');
INSERT INTO `municipio` VALUES (2030,28,31,'Palmillas');
INSERT INTO `municipio` VALUES (2031,28,32,'Reynosa');
INSERT INTO `municipio` VALUES (2032,28,33,'Río Bravo');
INSERT INTO `municipio` VALUES (2033,28,34,'San Carlos');
INSERT INTO `municipio` VALUES (2034,28,35,'San Fernando');
INSERT INTO `municipio` VALUES (2035,28,36,'San Nicolás');
INSERT INTO `municipio` VALUES (2036,28,37,'Soto la Marina');
INSERT INTO `municipio` VALUES (2037,28,38,'Tampico');
INSERT INTO `municipio` VALUES (2038,28,39,'Tula');
INSERT INTO `municipio` VALUES (2039,28,40,'Valle Hermoso');
INSERT INTO `municipio` VALUES (2040,28,41,'Victoria');
INSERT INTO `municipio` VALUES (2041,28,42,'Villagrán');
INSERT INTO `municipio` VALUES (2042,28,43,'Xicoténcatl');
INSERT INTO `municipio` VALUES (2043,29,1,'Amaxac de Guerrero');
INSERT INTO `municipio` VALUES (2044,29,2,'Apetatitlán de Antonio Carvajal');
INSERT INTO `municipio` VALUES (2045,29,3,'Atlangatepec');
INSERT INTO `municipio` VALUES (2046,29,4,'Atltzayanca');
INSERT INTO `municipio` VALUES (2047,29,5,'Apizaco');
INSERT INTO `municipio` VALUES (2048,29,6,'Calpulalpan');
INSERT INTO `municipio` VALUES (2049,29,7,'El Carmen Tequexquitla');
INSERT INTO `municipio` VALUES (2050,29,8,'Cuapiaxtla');
INSERT INTO `municipio` VALUES (2051,29,9,'Cuaxomulco');
INSERT INTO `municipio` VALUES (2052,29,10,'Chiautempan');
INSERT INTO `municipio` VALUES (2053,29,11,'Muñoz de Domingo Arenas');
INSERT INTO `municipio` VALUES (2054,29,12,'Españita');
INSERT INTO `municipio` VALUES (2055,29,13,'Huamantla');
INSERT INTO `municipio` VALUES (2056,29,14,'Hueyotlipan');
INSERT INTO `municipio` VALUES (2057,29,15,'Ixtacuixtla de Mariano Matamoros');
INSERT INTO `municipio` VALUES (2058,29,16,'Ixtenco');
INSERT INTO `municipio` VALUES (2059,29,17,'Mazatecochco de José María Morelos');
INSERT INTO `municipio` VALUES (2060,29,18,'Contla de Juan Cuamatzi');
INSERT INTO `municipio` VALUES (2061,29,19,'Tepetitla de Lardizábal');
INSERT INTO `municipio` VALUES (2062,29,20,'Sanctórum de Lázaro Cárdenas');
INSERT INTO `municipio` VALUES (2063,29,21,'Nanacamilpa de Mariano Arista');
INSERT INTO `municipio` VALUES (2064,29,22,'Acuamanala de Miguel Hidalgo');
INSERT INTO `municipio` VALUES (2065,29,23,'Natívitas');
INSERT INTO `municipio` VALUES (2066,29,24,'Panotla');
INSERT INTO `municipio` VALUES (2067,29,25,'San Pablo del Monte');
INSERT INTO `municipio` VALUES (2068,29,26,'Santa Cruz Tlaxcala');
INSERT INTO `municipio` VALUES (2069,29,27,'Tenancingo');
INSERT INTO `municipio` VALUES (2070,29,28,'Teolocholco');
INSERT INTO `municipio` VALUES (2071,29,29,'Tepeyanco');
INSERT INTO `municipio` VALUES (2072,29,30,'Terrenate');
INSERT INTO `municipio` VALUES (2073,29,31,'Tetla de la Solidaridad');
INSERT INTO `municipio` VALUES (2074,29,32,'Tetlatlahuca');
INSERT INTO `municipio` VALUES (2075,29,33,'Tlaxcala');
INSERT INTO `municipio` VALUES (2076,29,34,'Tlaxco');
INSERT INTO `municipio` VALUES (2077,29,35,'Tocatlán');
INSERT INTO `municipio` VALUES (2078,29,36,'Totolac');
INSERT INTO `municipio` VALUES (2079,29,37,'Ziltlaltépec de Trinidad Sánchez Santos');
INSERT INTO `municipio` VALUES (2080,29,38,'Tzompantepec');
INSERT INTO `municipio` VALUES (2081,29,39,'Xaloztoc');
INSERT INTO `municipio` VALUES (2082,29,40,'Xaltocan');
INSERT INTO `municipio` VALUES (2083,29,41,'Papalotla de Xicohténcatl');
INSERT INTO `municipio` VALUES (2084,29,42,'Xicohtzinco');
INSERT INTO `municipio` VALUES (2085,29,43,'Yauhquemehcan');
INSERT INTO `municipio` VALUES (2086,29,44,'Zacatelco');
INSERT INTO `municipio` VALUES (2087,29,45,'Benito Juárez');
INSERT INTO `municipio` VALUES (2088,29,46,'Emiliano Zapata');
INSERT INTO `municipio` VALUES (2089,29,47,'Lázaro Cárdenas');
INSERT INTO `municipio` VALUES (2090,29,48,'La Magdalena Tlaltelulco');
INSERT INTO `municipio` VALUES (2091,29,49,'San Damián Texóloc');
INSERT INTO `municipio` VALUES (2092,29,50,'San Francisco Tetlanohcan');
INSERT INTO `municipio` VALUES (2093,29,51,'San Jerónimo Zacualpan');
INSERT INTO `municipio` VALUES (2094,29,52,'San José Teacalco');
INSERT INTO `municipio` VALUES (2095,29,53,'San Juan Huactzinco');
INSERT INTO `municipio` VALUES (2096,29,54,'San Lorenzo Axocomanitla');
INSERT INTO `municipio` VALUES (2097,29,55,'San Lucas Tecopilco');
INSERT INTO `municipio` VALUES (2098,29,56,'Santa Ana Nopalucan');
INSERT INTO `municipio` VALUES (2099,29,57,'Santa Apolonia Teacalco');
INSERT INTO `municipio` VALUES (2100,29,58,'Santa Catarina Ayometla');
INSERT INTO `municipio` VALUES (2101,29,59,'Santa Cruz Quilehtla');
INSERT INTO `municipio` VALUES (2102,29,60,'Santa Isabel Xiloxoxtla');
INSERT INTO `municipio` VALUES (2103,30,1,'Acajete');
INSERT INTO `municipio` VALUES (2104,30,2,'Acatlán');
INSERT INTO `municipio` VALUES (2105,30,3,'Acayucan');
INSERT INTO `municipio` VALUES (2106,30,4,'Actopan');
INSERT INTO `municipio` VALUES (2107,30,5,'Acula');
INSERT INTO `municipio` VALUES (2108,30,6,'Acultzingo');
INSERT INTO `municipio` VALUES (2109,30,7,'Camarón de Tejeda');
INSERT INTO `municipio` VALUES (2110,30,8,'Alpatláhuac');
INSERT INTO `municipio` VALUES (2111,30,9,'Alto Lucero de Gutiérrez Barrios');
INSERT INTO `municipio` VALUES (2112,30,10,'Altotonga');
INSERT INTO `municipio` VALUES (2113,30,11,'Alvarado');
INSERT INTO `municipio` VALUES (2114,30,12,'Amatitlán');
INSERT INTO `municipio` VALUES (2115,30,13,'Naranjos Amatlán');
INSERT INTO `municipio` VALUES (2116,30,14,'Amatlán de los Reyes');
INSERT INTO `municipio` VALUES (2117,30,15,'Angel R. Cabada');
INSERT INTO `municipio` VALUES (2118,30,16,'La Antigua');
INSERT INTO `municipio` VALUES (2119,30,17,'Apazapan');
INSERT INTO `municipio` VALUES (2120,30,18,'Aquila');
INSERT INTO `municipio` VALUES (2121,30,19,'Astacinga');
INSERT INTO `municipio` VALUES (2122,30,20,'Atlahuilco');
INSERT INTO `municipio` VALUES (2123,30,21,'Atoyac');
INSERT INTO `municipio` VALUES (2124,30,22,'Atzacan');
INSERT INTO `municipio` VALUES (2125,30,23,'Atzalan');
INSERT INTO `municipio` VALUES (2126,30,24,'Tlaltetela');
INSERT INTO `municipio` VALUES (2127,30,25,'Ayahualulco');
INSERT INTO `municipio` VALUES (2128,30,26,'Banderilla');
INSERT INTO `municipio` VALUES (2129,30,27,'Benito Juárez');
INSERT INTO `municipio` VALUES (2130,30,28,'Boca del Río');
INSERT INTO `municipio` VALUES (2131,30,29,'Calcahualco');
INSERT INTO `municipio` VALUES (2132,30,30,'Camerino Z. Mendoza');
INSERT INTO `municipio` VALUES (2133,30,31,'Carrillo Puerto');
INSERT INTO `municipio` VALUES (2134,30,32,'Catemaco');
INSERT INTO `municipio` VALUES (2135,30,33,'Cazones de Herrera');
INSERT INTO `municipio` VALUES (2136,30,34,'Cerro Azul');
INSERT INTO `municipio` VALUES (2137,30,35,'Citlaltépetl');
INSERT INTO `municipio` VALUES (2138,30,36,'Coacoatzintla');
INSERT INTO `municipio` VALUES (2139,30,37,'Coahuitlán');
INSERT INTO `municipio` VALUES (2140,30,38,'Coatepec');
INSERT INTO `municipio` VALUES (2141,30,39,'Coatzacoalcos');
INSERT INTO `municipio` VALUES (2142,30,40,'Coatzintla');
INSERT INTO `municipio` VALUES (2143,30,41,'Coetzala');
INSERT INTO `municipio` VALUES (2144,30,42,'Colipa');
INSERT INTO `municipio` VALUES (2145,30,43,'Comapa');
INSERT INTO `municipio` VALUES (2146,30,44,'Córdoba');
INSERT INTO `municipio` VALUES (2147,30,45,'Cosamaloapan de Carpio');
INSERT INTO `municipio` VALUES (2148,30,46,'Cosautlán de Carvajal');
INSERT INTO `municipio` VALUES (2149,30,47,'Coscomatepec');
INSERT INTO `municipio` VALUES (2150,30,48,'Cosoleacaque');
INSERT INTO `municipio` VALUES (2151,30,49,'Cotaxtla');
INSERT INTO `municipio` VALUES (2152,30,50,'Coxquihui');
INSERT INTO `municipio` VALUES (2153,30,51,'Coyutla');
INSERT INTO `municipio` VALUES (2154,30,52,'Cuichapa');
INSERT INTO `municipio` VALUES (2155,30,53,'Cuitláhuac');
INSERT INTO `municipio` VALUES (2156,30,54,'Chacaltianguis');
INSERT INTO `municipio` VALUES (2157,30,55,'Chalma');
INSERT INTO `municipio` VALUES (2158,30,56,'Chiconamel');
INSERT INTO `municipio` VALUES (2159,30,57,'Chiconquiaco');
INSERT INTO `municipio` VALUES (2160,30,58,'Chicontepec');
INSERT INTO `municipio` VALUES (2161,30,59,'Chinameca');
INSERT INTO `municipio` VALUES (2162,30,60,'Chinampa de Gorostiza');
INSERT INTO `municipio` VALUES (2163,30,61,'Las Choapas');
INSERT INTO `municipio` VALUES (2164,30,62,'Chocamán');
INSERT INTO `municipio` VALUES (2165,30,63,'Chontla');
INSERT INTO `municipio` VALUES (2166,30,64,'Chumatlán');
INSERT INTO `municipio` VALUES (2167,30,65,'Emiliano Zapata');
INSERT INTO `municipio` VALUES (2168,30,66,'Espinal');
INSERT INTO `municipio` VALUES (2169,30,67,'Filomeno Mata');
INSERT INTO `municipio` VALUES (2170,30,68,'Fortín');
INSERT INTO `municipio` VALUES (2171,30,69,'Gutiérrez Zamora');
INSERT INTO `municipio` VALUES (2172,30,70,'Hidalgotitlán');
INSERT INTO `municipio` VALUES (2173,30,71,'Huatusco');
INSERT INTO `municipio` VALUES (2174,30,72,'Huayacocotla');
INSERT INTO `municipio` VALUES (2175,30,73,'Hueyapan de Ocampo');
INSERT INTO `municipio` VALUES (2176,30,74,'Huiloapan de Cuauhtémoc');
INSERT INTO `municipio` VALUES (2177,30,75,'Ignacio de la Llave');
INSERT INTO `municipio` VALUES (2178,30,76,'Ilamatlán');
INSERT INTO `municipio` VALUES (2179,30,77,'Isla');
INSERT INTO `municipio` VALUES (2180,30,78,'Ixcatepec');
INSERT INTO `municipio` VALUES (2181,30,79,'Ixhuacán de los Reyes');
INSERT INTO `municipio` VALUES (2182,30,80,'Ixhuatlán del Café');
INSERT INTO `municipio` VALUES (2183,30,81,'Ixhuatlancillo');
INSERT INTO `municipio` VALUES (2184,30,82,'Ixhuatlán del Sureste');
INSERT INTO `municipio` VALUES (2185,30,83,'Ixhuatlán de Madero');
INSERT INTO `municipio` VALUES (2186,30,84,'Ixmatlahuacan');
INSERT INTO `municipio` VALUES (2187,30,85,'Ixtaczoquitlán');
INSERT INTO `municipio` VALUES (2188,30,86,'Jalacingo');
INSERT INTO `municipio` VALUES (2189,30,87,'Xalapa');
INSERT INTO `municipio` VALUES (2190,30,88,'Jalcomulco');
INSERT INTO `municipio` VALUES (2191,30,89,'Jáltipan');
INSERT INTO `municipio` VALUES (2192,30,90,'Jamapa');
INSERT INTO `municipio` VALUES (2193,30,91,'Jesús Carranza');
INSERT INTO `municipio` VALUES (2194,30,92,'Xico');
INSERT INTO `municipio` VALUES (2195,30,93,'Jilotepec');
INSERT INTO `municipio` VALUES (2196,30,94,'Juan Rodríguez Clara');
INSERT INTO `municipio` VALUES (2197,30,95,'Juchique de Ferrer');
INSERT INTO `municipio` VALUES (2198,30,96,'Landero y Coss');
INSERT INTO `municipio` VALUES (2199,30,97,'Lerdo de Tejada');
INSERT INTO `municipio` VALUES (2200,30,98,'Magdalena');
INSERT INTO `municipio` VALUES (2201,30,99,'Maltrata');
INSERT INTO `municipio` VALUES (2202,30,100,'Manlio Fabio Altamirano');
INSERT INTO `municipio` VALUES (2203,30,101,'Mariano Escobedo');
INSERT INTO `municipio` VALUES (2204,30,102,'Martínez de la Torre');
INSERT INTO `municipio` VALUES (2205,30,103,'Mecatlán');
INSERT INTO `municipio` VALUES (2206,30,104,'Mecayapan');
INSERT INTO `municipio` VALUES (2207,30,105,'Medellín de Bravo');
INSERT INTO `municipio` VALUES (2208,30,106,'Miahuatlán');
INSERT INTO `municipio` VALUES (2209,30,107,'Las Minas');
INSERT INTO `municipio` VALUES (2210,30,108,'Minatitlán');
INSERT INTO `municipio` VALUES (2211,30,109,'Misantla');
INSERT INTO `municipio` VALUES (2212,30,110,'Mixtla de Altamirano');
INSERT INTO `municipio` VALUES (2213,30,111,'Moloacán');
INSERT INTO `municipio` VALUES (2214,30,112,'Naolinco');
INSERT INTO `municipio` VALUES (2215,30,113,'Naranjal');
INSERT INTO `municipio` VALUES (2216,30,114,'Nautla');
INSERT INTO `municipio` VALUES (2217,30,115,'Nogales');
INSERT INTO `municipio` VALUES (2218,30,116,'Oluta');
INSERT INTO `municipio` VALUES (2219,30,117,'Omealca');
INSERT INTO `municipio` VALUES (2220,30,118,'Orizaba');
INSERT INTO `municipio` VALUES (2221,30,119,'Otatitlán');
INSERT INTO `municipio` VALUES (2222,30,120,'Oteapan');
INSERT INTO `municipio` VALUES (2223,30,121,'Ozuluama de Mascareñas');
INSERT INTO `municipio` VALUES (2224,30,122,'Pajapan');
INSERT INTO `municipio` VALUES (2225,30,123,'Pánuco');
INSERT INTO `municipio` VALUES (2226,30,124,'Papantla');
INSERT INTO `municipio` VALUES (2227,30,125,'Paso del Macho');
INSERT INTO `municipio` VALUES (2228,30,126,'Paso de Ovejas');
INSERT INTO `municipio` VALUES (2229,30,127,'La Perla');
INSERT INTO `municipio` VALUES (2230,30,128,'Perote');
INSERT INTO `municipio` VALUES (2231,30,129,'Platón Sánchez');
INSERT INTO `municipio` VALUES (2232,30,130,'Playa Vicente');
INSERT INTO `municipio` VALUES (2233,30,131,'Poza Rica de Hidalgo');
INSERT INTO `municipio` VALUES (2234,30,132,'Las Vigas de Ramírez');
INSERT INTO `municipio` VALUES (2235,30,133,'Pueblo Viejo');
INSERT INTO `municipio` VALUES (2236,30,134,'Puente Nacional');
INSERT INTO `municipio` VALUES (2237,30,135,'Rafael Delgado');
INSERT INTO `municipio` VALUES (2238,30,136,'Rafael Lucio');
INSERT INTO `municipio` VALUES (2239,30,137,'Los Reyes');
INSERT INTO `municipio` VALUES (2240,30,138,'Río Blanco');
INSERT INTO `municipio` VALUES (2241,30,139,'Saltabarranca');
INSERT INTO `municipio` VALUES (2242,30,140,'San Andrés Tenejapan');
INSERT INTO `municipio` VALUES (2243,30,141,'San Andrés Tuxtla');
INSERT INTO `municipio` VALUES (2244,30,142,'San Juan Evangelista');
INSERT INTO `municipio` VALUES (2245,30,143,'Santiago Tuxtla');
INSERT INTO `municipio` VALUES (2246,30,144,'Sayula de Alemán');
INSERT INTO `municipio` VALUES (2247,30,145,'Soconusco');
INSERT INTO `municipio` VALUES (2248,30,146,'Sochiapa');
INSERT INTO `municipio` VALUES (2249,30,147,'Soledad Atzompa');
INSERT INTO `municipio` VALUES (2250,30,148,'Soledad de Doblado');
INSERT INTO `municipio` VALUES (2251,30,149,'Soteapan');
INSERT INTO `municipio` VALUES (2252,30,150,'Tamalín');
INSERT INTO `municipio` VALUES (2253,30,151,'Tamiahua');
INSERT INTO `municipio` VALUES (2254,30,152,'Tampico Alto');
INSERT INTO `municipio` VALUES (2255,30,153,'Tancoco');
INSERT INTO `municipio` VALUES (2256,30,154,'Tantima');
INSERT INTO `municipio` VALUES (2257,30,155,'Tantoyuca');
INSERT INTO `municipio` VALUES (2258,30,156,'Tatatila');
INSERT INTO `municipio` VALUES (2259,30,157,'Castillo de Teayo');
INSERT INTO `municipio` VALUES (2260,30,158,'Tecolutla');
INSERT INTO `municipio` VALUES (2261,30,159,'Tehuipango');
INSERT INTO `municipio` VALUES (2262,30,160,'Álamo Temapache');
INSERT INTO `municipio` VALUES (2263,30,161,'Tempoal');
INSERT INTO `municipio` VALUES (2264,30,162,'Tenampa');
INSERT INTO `municipio` VALUES (2265,30,163,'Tenochtitlán');
INSERT INTO `municipio` VALUES (2266,30,164,'Teocelo');
INSERT INTO `municipio` VALUES (2267,30,165,'Tepatlaxco');
INSERT INTO `municipio` VALUES (2268,30,166,'Tepetlán');
INSERT INTO `municipio` VALUES (2269,30,167,'Tepetzintla');
INSERT INTO `municipio` VALUES (2270,30,168,'Tequila');
INSERT INTO `municipio` VALUES (2271,30,169,'José Azueta');
INSERT INTO `municipio` VALUES (2272,30,170,'Texcatepec');
INSERT INTO `municipio` VALUES (2273,30,171,'Texhuacán');
INSERT INTO `municipio` VALUES (2274,30,172,'Texistepec');
INSERT INTO `municipio` VALUES (2275,30,173,'Tezonapa');
INSERT INTO `municipio` VALUES (2276,30,174,'Tierra Blanca');
INSERT INTO `municipio` VALUES (2277,30,175,'Tihuatlán');
INSERT INTO `municipio` VALUES (2278,30,176,'Tlacojalpan');
INSERT INTO `municipio` VALUES (2279,30,177,'Tlacolulan');
INSERT INTO `municipio` VALUES (2280,30,178,'Tlacotalpan');
INSERT INTO `municipio` VALUES (2281,30,179,'Tlacotepec de Mejía');
INSERT INTO `municipio` VALUES (2282,30,180,'Tlachichilco');
INSERT INTO `municipio` VALUES (2283,30,181,'Tlalixcoyan');
INSERT INTO `municipio` VALUES (2284,30,182,'Tlalnelhuayocan');
INSERT INTO `municipio` VALUES (2285,30,183,'Tlapacoyan');
INSERT INTO `municipio` VALUES (2286,30,184,'Tlaquilpa');
INSERT INTO `municipio` VALUES (2287,30,185,'Tlilapan');
INSERT INTO `municipio` VALUES (2288,30,186,'Tomatlán');
INSERT INTO `municipio` VALUES (2289,30,187,'Tonayán');
INSERT INTO `municipio` VALUES (2290,30,188,'Totutla');
INSERT INTO `municipio` VALUES (2291,30,189,'Tuxpan');
INSERT INTO `municipio` VALUES (2292,30,190,'Tuxtilla');
INSERT INTO `municipio` VALUES (2293,30,191,'Ursulo Galván');
INSERT INTO `municipio` VALUES (2294,30,192,'Vega de Alatorre');
INSERT INTO `municipio` VALUES (2295,30,193,'Veracruz');
INSERT INTO `municipio` VALUES (2296,30,194,'Villa Aldama');
INSERT INTO `municipio` VALUES (2297,30,195,'Xoxocotla');
INSERT INTO `municipio` VALUES (2298,30,196,'Yanga');
INSERT INTO `municipio` VALUES (2299,30,197,'Yecuatla');
INSERT INTO `municipio` VALUES (2300,30,198,'Zacualpan');
INSERT INTO `municipio` VALUES (2301,30,199,'Zaragoza');
INSERT INTO `municipio` VALUES (2302,30,200,'Zentla');
INSERT INTO `municipio` VALUES (2303,30,201,'Zongolica');
INSERT INTO `municipio` VALUES (2304,30,202,'Zontecomatlán de López y Fuentes');
INSERT INTO `municipio` VALUES (2305,30,203,'Zozocolco de Hidalgo');
INSERT INTO `municipio` VALUES (2306,30,204,'Agua Dulce');
INSERT INTO `municipio` VALUES (2307,30,205,'El Higo');
INSERT INTO `municipio` VALUES (2308,30,206,'Nanchital de Lázaro Cárdenas del Río');
INSERT INTO `municipio` VALUES (2309,30,207,'Tres Valles');
INSERT INTO `municipio` VALUES (2310,30,208,'Carlos A. Carrillo');
INSERT INTO `municipio` VALUES (2311,30,209,'Tatahuicapan de Juárez');
INSERT INTO `municipio` VALUES (2312,30,210,'Uxpanapa');
INSERT INTO `municipio` VALUES (2313,30,211,'San Rafael');
INSERT INTO `municipio` VALUES (2314,30,212,'Santiago Sochiapan');
INSERT INTO `municipio` VALUES (2315,31,1,'Abalá');
INSERT INTO `municipio` VALUES (2316,31,2,'Acanceh');
INSERT INTO `municipio` VALUES (2317,31,3,'Akil');
INSERT INTO `municipio` VALUES (2318,31,4,'Baca');
INSERT INTO `municipio` VALUES (2319,31,5,'Bokobá');
INSERT INTO `municipio` VALUES (2320,31,6,'Buctzotz');
INSERT INTO `municipio` VALUES (2321,31,7,'Cacalchén');
INSERT INTO `municipio` VALUES (2322,31,8,'Calotmul');
INSERT INTO `municipio` VALUES (2323,31,9,'Cansahcab');
INSERT INTO `municipio` VALUES (2324,31,10,'Cantamayec');
INSERT INTO `municipio` VALUES (2325,31,11,'Celestún');
INSERT INTO `municipio` VALUES (2326,31,12,'Cenotillo');
INSERT INTO `municipio` VALUES (2327,31,13,'Conkal');
INSERT INTO `municipio` VALUES (2328,31,14,'Cuncunul');
INSERT INTO `municipio` VALUES (2329,31,15,'Cuzamá');
INSERT INTO `municipio` VALUES (2330,31,16,'Chacsinkín');
INSERT INTO `municipio` VALUES (2331,31,17,'Chankom');
INSERT INTO `municipio` VALUES (2332,31,18,'Chapab');
INSERT INTO `municipio` VALUES (2333,31,19,'Chemax');
INSERT INTO `municipio` VALUES (2334,31,20,'Chicxulub Pueblo');
INSERT INTO `municipio` VALUES (2335,31,21,'Chichimilá');
INSERT INTO `municipio` VALUES (2336,31,22,'Chikindzonot');
INSERT INTO `municipio` VALUES (2337,31,23,'Chocholá');
INSERT INTO `municipio` VALUES (2338,31,24,'Chumayel');
INSERT INTO `municipio` VALUES (2339,31,25,'Dzan');
INSERT INTO `municipio` VALUES (2340,31,26,'Dzemul');
INSERT INTO `municipio` VALUES (2341,31,27,'Dzidzantún');
INSERT INTO `municipio` VALUES (2342,31,28,'Dzilam de Bravo');
INSERT INTO `municipio` VALUES (2343,31,29,'Dzilam González');
INSERT INTO `municipio` VALUES (2344,31,30,'Dzitás');
INSERT INTO `municipio` VALUES (2345,31,31,'Dzoncauich');
INSERT INTO `municipio` VALUES (2346,31,32,'Espita');
INSERT INTO `municipio` VALUES (2347,31,33,'Halachó');
INSERT INTO `municipio` VALUES (2348,31,34,'Hocabá');
INSERT INTO `municipio` VALUES (2349,31,35,'Hoctún');
INSERT INTO `municipio` VALUES (2350,31,36,'Homún');
INSERT INTO `municipio` VALUES (2351,31,37,'Huhí');
INSERT INTO `municipio` VALUES (2352,31,38,'Hunucmá');
INSERT INTO `municipio` VALUES (2353,31,39,'Ixil');
INSERT INTO `municipio` VALUES (2354,31,40,'Izamal');
INSERT INTO `municipio` VALUES (2355,31,41,'Kanasín');
INSERT INTO `municipio` VALUES (2356,31,42,'Kantunil');
INSERT INTO `municipio` VALUES (2357,31,43,'Kaua');
INSERT INTO `municipio` VALUES (2358,31,44,'Kinchil');
INSERT INTO `municipio` VALUES (2359,31,45,'Kopomá');
INSERT INTO `municipio` VALUES (2360,31,46,'Mama');
INSERT INTO `municipio` VALUES (2361,31,47,'Maní');
INSERT INTO `municipio` VALUES (2362,31,48,'Maxcanú');
INSERT INTO `municipio` VALUES (2363,31,49,'Mayapán');
INSERT INTO `municipio` VALUES (2364,31,50,'Mérida');
INSERT INTO `municipio` VALUES (2365,31,51,'Mocochá');
INSERT INTO `municipio` VALUES (2366,31,52,'Motul');
INSERT INTO `municipio` VALUES (2367,31,53,'Muna');
INSERT INTO `municipio` VALUES (2368,31,54,'Muxupip');
INSERT INTO `municipio` VALUES (2369,31,55,'Opichén');
INSERT INTO `municipio` VALUES (2370,31,56,'Oxkutzcab');
INSERT INTO `municipio` VALUES (2371,31,57,'Panabá');
INSERT INTO `municipio` VALUES (2372,31,58,'Peto');
INSERT INTO `municipio` VALUES (2373,31,59,'Progreso');
INSERT INTO `municipio` VALUES (2374,31,60,'Quintana Roo');
INSERT INTO `municipio` VALUES (2375,31,61,'Río Lagartos');
INSERT INTO `municipio` VALUES (2376,31,62,'Sacalum');
INSERT INTO `municipio` VALUES (2377,31,63,'Samahil');
INSERT INTO `municipio` VALUES (2378,31,64,'Sanahcat');
INSERT INTO `municipio` VALUES (2379,31,65,'San Felipe');
INSERT INTO `municipio` VALUES (2380,31,66,'Santa Elena');
INSERT INTO `municipio` VALUES (2381,31,67,'Seyé');
INSERT INTO `municipio` VALUES (2382,31,68,'Sinanché');
INSERT INTO `municipio` VALUES (2383,31,69,'Sotuta');
INSERT INTO `municipio` VALUES (2384,31,70,'Sucilá');
INSERT INTO `municipio` VALUES (2385,31,71,'Sudzal');
INSERT INTO `municipio` VALUES (2386,31,72,'Suma');
INSERT INTO `municipio` VALUES (2387,31,73,'Tahdziú');
INSERT INTO `municipio` VALUES (2388,31,74,'Tahmek');
INSERT INTO `municipio` VALUES (2389,31,75,'Teabo');
INSERT INTO `municipio` VALUES (2390,31,76,'Tecoh');
INSERT INTO `municipio` VALUES (2391,31,77,'Tekal de Venegas');
INSERT INTO `municipio` VALUES (2392,31,78,'Tekantó');
INSERT INTO `municipio` VALUES (2393,31,79,'Tekax');
INSERT INTO `municipio` VALUES (2394,31,80,'Tekit');
INSERT INTO `municipio` VALUES (2395,31,81,'Tekom');
INSERT INTO `municipio` VALUES (2396,31,82,'Telchac Pueblo');
INSERT INTO `municipio` VALUES (2397,31,83,'Telchac Puerto');
INSERT INTO `municipio` VALUES (2398,31,84,'Temax');
INSERT INTO `municipio` VALUES (2399,31,85,'Temozón');
INSERT INTO `municipio` VALUES (2400,31,86,'Tepakán');
INSERT INTO `municipio` VALUES (2401,31,87,'Tetiz');
INSERT INTO `municipio` VALUES (2402,31,88,'Teya');
INSERT INTO `municipio` VALUES (2403,31,89,'Ticul');
INSERT INTO `municipio` VALUES (2404,31,90,'Timucuy');
INSERT INTO `municipio` VALUES (2405,31,91,'Tinum');
INSERT INTO `municipio` VALUES (2406,31,92,'Tixcacalcupul');
INSERT INTO `municipio` VALUES (2407,31,93,'Tixkokob');
INSERT INTO `municipio` VALUES (2408,31,94,'Tixméhuac');
INSERT INTO `municipio` VALUES (2409,31,95,'Tixpéual');
INSERT INTO `municipio` VALUES (2410,31,96,'Tizimín');
INSERT INTO `municipio` VALUES (2411,31,97,'Tunkás');
INSERT INTO `municipio` VALUES (2412,31,98,'Tzucacab');
INSERT INTO `municipio` VALUES (2413,31,99,'Uayma');
INSERT INTO `municipio` VALUES (2414,31,100,'Ucú');
INSERT INTO `municipio` VALUES (2415,31,101,'Umán');
INSERT INTO `municipio` VALUES (2416,31,102,'Valladolid');
INSERT INTO `municipio` VALUES (2417,31,103,'Xocchel');
INSERT INTO `municipio` VALUES (2418,31,104,'Yaxcabá');
INSERT INTO `municipio` VALUES (2419,31,105,'Yaxkukul');
INSERT INTO `municipio` VALUES (2420,31,106,'Yobaín');
INSERT INTO `municipio` VALUES (2421,32,1,'Apozol');
INSERT INTO `municipio` VALUES (2422,32,2,'Apulco');
INSERT INTO `municipio` VALUES (2423,32,3,'Atolinga');
INSERT INTO `municipio` VALUES (2424,32,4,'Benito Juárez');
INSERT INTO `municipio` VALUES (2425,32,5,'Calera');
INSERT INTO `municipio` VALUES (2426,32,6,'Cañitas de Felipe Pescador');
INSERT INTO `municipio` VALUES (2427,32,7,'Concepción del Oro');
INSERT INTO `municipio` VALUES (2428,32,8,'Cuauhtémoc');
INSERT INTO `municipio` VALUES (2429,32,9,'Chalchihuites');
INSERT INTO `municipio` VALUES (2430,32,10,'Fresnillo');
INSERT INTO `municipio` VALUES (2431,32,11,'Trinidad García de la Cadena');
INSERT INTO `municipio` VALUES (2432,32,12,'Genaro Codina');
INSERT INTO `municipio` VALUES (2433,32,13,'General Enrique Estrada');
INSERT INTO `municipio` VALUES (2434,32,14,'General Francisco R. Murguía');
INSERT INTO `municipio` VALUES (2435,32,15,'El Plateado de Joaquín Amaro');
INSERT INTO `municipio` VALUES (2436,32,16,'General Pánfilo Natera');
INSERT INTO `municipio` VALUES (2437,32,17,'Guadalupe');
INSERT INTO `municipio` VALUES (2438,32,18,'Huanusco');
INSERT INTO `municipio` VALUES (2439,32,19,'Jalpa');
INSERT INTO `municipio` VALUES (2440,32,20,'Jerez');
INSERT INTO `municipio` VALUES (2441,32,21,'Jiménez del Teul');
INSERT INTO `municipio` VALUES (2442,32,22,'Juan Aldama');
INSERT INTO `municipio` VALUES (2443,32,23,'Juchipila');
INSERT INTO `municipio` VALUES (2444,32,24,'Loreto');
INSERT INTO `municipio` VALUES (2445,32,25,'Luis Moya');
INSERT INTO `municipio` VALUES (2446,32,26,'Mazapil');
INSERT INTO `municipio` VALUES (2447,32,27,'Melchor Ocampo');
INSERT INTO `municipio` VALUES (2448,32,28,'Mezquital del Oro');
INSERT INTO `municipio` VALUES (2449,32,29,'Miguel Auza');
INSERT INTO `municipio` VALUES (2450,32,30,'Momax');
INSERT INTO `municipio` VALUES (2451,32,31,'Monte Escobedo');
INSERT INTO `municipio` VALUES (2452,32,32,'Morelos');
INSERT INTO `municipio` VALUES (2453,32,33,'Moyahua de Estrada');
INSERT INTO `municipio` VALUES (2454,32,34,'Nochistlán de Mejía');
INSERT INTO `municipio` VALUES (2455,32,35,'Noria de Ángeles');
INSERT INTO `municipio` VALUES (2456,32,36,'Ojocaliente');
INSERT INTO `municipio` VALUES (2457,32,37,'Pánuco');
INSERT INTO `municipio` VALUES (2458,32,38,'Pinos');
INSERT INTO `municipio` VALUES (2459,32,39,'Río Grande');
INSERT INTO `municipio` VALUES (2460,32,40,'Sain Alto');
INSERT INTO `municipio` VALUES (2461,32,41,'El Salvador');
INSERT INTO `municipio` VALUES (2462,32,42,'Sombrerete');
INSERT INTO `municipio` VALUES (2463,32,43,'Susticacán');
INSERT INTO `municipio` VALUES (2464,32,44,'Tabasco');
INSERT INTO `municipio` VALUES (2465,32,45,'Tepechitlán');
INSERT INTO `municipio` VALUES (2466,32,46,'Tepetongo');
INSERT INTO `municipio` VALUES (2467,32,47,'Teúl de González Ortega');
INSERT INTO `municipio` VALUES (2468,32,48,'Tlaltenango de Sánchez Román');
INSERT INTO `municipio` VALUES (2469,32,49,'Valparaíso');
INSERT INTO `municipio` VALUES (2470,32,50,'Vetagrande');
INSERT INTO `municipio` VALUES (2471,32,51,'Villa de Cos');
INSERT INTO `municipio` VALUES (2472,32,52,'Villa García');
INSERT INTO `municipio` VALUES (2473,32,53,'Villa González Ortega');
INSERT INTO `municipio` VALUES (2474,32,54,'Villa Hidalgo');
INSERT INTO `municipio` VALUES (2475,32,55,'Villanueva');
INSERT INTO `municipio` VALUES (2476,32,56,'Zacatecas');
INSERT INTO `municipio` VALUES (2477,32,57,'Trancoso');
INSERT INTO `municipio` VALUES (2478,32,58,'Santa María de la Paz');

INSERT INTO parametro (clave, valor, descripcion, vigente_desde) VALUES
  ('alerta_bloqueos_dia', '20', 'Bloqueos de acceso en 24 horas que disparan el aviso operativo (0 lo apaga)', '2026-01-01'),
  ('aviso_privacidad_aprobado', '0', 'Vale 1 cuando el negocio y su asesor legal aprueban el aviso. Mientras tanto se muestra como borrador', '2026-01-01'),
  ('dias_anonimizar_ex_personal', '0', 'Días tras la baja para anonimizar a un ex empleado (0 no anonimiza solo). No tiene vuelta atrás', '2026-01-01'),
  ('dias_respuesta_arco', '20', 'Días para contestar una solicitud de derechos, por confirmar con el asesor legal', '2026-01-01'),
  ('horas_sesion_maxima', '12', 'Horas que dura como máximo una sesión web desde la entrada. «Seguir conectado» abre otra (0 la deja sin tope)', '2026-01-01'),
  ('minutos_sesion_inactiva', '720', 'Minutos que una sesión web puede estar sin uso antes de cerrarse (0 la deja abierta)', '2026-01-01'),
  ('minutos_sesion_inactiva_sensible', '60', 'Minutos sin uso antes de cerrar la sesión de administración, gerencia, caja y almacén (0 usa el tope general)', '2026-01-01'),
  ('privacidad_contacto', 'Por definir', 'Medio para ejercer derechos, en el aviso de privacidad', '2026-01-01'),
  ('privacidad_domicilio', 'Por definir', 'Domicilio del responsable en el aviso de privacidad', '2026-01-01'),
  ('privacidad_responsable', 'Por definir', 'Razón social del responsable en el aviso de privacidad', '2026-01-01'),
  ('segundo_factor_web', '1', 'Código de Authenticator en la web: 1 lo pide a los puestos sensibles al entrar y en las autorizaciones de otra persona. 0 lo quita y basta la contraseña', '2026-01-01');

INSERT INTO puesto (id, clave, nombre, usa_app) VALUES
  (1, 'administrador', 'Administrador',        0),
  (2, 'gerente',       'Gerente de sucursal',  1),
  (3, 'cajero',        'Cajero',               1),
  (4, 'mesero',        'Mesero',               1),
  (5, 'cocina',        'Cocina',               1),
  (6, 'barra',         'Barra',                1),
  (7, 'almacen',       'Encargado de almacén', 0);

INSERT INTO permiso (clave, descripcion) VALUES
  ('accesos_revisa',       'Revisar los accesos de los usuarios'),
  ('avisos_ver',           'Ver los avisos enviados a los equipos'),
  ('bitacora_exporta',     'Exportar la bitácora'),
  ('bitacora_ver',         'Consultar la bitácora'),
  ('notificaciones_envia', 'Enviar avisos a los equipos'),
  ('organizacion_admin',   'Editar sucursales'),
  ('organizacion_ver',     'Ver sucursales'),
  ('personal_admin',       'Personal, usuarios y equipos'),
  ('personal_ver',         'Ver el personal'),
  ('seguridad_admin',      'Seguridad, segundo factor y privacidad'),
  ('tablero_ver',          'Ver el tablero');

-- El administrador tiene todos los permisos de la capa base.
INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT 1, id FROM permiso;

-- El gerente opera su sucursal: ve, administra a su personal y avisa.
INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT 2, id FROM permiso
  WHERE clave IN ('tablero_ver', 'organizacion_ver', 'personal_ver', 'personal_admin',
                  'avisos_ver', 'notificaciones_envia', 'bitacora_ver');
-- FIN 006_datos_base.sql

-- ============================================================================
-- INICIO 007_restaurante.sql
-- ============================================================================
-- Plano y catálogo. Las llaves compuestas impiden referencias a otra sucursal.
SET NAMES utf8mb4;

CREATE TABLE area (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_area_sucursal_nombre (id_sucursal, nombre),
  UNIQUE KEY uq_area_sucursal_id (id_sucursal, id),
  CONSTRAINT fk_area_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE mesa (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_area INT UNSIGNED NOT NULL,
  numero VARCHAR(20) NOT NULL,
  capacidad TINYINT UNSIGNED NOT NULL,
  forma ENUM('redonda','cuadrada','rectangular') NOT NULL DEFAULT 'cuadrada',
  x TINYINT UNSIGNED NOT NULL DEFAULT 0,
  y TINYINT UNSIGNED NOT NULL DEFAULT 0,
  estado ENUM('libre','por_limpiar','bloqueada') NOT NULL DEFAULT 'libre',
  PRIMARY KEY (id),
  UNIQUE KEY uq_mesa_sucursal_numero (id_sucursal, numero),
  UNIQUE KEY uq_mesa_sucursal_id (id_sucursal, id),
  CONSTRAINT fk_mesa_area FOREIGN KEY (id_sucursal, id_area) REFERENCES area (id_sucursal, id),
  CONSTRAINT ck_mesa_posicion CHECK (x <= 100 AND y <= 100 AND capacidad > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE categoria_menu (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(80) NOT NULL,
  orden SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_categoria_menu_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE platillo (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_categoria INT UNSIGNED NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  descripcion VARCHAR(400) NOT NULL DEFAULT '',
  foto VARCHAR(255) DEFAULT NULL,
  preparacion ENUM('caliente','fria','barra') NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  CONSTRAINT fk_platillo_categoria FOREIGN KEY (id_categoria) REFERENCES categoria_menu (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE platillo_sucursal (
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_platillo INT UNSIGNED NOT NULL,
  precio DECIMAL(10,2) UNSIGNED NOT NULL,
  agotado TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id_sucursal, id_platillo),
  CONSTRAINT fk_platillo_sucursal_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_platillo_sucursal_platillo FOREIGN KEY (id_platillo) REFERENCES platillo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE modificador_platillo (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_platillo INT UNSIGNED NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  suplemento DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_modificador_platillo_nombre (id_platillo, nombre),
  CONSTRAINT fk_modificador_platillo FOREIGN KEY (id_platillo) REFERENCES platillo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permiso (clave, descripcion) VALUES
  ('plano_ver', 'Ver el plano de mesas'),
  ('plano_admin', 'Administrar el plano de mesas'),
  ('menu_ver', 'Consultar platillos y disponibilidad'),
  ('menu_admin', 'Administrar el catálogo general de platillos'),
  ('menu_sucursal', 'Administrar los precios y agotados de la sucursal'),
  ('comanda_ver', 'Consultar las cuentas de la sucursal'),
  ('comanda_captura', 'Abrir cuentas y enviar comandas'),
  ('comanda_cobra', 'Cobrar cuentas y consultar caja'),
  ('cocina_opera', 'Operar la pantalla de cocina o barra');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT puesto.id, permiso.id FROM puesto CROSS JOIN permiso
  WHERE (
    (puesto.clave = 'administrador' AND permiso.clave IN
      ('plano_ver','plano_admin','menu_ver','menu_admin','menu_sucursal','comanda_ver','comanda_captura','comanda_cobra','cocina_opera'))
    OR (puesto.clave = 'gerente' AND permiso.clave IN
      ('plano_ver','plano_admin','menu_ver','menu_sucursal','comanda_ver','comanda_captura','comanda_cobra','cocina_opera'))
    OR (puesto.clave = 'mesero' AND permiso.clave IN ('plano_ver','menu_ver','comanda_ver','comanda_captura'))
    OR (puesto.clave = 'cajero' AND permiso.clave IN ('plano_ver','menu_ver','comanda_ver','comanda_captura','comanda_cobra'))
    OR (puesto.clave IN ('cocina','barra') AND permiso.clave IN ('menu_ver','cocina_opera'))
  );
-- FIN 007_restaurante.sql

-- ============================================================================
-- INICIO 008_comanda.sql
-- ============================================================================
SET NAMES utf8mb4;

CREATE TABLE cuenta (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_mesa INT UNSIGNED DEFAULT NULL,
  id_mesero INT UNSIGNED NOT NULL,
  tipo ENUM('mesa','llevar','domicilio') NOT NULL,
  estado ENUM('ocupada','cuenta_pedida','pagada','cancelada','unida') NOT NULL DEFAULT 'ocupada',
  abierta TINYINT DEFAULT 1,
  version INT UNSIGNED NOT NULL DEFAULT 1,
  abierta_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cerrada_en DATETIME DEFAULT NULL,
  cliente VARCHAR(100) DEFAULT NULL,
  telefono VARCHAR(25) DEFAULT NULL,
  direccion VARCHAR(250) DEFAULT NULL,
  repartidor VARCHAR(100) DEFAULT NULL,
  entrega ENUM('recibido','preparando','listo','en_camino','entregado','cancelado') DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cuenta_mesa_abierta (id_mesa, abierta),
  UNIQUE KEY uq_cuenta_sucursal_id (id_sucursal, id),
  KEY ix_cuenta_sucursal_abierta (id_sucursal, abierta, id),
  CONSTRAINT fk_cuenta_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_cuenta_mesa FOREIGN KEY (id_sucursal, id_mesa) REFERENCES mesa (id_sucursal, id),
  CONSTRAINT fk_cuenta_mesero FOREIGN KEY (id_mesero) REFERENCES usuario (id),
  CONSTRAINT ck_cuenta_activa CHECK ((abierta = 1 AND estado IN ('ocupada','cuenta_pedida')) OR
    (abierta IS NULL AND estado IN ('pagada','cancelada','unida'))),
  CONSTRAINT ck_cuenta_tipo CHECK ((tipo = 'mesa') = (id_mesa IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Incluye la mesa principal. Así la unicidad también cubre la combinación
-- de mesa principal de una cuenta con mesa secundaria de otra.
CREATE TABLE cuenta_mesa (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_cuenta BIGINT UNSIGNED NOT NULL,
  id_mesa INT UNSIGNED NOT NULL,
  abierta TINYINT DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cuenta_mesa_activa (id_mesa, abierta),
  KEY ix_cuenta_mesa_cuenta (id_cuenta, abierta),
  CONSTRAINT fk_cuenta_mesa_cuenta FOREIGN KEY (id_sucursal, id_cuenta) REFERENCES cuenta (id_sucursal, id),
  CONSTRAINT fk_cuenta_mesa_mesa FOREIGN KEY (id_sucursal, id_mesa) REFERENCES mesa (id_sucursal, id),
  CONSTRAINT ck_cuenta_mesa_abierta CHECK (abierta IS NULL OR abierta = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ronda (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_cuenta BIGINT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  enviada_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_ronda_cuenta FOREIGN KEY (id_cuenta) REFERENCES cuenta (id),
  CONSTRAINT fk_ronda_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE cuenta_item (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_cuenta BIGINT UNSIGNED NOT NULL,
  id_ronda BIGINT UNSIGNED DEFAULT NULL,
  id_platillo INT UNSIGNED NOT NULL,
  platillo VARCHAR(100) NOT NULL,
  preparacion ENUM('caliente','fria','barra') NOT NULL,
  cantidad SMALLINT UNSIGNED NOT NULL,
  precio DECIMAL(10,2) UNSIGNED NOT NULL,
  modificadores JSON NOT NULL,
  nota VARCHAR(240) NOT NULL DEFAULT '',
  tiempo ENUM('entrada','fuerte') NOT NULL DEFAULT 'fuerte',
  asiento TINYINT UNSIGNED DEFAULT NULL,
  estado ENUM('capturado','enviado','en_preparacion','listo','entregado','cancelado') NOT NULL DEFAULT 'capturado',
  estado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  preparado_en DATETIME DEFAULT NULL,
  listo_en DATETIME DEFAULT NULL,
  cancelado_por INT UNSIGNED DEFAULT NULL,
  motivo VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_cuenta_item_cuenta (id_cuenta, estado),
  KEY ix_cuenta_item_ronda (id_ronda, preparacion, estado),
  CONSTRAINT fk_cuenta_item_cuenta FOREIGN KEY (id_cuenta) REFERENCES cuenta (id),
  CONSTRAINT fk_cuenta_item_ronda FOREIGN KEY (id_ronda) REFERENCES ronda (id),
  CONSTRAINT fk_cuenta_item_platillo FOREIGN KEY (id_platillo) REFERENCES platillo (id),
  CONSTRAINT fk_cuenta_item_cancela FOREIGN KEY (cancelado_por) REFERENCES usuario (id),
  CONSTRAINT ck_cuenta_item_cantidad CHECK (cantidad > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE evento_sucursal (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  tipo VARCHAR(32) NOT NULL,
  entidad BIGINT UNSIGNED NOT NULL,
  creado_en DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY ix_evento_sucursal_desde (id_sucursal, id),
  CONSTRAINT fk_evento_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE operacion_sincronizada
  ADD COLUMN huella CHAR(64) DEFAULT NULL,
  ADD COLUMN respuesta JSON DEFAULT NULL;
-- FIN 008_comanda.sql

-- ============================================================================
-- INICIO 009_equipo_restaurante.sql
-- ============================================================================
SET NAMES utf8mb4;

ALTER TABLE usuario ADD COLUMN pin_hash VARCHAR(255) DEFAULT NULL;

CREATE TABLE equipo (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED DEFAULT NULL,
  nombre VARCHAR(80) NOT NULL,
  tipo ENUM('mesero','caja','cocina','barra','impresor','gerencia') DEFAULT NULL,
  plataforma ENUM('android','ios','web') NOT NULL,
  codigo CHAR(10) NOT NULL,
  identificador_hash CHAR(64) NOT NULL,
  config JSON DEFAULT NULL,
  autorizado TINYINT(1) NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  autorizado_en DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_equipo_codigo (codigo),
  UNIQUE KEY uq_equipo_identificador (identificador_hash),
  KEY ix_equipo_sucursal (id_sucursal, autorizado),
  CONSTRAINT fk_equipo_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sesion_equipo (
  id_equipo INT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  sesion_version INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  actividad_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expira_en DATETIME NOT NULL,
  PRIMARY KEY (id_equipo),
  UNIQUE KEY uq_sesion_equipo_token (token_hash),
  KEY ix_sesion_equipo_usuario (id_usuario),
  CONSTRAINT fk_sesion_equipo_equipo FOREIGN KEY (id_equipo) REFERENCES equipo (id),
  CONSTRAINT fk_sesion_equipo_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permiso (clave, descripcion) VALUES
  ('equipo_admin', 'Autorizar equipos de comanda de la sucursal');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe
  WHERE p.clave IN ('administrador','gerente') AND pe.clave = 'equipo_admin';
-- FIN 009_equipo_restaurante.sql

-- ============================================================================
-- INICIO 010_cocina_caja.sql
-- ============================================================================
SET NAMES utf8mb4;

CREATE TABLE impresora (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  puerto SMALLINT UNSIGNED NOT NULL DEFAULT 9100,
  ancho ENUM('58','80') NOT NULL DEFAULT '80',
  destino ENUM('caliente','fria','barra','caja') NOT NULL,
  activa TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_impresora_destino (id_sucursal, destino),
  UNIQUE KEY uq_impresora_sucursal_id (id_sucursal, id),
  CONSTRAINT fk_impresora_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE trabajo_impresion (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_impresora INT UNSIGNED NOT NULL,
  tipo ENUM('comanda','precuenta','ticket','corte') NOT NULL,
  entidad BIGINT UNSIGNED NOT NULL,
  contenido TEXT NOT NULL,
  estado ENUM('pendiente','enviado','impreso','fallido') NOT NULL DEFAULT 'pendiente',
  id_equipo INT UNSIGNED DEFAULT NULL,
  arrendado_hasta DATETIME DEFAULT NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  terminado_en DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_impresion_pendiente (id_sucursal, estado, id),
  CONSTRAINT fk_impresion_impresora FOREIGN KEY (id_sucursal, id_impresora) REFERENCES impresora (id_sucursal, id),
  CONSTRAINT fk_impresion_equipo FOREIGN KEY (id_equipo) REFERENCES equipo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE turno_caja (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_cajero INT UNSIGNED NOT NULL,
  abierto TINYINT DEFAULT 1,
  fondo DECIMAL(12,2) UNSIGNED NOT NULL,
  abierto_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cerrado_en DATETIME DEFAULT NULL,
  efectivo_declarado DECIMAL(12,2) UNSIGNED DEFAULT NULL,
  efectivo_esperado DECIMAL(12,2) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_turno_sucursal_abierto (id_sucursal, abierto),
  CONSTRAINT fk_turno_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_turno_cajero FOREIGN KEY (id_cajero) REFERENCES usuario (id),
  CONSTRAINT ck_turno_abierto CHECK (abierto IS NULL OR abierto = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE pago_cuenta (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_cuenta BIGINT UNSIGNED NOT NULL,
  id_turno BIGINT UNSIGNED NOT NULL,
  id_cajero INT UNSIGNED NOT NULL,
  total DECIMAL(12,2) UNSIGNED NOT NULL,
  propina DECIMAL(12,2) UNSIGNED NOT NULL,
  descuento DECIMAL(12,2) UNSIGNED NOT NULL DEFAULT 0,
  descuento_autorizado_por INT UNSIGNED DEFAULT NULL,
  token_publico CHAR(32) NOT NULL,
  pagado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_pago_cuenta (id_cuenta),
  UNIQUE KEY uq_pago_token (token_publico),
  KEY ix_pago_turno (id_turno),
  CONSTRAINT fk_pago_cuenta FOREIGN KEY (id_cuenta) REFERENCES cuenta (id),
  CONSTRAINT fk_pago_turno FOREIGN KEY (id_turno) REFERENCES turno_caja (id),
  CONSTRAINT fk_pago_cajero FOREIGN KEY (id_cajero) REFERENCES usuario (id),
  CONSTRAINT fk_pago_autoriza FOREIGN KEY (descuento_autorizado_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE pago_cuenta_forma (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_pago BIGINT UNSIGNED NOT NULL,
  medio ENUM('efectivo','tarjeta','transferencia') NOT NULL,
  importe DECIMAL(12,2) UNSIGNED NOT NULL,
  referencia VARCHAR(80) DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_pago_forma FOREIGN KEY (id_pago) REFERENCES pago_cuenta (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE asiento_caja (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_turno BIGINT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  concepto VARCHAR(120) NOT NULL,
  importe DECIMAL(12,2) NOT NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_asiento_turno FOREIGN KEY (id_turno) REFERENCES turno_caja (id),
  CONSTRAINT fk_asiento_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- FIN 010_cocina_caja.sql

-- ============================================================================
-- INICIO 011_inventario.sql
-- ============================================================================
SET NAMES utf8mb4;

CREATE TABLE insumo (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  unidad VARCHAR(20) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_insumo_nombre (id_sucursal, nombre),
  UNIQUE KEY uq_insumo_sucursal_id (id_sucursal, id),
  CONSTRAINT fk_insumo_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE proveedor (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  contacto VARCHAR(100) NOT NULL DEFAULT '',
  PRIMARY KEY (id),
  UNIQUE KEY uq_proveedor_nombre (id_sucursal, nombre),
  UNIQUE KEY uq_proveedor_sucursal_id (id_sucursal, id),
  CONSTRAINT fk_proveedor_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE compra_insumo (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_proveedor INT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  referencia VARCHAR(80) NOT NULL,
  estado ENUM('ordenada','recibida','cancelada') NOT NULL DEFAULT 'ordenada',
  creada_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  recibida_en DATETIME DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_compra_sucursal (id_sucursal, id),
  CONSTRAINT fk_compra_proveedor FOREIGN KEY (id_sucursal, id_proveedor) REFERENCES proveedor (id_sucursal, id),
  CONSTRAINT fk_compra_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE compra_insumo_linea (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_compra BIGINT UNSIGNED NOT NULL,
  id_insumo INT UNSIGNED NOT NULL,
  cantidad DECIMAL(12,3) UNSIGNED NOT NULL,
  costo DECIMAL(10,2) UNSIGNED NOT NULL,
  vence DATE DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_compra_linea_compra FOREIGN KEY (id_compra) REFERENCES compra_insumo (id),
  CONSTRAINT fk_compra_linea_insumo FOREIGN KEY (id_insumo) REFERENCES insumo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE lote_insumo (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_insumo INT UNSIGNED NOT NULL,
  id_compra_linea BIGINT UNSIGNED DEFAULT NULL,
  vence DATE DEFAULT NULL,
  saldo DECIMAL(12,3) UNSIGNED NOT NULL,
  costo DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_lote_compra_linea (id_compra_linea),
  KEY ix_lote_insumo_vence (id_insumo, vence, id),
  CONSTRAINT fk_lote_insumo FOREIGN KEY (id_insumo) REFERENCES insumo (id),
  CONSTRAINT fk_lote_compra_linea FOREIGN KEY (id_compra_linea) REFERENCES compra_insumo_linea (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE receta_insumo (
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_platillo INT UNSIGNED NOT NULL,
  id_insumo INT UNSIGNED NOT NULL,
  cantidad DECIMAL(10,3) UNSIGNED NOT NULL,
  PRIMARY KEY (id_sucursal, id_platillo, id_insumo),
  CONSTRAINT fk_receta_insumo FOREIGN KEY (id_sucursal, id_insumo) REFERENCES insumo (id_sucursal, id),
  CONSTRAINT fk_receta_platillo FOREIGN KEY (id_platillo) REFERENCES platillo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE kardex_insumo (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_lote BIGINT UNSIGNED NOT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  id_cuenta BIGINT UNSIGNED DEFAULT NULL,
  tipo ENUM('entrada','consumo','merma','conteo') NOT NULL,
  cantidad DECIMAL(12,3) NOT NULL,
  motivo VARCHAR(160) NOT NULL DEFAULT '',
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_kardex_fecha (creado_en, id),
  CONSTRAINT fk_kardex_lote FOREIGN KEY (id_lote) REFERENCES lote_insumo (id),
  CONSTRAINT fk_kardex_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id),
  CONSTRAINT fk_kardex_cuenta FOREIGN KEY (id_cuenta) REFERENCES cuenta (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE gasto_sucursal (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_proveedor INT UNSIGNED DEFAULT NULL,
  id_usuario INT UNSIGNED NOT NULL,
  id_asiento BIGINT UNSIGNED DEFAULT NULL,
  concepto VARCHAR(120) NOT NULL,
  importe DECIMAL(10,2) UNSIGNED NOT NULL,
  comprobante VARCHAR(200) NOT NULL DEFAULT '',
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_gasto_sucursal_fecha (id_sucursal, creado_en),
  CONSTRAINT fk_gasto_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_gasto_proveedor FOREIGN KEY (id_sucursal, id_proveedor) REFERENCES proveedor (id_sucursal, id),
  CONSTRAINT fk_gasto_asiento FOREIGN KEY (id_asiento) REFERENCES asiento_caja (id),
  CONSTRAINT fk_gasto_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permiso (clave, descripcion) VALUES
  ('inventario_opera', 'Administrar insumos, compras, recetas y mermas'),
  ('gastos_opera', 'Registrar y consultar gastos');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe WHERE
    (p.clave IN ('administrador','gerente','almacen') AND pe.clave = 'inventario_opera')
    OR (p.clave IN ('administrador','gerente','cajero') AND pe.clave = 'gastos_opera');
-- FIN 011_inventario.sql

-- ============================================================================
-- INICIO 012_reservaciones.sql
-- ============================================================================
SET NAMES utf8mb4;

ALTER TABLE sucursal
  ADD COLUMN horario_publico VARCHAR(160) NOT NULL DEFAULT '',
  ADD COLUMN whatsapp_publico VARCHAR(20) NOT NULL DEFAULT '',
  ADD KEY ix_sucursal_clave (clave);

CREATE TABLE reservacion (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_mesa INT UNSIGNED DEFAULT NULL,
  cliente VARCHAR(100) NOT NULL,
  telefono VARCHAR(25) NOT NULL,
  personas TINYINT UNSIGNED NOT NULL,
  desde DATETIME NOT NULL,
  hasta DATETIME NOT NULL,
  estado ENUM('solicitada','confirmada','atendida','cancelada') NOT NULL DEFAULT 'solicitada',
  creada_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_reservacion_agenda (id_sucursal, desde, estado),
  KEY ix_reservacion_mesa (id_mesa, estado, desde, hasta),
  CONSTRAINT fk_reservacion_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_reservacion_mesa FOREIGN KEY (id_sucursal, id_mesa) REFERENCES mesa (id_sucursal, id),
  CONSTRAINT ck_reservacion_intervalo CHECK (hasta > desde AND personas > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permiso (clave, descripcion) VALUES
  ('reservaciones_opera', 'Administrar reservaciones de la sucursal'),
  ('reportes_restaurante', 'Consultar reportes del restaurante');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe
  WHERE p.clave IN ('administrador','gerente') AND pe.clave IN ('reservaciones_opera','reportes_restaurante');
-- FIN 012_reservaciones.sql

-- ============================================================================
-- INICIO 013_indices_operacion.sql
-- ============================================================================
SET NAMES utf8mb4;

ALTER TABLE pago_cuenta ADD KEY ix_pago_fecha (pagado_en, id_cuenta);
ALTER TABLE trabajo_impresion
  ADD COLUMN id_original BIGINT UNSIGNED DEFAULT NULL,
  ADD KEY ix_impresion_original (id_original, estado),
  ADD CONSTRAINT fk_impresion_original FOREIGN KEY (id_original) REFERENCES trabajo_impresion (id);
-- FIN 013_indices_operacion.sql

-- ============================================================================
-- INICIO 014_eventos_cuenta.sql
-- ============================================================================
SET NAMES utf8mb4;

-- Cada evento dice a qué cuenta pertenece, para que la app recargue sólo esa
-- cuenta y no todo el salón. Los eventos que no son de una cuenta (plano,
-- menú, impresión) lo dejan vacío.
ALTER TABLE evento_sucursal ADD COLUMN id_cuenta BIGINT UNSIGNED DEFAULT NULL;
-- FIN 014_eventos_cuenta.sql

-- ============================================================================
-- INICIO 015_cobro.sql
-- ============================================================================
-- Cobro con cambio y folio por sucursal, comensales por cuenta y faltantes de
-- inventario. Toda columna nueva lleva DEFAULT: lo ya cobrado no se toca.
SET NAMES utf8mb4;

ALTER TABLE pago_cuenta
  ADD COLUMN folio VARCHAR(24) DEFAULT NULL,
  ADD COLUMN descuento_motivo VARCHAR(120) DEFAULT NULL,
  ADD UNIQUE KEY uq_pago_folio (folio);

-- `importe` sigue siendo lo que se aplica a la cuenta. `recibido` es lo que el
-- cliente entregó en efectivo y `cambio` lo que se le regresa: el corte no cambia.
ALTER TABLE pago_cuenta_forma
  ADD COLUMN recibido DECIMAL(12,2) UNSIGNED DEFAULT NULL,
  ADD COLUMN cambio DECIMAL(12,2) UNSIGNED NOT NULL DEFAULT 0;

ALTER TABLE cuenta ADD COLUMN comensales TINYINT UNSIGNED DEFAULT NULL;

-- Lo que una receta pedía y el almacén no tenía al cobrar. El cobro no se
-- detiene: el faltante queda aquí para que almacén lo atienda.
CREATE TABLE faltante_insumo (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  id_insumo INT UNSIGNED NOT NULL,
  id_cuenta BIGINT UNSIGNED NOT NULL,
  cantidad DECIMAL(12,3) UNSIGNED NOT NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atendido_en DATETIME DEFAULT NULL,
  atendido_por INT UNSIGNED DEFAULT NULL,
  nota VARCHAR(160) DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_faltante_pendiente (id_sucursal, atendido_en, id),
  KEY ix_faltante_cuenta (id_cuenta),
  CONSTRAINT fk_faltante_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_faltante_insumo FOREIGN KEY (id_insumo) REFERENCES insumo (id),
  CONSTRAINT fk_faltante_cuenta FOREIGN KEY (id_cuenta) REFERENCES cuenta (id),
  CONSTRAINT fk_faltante_atendio FOREIGN KEY (atendido_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- FIN 015_cobro.sql

-- ============================================================================
-- INICIO 016_cuentas_separadas_mostrador.sql
-- ============================================================================
SET NAMES utf8mb4;

ALTER TABLE cuenta
  DROP CONSTRAINT ck_cuenta_tipo,
  MODIFY COLUMN tipo ENUM('mesa','llevar','domicilio','mostrador') NOT NULL,
  ADD COLUMN id_cuenta_madre BIGINT UNSIGNED DEFAULT NULL,
  ADD COLUMN ajuste_reparto DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  ADD KEY ix_cuenta_madre_abierta (id_sucursal, id_cuenta_madre, abierta, id),
  ADD CONSTRAINT fk_cuenta_madre FOREIGN KEY (id_sucursal, id_cuenta_madre) REFERENCES cuenta (id_sucursal, id),
  ADD CONSTRAINT ck_cuenta_tipo CHECK (
    (tipo = 'mesa' AND (id_mesa IS NOT NULL OR id_cuenta_madre IS NOT NULL))
    OR (tipo <> 'mesa' AND id_mesa IS NULL AND id_cuenta_madre IS NULL)
  );
-- FIN 016_cuentas_separadas_mostrador.sql

-- ============================================================================
-- INICIO 017_cocina_impresion.sql
-- ============================================================================
SET NAMES utf8mb4;

ALTER TABLE trabajo_impresion
  ADD COLUMN IF NOT EXISTS intentos TINYINT UNSIGNED NOT NULL DEFAULT 0;

INSERT INTO permiso (clave, descripcion) VALUES ('menu_agota', 'Marcar y retirar agotados de la sucursal');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT puesto.id, permiso.id FROM puesto CROSS JOIN permiso
  WHERE permiso.clave = 'menu_agota' AND puesto.clave IN ('administrador','gerente','cocina','barra');
-- FIN 017_cocina_impresion.sql

-- ============================================================================
-- INICIO 018_consulta_y_faltantes.sql
-- ============================================================================
SET NAMES utf8mb4;

INSERT INTO permiso (clave, descripcion) VALUES
  ('caja_consulta', 'Consultar turnos y cortes de caja'),
  ('faltantes_atiende', 'Atender faltantes de insumos registrados en caja');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe WHERE
    (p.clave IN ('administrador','gerente','cajero') AND pe.clave = 'caja_consulta')
    OR (p.clave IN ('administrador','gerente','almacen') AND pe.clave = 'faltantes_atiende');
-- FIN 018_consulta_y_faltantes.sql

-- ============================================================================
-- INICIO 019_horarios_reservacion.sql
-- ============================================================================
SET NAMES utf8mb4;

CREATE TABLE sucursal_horario (
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  dia TINYINT UNSIGNED NOT NULL,
  abre TIME NOT NULL,
  cierra TIME NOT NULL,
  PRIMARY KEY (id_sucursal, dia),
  CONSTRAINT ck_horario_dia CHECK (dia BETWEEN 1 AND 7),
  CONSTRAINT ck_horario_turno CHECK (abre BETWEEN '00:00:00' AND '23:59:59'
    AND cierra BETWEEN '00:00:00' AND '23:59:59' AND abre <> cierra),
  CONSTRAINT fk_horario_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE reservacion
  MODIFY COLUMN estado ENUM('solicitada','confirmada','atendida','cancelada','ausente') NOT NULL DEFAULT 'solicitada',
  ADD COLUMN folio VARCHAR(28) DEFAULT NULL,
  ADD COLUMN nota VARCHAR(240) NOT NULL DEFAULT '',
  ADD COLUMN solicitante_hash CHAR(64) DEFAULT NULL,
  ADD UNIQUE KEY uq_reserva_folio (folio),
  ADD KEY ix_reserva_solicitante (id_sucursal, solicitante_hash, creada_en);
-- FIN 019_horarios_reservacion.sql

-- ============================================================================
-- INICIO 020_especialidad.sql
-- ============================================================================
SET NAMES utf8mb4;

ALTER TABLE platillo ADD COLUMN especialidad TINYINT UNSIGNED NOT NULL DEFAULT 0;
-- FIN 020_especialidad.sql

-- ============================================================================
-- INICIO 021_compras_recepcion.sql
-- ============================================================================
SET NAMES utf8mb4;

ALTER TABLE compra_insumo
  MODIFY COLUMN estado ENUM('ordenada','parcial','recibida','cancelada') NOT NULL DEFAULT 'ordenada';

ALTER TABLE compra_insumo_linea
  ADD COLUMN recibido DECIMAL(12,3) UNSIGNED NOT NULL DEFAULT 0,
  ADD CONSTRAINT ck_compra_recibido CHECK (recibido <= cantidad);

UPDATE compra_insumo_linea l JOIN compra_insumo c ON c.id = l.id_compra
  SET l.recibido = l.cantidad WHERE c.estado = 'recibida';
-- FIN 021_compras_recepcion.sql

-- ============================================================================
-- INICIO 022_gasto_cancelacion.sql
-- ============================================================================
SET NAMES utf8mb4;

ALTER TABLE gasto_sucursal
  ADD COLUMN version INT UNSIGNED NOT NULL DEFAULT 1,
  ADD COLUMN cancelado_en DATETIME DEFAULT NULL,
  ADD COLUMN motivo_cancelacion VARCHAR(160) DEFAULT NULL;
-- FIN 022_gasto_cancelacion.sql

-- ============================================================================
-- INICIO 023_bajas_catalogo.sql
-- ============================================================================
SET NAMES utf8mb4;

ALTER TABLE area ADD COLUMN activa TINYINT UNSIGNED NOT NULL DEFAULT 1;
ALTER TABLE mesa ADD COLUMN activa TINYINT UNSIGNED NOT NULL DEFAULT 1;
ALTER TABLE categoria_menu ADD COLUMN activa TINYINT UNSIGNED NOT NULL DEFAULT 1;
ALTER TABLE insumo ADD COLUMN activo TINYINT UNSIGNED NOT NULL DEFAULT 1;
ALTER TABLE proveedor ADD COLUMN activo TINYINT UNSIGNED NOT NULL DEFAULT 1;
-- FIN 023_bajas_catalogo.sql

-- ============================================================================
-- INICIO 024_carta_y_promociones.sql
-- ============================================================================
SET NAMES utf8mb4;

-- La carta impresa se arma con el panel: leyenda por categoría, porción y
-- orden de cada platillo (la carta no va en orden alfabético).
ALTER TABLE categoria_menu ADD COLUMN descripcion VARCHAR(300) NOT NULL DEFAULT '';
ALTER TABLE platillo
  ADD COLUMN porcion VARCHAR(40) NOT NULL DEFAULT '',
  ADD COLUMN orden SMALLINT UNSIGNED NOT NULL DEFAULT 0;

-- Promociones por platillo. Se aplican solas al capturar: porcentaje, precio
-- especial o N×M (lleva N, paga M), con fechas, días y horario.
CREATE TABLE promocion (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(80) NOT NULL,
  tipo ENUM('porcentaje','precio','nxm') NOT NULL,
  valor DECIMAL(10,2) UNSIGNED DEFAULT NULL COMMENT 'Porcentaje de 1 a 90 o precio especial',
  lleva TINYINT UNSIGNED DEFAULT NULL,
  paga TINYINT UNSIGNED DEFAULT NULL,
  desde DATE NOT NULL,
  hasta DATE DEFAULT NULL,
  dias TINYINT UNSIGNED NOT NULL DEFAULT 127 COMMENT 'Máscara: lunes = 1, martes = 2 … domingo = 64',
  hora_inicio TIME DEFAULT NULL,
  hora_fin TIME DEFAULT NULL,
  activa TINYINT UNSIGNED NOT NULL DEFAULT 1,
  baja TINYINT UNSIGNED NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creado_por INT UNSIGNED DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_promocion_vigencia (desde, hasta),
  CONSTRAINT ck_promocion_dias CHECK (dias BETWEEN 1 AND 127),
  CONSTRAINT ck_promocion_fechas CHECK (hasta IS NULL OR hasta >= desde),
  CONSTRAINT ck_promocion_nxm CHECK (tipo <> 'nxm' OR (lleva BETWEEN 2 AND 10 AND paga BETWEEN 1 AND lleva - 1)),
  CONSTRAINT ck_promocion_valor CHECK (tipo = 'nxm' OR valor > 0),
  CONSTRAINT ck_promocion_horario CHECK ((hora_inicio IS NULL) = (hora_fin IS NULL)),
  CONSTRAINT fk_promocion_usuario FOREIGN KEY (creado_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE promocion_sucursal (
  id_promocion INT UNSIGNED NOT NULL,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (id_promocion, id_sucursal),
  KEY ix_promocion_sucursal (id_sucursal),
  CONSTRAINT fk_promo_suc_promocion FOREIGN KEY (id_promocion) REFERENCES promocion (id),
  CONSTRAINT fk_promo_suc_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE promocion_platillo (
  id_promocion INT UNSIGNED NOT NULL,
  id_platillo INT UNSIGNED NOT NULL,
  PRIMARY KEY (id_promocion, id_platillo),
  KEY ix_promocion_platillo (id_platillo),
  CONSTRAINT fk_promo_pla_promocion FOREIGN KEY (id_promocion) REFERENCES promocion (id),
  CONSTRAINT fk_promo_pla_platillo FOREIGN KEY (id_platillo) REFERENCES platillo (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- El renglón guarda la promoción con la que se capturó y lo que rebaja. El
-- precio sigue siendo el de lista más suplementos; el importe es
-- cantidad × precio − descuento.
ALTER TABLE cuenta_item
  ADD COLUMN id_promocion INT UNSIGNED DEFAULT NULL,
  ADD COLUMN promocion VARCHAR(80) NOT NULL DEFAULT '',
  ADD COLUMN descuento DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0,
  ADD KEY ix_cuenta_item_promocion (id_promocion),
  ADD CONSTRAINT fk_cuenta_item_promocion FOREIGN KEY (id_promocion) REFERENCES promocion (id);

INSERT INTO permiso (clave, descripcion) VALUES
  ('promocion_admin', 'Crear, pausar y dar de baja promociones de platillos');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe
  WHERE p.clave IN ('administrador','gerente') AND pe.clave = 'promocion_admin';

-- Los textos fijos de la carta impresa. Se cambian desde la pantalla Carta.
INSERT INTO parametro (clave, valor, descripcion, vigente_desde) VALUES
  ('carta_fundacion', '2020', 'Año de fundación que muestra la carta', '2026-01-01'),
  ('carta_sello', 'Sabor único', 'Frase destacada del encabezado de la carta', '2026-01-01'),
  ('carta_lema', 'Calidad • Calidez • Sabor • Frescura', 'Lema del pie de la carta', '2026-01-01'),
  ('carta_advertencia', 'Los alimentos crudos o poco cocidos incrementan el riesgo de intoxicaciones e infecciones en personas sensibles al consumo. Es responsabilidad de quien lo pide.', 'Advertencia sanitaria del pie de la carta', '2026-01-01'),
  ('carta_pagos', 'Aceptamos pagos en efectivo, tarjeta Visa, Mastercard y American Express.', 'Formas de pago del pie de la carta', '2026-01-01');
-- FIN 024_carta_y_promociones.sql

-- ============================================================================
-- INICIO 025_servidor_sucursal.sql
-- ============================================================================
SET NAMES utf8mb4;

-- Servidor de sucursal: una copia del sistema en la red del restaurante que
-- sigue operando sin internet y se sincroniza con el central.
--
-- Una sucursal `local` escribe su operación solo en su servidor; el central
-- la recibe por réplica y rechaza escribirla por su cuenta.
ALTER TABLE sucursal
  ADD COLUMN servidor ENUM('central','local') NOT NULL DEFAULT 'central'
  COMMENT 'Dónde se escribe la operación de la sucursal';

-- Los servidores de sucursal que conoce el central. Cada uno se autentica con
-- su secreto (se guarda solo el SHA-256) y reparte ids con su desplazamiento:
-- todas las instalaciones usan incremento 100; el central, desplazamiento 1.
CREATE TABLE instalacion (
  id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(80) NOT NULL,
  id_sucursal SMALLINT UNSIGNED NOT NULL,
  desplazamiento TINYINT UNSIGNED NOT NULL,
  secreto_hash CHAR(64) NOT NULL,
  activa TINYINT UNSIGNED NOT NULL DEFAULT 1,
  version VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'Liberación que reportó el servidor',
  ultimo_cambio BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Último cambio aplicado de su subida',
  ultima_subida DATETIME DEFAULT NULL,
  ultima_bajada DATETIME DEFAULT NULL,
  pendientes INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Cambios por subir que reportó en su último contacto',
  ultimo_error VARCHAR(300) NOT NULL DEFAULT '',
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creado_por INT UNSIGNED DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_instalacion_sucursal (id_sucursal),
  UNIQUE KEY uq_instalacion_desplazamiento (desplazamiento),
  UNIQUE KEY uq_instalacion_secreto (secreto_hash),
  CONSTRAINT ck_instalacion_desplazamiento CHECK (desplazamiento BETWEEN 2 AND 99),
  CONSTRAINT fk_instalacion_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursal (id),
  CONSTRAINT fk_instalacion_usuario FOREIGN KEY (creado_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lo que el servidor de sucursal tiene por subir. Lo llenan disparadores en la
-- misma transacción que el cambio; en el central queda vacía.
CREATE TABLE cambio_replica (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tabla VARCHAR(40) NOT NULL,
  llave VARCHAR(120) NOT NULL COMMENT 'Llave primaria de la fila, en JSON',
  momento DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  enviado TINYINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY ix_cambio_replica_pendiente (enviado, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La bitácora que sube de una sucursal recibe un id nuevo en el central (el
-- sello encadena por id) y guarda de dónde vino, para que reenviar no duplique.
ALTER TABLE bitacora
  ADD COLUMN origen_instalacion SMALLINT UNSIGNED DEFAULT NULL,
  ADD COLUMN origen_id BIGINT UNSIGNED DEFAULT NULL,
  ADD UNIQUE KEY uq_bitacora_origen (origen_instalacion, origen_id);

INSERT INTO permiso (clave, descripcion) VALUES
  ('servidor_admin', 'Registrar servidores de sucursal y revisar su sincronización');

INSERT INTO puesto_permiso (id_puesto, id_permiso)
  SELECT p.id, pe.id FROM puesto p CROSS JOIN permiso pe
  WHERE p.clave = 'administrador' AND pe.clave = 'servidor_admin';
-- FIN 025_servidor_sucursal.sql

-- ============================================================================
-- INICIO 026_liberaciones.sql
-- ============================================================================
SET NAMES utf8mb4;

-- Actualizaciones de las computadoras de sucursal (docs/servidor-sucursal.md).
--
-- El central guarda los paquetes firmados del sistema y a cuál debe llegar
-- cada computadora. La computadora lo pregunta, lo baja, comprueba la firma
-- con la llave pública que ya trae y lo instala cuando no hay cuentas ni turno
-- abiertos. El central nunca empuja nada: no necesita entrar al local.
CREATE TABLE liberacion (
  id VARCHAR(100) NOT NULL COMMENT 'El id de config/liberacion.php del paquete',
  esquema SMALLINT UNSIGNED NOT NULL COMMENT 'Último guion de esquema que trae',
  sha256 CHAR(64) NOT NULL,
  firma VARCHAR(100) NOT NULL COMMENT 'Ed25519 en base64 sobre id, esquema y sha256',
  peso BIGINT UNSIGNED NOT NULL,
  notas VARCHAR(300) NOT NULL DEFAULT '',
  creada_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  creada_por INT UNSIGNED DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_liberacion_sha256 (sha256),
  CONSTRAINT fk_liberacion_usuario FOREIGN KEY (creada_por) REFERENCES usuario (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- `version` (guion 025) sigue siendo la liberación que la computadora reporta
-- en cada contacto; aquí va la que debe tener y cómo va su actualización.
ALTER TABLE instalacion
  ADD COLUMN liberacion_asignada VARCHAR(100) DEFAULT NULL COMMENT 'La versión que debe instalar; null es quedarse como está',
  ADD COLUMN actualizacion VARCHAR(200) NOT NULL DEFAULT '' COMMENT 'Lo último que reportó su actualizador',
  ADD COLUMN actualizacion_error TINYINT UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN actualizada_en DATETIME DEFAULT NULL,
  ADD CONSTRAINT fk_instalacion_liberacion FOREIGN KEY (liberacion_asignada) REFERENCES liberacion (id);
-- FIN 026_liberaciones.sql

-- ============================================================================
-- INICIO 027_indice_version_instalacion.sql
-- ============================================================================
SET NAMES utf8mb4;

-- La lista de liberaciones cuenta las computadoras que ya tienen cada versión.
-- Es aditivo: el código anterior sigue funcionando y permite regresar.
CREATE INDEX ix_instalacion_version_activa ON instalacion (version, activa);
-- FIN 027_indice_version_instalacion.sql

-- El importador no ejecuta el registro que hace aplica-esquema.php después
-- de cada archivo. En una instalación nueva, este bloque deja el mismo libro.
INSERT IGNORE INTO migracion_esquema (numero, nombre, sha256) VALUES
  (1, '001_catalogos.sql', 'a53ce52cd27afc1da7660ed00403322e73f0e87abdd3a182cb4afc2c3e2bbdd3'),
  (2, '002_organizacion.sql', '71780a1be94e782330fdbc4319828371dc96e666b9c029bd809c6823afac4d9b'),
  (3, '003_personal_usuarios.sql', 'cef1f2c073f1c350ace96c2ba62f7a73eb1cebbaedf86e3d6aaede76ce9987c4'),
  (4, '004_bitacora_idempotencia.sql', '38855ce6c590ff95a79bacb6d7a4348141169300c8ed23fcec521bfffebf62b1'),
  (5, '005_privacidad_avisos.sql', 'ce49dc81ff3faebe463027307d8639dfaab7875a983f0c30b7d0a469172ef883'),
  (6, '006_datos_base.sql', '7644b6a9a69bb8a2a80a6faa27bb109e707ad20d9d2c0f0a165fdd7c10eb3b8f'),
  (7, '007_restaurante.sql', '81b0425203df8a70c78623b007b053cd8aa23dfd4ba30a4c5c30690cea44a0e1'),
  (8, '008_comanda.sql', 'f27d3d09313ae30874a4e8151695f711515157c881fc8c206ee325dd0cb76f98'),
  (9, '009_equipo_restaurante.sql', '3c11c4dd4ed705e8444f15f5d1f1234addd9aa6b431900941290f62a971a0341'),
  (10, '010_cocina_caja.sql', '7bbeb4baa3f7e9b3d177524ed8d6eef97419f2c79a1408b5634b2f7ef38cd5d0'),
  (11, '011_inventario.sql', '1b9f1f08725942510fdaa03583fc2634113b97d362ded9961872d86912a3df6b'),
  (12, '012_reservaciones.sql', 'c0f59488d0e4216c5d5b9e9365cd3acec205e5ad4ac86a720da1a6ac02834f82'),
  (13, '013_indices_operacion.sql', 'ac0c2f8e783ef0e4d16cf409e2db64304bd7d06569e56107325bd2b24af82906'),
  (14, '014_eventos_cuenta.sql', '96031fcb8ff41672800e4ac27b502d1baa518751936e17392112ee8900112348'),
  (15, '015_cobro.sql', 'f0ba2b8fe5bbbb9f4acdbe1a1cfed6824824853955660062e5216211a820b6f1'),
  (16, '016_cuentas_separadas_mostrador.sql', '8b3dcfa4a125f98d36af935b7db0e5fe07a7f0e59b495264e2a447a9bd2fdb3e'),
  (17, '017_cocina_impresion.sql', '93aee212d0633d146621262192aa172f381d247cfa61bd8d5615aa1bef1d4808'),
  (18, '018_consulta_y_faltantes.sql', 'e0046203310a929989004ab4bd1dd6ab3f5a4fc08f44df5ec464a64253fc3e3b'),
  (19, '019_horarios_reservacion.sql', '25adc6968210fdf838750c9bad28380cd7ec256f2a1c31e5735e7a7e61c68b72'),
  (20, '020_especialidad.sql', '7830b90591e475a86e7a3388dcb9764c3cf231c1d06687489b2636f130838dd9'),
  (21, '021_compras_recepcion.sql', '66a0dcae244279eca8bef7d0b640c99c09260d69a4e665341e15252d6187c4c3'),
  (22, '022_gasto_cancelacion.sql', 'fa6a744baa369fa52f9dcdf1eb974e327d2bfc342fbc790df5fcabd1d79bf9f4'),
  (23, '023_bajas_catalogo.sql', 'c6d04606cf7a01b0d29b201245cdbf2125a13aa3613b3aec741c5a40b8f42a63'),
  (24, '024_carta_y_promociones.sql', '6eb77b6c546894fe5e1de121bc1cce56cb2b97b876445103c44ca817f54d0841'),
  (25, '025_servidor_sucursal.sql', '2c22a7530f66a09e6479ae351bed190cba706ffd371c22b097b2cce175624054'),
  (26, '026_liberaciones.sql', '71ad126b5c0a5d206156ad12c686bf139cfe9b0713782d672fe84a5b65cc5ab4'),
  (27, '027_indice_version_instalacion.sql', '85ea064fb8fc2c2199c04d594e4adcc232204552b62f980bbc6a644ab545033e');
