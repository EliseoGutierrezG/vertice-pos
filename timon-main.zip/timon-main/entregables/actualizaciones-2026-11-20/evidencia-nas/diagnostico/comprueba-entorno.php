<?php
declare(strict_types=1);

// Diagnóstico de instalación: no carga configuraciones ni credenciales.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

$extensiones = [];
foreach (['mysqli', 'mbstring', 'gd', 'curl', 'json', 'openssl', 'fileinfo', 'sodium', 'zlib'] as $nombre) {
    $extensiones[$nombre] = extension_loaded($nombre);
}

echo json_encode([
    'diagnostico' => 'entorno-web-timon',
    'php' => PHP_VERSION,
    'interfaz' => PHP_SAPI,
    'https' => ($_SERVER['HTTPS'] ?? '') === 'on',
    'extensiones' => $extensiones,
    'proc_open_disponible' => function_exists('proc_open'),
    'phar_disponible' => class_exists('PharData'),
    'enlaces_disponibles' => function_exists('symlink'),
    'autoload_presente' => is_file(__DIR__ . '/../nucleo/Autocargador.php'),
    'bd_configurada' => is_file(__DIR__ . '/../config/bd.php'),
    'app_configurada' => is_file(__DIR__ . '/../config/app.php'),
    'seguridad_configurada' => is_file(__DIR__ . '/../config/seguridad.php'),
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
