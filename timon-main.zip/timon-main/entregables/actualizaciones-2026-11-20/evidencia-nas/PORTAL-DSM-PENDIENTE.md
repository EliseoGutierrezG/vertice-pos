# Portal de prueba de Timón en DSM

Este es el único trabajo pendiente para abrir Timón de forma segura. La carga y la base ya existen; no se debe publicar la copia temporal que quedó bajo `web/vertice-pos/timon`.

## Rutas del proyecto

Usar una ruta privada distinta de la carpeta web, ajustando el volumen si el NAS no usa `volume1`:

```text
/volume1/timon/actual/                 código extraído del paquete nuevo
/volume1/timon/actual/publico/         única raíz de documentos del portal
/volume1/timon/actual/app/dist/        alias web /app
/volume1/timon/almacenamiento/         registros, imágenes y respaldos
```

Extraer en `actual` el paquete local firmado:

```text
timon-20261121T060551Z-5582dbf09319.tar.gz
SHA256: 35217a9535a05e4cf91da718c9e4325988c4eabcb78825dee96f49b4e61eb0d4
```

El descriptor `.firma.json` acompaña al paquete. La firma y la huella ya se verificaron antes de esta entrega.

## Portal de Web Station

1. Crear un perfil PHP exclusivo de Timón con PHP 8.2 o posterior y las extensiones ya validadas: mysqli, mbstring, gd, curl, json, openssl, fileinfo, sodium y zlib.
2. Crear un portal de Apache 2.4 exclusivo, con raíz de documentos `/volume1/timon/actual/publico`. Habilitar el enrutamiento de `.htaccess` a `index.php`.
3. Crear el alias `/app` hacia `/volume1/timon/actual/app/dist`.
4. Asignar un host o puerto dedicado con HTTPS y certificado válido. Timón redirige HTTP a HTTPS y no debe vivir bajo `/vertice-pos/`.
5. Dar al usuario que ejecuta PHP escritura solo en `almacenamiento`; no publicar esa carpeta ni `config`.

## Configuración privada

En `/volume1/timon/actual/config/`, partir de los archivos `.ejemplo`.

- `bd.php`: usar base `vertice_pos`, usuario `timon_app`, host `localhost` y puerto `3306`. La persona dueña introduce la contraseña directamente en el NAS. Si la prueba de conexión falla, se diagnostica el host/socket antes de cambiar permisos.
- `app.php`: conservar `entorno => 'produccion'`, `depurar => false`, zona `America/Mexico_City`, poner la URL HTTPS final sin diagonal al final y rutas absolutas de `registros` e `imagenes` dentro de `/volume1/timon/almacenamiento/`.
- `seguridad.php`: generar dos llaves independientes con `php guiones/genera-clave-seguridad.php`; una para `llave_totp` y otra para `llave_sello`. Guardar una copia privada y no enviarlas por chat.
- No crear `instalacion.php` hasta registrar esta sucursal en el central de **staging**. Sin ese archivo la aplicación funciona sola y no intenta sincronizar contra Hostinger.

## Validación después de publicar

1. Abrir la URL HTTPS final y confirmar que el diagnóstico temporal ya no es necesario.
2. Desde una tarea manual de DSM o una consola autorizada, ejecutar el mismo binario PHP del perfil de Web Station. El siguiente comando es **solo de lectura**: prueba `timon_app`, muestra el estado del esquema y no aplica migraciones:

   ```bash
   /ruta/al/php /ruta/privada/timon/guiones/migraciones.php --estado
   ```

   Debe indicar `Base: vertice_pos`, `registradas: 27`, `disponibles: 27` y `Estado: al día.`. Si no sucede, detenerse y corregir conexión o ruta; no ejecutar `--aplicar` sobre la base ya importada.
3. Crear el primer administrador sólo después de la comprobación anterior:

   ```bash
   /ruta/al/php /ruta/privada/timon/guiones/crear-usuario.php
   ```

   El guion pide nombre, usuario y contraseña sin mostrarla. La persona administradora debe teclearla directamente; no usar argumentos ni enviar valores por chat.
4. Iniciar sesión por HTTPS en `/entrar` y comprobar que las rutas del panel responden. Retirar `publico/comprueba-entorno.php` si se utilizó y confirmar que no quedó ningún archivo de configuración en `web/`.
5. Solo después, registrar la sucursal en staging, añadir `instalacion.php` y programar la sincronización.
