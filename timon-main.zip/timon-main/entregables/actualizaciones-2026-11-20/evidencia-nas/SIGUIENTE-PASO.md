# Ajuste del NAS para abrir Timón

## Resultado comprobado en la carpeta real

La comprobación HTTP posterior al ajuste del dueño, en `vertice-pos/timon/publico/comprueba-entorno.php`, devolvió PHP **8.2.30**, interfaz `fpm-fcgi`. **Todas las extensiones comprobadas están disponibles: mysqli, mbstring, gd, curl, json, openssl, fileinfo, sodium y zlib. PharData, proc_open y symlink también están disponibles.** El guion no carga credenciales ni configuraciones privadas. La respuesta actual está en `diagnostico/resultado-entorno-validado.json`; `resultado-entorno.json` conserva la comprobación anterior al ajuste. La validación de extensiones no comprueba la conexión a MariaDB ni el funcionamiento completo de la aplicación.

La cuenta `timon_app@localhost` fue creada por el usuario. Se corrigió, con su confirmación, el permiso que tenía un escape duplicado. phpMyAdmin comprobó acceso específico a `vertice_pos`, `ALL PRIVILEGES`, `Grant: No`. No se ha probado todavía la autenticación con la contraseña de ese usuario ni se ha creado `config/bd.php` en el NAS.

## Acción para la persona administradora de DSM

1. Abrir **Web Station**. Con la sesión DSM disponible, el menú solo mostró File Station, DSM Help, PDF Viewer y Synology Drive; la búsqueda de Web Station devolvió «No match found». Esto acredita que no se pudo abrir con esa sesión, no que el paquete esté desinstalado.
2. **Extensiones comprobadas después del ajuste del dueño.** El perfil actual respondió con PHP 8.2.30 y todas las extensiones requeridas. El proyecto admite PHP 8.2 o posterior para este perfil; PHP 8.3 sigue siendo el estándar del central y debe adoptarse en el NAS cuando esté disponible. Mantener el perfil exclusivo de Timón, sin cambiar el de otros sitios.
3. Crear una ruta privada, por ejemplo `/volume1/timon/actual`, y extraer ahí el paquete nuevo `timon-20261121T060551Z-5582dbf09319.tar.gz`. La copia actual en `web/vertice-pos/timon` es solo transferencia y no debe alojar configuración ni ser el portal final.
4. Crear un servicio/portal exclusivo para Timón. El proyecto supone vivir en la raíz de un host, no bajo `/vertice-pos/`. La raíz de documentos debe ser **solo `/volume1/timon/actual/publico`** y `/app` debe apuntar a `/volume1/timon/actual/app/dist`.
5. Dejar configuraciones, almacenamiento, respaldos, esquemas, guiones y paquetes fuera de cualquier raíz pública. Configurar el enrutamiento a `index.php`; se recomienda Apache 2.4 porque el proyecto incluye reglas `.htaccess`. Si se usa Nginx, el administrador debe traducir esas reglas antes de publicar.
6. Asignar HTTPS y un certificado válido al host o puerto exclusivo, y confirmar la URL final. No desactivar la redirección HTTPS del sistema.
7. Con la ruta privada protegida, completar `config/bd.php`, `app.php` y `seguridad.php` en el servidor. La contraseña nueva de `timon_app` la introduce el usuario directamente. No crear todavía `config/instalacion.php`: se completa cuando el central de staging registre esta sucursal y proporcione su secreto.
8. Consultar `PORTAL-DSM-PENDIENTE.md` para las rutas y el orden exactos. Después se comprobarán conexión, inicio de sesión y módulos; la réplica con staging y las actualizaciones se configuran en una etapa posterior.

## Documentación oficial consultada

- [Perfiles PHP de Web Station](https://kb.synology.com/en-global/DSM/help/WebStation/application_webserv_php).
- [Servicios web de Web Station](https://kb.synology.com/en-us/DSM/help/WebStation/application_webserv_webservice?version=7).

No se cambiaron perfiles, puertos, usuarios de DSM ni servicios de otros sistemas. No se ha publicado una conexión privada ni activado la sincronización con Hostinger.
