# Carga inicial del NAS — 2026-11-20

## Código transferido

- Destino observado en File Station: `/web/vertice-pos/timon`.
- Paquete: `timon-20261121T034158Z-0e90a9234a16.tar.gz` (6.431.915 bytes).
- SHA256 local comprobado: `22cacabac74ef6051470bcf50c7c976b319434a6f56b451c64db417551916a06`.
- Se subieron el paquete y su firma; DSM extrajo primero `.gz` a `.tar` y luego `.tar` a la carpeta `timon`.
- Se verificaron las 15 carpetas superiores, incluida la PWA en `app` y el esquema en `instalacion`.
- Se conservaron `config.php`, `index.html` y `test_db.php` preexistentes.
- El paquete no contiene conexiones privadas de la aplicación ni la llave privada de firma.
- Evidencia visual: `codigo-extraido.jpg`.

## Paquete corregido, listo para sustituir la copia de transferencia

- La comprobación de compatibilidad se ajustó a PHP **8.2 o posterior** para el perfil Synology. PHP 8.3 sigue siendo el estándar del central y de desarrollo.
- Paquete firmado nuevo: `timon-20261121T060551Z-5582dbf09319.tar.gz`.
- SHA256: `35217a9535a05e4cf91da718c9e4325988c4eabcb78825dee96f49b4e61eb0d4`.
- Descriptor: `timon-20261121T060551Z-5582dbf09319.firma.json`.
- Se comprobó localmente la firma Ed25519, el tamaño y la huella del paquete con la llave pública incluida.
- El paquete anterior ya extraído en `/web/vertice-pos/timon` no contiene esta corrección. No debe publicarse ni recibir credenciales: es una copia de transferencia que se reemplazará al crear la ruta privada del portal.

## Carga y extracción comprobadas en DSM — 21 de noviembre

- Se cargaron correctamente al NAS el nuevo `.tar.gz`, su descriptor `.firma.json` y, para la extracción compatible con File Station, el `.tar` equivalente.
- File Station extrajo el código a `/web/vertice-pos/timon-20261121T060551Z-5582dbf09319/timon` sin sobrescribir `/web/vertice-pos/timon` ni los archivos preexistentes de Vértice.
- Se verificaron las 15 carpetas principales del candidato extraído: `app`, `config`, `controladores`, `despliegue`, `docs`, `dominio`, `esquema`, `guiones`, `instalacion`, `modelos`, `nucleo`, `publico`, `rutas`, `servicios` y `vistas`.
- El punto de entrada del nuevo candidato responde: al abrir `http://100.117.3.111/vertice-pos/timon-20261121T060551Z-5582dbf09319/timon/publico/` redirige a HTTPS y devuelve 500 porque todavía no existen las configuraciones privadas. Este resultado confirma que PHP procesa el código; no se considerará una publicación válida hasta crear el portal propio y completar la configuración.
- El menú de esta sesión DSM continúa mostrando solamente File Station, DSM Help, PDF Viewer y Synology Drive. No hay acceso visible a Web Station ni a Control Panel, por lo que no fue posible crear el host HTTPS ni configurar un perfil PHP desde esta cuenta.

## Limpieza aprobada y comprobada — 21 de noviembre

- Con confirmación expresa del usuario se retiraron los siete temporales de `/web/vertice-pos`: la carpeta antigua `timon`; los tres archivos del candidato `20261121T034158Z-0e90a9234a16`; y los tres archivos de empaquetado ya usados del candidato vigente `20261121T060551Z-5582dbf09319`.
- Se conservaron únicamente `timon-20261121T060551Z-5582dbf09319` (que contiene el código nuevo extraído) y los tres archivos preexistentes de Vértice: `config.php`, `index.html` y `test_db.php`.
- File Station confirmó que `/web/vertice-pos` quedó con exactamente esos cuatro elementos. La base `vertice_pos` no se modificó.

## Base de datos importada y comprobada

- Destino de la importación: `vertice_pos`, comprobada vacía antes del envío.
- Archivo: `esquema.sql`, 231.359 bytes, 27 guiones y 63 tablas declaradas.
- SHA256 del SQL verificado contra el manifiesto del paquete: `049c5b1c0152ac41fb69b4e1249bcfba0e43bd2d86bc02d6ad4f6557f8b041c1`.
- Se seleccionó el archivo y se pulsó Import en phpMyAdmin una sola vez. La pestaña inicial quedó esperando; después se comprobó el resultado desde una pestaña nueva.
- Confirmación directa en la estructura de `vertice_pos`: **63 tablas**, datos iniciales presentes y **27 filas en `migracion_esquema`**.
- Evidencia visual: `base-importada.jpg`. No se repitió la importación.
- Este SQL instala estructura y datos base; no es un volcado de ventas o datos cotidianos de la Mac.

## No operativo todavía

El usuario creó `timon_app@localhost`. Se corrigió con su confirmación el permiso de base y se retiró la entrada con escape duplicado. La comprobación final mostró únicamente el permiso correcto para `vertice_pos`, sin GRANT OPTION y sin privilegios globales. Falta configurar y probar la conexión privada de la aplicación, el portal y la raíz pública. La copia extraída es una carga inicial de código: no está conectada ni sincronizada con Hostinger.

En el menú DSM solo aparecieron File Station, DSM Help, PDF Viewer y Synology Drive. La búsqueda Web Station devolvió «No match found»; no se pudo configurar con esa sesión.

Después de que el dueño activó las extensiones, una nueva navegación al diagnóstico HTTP confirmó **PHP 8.2.30**, con **GD, cURL, OpenSSL y Sodium cargadas, y PharData disponible**. Mysqli, mbstring, JSON, fileinfo y zlib siguen disponibles; proc_open y symlink también. La respuesta todavía declara HTTPS y las configuraciones bd/app/seguridad en falso. Evidencia actual: `diagnostico/resultado-entorno-validado.json`; el JSON anterior conserva la comprobación previa al ajuste. La aplicación supone una raíz de host y aún no se ha resuelto su publicación bajo `/vertice-pos/`. Véase `SIGUIENTE-PASO.md` para el ajuste del perfil y del portal. El diagnóstico remoto sigue disponible para comprobar esos ajustes; no carga configuraciones ni credenciales.

La compatibilidad de código se validó localmente con PHP **8.2.34**: el verificador de host pasó y las **516 pruebas internas** pasaron sobre la base aislada `timon_pruebas`. Esta evidencia no sustituye la apertura del portal ni una prueba de conexión con la cuenta del NAS.
