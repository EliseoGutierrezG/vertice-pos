# Instalación de El Timón en el host

Este paquete es un **candidato preproductivo**. Permite validar el host y la
instalación sobre una base vacía, pero no debe abrirse todavía al negocio hasta
cerrar los módulos funcionales pendientes y regenerar el paquete final.

## Datos que se completan sin compartir contraseñas

Anotar antes de empezar:

- `DOMINIO`: dominio final, con certificado HTTPS;
- `RUTA`: directorio absoluto fuera de `public_html`, por ejemplo
  `/home/u123456789/domains/ejemplo.com/app`;
- `BASE`, `USUARIO_BD` y `HOST_BD` creados desde el panel;
- versión de PHP CLI, PHP web y MariaDB;
- ruta del ejecutable PHP que usará cron.

La contraseña se teclea directamente en Termius y en `config/bd.php`. No se
manda por chat, no se pone en la línea de comando y no se incluye en el paquete.

## 1. Subir y revisar

Subir estos dos archivos al directorio de la cuenta:

```text
app-candidato-productivo.tar.gz
app-candidato-productivo.tar.gz.sha256
```

En Termius, desde el directorio donde quedaron:

```bash
sha256sum -c app-candidato-productivo.tar.gz.sha256
tar -tzf app-candidato-productivo.tar.gz | less
mkdir -p RUTA_PADRE
tar -xzf app-candidato-productivo.tar.gz -C RUTA_PADRE
cd RUTA_PADRE/app
php guiones/verifica-host.php
```

En macOS puede usarse `shasum -a 256` si el host no ofrece `sha256sum`.

## 2. Publicación segura

En el panel del hosting, apuntar el `DocumentRoot` del dominio exactamente a:

```text
RUTA_PADRE/app/publico
```

No se admite copiar todo el proyecto dentro de `public_html`: `config/`,
`almacenamiento/`, `esquema/`, `guiones/`, `nucleo/` y `servicios/` deben quedar
fuera del alcance HTTP.

Crear la configuración desde las plantillas:

```bash
cp config/app.php.ejemplo config/app.php
cp config/bd.php.ejemplo config/bd.php
php guiones/genera-clave-seguridad.php
chmod 600 config/app.php config/bd.php config/seguridad.php
```

Editar `config/bd.php` en el host con `HOST_BD`, `BASE`, `USUARIO_BD` y la
contraseña. En `config/app.php` conservar:

```text
entorno = produccion
depurar = false
zona_horaria = America/Mexico_City
```

El usuario que ejecuta PHP debe poder escribir en `almacenamiento/`, sin hacer
esa carpeta pública. Los modos exactos dependen del hosting; comenzar con 750
para código, 600 para configuración y 770 para subdirectorios de
`almacenamiento/`, y ajustar el grupo desde el panel si PHP usa otro usuario.

## 3. Base de datos vacía

Comprobar el SQL antes de importarlo:

```bash
cd RUTA_PADRE/app/instalacion
sha256sum -c app-esquema.sql.sha256
```

Confirmar en el panel que `BASE` está vacía. Después:

```bash
mysql -h HOST_BD -u USUARIO_BD -p BASE < app-esquema.sql
```

El cliente pedirá la contraseña de forma interactiva. El SQL consolidado no
crea ni selecciona una base y se niega a incorporar `DROP DATABASE`,
`DROP TABLE`, `CREATE DATABASE` o `USE`. No debe reaplicarse sobre una base con
tablas o datos.

Verificar cantidad y nombres:

```bash
mysql -h HOST_BD -u USUARIO_BD -p BASE -e \
  "SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE' ORDER BY table_name"
```

La instalación debe coincidir con `cantidad_tablas` y `tablas` de
`app-esquema.sql.json` del mismo candidato (esquema 25: **62 tablas**) y
`php guiones/migraciones.php --estado` debe informar que no queda ningún guion
por aplicar.

Crear el primer administrador sin escribir su clave en el historial:

```bash
cd RUTA_PADRE/app
php guiones/crear-usuario.php
```

## 4. HTTPS, humo y cron

Cuando DNS, `DocumentRoot` y certificado estén activos, desde la computadora
que conserva el repositorio ejecutar:

```bash
pruebas/publicacion.sh https://DOMINIO \
  entregables/despliegue/app-candidato-productivo.tar.gz
```

La compuerta verifica la huella del candidato y exige que `/api/v1/salud`
publique exactamente su identificador y versión de esquema. Que `/entrar`
abra no basta para probar que se activó el código recién subido.

No ejecutar `pruebas/todo.sh`, `guiones/prepara-pruebas.php` ni
`guiones/aplica-esquema.php` en producción.

### Respaldo cifrado y alertas

Crear la llave de las copias y la configuración de alertas:

```bash
php guiones/genera-llave-respaldo.php
cp config/alertas.php.ejemplo config/alertas.php
chmod 600 config/respaldo.php config/alertas.php
```

`genera-llave-respaldo.php` no imprime la llave y se niega a sobrescribir una
existente. En `config/alertas.php` poner el correo que recibe los avisos, un
remitente del propio dominio y `transporte = mail`. **El dueño baja una copia
de `config/respaldo.php` a un lugar fuera del hosting** (gestor de contraseñas
o memoria cifrada): sin esa llave, las copias cifradas no se pueden abrir. Es
distinta de `config/seguridad.php`; perder una no compromete la otra.

Antes de abrir a usuarios, probar el ciclo completo a mano:

```bash
php guiones/tarea.php respaldo --cifrar
php guiones/descifra-respaldo.php almacenamiento/respaldos/cifrados/ARCHIVO.sgr --verifica
cp config/bd.php.ejemplo config/bd-desechable.php
chmod 600 config/bd-desechable.php
php guiones/restaura.php almacenamiento/respaldos/ARCHIVO.sql.gz --credenciales=config/bd-desechable.php
php guiones/tarea.php mantenimiento --ensayo
```

La base desechable es una base vacía creada en el panel sólo para esta prueba,
con su propio usuario; sus datos van en `config/bd-desechable.php`. Comparar en
phpMyAdmin que tenga las mismas tablas y usuarios que la de trabajo. Al
terminar, borrar la base desechable desde el panel y `config/bd-desechable.php`.
Si ese archivo nombra la base de trabajo, `restaura.php` se niega igual que sin
credenciales. Después programar cron con la ruta real de PHP:

```text
0 2 * * * /RUTA/PHP RUTA_PADRE/app/guiones/tarea.php respaldo --cifrar
30 2 * * * /RUTA/PHP RUTA_PADRE/app/guiones/tarea.php mantenimiento
```

`tarea.php` corre la tarea, deja su estado en `almacenamiento/tareas/` y manda
correo si falla o si quedan menos de 1 GB libres o los registros pasan de
200 MB (umbrales en `config/alertas.php`). Probar el canal sin romper ni
falsear una tarea real:

```bash
php guiones/tarea.php prueba-aviso
```

La orden debe terminar en cero y el responsable debe recibir un mensaje cuyo
asunto lo identifica expresamente como prueba.

### Copia fuera del hosting

Al menos una vez por semana, bajar el `.sgr` más reciente de
`almacenamiento/respaldos/cifrados/` a la computadora del dueño y verificarlo
allí, con la llave guardada aparte:

```bash
PB_LLAVE_RESPALDO_ARCHIVO=/ruta/a/respaldo.php php guiones/descifra-respaldo.php ARCHIVO.sgr --verifica
```

El archivo cifrado no deja ver datos aunque se pierda. Sólo el `.sgr` sale del
hosting; los `.sql.gz` en claro se quedan dentro.

### Retirar lo que sólo sirvió para instalar

Al terminar la instalación, borrar del hosting el paquete `.tar.gz`, su
`.sha256` y el SQL de `instalacion/` (se conserva `LIBERACION.json` y el
manifiesto). Confirmar que `https://DOMINIO/instalacion/`,
`https://DOMINIO/config/app.php` y `https://DOMINIO/almacenamiento/` responden
404 o 403.

Desde la raíz privada, ejecutar la auditoría de sólo lectura después de que
respaldo y mantenimiento hayan corrido correctamente:

```bash
php guiones/verifica-cierre-host.php --perfil=produccion
```

Debe terminar con **23 comprobaciones** en verde. La propia salida recuerda las
tres evidencias que no puede fabricar: cron activo en hPanel, correo recibido y
copia `.sgr` verificada fuera del hosting.

## 5. Cierre antes de compilar Android

No compilar el perfil productivo hasta tener confirmados:

- `https://DOMINIO` accesible y aprobado por `publicacion.sh`;
- endpoints finales de API en ese dominio;
- UUID definitivo de EAS bajo la cuenta del dueño;
- prueba funcional web y restauración de respaldo.

Después se configura `PB_API`, `EXPO_PROJECT_ID` y se genera el build EAS.
