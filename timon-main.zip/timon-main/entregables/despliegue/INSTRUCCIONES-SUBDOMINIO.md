# Hostinger: instalación confinada al subdominio

Esta variante se usa cuando Hostinger fija la raíz del subdominio y no permite
guardar la aplicación fuera de ella. Todo permanece dentro de la carpeta del
subdominio:

```text
index.php             público
recursos/             público
.htaccess             público, controla acceso y rutas
.user.ini             configuración PHP sin secretos
.app/                privado y negado por dos reglas independientes
```

No se toca ninguna carpeta hermana ni superior.

## Carpeta que se sube por FTP

El entregable principal es la carpeta local:

```text
entregables/despliegue/app-subdominio-ftp/
```

No se sube el directorio contenedor: se sube **su contenido** directamente a
la carpeta exacta del subdominio. Activar en el cliente FTP la visualización de
archivos ocultos para incluir `.app`, `.user.ini` y `.htaccess.app`.

1. Subir primero `app-bloqueo-instalacion.htaccess` y renombrarlo en el
   servidor a `.htaccess`; durante la actualización las peticiones responderán
   503.
2. Subir, archivo por archivo, el resto del contenido de
   `app-subdominio-ftp/`.
3. **No usar espejo/sincronización con borrado.** En una actualización no se
   borran ni reemplazan `.app/config/*.php`, `.app/almacenamiento/`,
   respaldos, alertas, imágenes o datos creados en el servidor. La carpeta
   candidata sólo trae plantillas `.ejemplo` para configuración.
4. Confirmar que el FTP transfirió también los archivos ocultos.

El `.tar.gz` queda como representación verificable para las pruebas y la
compuerta de publicación; no es necesario subirlo ni descomprimirlo en
Hostinger.

## Comprobación de la carpeta subida

Desde la carpeta exacta del subdominio:

```bash
sha256sum -c .app/instalacion/MANIFIESTO-SHA256.txt
php .app/guiones/verifica-host.php
```

No activar todavía `.htaccess.app`.

## Configuración privada

```bash
cp .app/config/app.php.ejemplo .app/config/app.php
cp .app/config/bd.php.ejemplo .app/config/bd.php
php .app/guiones/genera-clave-seguridad.php
chmod 600 .app/config/app.php .app/config/bd.php .app/config/seguridad.php
```

Editar los dos archivos dentro del host. La clave de la base sólo se escribe en
`.app/config/bd.php`. En Hostinger el host de la base es `localhost`; el nombre
y el usuario conservan el prefijo que hPanel agrega a la cuenta.

### Base mediante hPanel y phpMyAdmin

1. En hPanel abrir **Websites → Dashboard → Databases Management**.
2. Seleccionar el sitio correcto y crear una base nueva con su usuario.
3. Guardar nombre completo, usuario y contraseña; no compartir la contraseña.
4. Entrar a phpMyAdmin desde esa misma base.
5. Confirmar que la vista no contiene tablas.
6. Abrir **Import**, elegir `app-esquema.sql` desde la computadora, dejar
   formato SQL y las opciones predeterminadas, y pulsar **Import/Go**.
7. Confirmar el mensaje de éxito y comparar tablas y nombres con
   `app-esquema.sql.json` del mismo candidato (esquema 25: 62 tablas).

Una base que ya tiene tablas **no se vuelve a importar**. Para actualizarla,
primero se genera un respaldo y se restaura en una base desechable; después se
usa el aplicador incremental incluido en `.app/guiones/`:

```bash
php .app/guiones/migraciones.php --estado
php .app/guiones/migraciones.php --aplicar --acepto=NOMBRE_COMPLETO_BASE \
  --respaldo-verificado=.app/almacenamiento/respaldos/RESPALDO.sql.gz
```

La primera orden muestra lo pendiente; después de aplicar, debe informar que
no queda ningún guion por aplicar.

El SQL no incluye `CREATE DATABASE`, `USE`, `DROP DATABASE`, `DROP TABLE`,
`DEFINER`, procedimientos ni privilegios especiales.

Crear el primer administrador desde SSH, sin escribir su contraseña en el
historial:

```bash
php .app/guiones/crear-usuario.php
```

## Activación segura

Comprobar sintaxis y activar la regla preparada:

```bash
php -l index.php
php -l .app/publico/index.php
mv .htaccess .htaccess-instalacion
mv .htaccess.app .htaccess
```

Desde otra terminal, las rutas privadas tienen que responder 403 o 404, nunca
200:

```bash
curl -o /dev/null -sS -w '%{http_code}\n' https://SUBDOMINIO/.app/config/bd.php
curl -o /dev/null -sS -w '%{http_code}\n' https://SUBDOMINIO/.app/esquema/001_catalogos.sql
curl -o /dev/null -sS -w '%{http_code}\n' https://SUBDOMINIO/.app/almacenamiento/respaldos/
curl -o /dev/null -sS -w '%{http_code}\n' https://SUBDOMINIO/entrar
```

Los tres primeros deben ser 403/404 y `/entrar` debe ser 200. Si no es así,
restaurar inmediatamente el cierre:

```bash
mv .htaccess .htaccess-fallido
mv .htaccess-instalacion .htaccess
```

Después ejecutar desde la computadora de desarrollo:

```bash
bash pruebas/publicacion.sh https://SUBDOMINIO \
  entregables/despliegue/app-subdominio-candidato.tar.gz
```

La compuerta lee del candidato su identificador y esquema, comprueba primero
la huella local y sólo entonces consulta el dominio. No acepta como cierre una
versión anterior aunque `/entrar` todavía responda 200.

No ejecutar en producción `pruebas/todo.sh`, `guiones/prepara-pruebas.php`
ni `guiones/aplica-esquema.php`.

## Respaldo cifrado, cron y alertas

Con la aplicación activa, crear la llave de las copias y las alertas:

```bash
php .app/guiones/genera-llave-respaldo.php
cp .app/config/alertas.php.ejemplo .app/config/alertas.php
chmod 600 .app/config/respaldo.php .app/config/alertas.php
```

Editar `.app/config/alertas.php` con el correo del responsable, un remitente
del propio dominio y `transporte = mail`. **Bajar una copia de
`.app/config/respaldo.php` fuera del hosting el mismo día**: sin esa llave las
copias cifradas no se abren.

Probar el canal de avisos sin provocar una falla real:

```bash
php .app/guiones/tarea.php prueba-aviso
```

La orden debe terminar en cero y el responsable debe recibir el mensaje.

Probar el ciclo a mano. La base desechable se crea en el panel con su propio
usuario, y sus datos van en `.app/config/bd-desechable.php`, copiado de
`bd.php.ejemplo`:

```bash
php .app/guiones/tarea.php respaldo --cifrar
php .app/guiones/descifra-respaldo.php .app/almacenamiento/respaldos/cifrados/ARCHIVO.sgr --verifica
php .app/guiones/restaura.php .app/almacenamiento/respaldos/ARCHIVO.sql.gz --credenciales=.app/config/bd-desechable.php
php .app/guiones/tarea.php mantenimiento --ensayo
```

Después programar el cron en hPanel, con la ruta que devuelve `command -v php`:

```text
0 2 * * *  /RUTA/PHP RUTA_ABSOLUTA/.app/guiones/tarea.php respaldo --cifrar
30 2 * * * /RUTA/PHP RUTA_ABSOLUTA/.app/guiones/tarea.php mantenimiento
```

Al terminar, borrar la base desechable y `.app/config/bd-desechable.php`.
Cada semana, bajar el `.sgr` más reciente y verificarlo fuera del hosting. Comprobar también que
`https://SUBDOMINIO/.app/almacenamiento/respaldos/cifrados/` responde 403 o
404.

Cuando la publicación, restauración y copia externa ya estén aceptadas, retirar
los transportes internos y el cierre temporal (se conservan
`LIBERACION.json` y `MANIFIESTO-SHA256.txt`):

```bash
rm .app/instalacion/app-esquema.sql
rm .app/instalacion/app-esquema.sql.sha256
rm .app/instalacion/app-esquema.sql.json
rm .htaccess-instalacion
php .app/guiones/verifica-cierre-host.php --perfil=produccion
```

La última orden es de sólo lectura y debe terminar con **23 comprobaciones** en
verde. Su salida deja explícitos los tres cierres manuales: cron activo en
hPanel, correo recibido y copia `.sgr` verificada fuera del hosting.
