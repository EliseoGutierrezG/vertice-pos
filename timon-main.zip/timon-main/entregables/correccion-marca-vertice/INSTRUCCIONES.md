# Actualización Vértice Software y PWA

Preparado el 19 de noviembre de 2026 para `staging-timon.verticesoftware.com.mx`.

Se corrigieron la autoría del acceso, pie del panel y aviso de privacidad, las referencias del código y la identidad de las apps nativas. El producto conserva su nombre El Timón. La nueva identidad nativa es `mx.verticesoftware.eltimon`.

## Aplicar en staging por SSH

Suba `correccion-vertice-pwa.tar.gz` y su archivo `.sha256` a `public_html/.app/`. Después ejecute:

```bash
cd ~/domains/staging-timon.verticesoftware.com.mx/public_html
cd .app
sha256sum -c correccion-vertice-pwa.tar.gz.sha256
cd ..
mkdir -p .app/correccion-vertice-pwa
tar -xzf .app/correccion-vertice-pwa.tar.gz -C .app/correccion-vertice-pwa
php .app/correccion-vertice-pwa/aplica.php --ensayo
php .app/correccion-vertice-pwa/aplica.php
```

El instalador valida el dominio, integridad, sintaxis PHP y versiones previas de seis archivos. Si alguno tiene una modificación adicional, se detiene antes de sobrescribirlo. Respalda esos archivos y la PWA anterior dentro de `.app/resguardos-marca/`. Conserva el `.htaccess` actual de `/app/` y la configuración privada. No requiere migraciones ni cierre de cuentas.

Reabra `/entrar`, `/aviso-privacidad` y `/app/`. El acceso y el panel deben decir **Vértice Software**. Si la PWA estaba abierta, ciérrela y ábrala otra vez; aplique el aviso de actualización cuando aparezca.

## Android

Compilación de staging terminada correctamente en Expo:

https://expo.dev/accounts/thepanda/projects/el-timon-comanda/builds/ad50bfc8-6bf9-4d7c-89f0-a1957fd18de3

APK entregado: `El-Timon-staging-Vertice-1.0.0.apk` (versión 1.0.0, código 1, Android 7 o posterior). Integridad ZIP y manifiesto comprobados; SHA-256 en el archivo contiguo. Descarga directa: https://expo.dev/artifacts/eas/UW1h7Gad7J3nTP5ad3ndgaji5jGUCZ53eBfJUnH9CkU.apk

La nueva app utiliza otro identificador y se instala por separado de una instalación anterior. Registre y autorice nuevamente el equipo con el servidor de staging. Antes de retirar una app anterior, resuelva sus capturas locales pendientes. La comprobación física de Android e impresión queda pendiente en los dispositivos del usuario.

Solo se solicitaron Android y PWA, según la indicación del usuario; iOS no se envió a compilar.

## Verificación realizada

- TypeScript de la app: sin errores.
- Exportación web/PWA: completada.
- 11 pruebas de marca: pasan.
- 67 comprobaciones existentes de seguridad sobre la base local exclusiva de pruebas: pasan.
- Sintaxis PHP, JavaScript y configuración nativa: comprobadas.
- Acceso y aviso de privacidad: revisados en el navegador integrado local.
- Instalador: ensayo y aplicación comprobados en una copia temporal; los respaldos se conservaron.

La aplicación del parche al hosting corresponde al usuario, que mantiene el acceso SSH. El paquete completo regenerado también está disponible en `entregables/despliegue/app-subdominio-candidato.tar.gz`; para esta corrección basta con el paquete pequeño descrito arriba.
