<?php
declare(strict_types=1);
// Ejecutar desde public_html. El paquete no incluye configuración privada.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$raiz = getcwd();
$base = __DIR__;
$ensayo = in_array('--ensayo', $argv, true);
try {
    if (!is_file($raiz . '/.app/config/app.php')) throw new RuntimeException('Ejecute desde public_html.');
    $config = require $raiz . '/.app/config/app.php';
    if (rtrim((string)($config['url_publica'] ?? ''), '/') !== 'https://staging-timon.verticesoftware.com.mx') {
        throw new RuntimeException('Este paquete corresponde únicamente al staging de Timón.');
    }
    $lista = json_decode(file_get_contents($base . '/manifiesto.json'), true, flags: JSON_THROW_ON_ERROR);
    $cambios = [];
    foreach ($lista as $rel => $datos) {
        if (str_contains($rel, '..') || str_starts_with($rel, '/')) throw new RuntimeException('Ruta inválida.');
        $nuevo = $base . '/archivos/' . $rel;
        if (!is_file($nuevo) || hash_file('sha256', $nuevo) !== $datos['nuevo']) throw new RuntimeException('Integridad incorrecta: ' . $rel);
        if (str_ends_with($rel, '.php')) {
            exec(escapeshellarg(PHP_BINARY) . ' -l ' . escapeshellarg($nuevo) . ' 2>&1', $salida, $codigo);
            if ($codigo !== 0) throw new RuntimeException('Sintaxis incorrecta: ' . $rel);
        }
        if (!str_starts_with($rel, 'app/')) {
            $actual = is_file($raiz . '/' . $rel) ? hash_file('sha256', $raiz . '/' . $rel) : '';
            if ($actual === $datos['nuevo']) continue;
            if ($actual !== $datos['antes']) throw new RuntimeException('El archivo cambió desde la revisión; no se sobrescribió: ' . $rel);
            $cambios[] = $rel;
        }
    }
    echo 'Integridad y sintaxis correctas. Archivos del panel por actualizar: ' . count($cambios) . PHP_EOL;
    if ($ensayo) { echo "Ensayo terminado; no se modificó el sitio.\n"; exit; }
    $respaldo = $raiz . '/.app/resguardos-marca/' . date('Ymd-His') . '-' . bin2hex(random_bytes(3));
    if (!mkdir($respaldo, 0700, true)) throw new RuntimeException('No se pudo crear el respaldo.');
    foreach ($cambios as $rel) {
        $copia = $respaldo . '/' . $rel;
        if (!is_dir(dirname($copia))) mkdir(dirname($copia), 0700, true);
        if (!copy($raiz . '/' . $rel, $copia)) throw new RuntimeException('No se pudo respaldar: ' . $rel);
    }
    $nuevaApp = $raiz . '/.app-pwa-' . bin2hex(random_bytes(4));
    $copiaArbol = function (string $origen, string $destino) use (&$copiaArbol): void {
        if (!mkdir($destino, 0755, true)) throw new RuntimeException('No se pudo crear: ' . $destino);
        foreach (new DirectoryIterator($origen) as $item) {
            if ($item->isDot()) continue;
            $a = $item->getPathname(); $b = $destino . '/' . $item->getFilename();
            if ($item->isDir()) $copiaArbol($a, $b);
            elseif (!copy($a, $b)) throw new RuntimeException('No se pudo copiar la PWA.');
        }
    };
    $copiaArbol($base . '/archivos/app', $nuevaApp);
    // Se conserva la regla de Apache de la instalación actual.
    if (is_file($raiz . '/app/.htaccess')) copy($raiz . '/app/.htaccess', $nuevaApp . '/.htaccess');
    foreach ($cambios as $rel) {
        $temporal = $raiz . '/' . $rel . '.vertice-temporal';
        if (!copy($base . '/archivos/' . $rel, $temporal) || !rename($temporal, $raiz . '/' . $rel)) throw new RuntimeException('No se pudo actualizar: ' . $rel);
        if (function_exists('opcache_invalidate')) opcache_invalidate($raiz . '/' . $rel, true);
    }
    if (is_dir($raiz . '/app') && !rename($raiz . '/app', $respaldo . '/app')) throw new RuntimeException('No se pudo respaldar la PWA.');
    if (!rename($nuevaApp, $raiz . '/app')) {
        if (is_dir($respaldo . '/app')) rename($respaldo . '/app', $raiz . '/app');
        throw new RuntimeException('No se pudo activar la nueva PWA.');
    }
    echo "Actualización aplicada. Respaldo: $respaldo\n";
    echo "Reabra /app/ y compruebe /entrar y /aviso-privacidad. No se requieren migraciones.\n";
} catch (Throwable $e) {
    fwrite(STDERR, 'No se completó: ' . $e->getMessage() . PHP_EOL);
    exit(1);
}
