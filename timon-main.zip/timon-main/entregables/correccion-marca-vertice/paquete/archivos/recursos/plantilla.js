/*
 * Lo propio de El Timón sobre el `main.js` y el `datatables.js` de la plantilla base.
 *
 * La plantilla base pide sus renglones por AJAX y los pinta con DataTables. Aquí las
 * pantallas llegan pintadas desde el servidor —así las leen las pruebas de
 * humo y así funcionan sin JavaScript—, y este archivo sólo les pone encima
 * lo mismo que la plantilla base: DataTables con sus opciones, las tarjetas de
 * `record-cards` para el teléfono, la confirmación con SweetAlert2 y los
 * avisos. No agrega componentes: usa los de la plantilla base.
 */
(function (window, document) {
    'use strict';

    const $ = window.jQuery;

    function texto(valor) {
        return window.AppDataTables ? window.AppDataTables.text(valor) : String(valor ?? '');
    }

    /* ---------------------------------------------------------------------
     * Sesión (homologación §S, D19).
     *
     * - El servidor dice en `meta[name=pb-sesion-restante]` cuántos segundos le
     *   quedan. Cinco minutos antes, la página vuelve a preguntar con
     *   `GET /sesion/estado`, que no cuenta como uso: si el usuario trabaja en
     *   otra pestaña, ésta no avisa.
     * - El aviso ofrece «Seguir conectado» (`POST /sesion/renovar`) y «Cerrar
     *   sesión».
     * - Un 401 en un guardado no cierra el modal ni borra lo capturado: se entra
     *   en otra pestaña (`/entrar?vuelta=cerrar`) y, al volver, se toma la marca
     *   nueva. **No se reenvía solo:** un reenvío automático rompería el envío
     *   único (guía §10.4).
     * ------------------------------------------------------------------- */

    const AVISO_SEGUNDOS = 300;
    const JSON_CABECERAS = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
    let temporizadorSesion = null;
    let esperandoEntrada = false;

    function Swal() {
        return window.Swal || window.Sweetalert2;
    }

    function marcaActual() {
        return document.querySelector('meta[name="csrf-token"]')?.content || '';
    }

    function ponMarca(marca) {
        if (!marca) return;
        document.querySelector('meta[name="csrf-token"]')?.setAttribute('content', marca);
        document.querySelectorAll('input[name="_marca"]').forEach(function (campo) { campo.value = marca; });
    }

    async function estadoSesion() {
        const respuesta = await fetch('/sesion/estado', { credentials: 'same-origin', cache: 'no-store', headers: JSON_CABECERAS });
        if (respuesta.status === 401 || (respuesta.redirected && new URL(respuesta.url).pathname === '/entrar')) {
            return { terminada: true };
        }
        const cuerpo = await respuesta.json().catch(function () { return null; });
        if (!respuesta.ok || !cuerpo?.ok) {
            throw new Error('estado');
        }
        ponMarca(cuerpo.datos?.marca);
        return { terminada: false, restante: cuerpo.datos?.restante ?? null };
    }

    function minutos(segundos) {
        const s = Math.max(0, Math.round(segundos));
        return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
    }

    function programaAviso(restante) {
        window.clearTimeout(temporizadorSesion);
        if (restante === null || restante === undefined || Number.isNaN(Number(restante))) return;
        const espera = Math.max(0, (Number(restante) - AVISO_SEGUNDOS) * 1000);
        temporizadorSesion = window.setTimeout(revisaSesion, Math.min(espera, 2147483647));
    }

    async function revisaSesion() {
        let estado;
        try {
            estado = await estadoSesion();
        } catch (falla) {
            programaAviso(AVISO_SEGUNDOS + 60);
            return;
        }
        if (estado.terminada) {
            // Con una captura abierta no se navega: se perdería lo capturado.
            if (document.querySelector('.modal.show form[data-pb-ajax]')) sesionTerminadaConCaptura();
            else sesionTerminada();
        } else if (estado.restante !== null && estado.restante > AVISO_SEGUNDOS + 5) {
            programaAviso(estado.restante);
        } else if (estado.restante !== null) {
            avisaVencimiento(estado.restante);
        }
    }

    async function sigueConectado() {
        const datos = new FormData();
        datos.append('_marca', marcaActual());
        const respuesta = await fetch('/sesion/renovar', { method: 'POST', body: datos, credentials: 'same-origin', headers: JSON_CABECERAS });
        const cuerpo = await respuesta.json().catch(function () { return null; });
        if (!respuesta.ok || !cuerpo?.ok) {
            throw new Error(respuesta.status === 401 ? 'terminada' : 'renovar');
        }
        ponMarca(cuerpo.datos?.marca);
        programaAviso(cuerpo.datos?.restante ?? null);
    }

    function avisaVencimiento(restante) {
        if (!Swal()) return;
        const fin = Date.now() + restante * 1000;
        let reloj = null;
        Swal().fire({
            icon: 'warning',
            title: 'Su sesión terminará pronto',
            html: 'Su sesión terminará en <strong data-pb-cuenta>' + minutos(restante) + '</strong>.',
            showCancelButton: true,
            confirmButtonText: 'Seguir conectado',
            cancelButtonText: 'Cerrar sesión',
            allowOutsideClick: false,
            allowEscapeKey: false,
            timer: Math.max(1000, restante * 1000),
            didOpen: function (caja) {
                const cuenta = caja.querySelector('[data-pb-cuenta]');
                reloj = window.setInterval(function () {
                    if (cuenta) cuenta.textContent = minutos((fin - Date.now()) / 1000);
                }, 1000);
            },
            willClose: function () { window.clearInterval(reloj); }
        }).then(async function (resultado) {
            if (resultado.isConfirmed) {
                try {
                    await sigueConectado();
                } catch (falla) {
                    if (falla.message === 'terminada') sesionTerminada();
                    else window.alerts?.error('Sin respuesta. Revise la conexión e intente de nuevo.');
                }
            } else if (resultado.dismiss === Swal().DismissReason.cancel) {
                // Ya lo pidió con el botón: no se le vuelve a preguntar.
                try { await window.service?.request('Auth', 'logout'); } catch (falla) { /* sale de todos modos */ }
                window.location.assign('/entrar');
            } else {
                revisaSesion();
            }
        });
    }

    /** La sesión ya terminó y no había nada capturado: a la entrada, con vuelta a esta pantalla. */
    function sesionTerminada() {
        window.clearTimeout(temporizadorSesion);
        if (!Swal()) {
            window.location.assign('/entrar');
            return;
        }
        const vuelta = window.location.pathname + window.location.search;
        Swal().fire({
            icon: 'info',
            title: 'La sesión terminó',
            text: 'Entre de nuevo para seguir trabajando.',
            confirmButtonText: 'Entrar',
            allowOutsideClick: false,
            allowEscapeKey: false
        }).then(function () {
            window.location.assign('/entrar?vuelta=' + encodeURIComponent(vuelta));
        });
    }

    /** La sesión terminó a media captura: se entra en otra pestaña y lo capturado se queda. */
    function sesionTerminadaConCaptura() {
        window.clearTimeout(temporizadorSesion);
        esperandoEntrada = true;
        return Swal()?.fire({
            icon: 'info',
            title: 'Su sesión terminó',
            text: 'Entre de nuevo para guardar lo capturado.',
            confirmButtonText: 'Entrar en otra pestaña',
            showCloseButton: true,
            allowOutsideClick: false
        }).then(function (resultado) {
            if (resultado.isConfirmed) {
                window.open('/entrar?vuelta=cerrar', '_blank');
            }
        });
    }

    // De regreso de la otra pestaña: si ya hay sesión, la marca nueva y «Ya puede guardar».
    window.addEventListener('focus', async function () {
        if (!esperandoEntrada) return;
        try {
            const estado = await estadoSesion();
            if (estado.terminada) return;
            esperandoEntrada = false;
            programaAviso(estado.restante);
            Swal()?.fire({ icon: 'success', title: 'Sesión iniciada', text: 'Ya puede guardar.' });
        } catch (falla) {
            // Sin conexión todavía: se vuelve a intentar con el siguiente foco.
        }
    });

    window.pbSesion = {
        estado: estadoSesion,
        ponMarca,
        terminada: sesionTerminada,
        terminadaConCaptura: sesionTerminadaConCaptura
    };

    /* ---------------------------------------------------------------------
     * Tablas: `table[data-pb-tabla]` → DataTables de la plantilla base + record-cards.
     *
     * - El orden es el del servidor (`order: []`), que ya viene pensado.
     * - `data-pb-tabla="simple"` quita buscador, paginación y conteo: para
     *   tablas cortas dentro de una ficha.
     * - El renglón vacío (`tr[data-pb-vacio]`) se quita antes de iniciar y su
     *   texto pasa a ser el `emptyTable` de DataTables.
     * - En el teléfono cada renglón se vuelve una tarjeta: la columna marcada
     *   `data-pb-titulo` (o la primera) es el título, la `data-pb-insignia`
     *   va a la derecha, la `data-pb-acciones` abajo y el resto como lista.
     * ------------------------------------------------------------------- */

    function etiquetas(tabla) {
        return Array.from(tabla.tHead?.rows[0]?.cells || []).map(function (celda, indice) {
            return {
                indice,
                texto: celda.textContent.trim(),
                titulo: celda.hasAttribute('data-pb-titulo'),
                insignia: celda.hasAttribute('data-pb-insignia'),
                acciones: celda.hasAttribute('data-pb-acciones'),
                oculta: celda.hasAttribute('data-pb-sin-tarjeta')
            };
        });
    }

    function tarjeta(renglon, columnas) {
        const celdas = renglon.cells;
        const titulo = columnas.find((c) => c.titulo) || columnas.find((c) => !c.acciones && !c.insignia);
        const insignia = columnas.find((c) => c.insignia);
        const acciones = columnas.find((c) => c.acciones);
        const lista = columnas.filter((c) => c !== titulo && c !== insignia && c !== acciones && !c.oculta);
        const html = (c) => (c && celdas[c.indice] ? celdas[c.indice].innerHTML.trim() : '');

        return `
            <article class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
                        <div><strong>${html(titulo)}</strong></div>
                        ${insignia ? html(insignia) : ''}
                    </div>
                    ${lista.length ? `<dl class="record-card__list mb-0">
                        ${lista.map((c) => `
                            <div>
                                <dt>${texto(c.texto)}</dt>
                                <dd>${html(c) || '-'}</dd>
                            </div>`).join('')}
                    </dl>` : ''}
                    ${acciones && html(acciones) ? `<div class="table-actions mt-3">${html(acciones)}</div>` : ''}
                </div>
            </article>`;
    }

    /** El contenido del renglón vacío de un listado (D25.4). */
    function htmlVacio(vacio) {
        const escapa = (texto) => String(texto).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
        const icono = /^bi-[a-z0-9-]+$/.test(vacio.icono) ? vacio.icono : 'bi-inbox';
        return '<span class="pb-vacio-tabla"><i class="bi ' + icono + '" aria-hidden="true"></i>'
            + '<strong>' + escapa(vacio.titulo) + '</strong>'
            + (vacio.texto ? '<span>' + escapa(vacio.texto) + '</span>' : '')
            + '</span>';
    }

    function pintaTarjetas(tabla, api, contenedor, vacio) {
        const columnas = etiquetas(tabla);
        const renglones = api
            ? api.rows({ page: 'current', search: 'applied' }).nodes().toArray()
            : Array.from(tabla.tBodies[0]?.rows || []).filter((r) => !r.hasAttribute('data-pb-vacio'));

        contenedor.innerHTML = renglones.length
            ? renglones.map((r) => tarjeta(r, columnas)).join('')
            : window.AppDataTables.emptyCard(vacio.icono, vacio.titulo, vacio.texto);
    }

    /*
     * Las celdas de texto se parten en renglones (tema, bitácora 110), y el
     * navegador partía también los folios en el guion: «PED-» arriba y
     * «000376» abajo. Cada folio queda en un `span.text-nowrap`; el texto no
     * cambia, así que copiar y buscar siguen igual.
     */
    const FOLIO = /\b[A-Z]{2,5}-\d{3,}\b/g;

    function folioEntero(tabla) {
        const recorre = document.createTreeWalker(tabla.tBodies[0] || tabla, NodeFilter.SHOW_TEXT, {
            acceptNode: function (nodo) {
                FOLIO.lastIndex = 0;
                return FOLIO.test(nodo.nodeValue) && !nodo.parentElement.closest('.text-nowrap')
                    ? NodeFilter.FILTER_ACCEPT
                    : NodeFilter.FILTER_REJECT;
            }
        });
        const nodos = [];
        while (recorre.nextNode()) nodos.push(recorre.currentNode);
        nodos.forEach(function (nodo) {
            const partes = document.createDocumentFragment();
            let ultimo = 0;
            nodo.nodeValue.replace(FOLIO, function (folio, inicio) {
                partes.append(nodo.nodeValue.slice(ultimo, inicio));
                const envoltura = document.createElement('span');
                envoltura.className = 'text-nowrap';
                envoltura.textContent = folio;
                partes.append(envoltura);
                ultimo = inicio + folio.length;
                return folio;
            });
            partes.append(nodo.nodeValue.slice(ultimo));
            nodo.replaceWith(partes);
        });
    }

    function iniciaTabla(tabla) {
        const zona = tabla.closest('.table-zone');
        if (tabla.dataset.pbIniciada === '1') {
            preparada(zona);
            return;
        }
        if (!window.AppDataTables?.available()) {
            zona?.classList.add('pb-tabla-sin-tarjetas');
            preparada(zona);
            return;
        }
        tabla.dataset.pbIniciada = '1';

        let contenedor = zona?.nextElementSibling;
        if (zona && !contenedor?.classList.contains('record-cards')) {
            contenedor = document.createElement('div');
            contenedor.className = 'record-cards';
            zona.after(contenedor);
        }

        const filaVacia = tabla.querySelector('tbody tr[data-pb-vacio]');
        const simple = tabla.dataset.pbTabla === 'simple';
        const vacio = {
            icono: tabla.dataset.pbVacioIcono || 'bi-inbox',
            titulo: filaVacia?.textContent.trim() || 'Sin datos',
            texto: tabla.dataset.pbVacioTexto || ''
        };
        filaVacia?.remove();

        // La columna de acciones no se ordena aunque la vista no la marque.
        Array.from(tabla.tHead?.rows[0]?.cells || []).forEach(function (celda) {
            if (celda.hasAttribute('data-pb-acciones') || ['Acciones', 'Acción'].includes(celda.textContent.trim())) {
                celda.classList.add('no-orden');
            }
        });

        const config = {
            order: [],
            language: Object.assign({}, window.AppDataTables.language, {
                // En escritorio, la tabla vacía dice lo mismo que la tarjeta
                // vacía del teléfono: icono, título y, si hay, la explicación.
                // DataTables lo inserta como HTML: todo va escapado.
                emptyTable: htmlVacio(vacio),
                zeroRecords: htmlVacio({ icono: 'bi-search', titulo: 'Sin resultados', texto: 'Pruebe con otra búsqueda.' }),
                // «Sin datos» abajo repetía lo que ya dice la tabla.
                infoEmpty: ''
            }),
            columnDefs: [
                { targets: 'no-orden', orderable: false }
            ]
        };

        if (simple) {
            Object.assign(config, {
                paging: false,
                searching: false,
                info: false,
                // Una ficha trae pocos renglones: las flechas de orden sólo le
                // quitaban ancho a la columna del importe.
                ordering: false,
                dom: "<'table-responsive'tr>"
            });
        }

        const instancia = window.AppDataTables.create({
            table: tabla,
            config,
            onDraw: function (_filas, api) {
                // Las flechas de la paginación no tienen texto: sin esto el
                // lector de pantalla las anuncia como «vínculo».
                const envoltura = tabla.closest('.dataTables_wrapper');
                const buscador = envoltura?.querySelector('.dataTables_filter input');
                if (buscador && !buscador.getAttribute('aria-label')) {
                    const nombre = tabla.getAttribute('aria-label') || tabla.querySelector('caption')?.textContent.trim() || 'registros';
                    buscador.setAttribute('aria-label', 'Buscar en ' + nombre);
                }
                envoltura?.querySelectorAll('.paginate_button.previous .page-link, .paginate_button.next .page-link').forEach(function (liga) {
                    liga.setAttribute('aria-label', liga.closest('.previous') ? 'Página anterior' : 'Página siguiente');
                });
                envoltura?.querySelectorAll('.table-responsive').forEach(function (desliza) {
                    window.ui?.makeScrollRegionFocusable?.(desliza);
                });
                folioEntero(tabla);
                if (contenedor) {
                    pintaTarjetas(tabla, api, contenedor, vacio);
                }
            }
        });
        window.AppDataTables.setLoading(instancia, false);
        preparada(zona);
    }

    // También se usa al sustituir el contenido vivo del Tablero.
    window.pbTablas = { inicia: iniciaTabla };

    /**
     * La tabla llega pintada del servidor con `pb-preparando` (`pb_tabla`): se
     * ven sus primeros renglones, pero no todos, para que no salte al
     * paginarse. Las tarjetas del teléfono traen su esqueleto hasta que se
     * arman. Aquí se suelta.
     */
    function preparada(zona) {
        if (!zona) return;
        zona.classList.remove('pb-preparando');
        const tarjetas = zona.nextElementSibling;
        if (tarjetas?.classList.contains('record-cards')) {
            tarjetas.removeAttribute('aria-busy');
            tarjetas.querySelectorAll('.pb-esqueleto').forEach(function (e) { e.remove(); });
        }
    }

    /* ---------------------------------------------------------------------
     * Esqueletos de carga (`.pb-esqueleto`, tema.css).
     *
     * Mientras algo llega se ve su forma —renglones, campos, tarjetas—, no un
     * texto suelto ni un hueco: así nada salta cuando aparece el contenido.
     * El contenedor lleva `aria-busy` y un «Cargando» solo para el lector de
     * pantalla. Con movimiento reducido, el brillo no se mueve.
     * ------------------------------------------------------------------- */

    function barras(n, clase) {
        let html = '';
        for (let i = 0; i < n; i++) {
            html += '<span class="pb-esqueleto__barra ' + (clase || '') + '"></span>';
        }
        return html;
    }

    function esqueleto(tipo) {
        const anuncio = '<span class="visually-hidden" role="status">Cargando</span>';
        let cuerpo = '';
        if (tipo === 'ficha') {
            let datos = '';
            for (let i = 0; i < 6; i++) {
                datos += '<div class="pb-esqueleto__dato"><span class="pb-esqueleto__barra pb-esqueleto__barra--corta"></span><span class="pb-esqueleto__barra"></span></div>';
            }
            cuerpo = '<div class="row g-3"><div class="col-lg-5"><span class="pb-esqueleto__barra pb-esqueleto__barra--titulo"></span>' + datos + '</div>'
                + '<div class="col-lg-7"><span class="pb-esqueleto__barra pb-esqueleto__barra--titulo"></span>' + esqueletoTabla(4) + '</div></div>';
        } else if (tipo === 'tabla') {
            cuerpo = esqueletoTabla(5);
        } else if (tipo === 'tarjetas') {
            for (let i = 0; i < 3; i++) {
                cuerpo += '<div class="pb-esqueleto__tarjeta"><span class="pb-esqueleto__barra pb-esqueleto__barra--titulo"></span>' + barras(3) + '</div>';
            }
        } else if (tipo === 'metricas') {
            cuerpo = '<div class="row g-2">';
            for (let i = 0; i < 4; i++) {
                cuerpo += '<div class="col-sm-6 col-xl-3"><div class="pb-esqueleto__tarjeta"><span class="pb-esqueleto__barra pb-esqueleto__barra--corta"></span><span class="pb-esqueleto__barra pb-esqueleto__barra--titulo"></span></div></div>';
            }
            cuerpo += '</div>';
        } else {
            cuerpo = barras(4);
        }
        return '<div class="pb-esqueleto" aria-busy="true">' + anuncio + cuerpo + '</div>';
    }

    function esqueletoTabla(renglones) {
        let html = '<div class="pb-esqueleto__tabla"><div class="pb-esqueleto__renglon pb-esqueleto__renglon--cabeza">' + barras(4) + '</div>';
        for (let i = 0; i < renglones; i++) {
            html += '<div class="pb-esqueleto__renglon">' + barras(4) + '</div>';
        }
        return html + '</div>';
    }

    /** Los campos de un modal mientras llega su registro (`data-pb-registro-url`). */
    function esqueletoCampos(forma) {
        forma.classList.add('pb-esqueleto-campos');
        forma.setAttribute('aria-busy', 'true');
    }

    function quitaEsqueletoCampos(forma) {
        forma.classList.remove('pb-esqueleto-campos');
        if (forma.dataset.pbEnviando !== '1') forma.removeAttribute('aria-busy');
    }

    window.pbEsqueleto = esqueleto;
    window.pbPideJson = function (url) { return pideJson(url); };

    /*
     * Las fotos (selfies de la checada, imagen del producto) brillan hasta que
     * llegan: `img[data-pb-foto]`. El evento `load` no burbujea; se escucha en
     * captura.
     */
    document.addEventListener('load', function (evento) {
        if (evento.target instanceof HTMLImageElement) evento.target.classList.add('pb-cargada');
    }, true);
    document.addEventListener('error', function (evento) {
        if (evento.target instanceof HTMLImageElement) evento.target.classList.add('pb-cargada');
    }, true);

    /*
     * Al cambiar de pantalla —un enlace del menú, Buscar o Limpiar en los
     * filtros— la página de ahora se queda hasta que llegue la siguiente. Si
     * tarda más de un momento, una barra delgada arriba dice que va, y la
     * tabla y las tarjetas muestran su esqueleto. Las descargas, las pestañas
     * nuevas y lo que abre un modal no cuentan.
     */
    let temporizadorNavegacion = null;

    function navegando() {
        window.clearTimeout(temporizadorNavegacion);
        temporizadorNavegacion = window.setTimeout(function () {
            document.body.classList.add('pb-navegando');
            document.body.setAttribute('aria-busy', 'true');
            const principal = document.querySelector('main.app-main');
            if (principal && !principal.querySelector('.pb-carga-navegacion')) {
                const cubierta = document.createElement('div');
                cubierta.className = 'pb-carga-navegacion';
                cubierta.innerHTML = '<div class="pb-carga-navegacion__interior">' + esqueleto('metricas') + esqueleto('tabla') + '</div>';
                principal.append(cubierta);
            }
        }, 250);
    }

    function dejaDeNavegar() {
        window.clearTimeout(temporizadorNavegacion);
        document.body.classList.remove('pb-navegando');
        document.body.removeAttribute('aria-busy');
        document.querySelectorAll('.pb-carga-navegacion').forEach(function (cubierta) { cubierta.remove(); });
    }

    document.addEventListener('click', function (evento) {
        if (evento.defaultPrevented || evento.button !== 0 || evento.metaKey || evento.ctrlKey || evento.shiftKey || evento.altKey) {
            return;
        }
        const enlace = evento.target.closest('a[href]');
        if (!enlace || enlace.target || enlace.hasAttribute('download') || enlace.hasAttribute('data-bs-toggle')
            || enlace.hasAttribute('data-pb-post') || enlace.hasAttribute('data-pb-exporta') || enlace.closest('[data-pb-sin-espera]')) {
            return;
        }
        let destino;
        try {
            destino = new URL(enlace.href, window.location.href);
        } catch (falla) {
            return;
        }
        if (destino.origin !== window.location.origin || destino.hash && destino.pathname === window.location.pathname && destino.search === window.location.search) {
            return;
        }
        // Las hojas para imprimir y los archivos se abren aparte o se bajan.
        if (/\.(xlsx|pdf|csv)$/i.test(destino.pathname) || /\/(hoja|ticket|imprimir)$/.test(destino.pathname)) {
            return;
        }
        // Otro manejador puede cancelar el clic después de este listener.
        window.setTimeout(function () {
            if (!evento.defaultPrevented) navegando();
        }, 0);
    });

    document.addEventListener('submit', function (evento) {
        const forma = evento.target;
        if (!(forma instanceof HTMLFormElement) || forma.target === '_blank' || (forma.method || 'get').toLowerCase() !== 'get') {
            return;
        }
        // El submit se pudo cancelar más adelante (validación); se revisa al final del turno.
        window.setTimeout(function () {
            if (!evento.defaultPrevented) navegando();
        }, 0);
    });

    window.addEventListener('pageshow', dejaDeNavegar);

    /* ---------------------------------------------------------------------
     * Envío único (doble clic, esquema/062).
     *
     * Tres candados, porque ninguno solo alcanza:
     *
     * 1. Mientras un formulario viaja (`data-pb-enviando`), otro envío de ese
     *    mismo formulario no sale: lo frena un listener en captura antes que
     *    cualquier otro, sea modal, en línea o de toda la vida.
     * 2. Un modal que guarda no se cierra —ni con la X, ni con Esc, ni con el
     *    fondo— y sus botones quedan deshabilitados con su spinner.
     * 3. Cada POST lleva `_envio`, una llave por **intención**: por formulario
     *    y destino, o por enlace. Se conserva en los reintentos, así que si el
     *    primero sí llegó, el servidor contesta lo mismo y no lo vuelve a hacer
     *    (`ExigeEnvioUnico`). Tras «Atrás» la página vuelve con la misma llave:
     *    volver a Guardar repite la respuesta, no el guardado.
     * ------------------------------------------------------------------- */

    function nuevaLlave() {
        if (window.crypto?.randomUUID) {
            return window.crypto.randomUUID();
        }
        const b = new Uint8Array(16);
        window.crypto.getRandomValues(b);
        b[6] = (b[6] & 0x0f) | 0x40;
        b[8] = (b[8] & 0x3f) | 0x80;
        const h = Array.from(b, function (x) { return x.toString(16).padStart(2, '0'); }).join('');
        return h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20);
    }

    /** La llave de esta intención: del elemento y del destino. */
    function llaveDeEnvio(dueno, destino) {
        dueno._lbEnvios = dueno._lbEnvios || {};
        if (!dueno._lbEnvios[destino]) {
            dueno._lbEnvios[destino] = nuevaLlave();
        }
        return dueno._lbEnvios[destino];
    }

    const ESPERA = '<span class="spinner-border spinner-border-sm" aria-hidden="true"></span> ';

    /** Los botones que mandan este formulario, dentro o con `form="id"`. */
    function botonesDe(forma) {
        const dentro = Array.from(forma.querySelectorAll('button, input[type="submit"]'));
        const fuera = forma.id ? Array.from(document.querySelectorAll('button[form="' + CSS.escape(forma.id) + '"]')) : [];
        return dentro.concat(fuera);
    }

    function bloqueaEnvio(forma) {
        forma.dataset.pbEnviando = '1';
        forma.setAttribute('aria-busy', 'true');
        botonesDe(forma).forEach(function (b) {
            if (b.disabled) {
                b.dataset.pbYaApagado = '1';
                return;
            }
            b.disabled = true;
            b.setAttribute('aria-busy', 'true');
            // El botón dice que trabaja sin cambiar lo que dice (B6):
            // `data-loading-label` lo cambia por pantalla.
            if (b.matches('[type="submit"]') && b.tagName === 'BUTTON' && b.textContent.trim() !== '') {
                b.dataset.pbTexto = b.innerHTML;
                b.innerHTML = ESPERA + (b.dataset.loadingLabel ? texto(b.dataset.loadingLabel) : b.innerHTML);
            }
        });
        const modal = forma.closest('.modal');
        if (modal) {
            modal.dataset.pbEnviando = '1';
            modal.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function (b) {
                if (!b.disabled) {
                    b.disabled = true;
                    b.dataset.pbCierreApagado = '1';
                }
            });
        }
    }

    function liberaEnvio(forma) {
        botonesDe(forma).forEach(function (b) {
            if (b.dataset.pbYaApagado === '1') {
                delete b.dataset.pbYaApagado;
                return;
            }
            b.disabled = false;
            b.removeAttribute('aria-busy');
            if (b.dataset.pbTexto !== undefined) {
                b.innerHTML = b.dataset.pbTexto;
                delete b.dataset.pbTexto;
            }
        });
        delete forma.dataset.pbEnviando;
        delete forma.dataset.pbConfirmada;
        forma.removeAttribute('aria-busy');
        const modal = forma.closest('.modal');
        if (modal) {
            delete modal.dataset.pbEnviando;
            modal.querySelectorAll('[data-pb-cierre-apagado]').forEach(function (b) {
                b.disabled = false;
                delete b.dataset.pbCierreApagado;
            });
        }
        if (forma._lbDisparador) {
            liberaDisparador(forma._lbDisparador);
        }
    }

    /** Un enlace o botón de acción mientras su envío viaja. */
    function bloqueaDisparador(elemento) {
        elemento.dataset.pbEnviando = '1';
        elemento.setAttribute('aria-disabled', 'true');
        elemento.setAttribute('aria-busy', 'true');
        elemento.classList.add('pb-enviando');
        if (elemento.tagName === 'BUTTON') elemento.disabled = true;
        if (!elemento.querySelector('.pb-espera')) {
            elemento.insertAdjacentHTML('afterbegin', '<span class="pb-espera spinner-border spinner-border-sm me-1" aria-hidden="true"></span>');
        }
    }

    function liberaDisparador(elemento) {
        delete elemento.dataset.pbEnviando;
        elemento.removeAttribute('aria-disabled');
        elemento.removeAttribute('aria-busy');
        elemento.classList.remove('pb-enviando');
        if (elemento.tagName === 'BUTTON') elemento.disabled = false;
        elemento.querySelectorAll('.pb-espera').forEach(function (e) { e.remove(); });
    }

    /**
     * Manda una acción desde un enlace o botón que no es formulario (las
     * acciones de la fila, los paneles): arma un formulario de paso y lo manda
     * por el mismo camino que los modales. El disparador queda bloqueado desde
     * el clic hasta la respuesta —también mientras se confirma— y conserva su
     * llave para el reintento. Con `negocio`, la misma llave va además como
     * `llave_idempotencia` (`OperacionesPanel::unaVez`).
     */
    function enviaDesde(disparador, accion, campos, opciones) {
        if (disparador.dataset.pbEnviando === '1') {
            return;
        }
        const op = opciones || {};
        const forma = document.createElement('form');
        forma.method = 'post';
        forma.action = accion;
        forma.hidden = true;
        forma.setAttribute('data-pb-ajax', '');
        if (op.confirma) {
            forma.dataset.confirma = op.confirma;
            forma.dataset.confirmaTitulo = op.confirmaTitulo || 'Confirmar acción';
        }
        const llave = llaveDeEnvio(disparador, accion);
        const todos = [['_marca', marcaActual()], ['_envio', llave]].concat(campos || []);
        if (op.negocio) {
            todos.push(['llave_idempotencia', llave]);
        }
        todos.forEach(function ([nombre, valor]) {
            if (valor === null || valor === undefined || valor === '') return;
            const campo = document.createElement('input');
            campo.type = 'hidden';
            campo.name = nombre;
            campo.value = String(valor);
            forma.append(campo);
        });
        const enviar = document.createElement('button');
        enviar.type = 'submit';
        forma.append(enviar);
        forma._lbDisparador = disparador;
        bloqueaDisparador(disparador);
        document.body.append(forma);
        forma.requestSubmit(enviar);
    }

    window.pbEnvio = { llave: llaveDeEnvio, desde: enviaDesde };

    // Candado 1: lo que ya viaja no sale otra vez, venga de donde venga.
    document.addEventListener('submit', function (evento) {
        const forma = evento.target;
        if (forma instanceof HTMLFormElement && forma.dataset.pbEnviando === '1') {
            evento.preventDefault();
            evento.stopImmediatePropagation();
        }
    }, true);

    // Candado 2: el modal que guarda no se cierra.
    document.addEventListener('hide.bs.modal', function (evento) {
        if (evento.target.dataset?.pbEnviando === '1') {
            evento.preventDefault();
        }
    });

    // «Atrás» o «Adelante» devuelven la página congelada como estaba: con sus
    // botones girando. Se sueltan; la llave se queda, y un Guardar repetido
    // recibe la misma respuesta.
    window.addEventListener('pageshow', function (evento) {
        if (!evento.persisted) {
            return;
        }
        document.querySelectorAll('form[data-pb-enviando]').forEach(liberaEnvio);
        document.querySelectorAll('[data-pb-enviando]').forEach(function (e) {
            if (e instanceof HTMLFormElement) return;
            if (e.classList.contains('modal')) {
                delete e.dataset.pbEnviando;
            } else {
                liberaDisparador(e);
            }
        });
        document.querySelectorAll('form[data-pb-confirmada]').forEach(function (f) {
            delete f.dataset.pbConfirmada;
        });
        document.querySelectorAll('form[hidden][data-pb-ajax]').forEach(function (f) {
            if (!f.closest('.modal')) f.remove();
        });
    });

    /* ---------------------------------------------------------------------
     * Confirmación: `form[data-confirma]` pregunta con SweetAlert2 antes de
     * mandarse, como las bajas de la plantilla base. `data-confirma-titulo` opcional.
     *
     * D25.2: el botón del diálogo repite el verbo del que se pulsó («Dar de
     * baja», no «Confirmar») y va en rojo cuando la acción es destructiva: el
     * formulario trae `data-confirma-tono="peligro"`, el botón es rojo o está en
     * una sección de peligro. `data-confirma-accion` da el verbo a mano.
     * ------------------------------------------------------------------- */

    function verboDe(elemento) {
        if (!elemento) return '';
        const texto = elemento.tagName === 'INPUT' ? elemento.value : elemento.textContent;
        return String(texto || '').replace(/\s+/g, ' ').trim();
    }

    function esPeligro(forma, disparador) {
        if (forma.dataset.confirmaTono === 'peligro') return true;
        if (disparador && disparador.matches('.btn-danger, .btn-outline-danger, .text-danger')) return true;
        return Boolean(forma.closest('.form-section--danger') || disparador?.closest('.form-section--danger'));
    }

    document.addEventListener('submit', async function (evento) {
        const forma = evento.target.closest('form[data-confirma]');
        if (!forma || forma.dataset.pbConfirmada === '1' || !window.alerts) {
            return;
        }

        evento.preventDefault();
        const boton = evento.submitter;
        // El formulario de paso de una acción de fila no tiene botón con
        // texto: el verbo y el tono son los del enlace que lo armó.
        const disparador = verboDe(boton) !== '' ? boton : (forma._lbDisparador || boton);
        const verbo = forma.dataset.confirmaAccion || verboDe(disparador) || 'Confirmar';
        const respuesta = await Swal().fire({
            title: forma.dataset.confirmaTitulo || 'Confirmar acción',
            text: forma.dataset.confirma,
            icon: 'question',
            tono: esPeligro(forma, disparador) ? 'peligro' : undefined,
            showCancelButton: true,
            confirmButtonText: verbo,
            // Dos «Cancelar» en el mismo diálogo confunden.
            cancelButtonText: /^cancelar\b/i.test(verbo) ? 'Volver' : 'Cancelar',
            reverseButtons: true,
            focusCancel: true
        });
        if (!respuesta.isConfirmed) {
            if (forma._lbDisparador) {
                liberaDisparador(forma._lbDisparador);
            }
            if (forma.hidden && !forma.closest('.modal')) {
                forma.remove();
            }
            return;
        }

        forma.dataset.pbConfirmada = '1';
        if (typeof forma.requestSubmit === 'function') {
            forma.requestSubmit(boton || undefined);
        } else {
            forma.submit();
        }
    });

    /* ---------------------------------------------------------------------
     * Modales de alta y edición (`pb_modal` en piezas.php).
     *
     * El mismo modal sirve para las dos cosas. El botón que lo abre dice a
     * dónde mandar (`data-pb-accion`), con qué título (`data-pb-titulo`) y con
     * qué valores (`data-pb-registro`, JSON). Sin ellos, es un alta: el
     * formulario vuelve a sus valores de origen.
     * ------------------------------------------------------------------- */

    function ponValor(campo, valor) {
        if (campo.type === 'checkbox' || campo.type === 'radio') {
            // Una lista de casillas (`platillos[]`) llega como arreglo.
            campo.checked = Array.isArray(valor) ? valor.map(String).includes(String(campo.value))
                : String(campo.value) === String(valor ?? '');
        } else {
            campo.value = valor === null || valor === undefined ? '' : String(valor);
        }
        if ($ && campo.matches('select[data-app-select2]')) {
            $(campo).trigger('change');
        }
    }

    /*
     * `reset()` no regresa un `input` oculto a su valor de origen: en uno
     * oculto, asignar `value` reescribe el origen. Y la fecha de Flatpickr es
     * justo un oculto con un campo visible aparte. Por eso el origen se guarda
     * la primera vez que se abre el modal y se repone en cada apertura.
     */
    function reponeOcultos(forma) {
        forma.querySelectorAll('input[type="hidden"]').forEach(function (campo) {
            if (campo.dataset.pbOrigen === undefined) {
                campo.dataset.pbOrigen = campo.value;
            } else {
                campo.value = campo.dataset.pbOrigen;
            }
        });
    }

    // El campo visible de Flatpickr no se entera de un `value` asignado a mano.
    function sincronizaFechas(forma) {
        forma.querySelectorAll('input').forEach(function (campo) {
            if (campo._flatpickr) {
                if (campo.value) {
                    campo._flatpickr.setDate(campo.value, false);
                } else {
                    campo._flatpickr.clear(false);
                }
            }
        });
    }

    // Flatpickr oculta el campo con id y crea otro visible. La etiqueta sigue
    // apuntando al original, así que el control que recibe el foco necesita
    // heredar explícitamente su nombre y la ayuda asociada.
    function enlazaFechasVisibles(root = document) {
        root.querySelectorAll('input[data-app-date]').forEach(function (campo) {
            const visible = campo._flatpickr?.altInput;
            const etiqueta = campo.id
                ? document.querySelector('label[for="' + CSS.escape(campo.id) + '"]')
                : null;
            if (!visible || !etiqueta) return;

            if (!etiqueta.id) etiqueta.id = campo.id + '-etiqueta';
            visible.setAttribute('aria-labelledby', etiqueta.id);
            if (campo.required) visible.setAttribute('aria-required', 'true');
            if (campo.hasAttribute('aria-describedby')) {
                visible.setAttribute('aria-describedby', campo.getAttribute('aria-describedby'));
            }
        });
    }

    function limpiaError(forma) {
        const caja = forma.querySelector('[data-pb-error]');
        if (caja) {
            caja.textContent = '';
            caja.classList.add('d-none');
        }
        window.ui?.clearValidationErrors(forma);
    }

    /*
     * Los tres modos del mismo modal (guía §5.2, D5): `agregar` lo deja en
     * blanco; `actualizar` lo llena y cambia a dónde se manda; `ver` lo llena en
     * solo lectura (`ui.setFormReadonly`), sin botón de guardar.
     */
    document.addEventListener('show.bs.modal', function (evento) {
        const modal = evento.target;
        const forma = modal.matches('[data-pb-formulario]') ? modal.querySelector('form') : null;
        if (!forma) {
            return;
        }

        const boton = evento.relatedTarget;
        const titulo = modal.querySelector('[data-pb-modal-titulo]');
        const instruccion = modal.querySelector('[data-pb-instruccion]');
        let registro = null;
        try {
            registro = boton?.dataset.pbRegistro ? JSON.parse(boton.dataset.pbRegistro) : null;
        } catch (error) {
            registro = null;
        }
        const modo = modal.hasAttribute('data-pb-solo-ver') ? 'ver' : (boton?.dataset.pbModo || (registro ? 'actualizar' : 'agregar'));

        window.ui?.setFormReadonly(forma, false);
        forma.reset();
        reponeOcultos(forma);
        forma.querySelectorAll('select[data-app-select2]').forEach(function (s) { $ && $(s).trigger('change'); });
        liberaBloqueados(forma);
        // `data-pb-accion-alta`: un alta que va a otra ruta (Agregar casco de
        // un producto, ficha 28); el modal es el mismo para todos.
        forma.action = (modo !== 'agregar' || boton?.hasAttribute('data-pb-accion-alta')) && boton?.dataset.pbAccion
            ? boton.dataset.pbAccion : forma.dataset.pbAccionNueva;
        if (titulo) {
            titulo.textContent = modo !== 'agregar' || boton?.dataset.pbTitulo
                ? (boton?.dataset.pbTitulo || titulo.dataset.pbTituloNueva)
                : titulo.dataset.pbTituloNueva;
        }
        if (instruccion) {
            instruccion.hidden = modo === 'ver';
        }
        if (registro) {
            llenaRegistro(forma, registro);
        }
        sincronizaFechas(forma);
        aplicaSegun(forma);
        limpiaError(forma);
        if (modo === 'ver') {
            window.ui?.setFormReadonly(forma, true);
        }
        // `data-pb-solo-alta`: lo que define el registro (cliente, ruta) se
        // elige al agregar y no cambia al actualizar.
        forma.querySelectorAll('[data-pb-solo-alta]').forEach(function (campo) {
            campo.disabled = modo !== 'agregar';
            if ($ && campo.matches('select[data-app-select2], select.select2-hidden-accessible')) {
                $(campo).trigger('change.select2');
            }
        });
        modal.dataset.pbModo = modo;

        // Un registro grande —un pedido con sus productos— no viaja en la fila:
        // se pide al abrir (`data-pb-registro-url`, Fase 4) y se llena igual.
        const url = boton?.dataset.pbRegistroUrl;
        const pedido = String((Number(forma.dataset.pbPedido) || 0) + 1);
        forma.dataset.pbPedido = pedido;
        forma.querySelectorAll('[data-pb-esperando-registro]').forEach(function (b) {
            b.disabled = false;
            delete b.dataset.pbEsperandoRegistro;
        });
        quitaEsqueletoCampos(forma);
        if (url) {
            // Guardar no se puede hasta tener el registro completo: guardar a
            // medio llenar borraría lo que no alcanzó a llegar.
            botonesDe(forma).filter(function (b) { return b.matches('[type="submit"]') && !b.disabled; }).forEach(function (b) {
                b.disabled = true;
                b.dataset.pbEsperandoRegistro = '1';
            });
            esqueletoCampos(forma);
            pideJson(url).then(function (datos) {
                // Si entretanto se abrió otro registro, esta respuesta ya no es de nadie.
                if (forma.dataset.pbPedido !== pedido) return;
                llenaRegistro(forma, datos.registro || {});
                sincronizaFechas(forma);
                aplicaSegun(forma);
                if (modo === 'ver') {
                    window.ui?.setFormReadonly(forma, true);
                }
                quitaEsqueletoCampos(forma);
                forma.querySelectorAll('[data-pb-esperando-registro]').forEach(function (b) {
                    b.disabled = false;
                    delete b.dataset.pbEsperandoRegistro;
                });
            }).catch(function (falla) {
                if (forma.dataset.pbPedido !== pedido) return;
                quitaEsqueletoCampos(forma);
                muestraError(forma, falla.message);
            });
        }
    });

    /**
     * Quita lo que dejó `_bloqueados` en el registro anterior: los campos se
     * vuelven a capturar y las copias ocultas se van.
     */
    function liberaBloqueados(forma) {
        forma.querySelectorAll('[data-pb-copia-bloqueada]').forEach(function (copia) { copia.remove(); });
        forma.querySelectorAll('[data-pb-bloqueado]').forEach(function (campo) {
            campo.disabled = false;
            campo.removeAttribute('data-pb-bloqueado');
            if ($ && campo.matches('select.select2-hidden-accessible')) $(campo).trigger('change.select2');
        });
    }

    /**
     * `_bloqueados` (R6, ficha 28): los campos que ya no cambian —un producto
     * con compras o ventas— se ven deshabilitados y viajan en una copia oculta,
     * para que el servidor reciba el mismo valor y compruebe que no cambió.
     */
    function bloqueaCampos(forma, nombres) {
        liberaBloqueados(forma);
        nombres.forEach(function (nombre) {
            forma.querySelectorAll('[name="' + CSS.escape(nombre) + '"]').forEach(function (campo) {
                if (campo.type === 'hidden' || campo.disabled) return;
                if (campo.type !== 'checkbox' || campo.checked) {
                    const copia = document.createElement('input');
                    copia.type = 'hidden';
                    copia.name = nombre;
                    copia.value = campo.value;
                    copia.setAttribute('data-pb-copia-bloqueada', '');
                    campo.after(copia);
                }
                campo.disabled = true;
                campo.setAttribute('data-pb-bloqueado', '');
                if ($ && campo.matches('select.select2-hidden-accessible')) $(campo).trigger('change.select2');
            });
        });
    }

    function llenaRegistro(forma, registro) {
        Object.entries(registro).forEach(function ([nombre, valor]) {
            if (nombre === '_productos' || nombre === '_bloqueados') return;
            forma.querySelectorAll('[name="' + CSS.escape(nombre) + '"]').forEach(function (campo) {
                ponValor(campo, valor);
            });
        });
        if (Array.isArray(registro._productos)) {
            window.pbProductos?.pon(forma, registro._productos);
        }
        if (Array.isArray(registro._bloqueados)) {
            bloqueaCampos(forma, registro._bloqueados);
        }
        forma.querySelectorAll('[data-pb-marca-grupo]').forEach(function (madre) {
            reflejaGrupo(forma, madre.dataset.pbMarcaGrupo);
        });
    }

    async function pideJson(url) {
        let respuesta;
        try {
            respuesta = await fetch(url, { credentials: 'same-origin', headers: JSON_CABECERAS });
        } catch (falla) {
            throw new Error('Sin respuesta. Revise la conexión e intente de nuevo.');
        }
        if (respuesta.status === 401 && window.pbSesion) {
            window.pbSesion.terminada();
        }
        let cuerpo = null;
        try {
            cuerpo = await respuesta.json();
        } catch (falla) {
            cuerpo = null;
        }
        if (!respuesta.ok || !cuerpo || cuerpo.ok === false) {
            throw new Error(cuerpo?.error?.mensaje || cuerpo?.mensaje || 'No se pudo cargar la información.');
        }
        return cuerpo.datos ?? cuerpo;
    }

    /*
     * Modal de detalle (`pb_detalle`, Fase 4): la ficha que antes era una página
     * se pide como JSON a `{raiz}/{id}` y se pinta adentro. Lo que traiga ya
     * viene escapado del servidor; sus acciones son enlaces y modales de la
     * pantalla, que siguen funcionando porque se escuchan en `document`.
     */
    document.addEventListener('show.bs.modal', function (evento) {
        const modal = evento.target;
        if (!modal.matches('[data-pb-detalle-raiz]')) {
            return;
        }
        const id = evento.relatedTarget?.dataset.pbId || modal.dataset.pbIdPendiente || '';
        delete modal.dataset.pbIdPendiente;
        const cuerpo = modal.querySelector('[data-pb-detalle-cuerpo]');
        const titulo = modal.querySelector('[data-pb-modal-titulo]');
        if (!/^\d+$/.test(id) || !cuerpo) {
            return;
        }
        modal.dataset.pbId = id;
        cuerpo.innerHTML = esqueleto('ficha');
        if (titulo) titulo.textContent = titulo.dataset.pbTituloNueva || titulo.textContent;
        pideJson(modal.dataset.pbDetalleRaiz + '/' + id + (modal.dataset.pbDetalleConsulta || '')).then(function (datos) {
            if (modal.dataset.pbId !== id) return;
            if (titulo && datos.titulo) titulo.textContent = datos.titulo;
            cuerpo.innerHTML = datos.html || '';
            // Fechas, selectores y archivos de la ficha (una captura dentro del
            // modal) se arman como los de la página.
            try {
                window.ui?.initialize(cuerpo);
            } catch (error) {
                console.warn('No fue posible preparar los campos de la ficha.', error);
            }
            // Las tablas de la ficha se montan igual que las del listado: en el
            // teléfono son tarjetas.
            cuerpo.querySelectorAll('table[data-pb-tabla]').forEach(function (tabla) {
                try {
                    iniciaTabla(tabla);
                } catch (error) {
                    console.warn('No fue posible iniciar la tabla.', tabla, error);
                    tabla.closest('.table-zone')?.classList.add('pb-tabla-sin-tarjetas');
                    preparada(tabla.closest('.table-zone'));
                }
            });
            document.dispatchEvent(new CustomEvent('lb:detalle', { detail: { modal: modal, id: id, datos: datos } }));
        }).catch(function (falla) {
            const aviso = document.createElement('div');
            aviso.className = 'alert alert-danger';
            aviso.setAttribute('role', 'alert');
            aviso.textContent = falla.message;
            cuerpo.replaceChildren(aviso);
        });
    });

    // GEN-071: el calendario no se queda abierto cuando se cierra su modal.
    document.addEventListener('hide.bs.modal', function (evento) {
        evento.target.querySelectorAll('input').forEach(function (campo) {
            campo._flatpickr?.close();
        });
    });

    // El primer campo recibe el foco al abrir, como en la plantilla base.
    document.addEventListener('shown.bs.modal', function (evento) {
        if (evento.target.matches('[data-pb-formulario]')) {
            const enfoca = evento.target.dataset.pbModo === 'ver'
                ? evento.target.querySelector('.btn-close')
                : evento.target.querySelector('form input:not([type="hidden"]):not([disabled]), form select:not([disabled]), form textarea:not([disabled])');
            enfoca?.focus();
        }
    });

    /*
     * Acciones de la fila que cambian algo (`a[data-pb-post]`, O4): no son
     * formularios en la fila. Se arma uno de paso con la marca y se manda por el
     * mismo camino que los modales: confirmación, envío único y errores.
     */
    document.addEventListener('click', function (evento) {
        const enlace = evento.target.closest('a[data-pb-post]');
        if (!enlace) {
            return;
        }
        evento.preventDefault();
        let campos = [];
        try {
            campos = Object.entries(JSON.parse(enlace.dataset.pbCampos || '{}'));
        } catch (e) {
            campos = [];
        }
        if (enlace.dataset.pbLlave) {
            // La misma llave en cada reintento de este enlace: el servidor responde lo mismo (H6).
            campos.push(['llave_idempotencia', enlace.dataset.pbLlave]);
        }
        campos.unshift(['volver', enlace.dataset.pbVolver || '']);
        enviaDesde(enlace, enlace.dataset.pbPost, campos, {
            confirma: enlace.dataset.confirma,
            confirmaTitulo: enlace.dataset.confirmaTitulo
        });
    });

    /*
     * «Exportar XLS» (guía §7, GEN-031 y GEN-032): se baja por `fetch` para
     * saber cómo respondió el servidor. Mientras trabaja se dice; un error se
     * muestra en la pantalla, nunca como una pestaña con el error.
     */
    document.addEventListener('click', async function (evento) {
        const enlace = evento.target.closest('a[data-pb-exporta]');
        if (!enlace || !window.fetch) {
            return;
        }
        evento.preventDefault();
        if (enlace.dataset.pbEnviando === '1') {
            return;
        }
        enlace.dataset.pbEnviando = '1';
        const espera = window.alerts?.loading?.('Preparando el archivo', 'Esto puede tardar si son muchos registros.');
        const control = new AbortController();
        espera?.onCancel(function () { control.abort(); });
        try {
            const respuesta = await fetch(enlace.href, { credentials: 'same-origin', signal: control.signal, headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            if (respuesta.status === 401 || llevaALaEntrada(respuesta)) {
                espera?.close();
                sesionTerminada();
                return;
            }
            const tipo = respuesta.headers.get('content-type') || '';
            if (!respuesta.ok || tipo.includes('json') || tipo.includes('text/html')) {
                const cuerpo = await respuesta.json().catch(function () { return null; });
                espera?.close();
                window.alerts?.error(cuerpo?.error?.mensaje || 'Error del sistema. Intente de nuevo o avise a soporte.', 'No se pudo exportar');
                return;
            }
            const disposicion = respuesta.headers.get('content-disposition') || '';
            const nombre = (disposicion.match(/filename="([^"]+)"/) || [])[1] || 'exportacion.xlsx';
            const archivo = await respuesta.blob();
            const liga = document.createElement('a');
            liga.href = URL.createObjectURL(archivo);
            liga.download = nombre;
            document.body.append(liga);
            liga.click();
            liga.remove();
            window.setTimeout(function () { URL.revokeObjectURL(liga.href); }, 60000);
            espera?.close();
        } catch (falla) {
            espera?.close();
            if (falla?.name !== 'AbortError') {
                window.alerts?.error('Sin respuesta. Revise la conexión e intente de nuevo.', 'No se pudo exportar');
            }
        } finally {
            delete enlace.dataset.pbEnviando;
        }
    });

    // «Hoy» junto a la fecha del filtro (GEN-019): solo cambia la fecha; la
    // consulta corre con «Buscar».
    document.addEventListener('click', function (evento) {
        const boton = evento.target.closest('button[data-pb-hoy]');
        if (!boton) {
            return;
        }
        const campo = boton.form?.querySelector('input[name="fecha"]');
        if (!campo) {
            return;
        }
        if (campo._flatpickr) {
            campo._flatpickr.setDate(boton.dataset.pbHoy, true);
        } else {
            campo.value = boton.dataset.pbHoy;
            campo.dispatchEvent(new Event('change', { bubbles: true }));
        }
    });

    // `?ver={id}` abre el listado con el modal de ese registro ya abierto (D5).
    function abreDesdeLaUrl() {
        // Una captura que otra pantalla deja precargada (Caducidades → Registrar
        // baja, ficha 21): el servidor pinta un enlace oculto con su registro.
        const precarga = document.querySelector('[data-pb-abre-al-cargar]');
        if (precarga && window.bootstrap?.Modal) {
            const modal = document.querySelector(precarga.dataset.bsTarget);
            if (modal) {
                window.bootstrap.Modal.getOrCreateInstance(modal).show(precarga);
                return;
            }
        }
        const id = new URLSearchParams(window.location.search).get('ver');
        if (!id || !/^\d+$/.test(id)) {
            return;
        }
        const enlace = document.querySelector('[data-pb-modo="ver"][data-pb-id="' + id + '"]')
            || document.querySelector('[data-pb-modo="actualizar"][data-pb-id="' + id + '"]');
        if (enlace && window.bootstrap?.Modal) {
            const modal = document.querySelector(enlace.dataset.bsTarget);
            window.bootstrap.Modal.getOrCreateInstance(modal).show(enlace);
            return;
        }
        // La URL vieja de una ficha (`/pedidos/5`) llega aquí aunque el registro
        // no esté en el filtro de hoy: el modal de detalle lo pide por su id.
        const detalle = document.querySelector('[data-pb-detalle-raiz]');
        if (detalle && window.bootstrap?.Modal) {
            detalle.dataset.pbIdPendiente = id;
            window.bootstrap.Modal.getOrCreateInstance(detalle).show();
        }
    }

    /* ---------------------------------------------------------------------
     * `form[data-pb-ajax]`: se manda por `fetch` y el servidor contesta JSON.
     *
     * - 200: a donde diga `datos.redirige`; el aviso ya está en la sesión.
     * - 422: cada queja debajo de su campo, sin cerrar el modal ni perder lo
     *   capturado. La que no tenga campo visible va a la caja de error.
     * - Lo demás (409 «tiene 2 oficinas activas», 403, 419): a la caja de
     *   error del modal o, en una baja de renglón, a un aviso de SweetAlert2.
     *
     * Va después de la confirmación: si todavía no se confirmó, aquélla ya
     * detuvo el envío y aquí no se hace nada.
     * ------------------------------------------------------------------- */

    function muestraError(forma, mensaje) {
        const caja = forma.querySelector('[data-pb-error]');
        if (caja) {
            caja.textContent = mensaje;
            caja.classList.remove('d-none');
            caja.setAttribute('tabindex', '-1');
            caja.scrollIntoView({ block: 'nearest' });
            caja.focus({ preventScroll: true });
        } else {
            window.alerts?.error(mensaje, 'No se pudo');
        }
    }

    /** ¿La respuesta es la entrada? Un `fetch` sigue la redirección y llega ahí. */
    function llevaALaEntrada(respuesta) {
        try {
            return respuesta.redirected && new URL(respuesta.url).pathname === '/entrar';
        } catch (falla) {
            return false;
        }
    }

    document.addEventListener('submit', async function (evento) {
        const forma = evento.target.closest('form[data-pb-ajax]');
        if (!forma || evento.defaultPrevented || !window.fetch) {
            return;
        }

        evento.preventDefault();
        // Envío único (GEN-072): mientras viaja, otro clic no sale. Antes de
        // limpiar nada: el segundo clic no borra el error del primero.
        if (forma.dataset.pbEnviando === '1') {
            return;
        }
        limpiaError(forma);
        const datos = new FormData(forma);
        if (!datos.get('_envio')) {
            datos.set('_envio', llaveDeEnvio(forma, forma.action));
        }
        bloqueaEnvio(forma);

        try {
            const respuesta = await fetch(forma.action, {
                method: 'POST',
                body: datos,
                credentials: 'same-origin',
                headers: JSON_CABECERAS
            });
            const cuerpo = await respuesta.json().catch(function () { return null; });

            if (respuesta.ok && cuerpo?.ok) {
                window.location.assign(cuerpo.datos?.redirige || window.location.href);
                return;
            }

            const error = cuerpo?.error || {};
            const campos = error.campos || {};
            // `deposito_referencia.1` es el segundo `deposito_referencia[]`: tiene
            // campo, y `ui.showValidationErrors` lo pinta debajo de ese renglón.
            const sinCampo = Object.entries(campos).filter(function ([nombre]) {
                const base = CSS.escape(nombre.replace(/\.\d+$/, '').replace(/\[\]$/, ''));
                return !forma.querySelector('[name="' + base + '"], [name="' + base + '[]"]');
            });

            if (respuesta.status === 401 || (!cuerpo && llevaALaEntrada(respuesta))) {
                muestraError(forma, 'Su sesión terminó. Entre de nuevo para guardar lo capturado.');
                sesionTerminadaConCaptura();
            } else if (respuesta.status === 419) {
                // La marca cambió (otra entrada, o la sesión se vació). Se toma la
                // vigente y se pide repetir: no se reenvía solo.
                try {
                    const estado = await estadoSesion();
                    if (estado.terminada) {
                        muestraError(forma, 'Su sesión terminó. Entre de nuevo para guardar lo capturado.');
                        sesionTerminadaConCaptura();
                    } else {
                        muestraError(forma, 'La página llevaba mucho tiempo abierta. Vuelva a pulsar Guardar.');
                    }
                } catch (falla) {
                    muestraError(forma, 'Sin respuesta. Revise la conexión e intente de nuevo.');
                }
            } else if (respuesta.status === 422 && Object.keys(campos).length > 0) {
                const resumio = window.ui?.showValidationErrors(forma, campos);
                if (!resumio && sinCampo.length > 0) {
                    muestraError(forma, sinCampo.map(function ([, queja]) { return queja; }).join(' '));
                }
            } else if (!cuerpo) {
                muestraError(forma, 'Error del sistema. Intente de nuevo o avise a soporte.');
            } else {
                muestraError(forma, error.mensaje || 'Error del sistema. Intente de nuevo o avise a soporte.');
            }
        } catch (falla) {
            muestraError(forma, 'Sin respuesta. Revise la conexión e intente de nuevo.');
        }

        liberaEnvio(forma);
        if (forma.hidden && !forma.closest('.modal')) {
            forma.remove();
        }
    });

    /* ---------------------------------------------------------------------
     * Un campo numérico en cero se selecciona al entrar: quien escribe «116»
     * sobre «0.00» esperaba 116, no 0.00116.
     * ------------------------------------------------------------------- */

    document.addEventListener('focusin', function (evento) {
        const campo = evento.target;
        if (!(campo instanceof HTMLInputElement) || campo.type !== 'number' || campo.readOnly) {
            return;
        }
        if (campo.value !== '' && Number(campo.value) === 0) {
            window.setTimeout(function () { campo.select(); }, 0);
        }
    });

    /* ---------------------------------------------------------------------
     * Envíos: el botón se deshabilita mientras la página se va, para que un
     * doble clic no mande dos veces una venta o una salida.
     * ------------------------------------------------------------------- */

    document.addEventListener('submit', function (evento) {
        const forma = evento.target;
        if (evento.defaultPrevented || forma.method?.toLowerCase() !== 'post') {
            return;
        }
        if (!forma.querySelector('input[name="_envio"]')) {
            const campo = document.createElement('input');
            campo.type = 'hidden';
            campo.name = '_envio';
            campo.value = llaveDeEnvio(forma, forma.action);
            forma.append(campo);
        }
        if (forma.target === '_blank') {
            // La página se queda: sin candado, con la llave fija mientras viva.
            // Un segundo clic recibe lo mismo en lugar de repetir el trabajo.
            return;
        }
        forma.dataset.pbEnviando = '1';
        // Después de este turno: el botón que se pulsó tiene que viajar con su valor.
        window.setTimeout(function () { bloqueaEnvio(forma); }, 0);
    });

    /* ---------------------------------------------------------------------
     * Avisos de la sesión: se pintan en línea (sin JavaScript se leen igual)
     * y además se anuncian con SweetAlert2, como la plantilla base. El de éxito, como
     * aviso breve que no hay que cerrar.
     * ------------------------------------------------------------------- */

    function anunciaAviso() {
        const aviso = document.querySelector('[data-pb-aviso]');
        if (!aviso || !window.alerts) {
            return;
        }
        const mensaje = aviso.querySelector('[data-pb-aviso-texto]')?.textContent.trim() || aviso.textContent.trim();
        const tono = aviso.dataset.pbAviso;
        if (tono === 'success') {
            // D11 (homologación): el éxito es el modal «Operación correcta», como
            // en RhToroV1. Antes era un aviso en la esquina.
            window.alerts.success(mensaje);
            aviso.hidden = true;
        } else if (tono === 'warning') {
            window.alerts.warning(mensaje);
        } else if (tono === 'danger') {
            window.alerts.error(mensaje);
        }
    }

    /*
     * Secciones según un campo (ficha 30): `data-pb-segun="tipo"` con
     * `data-pb-segun-valor="paquete"` solo se ve, y solo se envía, cuando el
     * campo `tipo` del formulario vale eso. Se anidan: lo de adentro de una
     * sección oculta queda apagado. Solo se reencienden los campos que esta
     * función apagó, no los que otra regla deshabilitó.
     */
    function aplicaSegun(forma) {
        if (!forma) return;
        forma.querySelectorAll('[data-pb-segun]').forEach(function (bloque) {
            const campo = forma.elements.namedItem(bloque.dataset.pbSegun);
            const valor = campo && 'value' in campo ? String(campo.value) : '';
            const padre = bloque.parentElement?.closest('[data-pb-segun]');
            const ve = valor === bloque.dataset.pbSegunValor && !(padre && padre.hidden);
            bloque.hidden = !ve;
            bloque.querySelectorAll('input, select, textarea').forEach(function (c) {
                if (!ve && !c.disabled) {
                    c.disabled = true;
                    c.dataset.pbSegunApagado = '';
                } else if (ve && c.hasAttribute('data-pb-segun-apagado')) {
                    c.disabled = false;
                    delete c.dataset.pbSegunApagado;
                }
            });
        });
    }

    // Select2 avisa con el `change` de jQuery, que no llega a addEventListener.
    if ($) {
        $(document).on('change', 'form select, form input', function () { if (this.form?.querySelector('[data-pb-segun]')) aplicaSegun(this.form); });
    } else {
        document.addEventListener('change', function (evento) {
            if (evento.target.form?.querySelector('[data-pb-segun]')) aplicaSegun(evento.target.form);
        });
    }

    /* ---------------------------------------------------------------------
     * «Toda la categoría»: la casilla con `data-pb-marca-grupo` marca o
     * desmarca las de su grupo (`data-pb-grupo`), y refleja si están todas.
     * ------------------------------------------------------------------- */

    document.addEventListener('change', function (evento) {
        const casilla = evento.target;
        const forma = casilla.form;
        if (!forma) return;
        if (casilla.dataset.pbMarcaGrupo) {
            forma.querySelectorAll('[data-pb-grupo="' + CSS.escape(casilla.dataset.pbMarcaGrupo) + '"]').forEach(function (c) {
                c.checked = casilla.checked;
            });
        } else if (casilla.dataset.pbGrupo) {
            reflejaGrupo(forma, casilla.dataset.pbGrupo);
        }
    });

    function reflejaGrupo(forma, grupo) {
        const todas = forma.querySelectorAll('[data-pb-grupo="' + CSS.escape(grupo) + '"]');
        const marcadas = Array.prototype.filter.call(todas, function (c) { return c.checked; }).length;
        const madre = forma.querySelector('[data-pb-marca-grupo="' + CSS.escape(grupo) + '"]');
        if (madre) {
            madre.checked = marcadas > 0 && marcadas === todas.length;
            madre.indeterminate = marcadas > 0 && marcadas < todas.length;
        }
    }

    // Al llenar un modal para actualizar, las casillas de grupo se ponen al día.
    document.addEventListener('shown.bs.modal', function (evento) {
        evento.target.querySelectorAll('form [data-pb-marca-grupo]').forEach(function (madre) {
            reflejaGrupo(madre.form, madre.dataset.pbMarcaGrupo);
        });
    });

    /* ---------------------------------------------------------------------
     * Vista previa de la foto antes de subirla: el `input[type=file]` con
     * `data-pb-vista-previa` apunta a la `img` de `image-upload-preview`.
     * ------------------------------------------------------------------- */

    document.addEventListener('change', function (evento) {
        const entrada = evento.target.closest('input[type="file"][data-pb-vista-previa]');
        const imagen = entrada && document.querySelector(entrada.dataset.pbVistaPrevia);
        const archivo = entrada?.files?.[0];
        if (!imagen || !archivo || !archivo.type.startsWith('image/')) {
            return;
        }
        if (imagen.dataset.pbUrl) {
            URL.revokeObjectURL(imagen.dataset.pbUrl);
        }
        imagen.dataset.pbUrl = URL.createObjectURL(archivo);
        imagen.src = imagen.dataset.pbUrl;
        imagen.hidden = false;
        imagen.closest('.image-upload-preview')?.querySelector('[data-pb-sin-foto]')?.setAttribute('hidden', '');
    });

    /* ---------------------------------------------------------------------
     * Filtros plegables en el teléfono. En pedidos, inventario o vehículos
     * los filtros ocupaban la primera pantalla entera a 375 px y la lista
     * quedaba abajo. Bajo 768 px se pliegan detrás de una barra que dice qué
     * está aplicado; con un error o con pocos campos se quedan abiertos.
     * ------------------------------------------------------------------- */

    function resumenFiltros(forma) {
        const partes = [];
        forma.querySelectorAll('input:not([type=hidden]):not([type=submit]), select').forEach(function (campo) {
            // Las fechas de flatpickr: el `name` va en un oculto y lo que se ve
            // es un texto sin nombre, etiquetado con `aria-labelledby`.
            const visibleDeFecha = !campo.name && campo.getAttribute('aria-labelledby');
            if (campo.disabled || (!campo.name && !visibleDeFecha) || campo.closest('[hidden]')) {
                return;
            }
            let valor = '';
            if (campo.tagName === 'SELECT') {
                valor = campo.value !== '' ? (campo.selectedOptions[0]?.textContent || '').trim() : '';
            } else if (campo.type === 'checkbox' || campo.type === 'radio') {
                valor = campo.checked ? 'sí' : '';
            } else {
                valor = campo.value.trim();
            }
            if (valor === '') {
                return;
            }
            const etiqueta = visibleDeFecha
                ? document.getElementById(visibleDeFecha)
                : (campo.id ? forma.querySelector('label[for="' + CSS.escape(campo.id) + '"]') : null);
            const nombre = (etiqueta?.textContent || '').replace('*', '').trim();
            partes.push(nombre ? nombre + ': ' + valor : valor);
        });
        return partes;
    }

    function plegaFiltros(forma, indice) {
        const campos = forma.querySelectorAll('input:not([type=hidden]):not([type=submit]), select, textarea');
        if (campos.length < 3 || forma.dataset.pbPlegable === '0') {
            return;
        }
        const id = forma.id || (forma.id = 'pb-filtros-' + indice);
        const barra = document.createElement('div');
        barra.className = 'pb-filtros-barra';
        const resumen = document.createElement('span');
        resumen.className = 'pb-filtros-barra__resumen';
        const boton = document.createElement('button');
        boton.type = 'button';
        boton.className = 'btn btn-outline-secondary btn-sm';
        boton.setAttribute('aria-controls', id);
        barra.append(resumen, boton);
        forma.before(barra);

        const pinta = function (abierto) {
            forma.classList.toggle('pb-filtros-plegados', !abierto);
            boton.setAttribute('aria-expanded', abierto ? 'true' : 'false');
            const partes = resumenFiltros(forma);
            resumen.textContent = partes.length ? partes.join(' · ') : 'Sin filtros aplicados';
            boton.innerHTML = '<i class="bi ' + (abierto ? 'bi-chevron-up' : 'bi-funnel') + '" aria-hidden="true"></i> '
                + (abierto ? 'Ocultar filtros' : 'Filtros' + (partes.length ? ' (' + partes.length + ')' : ''));
        };
        const conError = forma.querySelector('.is-invalid, .invalid-feedback:not(:empty)') !== null;
        pinta(conError);
        // flatpickr llena su texto visible después de este punto.
        window.setTimeout(function () { pinta(!forma.classList.contains('pb-filtros-plegados')); }, 0);
        boton.addEventListener('click', function () {
            const abrir = forma.classList.contains('pb-filtros-plegados');
            pinta(abrir);
            if (abrir) {
                forma.querySelector('input:not([type=hidden]), select')?.focus();
            }
        });
    }

    /*
     * Movimiento (D25.3). Lo que se mueve lo pone `tema.css`; aquí solo
     * se cuenta (CSS no sabe en qué lugar va cada tarjeta) y se hacen rodar las
     * cifras del Tablero, con el efecto Number Ticker.
     */
    const REVELABLES = '.app-main :is(.module-card, .summary-tile, .metric-card, .inicio-acceso, .form-section, .record-cards > :not(.pb-esqueleto))';
    const reduceMovimiento = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches === true;

    /** El turno de cada tarjeta en la cascada, en el orden de la página; desde la octava ya no espera. */
    function numeraRevelados(raiz) {
        raiz.querySelectorAll(REVELABLES).forEach(function (elemento, indice) {
            elemento.style.setProperty('--pb-i', String(Math.min(indice, 7)));
        });
    }

    /** Lo que entre después de la carga (el Tablero que se actualiza, otra página de la tabla) ya no se revela. */
    function terminaRevelado() {
        window.setTimeout(function () { document.documentElement.classList.add('pb-revelado'); }, 1200);
    }

    const CIFRAS = '.app-main :is(.summary-tile, .metric-card) > strong';
    const DURACION_CIFRA = 600;

    /** «$1,234.50» → prefijo «$», 1234.5 con dos decimales y comas. Si no es solo una cifra, nada. */
    function parteCifra(texto) {
        const m = String(texto).trim().match(/^([^\d-]{0,3})(-?\d[\d,]*(?:\.\d+)?)([^\d]{0,12})$/);
        if (!m) return null;
        const numero = Number(m[2].replace(/,/g, ''));
        if (!Number.isFinite(numero)) return null;
        return {
            prefijo: m[1],
            numero: numero,
            decimales: (m[2].split('.')[1] || '').length,
            comas: m[2].includes(','),
            sufijo: m[3],
        };
    }

    function escribeCifra(partes, valor) {
        return partes.prefijo + valor.toLocaleString('en-US', {
            minimumFractionDigits: partes.decimales,
            maximumFractionDigits: partes.decimales,
            useGrouping: partes.comas,
        }) + partes.sufijo;
    }

    /** La etiqueta de la tarjeta («Pedidos», «Total del día») identifica la cifra entre una actualización y otra. */
    function llaveCifra(fuerte) {
        return fuerte.parentElement?.querySelector(':scope > span, :scope > div > span')?.textContent.trim() || '';
    }

    function leeCifras(raiz) {
        const valores = new Map();
        raiz.querySelectorAll(CIFRAS).forEach(function (fuerte) {
            const valor = fuerte.dataset.pbValor !== undefined ? Number(fuerte.dataset.pbValor) : parteCifra(fuerte.textContent)?.numero;
            if (Number.isFinite(valor)) valores.set(llaveCifra(fuerte), valor);
        });
        return valores;
    }

    function ruedaCifra(fuerte, partes, desde) {
        const real = fuerte.textContent.trim();
        // El lector de pantalla lee el valor final desde el principio; lo que rueda es solo para la vista.
        // `<data>` y no `<span>`: la plantilla da a todo `span` de la tarjeta el aspecto de la etiqueta.
        fuerte.textContent = '';
        const oculto = document.createElement('data');
        oculto.value = String(partes.numero);
        oculto.className = 'visually-hidden';
        oculto.textContent = real;
        const visible = document.createElement('data');
        visible.value = String(partes.numero);
        visible.setAttribute('aria-hidden', 'true');
        visible.dataset.pbCifra = '';
        visible.textContent = escribeCifra(partes, desde);
        fuerte.append(oculto, visible);
        fuerte.dataset.pbValor = String(partes.numero);

        const arranque = performance.now();
        const paso = function (ahora) {
            const t = Math.min(1, (ahora - arranque) / DURACION_CIFRA);
            const avance = 1 - Math.pow(1 - t, 3);
            visible.textContent = escribeCifra(partes, desde + (partes.numero - desde) * avance);
            if (t < 1) {
                window.requestAnimationFrame(paso);
            } else {
                visible.textContent = real;
            }
        };
        window.requestAnimationFrame(paso);
    }

    /**
     * Hace rodar las cifras de `raiz`: desde 0 al entrar en pantalla, o desde
     * el valor que tenían (`previos`, de `lee`) cuando el Tablero se actualiza.
     */
    function iniciaCifras(raiz, previos) {
        if (reduceMovimiento()) return;
        const observador = !previos && 'IntersectionObserver' in window
            ? new IntersectionObserver(function (entradas) {
                entradas.forEach(function (entrada) {
                    if (!entrada.isIntersecting) return;
                    observador.unobserve(entrada.target);
                    const partes = parteCifra(entrada.target.textContent);
                    if (partes) ruedaCifra(entrada.target, partes, 0);
                });
            }, { threshold: 0.4 })
            : null;
        raiz.querySelectorAll(CIFRAS).forEach(function (fuerte) {
            if (fuerte.dataset.pbValor !== undefined) return;
            const partes = parteCifra(fuerte.textContent);
            if (!partes) return;
            if (previos) {
                const antes = previos.get(llaveCifra(fuerte));
                if (Number.isFinite(antes) && antes !== partes.numero) ruedaCifra(fuerte, partes, antes);
            } else if (observador) {
                observador.observe(fuerte);
            } else {
                ruedaCifra(fuerte, partes, 0);
            }
        });
    }

    window.pbCifras = { lee: leeCifras, inicia: iniciaCifras };

    document.addEventListener('DOMContentLoaded', function () {
        // Los mensajes de validación de `main.js` en español en todo el sistema.
        document.querySelectorAll('form:not([data-app-validation-lang])').forEach(function (forma) {
            forma.dataset.appValidationLang = 'es';
        });
        enlazaFechasVisibles();
        document.querySelectorAll('table[data-pb-tabla]').forEach(function (tabla) {
            try {
                iniciaTabla(tabla);
            } catch (error) {
                console.warn('No fue posible iniciar la tabla.', tabla, error);
                tabla.closest('.table-zone')?.classList.add('pb-tabla-sin-tarjetas');
                preparada(tabla.closest('.table-zone'));
            }
        });
        // Lo que no tenga tabla que iniciar no se queda en esqueleto.
        document.querySelectorAll('.table-zone.pb-preparando').forEach(preparada);
        document.querySelectorAll('img[data-pb-foto]').forEach(function (foto) {
            if (foto.complete) foto.classList.add('pb-cargada');
        });
        // La barra sólo se ve bajo 768 px (tema.css): en el escritorio
        // los filtros siguen abiertos aunque la clase quede puesta.
        document.querySelectorAll('form.module-filters').forEach(plegaFiltros);
        anunciaAviso();
        abreDesdeLaUrl();
        const restante = document.querySelector('meta[name="pb-sesion-restante"]')?.content;
        if (restante !== undefined && restante !== '') {
            programaAviso(Number(restante));
        }
        numeraRevelados(document);
        terminaRevelado();
        iniciaCifras(document);
    });
})(window, document);
