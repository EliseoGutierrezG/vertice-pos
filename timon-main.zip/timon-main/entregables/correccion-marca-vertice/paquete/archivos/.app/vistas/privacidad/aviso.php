<?php
/**
 * Aviso de privacidad. ⚠️ Borrador para revisión legal: los datos del responsable
 * salen de `parametro` y el letrero se quita con `aviso_privacidad_aprobado`.
 *
 * @var callable $e
 * @var bool $aprobado
 * @var string $responsable
 * @var string $domicilio
 * @var string $contacto
 */
?>
<main class="aviso-privacidad" id="contenido" tabindex="-1">
<h1>Aviso de privacidad</h1>
<?php if (!$aprobado): ?>
<p role="status"><strong>Borrador pendiente de revisión legal.</strong> Puede cambiar antes de aprobarse.</p>
<?php endif; ?>

<h2>Aviso corto</h2>
<p><?= $e($responsable) ?> usa sus datos para atender sus pedidos y reservaciones, cobrar y llevar el control del personal. Para conocer el detalle y sus derechos, lea este aviso completo.</p>

<h2>Quién es responsable</h2>
<p><?= $e($responsable) ?>, con domicilio en <?= $e($domicilio) ?>. Vértice Software da la licencia del sistema y su soporte, y trata los datos sólo por encargo del responsable.</p>

<h2>Qué datos se usan y para qué</h2>
<ul>
    <li><strong>Clientes:</strong> nombre, teléfono y, en pedidos a domicilio, la dirección de entrega, para preparar, entregar y cobrar su pedido; en reservaciones, nombre, teléfono, fecha y número de personas.</li>
    <li><strong>Personal:</strong> nombre, teléfono, correo, puesto y sucursal, para administrar su acceso y su trabajo.</li>
    <li><strong>Proveedores:</strong> contacto, teléfono, correo y RFC, para las compras.</li>
    <li><strong>Quien usa el sistema:</strong> sus acciones y dirección IP, para la seguridad y la auditoría.</li>
</ul>

<h2>Cuánto tiempo se guardan</h2>
<ul>
    <li>Las ventas y los registros contables se conservan el plazo que marcan las obligaciones fiscales.</li>
    <li>Los demás datos, mientras dure la relación y lo que exijan las obligaciones aplicables.</li>
</ul>

<h2>Con quién se comparten</h2>
<ul>
    <li>Con el proveedor de alojamiento del sistema y con Expo, que entrega los avisos a la app.</li>
    <li>Con WhatsApp y las aplicaciones de mapas, sólo cuando la persona decide usarlas.</li>
</ul>

<h2>Sus derechos</h2>
<p>Puede pedir acceso, rectificación, cancelación u oposición al uso de sus datos, y revocar su consentimiento, escribiendo a: <?= $e($contacto) ?>. Indique su nombre, cómo contestarle y qué pide. Si se cancelan sus datos, se quitan los que lo identifican y las ventas se conservan sin ellos, porque hay obligación de guardarlas.</p>

<h2>Cambios a este aviso</h2>
<p>Los cambios se publican en esta misma página. Última actualización: 19 de noviembre de 2026.</p>
<p><small>© 2026 Vértice Software. Todos los derechos reservados.</small></p>
</main>
