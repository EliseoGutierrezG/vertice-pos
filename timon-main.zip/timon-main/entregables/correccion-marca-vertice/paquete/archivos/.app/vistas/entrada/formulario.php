<?php
/**
 * La pantalla de entrada, con el formulario de entrada de la plantilla base.
 *
 * El mensaje de error es siempre el mismo, diga lo que diga el motivo real:
 * "usuario no existe" y "contraseña incorrecta" por separado le regalan a
 * quien prueba la mitad del trabajo.
 *
 * A diferencia de la plantilla base no entra por AJAX: es un POST normal con su marca
 * CSRF, así que funciona igual sin JavaScript.
 *
 * @var callable $e
 * @var \Nucleo\Csrf $csrf
 * @var string|null $error
 * @var string $usuario
 * @var string|null $vuelta  A dónde regresar al entrar (`Entrada::vueltaValida`)
 */
?>
<div class="auth-brand">
    <?= pb_marca_logo($marcaVisual ?? null, 'horizontal', pb_marca_texto($marcaVisual ?? null)) ?>
</div>

<div class="auth-heading">
    <span class="auth-badge">Acceso privado</span>
    <h1>Entrar</h1>
    <p>Use el usuario y la contraseña que le dio la gerencia.</p>
</div>

<form id="loginForm" method="post" action="/entrar" autocomplete="on">
    <?= $csrf->campo() ?>
    <?php if (!empty($vuelta)): ?>
        <input type="hidden" name="vuelta" value="<?= $e((string) $vuelta) ?>">
    <?php endif; ?>

    <div class="auth-field">
        <label for="usuario">Usuario <span aria-hidden="true">*</span></label>
        <input id="usuario" name="usuario" type="text" placeholder="Usuario"
            autocapitalize="none" spellcheck="false" autocomplete="username" required autofocus
            value="<?= $e($usuario ?? '') ?>">
    </div>

    <div class="auth-field">
        <label for="clave">Contraseña <span aria-hidden="true">*</span></label>
        <?php /* «Mostrar» lo enciende entrada.js: sin JavaScript no aparece. */ ?>
        <div class="auth-clave-campo">
            <input id="clave" name="clave" type="password" placeholder="Contraseña"
                autocomplete="current-password" required>
            <button class="auth-mostrar" type="button" data-mostrar-clave="clave"
                aria-controls="clave" aria-pressed="false" hidden>
                <i class="bi bi-eye" aria-hidden="true"></i><span>Mostrar</span>
            </button>
        </div>
    </div>

    <p id="loginError" class="auth-error" role="alert" aria-live="polite"><?= !empty($error) ? $e((string) $error) : '' ?></p>
    <button class="auth-submit" id="loginSubmit" type="submit">Entrar</button>
</form>

<p class="auth-note">Plataforma interna de <?= pb_marca_texto($marcaVisual ?? null) ?> · <a href="/aviso-privacidad">Aviso de privacidad</a></p>
<p class="auth-note auth-note--pie">© 2026 Vértice Software. Todos los derechos reservados.</p>
