<?php
/**
 * El armazón de todas las pantallas del sistema.
 *
 * Es el marcado de la plantilla base (encabezado, barra lateral, barra
 * superior, pie y scripts) con sus mismas librerías, en el mismo orden, y su
 * `main.css` intacto. Lo único propio es `tema.css`, que cambia
 * los colores, y `plantilla.js`, que monta DataTables y las tarjetas sobre las
 * tablas que ya llegan pintadas del servidor. La identidad y la autorización
 * siguen siendo de El Timón; el código de negocio de RH no se copia.
 *
 * El menú se arma con lo que el usuario **puede**, preguntándoselo a la misma
 * identidad que el backend usa para rechazar. Esconder el botón es cortesía;
 * quien protege es el intermediario de permiso. Agrupar las entradas no cambia
 * eso: **cada entrada sigue pasando por `puede()`** y un grupo que se queda sin
 * entradas visibles no se pinta.
 *
 * @var callable $e
 * @var string   $contenido  HTML ya pintado: es la pantalla de dentro
 * @var \Nucleo\Identidad $identidad
 * @var \Nucleo\Sesion    $sesion
 * @var \Nucleo\Csrf      $csrf
 * @var string   $titulo
 */

$titulo ??= 'El Timón';
$aviso = $sesion->aviso();

/**
 * Los grupos del menú, pintados como las secciones de
 * la plantilla base: un `app-menu__toggle` que despliega sus opciones. Cada entrada es
 * ruta, nombre, icono y el permiso —o los permisos, y basta con tener uno— del
 * que cuelga.
 *
 * Solo se listan las pantallas que ya existen: cada fase agrega las suyas
 * en `menu.php`.
 */
$grupos = require __DIR__ . '/menu.php';

// La ruta de ahora, sin la consulta. Se usa para marcar el activo y para el
// antetítulo; es lectura de la petición, no una decisión de negocio.
$aqui = '/' . trim((string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH), '/');

// Pantallas que no tienen entrada propia en el menú y viven dentro de un módulo.
$alias = [];

/** Marca activa la entrada del módulo, también en sus pantallas de dentro. */
$activa = static function (string $ruta) use ($aqui, $alias): bool {
    foreach ([$ruta, ...($alias[$ruta] ?? [])] as $raiz) {
        if ($aqui === $raiz || str_starts_with($aqui, $raiz . '/')) {
            return true;
        }
    }

    return false;
};

/** ¿Hay algún permiso de los que pide esta entrada? */
$puede = static function (array|string $permiso) use ($identidad): bool {
    foreach ((array) $permiso as $cual) {
        if ($identidad->puede($cual)) {
            return true;
        }
    }

    return false;
};

// El antetítulo es el módulo en el que se está. Sale del propio menú, así que
// no hay una segunda lista que se pueda desincronizar.
$modulo = (($marcaVisual ?? null)?->vigente() ?? \Servicios\MarcaVisual::BASE)['nombre_corto'];
foreach ($grupos as [, , $entradas]) {
    foreach ($entradas as [$ruta, $nombre]) {
        if ($activa($ruta)) {
            $modulo = $nombre;
        }
    }
}
if ($activa('/perfil')) {
    $modulo = 'Cuenta';
}
if ($aqui === '/panel') {
    $modulo = 'Tablero';
}

// La sucursal de la persona; el administrador no tiene una porque ve todas.
$sucursal = trim((string) ($identidad->hay() ? ($identidad->usuario()['sucursal'] ?? 'Todas las sucursales') : ''));
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= $e($csrf->marca()) ?>">
    <?php $restanteSesion = isset($vidaSesion) ? $vidaSesion() : null; ?>
    <?php if ($restanteSesion !== null): ?>
        <meta name="pb-sesion-restante" content="<?= (int) $restanteSesion ?>">
    <?php endif; ?>
    <meta name="theme-color" content="<?= $e((($marcaVisual ?? null)?->vigente() ?? \Servicios\MarcaVisual::BASE)['colores']['tinta']) ?>">
    <title><?= $e($titulo) ?> · <?= pb_marca_texto($marcaVisual ?? null, 'nombre_corto') ?></title>
    <link rel="icon" href="/recursos/isotipo.svg?v=20261114.2" type="image/svg+xml">
    <?php require __DIR__ . '/estilos.php'; ?>
</head>
<body>
<a class="visually-hidden-focusable btn btn-primary position-fixed top-0 start-0 m-2 pb-saltar" href="#contenido">Saltar al contenido</a>
<div class="app-shell">
    <aside class="app-sidebar" id="appSidebar" aria-label="Menú principal">
        <div class="app-brand">
            <span class="app-brand__mark">
                <?= pb_marca_logo($marcaVisual ?? null, 'isotipo', pb_marca_texto($marcaVisual ?? null, 'nombre_corto')) ?>
            </span>
            <div>
                <strong><?= pb_marca_texto($marcaVisual ?? null, 'nombre_corto') ?></strong>
                <small>Panel</small>
            </div>
        </div>

        <nav class="app-menu" aria-label="Navegación principal">
            <a class="app-menu__link <?= $aqui === '/panel' ? 'is-active' : '' ?>" href="/panel" title="Tablero"
               <?= $aqui === '/panel' ? 'aria-current="page"' : '' ?>>
                <span class="app-menu__item">
                    <i class="bi bi-speedometer2"></i>
                    <span class="app-menu__text">Tablero</span>
                </span>
            </a>
            <?php foreach ($grupos as $numero => [$grupo, $iconoGrupo, $entradas]): ?>
                <?php
                // Primero se resuelve qué entradas se ven; si no queda
                // ninguna, la sección tampoco se pinta.
                $visibles = array_values(array_filter($entradas, static fn (array $fila): bool => $puede($fila[3])));
                if ($visibles === []) {
                    continue;
                }
                $abierta = false;
                foreach ($visibles as [$ruta]) {
                    $abierta = $abierta || $activa($ruta);
                }
                $idGrupo = 'menu-grupo-' . $numero;
                ?>
                <button class="app-menu__toggle <?= $abierta ? '' : 'collapsed' ?>" type="button"
                    data-bs-toggle="collapse" data-bs-target="#<?= $idGrupo ?>"
                    aria-expanded="<?= $abierta ? 'true' : 'false' ?>" aria-controls="<?= $idGrupo ?>"
                    title="<?= $e($grupo) ?>">
                    <span class="app-menu__item">
                        <i class="bi <?= $e($iconoGrupo) ?>"></i>
                        <span class="app-menu__text"><?= $e($grupo) ?></span>
                    </span>
                    <i class="bi bi-chevron-right app-menu__chevron"></i>
                </button>
                <div class="collapse app-menu__submenu <?= $abierta ? 'show' : '' ?>" id="<?= $idGrupo ?>">
                    <?php foreach ($visibles as [$ruta, $nombre, $icono]): ?>
                        <a class="<?= $activa($ruta) ? 'is-active' : '' ?>" href="<?= $e($ruta) ?>"
                           <?= $activa($ruta) ? 'aria-current="page"' : '' ?>>
                            <i class="bi <?= $e($icono) ?>"></i>
                            <?= $e($nombre) ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </nav>
    </aside>
    <div class="app-sidebar-backdrop" id="sidebarBackdrop" aria-hidden="true"></div>

    <div class="app-content">
        <header class="app-topbar">
            <button class="app-icon-button d-lg-none" type="button" id="sidebarToggle"
                aria-label="Abrir menú" aria-controls="appSidebar" aria-expanded="false">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <button class="app-icon-button app-sidebar-collapse d-none d-lg-inline-grid" type="button"
                id="sidebarCollapseToggle" aria-label="Contraer menú" aria-pressed="false">
                <i class="bi bi-layout-sidebar-inset"></i>
            </button>

            <div class="app-topbar__heading">
                <p class="app-topbar__eyebrow mb-0"><?= $e(mb_strtoupper($modulo)) ?><?= $sucursal !== '' ? ' · ' . $e(mb_strtoupper($sucursal)) : '' ?></p>
            </div>

            <?php if ($identidad->hay()): ?>
                <div class="app-topbar__actions">
                    <div class="app-user-menu" id="userMenu">
                        <button class="app-user-menu__toggle" type="button" id="userMenuToggle"
                            aria-expanded="false" aria-haspopup="true">
                            <span class="app-user-menu__avatar pb-inicial" aria-hidden="true"><?= $e(pb_inicial($identidad->nombre())) ?></span>
                            <span class="app-user-menu__text">
                                <strong><?= $e($identidad->nombre()) ?></strong>
                                <small><?= $e($identidad->usuario()['usuario'] ?? '') ?></small>
                            </span>
                            <i class="bi bi-chevron-down app-user-menu__caret" aria-hidden="true"></i>
                        </button>
                        <div class="app-user-menu__dropdown" id="userMenuDropdown" hidden>
                            <div class="app-user-menu__header">
                                <span class="app-user-menu__photo pb-inicial" aria-hidden="true"><?= $e(pb_inicial($identidad->nombre())) ?></span>
                                <strong><?= $e($identidad->nombre()) ?></strong>
                                <small><?= $e($identidad->usuario()['usuario'] ?? '') ?></small>
                            </div>
                            <div class="app-user-menu__actions">
                                <a class="app-user-menu__action" href="/perfil">
                                    <i class="bi bi-person-circle" aria-hidden="true"></i>
                                    <span>Mi perfil</span>
                                </a>
                                <a class="app-user-menu__action app-user-menu__action--danger"
                                    href="/entrar" data-action="logout">
                                    <i class="bi bi-box-arrow-right" aria-hidden="true"></i>
                                    <span>Cerrar sesión</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </header>
        <main class="app-main" id="contenido" tabindex="-1">
            <?php if ($aviso !== null): ?>
                <?= pb_aviso($aviso['tono'], $aviso['texto'], $aviso['campos'] ?? [], true) ?>
            <?php endif; ?>
            <?= $contenido ?>
        </main>
        <footer class="app-footer">
            <span><strong><?= pb_marca_texto($marcaVisual ?? null) ?></strong></span>
            <span>© 2026 Vértice Software. Todos los derechos reservados.</span>
        </footer>
    </div>
</div>
<?php require __DIR__ . '/scripts.php'; ?>
</body>
</html>
