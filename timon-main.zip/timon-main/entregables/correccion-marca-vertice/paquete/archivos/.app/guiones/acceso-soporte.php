<?php
declare(strict_types=1);

/**
 * El acceso de soporte de Vértice Software: nominal, con motivo y con caducidad.
 *
 *   php guiones/acceso-soporte.php abre --usuario=nombre.apellido --nombre="Nombre" --apellido="Apellido" \
 *       --horas=8 --motivo="Ticket 123: revisar una liquidación"
 *   php guiones/acceso-soporte.php cierra --usuario=nombre.apellido
 *
 * La cuenta es de una persona con nombre; no hay un usuario «soporte» compartido.
 * Nace con una contraseña temporal que se enseña una sola vez y debe cambiarse al
 * entrar. Al vencer no entra, y el mantenimiento diario la deja inactiva y le corta
 * los teléfonos. Abrir de nuevo la reactiva. Todo queda en la bitácora.
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

use Modelos\Usuarios;
use Nucleo\BaseDatos;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

const HORAS_MAXIMAS = 72;

// A mano y no con getopt(): getopt deja de leer en el primer argumento que no es
// opción, y aquí ése es justo la acción.
$opciones = [];
foreach (array_slice($argv, 2) as $argumento) {
    if (preg_match('/^--(usuario|nombre|apellido|horas|motivo|puesto)=(.*)$/su', $argumento, $m) !== 1) {
        fwrite(STDERR, "No entiendo «{$argumento}». Las opciones van como --nombre=valor.\n");
        exit(2);
    }
    $opciones[$m[1]] = $m[2];
}
$accion = $argv[1] ?? '';
$usuario = trim((string) ($opciones['usuario'] ?? ''));

if (!in_array($accion, ['abre', 'cierra'], true) || $usuario === '') {
    fwrite(STDERR, "Uso: acceso-soporte.php (abre|cierra) --usuario=nombre.apellido [--nombre= --apellido= --horas= --motivo=]\n");
    exit(2);
}

$bd = new BaseDatos(Nucleo\Configuracion::baseDatos($raiz));
$app = Nucleo\Configuracion::aplicacion($raiz);
$bitacora = new Nucleo\Bitacora(
    $bd,
    new Nucleo\Registro((string) $app['registros'], (bool) $app['depurar']),
    (new Nucleo\ContextoAuditoria())->comoGuion('acceso_soporte')
);
$usuarios = new Usuarios($bd);
$cuenta = $usuarios->porUsuario($usuario);

if ($accion === 'cierra') {
    if ($cuenta === null) {
        fwrite(STDERR, "No existe esa cuenta.\n");
        exit(1);
    }
    if ($bd->valor('SELECT acceso_hasta FROM usuario WHERE id = ?', [(int) $cuenta['id']]) === null) {
        fwrite(STDERR, "Esa cuenta no es un acceso con caducidad; se da de baja en Personal.\n");
        exit(1);
    }
    $bd->transaccion(static function (BaseDatos $bd) use ($cuenta, $bitacora, $usuario): void {
        $id = (int) $cuenta['id'];
        $bd->ejecuta('UPDATE usuario SET acceso_hasta = NOW(), id_estatus = 3, sesion_version = sesion_version + 1 WHERE id = ?', [$id]);
        $bd->ejecuta('UPDATE token_acceso SET revocado_en = NOW() WHERE id_usuario = ? AND revocado_en IS NULL', [$id]);
        $bitacora->registra('seguridad', 'cierra_acceso_soporte', 'usuario', $id, despues: ['usuario' => $usuario]);
    });
    printf("Acceso de «%s» cerrado.\n", $usuario);
    exit(0);
}

$horas = (int) ($opciones['horas'] ?? 0);
$motivo = trim((string) ($opciones['motivo'] ?? ''));
if ($horas < 1 || $horas > HORAS_MAXIMAS) {
    fwrite(STDERR, 'Indique --horas entre 1 y ' . HORAS_MAXIMAS . ".\n");
    exit(2);
}
if (mb_strlen($motivo) < 10 || mb_strlen($motivo) > 255) {
    fwrite(STDERR, "Indique --motivo, entre 10 y 255 caracteres: por qué hace falta entrar.\n");
    exit(2);
}

$temporal = null;
if ($cuenta === null) {
    $nombre = trim((string) ($opciones['nombre'] ?? ''));
    $apellido = trim((string) ($opciones['apellido'] ?? ''));
    if ($nombre === '' || $apellido === '') {
        fwrite(STDERR, "Una cuenta nueva pide --nombre y --apellido: el acceso es de una persona.\n");
        exit(2);
    }
    $clavePuesto = (string) ($opciones['puesto'] ?? 'administrador');
    $idPuesto = (int) $bd->valor('SELECT id FROM puesto WHERE clave = ? AND id_estatus = 4', [$clavePuesto]);
    if ($idPuesto === 0) {
        fwrite(STDERR, "No existe ese puesto.\n");
        exit(1);
    }
    if ($clavePuesto !== 'administrador') {
        fwrite(STDERR, "Sólo el puesto de administrador no necesita sucursal; los demás se dan de alta en Personal.\n");
        exit(2);
    }
    $temporal = Usuarios::claveTemporal();
}

$hasta = $bd->transaccion(static function (BaseDatos $bd) use (
    $cuenta, $usuarios, $temporal, $usuario, $horas, $motivo, $bitacora, &$idPuesto, &$nombre, &$apellido
): string {
    if ($cuenta === null) {
        $idPersonal = $bd->inserta(
            'INSERT INTO personal (nombre, apellido_paterno, id_puesto, id_sucursal, fecha_ingreso) VALUES (?, ?, ?, NULL, CURDATE())',
            [$nombre, $apellido, $idPuesto]
        );
        $id = $usuarios->crea($idPersonal, $usuario, (string) $temporal, temporal: true);
    } else {
        $id = (int) $cuenta['id'];
    }

    $bd->ejecuta(
        'UPDATE usuario SET acceso_hasta = DATE_ADD(NOW(), INTERVAL ? HOUR), acceso_motivo = ?, id_estatus = 4 WHERE id = ?',
        [$horas, $motivo, $id]
    );
    $vence = (string) $bd->valor('SELECT acceso_hasta FROM usuario WHERE id = ?', [$id]);
    $bitacora->registra('seguridad', 'abre_acceso_soporte', 'usuario', $id, despues: [
        'usuario' => $usuario, 'motivo' => $motivo, 'horas' => $horas, 'hasta' => $vence,
    ]);

    return $vence;
});

printf("Acceso de «%s» abierto hasta %s.\n", $usuario, $hasta);
if ($temporal !== null) {
    // Se enseña esta única vez. No se guarda en claro ni va al registro.
    printf("Contraseña temporal, para cambiarla al entrar: %s\n", $temporal);
}
