'use strict';
const cacheApp = 'timon-app-ada4be35cc679c47';
const inicio = '/app/';
const recursos = path => path.startsWith('/app/_expo/') || path.startsWith('/app/assets/');

self.addEventListener('install', event => event.waitUntil((async () => {
    const cache = await caches.open(cacheApp);
    const pagina = await fetch(inicio, { cache: 'reload' });
    if (!pagina.ok) throw new Error('La app no está disponible');
    const html = await pagina.clone().text();
    const rutas = [...html.matchAll(/(?:src|href)="([^"]+)"/g)]
        .map(x => new URL(x[1], self.location.origin + inicio))
        .filter(x => x.origin === self.location.origin && recursos(x.pathname))
        .map(x => x.pathname);
    await cache.addAll(rutas);
    await cache.put(inicio, pagina);
    await self.skipWaiting();
})()));

self.addEventListener('activate', event => event.waitUntil((async () => {
    await Promise.all((await caches.keys()).filter(clave => clave.startsWith('timon-app-') && clave !== cacheApp)
        .map(clave => caches.delete(clave)));
    await self.clients.claim();
})()));

self.addEventListener('fetch', event => {
    const ruta = new URL(event.request.url);
    if (ruta.origin !== self.location.origin || event.request.method !== 'GET') return;
    if (ruta.pathname === '/app/' && event.request.mode === 'navigate') {
        event.respondWith(fetch(event.request).then(async respuesta => {
            if (respuesta.ok) {
                const cache = await caches.open(cacheApp);
                await cache.put(inicio, respuesta.clone());
            }
            return respuesta;
        }).catch(() => caches.match(inicio)));
    } else if (recursos(ruta.pathname)) {
        event.respondWith(caches.match(event.request).then(enCache => enCache || fetch(event.request).then(async respuesta => {
            if (respuesta.ok) {
                const cache = await caches.open(cacheApp);
                await cache.put(event.request, respuesta.clone());
            }
            return respuesta;
        })));
    }
});
