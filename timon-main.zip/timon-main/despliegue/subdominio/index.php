<?php

declare(strict_types=1);

/**
 * Punto de entrada para un hosting cuya raíz pública no se puede cambiar.
 *
 * El código vive en `.app/`, protegido por las reglas del servidor. El punto
 * de entrada canónico conserva su ubicación relativa dentro de esa carpeta,
 * así que la aplicación sigue resolviendo su raíz sin rutas especiales.
 */

require __DIR__ . '/.app/publico/index.php';
