# Instalación de prueba en Synology

Estado: preparada para reconocimiento e instalación; aún no se ha probado en DSM. No se conoce el modelo ni si admite Container Manager. El sitio que ya existe en `/vertice-pos/` conserva sus carpetas, base y host virtual. Timón necesita un host virtual independiente y vive en la raíz de ese host.

## Reconocimiento sin cambios

Con SSH por llave, ejecute `sh despliegue/synology/reconoce.sh`. En DSM revise además modelo, paquetes Web Station, PHP 8.2 o posterior, MariaDB 10 y Container Manager. No envíe archivos de configuración con claves. La ausencia de Docker en PATH no prueba que no esté instalado: compruébelo en el Centro de paquetes. PHP 8.3 continúa siendo el estándar del central y de desarrollo; PHP 8.2 se admite para este perfil de Web Station ya comprobado y debe actualizarse cuando el NAS lo permita.

Si hay Container Manager, use la [instalación Docker](../../docs/servidor-sucursal.md#instalación) con puertos exclusivos que no estén ocupados por DSM u otros sitios. No reutilice 5001, que suele atender DSM. Ajuste los puertos del servicio web en una copia de `compose.yaml`, y la URL pública de Timón para que coincidan. La actualización no necesita Tailscale: solo salida HTTPS hacia staging.

## Sin Container Manager

1. Cree una carpeta independiente, por ejemplo `/volume1/timon`, escribible únicamente por la cuenta que ejecutará PHP y las tareas de Timón. Cree `compartido/config`, `compartido/almacenamiento` y `compartido/descargas`. No la sitúe dentro de la carpeta pública de otro sistema.
2. Un administrador de DSM crea una base vacía y un usuario MariaDB propio de Timón. El usuario recibe permisos sobre esa base, incluidos crear tablas, migraciones y disparadores. La aplicación no usa root.
3. Copie a `compartido/config/` los ejemplos `app`, `bd`, `seguridad`, `respaldo`, `alertas` e `instalacion` del paquete y complete los valores en el servidor. La instalación usa tipo `sucursal`, el registro de **staging**, su desplazamiento y su secreto. La llave TOTP debe corresponder al central de staging. El respaldo tiene su propia llave. Configure `registros` con una ruta absoluta a `compartido/almacenamiento/registros` y `url_publica` con el host/puerto de Timón.
4. Verifique las extensiones con `reconoce.sh`. El PHP CLI del programador debe ser el mismo PHP 8.2 o posterior del perfil de Web Station. Debe permitir `proc_open`, Phar y enlaces simbólicos. No desactive la verificación de certificados. Si usa una CA local, configure `salud_ca` con la ruta del certificado público en `instalacion.php`.
5. Transfiera el paquete firmado, su `.firma.json` y una copia confiable de la llave pública por un canal independiente. Compare esa llave con `config/firma-liberaciones.pub` del paquete antes de ejecutar su código. Extraiga la primera copia en una carpeta temporal y, usando el binario PHP encontrado, ejecute desde ella:

   ```bash
   /ruta/al/php guiones/actualiza.php --instala=/ruta/timon-version.tar.gz --firma=/ruta/timon-version.firma.json --base=/volume1/timon --sin-base
   ```

6. Genere el esquema **para la base nueva vacía** con `actual/guiones/genera-sql-despliegue.php`, impórtelo con el usuario propio y ejecute `actual/guiones/migraciones.php` para comprobarlo, seguido de `actual/guiones/disparadores-replica.php`. No importe el esquema completo sobre una base existente.
7. Cree en Web Station un portal/host virtual exclusivo con raíz `/volume1/timon/actual/publico`, perfil PHP 8.2 o posterior y HTTPS. Configure el enrutamiento a `index.php` (Apache con `.htaccess`) y un alias `/app` hacia `/volume1/timon/actual/app/dist`. El PHP debe permitir los enlaces hacia `compartido`; con `open_basedir` incluya la carpeta raíz de Timón. No publique `compartido`, `liberaciones`, configuración ni respaldos.
8. La recarga automática de Apache del paquete Docker no existe en Web Station. Para admitir actualizaciones automáticas sin privilegios de administración, configure el perfil PHP de este host con `opcache.validate_timestamps=1`, `opcache.revalidate_freq=0` y `realpath_cache_ttl=0`; el enrutamiento debe resolver `actual` en cada petición. Verifique N → N+1 por HTTP antes de usarlo: si DSM fija la ruta física anterior, la comprobación de salud fallará y se regresará a N. En ese caso mantenga las actualizaciones sin asignar hasta configurar un mecanismo de recarga exclusivo para este portal.
9. En el Programador de tareas de DSM, con la cuenta propia de Timón, configure rutas absolutas:

   ```bash
   # Cada minuto (un ciclo de réplica; no deje un proceso permanente en el programador).
   /ruta/al/php /volume1/timon/actual/guiones/sincroniza.php --una-vez
   # Cada 15 minutos.
   /ruta/al/php /volume1/timon/actual/guiones/actualiza.php
   # Una vez al día, a las 04:00, zona America/Mexico_City.
   /ruta/al/php /volume1/timon/actual/guiones/tarea.php respaldo --cifrar
   /ruta/al/php /volume1/timon/actual/guiones/tarea.php mantenimiento
   ```

   Sustituya `/ruta/al/php` por la ruta absoluta del mismo perfil de Web Station. Evite ciclos de réplica solapados y revise las salidas de las tareas. Mantenga la pantalla de Operación local en staging bajo observación.

10. Instale la CA en los equipos del piloto y siga la [lista de comprobación](../../docs/servidor-sucursal.md#comprobación-del-piloto). La prueba remota y la compatibilidad de Web Station quedan pendientes hasta contar con acceso.
