#!/bin/sh
# Solo lectura. No examina contraseñas, configuración de otros sitios ni bases.
set -u
printf 'Sistema: '; uname -srm
if [ -r /etc.defaults/VERSION ]; then
  sed -n '/^\(majorversion\|minorversion\|productversion\|buildnumber\)=/p' /etc.defaults/VERSION
fi
if command -v docker >/dev/null 2>&1; then
  docker --version
  docker compose version 2>/dev/null || true
else
  printf 'Container Manager/Docker: no está en PATH\n'
fi
for php in \
  /usr/local/bin/php83 \
  /var/packages/PHP8.3/target/usr/local/bin/php83 \
  /usr/local/bin/php82 \
  /var/packages/PHP8.2/target/usr/local/bin/php82; do
  if [ -x "$php" ]; then
    "$php" -r 'echo "PHP ", PHP_VERSION, " · ", PHP_BINARY, PHP_EOL; foreach (["mysqli","sodium","curl","phar","zlib","mbstring","bcmath","gd","zip"] as $e) echo $e, ": ", extension_loaded($e)?"sí":"falta", PHP_EOL;'
    break
  fi
done
for mysql in /usr/local/mariadb10/bin/mysql /var/packages/MariaDB10/target/usr/local/mariadb10/bin/mysql; do
  if [ -x "$mysql" ]; then "$mysql" --version; break; fi
done
