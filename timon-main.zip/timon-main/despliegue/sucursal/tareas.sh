#!/bin/sh
# El cron de la computadora de sucursal:
#   · cada 15 minutos, el actualizador (guiones/actualiza.php);
#   · una vez al día, a las 4 de la mañana, respaldo cifrado y mantenimiento
#     (que aquí no sella la bitácora).
# Si el actualizador instaló otra versión, sale: Docker lo vuelve a levantar
# con el código nuevo.
set -u
raiz=/srv/timon/actual
version=$(readlink "$raiz")
ultimo=""
vuelta=0
while true; do
  if [ $((vuelta % 3)) -eq 0 ]; then
    php "$raiz/guiones/actualiza.php"
  fi
  [ "$(readlink "$raiz")" != "$version" ] && exit 0
  hoy=$(date +%F)
  if [ "$(date +%H)" = "04" ] && [ "$ultimo" != "$hoy" ]; then
    php "$raiz/guiones/tarea.php" respaldo --cifrar
    php "$raiz/guiones/tarea.php" mantenimiento
    ultimo="$hoy"
  fi
  vuelta=$((vuelta + 1))
  sleep 300
done
