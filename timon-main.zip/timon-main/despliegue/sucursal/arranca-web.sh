#!/bin/sh
# Apache en primer plano y, a un lado, quien lo recarga cuando el actualizador
# deja la señal compartido/recarga: los procesos nuevos ya leen la versión a la
# que apunta `actual`, sin cortar las peticiones en curso.
set -u
senal=/srv/timon/compartido/recarga
(
  visto=$(cat "$senal" 2>/dev/null || echo "")
  while sleep 5; do
    ahora=$(cat "$senal" 2>/dev/null || echo "")
    if [ -n "$ahora" ] && [ "$ahora" != "$visto" ]; then
      apachectl -k graceful
      visto="$ahora"
    fi
  done
) &
exec apache2-foreground
