# El Timón

Sistema de comanda para El Timón, restaurante de mariscos con varias sucursales.

- **Panel** (`/panel`) con sucursales, planos, catálogo, equipos, reservaciones, inventario, compras, gastos y reportes.
- **Comanda** (`/app/`) en Expo para Android, iPad y web instalable, con operación de mesas, cocina, caja e impresión térmica.
- **Sitio público** (`/`) y menú QR por sucursal (`/menu/{sucursal}`).

La identidad aprobada es [Timón y ola con la paleta Peltre](marca/marca.md). El sistema también es la [plantilla](docs/plantilla.md) para otros negocios.

## Arquitectura

PHP 8.3 sin framework y MariaDB, pensado para hospedaje compartido (Hostinger). Un solo subdominio sirve la landing en `/`, el panel en `/panel`, la app web en `/app` y la API en `/api/v1`. La app consulta eventos por sucursal cada pocos segundos. El detalle está en el [plan](docs/plan.md).

```
nucleo/        router, base de datos, sesión, seguridad, exportaciones
controladores/ Web (panel) y Api (app)
servicios/     reglas de negocio
modelos/       acceso a tablas que comparten varios servicios
dominio/       valores sin base de datos: dinero, impuestos, TOTP, QR
vistas/        plantillas PHP del panel
esquema/       DDL en guiones numerados
guiones/       herramientas de línea de comandos
pruebas/       unitarias y de humo
```

## Arrancar en local

Requisitos: PHP 8.3 y MariaDB 10.11 de Homebrew, y Node 24 para las herramientas.

1. Crear las bases `timon` y `timon_pruebas`, cada una con su usuario, y su configuración en `config/` a partir de los `*.ejemplo` (`app`, `bd`, `seguridad`, `respaldo` y `alertas`, con su variante `.pruebas`, y `giro`, que enciende los módulos). Las llaves se generan con `guiones/genera-clave-seguridad.php` y `guiones/genera-llave-respaldo.php`. Ningún `config/*.php` entra a Git.
2. Para una base local existente, ejecute `php guiones/migraciones.php --estado` y aplique los cambios pendientes con `--aplicar --acepto=timon`. Para una base nueva, cargue el esquema consolidado:

   ```bash
   /opt/homebrew/opt/php@8.3/bin/php guiones/aplica-esquema.php --acepto=timon
   ```

3. Dar de alta al administrador (pide la contraseña sin mostrarla):

   ```bash
   /opt/homebrew/opt/php@8.3/bin/php guiones/crear-usuario.php
   ```

4. Levantar el panel en http://127.0.0.1:8080:

   ```bash
   guiones/servidor-local.sh
   ```

## App local

```bash
npm --prefix app ci
npm --prefix app run tipos
npm --prefix app run web
```

Abra [la PWA local](http://127.0.0.1:8080/app/). Registre el equipo, autorícelo en **Equipos de comanda** y configure el PIN desde **Mi perfil**. Para dispositivos nativos y publicación, siga el [runbook de salida](docs/salida.md).

## Pruebas

```bash
guiones/servidor-pruebas.sh
```

```bash
pruebas/todo.sh
```

`todo.sh` reconstruye `timon_pruebas` y corre las unitarias, las de humo contra el 8081, el respaldo, el mantenimiento y los paquetes de despliegue. ⚠️ **Nunca contra producción.**

Si la base cotidiana todavía está en un esquema anterior, ejecute `PB_ESQUEMA_AISLADO=1 pruebas/todo.sh`. El resto de la suite se ejecuta con normalidad. Use `guiones/migraciones.php --estado` para auditar por separado las migraciones cotidianas pendientes.
