# Iniciar otro negocio

1. Copie el código a un repositorio y a una instalación propios. Excluya los archivos que ignora Git, los respaldos, los registros, las fotos privadas y las bases de El Timón.
2. Edite `marca/tokens.json`, la geometría del símbolo en `guiones/genera-marca.mjs` y las aplicaciones de la marca. Ejecute `node guiones/genera-marca.mjs`. Para actualizar los iconos en macOS, convierta `marca/icono-cuadrado.svg` a `app/assets/icono.png` con `sips -s format png` y genere las variantes de 192 y 512 px de `app/public/` con `sips -Z`.
3. Configure `config/giro.php`. Use `restaurante = false` para iniciar con la capa base. Use `sitio_publico = false` para operar el restaurante internamente mientras prepara la web. En una copia nueva se pueden separar las migraciones de giro antes de instalar. Después de instalar, conserve el historial y haga cualquier cambio con migraciones nuevas.
4. Prepare sus bases vacías y los archivos de entorno a partir de la configuración de ejemplo. Fije el dominio canónico, la razón social y una zona horaria. Genere llaves y usuarios nuevos. Cree sucursales, dé de alta sus empleados y configure permisos y equipos.
5. Para una app independiente, cambie nombre, slug, scheme, identificadores iOS y Android e iconos en `app/app.json`. Vincule el repositorio de esa instalación a su proyecto EAS.
6. Verifique en una base aislada y genere el paquete de su instalación con el [runbook de salida](../salida.md).

El [mapa de la plantilla](../plantilla.md) localiza la capa común, las tablas de giro y las rutas.
