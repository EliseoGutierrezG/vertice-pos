# Guía de construcción del panel de El Timón

La [homologación de El Timón](homologacion-timon.md) contiene la guía de construcción, las fichas por ruta y la lista de cierre. Para cambiar una pantalla, partir de su ficha, revisar el permiso del GET y de cada escritura, y comprobar los datos consultados y guardados.

## Pantalla y menú

- El título visible y la pestaña usan el nombre de [la entrada del menú](../vistas/plantilla/menu.php). El menú y los accesos de Tablero comparten esa definición y filtran por permisos.
- El orden de lectura es encabezado, filtros, indicadores, conteo, avisos y tabla. Tablero y Plano del salón tienen su propia estructura.
- Usar `pb_modulo()`, `pb_seccion()` y las [piezas de la plantilla](../vistas/partes/piezas.php). La acción principal del módulo lleva el estilo primario. «Exportar XLS» usa contorno.
- La tabla principal presenta Acción primero, con Ver, Actualizar y las transiciones permitidas. Mostrar estados con texto mediante `pb_estatus()` o `pb_insignia()` e importes con `pb_dinero()`.
- Señalar título, insignia y acciones para que las tarjetas debajo de 768 px ofrezcan los mismos datos y controles. Verificar el foco visible y objetivos táctiles de 44 px.

## Filtros y descargas

- Elegir filtros con sentido para la ficha. Buscar aplica la consulta y Limpiar filtro recupera los valores iniciales. El rango permite captura directa y atajos.
- Precisar el total filtrado, el tamaño de página y el orden. Compras, Kardex, Gastos y Bitácora paginan en servidor con 25 filas iniciales y hasta 100.
- El listado y XLS comparten el alcance de sucursal, los filtros aplicados y el orden. La descarga lleva todas las filas filtradas con fechas, importes y cantidades del tipo correspondiente. Usar `pb_exportar()` con los filtros normalizados.

## Fichas y escrituras

- Ver es de solo lectura. Ver y Actualizar piden los datos actuales al servidor, con `pb_detalle()` y `fichaEnModal()` o la precarga de `pb_accion_modal()`.
- Cada acción respeta el permiso, la sucursal y el estado del registro. Los errores de captura se muestran junto al campo. Al cerrar el modal se recupera el foco. Tras guardar se conserva el contexto del listado.
- Una transición como recibir una compra, confirmar una reserva o retirar un equipo conserva su transacción, validación e historial. Los reintentos se validan mediante el patrón de envío único cuando corresponde.

## Evidencia

Usar el entorno local de pruebas. Registrar ruta, versión, perfil, ancho, fecha, resultado y evidencia. Comprobar 1440, 768 y 375 px con los puestos que usan la ficha, además del acceso directo, los filtros, las tarjetas y las descargas. Cuando una pantalla comparte datos con comanda, caja, cocina, carta QR o tickets, verificar también ese flujo.

Consultar la [guía de textos](textos/guia-de-textos.md), los [tokens de Peltre](../marca/tokens.json) y el [procedimiento de pruebas del plan](plan.md).
