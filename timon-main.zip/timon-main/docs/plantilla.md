# La plantilla: capa base y capa de giro

El Timón es el primer negocio construido sobre esta base, y no el último. Por eso el código se separa en dos capas, y cada archivo nuevo sabe a cuál pertenece.

## Capa base

Lo que cualquier negocio con sucursales necesita, sin importar qué venda. Viene de Distribuidora, con los nombres neutros de la plantilla.

| Pieza | Dónde |
|---|---|
| Núcleo: router, contenedor, base de datos, sesión, CSRF, errores, exportaciones (CSV, XLSX y PDF) | `nucleo/` |
| Seguridad: permisos que fallan cerrados, segundo factor, bitácora sellada, revisión de accesos, envío único | `nucleo/Middleware/`, `servicios/Seguridad.php`, `servicios/SegundoFactor.php` |
| Sucursales, personal, usuarios, puestos y permisos | `servicios/Organizacion.php`, `servicios/Personal.php`, `esquema/002`–`003` |
| Equipos (dispositivos) y avisos push | `modelos/Dispositivos.php`, `servicios/Notificaciones.php` |
| Privacidad: aviso, solicitudes ARCO y anonimización | `servicios/DerechosTitular.php`, `esquema/005` |
| Marca visual por instalación | `servicios/MarcaVisual.php`, `config/marca-visual.php` |
| Piezas de pantalla `pb_*` y el armazón del panel | `vistas/partes/piezas.php`, `vistas/plantilla/` |
| Herramientas: esquema, migraciones, respaldo cifrado, mantenimiento, despliegue | `guiones/` |

Caja, inventario, compras y gastos usan datos por sucursal. La coordinación con comandas y recetas vive en los servicios del restaurante. Consulte el [paso a paso para reutilizar la aplicación](plantilla/nuevo-negocio.md).

## Capa de giro restaurante

Lo que solo tiene sentido en un restaurante: áreas y mesas con su plano, comandas con rondas y tiempos, cocina y barra (pantalla y papel), menú con modificadores, para llevar y domicilio, reservaciones y menú QR. El detalle está en el [plan](plan.md).

## Reglas para que la separación aguante

- **Lo de la base no conoce al giro.** Un servicio de la base nunca consulta una tabla del giro. Cuando la base necesita saber algo del giro (por ejemplo, si una sucursal tiene cuentas abiertas antes de darla de baja), el giro lo registra como impedimento.
- **Los nombres de la base son neutros**: `pb_` en las piezas, `tema.css`, `plantilla.js`, `APP_ENTORNO`. Nada de «Timón» en la capa base fuera de la configuración y la marca.
- **El esquema numera las dos capas en una sola serie.** El comentario de cabecera de cada guion dice a qué capa pertenece.

## Un negocio nuevo

Siga [Iniciar otro negocio](plantilla/nuevo-negocio.md) para generar su marca, elegir el giro y configurar su instalación.
