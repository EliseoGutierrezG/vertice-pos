# Computadora de sucursal: operar sin internet

Si se cae el internet del restaurante, la comanda no se detiene. Cada sucursal puede tener **su propia computadora** con el mismo sistema. Tabletas, cocina, impresoras y caja trabajan contra ella por el WiFi del local, que sigue funcionando sin internet. Cuando vuelve la conexión, esa computadora sube al central (Hostinger) lo que pasó y baja lo que cambió en el catálogo.

En el panel, la pantalla se llama **Operación local** (`/servidores`, permiso `servidor_admin`). En el código, a esa computadora se le dice «servidor de sucursal» o «instalación».

## Quién es dueño de qué

| Lo escribe | Qué |
|---|---|
| **El central** | Menú, precios, promociones, personal, puestos, plano de mesas, impresoras, horarios, parámetros, sitio público, menú QR, solicitudes de reservación y el sello de la bitácora |
| **La computadora de la sucursal** | Cuentas, rondas, cobros, turnos y cortes, impresión, inventario, gastos, estado de las mesas, agotados, reservaciones ya recibidas, equipos de comanda y su bitácora |

Mientras una sucursal está en `local` (columna `sucursal.servidor`), el central **rechaza** cualquier escritura de su operación con un 409 («Esta sucursal opera en su computadora. Hágalo desde ahí.»). En la computadora de la sucursal pasa lo contrario: el catálogo no se cambia («Esto se cambia en el panel central.») y el panel solo deja escribir lo operativo (`nucleo/Middleware/ExigeEscrituraDeSucursal.php`).

## Cómo se sincroniza

- **Ids sin choques.** Cada conexión fija `auto_increment_increment = 100`. El central usa el desplazamiento 1 y cada sucursal el suyo, de 2 a 99 (`config/instalacion.php`). Una fila tiene el mismo id en las dos bases.
- **Bajada** (cada 60 s, `GET /api/v1/replica/catalogo`): el central manda el catálogo de la sucursal completo con su huella. Si la huella no cambió, no manda nada. La sucursal conserva sus columnas operativas: el `estado` de la mesa, el `agotado` del platillo y el último periodo del segundo factor.
- **Subida** (cada 15 s, `POST /api/v1/replica/subida`): unos disparadores de MariaDB, que solo existen en la sucursal (`guiones/disparadores-replica.php`), anotan cada cambio en `cambio_replica` dentro de la misma transacción. `guiones/sincroniza.php` manda la foto de cada fila en lotes de hasta 500, con los padres antes que los hijos aunque se hayan anotado después: así un corte largo no atora la subida. El central las aplica en orden de llaves y revisa que cada una sea de esa sucursal. El lote es idempotente: si se repite, no duplica nada.
- **Bitácora.** Al subir, cada apunte recibe un id nuevo del central, que es quien la sella. El origen queda en `origen_instalacion` y `origen_id`. La computadora de la sucursal no sella.
- **Folios.** El ticket ya es consecutivo por sucursal. Las reservaciones tomadas en la sucursal usan su propia serie, `RES-<clave>-000001`.
- **Arranque.** La primera vez, además del catálogo, baja lo vivo de la sucursal: inventario, reservaciones futuras, estado de las mesas, agotados y series de folio. Solo se hace en una base sin cuentas.

## Lo que necesita el restaurante

- Una computadora encendida todo el día: mini PC con Linux, o la PC de caja con Docker Desktop.
- **IP fija** para esa computadora, reservada en el módem.
- **No-break** para la computadora, el módem o WiFi y las impresoras.
- La hora automática activada.

## Instalación

1. **En el central**, una sola vez: `config/instalacion.php` con `return ['tipo' => 'central'];`.
2. Cierre las cuentas y el turno de caja de la sucursal.
3. En el panel central, **Operación local → Registrar computadora**. El aviso muestra **una sola vez** el número (desplazamiento) y la llave. Anótelos: el central solo guarda el SHA-256 de la llave.
4. En la computadora de la sucursal, con Docker, openssl, el código y la PWA compilada (`npm --prefix app run web`):

   ```bash
   bash guiones/instala-sucursal.sh /ruta/timon-version.tar.gz /ruta/timon-version.firma.json
   ```

   El guion pide la IP, la dirección del central, el número de sucursal, el número y la llave del registro, y la `llave_totp` de `config/seguridad.php` del central. Las llaves se leen sin mostrarse. Después:
   - deja la configuración en `despliegue/sucursal/local/config/`, fuera de Git;
   - crea la autoridad de certificados y un certificado para la IP, válido por 825 días;
   - arma la imagen, crea la base y los disparadores, y arranca `web`, `sincroniza` y `tareas` (respaldo cifrado y mantenimiento a las 4 a. m.).
5. **Confiar en la autoridad**, una vez por equipo, desde `http://<IP>/ca.crt`:
   - **Android**: Ajustes → Seguridad → Cifrado y credenciales → Instalar certificado → Certificado de CA. La app de release ya confía en las autoridades del usuario (`app/plugins/autoridad-local.js`).
   - **Windows**: abrir `ca.crt` → Instalar certificado → Equipo local → «Entidades de certificación raíz de confianza».
   - **iPad**: abrir el enlace en Safari, instalar el perfil y activarlo en Ajustes → General → Información → Ajustes de confianza de certificados.
6. **Equipos**: en la app, dar de alta el equipo con la dirección de la computadora (`192.168.1.50`) y aprobarlo en `https://<IP>/equipos-comanda`. En las PC se abre la PWA en `https://<IP>/app`.

Guarde fuera de esa computadora la carpeta `despliegue/sucursal/local/autoridad/`, con la llave de la autoridad, y la llave de respaldo.

La instalación usa `local/raiz/liberaciones/<id>`, el enlace `local/raiz/actual` y `local/raiz/compartido` para configuración, descargas y datos. La imagen Docker solo contiene Apache/PHP; el código se monta desde esa raíz. Para Synology, consulte el [reconocimiento y alternativa Web Station](../despliegue/synology/README.md). Esa alternativa requiere comprobar el modelo y sus paquetes; no se ha instalado todavía en DSM.

## Actualizaciones

El administrador asigna una versión a cada computadora desde **Operación local**. La computadora consulta cada 15 minutos y descarga por HTTPS hacia fuera; no necesita puertos entrantes ni VPN. Una caída de internet conserva la versión actual. El paquete y su descriptor se verifican con SHA-256 y Ed25519 usando la llave pública que la sucursal ya tiene.

### Preparar y asignar una versión

1. En la máquina de empaquetado, genere una sola vez el par de firma con `php guiones/genera-llave-firma.php`. La pública queda en `config/firma-liberaciones.pub`; la privada queda fuera del repositorio, por omisión en `~/.timon/firma-liberaciones.llave`, con permisos 0600. Guarde una copia privada fuera de esta Mac. No suba la privada al central. La primera instalación debe recibir la pública por un canal confiable independiente del paquete descargado.
2. Ejecute las pruebas locales, `npm --prefix app run tipos` y `npm --prefix app run web`. Después:

   ```bash
   bash guiones/prepara-liberacion-sucursal.sh /ruta/salida
   # Opcional: binario firmado Android y versión mínima compatible.
   bash guiones/prepara-liberacion-sucursal.sh /ruta/salida /ruta/comanda-firmada.apk 1.0.0
   ```

   El APK debe ser del mismo proyecto, versión de `app/app.json` y certificado Android que los instalados. Para actualizar una instalación de Google Play con el APK propio, la firma debe coincidir con la llave de firma de Play; la llave de subida de Play puede ser distinta. Compruébelo en un equipo piloto antes de mezclar ambas vías. El script no firma el APK ni valida sus credenciales de tienda: empaca el binario ya firmado dentro de la liberación firmada.
3. Actualice primero el **central de staging** mediante las migraciones incrementales, incluida `026_liberaciones.sql`, su código y la llave pública. Los empaquetadores del central y de sucursal comparten la lista de código y guiones. La privada de firma no viaja. Las migraciones de una actualización automática deben ser compatibles con el código anterior: agregar tablas/columnas con valores por omisión y conservar los contratos anteriores. Cambios destructivos requieren un procedimiento asistido y no deben asignarse al actualizador automático.
4. Suba `.tar.gz` y `.firma.json` en **Operación local → Subir versión**. Si exceden el límite de subida de PHP, cópielos fuera de la raíz pública y registre con `php guiones/registra-liberacion.php PAQUETE.tar.gz PAQUETE.firma.json "Notas"`. El central vuelve a verificar la firma. Asigne primero una sola computadora piloto; asignar vacío conserva su versión.
5. Compruebe **Versión**, **Va a** y el estado de actualización en Operación local antes de asignarla al resto. Los paquetes se guardan fuera de `publico/`; su descarga exige la llave de instalación y solo permite la versión asignada, con `Range` para reanudar.

### Qué hace la computadora

- Descarga y verifica antes de instalar. Si falla la integridad, descarta el archivo. Evita ciclos simultáneos de descarga, réplica e instalación.
- Espera a que no haya **ninguna cuenta ni turno de caja abiertos**. Además exige entre las 03:00 y las 05:00 (fin exclusivo), o 30 minutos sin apuntes de operación. La zona es `America/Mexico_City`.
- Toma un candado exclusivo que deja terminar las peticiones y la réplica en curso; si alguna sigue trabajando, espera al próximo ciclo. Las peticiones nuevas reciben un conflicto reintentable. Revisa otra vez el cierre antes de respaldar.
- Genera y verifica un respaldo cifrado, extrae la liberación, enlaza configuración/datos compartidos, aplica migraciones incrementales y rehace disparadores. Mueve `actual` de forma atómica y pide recargar Apache.
- Comprueba por HTTP(S) `/api/v1/salud`: base viva, esquema e id nuevo. Con certificado de CA local usa `salud_ca`; nunca desactiva TLS. Si no confirma la salud, devuelve `actual` a la versión anterior y vuelve a pedir recarga. Las últimas tres versiones se conservan. El regreso cambia el código; no deshace migraciones ni restaura la base automáticamente.

Mientras el esquema de la sucursal sea anterior al del catálogo central, sigue subiendo su operación y avisa **Esperando actualización**; la bajada y la huella se retoman cuando el esquema alcanza al central. La PWA viaja en `app/dist`, identifica su caché con el hash de la exportación y usa la red al recargar. El aviso de actualización permite terminar la captura antes de recargar.

Cambiar la imagen de PHP o las extensiones se hace excepcionalmente con acceso de mantenimiento. No lo intenta el actualizador del código.

## Comprobación del piloto

La prueba automatizada local es `TZ=America/Mexico_City python3 pruebas/humo-sucursal.py`. Usa bases aisladas, dos servidores HTTP locales y llaves de firma efímeras. Comprueba operación sin central, réplica con esquema atrasado, descarga autenticada/reanudable, espera con cuenta abierta, instalación N → N+1, respaldo cifrado, descarga local de un APK ficticio y regreso al fallar salud. El APK ficticio nunca se instala.

La aceptación en el equipo real queda pendiente de acceso:

1. Reconocer sistema y paquetes, sin tocar `/vertice-pos/`, y elegir Docker o Web Station.
2. Registrar la sucursal contra staging; instalar su certificado y un APK real de staging en un equipo físico.
3. Cortar internet, operar una venta de prueba y reconectar; comprobar que sube una sola vez.
4. Asignar N+1, mantener una cuenta abierta, cerrarla y esperar la ventana segura; verificar id por salud web y reporte central.
5. Ensayar una versión defectuosa controlada y confirmar la salud de la anterior después del regreso.
6. Publicar una actualización EAS al canal staging y comprobar recepción en la tableta; revisar por separado Google Play y TestFlight/App Store con las cuentas del negocio.

## Comprobar que sincroniza

- `https://<IP>/api/v1/salud` trae `central.alcanzable` y `central.pendientes`.
- La app muestra «Sin internet: todo funciona. N cambios por subir.» mientras no alcanza al central.
- En el panel central, Operación local muestra la última subida, la última bajada, lo que falta por subir y la versión del código. Si pasan 30 minutos sin noticias, marca la fila **Sin noticias**. Si un lote no entra, marca **Con error** con el motivo y no se salta nada.
- En la computadora: `docker compose -f despliegue/sucursal/compose.yaml logs -f sincroniza`.

## Si la computadora de la sucursal falla

1. Si todavía enciende, espere a que **Por subir** llegue a 0.
2. En el panel central, **Operación local → Regresar al central**. Desde ahí, las tabletas se dan de alta otra vez contra el central.
3. Si se perdió con cambios sin subir, el regreso se fuerza (`aun_con_pendientes`). Lo que no subió solo está en su respaldo cifrado (`almacenamiento/respaldos/cifrados/`).

## Lo que no se vuelve offline

- El sitio público, el menú QR y el ticket por enlace viven en el central. El cliente los abre con sus datos. El ticket por enlace aparece cuando sube el pago; el impreso sale en el momento.
- Lo que se cambie en el catálogo durante un corte llega a la sucursal cuando vuelve la conexión.
- El central revisa que cada fila que sube sea de esa sucursal, pero no las referencias a otras filas (por ejemplo, el turno de un pago). Solo la computadora registrada puede subir. Si su llave se filtra, regrese la sucursal al central desde «Operación local» (la llave deja de servir) y registre la computadora otra vez.
