# Documentación

| Documento | Qué es |
|---|---|
| [Plan](plan.md) | Las fases 0 a 12, la arquitectura de la comanda y cómo se comprueba cada una |
| [La plantilla](plantilla.md) | Capa base contra capa de giro, y cómo se parte un negocio nuevo |
| [Guía de pantallas](guia-pantallas.md) | Cómo se arma una pantalla del panel. Se lee antes de tocar una |
| [Homologación del panel](homologacion-timon.md) | Auditoría, guía de construcción, 26 fichas y lista de cierre del panel web |
| [Guía de textos](textos/guia-de-textos.md) | Trato, largo y vocabulario de todo lo que se lee en pantalla |
| [Marca aprobada](../marca/marca.md) | Timón y ola con la paleta Peltre |
| [Iniciar otro negocio](plantilla/nuevo-negocio.md) | Instalación independiente, marca y giro |
| [Salida a Hostinger y EAS](salida.md) | Empaquetado, app nativa y piloto |
| [Operar sin internet](servidor-sucursal.md) | La computadora de cada sucursal: instalación, sincronización y qué hacer si falla |
| [Preparar Synology](../despliegue/synology/README.md) | Reconocimiento y preparación del piloto con Container Manager o Web Station |
| [Validación de actualizaciones](validacion-actualizaciones-2026-11-20.md) | Evidencia local, candidato firmado y pendientes del piloto remoto |
| [Staging en Hostinger](staging.md) | El sitio de pruebas `staging-timon.verticesoftware.com.mx`: alta, base, subida y comprobación |
| [Despliegue automático](ci-cd.md) | GitHub Actions → Hostinger por FTP: ramas, qué sube y qué sigue a mano |
| [Propuestas de marca](marca/propuestas.html) | Los tres logotipos y las tres paletas para elegir en la fase 1 |

El sistema visual heredado está en [`design-system/plantilla/MASTER.md`](../design-system/plantilla/MASTER.md). Las reglas de trabajo y el mapa del repositorio, en [`CLAUDE.md`](../CLAUDE.md).
