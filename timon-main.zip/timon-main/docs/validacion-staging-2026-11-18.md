# Validación del staging de Timón · 2026-11-18

Origen comprobado: `https://staging-timon.verticesoftware.com.mx`.
Plan de referencia: [staging.md](staging.md).

**Resultado técnico web:** las comprobaciones públicas pasan completas y el
panel, la venta y las reservaciones funcionan en staging. El dueño corrigió
`url_publica`: el sitemap habitual y el QR de S1 ya apuntan al origen de staging.
Se recibieron las salidas por SSH: PHP 8.3.36 con extensiones requeridas,
25 migraciones al día, entorno `produccion` y depuración desactivada.
Al probar la reservación autorizada se encontró además un fallo de confirmación:
se corrigió y comprobó en local, el dueño aplicó el parche por SSH y después
se verificó en staging el recorrido completo Solicitada → Confirmada → Cancelada.
El dueño conserva el acceso SSH/SFTP.

## Candidato instalado

- Liberación pública: `20261119T041159Z-f54e2f0105f7`.
- Esquema: 25; el descriptor SQL local declara 62 tablas y 25 guiones.
- La API confirma `base=viva` y coincide con el candidato conservado en
  `entregables/despliegue/app-subdominio-candidato.tar.gz`.
- La huella SHA-256 externa coincide. Los 200 archivos de controladores,
  dominio, modelos, núcleo, servicios, vistas y rutas del candidato coinciden
  con el código local en la revisión inicial. Después se corrigió
  `controladores/Web/Restaurante.php`; ese archivo ya difiere del candidato
  instalado. Se conserva el candidato original como evidencia y el parche
  incluye sus huellas anterior y posterior.

## Evidencia aprobada

| Comprobación | Resultado |
|---|---|
| Suite integral local aislada (`PB_ESQUEMA_AISLADO=1 pruebas/todo.sh`) | 503 pruebas PHP después de corregir la confirmación y todas las tandas en verde: migraciones, HTTP, concurrencia, réplica sin internet, seguridad, restauración, mantenimiento, paquetes y cierre local del host |
| TypeScript y exportación PWA | Pasan `npm --prefix app run tipos` y `npm --prefix app run web` |
| Exportación nativa | Android (677 módulos) e iOS (691 módulos), con el origen de staging; no constituye prueba de un APK o de un dispositivo |
| Compilaciones existentes en EAS | Dos Android `preview` terminadas; la última terminó el 18 de noviembre a las 22:24 (México), con el commit `3418328`, canal `preview`, versión 1.0.0 (1). No hay una compilación del perfil/canal `staging` ni una iOS en la lista consultada |
| Entorno de Expo Update | Se detectó que `EXPO_PUBLIC_API_URL` faltaba en proyecto y cuenta. Se creó únicamente esa variable pública en `preview` del proyecto y se confirmó por lectura que apunta a staging. No se publicó una OTA ni se inició un build |
| Compuerta HTTP del candidato instalado | 62 comprobaciones aprobadas |
| Validación ampliada pública | 41 comprobaciones aprobadas, sin fallas; incluye el sitemap habitual después de vencer la copia anterior del CDN |
| Host por SSH | El dueño aportó `verifica-host.php`: PHP 8.3.36 en CLI, todas las extensiones obligatorias y exif, host apto. `migraciones.php --estado`: 25 registradas y 25 disponibles, al día. Configuración: `produccion`, `depurar=false`, origen correcto y base nombrada como staging |
| QR de mesa | El QR de S1 enlaza a `https://staging-timon.verticesoftware.com.mx/menu/CEN?mesa=1`; se abrió en el navegador integrado y el menú muestra Mesa S1 |
| Cuentas de demostración | 23 cuentas, seis perfiles, dos sucursales: 334 comprobaciones aprobadas, sin fallas |
| Comanda y venta de demostración | 15 comprobaciones aprobadas; ticket `CEN-000001`, cuenta 2001, importe $210.00, cambio $20.00 |
| Navegador integrado | 25 pantallas del panel cargadas, fichas Ver y Actualizar de Áreas con datos del servidor; formulario cerrado sin guardar |
| Sitio móvil | Portada y menú a 375 px, sin desbordamiento horizontal; portada sin imágenes rotas ni errores de consola |
| Reservación pública | Autorizada expresamente por el dueño y enviada desde la landing: folio `RES-000001`, id 301, dos personas, 20 de noviembre a las 15:00. Después de aplicar el parche se confirmó en S1 y se canceló desde el panel, con ambos estados verificados en el navegador integrado |
| Corrección de confirmación | La regresión nueva falla antes del cambio (`confirmada` se vuelve `solicitada`) y pasa después. Las siete pruebas de reservaciones pasan; el navegador local completa Solicitada → Confirmada en R1 → Cancelada. Se retiraron la cuenta y la sucursal locales temporales y se restauró su parámetro de acceso |

Los permisos comprobados incluyen las rutas de plano, platillos, equipos,
turnos, inventario, personal, diagnóstico y servidores. El diagnóstico se
oculta con 404 porque staging usa el entorno `produccion`; consultar la otra
sucursal también devuelve 404. Los POST sin CSRF y los intentos de crear una
promoción sin permiso se rechazan.

La venta usa tres equipos nuevos. Dos intentan abrir la misma mesa al mismo
tiempo: reciben 201 y 409; la lectura del plano del segundo equipo refleja la
cuenta en **1.13 s** desde el inicio de la apertura. Es una medida de API, no
del sondeo visual de dos dispositivos físicos. Repetir una captura, envío y
cobro con la misma llave conserva un platillo, una ronda y un pago. Cocina
prepara, termina y despacha la ronda. Se revisan la precuenta, el conflicto de
versión del cobro, el ticket público y la disponibilidad de la cola de impresión.

Al terminar, la mesa queda libre y los tres equipos quedan **Retirados**;
sus tokens ya reciben 401. El ticket y la bitácora se conservan como evidencia
de la prueba autorizada. No se cierra el turno de demostración que ya estaba
abierto ni se consumen trabajos en una impresora física.

Registros:

- [Suite local](../entregables/validacion-staging-2026-11-18/suite-local.txt).
- [Publicación pública final](../entregables/validacion-staging-2026-11-18/publicacion-staging-final.txt),
  [sitemap verificado](../entregables/validacion-staging-2026-11-18/sitemap-verificado.xml)
  y [resultados de SSH aportados por el dueño](../entregables/validacion-staging-2026-11-18/hosting-ssh-verificado.txt).
- [Accesos y permisos](../entregables/validacion-staging-2026-11-18/cuentas-demostracion.txt).
- [Comanda en staging](../entregables/validacion-staging-2026-11-18/comanda-staging.txt).
- [Exportación nativa](../entregables/validacion-staging-2026-11-18/exportacion-nativa.txt).
- [Metadatos de compilaciones EAS](../entregables/validacion-staging-2026-11-18/compilaciones-eas.json), consultados sin iniciar builds ni publicar actualizaciones.
- [Variable pública de Expo verificada](../entregables/validacion-staging-2026-11-18/entorno-eas.txt).
- [Instrucciones y archivo para corregir la confirmación](../entregables/validacion-staging-2026-11-18/correccion-reservaciones/INSTRUCCIONES.md).
- [Archivo comprimido de la corrección](../entregables/validacion-staging-2026-11-18/correccion-reservaciones.tar.gz),
  [regresión antes del cambio](../entregables/validacion-staging-2026-11-18/reserva-regresion-antes.txt)
  y [regresión después del cambio](../entregables/validacion-staging-2026-11-18/reserva-regresion-despues.txt).
- [Solicitud recibida en staging](../entregables/validacion-staging-2026-11-18/reservacion-solicitada.jpg),
  [error al confirmar en staging](../entregables/validacion-staging-2026-11-18/reservacion-error-confirmacion.jpg),
  [confirmación local corregida](../entregables/validacion-staging-2026-11-18/reservacion-confirmada-local.jpg)
  y [cancelación local](../entregables/validacion-staging-2026-11-18/reservacion-cancelada-local.jpg).
- [Confirmación corregida en staging](../entregables/validacion-staging-2026-11-18/reservacion-confirmada-staging.jpg),
  [estado final cancelado en staging](../entregables/validacion-staging-2026-11-18/reservacion-cancelada-staging.jpg)
  y [registro del cierre de la reservación](../entregables/validacion-staging-2026-11-18/reservacion-staging.txt).
- [Menú móvil](../entregables/validacion-staging-2026-11-18/timon-staging-menu-movil.jpg),
  [portada móvil](../entregables/validacion-staging-2026-11-18/timon-staging-portada-movil.jpg)
  y [QR antes del ajuste](../entregables/validacion-staging-2026-11-18/timon-staging-qr-antes.jpg).
- [QR corregido y comprobado](../entregables/validacion-staging-2026-11-18/timon-staging-qr-corregido.jpg).
- [Candidato consolidado para la próxima actualización](../entregables/validacion-staging-2026-11-18/candidato-actualizado/app-subdominio-candidato.tar.gz),
  [su SHA-256](../entregables/validacion-staging-2026-11-18/candidato-actualizado/app-subdominio-candidato.tar.gz.sha256)
  y [manifiesto verificado](../entregables/validacion-staging-2026-11-18/candidato-actualizado/manifiesto-verificado.txt).
  Incluye el controlador corregido, la PWA y el origen absoluto de staging;
  liberación `20261119T053729Z-1ad9ca0e257a`, esquema 25. Los 378 archivos del
  manifiesto y la huella del archivo pasan. Está preparado localmente; el
  staging continúa con su liberación original más el parche puntual.

## Correcciones de la validación

- Las rutas privadas admiten 403 o 404: Hostinger puede negarlas antes del
  enrutador. Ninguna de las dos respuestas expone el contenido.
- El humo reconoce el bloqueo global de robots de staging además del bloqueo
  de `/panel` de producción.
- La guía compara tablas contra el descriptor del mismo SQL, verifica el
  SHA-256 antes de extraer y genera direcciones públicas absolutas.
- La guía de Expo Update usa el entorno `preview` explícito con el canal
  `staging`, conforme a [Expo SDK 55 y posteriores](https://docs.expo.dev/eas/environment-variables/usage/).
- Los PNG del CDN se comparan por dimensiones y píxeles: ambos iconos tienen
  la misma imagen que el candidato aunque el CDN cambie su compresión.

## Ajuste del origen público

Desde SSH, en la carpeta exclusiva del staging:

```bash
cd ~/domains/staging-timon.verticesoftware.com.mx/public_html
cp -p .app/config/app.php .app/config/app.php.antes-url-staging
nano .app/config/app.php
```

Cambiar solo esta entrada, conservando el resto de la configuración:

```php
'url_publica' => 'https://staging-timon.verticesoftware.com.mx',
```

Comprobar después:

```bash
php -l .app/config/app.php
curl -fsS https://staging-timon.verticesoftware.com.mx/sitemap.xml
```

Reabrir un QR de mesa y comprobar que su enlace use el mismo origen.
Si el sitemap se quedó guardado en CDN, purgar su caché desde hPanel.
Finalmente repetir `python3 pruebas/staging.py` con el mismo candidato.

**Comprobado después del ajuste:** el QR ya usaba el origen correcto, pero
el CDN conservaba el sitemap anterior (`Age: 3510`, `max-age=3600`). Una
solicitud nueva devolvía el origen correcto. Al vencer esa copia, la URL
habitual también quedó correcta y la validación completa pasó con 62 + 41
comprobaciones. No se cambió el verificador para aceptar una respuesta obsoleta.

## Corrección de la confirmación de reservaciones

La solicitud pública autorizada se creó correctamente como `RES-000001`
(id 301). Al confirmar desde el panel se obtuvo un 422: `verReserva()`
devolvía el estado actual en `registro`, y la precarga genérica del modal
reemplazaba el destino fijo `confirmada` por `solicitada`.

La corrección devuelve solo `id` e `id_mesa` para precargar; el HTML de Ver
sigue mostrando el estado actual. No cambia permisos, transiciones ni
validaciones de capacidad y horario. La prueba de regresión falla antes del
cambio, pasa después y el navegador integrado confirma y cancela una reserva
local con el código corregido. La suite completa volvió a pasar con 503
pruebas PHP. El ensayo del guion de aplicación conserva los permisos,
guarda un respaldo y rechaza un controlador que difiera de la versión auditada.
La CLI de revisión de 21st no está disponible en esta máquina: la evidencia
es la reproducción en navegador, la regresión y las pruebas del proyecto.

Para publicar solo esta corrección, subir el contenido de
`entregables/validacion-staging-2026-11-18/correccion-reservaciones/` a
`.app/correccion-reservaciones/` y ejecutar:

```bash
cd ~/domains/staging-timon.verticesoftware.com.mx/public_html
bash .app/correccion-reservaciones/aplica.sh
```

También se entrega el `.tar.gz` con los mismos cinco archivos. Si se sube a
`.app/correccion-reservaciones.tar.gz`, extraerlo antes:

```bash
mkdir -p .app/correccion-reservaciones
tar -xzf .app/correccion-reservaciones.tar.gz -C .app/correccion-reservaciones
```

El dueño aplicó el parche por SSH: las huellas anterior y posterior y la
sintaxis PHP resultaron correctas. Quedó el respaldo
`.app/controladores/Web/Restaurante.php.antes-reservas-20261119-052407-3650494.bak`.
Después se reabrió la agenda en el navegador integrado, se confirmó
`RES-000001` en S1 y se canceló. El estado final remoto es **Cancelada** y
solo conserva la acción Ver. No queda una reservación de prueba activa.

La API sigue reportando la liberación original y esquema 25, conforme al
alcance puntual del parche; no se presenta como una liberación integral nueva.

## Comprobaciones privadas por SSH

Como el dueño conserva el acceso SSH, las siguientes órdenes de lectura
permiten completar los puntos 3 y 4 del plan sin compartir contraseñas:

```bash
cd ~/domains/staging-timon.verticesoftware.com.mx/public_html
php .app/guiones/verifica-host.php
php .app/guiones/migraciones.php --estado
php -r '$a=require ".app/config/app.php"; $b=require ".app/config/bd.php"; echo json_encode(["entorno"=>$a["entorno"]??null,"depurar"=>$a["depurar"]??null,"url_publica"=>$a["url_publica"]??null,"base_nombrada_como_staging"=>str_contains(strtolower((string)($b["base"]??"")),"staging")],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),PHP_EOL;'
```

El diagnóstico debe indicar que el host es apto; las migraciones no deben
mostrar pendientes ni alteraciones. El resumen debe mostrar `produccion`,
`depurar=false`, el origen de staging y una base identificada como staging.
El nombre es una comprobación de intención, no prueba por sí solo la
separación respecto de producción: el dueño debe contrastar la base y el
usuario de ambas instalaciones en hPanel, sin compartir sus contraseñas.

El perfil de cierre `--perfil=produccion` exige respaldo, cron y alertas;
esos tres puntos son opcionales en el plan de staging. No se usa su resultado
local para afirmar que el hosting ya los tiene configurados.

## Auditoría contra los ocho pasos del plan

| Paso | Evidencia actual | Qué falta para cerrarlo |
|---|---|---|
| 1. Sitio aparte | El origen de staging sirve Timón y la landing principal conserva su CSP. El guion aplicado por el dueño exige la carpeta física `domains/staging-timon.verticesoftware.com.mx/public_html`, y el resumen privado confirma la URL y la base de staging | Confirmar que las claves son exclusivas del entorno |
| 2. SSL | Las pruebas HTTPS validan el certificado, y HTTP redirige a HTTPS | Sin pendiente público observado |
| 3. PHP 8.3 y extensiones | `verifica-host.php` aportado por el dueño: PHP CLI 8.3.36 y todas las extensiones obligatorias y exif, host apto. La aplicación web funciona sin exponer el diagnóstico | La salida corresponde a CLI; el ajuste específico de la versión web se gestiona en hPanel |
| 4. Base propia | Salud activa, base identificada como staging, esquema 25 y 25 migraciones registradas/disponibles al día, operaciones de demostración funcionales | Confirmación del dueño de que la base y las claves se mantendrán separadas de producción; las 62 tablas del descriptor no constituyen un conteo remoto |
| 5. SSH | El dueño aplicó el parche, ajustó la configuración y aportó las comprobaciones de lectura del host y las migraciones | Sin pendiente de acceso para las comprobaciones recibidas; el acceso continúa en manos del dueño |
| 6. Paquete | SHA-256 del candidato original, recursos PWA verificados y rutas privadas negadas. Parche aplicado con ambas huellas y sintaxis correctas, confirmado mediante el flujo remoto. Candidato consolidado nuevo preparado, con SHA-256 y 378 archivos del manifiesto correctos | La instalación actual conserva el id original más el parche. El manifiesto completo del árbol remoto requiere SSH; el candidato consolidado queda para la próxima actualización |
| 7. Diferencias de staging | `noindex,nofollow`, robots global, `url_publica`, sitemap, QR, PWA del mismo origen, perfiles y variable pública de Expo comprobados | Confirmar claves privadas independientes y probar el binario nativo en equipos de prueba; no hay un build `staging` ni iOS en el listado consultado. Respaldo, cron y alertas son opcionales según el plan |
| 8. Comprobación | 62 defensas HTTP, 41 validaciones públicas adicionales aprobadas, 334 de perfiles, 15 de comanda y flujo público de reservación confirmado y cancelado; panel y sitio recorridos en navegador integrado | Las comprobaciones web descritas pasan completas; las apps nativas requieren la verificación de dispositivos del paso 7 |

No se marca el plan como completamente validado mientras estos puntos sigan
sin evidencia. El listado distingue el resultado de las pruebas del estado
de publicación, del acceso privado y de las verificaciones físicas.

## Límites

La respuesta de salud no acredita por sí sola la separación de credenciales
y bases entre staging y producción ni un respaldo recuperable. Las
extensiones de PHP CLI y las migraciones se acreditan con la salida privada
aportada por el dueño, no con la salud pública. No se recibieron claves privadas.
Las pruebas de impresión física y de Android/iPad se registran por separado
en el [piloto](salida.md).
