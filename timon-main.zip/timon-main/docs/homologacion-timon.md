# Homologación del panel web de El Timón

**Versión 1 · 16 de noviembre de 2026 · Diagnóstico y propuesta de ejecución**

RhToroV1 es la referencia de construcción. Distribuidora (Suga) es el antecedente de cómo se corrigió una aplicación que ya tenía la plantilla base. El código actual de El Timón, sobre `dc1b2a0` y con los archivos de trabajo presentes al revisar, es la referencia para campos, permisos, rutas y reglas del restaurante.

[Auditoría](#1-auditoría) · [Guía de construcción](#2-guía-de-construcción) · [Menú y fichas](#3-menú-y-fichas) · [Ejecución](#4-plan-de-ejecución) · [Lista de cierre](#5-lista-de-cierre) · [Criterios de RhToroV1](#6-los-84-criterios-de-rhtorov1)

## 1. Auditoría

### Alcance y método

El panel tiene **23 opciones de menú, más Tablero**. Se revisaron sus rutas, vistas, controles, consultas, permisos y componentes compartidos. También se rastrearon los detalles enlazables, la configuración del perfil y los límites con la app y el sitio público. La revisión fue estática, con una reproducción local del enlace de exportación en PHP. Quedan para la ejecución la comprobación de estilos calculados, navegación con teclado, operación por perfil y descargas con datos en un navegador autenticado.

Se usaron las cinco piezas y el mapa de pantallas del ZIP `suga_homologacion_2026-11-05.zip`. Los IDs R1–R84 del anexo conservan su vínculo con la auditoría de Suga. Sus recuentos, fases y aprobaciones corresponden a Distribuidora. Los ajustes de Timón se presentan como propuestas. Se cotejaron el checklist de cierre, Sucursales y Viáticos de RhToroV1, y la guía vigente y los listados de Clientes y Bodegas de Suga.

### Hallazgos priorizados

| ID | Prioridad | Diferencia comprobada | Corrección y prueba de aceptación |
|---|---|---|---|
| HT-01 | Alta | Reportes, Avisos y Sucursales construyen un enlace XLS con consulta y lo pasan a `pb_exportar()`, que vuelve a agregar los parámetros de la página. Con un filtro parcial de Reportes, PHP interpreta `hasta=2026-11-16?sucursal=2`. La validación del periodo recibe una fecha inválida. [Helper](../vistas/partes/piezas.php#L333) · [Reportes](../vistas/restaurante/reportes.php#L4) · [Avisos](../vistas/avisos/lista.php#L12) · [Sucursales](../vistas/organizacion/sucursales.php#L24) | Construir la consulta una vez con los filtros normalizados y excluir cursores y parámetros de presentación. Probar URL limpia, filtro completo y filtro parcial. En Sucursales probar activas, bajas y todas con un conjunto distinto por estatus. |
| HT-02 | Alta | Compras y Kardex se limitan a 100 filas. Gastos y Reservaciones tienen límite de 200. DataTables pagina las filas que ya llegaron al HTML. En Bitácora, el cursor del servidor convive con DataTables local y el enlace «Ver lo anterior». [Inventario](../servicios/InventarioRestaurante.php#L21) · [Gastos](../servicios/GastosRestaurante.php#L21) · [Agenda](../servicios/Reservaciones.php#L69) · [Bitácora](../vistas/bitacora/lista.php#L98) | Añadir filtros y paginación en servidor a los historiales. Probar con más de 100 y 200 coincidencias y estabilizar el orden. Distinguir el total filtrado de la cantidad de la página. Mantener explícita la ventana operativa de la agenda. |
| HT-03 | Alta | Áreas, Mesas, Categorías, Platillos e Impresoras precargan los formularios de edición desde la fila. Los listados del restaurante revisados carecen de una acción de consulta **Ver**. Personal ya dispone de consulta fresca y sirve de referencia local. [Áreas](../vistas/restaurante/areas.php#L15) · [Mesas](../vistas/restaurante/mesas.php#L20) · [Categorías](../vistas/restaurante/categorias.php#L13) · [Platillos](../vistas/restaurante/platillos.php#L20) · [Impresoras](../vistas/restaurante/impresoras.php#L15) · [Personal](../vistas/personal/lista.php#L80) | Adaptar el patrón `pb_detalle` / `fichaEnModal`. Abrir Ver con permiso de lectura y pedir los datos actuales también al editar. Probar que un cambio realizado en otro equipo después de cargar el listado aparece en el modal. |
| HT-04 | Alta | En Impresoras, «Actualizar» usa el mismo POST de alta. El servicio identifica el registro por sucursal y destino, y el selector Destino está habilitado. Editar y elegir otra zona guarda sobre la zona elegida y deja intacta la anterior. [Vista](../vistas/restaurante/impresoras.php#L15) · [Servicio](../servicios/ImpresionRestaurante.php#L16) | Propuesta de edición: identificar la impresora por su zona actual y fijar el destino, conservando el destino en el envío mediante un dato validado. Si se requiere reasignar zonas, decidir el flujo y cómo tratar los trabajos de impresión antes de habilitarlo. Probar con dos zonas ya configuradas. |
| HT-05 | Media | Mesas incluye un editor de plano debajo del listado. Cada fila de Platillos agrega una acción por modificador. Reservaciones contiene la configuración de horario y WhatsApp de la sucursal. Reportes mezcla las tarjetas del día con el periodo histórico. [Mesas](../vistas/restaurante/mesas.php#L29) · [Platillos](../vistas/restaurante/platillos.php#L20) · [Reservaciones](../vistas/restaurante/reservaciones.php#L53) · [Reportes](../vistas/restaurante/reportes.php#L8) | Dar al Plano su entrada. Llevar modificadores al detalle del platillo y datos públicos al de la sucursal. Colocar los indicadores vivos en Tablero o en un bloque de «Hoy» explícito si se conservan en Reportes. Probar las cuatro operaciones originales después de moverlas. |
| HT-06 | Media | El filtro compartido del restaurante únicamente selecciona sucursal. Reportes, Avisos y Bitácora muestran fechas sueltas pese a que el calendario común ya implementa rangos. El buscador local queda fuera de las consultas de exportación. [Filtro](../vistas/restaurante/filtro.php) · [Calendario](../publico/recursos/plantilla/main.js#L569) · [Tablas](../publico/recursos/plantilla.js#L345) | Usar un control de rango en historiales aplicables y una sola búsqueda autoritativa cuando hay XLS. Los atajos preparan la consulta. Buscar la aplica. Verificar tecleo sin Enter, Tab, limpiar y volver a la misma búsqueda tras abrir un detalle. |
| HT-07 | Media | La vista de inventario genera las columnas sin asignar título o insignia a la tarjeta móvil. En lotes y compras, la primera columna es Acción y el generador usa la primera celda como título de reserva. Reportes también carece de título explícito para la tarjeta. Hay campos de estatus en texto plano en Mesas, Platillos, Reservaciones y Compras. [Inventario](../vistas/restaurante/inventario.php#L28) · [Reportes](../vistas/restaurante/reportes.php#L26) · [Generador](../publico/recursos/plantilla.js#L209) | Marcar la columna descriptiva, la insignia y la zona de acciones. Usar `pb_insignia`/`pb_estatus` con texto. En teléfono verificar título, datos, acciones, orden y teclado con registros representativos. |
| HT-08 | Media | `Restaurante::inventario()` carga las siete colecciones de inventario en cada una de las seis pantallas, aunque cada una muestra su propia tabla. `Restaurante` también concentra flujos independientes del giro. [Controlador](../controladores/Web/Restaurante.php#L194) · [Servicio](../servicios/InventarioRestaurante.php#L21) | Cargar la tabla seleccionada y solo los catálogos que utiliza su modal. Mantener los flujos explícitos, agrupados por servicio. Separar controladores solo donde ayude a leer y probar la responsabilidad. Medir consultas por pantalla y preservar las rutas. |
| HT-09 | Media | La [guía heredada](guia-pantallas.md) conserva bodegas, reparto, liquidaciones, decisiones de Suga y enlaces a fichas inexistentes en Timón. El [sistema visual](../design-system/plantilla/MASTER.md) conserva ejemplos y valores históricos de Suga. Hay selectores de módulos heredados en la hoja global. [Tema](../publico/recursos/tema.css#L1140) | Usar la guía de este documento para el alcance de homologación y sincronizar la guía existente al ejecutar la fase 0. Inventariar referencias de CSS antes de retirar selectores. Tomar los valores vigentes de [Peltre](../marca/tokens.json) y comprobar el aspecto calculado en navegador. |
| HT-10 | Media | Equipos personales y Equipos de comanda tienen nombres parecidos, permisos, tablas y ciclos de acceso diferentes. [Menú](../vistas/plantilla/menu.php#L16) · [Rutas](../rutas/web.php#L96) | Usar «Equipos de comanda» y «Equipos del personal» como nombres distinguibles. Probar que retirar uno invalida sus sesiones según el flujo correspondiente y que los controles aparecen en el perfil correcto. |

**Base reutilizable.** Timón ya genera un encabezado común con `pb_modulo()`, tiene `pb_tabla()` y tarjetas móviles, acciones apiladas, modales de captura con fondo estático, mensajes junto a campos, protección de permisos y piezas de exportación. Sucursales, Personal, Avisos y Bitácora ya abren fichas en modal. En la primera tanda se corrigen diferencias sobre estas piezas para que cada pantalla del restaurante deje de resolverlas de forma particular. [Componentes PHP](../vistas/partes/piezas.php) · [Interacción común](../publico/recursos/plantilla.js) · [Rutas web](../rutas/web.php#L71)

## 2. Guía de construcción

### 2.1 Pantalla, menú, botones y tarjetas

- Cada listado tiene una entrada, una ruta, un título visible igual al menú y a la pestaña, un ícono y una tabla principal. Usar `pb_modulo()` con un único `h1` y un subtítulo concreto. El nivel semántico y el tamaño visual se ajustan por separado. Mantener visible la sucursal seleccionada cuando la consulta es de una sucursal.
- Orden de la pantalla: encabezado, filtros, indicadores pertinentes, conteo, avisos y tabla con representación móvil. Usar `pb_filtros()`, `pb_registros()`, `pb_tabla()` y `pb_tabla_fin()`. Una configuración única usa una ficha. Tablero usa tarjetas de resumen. El editor de plano usa un espacio de trabajo propio.
- Un primario en el encabezado. «Agregar» abre un alta, el verbo de operación abre la acción que inicia un flujo, y «Exportar XLS» queda a la derecha en contorno. La navegación de módulos vive en el menú. CSV, PDF y QR conservan su propósito y su ruta original.
- «Acción» va primero, después de la casilla cuando exista una operación masiva. Orden: Ver, Actualizar, operaciones del estado, descarga, cierre o retiro. Enlaces apilados, con nombre accesible y confirmación contextual para la acción sensible. No ofrecer acciones nuevas a partir de un nombre o un estado de base de datos.
- Usar `summary-tile` / `metric-card` para indicadores, `pb_estatus()` / `pb_insignia()` para estados y `form-section` para secciones. Mantener la identidad Peltre y los íconos locales ya cargados. Una métrica del día lleva su alcance temporal aunque se vea al lado de un historial.
- Tarjetas y tabla usan la misma fila. Marcar `data-pb-titulo`, `data-pb-insignia` y `data-pb-acciones`. Usar un solo punto de corte para listados que compartan la misma composición. Propuesta: tarjetas desde anchos inferiores a 768 px y tabla a 768 px si cabe, con zona de desplazamiento delimitada para matrices anchas.

### 2.2 Filtros, consultas y exportación

- Orden: periodo o fecha, sucursal cuando aplica, catálogos del módulo, estado y búsqueda. En filtros de operación diaria mantener el contexto del día. En historiales usar el mes en curso cuando la ficha lo proponga y conservar los valores históricos ya implementados. Para agotados, mostrar «Disponibilidad actual».
- Los atajos del calendario cambian el rango visible. «Buscar» aplica. «Limpiar filtro» restaura los valores por defecto de la ficha. Con el patrón GET actual se puede volver a la ruta base al limpiar. Al enviar, el campo con fecha tecleada debe consolidar el valor aunque termine con Tab o se pulse directamente Buscar. Al cerrar un modal se cierra también su calendario.
- La búsqueda por texto relevante consulta el conjunto completo con palabras combinables e independientes del orden. Verificar acentos y mayúsculas en la base configurada. Usar selectores con catálogo cuando corresponda. Buscar en servidor para catálogos de personas de alto volumen con el mismo alcance que el listado. Mantener las opciones vigentes como elegibles al capturar.
- Aplicar un único conjunto de filtros validados a listado, conteo y exportación. La página y el cursor delimitan el listado, mientras el XLS recorre todos los resultados filtrados. Para consultas amplias usar paginación del servidor, 25 por defecto y hasta 100 por página como propuesta, y orden determinista con desempate. Preservar el orden de negocio, por ejemplo agenda ascendente y lotes por caducidad. Mantener `order: []` cuando manda el orden del servidor.
- Exportar XLS con nombres legibles, formatos de cantidad, moneda y fecha, las columnas de datos de la ficha y el orden del listado. Un formato técnico de auditoría como el CSV de Bitácora tiene su propia finalidad. Probar total, primera y última fila, filtros efectivos, nombre del archivo, importes como números, permiso y falla de descarga. El enlace se construye una vez desde el estado aplicado.

### 2.3 Modales, errores y continuidad

- Un conjunto de campos compartidos para Agregar, Ver y Actualizar donde representan la misma ficha. Ver puede tener presentación de solo lectura y subtablas. Usar `pb_modal()`, `pb_detalle()` y `pb_seccion()`. Consultar la ficha actual al abrir Ver o Actualizar. Conservar el enlace directo mediante `?ver=`, la sucursal y los filtros aplicados.
- Captura con fondo estático, título enlazado por `aria-labelledby`, X con nombre «Cerrar», scroll interno y pantalla completa en teléfono mediante la pieza común. Pie con «Guardar» o el verbo de la operación. En Ver no aparece Guardar. El foco entra en el diálogo, sigue un orden visible y vuelve al disparador al cerrar. Si el detalle falla, mostrar la causa y permitir reintentar sin perder el listado.
- Etiqueta visible y asociada, asterisco en obligatorios, «(Opcional)» en opcionales, ayuda donde haga falta y error por campo. Al cargar un detalle usar la espera común. Al guardar, proteger el envío repetido, conservar los datos ante `409`/`422` y anunciar el resultado. Mantener el contraste, los estados de foco, los controles táctiles de 44 px y el ajuste de movimiento reducido.
- Conservar CSRF, sesión, renovación, permisos y alcance de sucursal. Permiso de lectura para Ver y permiso original de escritura para Actualizar. Pruebas directas de sesión vencida, acción denegada, datos inadecuados y registro ajeno. Revisar que el sondeo de indicadores no mantenga viva por sí solo la sesión.

### 2.4 Arquitectura

| Capa | Responsabilidad en Timón | Referencia |
|---|---|---|
| Menú y rutas | Una definición de navegación compartida por la barra lateral y el tablero. Cada GET y POST conservan su middleware y su `#[Accion]`. | [Menú](../vistas/plantilla/menu.php) · [Rutas](../rutas/web.php) |
| Controlador web | Normaliza filtros, prepara la vista y negocia HTML o JSON con los helpers del proyecto. Devuelve errores controlados y resuelve el regreso al listado. | [Controlador base](../controladores/Controlador.php#L39) · [Personal](../controladores/Web/PersonalWeb.php#L115) |
| Servicios y consultas | Conservan operaciones, transacciones, alcance y auditoría. Comparten la consulta de listado y la exportación cuando representan el mismo conjunto. Consultas preparadas, orden estable y carga de datos por pantalla. | [Inventario](../servicios/InventarioRestaurante.php) · [Reportes](../servicios/ReportesRestaurante.php) |
| Vistas y recursos | PHP compone piezas `pb_*`. La hoja global aplica la marca y el JavaScript común maneja filtros, tablas, modales y descargas. El plano mantiene su interacción especializada. | [Piezas](../vistas/partes/piezas.php) · [Plantilla](../publico/recursos/plantilla.js) · [Plano](../publico/recursos/plano-editor.js) |
| Integraciones | El cambio pertenece al panel web. Los contratos de `/api/v1`, la app de comanda, el acceso por PIN, la impresión, la landing, el menú QR y el ticket se verifican por regresión cuando los datos que comparten resulten afectados. | [API](../rutas/api.php) · [Prueba de comanda](../pruebas/humo-comanda.py) |

Evitar un CRUD genérico para inventario, reservaciones o caja. Cada transición conserva su validación, permiso y bitácora. Para una ruta nueva de consulta, reutilizar el permiso existente del listado y validar el registro dentro de la sucursal. Si hay una necesidad comprobada de cambiar un permiso, una regla o el esquema, registrar el caso con su evidencia y tratarlo como decisión de producto.

## 3. Menú y fichas

Las fichas identifican la pantalla por su ruta actual y distinguen campos y acciones existentes de los ajustes propuestos. Las pantallas que comparten vista mantienen su comportamiento por tipo. Las llamadas POST y validaciones exactas se rastrean en [rutas web](../rutas/web.php#L82) y en los servicios enlazados.

### Menú propuesto

| Grupo | Entradas en orden |
|---|---|
| Inicio | Tablero |
| Salón y carta | Áreas · Mesas · Plano del salón · Reservaciones · Categorías del menú · Platillos · Promociones · Carta |
| Equipos y ventas | Equipos de comanda · Impresoras · Gastos · Reportes |
| Almacén y compras | Insumos · Lotes de insumo · Compras · Proveedores · Recetas · Kardex de insumos |
| Negocio y seguridad | Sucursales · Operación local · Personal · Equipos del personal · Avisos · Verificación en dos pasos · Revisión de accesos · Bitácora · Privacidad |

**Cambio de navegación propuesto.** Una entrada nueva, «Plano del salón», extrae una función que ya existe en Mesas. «Equipos del personal» cambia el nombre visible de `/dispositivos` en menú, encabezado y pestaña. Rutas, iconos y permisos de las demás entradas se toman del menú actual. El nuevo ícono de Plano debe distinguirse del de Áreas. Opciones y accesos del tablero salen de la misma definición y respetan el giro activo.

### 3.1 Inicio, salón y carta

| Ficha y permiso de entrada | Hoy | Ajuste y validación específica |
|---|---|---|
| 01 · **Tablero** `/panel` · sesión | «Lo que hay que atender hoy en sus sucursales.» Tarjetas y accesos según permisos. [Vista](../vistas/tablero/inicio.php) | Usar tarjetas comunes con última actualización y alcance visible. Revisar destinos con administrador y puesto limitado. Si aquí pasan los indicadores de Reportes, conservar su permiso y su sucursal. Excepción de tablero, sin tabla artificial. |
| 02 · **Áreas** `/areas` · `plano_ver` | «Áreas que organizan el plano de la sucursal.» Filtro sucursal. Área y cantidad de mesas. Agregar/Actualizar con `nombre` máximo 80 y permiso `plano_admin`. [Vista](../vistas/restaurante/areas.php) | Piloto de ficha Ver/Actualizar desde servidor. Área como título móvil y Mesas como número. Mantener el alcance al regresar. Probar un nombre duplicado conforme a la validación vigente y que un lector pueda Ver sin editar. |
| 03 · **Mesas** `/mesas` · `plano_ver` | «Mesas, capacidad y ubicación por área.» Sucursal, número, área, capacidad y estado. Captura `numero`, `id_area`, `capacidad` 1–255, `forma`, `x`/`y` 0–100 y `estado`. Actualizar con `plano_admin` si la mesa no tiene cuenta. Imprimir QR si hay clave pública de sucursal. [Vista](../vistas/restaurante/mesas.php) | Ver, Actualizar e Imprimir QR en ese orden según reglas vigentes. Añadir Área y Estado como filtros cuando se aprueben. Tabla conserva número como título e insignia textual. La ficha enseña forma y posición. Probar mesa con cuenta, QR de la sucursal y conservación del contexto al volver. |
| 04 · **Plano del salón** `/mesas/plano` propuesta · `plano_ver` | Vive debajo de Mesas. Posición por área y desplazamiento por arrastre o flechas. El POST de posición exige `plano_admin`. [Vista](../vistas/restaurante/mesas.php#L30) · [Interacción](../publico/recursos/plano-editor.js) | «Ubicación de las mesas por área de la sucursal.» Trasladar el editor a una pantalla propia. Probar lectura, arrastre, flechas, persistencia, estado anunciado y error de guardado. Mantener contrato de posición, QR y acceso desde el menú. |
| 05 · **Reservaciones** `/reservaciones` · `reservaciones_opera` | «Agenda y asignación de mesas por sucursal.» Cliente, teléfono, fecha, personas, mesa y estado. Solicitud permite confirmar o cancelar. Confirmada permite reasignar, atender o cancelar. La agenda lee desde ayer, en orden de fecha ascendente, con límite de 200. [Vista](../vistas/restaurante/reservaciones.php) · [Servicio](../servicios/Reservaciones.php#L69) | Ver en modal con inicio y fin. Propuesta de fecha o rango y estado con la agenda habitual como entrada. Mantener selección de mesa y validación de capacidad, horario y solapes. Llevar horario y WhatsApp a Sucursales. Probar que atender libera el flujo para que se abra la mesa. |
| 06 · **Categorías del menú** `/categorias-menu` · `menu_admin` | «Categorías que agrupan los platillos.» Categoría y orden. Agregar/Actualizar `nombre` de hasta 80 y `orden` 0–65535, por defecto 0. El catálogo es general y la pantalla usa contexto de sucursal. [Vista](../vistas/restaurante/categorias.php) · [Servicio](../servicios/MenuRestaurante.php#L37) | Ver/Actualizar con ficha liviana y orden igual al de la carta, por orden y nombre. Indicar que el cambio es de catálogo general. Evitar aplicar silenciosamente un filtro de catálogo por sucursal. |
| 07 · **Platillos** `/platillos` · `menu_admin` o `menu_sucursal` | «Carta, precios y disponibilidad por sucursal.» Platillo, categoría, preparación, precio y disponibilidad. Edición general de `nombre`, `id_categoria`, `preparacion`, `descripcion`, `foto` y `activo`. Modificadores con nombre, suplemento y estado. Precio/agotado se guarda por sucursal. [Vista](../vistas/restaurante/platillos.php) | Propuesta de filtros Categoría, Preparación y Disponibilidad. En Ver mostrar ficha y subtabla de modificadores. `menu_admin` edita catálogo/modificadores y `menu_sucursal` cambia precio/disponibilidad, con un modal específico. Conservar «Sin publicar», «Inactivo», «Agotado» y «Disponible». Probar cada permiso por separado y comprobar que el cambio llega a la comanda y la carta pública. |
| 07a · **Promociones** `/promociones` · `promocion_admin` | Agregada el 2026-11-18. «Descuentos por platillo que se aplican solos al capturar.» Filtros sucursal, platillo y estado (Vigente ahora, Programada, Pausada, Vencida). Tipo porcentaje (1–90 %), precio especial o 2x1/3x2, con fechas, días y horario. Ver, Actualizar, Pausar o Reanudar y Dar de baja con envío único y bitácora. [Vista](../vistas/restaurante/promociones.php) · [Servicio](../servicios/Promociones.php) · [Reglas](../dominio/Promocion.php) | Al guardar avisa si se empalma con otra; gana la de mayor rebaja. La promoción se fija en el renglón al capturar y la rebaja se recalcula al cambiar cantidades, cancelar, transferir o separar. Comprobado en navegador a 1440 px: alta de precio especial, estado «Vigente ahora», carta, menú QR y landing con precio tachado. |
| 07b · **Carta** `/carta` · `menu_admin` o `menu_sucursal` | Agregada el 2026-11-18. «Se arma sola con las categorías, los platillos y las promociones.» Vista previa de la hoja impresa (portada y menú a tres columnas con el diseño del PDF del dueño), opciones de promociones y tamaño, aviso de cuántas hojas ocupa. «Imprimir la carta» (imprime o guarda en PDF) y «Textos del pie» (`menu_admin`). [Vista](../vistas/restaurante/carta.php) · [Hoja](../vistas/restaurante/carta-hoja.php) · [Servicio](../servicios/CartaImpresa.php) | La vista previa consulta la huella cada 3 s con la pestaña visible y recarga sin parpadeo. Es la única respuesta que se deja enmarcar, y solo por el mismo sitio (`Respuesta::conMarcoPropio`). Comprobado: un precio cambiado se vio en menos de 4 s; 1440 y 375 px sin desplazamiento horizontal. |

### 3.2 Equipos, gastos y reportes

| Ficha y permiso de entrada | Hoy | Ajuste y validación específica |
|---|---|---|
| 08 · **Equipos de comanda** `/equipos-comanda` · `equipo_admin` | «Equipos vinculados a la sucursal y su modo de operación.» Equipo, modo, plataforma, estado. Autorizar con código de diez caracteres hexadecimales y modo. Retirar confirma pérdida de acceso. [Vista](../vistas/restaurante/equipos.php) | Agregar Ver con los datos permitidos. Rotular la operación principal «Autorizar equipo». Mantener retiro según estado. Presentar el modo y la plataforma con etiquetas de usuario. Probar autorización de un código, retiro y rechazo de sesión del equipo retirado. |
| 09 · **Impresoras** `/impresoras` · `plano_admin` | «Impresoras térmicas y áreas que atienden.» Equipo, destino, red, rollo y estado. Campos `nombre`, `destino`, IPv4 privada, puerto 1–65535 (9100 inicial), rollo 58/80 y estado. [Vista](../vistas/restaurante/impresoras.php) | Ver y Actualizar consultan por sucursal y destino actual. Hacer explícito el alcance de edición de destino según HT-04. Probar alta por destino, guardar edición del destino original, validación de IP y compatibilidad con una cola de prueba. |
| 10 · **Gastos** `/gastos` · `gastos_opera` | «Gastos y salidas de caja de la sucursal.» Concepto, proveedor, importe, referencia, pagado en caja y fecha. Agregar con concepto, importe positivo, proveedor y referencia opcionales. «Pagar desde caja» exige `comanda_cobra`. [Vista](../vistas/restaurante/gastos.php) · [Servicio](../servicios/GastosRestaurante.php) | Propuesta de historial con periodo, proveedor y pago de caja. Incorporar Ver con datos existentes y XLS del conjunto filtrado. Probar gasto con y sin proveedor y un solo asiento cuando paga caja. Sin botón de edición o retiro mientras el flujo carezca de esas operaciones. |
| 11 · **Reportes** `/reportes` · `reportes_restaurante` | «Ventas, cocina e inventario por sucursal.» Sucursal, reporte y Desde/Hasta, con mes en curso y Ventas por día al entrar. Una tabla dinámica, indicadores de hoy y exportación CSV, PDF y XLSX. [Vista](../vistas/restaurante/reportes.php) · [Consulta](../servicios/ReportesRestaurante.php#L12) | Conservar un reporte seleccionado por vista con URL reproducible. Unificar fechas, fijar los enlaces HT-01 y etiquetar o mover los indicadores vivos. Validar las nueve variantes, sus columnas y los tres formatos. Agotados representa la disponibilidad actual. |

**Variantes que se deben comprobar al cerrar Reportes.** Ventas por día, hora y mesero conservan agrupación, tickets, venta, propinas y ticket promedio. Ventas por platillo conserva platillo, unidades y consumo. Tiempos de cocina conserva área, platillos listos y minutos promedio. Cancelaciones conserva cuenta, platillo, cantidad, motivo y fecha. Agotados conserva platillo, categoría y preparación. Consumo y mermas conserva insumo, unidad, consumo según recetas, merma y ajuste de conteo. Gastos conserva concepto, proveedor, importe y fecha. [Definiciones de columnas](../servicios/ReportesRestaurante.php#L21)

### 3.3 Almacén y compras

Las seis entradas usan `inventario_opera`, seleccionan una sucursal autorizada y comparten hoy la [vista](../vistas/restaurante/inventario.php) y el [servicio](../servicios/InventarioRestaurante.php). El cambio de lectura recomendado es una consulta por listado, más catálogos pertinentes a su formulario.

| Ficha | Datos y captura actual | Ajuste y validación específica |
|---|---|---|
| 12 · **Insumos** `/inventario/insumos` | «Existencias y unidades de medida.» Insumo, unidad, existencia y vencido. Agregar con nombre y unidad. | Buscar por insumo. Ver y XLS como lectura con unidad y cantidad. Conservar la forma de calcular existencia y vencido. El alta no implica una operación de actualización. |
| 13 · **Lotes de insumo** `/inventario/lotes` | «Caducidad, costo y saldo por lote.» Lote, insumo, saldo, caducidad y costo. Merma y conteo requieren cantidad y motivo. Solo lista lotes con saldo, ordenados por caducidad. | Ver, Registrar merma y Registrar conteo. Propuesta de filtros Insumo y Caducidad, con alcance claro sobre lotes con saldo. Usar nombre de insumo y lote para la tarjeta. Probar saldo y movimiento resultante una sola vez. |
| 14 · **Compras** `/inventario/compras` | «Órdenes y recepciones de insumos.» Referencia, proveedor, fecha y estado. Captura un renglón con proveedor, referencia, insumo, cantidad, costo y caducidad. «Recibir» solo en ordenada. | Periodo, proveedor y estado en servidor. Ver encabeza la fila y muestra los renglones existentes en subtabla. Guardar y recibir conserva la transacción. La captura de varios renglones ya es admitida por el servicio y se puede evaluar después como cambio de alcance de la interfaz. Probar 101 compras y que repetir la recepción no cree otros lotes. |
| 15 · **Proveedores** `/inventario/proveedores` | «Proveedores de insumos de la sucursal.» Nombre y contacto. Agregar con nombre obligatorio y contacto opcional. | Buscar por nombre, Ver y XLS. Comprobar alcance y presencia del proveedor en captura de compras o gastos. No inventar edición o baja. |
| 16 · **Recetas** `/inventario/recetas` | «Consumo de insumos por platillo.» Platillo, insumo y cantidad. El formulario envía esa combinación. El servicio agrega o actualiza y, con cantidad cero, retira el insumo. | Propuesta de filtro por platillo. Ver receta por platillo como ficha con sus insumos. Etiquetar con claridad la captura de cantidad y explicitar el efecto de cero. Probar fracciones de milésimas, retiro y consumo por receta al cobrar. |
| 17 · **Kardex de insumos** `/inventario/movimientos` | «Entradas, consumos, mermas y conteos.» Lote, insumo, movimiento, cantidad, motivo y fecha. Consulta de los últimos 100 movimientos. | Periodo, insumo y tipo con paginación del servidor. Ficha de solo lectura y XLS de todo lo filtrado. Conservar signo y precisión de cantidad, vínculo con lote y orden reciente primero. |

### 3.4 Negocio y seguridad

| Ficha y permiso de entrada | Hoy | Ajuste y validación específica |
|---|---|---|
| 18 · **Sucursales** `/sucursales` · `organizacion_ver` | «Sucursales del negocio, con su clave para tickets y su dirección.» Estatus (activas al entrar), clave, nombre, dirección, teléfono, personal activo. Ver en modal, XLS, y alta/edición/baja/reactivación con `organizacion_admin`. [Vista](../vistas/organizacion/sucursales.php) | Corregir XLS y pedir ficha fresca para editar cuando proceda. Propuesta de mover aquí los datos públicos de Reservaciones, con el mismo POST y permiso. Probar que horario/WhatsApp de una sucursal aparecen en el sitio y que los demás campos del modal sobreviven al traslado. |
| 19 · **Personal** `/personal` · `personal_ver` | Filtros sucursal, puesto y estatus. Nombre, puesto, sucursal, usuario y estatus. Ver y Actualizar consultan `/personal-detalle/{id}`. Gestión de usuario, contraseña, segundo factor y acceso según permisos y estado. [Vista](../vistas/personal/lista.php) · [Controlador](../controladores/Web/PersonalWeb.php#L115) | Patrón local para consulta fresca. Alinear acciones de detalle y listado, preservando credencial y flujos sensibles de la ficha. Probar enlaces directos, perfil limitado, contraseña temporal y que dar de baja o reactivar conserva el comportamiento de acceso. |
| 20 · **Equipos del personal** `/dispositivos` · `personal_ver` | Se llama «Equipos». Filtro de mostrar, persona, puesto, sucursal, equipo, último acceso y estatus. Ver, Autorizar, Revocar acceso, notificación y XLS según permiso. [Vista](../vistas/dispositivos/lista.php) | «Dispositivos vinculados a las cuentas del personal.» Renombrar de forma consistente. Mantener `personal_admin` para autorizar/revocar y `notificaciones_envia` para el envío. Comparar el XLS con la tabla y el filtro vigente. |
| 21 · **Avisos** `/avisos` · `avisos_ver` o `notificaciones_envia` | «Avisos del panel a los teléfonos del personal.» Periodo del mes actual. Título, hora, destino, personas, teléfonos, recibidos, fallidos y quién envió. Ver, XLS y enviar con destino, título y mensaje cuando hay permiso y destinos. [Vista](../vistas/avisos/lista.php) | Control de rango y corrección HT-01. Mantener conteos, resultados y el detalle de entrega. Probar con lector y emisor por separado, sin enviar notificaciones reales. |
| 22 · **Verificación en dos pasos** `/seguridad` · `seguridad_admin` | Configuración única con estado, cobertura, contexto de acceso y último cambio. Actualizar en modal con las credenciales exigidas por el estado actual. [Vista](../vistas/seguridad/ver.php) | Conservar la ficha y su vínculo contextual a Bitácora. Comprobar con estado encendido/apagado, error dentro del modal y reglas de autorización vigentes. |
| 23 · **Revisión de accesos** `/seguridad/accesos` · `accesos_revisa` o `seguridad_admin` | Usuario, nombre, puesto, sucursal, cuenta, Authenticator y acceso hasta. Descargar CSV/XLS, registrar revisión, consultar anteriores y ver persona o bloquear si corresponde. [Vista](../vistas/seguridad/accesos.php) | Mantener un listado principal y el historial en modal. Revisar el alcance de lectura, bloqueo y exportación por separado. Probar registro de revisión y que abrir un detalle conserve la consulta. |
| 24 · **Bitácora** `/bitacora` · `bitacora_ver` | Desde, Hasta, canal, módulo, acción, quién, tipo y número de registro y operación. Ver apunte. XLS/CSV por `bitacora_exporta`. Mes en curso inicial y cursor de anteriores. [Vista](../vistas/bitacora/lista.php) · [Controlador](../controladores/Web/BitacoraWeb.php) | Un rango y paginación del servidor sin doble control local. Conservar el modo histórico de fechas vacías y el CSV técnico. Probar permisos, redacción de valores sensibles conforme al flujo vigente y XLS de todo el conjunto temporal. |
| 25 · **Privacidad** `/privacidad` · `seguridad_admin` | Registro de solicitudes, estado y vencimiento. Ver, Atender, Descargar datos y Anonimizar según tipo, titular y estado. Resumen de solicitudes y XLS. [Vista](../vistas/privacidad/lista.php) | Tarjetas y estatus comunes. Propuesta de filtros según volumen, con el mismo conjunto en conteo y XLS. Mantener verificación de titular y confirmación reforzada. Probar con datos ficticios y preservar el aviso público. |
| 26 · **Operación local** `/servidores` · `servidor_admin` | Nueva el 2026-11-18. «Sucursales que siguen operando sin internet.» Una fila por sucursal activa: dónde opera, computadora, última subida, última bajada, cambios por subir, versión y estado (Al día, Sin noticias tras 30 min, Con error). Registrar computadora en modal (muestra una vez el número y la llave) y Regresar al central. [Vista](../vistas/admin/servidores.php) · [Guía](servidor-sucursal.md) | Probar que registrar exige cuentas y turno cerrados, que la llave no se vuelve a mostrar y que regresar exige cero pendientes. El humo `pruebas/humo-sucursal.py` cubre la réplica completa. |

**Rutas auxiliares.** Mi perfil y Cambio de contraseña son flujos de cuenta. Conservar el modal de PIN y el cambio obligatorio de contraseña. `/sesion/lista` es la confirmación de renovación desde otra pestaña. `/mesas/{id}/qr`, `/menu/{sucursal}` y `/ticket/{token}` conservan su presentación de papel o consulta pública. Los detalles directos de Personal, Sucursales, Equipos, Avisos, Bitácora y Privacidad conservan sus enlaces y su redirección o negociación vigente. [Rutas](../rutas/web.php) · [Perfil](../vistas/perfil/ver.php) · [Renovación](../vistas/sesion/lista.php)

### 3.5 Consultas agregadas

| Ficha y permiso | Datos y acciones | Evidencia esperada |
|---|---|---|
| 26 · **Turnos y cortes** `/caja/turnos` · `caja_consulta` | Sucursal y periodo. Ver desglosa cobros por forma, movimientos, efectivo esperado y contado, y diferencia. XLS del periodo. | Verificar turno abierto y cerrado, cálculo con cambio y alcance de sucursal. El cajero opera su turno en la app. |
| 27 · **Faltantes** `/inventario/faltantes` · `faltantes_atiende` | Insumo, cantidad, ticket y estado. Filtro por sucursal y estado. Atender registra la nota, el responsable y la hora. | Cobrar un platillo sin existencia, atender el faltante y verificar que salga del indicador de pendientes. Comprobar doble envío y sucursal ajena. |

## 4. Plan de ejecución

### Decisiones del 16 de noviembre de 2026

- Se aprueban los cuatro grupos del menú, la pantalla propia **Plano del salón** y el nombre **Equipos del personal**.
- El horario y WhatsApp se administran en Sucursales. Tablero reúne los indicadores del día. Reportes conserva la consulta histórica.
- La edición de impresoras conserva el destino. El alta configura destinos libres.
- Compras, Kardex, Gastos y Bitácora filtran y paginan en servidor, con 25 filas iniciales y hasta 100 por página. XLS lleva el conjunto filtrado completo.
- Caja opera en la app. El panel consulta turnos y cortes. Los cambios de escritura aprobados para catálogos, compras y gastos corresponden a la etapa de funciones nuevas.
- La app se valida en el simulador de iPad. Las pruebas de Android, incluido el impresor, son manuales con equipos físicos en el piloto.

| Fase | Trabajo | Evidencia para cerrar |
|---|---|---|
| **0. Reconocer** | Registrar versión y consultas de cada ruta. Capturar escritorio, tableta y móvil en el entorno de pruebas, con administrador y perfiles de lectura/operación. Resolver las propuestas de navegación, filtros, alcance de XLS y destino de impresora. Actualizar la guía heredada con las reglas de Timón. | Capturas y matriz de permisos actual. Mapa de datos y contratos confirmados. Decisiones fechadas. |
| **1. Componentes y piloto en Áreas** | Ajustar el encabezado, las secciones, los modales de ficha y el regreso al listado. Aplicarlos primero en Áreas. Corregir el enlace XLS compartido con pruebas para Reportes, Avisos y Sucursales. | Alta, Ver y Actualizar en la misma pantalla, datos recién consultados, 401/403/404/422 esperados y listado coherente a tres anchos. Prueba con URL limpia, completa y parcial de cada XLS afectado. |
| **2. Salón, carta y equipos** | Homologar Mesas, Plano, Categorías, Platillos, Reservaciones, Equipos de comanda e Impresoras. Completar tarjetas y estados. Aplicar las decisiones de separación de funciones. | Matriz acción por estado y permiso. QR, arrastre y flechas, carta, reserva, autorización/retiro y edición de impresora comprobados. |
| **3. Inventario, gastos y consultas** | Acotar lecturas de Inventario. Implementar filtros y paginación de historiales y revisar paridad de Reportes y Bitácora. Aplicar descargas acordadas, con tipos y columnas de ficha. | Prueba por encima de los límites actuales, consulta acotada por sucursal, compras/mermas/conteos sin duplicados y exportaciones cotejadas con la consulta. |
| **4. Negocio y seguridad** | Alinear modal y regreso donde falte, contraste, texto, iconos, filtros y descargas. Desambiguar Equipos del personal. Revisar acciones de acceso y datos de privacidad. | Perfiles que leen, que escriben y que carecen de permiso. Renovación de sesión, enlace profundo, regreso a filtros y acciones sensibles comprobados. |
| **5. Validación integral** | Recorrer las 25 fichas propuestas y rutas auxiliares. Ejecutar la suite local y los escenarios de regresión de comanda que apliquen. Repetir los flujos críticos en staging cuando la versión esté instalada. | Lista de cierre por ficha, resultados y capturas. Pendientes con ruta, perfil y reproducción. Registro de regresión de comanda, QR y ticket. |

**Decisiones a registrar antes de la tanda correspondiente.** Aprobar el nombre de Equipos del personal y la separación de Plano, horarios y métricas del día. Acordar el conjunto de filtros y nuevos XLS significativos. Resolver qué debe ocurrir ante el cambio de destino de una impresora. La captura de compras con varios renglones y nuevas operaciones de escritura requieren su propia definición si se incorporan.

**Evidencia por ficha.** Registrar el permiso del GET, el permiso de cada acción y sus estados de origen. Probar con administrador y los puestos a los que afecta la pantalla, como gerente, almacén, cajero o mesero. Para un registro de otra sucursal, comprobar que listado, detalle, escrituras y XLS aplican el mismo alcance. Guardar ruta, perfil, fecha, ancho, resultado y referencia a la captura o prueba.

**Recorrido integral de muestra.** Confirmar una reserva y marcarla atendida. Abrir la mesa en la app, tomar una ronda, verla en cocina y registrar la entrega. Cobrar, comprobar ticket y corte, y cotejar el consumo del lote en Kardex y la venta en Reportes. En otra operación, recibir una compra y registrar una merma o un conteo para cotejar saldo y bitácora. Estos recorridos enlazan los datos del panel con la operación que los genera.

## 5. Lista de cierre

- [ ] Menú, título, icono y permiso coinciden. El destino funciona por URL directa y desde el menú o Tablero.
- [ ] Campos, obligatoriedad, catálogos, reglas y mensajes fueron cotejados con la ficha y el servicio. Se consignaron las decisiones de cambio con fecha.
- [ ] Una tabla principal con acciones primero, conteo de la consulta, estados con texto, vacío contextual y carga sin parpadeos ni desplazamientos.
- [ ] Al filtrar, los valores aplicados, la página, el orden, los indicadores pertinentes y las descargas corresponden al mismo conjunto. Rango tecleado, limpieza y recuperación de error probados.
- [ ] Agregar, Ver y Actualizar abren el modo correspondiente. Ver es de lectura. Los datos actuales aparecen aunque se hayan modificado desde otro equipo. Cerrar devuelve foco y contexto.
- [ ] Las acciones por fila respetan permiso y estatus en vista y servidor. Probar sesión vencida, acceso directo denegado, registro ajeno, conflicto de estado y 422 de campo.
- [ ] Guardado repetido y reintento conservan la idempotencia de las operaciones que la requieren. Confirmar bitácora de permisos, movimientos de inventario, retiros y demás transiciones tocadas.
- [ ] A 1440, 768 y 375 px, con teclado y tacto, el foco es visible, las etiquetas están asociadas, el contenido crítico cabe y las acciones de tarjetas equivalen a las de tabla.
- [ ] XLS abre con nombre real, fecha, cantidades e importes de tipo correcto. Verificar primera y última fila, columnas, orden, total y respuesta sin permiso. Comprobar PDF/CSV donde existan.
- [ ] Ejecutar `pruebas/todo.sh` en entorno local de pruebas. Este guion reconstruye la base de pruebas. Usar la prueba de comanda y los flujos afectados para verificar salida a cocina, reservación, inventario, cobro o impresión sin tráfico ni datos reales.
- [ ] Registrar resultado por ficha, perfil, ancho, fecha, versión y evidencia. La fase queda cerrada cuando sus comprobaciones pasen y cualquier excepción tenga una decisión documentada.

## 6. Los 84 criterios de RhToroV1

Los identificadores corresponden al ZIP de Suga. **Base** indica mecanismo comprobado por código. **Parcial** indica que el mecanismo existe con una brecha demostrable. **Corregir** indica una diferencia concreta. **Validar** indica que falta observar el comportamiento completo. **Proceso** y **Fuera de alcance** indican comprobaciones de ejecución o requisitos de un flujo que Timón no tiene. «Base» requiere la prueba de cierre en cada pantalla donde se use.

| ID | Criterio aplicado a Timón | Estado | Evidencia o comprobación |
|---|---|---|---|
| R1 | Armazón común y viewport | Base | Base del panel en `vistas/plantilla/base.php`. Revisar por ancho en fase 5. |
| R2 | Encabezado con icono, título y descripción | Base | `pb_modulo` ya lo genera. Comparar jerarquía calculada. |
| R3 | Acciones, filtros, tabla y tarjetas | Base | Las 27 pantallas usan `pb_tabla` con marcas de título, insignia y acciones; Reportes recibió `data-pb-titulo` el 17 nov 2026. Ver §7. |
| R4 | Componentes y estilos comunes | Parcial | `tema.css` conserva selectores de pantallas heredadas. Revisar usos antes de retirar, HT-09. |
| R5 | Librerías servidas en local | Base | Los includes del panel sirven Bootstrap, Iconos y plugins desde `/recursos/vendor/`. |
| R6 | Título de pestaña y favicon | Base | Plantilla común. Comprobar coincidencia tras renombrar Equipos del personal. |
| R7 | Menú con destinos reales | Base | Las 23 rutas se cotejaron contra `rutas/web.php`. |
| R8 | Descargas con estilo de contorno | Base | `pb_exportar` y acciones CSV/PDF de Reportes. |
| R9 | XLS en el encabezado de los listados aprobados | Base | XLS en Gastos, Reportes, Insumos, Proveedores, Kardex, Compras, Turnos y cortes, Sucursales, Personal, Equipos del personal, Avisos, Accesos, Bitácora y Privacidad. Ver §7. |
| R10 | Visibilidad y servidor concuerdan con el permiso | Validar | Atributos y middleware presentes. Probar cada combinación de permisos declarados. |
| R11 | Acción sensible con contexto y confirmación | Parcial | Retiro y cancelación usan modal. Agrupar gestión de cuenta y comprobar diferencias según estado. |
| R12 | Baja individual confirmada | Base | Personal y Sucursales tienen acciones individuales. |
| R13 | Equivalencia de botones con el sistema anterior | Fuera de alcance | La línea base funcional es Timón actual. |
| R14 | Etiquetas y Buscar/Limpiar filtro | Parcial | Helper estándar. Personal compone filtros de forma propia. Comparar comportamiento, no solo texto. |
| R15 | Buscar aplica la consulta | Parcial | El GET se envía con Buscar. «Limpiar filtro» es un enlace al estado inicial. Confirmar navegación y valores por defecto acordados. |
| R16 | Selector de rango con atajos | Corregir | Reportes, Avisos y Bitácora usan dos controles independientes, HT-06. |
| R17 | Exportar con los filtros aplicados | Corregir | Consulta duplicada reproducida en PHP, HT-01. |
| R18 | Conservar resultados tras error | Validar | Probar los flujos asíncronos y las respuestas de consulta al introducir filtros inválidos. |
| R19 | Buscar personas en servidor en catálogos amplios | Parcial | Bitácora carga la lista de quiénes desde el modelo. Definir búsqueda acotada si aplica al volumen. |
| R20 | Búsqueda por términos en cualquier orden | Validar | Verificar buscador de pantalla y consulta de servidor con palabras invertidas, acentos y mayúsculas. |
| R21 | Filtros limitados al alcance del usuario | Base | `Restaurante::pantalla()` filtra sucursales por identidad. Probar peticiones directas con otro alcance. |
| R22 | Históricos admiten baja y captura ofrece vigentes | Validar | Probar por separado Personal, Sucursales y los catálogos de captura relacionados. |
| R23 | Tabla y tarjetas equivalentes | Base | Tarjetas a 375 px sin desplazamiento horizontal y con las mismas acciones que la tabla en las pantallas recorridas. Ver §7. |
| R24 | Casilla, Acción y datos | Base | Acción aparece primero en las tablas principales que la incluyen. Revisar subtablas con gestión. |
| R25 | Texto e icono de la versión anterior | Fuera de alcance | Aplicar el estándar actual de enlace con icono útil dentro de Timón. |
| R26 | Orden inicial definido en servidor | Base | `order: []` y consultas con orden. Añadir desempate donde haga falta al paginar. |
| R27 | Orden del sistema anterior | Fuera de alcance | Seguir el orden de negocio documentado por ficha. |
| R28 | Paginación de alto volumen en servidor | Corregir | Límites sin navegación completa en Inventario, Gastos y Reservaciones. Doble control en Bitácora, HT-02. |
| R29 | Paridad de búsqueda y exportación | Parcial | Los XLS usan parámetros del servidor. La búsqueda local de DataTables tiene estado aparte, HT-06. |
| R30 | Conteo, indicadores y exportación del conjunto | Parcial | Los conteos de historiales limitados usan filas cargadas y las tarjetas de Reportes miden hoy, HT-02 y HT-05. |
| R31 | Cabeceras con el estilo compartido | Base | `pb_tabla` usa las clases de tabla de la plantilla. Verificar estilos calculados. |
| R32 | Fila verde para Realizado | Fuera de alcance | Usar los estados propios de cada flujo de Timón. |
| R33 | Resultado de importación masiva | Fuera de alcance | El panel revisado carece de este flujo. |
| R34 | Cerrar detalle conserva consulta, página y orden | Validar | `pb_detalle` abre sobre el listado. Probar cierre, actualización y enlace directo con filtro. |
| R35 | Datos visibles con nombres de catálogo | Parcial | Etiquetas de área y proveedor presentes. Reportes de cocina y agotados devuelven claves de preparación en la consulta. Distinguir claves de negocio como número de lote. |
| R36 | Ver y descargar archivos existentes | Fuera de alcance | Gastos captura una referencia del comprobante. Los QR y tickets tienen su propio flujo de documento. |
| R37 | Scroll interno y pantalla completa en móvil | Base | `pb_modal` y `pb_detalle` usan las clases de diálogo Bootstrap. |
| R38 | Formularios en secciones con encabezado y ayuda | Parcial | Hay `pb_seccion`. Varios modales de Restaurante usan solo rejilla, especialmente los de varios campos. |
| R39 | X de cierre y pie de operación | Base | Los modales comunes usan la X y su acción de guardado u operación. |
| R40 | Nombres accesibles en modal y cierre | Base | Helpers con `aria-labelledby` y `aria-label`. Comprobar unicidad de IDs. |
| R41 | Ver en solo lectura | Base | Ver abre `pb_detalle` de solo lectura en Áreas, Mesas, Reservaciones, Platillos, Impresoras, Gastos, Turnos, Insumos, Proveedores, Compras, Sucursales, Personal y Bitácora; todas responden 200. Ver §7. |
| R42 | Actualizar trae los datos desde servidor | Base | Actualizar pide el registro con `data-pb-registro-url` en Áreas, Mesas, Reservaciones, Platillos, Impresoras, Gastos, Insumos, Proveedores y Personal; todas responden 200. Ver §7. |
| R43 | Campos pertinentes y datos internos ocultos | Parcial | CSRF e identificadores de contexto viajan ocultos. Dar tratamiento de configuración a ruta de foto y parámetros técnicos de la impresora. |
| R44 | Ver el archivo ya cargado | Fuera de alcance | No convertir una referencia de comprobante ni una ruta de imagen en un cargador dentro de esta homologación. |
| R45 | Error dentro del modal | Base | `data-pb-error` y `data-error-for` en las piezas comunes. Probar 409 y 422 reales. |
| R46 | Calendario cabe y cierra junto con su modal | Validar | Comprobar en filtro y en caducidad de la compra en los tres anchos. |
| R47 | Confirmación identifica la operación y objetivo | Parcial | Varias confirmaciones de seguridad nombran el registro. Al retirar un equipo o cancelar una reserva se debe identificar el contexto con los datos necesarios. |
| R48 | Conservar todos los campos al pasar a modal | Proceso | Cotejar ficha, servicio y contrato antes del traslado. |
| R49 | Indicador con título y contexto de dimensión | Parcial | Reportes mezcla alcance del día y periodo, HT-05. |
| R50 | Acciones equivalentes en tarjetas | Validar | Revisar Ver y confirmaciones desde tarjeta, principalmente Compras, Lotes y Reservaciones. |
| R51 | Asterisco en obligatorios | Base | `pb_campo` genera un marcador de requerido. |
| R52 | Errores por campo | Base | `pb_campo` y JS común asignan error al nombre. |
| R53 | Validación comprensible en campos y selectores | Validar | Probar nativos y Select2, mensajes de negocio y foco al primer error. |
| R54 | Select con opciones de catálogo y clave válida | Base | Áreas, categorías, proveedores e insumos usan catálogos. Comprobar el alcance al enviar. |
| R55 | Opcionales identificados | Base | El helper agrega «(Opcional)» en captura. Revisar formularios que no usan el helper. |
| R56 | Fecha tecleada se consolida al salir del campo | Base | Existe `commitTypedDate` en el calendario común. Confirmar al introducir rangos en nuevas vistas. |
| R57 | Guardado con espera y protección de repetición | Base | JS de envío único y `#[Accion(unaVez: true)]` en operaciones del giro. Probar reintento y concurrencia. |
| R58 | Carga de archivos con arrastrar y soltar | Fuera de alcance | El giro captura referencias en Gastos y ruta de foto en Platillos. |
| R59 | Estado de carga legible en español | Base | Tabla con esqueleto y texto «Cargando» para asistencia. |
| R60 | Recuperación de fallo de carga inicial | Validar | Simular fallo de ficha o listado asíncrono y comprobar cómo se reintenta. |
| R61 | Error de conexión en español | Base | Interacción común de formularios y descargas. Simular caída de red. |
| R62 | Resultado de importación masiva | Fuera de alcance | El flujo no existe en el panel revisado. |
| R63 | Espera, progreso y cancelación de descargas largas | Validar | Revisar el modo común de XLS y el recorrido completo de Bitácora. |
| R64 | Respuestas controladas de sesión, permiso y validación | Base | Middleware y manejadores comunes. Probar con cada respuesta aplicable. |
| R65 | Fallo de descarga se anuncia en el panel | Base | `data-pb-exporta` utiliza el manejador compartido de descarga. Verificar CSV/PDF aparte. |
| R66 | Descarga trae el nombre del archivo | Base | Los controladores definen la descarga. Verificar nombre y formato en navegador. |
| R67 | «Exportar XLS» como texto común | Base | `pb_exportar` lo imprime. CSV, PDF y QR son formatos diferentes. |
| R68 | XLS respeta columnas y filtros | Base | El enlace XLS lleva los mismos filtros que el listado (periodo, sucursal, texto) y descarga XLSX en todas las pantallas que lo ofrecen. Ver §7. |
| R69 | Exportación autorizada en interfaz y servidor | Base | Bitácora separa el permiso de exportar. Confirmar todos los endpoints con perfiles limitados. |
| R70 | Comparar XLS contra sistema anterior | Fuera de alcance | Comparar contra los datos y las columnas del panel de Timón. |
| R71 | Filtros, modales y ancho adaptables | Base | Recorrido a 375 px con gerente: filtros plegados, modales a pantalla completa y ancho de documento igual al de la ventana. Ver §7. |
| R72 | Paginación móvil común | Validar | Repetir con tablas locales y paginación introducida en servidor. |
| R73 | Corte adaptable por necesidad | Parcial | La hoja heredada cambia la presentación bajo 992 px. Verificar la propuesta a 768 px con datos densos. |
| R74 | Probar a 1440, 768 y 375 px | Proceso | Cerrar cada ficha en los tres anchos. |
| R75 | Foco visible y navegación por teclado | Base | `tema.css` aplica `:focus-visible` y el plano escucha flechas. Validar el recorrido y retorno real. |
| R76 | Objetivos táctiles de 44 px | Validar | Hay reglas para controles táctiles. Medir enlaces de fila, cierre, paginación y plano. |
| R77 | Asociación de etiquetas y semántica de controles | Base | `pb_campo` genera etiqueta e ID único por pantalla. Revisar HTML manual, botones y enlaces externos. |
| R78 | Vocabulario uniforme | Parcial | Filtro y XLS comunes. Normalizar nombres de acciones, «Estado»/«Estatus» y textos de las fichas sin alterar su significado. |
| R79 | Tokens de color e iconos locales | Parcial | Peltre ya es la marca. Quedan detalles de CSS heredados y documentación de otro giro, HT-09. |
| R80 | Validar flujo por flujo | Proceso | Usar matriz de permisos y lista de cierre. |
| R81 | Revisión móvil con datos representativos | Proceso | Usar datos de prueba con nombres largos, varias páginas y todos los estados. |
| R82 | Probar un cambio global primero en un módulo | Proceso | Áreas es el piloto. |
| R83 | Hallazgos con referencia estable | Proceso | HT-01 a HT-10 documentan archivo y comprobación. |
| R84 | Textos en español, recursos locales y sin trazas de depuración | Validar | Verificar recursos, consola y textos durante las pruebas de navegador. |

### Fuentes

- **Suga.** ZIP `suga_homologacion_2026-11-05.zip` con `auditoria_ui_suga.md`, `guia_construccion_suga.md`, `plan_ejecucion_suga.md`, `plan_homologacion_ui_suga.md`, `propuesta_menu_subtitulos_acciones.md` y `mapa_pantallas/`. Se cotejó también la guía en la copia actual de Distribuidora, bajo `docs/homologacion/guia_construccion_suga.md`, junto con los listados de Clientes y Bodegas.
- **RhToroV1.** `AGENTS.md`, `docs/memoria/checklist_cierre_modulo.md`, `mtto/admin/catalogos/sucursales/views/listado.php` y `mtto/admin/viaticos/views/listado.php`.
- **Timón.** [Menú y permisos visibles](../vistas/plantilla/menu.php) · [Rutas y middleware](../rutas/web.php) · [Componentes](../vistas/partes/piezas.php) · [JavaScript común](../publico/recursos/plantilla.js) · [Marca y tokens](../marca/marca.md) · [Guía de textos](textos/guia-de-textos.md).

## 7. Registro de validación del 17 de noviembre de 2026

Entorno local, versión del árbol de trabajo del 17 nov 2026. Perfiles: gerente de sucursal de la demostración (base `timon`, 8080) y un administrador temporal de pruebas (base `timon_pruebas`, 8081). Anchos: 1440 y 768 px en la etapa 1 y 375 px en este recorrido.

| Pantalla | Perfil | Ancho | Resultado |
|---|---|---|---|
| Las 27 rutas del menú | Gerente y administrador | 375 | 200, título igual al menú, sin desplazamiento horizontal. Categorías, Accesos y Privacidad dan 403 al gerente, como su puesto |
| Turnos y cortes | Gerente | 375 | Ver muestra fondo, venta, descuentos, propinas, esperado, contado, diferencia, formas de pago y movimientos. El esperado cuadra con fondo + efectivo − retiros. XLS con periodo y sucursal |
| Compras | Gerente | 375 | **Corregido:** Recibir daba 500 (`compact()` dentro de una función flecha). Ahora abre con lo pendiente por renglón. Fechas con `pb_fecha`. Alta con varios renglones |
| Platillos | Gerente | 375 | **Corregido:** Ver daba 500 por la misma causa. Precios en lote y precio y disponibilidad por fila |
| Insumos y Proveedores | Gerente | 375 | **Agregado:** campo de búsqueda (sin acentos ni mayúsculas) y XLS con el mismo filtro |
| Recetas | Gerente | 375 | **Agregado:** filtro por platillo, que muestra su receta completa, y por renglón Actualizar cantidad y Quitar (cantidad cero, confirmado) |
| Lotes y Kardex | Gerente | 375 | Caducidad y fecha con `pb_fecha`, costo con `pb_dinero`. Kardex pagina en servidor y exporta lo filtrado |
| Gastos | Gerente | 375 | Ver, Actualizar y Cancelar por fila; XLS con periodo |
| Reservaciones | Gerente | 375 | Alta manual, Asignar mesa, Marcar atendida, No se presentó y Cancelar según estado |
| Faltantes | Gerente | 375 | Filtro por estado y vacío contextual |
| Reportes | Gerente | 375 | **Corregido:** la primera columna es el título de la tarjeta. CSV, PDF y XLS en contorno |
| Sucursales | Administrador | servidor | Ficha con horario semanal y lista de arranque completa (clave, horario, áreas, mesas, platillos con precio, impresoras, personal con PIN, equipos). «Horario público» se renombró «Horario de respaldo», como en el formulario |
| XLS de administrador | Administrador | servidor | Sucursales, Accesos, Privacidad, Bitácora y Personal descargan XLSX |

Decisión registrada: «Buscar» lleva estilo primario dentro del filtro. La regla de un primario aplica al encabezado, donde solo está «Agregar».

Candado nuevo: `ArquitecturaPrueba` rechaza `compact()` dentro de una función flecha.

Pendiente de este registro: el recorrido a 375 px con el administrador fue por servidor y no en el navegador.
