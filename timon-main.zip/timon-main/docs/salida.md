# Salida a Hostinger y EAS

## Preparación de una instalación

- Configure PHP 8.3, MariaDB 10.11 y un subdominio con HTTPS. El directorio público sirve `/`, `/panel`, `/app/`, `/menu/{sucursal}` y `/api/v1`. Fije `url_publica` al origen HTTPS para que los QR apunten al dominio correcto.
- Cargue las sucursales reales, sus claves públicas, planos, horarios, teléfonos de WhatsApp, direcciones, carta y precios. Agregue las URL HTTPS oficiales a `redes` en `config/giro.php` con las claves `Instagram`, `Facebook` o `TikTok`. La fotografía de portada es ilustrativa, generada con ImageGen. Cambie el archivo cuando haya fotografía propia.
- **Lo que la landing toma del panel**: el horario de cada día, «Abierto ahora», el teléfono, el WhatsApp (también el botón «Pídalo por WhatsApp»), la dirección con código postal y estado, las coordenadas de «Cómo llegar» y las especialidades marcadas en Platillos. Si una sucursal no captura coordenadas, «Cómo llegar» busca la dirección en el mapa. Lo que no capture no aparece; la página no inventa datos.
- **Lo que confirma el dueño antes de publicar**: si hay servicio a domicilio (la landing hoy dice «en su mesa o para llevar»), las fotos del salón y la galería (son ilustrativas), y el texto de «La casa». Con `URL_PUBLICA=https://dominio bash guiones/prepara-despliegue-subdominio.sh` las direcciones de `canonical`, Open Graph y JSON-LD salen absolutas; `robots.txt` y `sitemap.xml` usan `url_publica`.
- Prepare los perfiles y PIN, las áreas de impresión, las IP privadas y los anchos de rollo. Mantenga cocina e impresor en equipos dedicados.
- Verifique la revisión del aviso de privacidad antes de publicar el formulario de reservación. Configure correo operativo, respaldo cifrado y mantenimiento según las [instrucciones del paquete](../entregables/despliegue/INSTRUCCIONES-SUBDOMINIO.md).

## Publicación reproducible

Desde la raíz del proyecto, con PHP 8.3 y Node 24:

```sh
npm ci
npm --prefix app ci
node guiones/genera-marca.mjs --verifica
npm --prefix app run tipos
npm --prefix app run web
PB_ESQUEMA_AISLADO=1 pruebas/todo.sh
bash guiones/prepara-despliegue-subdominio.sh
```

La última orden incluye la exportación web en `app/` y produce el paquete del subdominio y su hash. Si se ejecuta sin una exportación disponible, genera el paquete PHP sin la PWA. La app estática se actualiza al publicar el directorio completo de la misma exportación.

En una instalación existente, obtenga un respaldo recuperable, verifique su restauración y aplique solo los pendientes con `guiones/migraciones.php`. El SQL consolidado va destinado a una base nueva. Compruebe `/api/v1/salud`, el esquema, la liberación, el panel y las rutas públicas. Retire los archivos de instalación al terminar y pruebe las tareas programadas desde el hospedaje.

## App nativa

- Configure `EXPO_PUBLIC_API_URL` con el origen HTTPS del subdominio en los perfiles de EAS. Para la verificación local, el simulador de iPad usa el origen de la máquina de desarrollo. Las pruebas Android se realizan manualmente en dispositivos físicos, incluido el equipo impresor.
- Vincule el proyecto con `eas init` y habilite actualizaciones con `eas update:configure` desde `app/`. Esta vinculación depende de la cuenta y el proyecto de EAS del negocio.
- Use `eas build --profile piloto --platform android` para el APK, y `eas build --profile piloto --platform ios` para una compilación interna iOS con sus dispositivos aprovisionados. Las funciones nativas de SQLite cifrado y ESC/POS requieren su propio binario.
- **Staging**: el perfil `staging` de `app/eas.json` fija `EXPO_PUBLIC_API_URL` en `https://staging-timon.verticesoftware.com.mx`, con su canal `staging` y APK interno. Compile con `eas build --profile staging --platform android` (o `ios`). Ese binario solo se instala en equipos de prueba, nunca en los que operan con producción. Comparte el identificador `mx.verticesoftware.eltimon` con los demás perfiles, así que no convive con la app de producción en el mismo equipo. La configuración del sitio de staging en Hostinger está en [staging.md](staging.md).
- `eas update` no lee el `env` del perfil de compilación. En SDK 57 exige `--environment`: registre el origen en `EXPO_PUBLIC_API_URL` del entorno de EAS **preview**, compruebe solo esa variable con `eas env:get preview --variable-name EXPO_PUBLIC_API_URL --scope project --non-interactive --format short` y publique staging con `eas update --channel staging --environment preview`. Anteponer una variable local no sustituye esa configuración. [Variables para EAS Update](https://docs.expo.dev/eas/environment-variables/usage/).
- Para el canal piloto use también `--environment` con el entorno de EAS que tenga el origen del piloto y verifique primero su valor. Vuelva a compilar cuando cambien plugins, permisos o dependencias nativas. La exportación web se genera con `npm run web` desde `app/`. [Publicación web de Expo](https://docs.expo.dev/guides/publishing-websites/) · [SQLite en Expo](https://docs.expo.dev/versions/v57.0.0/sdk/sqlite/)

## Autoría y nuevas compilaciones (2026-11-19)

El sistema pertenece a **Vértice Software**. Android e iOS usan `mx.verticesoftware.eltimon`, definido en `app/app.json`; los proyectos nativos locales se sincronizaron con ese identificador. El cambio requiere una compilación completa, no una actualización OTA. Si ya hay una instalación con el identificador anterior, la nueva se instala por separado; registre y autorice su equipo de nuevo. Conserve la instalación anterior hasta resolver cualquier captura local pendiente. El nombre comercial del restaurante sigue siendo El Timón.

La PWA mantiene su dominio y registro de navegador. La actualización de autoría del panel se entrega como un parche sin migraciones ni cambios de configuración privada.

## Carta impresa y promociones (2026-11-18)

1. Aplique el guion `024_carta_y_promociones.sql` con `guiones/migraciones.php --aplicar --acepto=<base>`. Agrega leyenda por categoría, porción y orden por platillo, las promociones y el permiso `promocion_admin` para administrador y gerente.
2. Publique la app con `eas update` antes de dar de alta la primera promoción. Una app anterior suma el mostrador por su cuenta y su cobro se rechaza mientras haya una promoción vigente.
3. Si el dueño lo pide, cargue la carta de su PDF en una sucursal: primero `guiones/carga-carta.php --sucursal=<clave>` para ver lo que agregaría y después con `--aplicar`. Solo agrega lo que falta; nunca borra ni cambia precios.
4. Confirme con el dueño, antes de imprimir:
   - El cóctel grande ($145) cuesta menos que el mediano ($200).
   - El tarro michelado o chelado a $15.
   - Si los tamaños de cóctel son platillos aparte (así están cargados) o modificadores de un solo cóctel.
   - Los nombres que se repetían en Camarones y Filetes («Talla», «Mojo»…) se cargaron completos para que cocina no los confunda. Puede acortarlos en Platillos.
5. Pida al dueño el diseño original de su carta (Canva o su diseñador). Las ilustraciones de la hoja (`publico/recursos/carta/`) son recortes de su PDF y pierden calidad al imprimir en grande. Al tenerlo, reemplace los archivos con el mismo nombre.
6. Revise en **Carta → Textos del pie** el año de fundación, la frase del encabezado, el lema, la advertencia y las formas de pago. Las redes salen de `config/giro.php`; los teléfonos y la dirección, de la sucursal.

## Computadora de la sucursal (operación sin internet)

1. Aplique el guion `025_servidor_sucursal.sql` al central con `guiones/migraciones.php --aplicar --acepto=<base>` y suba el código. Después agregue `config/instalacion.php` con `return ['tipo' => 'central'];`.
2. Compre o asigne la computadora (mini PC con Linux o la PC de caja con Docker Desktop), reserve su IP en el módem y conéctela con la impresora y el módem a un no-break.
3. Siga [`servidor-sucursal.md`](servidor-sucursal.md): registro en **Operación local**, `guiones/instala-sucursal.sh` y la autoridad en cada equipo.
4. Publique un build nuevo de EAS: cambia la parte nativa (dirección de la sucursal y confianza en su autoridad).

## Actualizaciones remotas

La [guía de actualizaciones](servidor-sucursal.md#actualizaciones) cubre el par Ed25519, la liberación firmada con PWA/APK, las migraciones 026–027, la asignación por sucursal y el regreso por fallo de salud. Prepare primero el central de staging; no registre el piloto contra producción. El usuario dejó pendiente el acceso al equipo por Tailscale y pidió preparar la instalación. La [alternativa Synology](../despliegue/synology/README.md) incluye reconocimiento sin cambios y Web Station cuando no haya Docker; no se ha validado en DSM.

### App: dos vías Android y distribución iPad

En Ajustes se muestra versión, canal e id de actualización, y **Buscar actualización**. Una actualización descargada se aplica cuando la persona lo decide, después de terminar sus capturas. La app nativa tiene `runtimeVersion` con política `appVersion`, `checkAutomatically: ON_LOAD` y `fallbackToCacheTimeout: 0`, para abrir con su copia guardada sin esperar internet. Los cambios de plugins/SDK requieren subir `expo.version`, construir otro binario y probarlo; una OTA solo llega a los binarios con el mismo runtime. [Referencia de Expo Updates](https://docs.expo.dev/versions/v57.0.0/sdk/updates/).

Desde `app/`, compruebe el origen en el entorno EAS correspondiente y use:

```bash
# Ensayo con el entorno preview que tiene el origen de staging.
eas update --channel staging --environment preview --message "Prueba de actualización"
# Piloto y producción usan el entorno que tenga el origen autorizado.
eas update --channel piloto --environment production --message "Versión piloto"
eas update --channel produccion --environment production --message "Versión aprobada"
```

El APK de staging solo se instala en equipos de ensayo. La app permite registrar el origen local de la sucursal; el canal de OTA sigue siendo el del build, aunque cambie ese origen. El piloto debe comprobar la CA local en el binario real. La publicación y recepción de estas OTA quedan pendientes de la prueba en tableta.

- **Google Play:** prepare la cuenta Play Console, la ficha y la distribución privada o la prueba cerrada con su lista de usuarios. `eas build --profile produccion --platform android` genera el binario para tienda; `eas submit --profile produccion --platform android --latest` está preparado para la pista **interna** como primer ensayo. Configure en Play la pista y audiencia definitivas antes de promover. La primera alta puede exigir una carga manual en Play. Las credenciales de servicio quedan fuera de Git. La publicación no se ha ejecutado.
- **APK propio:** construya con `eas build --profile piloto --platform android`, descargue el APK firmado e inclúyalo en `prepara-liberacion-sucursal.sh` junto con la mínima compatible. `/api/v1/salud` declara `app_minima`, `app_version` y `apk`; **Descargar APK** abre el archivo servido por esa computadora, sin depender de internet. Después se abre el archivo descargado y Android muestra su instalador. Cada equipo autoriza una vez instalar desde ese navegador. Compruebe la compatibilidad de firmas con Play antes de alternar vías.
- **iPad:** use `eas build --profile produccion --platform ios` y distribuya mediante TestFlight o App Store no listada, con la cuenta Apple del negocio. EAS Update usa el mismo mecanismo de runtime/canal. La distribución de tienda y su recepción quedan pendientes.

Una app anterior a la mínima muestra una pantalla de actualización en vez de abrir la operación. No eleve la mínima hasta que el binario compatible esté realmente disponible en Play/TestFlight o en el APK del paquete asignado.

## Piloto de una sucursal

1. Prepare una sala y al menos dos equipos de comanda, caja en PC, cocina en tableta y el impresor Android. Abra la misma mesa desde dos equipos y mida cuánto tarda el segundo en verla.
2. Envíe una ronda con modificadores a cocina y barra. Verifique la hora, el detalle y el rollo. Interrumpa la conexión de la impresora durante más de 20 segundos y compruebe el aviso y la reimpresión. El estado «impreso» confirma el envío TCP al equipo térmico. Revise también el papel en la impresora.
3. Capture un platillo sin red y recupere la conexión. Verifique que el pendiente se aplica una sola vez y que las operaciones de mesa piden conexión.
4. Abra turno, cobre un ticket de prueba con pago mixto, revise la impresión desde Windows, cuadre el cierre y compruebe existencias y reportes.
5. Complete una reservación y un pedido para llevar o a domicilio. Verifique los enlaces y el menú QR de la sucursal.
6. **Sin internet:** desconecte el cable de internet del módem durante un servicio de prueba. Abra mesa, envíe a cocina, imprima, cobre y haga el corte. Reconecte y confirme en **Operación local** que «Por subir» llega a 0 y que el corte se ve igual en el central.
7. Registre latencia, errores, límites de procesos del hosting, recepción de alertas y respaldo recuperable. Confirme el piloto con el personal antes de operar ventas reales.

La prueba local concurrente vive en `pruebas/humo-comanda.py`. Verifica adquisición por única cuenta, reintentos, cobro, cocina, avisos de impresión, reimpresión en un receptor TCP local, FEFO y diez clientes en paralelo. La prueba no mide la red ni los equipos del restaurante.
