# Staging de El Timón en Hostinger

Subdominio de pruebas: **`staging-timon.verticesoftware.com.mx`**. Ahí se prueba cada versión de El Timón antes de pasarla a producción (`timon.verticesoftware.com.mx`, más adelante). Staging y producción **nunca comparten base de datos ni configuración**.

La instalación de la aplicación sigue el procedimiento del propio proyecto: [`entregables/despliegue/INSTRUCCIONES-SUBDOMINIO.md`](../entregables/despliegue/INSTRUCCIONES-SUBDOMINIO.md). Esta guía cubre lo que se hace en hPanel y lo que cambia por ser staging.

## Las tres partes de El Timón en staging

El Timón sirve todo desde **un solo subdominio**, así que un staging cubre las tres partes a la vez, con la misma base de datos de pruebas:

| Parte | Dirección en staging | Cómo llega a staging |
|---|---|---|
| **Landing** (sitio público, menú QR y reservaciones) | `https://staging-timon.verticesoftware.com.mx/`, `/menu/{sucursal}`, `/aviso-privacidad` | Viaja en el paquete (`sitio/`). Los QR apuntan a staging porque se arman con `url_publica`. |
| **Panel administrativo** | `https://staging-timon.verticesoftware.com.mx/entrar` → `/panel` | Viaja en el paquete (PHP). |
| **App de comanda (web/PWA)** para las PC con Windows | `https://staging-timon.verticesoftware.com.mx/app/` | Viaja en el paquete si antes se corrió `npm --prefix app run web`. Usa el mismo origen, así que habla sola con la API de staging. |
| **App de comanda nativa** (Android, iPad) | Llama a `https://staging-timon.verticesoftware.com.mx/api/v1` | **No viaja en el paquete.** El perfil `staging` sugiere este origen con `EXPO_PUBLIC_API_URL`; al registrar el equipo se confirma la dirección (ver paso 7). |

Una versión nueva se prueba completa en staging (landing, panel y apps) y solo entonces se pasa a producción.

## 1. Crear el staging como sitio web aparte

Hostinger no acepta subdominios de dos niveles (`staging.timon…` da «Multi-level subdomains are not supported» y «Domain has too many subdomain levels»). Por eso el staging usa un solo nivel: `staging-timon`. Se da de alta como **sitio web propio** (el plan permite sitios ilimitados), para que tenga su carpeta separada de la landing:

1. hPanel → **Sitios web → Agregar sitio web** → **Sitio web PHP/HTML**.
2. En «¿Qué dominio o subdominio te gustaría utilizar?», escribe `staging-timon.verticesoftware.com.mx`. No compres nada ni uses el dominio gratis.
3. Servidor: el mismo de la landing (Estados Unidos, Carolina del Norte).

El sitio queda con su propia carpeta `public_html` (`~/domains/staging-timon.verticesoftware.com.mx/public_html`), separada de cualquier otro sitio de la cuenta. Esa carpeta es la «carpeta del subdominio» de las instrucciones de El Timón.

Si después de unos minutos no abre, revisa el DNS de `verticesoftware.com.mx`: debe existir un registro **A** con nombre `staging-timon` que apunte a la misma IP que el registro A de `@`.

## 2. SSL

**Seguridad → SSL** (dentro del sitio nuevo): `staging-timon.verticesoftware.com.mx` debe aparecer como **Activo**. Si no aparece o dice pendiente, instálalo desde ahí y espera unos minutos; el DNS tiene que responder antes de que se emita.

## 3. PHP 8.3

**Avanzado → Configuración de PHP** → versión **8.3**. Si la pantalla deja elegir sitio o subdominio, asegúrate de estar en el sitio `staging-timon.verticesoftware.com.mx`. Revisa que estén activas las extensiones que pide `verifica-host.php`: `mysqli`, `mbstring`, `gd`, `curl`, `json`, `openssl`, `fileinfo`, `sodium` y `zlib` (y `exif`, recomendada para las fotos).

## 4. Base de datos propia de staging

1. **Bases de datos → Administración de bases de datos**.
2. Dentro del sitio `staging-timon…`, crea la base `timon_staging` con su usuario `timon_staging`. hPanel les antepone el prefijo de la cuenta (`u123456789_…`): guarda los nombres completos.
3. Genera una contraseña fuerte y guárdala en tu gestor de contraseñas. Solo se escribe en `.app/config/bd.php` del servidor.
4. Desde phpMyAdmin de esa base vacía, importa `app-esquema.sql` (paso «Base mediante hPanel y phpMyAdmin» de las instrucciones de El Timón). Verifica la cantidad y los nombres contra `app-esquema.sql.json` del mismo candidato: el esquema 25 declara **62 tablas y 25 guiones**. No vuelvas a importar si ya hay tablas.

## 5. Acceso SSH

**Avanzado → Acceso SSH** → actívalo y anota host, puerto y usuario. Las órdenes `php .app/guiones/…` de la instalación se ejecutan por SSH, desde la carpeta del subdominio.

## 6. Generar el paquete y subirlo

En la computadora, desde la raíz de El Timón y con PHP 8.3 y Node 24:

```bash
export PATH="/opt/homebrew/opt/php@8.3/bin:/opt/homebrew/opt/node@24/bin:$PATH"
npm --prefix app run web
URL_PUBLICA=https://staging-timon.verticesoftware.com.mx bash guiones/prepara-despliegue-subdominio.sh
```

Copia a `entregables/despliegue/subir-staging/` (fuera de Git) los archivos que se suben:

- `app-bloqueo-instalacion.htaccess`
- `app-subdominio-candidato.tar.gz`
- `app-subdominio-candidato.tar.gz.sha256`

Súbelos por **SFTP** (FileZilla o Cyberduck, con los datos del acceso SSH) a la carpeta del sitio. Después, por SSH y dentro de esa carpeta, primero el bloqueo y luego el paquete:

```bash
sha256sum -c app-subdominio-candidato.tar.gz.sha256
```

Continúa solo si la huella coincide:

```bash
rm -f default.php && mv app-bloqueo-instalacion.htaccess .htaccess && tar -xzf app-subdominio-candidato.tar.gz && rm app-subdominio-candidato.tar.gz app-subdominio-candidato.tar.gz.sha256 && ls -A
sha256sum -c .app/instalacion/MANIFIESTO-SHA256.txt --quiet && php .app/guiones/verifica-host.php
```

La base se importa desde SSH con el SQL que ya trae el paquete (o desde phpMyAdmin con `app-esquema.sql`):

```bash
mysql -h localhost -u USUARIO_COMPLETO -p BASE_COMPLETA < .app/instalacion/app-esquema.sql
```

Luego siguen la configuración privada, el primer administrador y la activación de `.htaccess.app`, como dicen las instrucciones de El Timón.

En una **actualización** el procedimiento cambia: no se borra ni reemplaza `.app/config/*.php` ni `.app/almacenamiento/`, y la base se actualiza con `migraciones.php` después de un respaldo verificado.

## 7. Lo que cambia por ser staging

- En `.app/config/app.php`: `url_publica` = `https://staging-timon.verticesoftware.com.mx` y `entorno` = `produccion` (staging debe portarse igual que producción: HTTPS, cookies seguras, sin depuración).
- **Fuera de Google**: como sitio aparte, el staging no hereda el `.htaccess` de la landing. Al activar `.htaccess.app`, agrega al inicio del `.htaccess` del staging:

  ```apache
  <IfModule mod_headers.c>
      Header always set X-Robots-Tag "noindex, nofollow"
  </IfModule>
  ```

  y sube un `robots.txt` con `User-agent: *` y `Disallow: /`. Se repite en cada actualización que reemplace el `.htaccess`.
- **Datos de prueba**, nunca datos reales de clientes ni de ventas.
- Las claves de `seguridad.php` y `respaldo.php` se generan **aparte** para staging; no se copian a producción.
- Respaldo cifrado, cron y alertas: opcionales en staging. Las alertas esperan a que exista el correo del dominio.
- **App nativa**: `app/eas.json` de El Timón ya tiene el perfil `staging`:

  ```json
  "staging": {
    "environment": "preview",
    "distribution": "internal",
    "channel": "staging",
    "android": { "buildType": "apk" },
    "env": { "EXPO_PUBLIC_API_URL": "https://staging-timon.verticesoftware.com.mx" }
  }
  ```

  Desde `app/`, se compila con `eas build --profile staging --platform android` (y `ios` para el iPad). Para actualizaciones compatibles con ese binario, SDK 57 exige un entorno de EAS: registra `EXPO_PUBLIC_API_URL=https://staging-timon.verticesoftware.com.mx` como variable pública del entorno **preview** en el proyecto de Expo, comprueba solo esa variable con `eas env:get preview --variable-name EXPO_PUBLIC_API_URL --scope project --non-interactive --format short` y publica con `eas update --channel staging --environment preview`. El canal se llama `staging`; el conjunto de variables se llama `preview`, como declara `eas.json`. No basta con anteponer una variable local ni con el `env` del perfil de build. [Documentación de Expo](https://docs.expo.dev/eas/environment-variables/usage/).

  La app nativa actual permite confirmar o cambiar el servidor al registrar el equipo: revisa que siga siendo staging. Una compilación de staging **nunca** se instala en los equipos que operan con producción. Si se quiere tener ambas en el mismo equipo, la de staging necesita otro identificador de app. Un cambio de plugins o de confianza en certificados requiere **otro build**, no solo una actualización.
- **App web/PWA**: si se instaló en una PC desde staging, queda ligada a staging; para producción se instala de nuevo desde `timon.verticesoftware.com.mx/app/`.
- Para actualizar staging con una versión nueva se usa el mismo procedimiento de actualización (bloqueo, subida sin borrar `.app/config` ni `almacenamiento`, migraciones con respaldo).

## 8. Comprobación

```bash
curl -sI https://staging-timon.verticesoftware.com.mx/entrar | grep -iE "^HTTP|x-robots"
curl -o /dev/null -sS -w '%{http_code}\n' https://staging-timon.verticesoftware.com.mx/.app/config/bd.php
curl -sI https://verticesoftware.com.mx | grep -i content-security-policy
```

- `/entrar` responde **200** y trae `x-robots-tag: noindex, nofollow` (lo agrega el `.htaccess` del staging, paso 7).
- La landing (`/`), un menú QR (`/menu/{sucursal}`), la app web (`/app/`) y `/api/v1/salud` cargan desde staging.
- `/.app/config/bd.php` responde **403 o 404**, nunca 200.
- La landing sigue enviando su `content-security-policy`.

Al final, desde `Timon/`: `bash pruebas/publicacion.sh https://staging-timon.verticesoftware.com.mx entregables/despliegue/app-subdominio-candidato.tar.gz`.

La comprobación ampliada incluye esa compuerta y además exige `noindex`/`nofollow` en las páginas públicas, el bloqueo global de robots, menús con platillos, recursos de la PWA coincidentes con el candidato y la CSP de la landing principal. En los PNG compara dimensiones y píxeles con GD de PHP 8.3: el CDN puede recomprimirlos sin cambiar su imagen.

```bash
python3 pruebas/staging.py https://staging-timon.verticesoftware.com.mx entregables/despliegue/app-subdominio-candidato.tar.gz
```

Para consultar acceso, permisos y alcance de las cuentas de demostración, usando el archivo privado local sin imprimir claves:

```bash
python3 pruebas/staging-personal.py https://staging-timon.verticesoftware.com.mx almacenamiento/credenciales-demostracion.txt
```

`pruebas/staging-comanda.py` es una prueba distinta: **escribe en staging**.
Con `--ejecutar` crea tres equipos, abre una mesa desde dos equipos a la vez,
envía un platillo a cocina y cobra un ticket de demostración. Retira sus equipos
y libera la mesa al terminar; el cobro y su bitácora se conservan. Se ejecuta
solo con autorización expresa para esa venta simulada. No imprime en hardware
ni sustituye el piloto del restaurante.

El estado y los límites de la validación están en [validacion-staging-2026-11-18.md](validacion-staging-2026-11-18.md).

⚠️ Nunca ejecutes `pruebas/todo.sh`, `guiones/prepara-pruebas.php` ni `guiones/aplica-esquema.php` contra el servidor.

Si un cambio no se ve, purga la caché del CDN en hPanel (**Rendimiento → CDN**).
