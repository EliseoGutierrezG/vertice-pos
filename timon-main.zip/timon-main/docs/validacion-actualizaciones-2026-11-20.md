# Validación local de actualizaciones remotas

Fecha: 20 de noviembre de 2026, America/Mexico_City. Proyecto: copia de Downloads/Proyectos/Timon, rama `main`, con cambios preexistentes conservados. Se retomó el plan adjunto de Claude sobre servidores de sucursal y apps. El usuario indicó que aún no está disponible el acceso por Tailscale y pidió dejar preparada la instalación.

## Resultado

Implementación local y candidato firmado preparados. No se ejecutaron commits, publicaciones EAS, envíos a tiendas ni despliegues remotos. La base cotidiana `timon` y producción no se modificaron. Las pruebas reconstruyeron exclusivamente bases locales aisladas.

| Comprobación | Resultado |
|---|---|
| Suite integral `PB_ESQUEMA_AISLADO=1 APP_ENTORNO=pruebas pruebas/todo.sh` | Todo pasa; 516 internas, humo web/API/identidad/organización/personal/comanda/sucursal, seguridad, respaldo/restauración, mantenimiento, paquetes y cierre local del host |
| `npm --prefix app run tipos` | Pasa |
| `npm --prefix app run web` | Exportación completa y preparación PWA correctas |
| Compatibilidad de versiones de la app | 2 casos Node; compara numéricamente versiones como 1.9.0 y 1.10.0 |
| Esquema | Migraciones hasta 027 comprobadas en bases de pruebas, sin editar migraciones aplicadas |
| Paquete firmado | Firma Ed25519, peso, SHA-256, instalación inicial temporal y manifiesto completo verificados |
| Revisión PWA en navegador | Ajustes, búsqueda y aplicación de actualización; 375 × 812, 812 × 375 y 1440 × 900 |
| Formularios del panel | Subir y asignar versión revisados con la plantilla real y datos ficticios, sin enviar formularios ni cambiar instalaciones |

La primera corrida integral detectó reglas de auditoría, reloj, índice y textos; se corrigieron y se repitió la suite completa. El índice se agregó en 027, sin modificar 026. No quedan fallas en la corrida final. El sandbox necesitó autorizar conexiones a MariaDB/HTTP locales; las comprobaciones siguieron limitadas a pruebas.

## Ajuste Synology del 21 de noviembre

El NAS de prueba respondió con PHP 8.2.30 y las extensiones requeridas. Se ajustó el mínimo del reconocimiento y del diagnóstico a PHP 8.2, sin cambiar PHP 8.3 como estándar de desarrollo y central. Con PHP 8.2.34 local, `guiones/verifica-host.php` pasó y las **516 pruebas internas** pasaron sobre `timon_pruebas`; después, la suite integral actual volvió a terminar en verde. Se generó el paquete firmado **20261121T060551Z-5582dbf09319**, comprobado con su llave pública, SHA-256 y tamaño. La configuración del portal real sigue pendiente de un administrador DSM.

## Ensayo entre dos servidores locales

`pruebas/humo-sucursal.py` ahora incluye `pruebas/actualizaciones-sucursal.py` y comprueba:

1. Operación completa con central apagado: mesa, ronda, cocina, impresión simulada, cobro y corte.
2. Al volver el central, la operación sube una sola vez. Con esquema local atrasado sigue subiendo, conserva el catálogo anterior y muestra la espera; al recuperar el esquema baja el catálogo.
3. La descarga exige la llave de instalación, rechaza una versión no asignada y sirve `Range`, incluido el byte cero.
4. Con cuenta abierta descarga el paquete y espera sin mover `actual`.
5. Con todo cerrado instala N+1, genera respaldo cifrado, migra, rehace disparadores y comprueba salud por HTTP con el id nuevo.
6. Si N+2 devuelve una salud incorrecta, regresa el enlace y confirma por HTTP N+1. Se vacía la caché de rutas al cambiar el enlace; Docker recibe una señal de recarga que distingue incluso cambios en el mismo segundo.
7. La descarga local de APK funciona. El binario usado por esta prueba es **ficticio y no instalable**; no sustituye un ensayo Android físico.
8. La bitácora central conserva su integridad.

El candado compartido de peticiones y réplica impide migrar mientras una operación está en curso. Las peticiones nuevas reciben un conflicto reintentable durante la instalación; salud sigue disponible. La ventana segura se revalida dentro del candado exclusivo.

## Entrega

[Instrucciones del candidato y evidencias](../entregables/actualizaciones-2026-11-20/ENTREGA.md). La llave privada se generó fuera del repositorio en `~/.timon/firma-liberaciones.llave`, con permisos 0600. No se imprime ni se incluye en los paquetes; el dueño debe resguardar su copia. La pública es `config/firma-liberaciones.pub`.

## Pendiente externo

- Reconocimiento e instalación del equipo real por Tailscale. No se conoce aún su sistema, modelo, paquetes ni arquitectura.
- Construcción/arranque real de Docker o configuración de Web Station. Esta Mac no tiene Docker. La [guía Synology](../despliegue/synology/README.md) es preparación, no certificación de DSM.
- Corte físico de internet y actualización N → N+1 desde staging en ese equipo, sin tocar el sistema existente de `/vertice-pos/`.
- APK real con el mismo certificado de firma, confianza en la CA local, impresoras y uso en tabletas/Windows/iPad.
- Cuentas y distribución privada/cerrada de Google Play, TestFlight/App Store y recepción de EAS Update en dispositivos. Se prepararon los flujos, no se publicaron.
- Compatibilidad con el código anterior de cada migración futura. El regreso automático cambia el código y conserva la base migrada; no revierte DDL ni datos.

No se certificaron lector de pantalla, tamaño máximo de texto del sistema, modo oscuro nativo ni hardware. La evidencia del navegador corresponde a la PWA.
