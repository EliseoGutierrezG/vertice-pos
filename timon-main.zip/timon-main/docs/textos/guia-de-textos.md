# Guía de textos

Cómo se escribe todo lo que ve la gente en la web, la app y los mensajes del sistema.

La gente no se detiene a leer. Cada texto tiene que servir para actuar, o no va.

**Estado:** vigente. Viene de la plantilla de Distribuidora y la hace cumplir `pruebas/TextosPrueba.php`; la forma de armar pantallas está en la [guía de pantallas](../guia-pantallas.md).

## Reglas

| # | Tipo | Regla | Bien |
|---|---|---|---|
| R1 | Trato | **Usted** en todo. Botones y títulos no llevan trato | «Seleccione una mesa» |
| R2 | Botón | Infinitivo y objeto, 3 palabras o menos | «Cerrar día» |
| R3 | Título o etiqueta | Nombra el tema, 4 palabras o menos. No repite el botón ni lleva punto | «Entrada pendiente» |
| R4 | Error | Qué pasó y qué hacer, 10 palabras o menos. Junto al campo y sin culpar | «La foto no se subió. Intente de nuevo» |
| R5 | Éxito | El hecho, 4 palabras o menos. Solo se agrega lo que falta por hacer | «Persona creada. Falta su usuario.» |
| R6 | Vacío | «Sin X» si hay filtro o fecha, «Aún no hay X» si nunca hubo. Una línea | «Sin cargas en esta fecha» |
| R7 | Confirmación | La pregunta y solo la consecuencia irreversible, 12 palabras o menos | «¿Concluir? Descuenta inventario y no se repite.» |
| R8 | Pista o aviso | 8 palabras o menos, solo si evita un error o avisa algo irreversible | «Capture 0.16 para 16%» |
| R9 | Jerga | Sin términos técnicos que la gente no usa | «Mapa no disponible», no «cliente HTTPS» |
| R10 | Vocabulario | Una palabra por concepto y un verbo por acción | Ver el glosario |
| R11 | Ortografía | Acentos completos y «solo» sin tilde | |
| R12 | Mayúsculas | Normales. Si un diseño las pide, se hace con estilo, no escribiendo el texto así | «Total estimado» |
| R13 | Datos personales | Antes de pedirlos, se dice qué se pide y para qué | «Selfie, hora y ubicación para registrar su entrada.» |
| R14 | Subtítulo de pantalla | Obligatorio. Frase nominal de una línea, con punto, 16 palabras o menos. El texto aprobado está en la ficha de la pantalla | «Sucursales del negocio, con su dirección, teléfono y personal activo.» |

Las explicaciones de «para qué sirve» o «cómo funciona» no van en pantalla: van al documento de explicaciones.

## Lo que no se recorta

- El aviso de privacidad, que está en revisión legal.
- El aviso de ubicación en segundo plano y el de selfie, antes de pedirlas: deben decir para qué se usan.
- La contraseña temporal y los códigos de recuperación: deben decir que no se vuelven a mostrar.
- Las etiquetas para lector de pantalla, que pueden ser más largas para no perder contexto.
- La landing es publicidad: lleva el mismo trato, pero no el tope de palabras.

## Glosario

| Use | En lugar de | Nota |
|---|---|---|
| Contraseña | Clave | Para entrar al sistema. «Clave» queda para la clave del día y las claves SAT |
| Teléfono | Dispositivo, equipo, celular | |
| Negocio | Comercio, tienda | El lugar. «Cliente» es a quien se le vende |
| Casco | Envase, envase retornable | ⚠️ Por confirmar |
| Mínimo | Piso | |
| Unidad | UMV, unidad mínima | ⚠️ Por confirmar |
| Estatus | Estado, en un registro | «Estado» queda para la entidad federativa |
| Bodega | Almacén, como lugar | «Almacén» queda para la función: salida de almacén |
| Bajar | Descargar, en la app | «Descargar» es para archivos |
| Subir | Sincronizar, enviar | |
| Entrar | Iniciar sesión, ingresar | «Cerrar sesión» se queda |
| Ver | Consultar, abrir detalle | |
| Seleccione | Elija | En los `select` y las listas (homologación T7, 2026-11-05) |
| Capture | Escriba, ingrese | En el texto libre. «En captura» sigue como estado |
| Intente de nuevo | Vuelva a intentar | El botón dice «Reintentar» |

**Verbos que no son sinónimos:**

- **Agregar** a una lista, **Guardar** lo que se edita, **Registrar** lo que ya pasó.
- **Autorizar** es el permiso de otra persona, **Validar** es revisar que un dato sea correcto.
- **Cerrar** día, turno y liquidación, **Concluir** solo la carga, **Terminar** una promoción o una edición.

## En qué se basa

Está **basada en** estas referencias. No es una certificación de cumplimiento.

| Referencia | Qué se toma | Comprobado |
|---|---|---|
| [ISO 24495-1:2023](https://www.iplfederation.org/iso-standard/), lenguaje claro | Lo que se lee debe ser [relevante, fácil de encontrar, comprensible y utilizable](https://perspectives.iiid.net/iso-plain-language-standard/) | Sus principios, por fuentes secundarias. La norma es de pago |
| [ISO 9241-110:2020](https://www.standards.govt.nz/shop/ISO-9241-1102020), interacción | Marco de coherencia entre pantallas | Solo su alcance |
| [WCAG 2.2, criterio 3.3.1](https://w3c.github.io/wcag/understanding/error-identification.html), y [3.3.2 y 3.3.3](https://www.w3.org/WAI/WCAG20/Understanding/input-assistance) | Señalar el error en texto, etiquetar y sugerir la corrección | Sí |
| [Nielsen Norman Group](https://www.nngroup.com/articles/error-message-guidelines/) | Forma de los mensajes de error | Sí |
| [Manual de Lenguaje Ciudadano](https://inmujeres.wdinamo.com/308-escritorio/pdf/complementarias/lenguaje_ciudadano.pdf) | Lenguaje claro en México | Sí |
| [RAE](https://www.rae.es/espanol-al-dia/el-adverbio-solo-y-los-pronombres-demostrativos-sin-tilde) | «solo» sin tilde | Sí |

Ninguna de estas normas elige entre usted y tú: piden coherencia y adecuación al público. Se eligió **usted** porque ya predominaba y es un sistema de trabajo.

Los topes de palabras son una decisión de este proyecto para hacer medibles esos principios. **No salen de ninguna norma.**

## Cómo se mantiene el mapa

```bash
php pruebas/mapa-textos.php docs/textos/mapa-textos.csv
```

El CSV se genera: no se edita a mano ni se guarda en el repositorio.

