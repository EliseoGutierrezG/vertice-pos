# Plan de El Timón

> Aprobado el 2026-11-14; revisión integral del 2026-11-17. Cada fase se cierra solo si se comprobó; el estado vigente está en [`CLAUDE.md`](../CLAUDE.md).

## Estado al 2026-11-14

- **Fases 0 a 11 terminadas y comprobadas.** `pruebas/todo.sh` pasa completo: unitarias, humo de panel y API, concurrencia de comanda (`pruebas/humo-comanda.py`), marca, seguridad, respaldo, paquete y cierre del host.
- **Marca:** el usuario eligió la combinación «1A», es decir, logotipo Timón y ola con la paleta Peltre. Está en [`marca/marca.md`](../marca/marca.md) y [`marca/tokens.json`](../marca/tokens.json).
- **Fase 12:** la plantilla ([`docs/plantilla/nuevo-negocio.md`](plantilla/nuevo-negocio.md)) y el runbook ([`docs/salida.md`](salida.md)) están escritos. El **piloto en una sucursal** se hace en el restaurante con equipos reales y queda en manos del negocio.
- **Interfaz comprobada:** panel, portada, menú QR y PWA en el navegador a 1440 y 375 px, con alta de equipo, PIN, plano en vivo y envío a cocina. La app nativa compila en Release para el simulador de iPad, abre con la paleta Peltre, guarda su llave en el llavero y completa el alta y la autorización del equipo.
- **Android:** no se prueba en emulador. Se prueba a mano en dispositivos físicos durante el piloto, incluido el equipo impresor.

## Revisión integral del 2026-11-17

Después de las fases se revisó el producto completo (comanda, punto de venta, panel y sitio) en cinco etapas. Las decisiones del 2026-11-16 y la evidencia por pantalla están en [`homologacion-timon.md`](homologacion-timon.md).

1. **Comanda y cobro.** La versión de la cuenta cuenta solo cambios cobrables o de ubicación, y la cocina ya no bloquea al mesero. Cola de envío propia en la app, cambios por cuenta, cobro con cambio, folio, propina y descuento, cuentas separadas, venta de mostrador y un cobro que no se detiene por falta de existencia. La app trabaja a dos paneles en tableta y PC.
2. **Homologación del panel.** Una tabla principal por pantalla, Ver y Actualizar con la ficha del servidor, paginación en servidor y XLS con los mismos filtros.
3. **Funciones nuevas del panel.** Tablero del restaurante, Turnos y cortes (solo consulta), Faltantes, lista de arranque y horario por día de cada sucursal, multisucursal, foto y precios en lote, reservación por teléfono, catálogos editables, compras y gastos completos.
4. **Sitio.** Landing con estado «Abierto ahora», especialidades, sucursales con horario por día, pedidos por WhatsApp, reservación con folio, barra fija en el celular, JSON-LD, `robots.txt` y `sitemap.xml`. El menú QR toma el estilo del sitio y nombra la mesa.
5. **Limpieza.** Se retiraron las piezas, estilos y guiones heredados de reparto y productos, y `servicios/OperacionesPanel.php`. `config/giro.php.ejemplo` queda versionado.

Lo que depende del dueño antes de publicar está en [`salida.md`](salida.md).

## Carta y promociones del 2026-11-18

El dueño entregó su carta en PDF. A partir de ella:

1. **La carta se arma sola** con Categorías (orden y leyenda) y Platillos (orden, porción, precio y modificadores como línea de preparaciones). La pantalla **Carta** muestra la hoja impresa con el diseño del PDF y se actualiza en 3 s cuando alguien guarda un cambio. «Imprimir la carta» abre la hoja lista para imprimir. Los textos del pie se guardan en `parametro`.
2. **Promociones por platillo**: porcentaje, precio especial y 2x1 o 3x2, por sucursal, fechas, días y horario. Se aplican solas al capturar en la comanda; el renglón guarda la promoción y su rebaja (`cuenta_item.descuento`), y el importe es cantidad × precio − descuento. El mostrador cotiza con el servidor antes de cobrar. Ticket, precuenta, corte y el reporte «Promociones» las muestran.
3. **Menú QR** con el estilo de la carta (marino y dorado), leyendas, preparaciones y «Promociones de hoy». La **landing** conserva la marca 1A y suma la insignia, el precio tachado y la franja de promociones.
4. La carta del PDF quedó en `pruebas/fixtures/carta-el-timon.php` y se carga con `guiones/carga-carta.php`. Lo que el dueño debe confirmar está en [`salida.md`](salida.md).

## Operación sin internet del 2026-11-18

El internet del restaurante falla seguido y la comanda no puede detenerse. El dueño eligió **una computadora en cada sucursal** con el mismo sistema; la guía completa está en [`servidor-sucursal.md`](servidor-sucursal.md).

1. **Guion 025.** `sucursal.servidor` (`central` o `local`), las tablas `instalacion` y `cambio_replica`, el origen de la bitácora y el permiso `servidor_admin`. `config/instalacion.php` declara el central o la sucursal, y cada conexión reparte los ids de 100 en 100 con su desplazamiento.
2. **Réplica** (`servicios/Replica.php`, `guiones/sincroniza.php`). El catálogo baja cada 60 s con huella, sin pisar las columnas que son de la sucursal. La operación sube cada 15 s desde los disparadores, en lotes idempotentes que el central revisa fila por fila. La bitácora sube renumerada para que el central la siga sellando.
3. **El central respeta a la sucursal local**: rechaza con 409 escribir su operación, y la sucursal rechaza cambiar el catálogo. Pantalla nueva **Operación local** (`/servidores`).
4. **App.** Pide la dirección de la computadora de la sucursal, avisa «Sin internet: todo funciona» con los cambios por subir, y el APK confía en la autoridad propia de la sucursal (`app/plugins/autoridad-local.js`). Hace falta un build nuevo de EAS.
5. **Paquete** (`despliegue/sucursal/`, `guiones/instala-sucursal.sh`): Docker con Apache, PHP 8.3, MariaDB 10.11, la sincronización y el respaldo diario. Certificado propio para la IP fija del restaurante.
6. **Comprobado** con `pruebas/servicios/ReplicaPrueba.php` y `pruebas/humo-sucursal.py`: con el central apagado, la sucursal abre mesa, envía a cocina, imprime, cobra con folio y hace el corte; al volver, el central queda igual y la sucursal recibe el precio y la reservación nuevos. El contenedor no se probó en esta Mac porque no tiene Docker: se prueba en el equipo del piloto.

## Contexto

### Continuación de actualizaciones remotas (2026-11-20)

Se retomó el plan de Claude del 2026-11-20: liberaciones Ed25519 por sucursal, descarga autenticada y reanudable, instalación con horario seguro, respaldo cifrado, candados entre peticiones/réplica/actualizador, comprobación de salud web y regreso de código. El esquema 026 registra las versiones y la asignación; 027 agrega el índice de versión instalada. El central se actualiza primero y la sucursal atrasada sigue subiendo mientras espera la bajada del catálogo. La PWA viaja en la liberación.

La app incluye ajustes de actualización y bloqueo por versión mínima, y se prepararon las dos vías Android (Play y APK local) y los canales EAS de staging, piloto y producción. La [guía de sucursal](servidor-sucursal.md#actualizaciones) explica el procedimiento y sus límites; la [guía de salida](salida.md#actualizaciones-remotas) cubre la distribución de las apps.

El usuario indicó que todavía no está disponible el acceso por Tailscale: se prepara la instalación y se difiere el ensayo remoto. Docker/DSM, APK real, impresoras, Play/TestFlight y recepción OTA en dispositivos requieren el piloto; no se consideran comprobados con las pruebas locales.

El Timón, restaurante de mariscos con varias sucursales, necesita cuatro piezas:

1. Una **landing** de publicidad.
2. Un **panel administrativo**: inventario, pedidos, gastos, caja y reportes.
3. Una **app de comanda** que se use al mismo tiempo en teléfono, tableta y PC.
4. Una **identidad gráfica** nueva, desde cero, con su paleta.

Lo crítico del sistema es ubicar las mesas, impedir que se asigne una mesa ocupada (sincronización), los pedidos y los tickets.

La carpeta `Timon/` está vacía. La base será **Distribuidora (Suga v2)**, en `../Distribuidora/Distribuidora`: PHP 8.3 nativo con MariaDB en Hostinger y Expo SDK 57. Ya tiene router, permisos que fallan cerrados, CSRF, sesión, TOTP, idempotencia, caja con cierre ciego, inventario con FEFO y kardex, exportaciones a PDF y XLSX, la guía de pantallas y las pruebas de humo.

Lo que decidiste:

- **App:** Expo universal. Nativa en Android y iPad, y la misma app como web instalable (PWA) en las PC con Windows.
- **Servidor:** Hostinger compartido.
- **Cocina:** pantalla de cocina (KDS) **y** papel térmico.
- **Alcance de la v1:** además de lo básico, para llevar y domicilio, reservaciones y menú QR. Sin CFDI.
- **Identidad:** desde cero.
- **Plantilla:** este sistema será la base de los siguientes negocios.

## Enfoque general

- **Una instalación por negocio**, como en Suga: su propia base y su propia marca. El código se organiza para que sirva de plantilla. Tiene dos capas:
  - **Capa base**, reutilizable: núcleo, seguridad, usuarios, sucursales, equipos, caja, inventario, gastos, reportes y marca.
  - **Capa de giro restaurante**: mesas, comandas, cocina, reservaciones y menú.
- Al iniciar un negocio nuevo se copia el repositorio y se cambian la marca (`marca/tokens.json` y logos) y `config/giro.php` (a partir de `config/giro.php.ejemplo`), que activa y desactiva módulos.
- **No se copian los 13 GB de Distribuidora.** Se trae solo la capa base. No vienen los módulos de reparto, preventa, rutas, vehículos, hojas de carga, liquidaciones, visitas, checadas ni geocodificación.
- Los identificadores heredados de «La Barrica» (`lb_`, `tema-barrica.css`, `barrica.js`, `labarrica`) se renombran a nombres neutros de plantilla al copiar (prefijo `pb_`, `tema.css`, `plantilla.js`).
- El esquema arranca en **una serie nueva y consolidada** (`esquema/001…`), porque la base nace vacía y no hace falta arrastrar los 67 guiones históricos.
- **Un solo subdominio en Hostinger:**

  | Ruta | Qué sirve |
  |---|---|
  | `/` | Landing |
  | `/panel` | Panel administrativo |
  | `/app` | Expo web exportada como estática; Node no corre en Hostinger |
  | `/menu/{sucursal}` | Menú QR |
  | `/api/v1` | API |

## Arquitectura de la comanda (el corazón)

### Ubicación de mesas

- Las tablas son `sucursal` → `area` (salón, terraza, barra) → `mesa`. Cada mesa tiene número, capacidad, forma y posición `x,y` en el plano.
- En el panel hay un **editor de plano** para arrastrar las mesas.
- En la app se ve el **plano en vivo** con estos estados: libre, ocupada, cuenta pedida, por limpiar, reservada y bloqueada. Cada estado lleva color **e** icono o texto, y el plano muestra mesero y tiempo transcurrido.
- En teléfono, el plano se convierte en una lista por área.

### Que nunca se den dos mesas

- La tabla `cuenta` lleva `abierta TINYINT NULL` y `UNIQUE(id_mesa, abierta)`. Es el mismo truco de `turno_caja` en `esquema/042_caja.sql:27-34` de Distribuidora: la base de datos **rechaza** una segunda cuenta abierta en la misma mesa.
- Para unir mesas, `cuenta_mesa` usa la misma unicidad.
- Toda escritura pasa por `BaseDatos::transaccion()` con `SELECT … FOR UPDATE` sobre la cuenta. Además lleva un `version` de la cuenta (concurrencia optimista) y responde **409** con el estado actual si otro equipo se adelantó.
- Cada operación lleva una llave de idempotencia UUID. Se reutilizan `BaseDatos::guardaUnaSolaVez()` y la tabla `operacion_sincronizada`, así un reintento por mala señal no duplica platillos.
- Abrir, cerrar, cambiar o unir mesas **exige conexión**. Sin conexión no se puede garantizar la exclusividad, y la app lo dice claramente.
- Agregar platillos a una cuenta ya abierta sí puede encolarse sin conexión. Se reutiliza el diseño de `movil/src/nucleo/cola.ts` y `subidor.ts`, y lo pendiente se marca como «sin enviar».

### Sincronización en vivo sobre Hostinger compartido

Ahí no hay WebSockets, así que el tiempo real se resuelve así:

- Una tabla `evento_sucursal` con id autoincremental. Cada cambio de mesa, cuenta, ítem o impresión inserta un evento en la misma transacción.
- `GET /api/v1/cambios?desde=N` es un endpoint ligero: sin sesión de archivo, con token y con índice. Devuelve solo los eventos nuevos, o vacío.
- La app lo consulta cada **2 s** en primer plano, cada 10 s si está inactiva y se pausa en segundo plano. Al reconectar hace una bajada completa del estado de la sucursal.
- Carga estimada: unas 5 peticiones por segundo por sucursal con unos 10 equipos. ⚠️ Hay que vigilar los límites de procesos de entrada del plan de Hostinger. Si se queda corto, la salida es subir a un VPS sin cambiar el contrato: el mismo endpoint pasaría a SSE o WebSocket.

### Pedidos y rondas

- `cuenta` → `ronda` (cada «enviar a cocina») → `cuenta_item`. Cada ítem lleva:
  - modificadores (término, sin cebolla, salsa aparte);
  - tiempo (entrada o fuerte);
  - comensal o asiento, para dividir después.
- Estados del ítem: capturado → enviado → en preparación → listo → entregado.
- Cancelar un ítem ya enviado exige motivo y la **autorización** de un gerente. Se reutilizan `AutorizacionOperacion` y `SegundoFactor`, y todo queda en bitácora.
- También se puede: cambiar de mesa, transferir ítems entre cuentas, dividir la cuenta (por ítems, por comensal o en partes iguales) y marcar platillos como agotados (los ve toda la sucursal al instante).
- Tipos de cuenta: `mesa`, `llevar` y `domicilio`. Llevar y domicilio guardan cliente, teléfono, dirección y repartidor, y tienen su propio tablero de estados.

### Cocina, barra y tickets

- Cada platillo pertenece a un **área de preparación**: cocina caliente, cocina fría (ceviches y cocteles) o barra. Al enviar una ronda, el servidor la parte por área.
- **KDS:** la app en modo «Cocina» o «Barra», en tableta horizontal, muestra comandas con temporizador y los botones «En preparación», «Listo» y «Retomar».
- **Papel:**
  - Tabla `impresora`, por sucursal: IP, puerto 9100, ancho de 58 u 80 mm y áreas que atiende.
  - Tabla `trabajo_impresion`, la cola: comanda, precuenta, ticket de pago y corte.
  - Un **equipo impresor** por sucursal (tableta o teléfono Android con la app nativa) toma la cola y manda ESC/POS por TCP con `react-native-tcp-socket`. Necesita una dev build; Expo Go no sirve, igual que en Suga.
  - Cada trabajo se confirma y se puede reimprimir. Si un trabajo lleva más de 20 s sin imprimirse, se avisa en caja y en el KDS.
- **Ticket del cliente desde la PC de caja:** `window.print()` con las hojas `ticket-80.css` y `imprime.js`, que ya existen en Distribuidora. Además, el ticket público por enlace o QR (`TicketsPublicos`).

### Equipos por sucursal

- Tabla `equipo`: sucursal, nombre, tipo, identificador, autorizado y `config` en JSON (áreas que ve e impresora asignada).
- Tipos: mesero, caja, cocina, barra, impresor y gerencia.
- Alta del equipo:
  1. El equipo nuevo muestra un código.
  2. El gerente lo aprueba en el panel y le asigna la sucursal y el tipo.
  3. Desde entonces el equipo queda **fijo a esa sucursal**.

  Se parte de `modelos/Dispositivos.php` y `controladores/Web/DispositivosWeb.php`, que hoy ligan el dispositivo al usuario. Aquí se ligará a la sucursal.
- **PIN rápido de 4 a 6 dígitos** por usuario para cambiar de mesero en tabletas compartidas. Lleva límite de intentos (se reutiliza `IntentosAcceso`) y cierre por inactividad.
- La identidad se generaliza: `Identidad::exigeBodega()` pasa a `exigeSucursal()`. El alcance de cada usuario se define por una o varias sucursales.

## Panel administrativo (capa base adaptada)

- **Organización:** sucursales, áreas, mesas, editor de plano, equipos, impresoras, usuarios y roles: administrador, gerente de sucursal, cajero, mesero, cocina, barra y almacén.
- **Menú:** categorías, platillos con foto, modificadores, área de preparación, precio por sucursal (se reutilizan `Productos` y `PreciosProgramados`) y disponibilidad.
- **Caja:** se reutiliza `servicios/Cajas.php` y `esquema/042`: turnos, movimientos y **cierre ciego**. El cobro admite efectivo, tarjeta (con referencia de la terminal), transferencia, pago mixto y propina. Los descuentos piden autorización (`AutorizacionDescuento`).
- **Inventario:** se reutilizan `Inventario`, `Kardex`, `Lotes` (FEFO, clave para mariscos perecederos), `ConteosFisicos`, `Bajas` (mermas) y `Caducidades`.
  - Se agregan **recetas**: cada platillo consume insumos, y su consumo se descuenta al cobrar.
  - El reporte compara el consumo teórico con el real.
- **Compras y proveedores:** las órdenes de compra y entradas que ya existen.
- **Gastos:** un módulo nuevo e independiente de las liquidaciones, con concepto, proveedor, comprobante y la opción de pagarse desde caja.
- **Reservaciones:** agenda por sucursal. Las solicitudes llegan de la landing con estado «solicitada»; a la mesa asignada se le aplica un bloqueo X minutos antes de la hora.
- **Reportes:** ventas por día, hora, platillo y mesero; ticket promedio; propinas; tiempos de cocina; cancelaciones; agotados.
  - Se exportan en CSV, PDF y XLSX con `nucleo/Exporta/`.
  - El tablero vivo se adapta de `TableroVivo`.
- Todas las pantallas siguen `docs/homologacion/guia_construccion_suga.md`, que se copiará como `docs/guia-pantallas.md`.

## App Expo universal (`app/`)

- Se toma el núcleo de `movil/src/nucleo/`: sesión, `cola`, `subidor`, `llavero`, cliente de la API, `turnoBd`, `ui.tsx` y `marca.ts`.
- Hay **adaptadores por plataforma** (`.web.ts`), porque SQLCipher y SecureStore no corren en web:
  - **Nativo:** SQLite cifrado y SecureStore.
  - **Web:** almacenamiento del navegador con un caché mínimo. La comanda depende del servidor.
- Se quitan `orientation: portrait` y `supportsTablet: false`.
- Diseño adaptable en tres tamaños:
  - **Teléfono:** mesero, con lista de mesas y captura rápida.
  - **Tableta horizontal:** plano completo y KDS.
  - **Escritorio (PC con la PWA):** caja, cobro y precuenta.
- El modo del equipo (mesero, caja, cocina, barra o impresor) lo fija el panel, y la app abre directo en esa vista.
- **Actualizaciones:**
  - Nativo: EAS Update por aire y EAS Build para APK y iPad.
  - Web: `expo export --platform web`, que se sube a `/app`. Así las PC se actualizan solas.

## Identidad gráfica (primera entrega visible)

- **Concepto:** el timón como símbolo de rumbo y oficio marinero, con mariscos frescos. Habrá **3 propuestas de logotipo** en SVG:
  1. timón con ola;
  2. timón cuyos rayos son espinas de pez;
  3. wordmark con el timón en la «ó».
- **Decisión:** se eligió «1A», Timón y ola con la paleta Peltre. La tabla de abajo es la propuesta inicial y ya no rige; los valores vigentes están en `marca/tokens.json`.
- **Paleta propuesta** (se presentan 2 o 3 variantes para elegir, con contrastes medidos AA como en la marca de Suga):

  | Papel | Color | Valor |
  |---|---|---|
  | Primario | Azul océano profundo | `#0B3C5D` |
  | Barra lateral y héroe | Noche marina | `#072A40` |
  | Acento de apetito | Coral camarón | `#E8604C` |
  | Secundario | Turquesa laguna | `#1F8A8A` |
  | Fondo | Arena | `#F6F0E6` |
  | Éxito y libre | Verde alga | `#2E7D5B` |
  | Advertencia | Limón | `#E3B23C` |

  Los estados de mesa tienen colores asignados y siempre llevan icono además del color.
- **Tipografía:** una display con carácter marinero para titulares y una sans muy legible para la operación, que se lea en la cocina a distancia.
- **Una sola fuente de verdad:** `marca/tokens.json` y un generador `guiones/genera-marca.mjs` que produce el CSS del panel, las variables de la landing y `app/src/nucleo/marca.ts`. Esto corrige la triple duplicación que tiene Suga, y es lo que hace funcionar la plantilla.
- Se entrega `marca/marca.md` con logos, usos incorrectos, contrastes y aplicaciones: ticket, menú QR, icono de la app e impresión en papel térmico (en monocromo).

## Landing (`landing/`)

- HTML y CSS estáticos, como en Suga, con pocas piezas dinámicas:
  - héroe con fotografía de platillos;
  - especialidades;
  - menú, que enlaza al menú QR de cada sucursal;
  - sucursales con horario, mapa y WhatsApp;
  - formulario de reservación que hace POST a la API, con un campo trampa y límite de envíos;
  - redes sociales.
- **Menú QR:** `/menu/{sucursal}`, en solo lectura, con fotos y con los agotados marcados. El panel genera e imprime un QR por mesa con `dominio/CodigoQr.php`.

## Fases (cada una se cierra solo si se comprobó)

0. **Fundación:**
   - repositorio git en `Timon/` y copia selectiva de la capa base;
   - renombre de identificadores a nombres neutros;
   - esquema consolidado y configuración de entornos;
   - `pruebas/todo.sh` en verde con lo heredado.
1. **Identidad:** 3 logos y 2 o 3 paletas para que elijas; luego `tokens.json`, el generador y `marca.md`.
2. **Organización:** sucursales, áreas, mesas y editor de plano; equipos por sucursal con aprobación; usuarios con PIN y roles.
3. **Menú:** catálogo, modificadores, áreas de preparación, precios por sucursal y agotados.
4. **Motor de comanda en el servidor:**
   - cuentas, rondas e ítems;
   - unicidad de mesa, versiones e idempotencia;
   - `evento_sucursal` y `/cambios`;
   - pruebas de concurrencia.
5. **App universal:** acceso del equipo con PIN, plano en vivo, toma de pedido, envío y precuenta, en los tres tamaños.
6. **Cocina y barra:** KDS, cola de impresión, equipo impresor ESC/POS y alertas de impresora caída.
7. **Caja:** cobro, división de cuenta, propina, descuentos autorizados, turno con cierre ciego y ticket.
8. **Para llevar, domicilio y reservaciones.**
9. **Inventario con recetas, compras, gastos y mermas.**
10. **Reportes y tablero vivo.**
11. **Landing y menú QR**, con la reservación web.
12. **Plantilla y salida:**
    - `docs/plantilla/nuevo-negocio.md`: cómo iniciar otro giro o marca;
    - runbook de Hostinger y EAS;
    - piloto en una sucursal.

## Archivos de Distribuidora que se reutilizan (rutas relativas a `../Distribuidora/Distribuidora`)

- **Núcleo:** `nucleo/` completo (`Aplicacion`, `Router`, `Contenedor`, `BaseDatos`, `Identidad`, `Sesion`, `Csrf`, `Reloj`, `Exporta/`, `Seguridad/`, `MigracionesEsquema`) y `nucleo/Middleware/*`, incluidos `ExigeEnvioUnico` y `ExigeDispositivo`.
- **Servicios:** `Cajas`, `Inventario`, `Kardex`, `Lotes`, `ConteosFisicos`, `Bajas`, `Caducidades`, `Productos`, `PreciosProgramados`, `AutorizacionDescuento`, `AutorizacionOperacion`, `SegundoFactor`, `Personal`, `Organizacion` (se adapta a sucursal), `TicketsPublicos`, `Notificaciones`, `MarcaVisual`, `Reportes`, `TableroVivo` y `Sincronizacion` (su idempotencia).
- **Dominio:** `Dinero`, `Cantidad`, `CalculoFiscal`, `Impuesto`, `Redondeo`, `Totp`, `CodigoQr` y `AnchoTicket`.
- **Panel:** `vistas/plantilla/*`, `vistas/partes/piezas.php`, `publico/recursos/` (vendor, `imprime.js`, `ticket-*.css`, `envio-unico.js` y los esqueletos de `barrica.js`) y `design-system/la-barrica/MASTER.md`, que se convierte en el design system propio.
- **App:** de `movil/src/nucleo/`, los archivos `sesion.tsx`, `cola.ts`, `subidor.ts`, `llavero.ts`, `turnoBd.ts`, `sqlite.ts` y `marca.ts`; además `movil/src/componentes/ui.tsx` y `movil/eas.json`.
- **Herramientas:** de `guiones/`, los archivos `aplica-esquema.php`, `migraciones.php`, `prepara-despliegue-subdominio.sh`, `genera-sql-despliegue.php`, `servidor-pruebas.sh` y `tarea.php` (respaldo y mantenimiento); también `pruebas/correr.php` y el patrón de `humo-*.sh`.

## Verificación

- **Unitarias y de humo:** `pruebas/todo.sh` contra el servidor local, en cada fase.
- **Concurrencia:** dos peticiones simultáneas de «abrir mesa 5», en paralelo con `curl` y `&`, deben terminar en exactamente 201 y 409. Lo mismo para cambiar de mesa, unir mesas y cobrar la misma cuenta dos veces.
- **Idempotencia:** el mismo POST con la misma llave, enviado 3 veces, debe dejar una sola ronda.
- **Sincronización:** con dos navegadores y el simulador, un cambio en un equipo debe verse en el otro en 3 s o menos. Se mide la carga de `/cambios` con 10 clientes simulados.
- **Impresión:** un emulador ESC/POS en el puerto 9100 (`nc -l 9100 > salida.bin`, que luego se decodifica) y después una impresora real. También se prueba el aviso de impresora caída.
- **Interfaz:**
  - el panel y la PWA en el navegador integrado a 1440, 768 y 375 px;
  - la app en el simulador de iOS (iPad); Android se prueba en dispositivos físicos durante el piloto;
  - la lista de cierre de la guía de pantallas.
- **Marca:** una prueba automática de contrastes AA sobre `tokens.json`, como hace `marca.prueba.ts` en Suga.
