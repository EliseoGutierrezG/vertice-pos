# Despliegue automático (CI/CD)

El Timón usa la plantilla `ci-cd-hostinger` de Vértice Software tal cual: GitHub Actions arma el paquete y lo sincroniza por FTPS con Hostinger. Lo único propio del proyecto es [`.github/workflows/service.sh`](../.github/workflows/service.sh) y el build [`guiones/prepara-ci.sh`](../guiones/prepara-ci.sh) (`npm run build`).

| Rama | Sitio | Entorno de GitHub |
|---|---|---|
| `staging` | `https://staging-timon.verticesoftware.com.mx` | `staging` |
| `main` | `https://timon.verticesoftware.com.mx` | `produccion` |

Día a día: rama desde `staging` → PR a `staging` (se publica en staging y semantic-release crea la versión) → PR `staging` → `main` (se publica en producción con su Release). Los mensajes `feat:` y `fix:` deciden la versión.

## Qué sube y qué no

- Sube `entregables/despliegue/app-subdominio-ftp/`, la misma carpeta del [procedimiento manual](../entregables/despliegue/INSTRUCCIONES-SUBDOMINIO.md), con la PWA y la regla pública ya activa como `.htaccess`.
- **No** sube `.app/config/giro.php`, el SQL de instalación ni el cerrojo de instalación. La configuración del servidor (`bd.php`, `seguridad.php`…) y `almacenamiento/` nunca están en el paquete, así que la sincronización no los toca.
- El `.htaccess` niega `.ftp-deploy-sync-state.json` y manda `noindex` en los hosts `staging-…`. No borres ese archivo del servidor o la siguiente vez sube todo.

## Lo que sigue siendo a mano

- **La primera instalación** de cada sitio (base, configuración privada, administrador) con las instrucciones del subdominio. El flujo solo actualiza un sitio ya instalado: instala producción antes del primer PR a `main`.
- **Las migraciones de la base**: si una versión trae un guion nuevo en `esquema/`, después del despliegue se aplican por SSH con `migraciones.php`, con respaldo verificado.
- Cuentas FTP `ghtimon` y `ghtimonstg` (directorio `public_html` de cada sitio) y sus secretos `FTP_SERVER`, `FTP_USERNAME` y `FTP_PASSWORD` en cada entorno.
