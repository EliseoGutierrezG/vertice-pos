## [1.0.2](https://github.com/vertice-software-feb/timon/compare/v1.0.1...v1.0.2) (2026-11-23)


### Bug Fixes

* crear-usuario funciona en Hostinger, donde shell_exec está deshabilitado ([1d1ea86](https://github.com/vertice-software-feb/timon/commit/1d1ea8633dbea8b48da2987bfcf226f6998e34b6))

## [1.0.1](https://github.com/vertice-software-feb/timon/compare/v1.0.0...v1.0.1) (2026-11-23)


### Bug Fixes

* el registro de versiones de producción ya no lo ignora Git ([345aea9](https://github.com/vertice-software-feb/timon/commit/345aea9b9ab6b16066983e58c970599d4ff1a0c8))

# 1.0.0 (2026-11-23)


### Features

* actualizaciones de sucursal firmadas y operación sin internet ([60a2d7f](https://github.com/vertice-software-feb/timon/commit/60a2d7f7d24af0c7cb5f0f75ecdd11b6f948f9ad))
