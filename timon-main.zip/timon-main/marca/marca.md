# El Timón · Timón y ola

Combinación «1A» aprobada por el usuario el 14 de noviembre de 2026: logotipo Timón y ola con la paleta Peltre. El timón va en cobalto sobre superficies claras y en blanco sobre tinta de calamar. La ola va en rojo salsa sobre claro y en verde limón sobre oscuro. La versión negra se usa en el ticket térmico. El icono de la app usa el símbolo sobre tinta de calamar, con margen alrededor de las manijas.

La paleta Peltre toma el azul cobalto y el blanco esmaltado de los platos de peltre. Usa cobalto para acciones, tinta de calamar para texto, rojo salsa para avisos de error y amarillo limón para avisos que piden atención; el verde limón solo adorna la ola sobre fondo oscuro. Los estados de mesa llevan texto visible. En el plano, una mesa libre lleva verde y una ocupada lleva cobalto. El sitio usa Playfair Display en la portada y los títulos de sección, Sora en los demás titulares y Plus Jakarta Sans para lectura. El panel usa Sora y Plus Jakarta Sans. Todas se sirven desde el proyecto. La app usa la tipografía del sistema para preservar las métricas nativas.

Conserva la proporción del símbolo y su margen. Evita colocarlo sobre zonas con mucho detalle de una foto. Usa la versión monocroma para papel térmico y conserva la leyenda de la sucursal junto al QR.

Edita `tokens.json` y ejecuta `node guiones/genera-marca.mjs`. El guion regenera los SVG y las variables del panel, el sitio y la app. Con `--verifica` comprueba que los archivos están al día y los pares de color alcanzan contraste AA.

La imagen `publico/recursos/sitio/aguachile.jpg` se generó con ImageGen a partir de una solicitud de fotografía editorial de aguachile verde de camarón, pepino, cebolla morada y limón en peltre, con luz natural costera. Se sirve en AVIF y WebP de 720 y 1440 px, con el JPG de respaldo.
