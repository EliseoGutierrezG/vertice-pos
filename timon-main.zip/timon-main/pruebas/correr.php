<?php
declare(strict_types=1);

/**
 * El corredor de pruebas.
 *
 *   php pruebas/correr.php            todas
 *   php pruebas/correr.php router     sólo las que lleven "router" en el nombre
 *
 * Cada archivo pruebas/**\/*Prueba.php devuelve un arreglo
 * ['lo que debe pasar' => function (): void { ... }].
 * El nombre de la prueba se lee como una frase; si falla, esa frase es el
 * informe. Por eso están escritas en español y en indicativo.
 */

$raiz = dirname(__DIR__);

// La suite escribe en casi todos los módulos. Una ejecución directa también
// debe elegir y verificar la base aislada, no depender de que todo.sh lo haga.
if (getenv('APP_ENTORNO') === false || getenv('APP_ENTORNO') === '') {
    putenv('APP_ENTORNO=pruebas');
}

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
require __DIR__ . '/Afirma.php';
require __DIR__ . '/Semilla.php';

try {
    Nucleo\CerrojoPruebas::exige($raiz);
} catch (Throwable $e) {
    fwrite(STDERR, "CERROJO: {$e->getMessage()}\n");
    exit(1);
}

Nucleo\Reloj::fijaLaZona($raiz);
error_reporting(E_ALL);
ini_set('display_errors', '1');

$filtro   = $argv[1] ?? '';
$archivos = [];

$directorio = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(__DIR__));
foreach ($directorio as $archivo) {
    if ($archivo->isFile() && str_ends_with($archivo->getFilename(), 'Prueba.php')) {
        $archivos[] = $archivo->getPathname();
    }
}
sort($archivos);

$verde = "\033[32m";
$rojo  = "\033[31m";
$gris  = "\033[90m";
$nada  = "\033[0m";

$pasadas = 0;
$fallas  = [];
$grupoAnterior = '';

$rotos = [];

foreach ($archivos as $archivo) {
    /** @var array<string,callable> $pruebas */
    $pruebas = require $archivo;
    $grupo   = basename($archivo, '.php');

    // ⚠️ Un archivo que no devuelve su arreglo de pruebas no falla: `require`
    // devuelve 1, el `foreach` de abajo suelta un aviso por el error estándar y
    // la corrida sigue. Medido: `pruebas/dominio/EscalaPrueba.php` estaba
    // **vacío** y el aviso llevaba ahí no se sabe cuántas corridas, enterrado
    // entre trescientas líneas verdes, mientras la clase por donde pasan todos
    // los pesos y todas las unidades del sistema quedaba con una sola prueba
    // —y escrita en el archivo de otra clase—. Un archivo de pruebas que no se
    // puede leer se ve igual que uno que pasa. Ahora se ve en rojo y tumba la
    // corrida.
    if (!is_array($pruebas)) {
        $rotos[] = str_replace($raiz . '/', '', $archivo);
        echo "\n{$rojo}✗ {$grupo} no devuelve un arreglo de pruebas{$nada}\n";
        continue;
    }

    foreach ($pruebas as $nombre => $prueba) {
        if ($filtro !== '' && !str_contains(strtolower($grupo . ' ' . $nombre), strtolower($filtro))) {
            continue;
        }

        if ($grupo !== $grupoAnterior) {
            echo "\n{$gris}{$grupo}{$nada}\n";
            $grupoAnterior = $grupo;
        }

        try {
            $prueba();
            $pasadas++;
            echo "  {$verde}✓{$nada} {$nombre}\n";
        } catch (Throwable $e) {
            $fallas[] = [$grupo, $nombre, $e];
            echo "  {$rojo}✗{$nada} {$nombre}\n";
            echo "    {$rojo}{$e->getMessage()}{$nada}\n";
        }
    }
}

echo "\n";

if ($rotos !== []) {
    echo "{$rojo}" . count($rotos) . " archivo(s) de pruebas no se pudieron leer:{$nada}\n";
    foreach ($rotos as $roto) {
        echo "  · {$roto} — tiene que terminar con `return [...]`\n";
    }
    echo "\n";
}

if ($fallas === [] && $rotos === []) {
    echo "{$verde}" . $pasadas . " pruebas, todas pasan.{$nada}\n";
    exit(0);
}

if ($fallas === []) {
    echo "{$rojo}Las " . $pasadas . " pruebas pasan, pero hay archivos sin leer.{$nada}\n";
    exit(1);
}

echo "{$rojo}" . count($fallas) . " de " . ($pasadas + count($fallas)) . " fallan:{$nada}\n";
foreach ($fallas as [$grupo, $nombre, $e]) {
    echo "  · {$grupo} → {$nombre}\n";
    echo "    " . $e->getMessage() . "\n";
    echo "    {$gris}" . $e->getFile() . ':' . $e->getLine() . "{$nada}\n";
}
exit(1);
