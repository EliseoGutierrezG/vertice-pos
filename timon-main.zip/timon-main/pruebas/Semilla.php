<?php
declare(strict_types=1);

namespace Pruebas;

use Modelos\Usuarios;
use Nucleo\BaseDatos;
use RuntimeException;

/**
 * Lo que las pruebas siembran y después se llevan.
 *
 * En la v2 no hay usuario sin personal (D12), así que dar de alta a alguien
 * son dos renglones y un puesto. Si cada prueba lo hiciera a su manera, la
 * primera vez que el modelo cambie habría quince sitios que arreglar y alguno
 * se quedaría sembrando basura. Aquí se hace una vez.
 *
 * Todo lo sembrado lleva un **prefijo** en el nombre de usuario, y con ese
 * prefijo se borra: una prueba nunca borra lo que no sembró.
 */
final class Semilla
{
    /**
     * Una persona con su puesto y su usuario, lista para entrar.
     *
     * La contraseña no es temporal: la prueba quiere probar otra cosa, no el
     * cambio obligatorio.
     */
    public static function usuario(
        BaseDatos $bd,
        string $usuario,
        string $puesto,
        string $clave = 'contraseña-larga-x',
        ?int $idSucursal = null
    ): int {
        $idPuesto = (int) $bd->valor('SELECT id FROM puesto WHERE clave = ?', [$puesto]);

        if ($idPuesto === 0) {
            throw new RuntimeException('No existe el puesto ' . $puesto);
        }

        return $bd->transaccion(static function (BaseDatos $bd) use ($usuario, $idPuesto, $clave, $idSucursal): int {
            $idPersonal = $bd->inserta(
                'INSERT INTO personal (nombre, apellido_paterno, id_puesto, id_sucursal, fecha_ingreso)
                 VALUES (?, ?, ?, ?, CURDATE())',
                ['Prueba', $usuario, $idPuesto, $idSucursal]
            );

            return (new Usuarios($bd))->crea($idPersonal, $usuario, $clave, temporal: false);
        });
    }

    /** Una llave de idempotencia nueva, como la que manda `pb_llave()`. */
    public static function llave(): string
    {
        $b = random_bytes(16);
        $b[6] = chr((ord($b[6]) & 0x0f) | 0x40);
        $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($b), 4));
    }

    /** Borra a los usuarios cuyo nombre de acceso empieza con el prefijo, y todo lo suyo. */
    public static function borraUsuarios(BaseDatos $bd, string $prefijo): void
    {
        if ($prefijo === '' || str_contains($prefijo, '%') || str_contains($prefijo, '_')) {
            // Un prefijo vacío o con comodines borraría de más.
            throw new RuntimeException('El prefijo tiene que ser literal y no vacío');
        }

        $ids = array_map(
            static fn (array $f): int => (int) $f['id'],
            $bd->filas('SELECT id FROM usuario WHERE usuario LIKE ?', [$prefijo . '%'])
        );

        if ($ids === []) {
            return;
        }

        $marcas = implode(', ', array_fill(0, count($ids), '?'));

        $bd->ejecuta('DELETE FROM totp_codigo_recuperacion WHERE id_usuario IN (' . $marcas . ')', $ids);

        // Una notificación apunta a su equipo y a su aviso, y el aviso a quien
        // lo mandó: se van antes que el equipo y la persona.
        $bd->ejecuta(
            'DELETE FROM notificacion WHERE id_usuario IN (' . $marcas . ')
             OR id_aviso IN (SELECT id FROM aviso WHERE creado_por IN (' . $marcas . '))',
            [...$ids, ...$ids]
        );
        $bd->ejecuta('DELETE FROM aviso WHERE creado_por IN (' . $marcas . ')', $ids);

        foreach (['bitacora', 'token_acceso', 'dispositivo', 'usuario_sucursal', 'operacion_sincronizada', 'operacion_panel', 'envio_panel'] as $tabla) {
            $bd->ejecuta('DELETE FROM ' . $tabla . ' WHERE id_usuario IN (' . $marcas . ')', $ids);
        }

        $personal = array_map(
            static fn (array $f): int => (int) $f['id_personal'],
            $bd->filas('SELECT id_personal FROM usuario WHERE id IN (' . $marcas . ')', $ids)
        );

        $bd->ejecuta('DELETE FROM usuario WHERE id IN (' . $marcas . ')', $ids);
        $bd->ejecuta('DELETE FROM personal WHERE id IN (' . $marcas . ')', $personal);
    }
}
