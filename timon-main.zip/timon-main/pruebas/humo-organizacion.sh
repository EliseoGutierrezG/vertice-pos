#!/usr/bin/env bash
# Prueba de humo de las sucursales.
#
#   pruebas/humo-organizacion.sh
#
# Alta, edición, baja y unicidad de nombre y clave; una sucursal con personal
# activo no se da de baja. Además, la pantalla contesta JSON a quien lo pide
# —así manda los modales `plantilla.js`— y redirección al POST de toda la vida,
# y quien no administra no escribe.
#
# Al terminar borra lo que creó, pase lo que pase.

set -u
BASE="${1:-http://127.0.0.1:8081}"
PHP=/opt/homebrew/opt/php@8.3/bin/php
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
. "$RAIZ/pruebas/exige-entorno.sh"
. "$RAIZ/pruebas/fixtures/entra-segundo-factor.sh"
TARRO=$(mktemp -d)
GALLETAS="$TARRO/galletas"

verde=$'\033[32m'; rojo=$'\033[31m'; gris=$'\033[90m'; nada=$'\033[0m'
pasadas=0; fallas=0

ok()   { printf "  %s✓%s %s\n" "$verde" "$nada" "$1"; pasadas=$((pasadas + 1)); }
mal()  { printf "  %s✗%s %s\n" "$rojo" "$nada" "$1"; fallas=$((fallas + 1)); }
juzga() { if [ "$2" = "$3" ]; then ok "$1"; else mal "$1 — esperaba $3, llegó $2"; fi; }
dice()  { if printf '%s' "$2" | grep -q -- "$3"; then ok "$1"; else mal "$1"; fi; }
calla() { if printf '%s' "$2" | grep -q -- "$3"; then mal "$1"; else ok "$1"; fi; }

# Lo que dieron de alta los usuarios `humo.org.`, y después ellos. El personal
# se va antes que las sucursales porque puede apuntar a una.
limpia_bd() {
  "$PHP" -r '
    require "'"$RAIZ"'/nucleo/Autocargador.php";
    Nucleo\Autocargador::registrar("'"$RAIZ"'");
    Nucleo\Reloj::fijaLaZona("'"$RAIZ"'");
    require "'"$RAIZ"'/pruebas/Semilla.php";
    $bd  = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
    $ids = array_map("intval", array_column($bd->filas("SELECT id FROM usuario WHERE usuario LIKE ?", ["humo.org.%"]), "id"));
    $sucursales = [];
    if ($ids !== []) {
      $m = implode(", ", array_fill(0, count($ids), "?"));
      $sucursales = array_map("intval", array_column($bd->filas("SELECT id FROM sucursal WHERE creado_por IN ($m)", $ids), "id"));
    }
    $bd->ejecuta("DELETE FROM intento_acceso");
    Pruebas\Semilla::borraUsuarios($bd, "humo.org.");
    if ($sucursales !== []) {
      $bd->ejecuta("DELETE FROM sucursal WHERE id IN (" . implode(", ", $sucursales) . ")");
    }
  '
}

limpia() {
  limpia_bd
  rm -rf "$TARRO"
}
trap limpia EXIT

# La contraseña vive en esta variable y muere con el guion.
CLAVE="prueba-$(head -c 12 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9')"
# Un sufijo por corrida: así una corrida que murió a medias no choca con ésta.
S=$(head -c 3 /dev/urandom | xxd -p)

limpia_bd
"$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  require "'"$RAIZ"'/pruebas/Semilla.php";
  $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
  Pruebas\Semilla::usuario($bd, "humo.org.admin", "administrador", $argv[1]);
  Pruebas\Semilla::usuario($bd, "humo.org.super", "gerente", $argv[1]);
  Pruebas\Semilla::usuario($bd, "humo.org.mesero", "mesero", $argv[1]);
' "$CLAVE"

echo "${gris}Contra ${BASE}${nada}"

marca_de() { curl -s -m 10 -c "$GALLETAS" -b "$GALLETAS" "$BASE$1" \
  | grep -o 'name="\(_marca\|csrf-token\)" \(value\|content\)="[a-f0-9]*"' | head -1 | sed 's/.*="//;s/"//'; }

entra() {
  entra_web_segura "$BASE" "$PHP" "$RAIZ" "$1" "$CLAVE" "$GALLETAS" || return 1
  MARCA=$(marca_de /panel)
}

# Un POST de formulario de siempre: código y a dónde manda.
postea() { curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code} %{redirect_url}' \
  --data-urlencode "_marca=$MARCA" "${@:2}" "$BASE$1"; }
# El mismo POST como lo manda `plantilla.js`: pide JSON.
postea_json() { curl -s -m 10 -b "$GALLETAS" -w '|%{http_code}' -H 'Accept: application/json' \
  --data-urlencode "_marca=$MARCA" "${@:2}" "$BASE$1"; }
codigo() { curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' "$BASE$1"; }
pagina() { curl -s -m 10 -b "$GALLETAS" "$BASE$1"; }
# La ficha como la pide el modal de Ver (Fase 4): JSON con su HTML.
pagina_json() { curl -s -m 10 -b "$GALLETAS" -H 'Accept: application/json' "$BASE$1"; }

# --- administrador ----------------------------------------------------------
entra humo.org.admin
[ -n "$MARCA" ] && ok "el administrador entra y la pantalla trae su marca" || mal "el administrador entra y la pantalla trae su marca"

echo "${gris}la pantalla${nada}"
juzga "sucursales abre"  "$(codigo /sucursales)"  200
dice  "el menú la ofrece" "$(pagina /panel)" 'href="/sucursales"'

echo "${gris}sucursales${nada}"
CLAVE_SUC=$(printf 'H%s' "$S" | tr 'a-z' 'A-Z' | cut -c1-6)
R=$(postea /sucursales --data-urlencode "nombre=Sucursal Humo $S" --data-urlencode "clave=$CLAVE_SUC" --data-urlencode "telefono=222 123 4567" --data-urlencode "cp=72000")
juzga "el alta abre su ficha en el listado" "$(printf '%s' "$R" | grep -o '^302 .*/sucursales?ver=[0-9]*$' | cut -c1-3)" 302
SUCURSAL=$(printf '%s' "$R" | grep -o '[0-9]*$')
LISTA=$(pagina "/sucursales?ver=$SUCURSAL")
dice "el listado trae el aviso del alta"  "$LISTA" 'Sucursal dada de alta'
dice "y el modal de Ver"                  "$LISTA" 'id="modal-detalle-sucursal"'
dice "con Exportar"                       "$LISTA" 'href="/sucursales.xlsx"'
FICHA=$(pagina_json "/sucursales/$SUCURSAL")
dice "la ficha en JSON la nombra"         "$FICHA" "Sucursal Humo $S"
dice "y trae su html"                     "$FICHA" '"html":'
juzga "la URL vieja de la ficha llega al listado" "$(curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code} %{redirect_url}' "$BASE/sucursales/$SUCURSAL")" "302 $BASE/sucursales?ver=$SUCURSAL"
juzga "Exportar da un XLSX" "$(curl -s -m 20 -b "$GALLETAS" -o /dev/null -w '%{http_code} %{content_type}' "$BASE/sucursales.xlsx" | cut -c1-3)" 200
dice "y el teléfono quedó limpio"         "$FICHA" '2221234567'

R=$(postea_json /sucursales --data-urlencode "nombre=Sucursal sin clave $S")
juzga "la clave pública es obligatoria" "${R##*|}" 422
dice  "y señala el campo clave" "$R" '"clave":"Capture la clave pública"'
R=$(postea_json /sucursales --data-urlencode "nombre=Sucursal Humo $S" --data-urlencode "clave=S$S")
juzga "el mismo nombre otra vez da 422" "${R##*|}" 422
dice  "con la queja en el campo nombre" "$R" '"nombre":"Ya hay una sucursal activa'
R=$(postea_json /sucursales --data-urlencode "nombre=Sucursal Clave $S" --data-urlencode "clave=$CLAVE_SUC")
juzga "la misma clave otra vez da 422" "${R##*|}" 422
dice  "con la queja en el campo clave" "$R" '"clave":"Ya hay una sucursal activa'

R=$(postea_json /sucursales --data-urlencode "nombre=<b>Sucursal</b> Otra $S" --data-urlencode "clave=O$S")
juzga "una segunda sucursal por JSON contesta 200" "${R##*|}" 200
dice  "y dice a dónde ir" "$R" '"redirige":"/sucursales?ver=[0-9]*"'
OTRA=$(printf '%s' "$R" | sed -n 's/.*"redirige":"\/sucursales?ver=\([0-9]*\)".*/\1/p')
dice "el nombre con etiquetas se pinta escapado" "$(pagina /sucursales)" "&lt;b&gt;Sucursal&lt;/b&gt; Otra $S"

R=$(postea "/sucursales/$SUCURSAL" --data-urlencode "nombre=Sucursal Humo Editada $S" --data-urlencode "clave=$CLAVE_SUC" --data-urlencode "volver=/sucursales")
juzga "la edición regresa a la lista de donde se mandó" "$R" "302 $BASE/sucursales"
dice  "y el nombre cambió" "$(pagina /sucursales)" "Sucursal Humo Editada $S"

R=$(postea "/sucursales/$SUCURSAL" --data-urlencode "nombre=Sucursal Humo Editada $S" --data-urlencode "clave=$CLAVE_SUC" --data-urlencode "volver=https://otro.sitio/robo")
juzga "un «volver» a otro sitio se ignora" "$R" "302 $BASE/sucursales?ver=$SUCURSAL"

juzga "una sucursal que no existe da 404" "$(curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' -H 'Accept: application/json' "$BASE/sucursales/65000")" 404

echo "${gris}bajas${nada}"
"$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  require "'"$RAIZ"'/pruebas/Semilla.php";
  $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
  Pruebas\Semilla::usuario($bd, "humo.org.cocina", "cocina", $argv[1], (int) $argv[2]);
' "$CLAVE" "$SUCURSAL"
R=$(postea_json "/sucursales/$SUCURSAL/baja")
juzga "la sucursal con personal activo no se da de baja: 409" "${R##*|}" 409
dice  "y se dice por qué" "$R" 'una persona del personal'
"$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  require "'"$RAIZ"'/pruebas/Semilla.php";
  $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
  Pruebas\Semilla::borraUsuarios($bd, "humo.org.cocina");
'
juzga "sin personal, sí se da de baja" "$(postea_json "/sucursales/$SUCURSAL/baja" | sed 's/.*|//')" 200
calla "la sucursal ya no sale entre las activas" "$(pagina /sucursales)" "Sucursal Humo Editada $S"
dice  "pero sí entre las dadas de baja" "$(pagina '/sucursales?estatus=inactivas')" "Sucursal Humo Editada $S"
juzga "y se reactiva" "$(postea_json "/sucursales/$SUCURSAL/reactiva" | sed 's/.*|//')" 200

echo "${gris}sin la marca${nada}"
juzga "un POST sin marca da 419" \
  "$(curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' -d "nombre=Sin marca $S" "$BASE/sucursales")" 419

# --- gerente: consulta, no escribe -----------------------------------------
echo "${gris}gerente${nada}"
entra humo.org.super
juzga "ve la lista de sucursales" "$(codigo /sucursales)" 200
calla "sin botón de alta" "$(pagina /sucursales)" 'data-bs-target="#modalSucursal"'
juzga "pero dar de alta le da 403" "$(postea_json /sucursales --data-urlencode "nombre=Intrusa $S" | sed 's/.*|//')" 403
juzga "y dar de baja una sucursal también" "$(postea_json "/sucursales/$OTRA/baja" | sed 's/.*|//')" 403

# --- mesero: ni consulta ----------------------------------------------------
echo "${gris}mesero${nada}"
entra humo.org.mesero
juzga "no ve las sucursales" "$(codigo /sucursales)" 403
calla "ni el menú se las ofrece" "$(pagina /panel)" 'href="/sucursales"'

echo
if [ "$fallas" -eq 0 ]; then
  echo "${verde}${pasadas} comprobaciones, todas pasan.${nada}"
else
  echo "${rojo}${fallas} de $((pasadas + fallas)) fallan.${nada}"
  exit 1
fi
