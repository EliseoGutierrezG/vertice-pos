import assert from 'node:assert/strict';
import { test } from 'node:test';
import { versionAnterior } from '../app/src/nucleo/compatibilidad.ts';

test('la versión mínima compara números, incluidas las versiones de dos dígitos', () => {
    assert.equal(versionAnterior('1.0.0', '1.0.1'), true);
    assert.equal(versionAnterior('1.9.0', '1.10.0'), true);
    assert.equal(versionAnterior('1.10.0', '1.9.0'), false);
    assert.equal(versionAnterior('2.0.0', '1.99.99'), false);
    assert.equal(versionAnterior('1.0.0', '1.0.0'), false);
});
test('un servidor anterior o un valor ilegible no bloquea por una comparación inventada', () => {
    assert.equal(versionAnterior('1.0.0', ''), false);
    assert.equal(versionAnterior('1.0.0', 'no-es-version'), false);
});
