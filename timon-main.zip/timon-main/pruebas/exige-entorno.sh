#!/usr/bin/env bash
# Cerrojo común para cualquier prueba que escriba o borre datos.
# El entorno de pruebas es el predeterminado, pero una selección explícita se
# respeta y se valida antes de ejecutar la primera sentencia destructiva.

if [ -z "${RAIZ:-}" ]; then
  echo "CERROJO: el guion debe definir RAIZ antes de cargar exige-entorno.sh" >&2
  exit 1
fi

if [ -z "${PHP:-}" ]; then
  PHP=/opt/homebrew/opt/php@8.3/bin/php
fi

export APP_ENTORNO="${APP_ENTORNO:-pruebas}"

if [ -n "${BASE:-}" ]; then
  "$PHP" "$RAIZ/pruebas/verifica-entorno.php" "$BASE" >/dev/null || exit 1
else
  "$PHP" "$RAIZ/pruebas/verifica-entorno.php" >/dev/null || exit 1
fi

# Cada POST de formulario lleva su llave de envío, como en el navegador.
. "$RAIZ/pruebas/fixtures/envio-unico.sh"
