<?php
declare(strict_types=1);

use Pruebas\Afirma;

/**
 * La documentación, como parte del proyecto y no como adorno.
 *
 * Este proyecto se documenta conforme avanza, y crece con cada fase. Un enlace
 * roto o un documento al que nadie apunta no rompen nada hoy: rompen mañana,
 * cuando alguien llegue buscando y no encuentre. Igual que las reglas de
 * arquitectura, esto se comprueba en lugar de confiarse.
 *
 * Lo que **no** se comprueba aquí: que lo escrito sea cierto. Eso lo sostienen
 * las otras pruebas, y en última instancia leerlo.
 */

$raiz = dirname(__DIR__);

/** @return list<string> todos los .md del proyecto, menos los de node_modules y los borradores de `tmp/` y `output/` */
$documentos = static function (string $raiz): array {
    $todos    = [];
    $iterador = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($raiz, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($iterador as $archivo) {
        $ruta = $archivo->getPathname();

        $corto = substr($ruta, strlen($raiz) + 1);
        if (str_ends_with($ruta, '.md') && !str_contains($ruta, '/node_modules/')
            && !str_starts_with($corto, 'tmp/') && !str_starts_with($corto, 'output/')) {
            $todos[] = $ruta;
        }
    }

    sort($todos);

    return $todos;
};

/** @return list<string> los destinos relativos que enlaza un documento */
$enlaces = static function (string $archivo): array {
    preg_match_all('/\]\(([^)\s]+)\)/', file_get_contents($archivo) ?: '', $coincidencias);

    $destinos = [];

    foreach ($coincidencias[1] as $enlace) {
        if (preg_match('#^(https?://|mailto:|\#)#', $enlace) === 1) {
            continue;
        }

        // Se quita el ancla: lo que se comprueba es que el archivo exista.
        $destinos[] = explode('#', $enlace)[0];
    }

    return $destinos;
};

return [
    'ningún documento reproduce el valor de un secreto' => function () use ($raiz, $documentos): void {
        // ⚠️ Pasó, y en esta misma bitácora: al documentar que el registro de
        // errores escribía trozos de contraseña, **copié el trozo**. Quince
        // caracteres de una contraseña de pruebas, en un documento que se lee en
        // voz alta. La regla de `CLAUDE.md` es de una línea: se indica **dónde**
        // están los secretos, no cuánto valen.
        //
        // La regla busca una cadena entrecomillada que parezca un valor —diez
        // caracteres o más, con mayúscula y dígito— en un renglón que hable de
        // contraseñas, tokens o llaves. Pide las dos cosas a la vez para no
        // señalar cada nombre de clase ni cada ruta.
        $hablaDeSecretos = '/contrase|clave|token|secret|llave|passw/i';
        $pareceUnValor   = '/[`\'"]([A-Za-z0-9!@#$%^&*.+-]{10,})[`\'"]/';
        $culpables       = [];

        foreach ($documentos($raiz) as $archivo) {
            foreach (explode("\n", file_get_contents($archivo) ?: '') as $numero => $linea) {
                if (preg_match($hablaDeSecretos, $linea) !== 1) {
                    continue;
                }

                if (preg_match_all($pareceUnValor, $linea, $hallados) === 0) {
                    continue;
                }

                foreach ($hallados[1] as $valor) {
                    // Un nombre de clase, un archivo o una constante no es un
                    // valor: llevan punto, guion bajo o barra.
                    if (preg_match('/[._\/\\\\]/', $valor) === 1) {
                        continue;
                    }

                    if (preg_match('/[A-Z]/', $valor) !== 1 || preg_match('/[0-9]/', $valor) !== 1) {
                        continue;
                    }

                    // No se escribe el valor en el mensaje de la falla: se dice
                    // dónde está. Sería el mismo error otra vez.
                    $culpables[] = str_replace($raiz . '/', '', $archivo) . ':' . ($numero + 1);
                }
            }
        }

        Afirma::igual([], array_values(array_unique($culpables)), 'renglones con lo que parece el valor de un secreto');
    },

    'todos los enlaces de la documentación resuelven' => function () use ($raiz, $documentos, $enlaces): void {
        $rotos   = [];
        $cuantos = 0;

        foreach ($documentos($raiz) as $archivo) {
            foreach ($enlaces($archivo) as $destino) {
                if ($destino === '') {
                    continue;
                }

                $cuantos++;

                if (!file_exists(dirname($archivo) . '/' . $destino)) {
                    $rotos[] = str_replace($raiz . '/', '', $archivo) . ' → ' . $destino;
                }
            }
        }

        // Si un día esto revisa doce enlaces, el recorrido se rompió y la
        // prueba pasaría en verde sin haber mirado nada.
        Afirma::cierto($cuantos > 15, "se revisaron $cuantos enlaces relativos");
        Afirma::igual([], $rotos, 'enlaces que no llevan a ninguna parte');
    },

    'no hay ningún documento al que nadie apunte' => function () use ($raiz, $documentos, $enlaces): void {
        // Se entra por donde entra una persona: el índice de docs/ y los dos
        // documentos de la raíz. Desde ahí se sigue cada enlace. Un documento al
        // que no se llega existe nada más para quien ya sabía que existía.
        $porVisitar = [
            $raiz . '/docs/README.md',
            $raiz . '/README.md',
            $raiz . '/CLAUDE.md',
        ];

        $vistos = [];

        while ($porVisitar !== []) {
            $actual = array_pop($porVisitar);
            $real   = realpath($actual);

            if ($real === false || isset($vistos[$real])) {
                continue;
            }

            $vistos[$real] = true;

            foreach ($enlaces($real) as $destino) {
                if (!str_ends_with($destino, '.md')) {
                    continue;
                }

                $porVisitar[] = dirname($real) . '/' . $destino;
            }
        }

        $huerfanos = [];

        foreach ($documentos($raiz . '/docs') as $archivo) {
            if (!isset($vistos[realpath($archivo) ?: $archivo])) {
                $huerfanos[] = str_replace($raiz . '/', '', $archivo);
            }
        }

        Afirma::cierto(count($vistos) >= 4, 'el recorrido pasó por la documentación entera');
        Afirma::igual([], $huerfanos, 'documentos a los que no se llega desde el índice');
    },
];
