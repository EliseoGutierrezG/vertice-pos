<?php
declare(strict_types=1);

use Pruebas\Afirma;

/**
 * La configuración y sus plantillas (paso 20.3).
 *
 * Desplegar consiste, en buena parte, en copiar dos archivos y rellenarlos. Lo
 * que se rompe ahí no se rompe con un error: se rompe en silencio —la cookie
 * sin `Secure`, la traza del error en la pantalla del cliente— y nadie se
 * entera. Así que las plantillas se prueban como código.
 *
 * Las dos preguntas que contesta esto:
 *  - ¿La plantilla tiene **las mismas llaves** que la configuración de verdad?
 *    Una plantilla a la que le falta una llave es peor que no tenerla, porque se
 *    copia, arranca, y falla el día que alguien toca esa parte.
 *  - ¿La plantilla trae valores **de mentira**? Es un archivo hecho para
 *    compartirse; si alguna vez lleva la contraseña de verdad, la lleva a donde
 *    se comparta.
 */

$raiz = dirname(__DIR__);

/** @return array<string,mixed> */
$lee = static function (string $ruta): array {
    /** @var array<string,mixed> $valores */
    $valores = require $ruta;

    return $valores;
};

return [
    'el servidor de sucursal admite PHP 8.2 o posterior' => function () use ($raiz): void {
        Afirma::cierto(version_compare(PHP_VERSION, '8.2.0', '>='), 'las pruebas corren con ' . PHP_VERSION);
        Afirma::contiene("version_compare(PHP_VERSION, '8.2.0', '>=')", (string) file_get_contents($raiz . '/guiones/verifica-host.php'), 'el mínimo del hospedaje');
        Afirma::contiene("version_compare(PHP_VERSION, '8.2.0', '>=')", (string) file_get_contents($raiz . '/controladores/Sistema/Diagnostico.php'), 'el diagnóstico');
    },

    'cada configuración tiene su plantilla, con las mismas llaves' => function () use ($raiz, $lee): void {
        foreach (['bd', 'app', 'seguridad'] as $cual) {
            $real      = $raiz . "/config/$cual.php";
            $plantilla = $real . '.ejemplo';

            Afirma::cierto(is_file($plantilla), "existe config/$cual.php.ejemplo");

            $llavesReales     = array_keys($lee($real));
            $llavesPlantilla  = array_keys($lee($plantilla));

            sort($llavesReales);
            sort($llavesPlantilla);

            Afirma::igual(
                $llavesReales,
                $llavesPlantilla,
                "config/$cual.php.ejemplo pide exactamente lo que el sistema lee"
            );
        }
    },

    'la plantilla trae los valores de producción, que son los que se olvidan' => function () use ($raiz, $lee): void {
        $ejemplo = $lee($raiz . '/config/app.php.ejemplo');

        // `entorno` no es decorativo: de él depende que la cookie de sesión
        // lleve `Secure`, y sin `Secure` la sesión viaja en claro la primera vez
        // que alguien teclee la dirección sin la s.
        Afirma::igual('produccion', $ejemplo['entorno'], 'la plantilla viene en produccion');
        Afirma::falso((bool) $ejemplo['depurar'], 'y con la depuración apagada');

        // Y la de local, al revés: si un día quedara en `produccion`, la cookie
        // exigiría HTTPS y nadie podría entrar al sitio de desarrollo.
        $local = $lee($raiz . '/config/app.php');
        Afirma::igual('local', $local['entorno'], 'la de esta máquina sigue siendo local');

        foreach ([$ejemplo, $local] as $cual => $config) {
            $registros = (string) $config['registros'];
            Afirma::falso(
                str_contains(str_replace('\\', '/', realpath(dirname($registros)) ?: $registros), '/publico/'),
                'los registros de error no se escriben donde el navegador los pueda leer'
            );
        }
    },

    'la plantilla no lleva ningún valor de verdad' => function () use ($raiz, $lee): void {
        $real    = $lee($raiz . '/config/bd.php');
        $ejemplo = $lee($raiz . '/config/bd.php.ejemplo');

        // Se comparan, no se imprimen: si esto falla, el mensaje dice cuál
        // llave coincide y nunca cuánto vale.
        foreach (['base', 'usuario', 'clave'] as $llave) {
            Afirma::falso(
                (string) $ejemplo[$llave] === (string) $real[$llave],
                "la plantilla no trae el valor real de «{$llave}»"
            );
        }

        // Y la contraseña tampoco escondida en un comentario. Sólo la
        // contraseña: el nombre de usuario local es corto y aparece de verdad
        // dentro del de la plantilla (`u00000000_timon`), así que buscarlo
        // daría una falla que no es una falla. El secreto es la contraseña.
        $texto = (string) file_get_contents($raiz . '/config/bd.php.ejemplo');
        Afirma::cierto(strlen((string) $real['clave']) >= 8, 'la contraseña local es razonable');
        Afirma::falso(
            str_contains($texto, (string) $real['clave']),
            'ni en los comentarios del archivo'
        );

        Afirma::igual(3306, $ejemplo['puerto'], 'el puerto es el de siempre, sin adivinar');

        $seguridadReal = $lee($raiz . '/config/seguridad.php');
        $seguridadEjemplo = $lee($raiz . '/config/seguridad.php.ejemplo');
        Afirma::falso(
            hash_equals((string) $seguridadReal['llave_totp'], (string) $seguridadEjemplo['llave_totp']),
            'la plantilla de segundo factor no contiene la llave real'
        );
        Afirma::igual(32, strlen((string) base64_decode((string) $seguridadReal['llave_totp'], true)), 'la llave TOTP local tiene 32 bytes');
    },
];
