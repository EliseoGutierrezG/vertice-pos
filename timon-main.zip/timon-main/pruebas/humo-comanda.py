#!/usr/bin/env python3
"""Comprueba la comanda local con varios trabajadores PHP y solicitudes HTTP paralelas."""

from base64 import b64decode
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
import json
import os
from pathlib import Path
import secrets
import signal
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import uuid

RAIZ = Path(__file__).resolve().parents[1]
PHP = "/opt/homebrew/opt/php@8.3/bin/php"
LOTE = secrets.token_hex(3)
ENV = {**os.environ, "APP_ENTORNO": "pruebas", "PHP_CLI_SERVER_WORKERS": "6"}


def fixture(modo, *args):
    return subprocess.check_output([PHP, str(RAIZ / "pruebas/fixtures/comanda.php"), modo, LOTE, *map(str, args)],
                                   env=ENV, text=True)


def pide(ruta, token=None, datos=None, llave=None, secreto=None, espera=200):
    cabeceras = {"Accept": "application/json"}
    if token:
        cabeceras["Authorization"] = f"Bearer {token}"
    if secreto:
        cabeceras["X-Equipo"] = secreto
    if datos is not None:
        cabeceras["Content-Type"] = "application/json"
        cabeceras["Idempotency-Key"] = str(llave or uuid.uuid4())
    solicitud = urllib.request.Request(BASE + ruta, json.dumps(datos).encode() if datos is not None else None, cabeceras)
    try:
        respuesta = urllib.request.urlopen(solicitud, timeout=10)
    except urllib.error.HTTPError as error:
        respuesta = error
    with respuesta:
        estado = respuesta.status
        crudo = respuesta.read()
    if espera is not None and estado != espera:
        raise AssertionError(f"{ruta}: esperaba {espera}, recibió {estado}: {crudo[:220]!r}")
    salida = json.loads(crudo) if ruta.startswith("/api/") else crudo
    return estado, salida.get("datos", salida.get("error")) if isinstance(salida, dict) else salida


def api(ruta, *args, **kwargs):
    return pide("/api/v1" + ruta, *args, **kwargs)[1]


def equipo(tipo, rol, plataforma="web"):
    registro = api("/equipo", datos={"nombre": f"Prueba {tipo}", "plataforma": plataforma}, espera=201)
    fixture("autoriza", registro["codigo"], tipo)
    token = api("/equipo/entrar", datos={"usuario": f"{DATOS['prefijo']}{rol}", "pin": DATOS["pin"]},
                secreto=registro["secreto"])
    return token["token"]


def en_paralelo(peticiones, esperados):
    with ThreadPoolExecutor(max_workers=len(peticiones)) as grupo:
        futuros = [grupo.submit(pide, "/api/v1" + ruta, token, datos, llave, espera=None)
                   for ruta, token, datos, llave in peticiones]
        respuestas = [f.result() for f in futuros]
    assert sorted(r[0] for r in respuestas) == sorted(esperados), respuestas
    return respuestas


def recibe_escpos(trabajo):
    """Entrega los bytes al receptor TCP local, sin contactar la IP de la impresora."""
    datos = b64decode(trabajo["bytes"], validate=True)
    with socket.socket() as servidor:
        servidor.bind(("127.0.0.1", 0))
        servidor.listen(1)
        servidor.settimeout(5)
        with socket.create_connection(servidor.getsockname(), timeout=5) as cliente:
            cliente.sendall(datos)
            cliente.shutdown(socket.SHUT_WR)
        conexion, _ = servidor.accept()
        with conexion, conexion.makefile("rb") as receptor:
            return receptor.read()



def prueba():
    mesero = equipo("mesero", "mesero")
    caja = equipo("caja", "cajero")
    cocina = equipo("cocina", "cocina")
    impresor = equipo("impresor", "gerente", "android")
    mesas = DATOS["mesas"]
    api("/plano", espera=401)
    api("/plano", cocina, espera=403)
    api("/caja", mesero, espera=403)

    cursor = api("/plano", caja)["cursor"]
    respuestas = en_paralelo([
        ("/cuentas", mesero, {"id_mesa": mesas[0]}, uuid.uuid4()),
        ("/cuentas", caja, {"id_mesa": mesas[0]}, uuid.uuid4()),
    ], [201, 409])
    id_cuenta = next(datos["id"] for estado, datos in respuestas if estado == 201)
    assert next(datos["estado_actual"] for estado, datos in respuestas if estado == 409)["id_cuenta"] == id_cuenta
    cambio = api(f"/cambios?desde={cursor}", caja)
    assert any(e["tipo"] == "cuenta_abierta" and e["entidad"] == id_cuenta for e in cambio["eventos"])
    assert api("/plano", caja)["mesas"][0]["id_cuenta"] == id_cuenta
    print("✓ Dos equipos simultáneos reciben 201 y 409. El segundo ve la cuenta en el plano.")

    # La carta viaja con huella: quien ya la tiene recibe un 304 sin cuerpo.
    def carta(huella=None):
        cabeceras = {"Accept": "application/json", "Authorization": f"Bearer {mesero}"}
        if huella:
            cabeceras["If-None-Match"] = huella
        try:
            respuesta = urllib.request.urlopen(urllib.request.Request(BASE + "/api/v1/carta", None, cabeceras), timeout=10)
        except urllib.error.HTTPError as error:
            respuesta = error
        with respuesta:
            return respuesta.status, respuesta.headers.get("ETag"), respuesta.read()
    estado, huella, cuerpo = carta()
    assert estado == 200 and huella and b"Tostada de at" in cuerpo
    assert carta(huella) == (304, huella, b"")
    assert carta('"otra"')[0] == 200
    ahora = api("/cambios", cocina)
    assert ahora["eventos"] == [] and ahora["cursor"] >= cursor
    assert api("/cocina", cocina)["cursor"] >= cursor
    print("✓ La carta responde 304 con su huella. Cocina e impresor obtienen el cursor sin cargar el plano.")

    otra = api("/cuentas", caja, {"id_mesa": mesas[1]}, espera=201)["id"]
    en_paralelo([
        (f"/cuentas/{id_cuenta}/cambia-mesa", mesero, {"id_mesa": mesas[2], "version": 1}, uuid.uuid4()),
        (f"/cuentas/{otra}/cambia-mesa", caja, {"id_mesa": mesas[2], "version": 1}, uuid.uuid4()),
    ], [200, 409])
    v1 = api(f"/cuentas/{id_cuenta}", caja)["version"]
    v2 = api(f"/cuentas/{otra}", caja)["version"]
    en_paralelo([
        (f"/cuentas/{id_cuenta}/une-mesa", mesero, {"id_mesa": mesas[3], "version": v1}, uuid.uuid4()),
        (f"/cuentas/{otra}/une-mesa", caja, {"id_mesa": mesas[3], "version": v2}, uuid.uuid4()),
    ], [200, 409])
    api("/cuentas", mesero, {"id_mesa": mesas[3]}, espera=409)
    print("✓ Cambiar y unir la misma mesa en paralelo admite una sola cuenta.")

    version = api(f"/cuentas/{id_cuenta}", caja)["version"]
    item = api(f"/cuentas/{id_cuenta}/items", mesero, {
        "version": version, "id_platillo": DATOS["platillo"], "cantidad": 2,
        "asiento": 1, "tiempo": "entrada", "modificadores": [DATOS["modificador"]],
    }, espera=201)
    version = item["version"]
    llave = uuid.uuid4()
    rondas = en_paralelo([
        (f"/cuentas/{id_cuenta}/rondas", mesero, {"version": version}, llave) for _ in range(3)
    ], [201, 201, 201])
    assert len({r[1]["id_ronda"] for r in rondas}) == 1
    ronda = rondas[0][1]["id_ronda"]
    detalle = api("/cocina", cocina)["items"]
    assert len(detalle) == 1 and detalle[0]["id_ronda"] == ronda and detalle[0]["cantidad"] == 2

    # Cocina avanza mientras el mesero sigue capturando. Tres capturas llevan
    # una versión vieja, como las mandaría una app anterior, y dos no la llevan.
    cursor = api("/plano", caja)["cursor"]
    antes = api(f"/cuentas/{id_cuenta}", caja)["version"]
    platillo = {"id_platillo": DATOS["platillo"], "cantidad": 1}
    juntas = en_paralelo(
        [(f"/cocina/{ronda}/preparar", cocina, {"area": "fria"}, uuid.uuid4())]
        + [(f"/cuentas/{id_cuenta}/items", mesero, {**platillo, "version": 1}, uuid.uuid4()) for _ in range(3)]
        + [(f"/cuentas/{id_cuenta}/items", mesero, platillo, uuid.uuid4()) for _ in range(2)],
        [200, 201, 201, 201, 201, 201])
    extras = [d["id_item"] for e, d in juntas if e == 201]
    assert len(set(extras)) == 5
    assert api(f"/cuentas/{id_cuenta}", caja)["version"] == antes + 5
    eventos = api(f"/cambios?desde={cursor}", caja)["eventos"]
    assert sum(e["tipo"] == "item_capturado" and e["id_cuenta"] == id_cuenta for e in eventos) == 5
    assert any(e["tipo"] == "cocina_avance" and e["entidad"] == ronda and e["id_cuenta"] == id_cuenta for e in eventos)
    api(f"/cocina/{ronda}/listo", cocina, {"area": "fria"})
    assert api(f"/cuentas/{id_cuenta}", caja)["version"] == antes + 5
    assert any(m["id_cuenta"] == id_cuenta and int(m["listos"]) == 2 for m in api("/plano", mesero)["mesas"])
    api(f"/cuentas/{id_cuenta}/estado-item", mesero, {"id_item": item["id_item"], "estado": "entregado"})
    assert api(f"/cuentas/{id_cuenta}", caja)["version"] == antes + 5
    assert not any(m["id_cuenta"] == id_cuenta and int(m["listos"]) for m in api("/plano", mesero)["mesas"])
    print("✓ Cocina avanza y cinco capturas simultáneas entran sin choque. Sólo lo capturado cambia la versión.")

    llave = uuid.uuid4()
    repetido = [api(f"/cuentas/{id_cuenta}/items", mesero, platillo, llave, espera=201)["id_item"] for _ in range(2)]
    assert repetido[0] == repetido[1]
    extras.append(repetido[0])
    activos = lambda cuenta: [i for i in api(f"/cuentas/{cuenta}", caja)["items"] if i["estado"] != "cancelado"]
    assert len(activos(id_cuenta)) == 7
    api(f"/cuentas/{id_cuenta}/edita-item", mesero, {"id_item": extras[0], "cantidad": 3, "nota": "Sin cebolla"})
    assert next(i for i in activos(id_cuenta) if i["id"] == extras[0])["cantidad"] == 3
    api(f"/cuentas/{id_cuenta}/edita-item", mesero, {"id_item": item["id_item"], "cantidad": 1}, espera=409)

    # Transferir sólo pide la versión del origen: al destino le basta seguir abierto.
    cursor = api("/plano", caja)["cursor"]
    version = api(f"/cuentas/{id_cuenta}", caja)["version"]
    api(f"/cuentas/{id_cuenta}/transfiere", mesero, {"version": version, "id_item": extras[0], "id_destino": otra})
    assert [i["id"] for i in activos(otra)] == [extras[0]]
    eventos = api(f"/cambios?desde={cursor}", caja)["eventos"]
    assert any(e["tipo"] == "item_recibido" and e["id_cuenta"] == otra for e in eventos)
    for sobrante in extras[1:]:
        api(f"/cuentas/{id_cuenta}/estado-item", mesero, {"id_item": sobrante, "estado": "cancelado", "motivo": "Prueba"})
    assert len(activos(id_cuenta)) == 1
    print("✓ La misma llave captura una sola vez. Un platillo sin enviar se corrige, se transfiere y se cancela.")
    fixture("demora-impresion")
    assert api("/caja", caja)["impresiones_demoradas"] == 1
    assert api("/cocina", cocina)["impresiones_demoradas"] == 1
    trabajo = api("/impresiones/tomar", impresor, {})
    assert trabajo["puerto"] == 9100 and trabajo["intento"] == 1
    confirma = f"/impresiones/{trabajo['id']}/confirmar"
    for intento in [1, 2, 3]:
        fallo = {"impreso": False, "intento": intento, "reintentable": True}
        api(confirma, impresor, fallo)
        api(confirma, impresor, fallo)
        if intento < 3:
            api(f"/impresiones/{trabajo['id']}/reimprimir", caja, {}, espera=409)
            nueva = api("/impresiones/tomar", impresor, {})
            assert nueva["id"] == trabajo["id"] and nueva["intento"] == intento + 1
            api(confirma, impresor, fallo)
    copia = api(f"/impresiones/{trabajo['id']}/reimprimir", caja, {}, espera=201)
    trabajo_copia = api("/impresiones/tomar", impresor, {})
    assert trabajo_copia["id"] == copia["id"]
    recibido = recibe_escpos(trabajo_copia)
    assert recibido.startswith(b"\x1b@REIMPRESION")
    assert b"Tostada de atun" in recibido and recibido.endswith(b"\x1dV\x00")
    api(f"/impresiones/{copia['id']}/confirmar", impresor, {"impreso": True, "intento": 1})
    assert api("/caja", caja)["impresiones_demoradas"] == 0
    print("✓ Tres intentos de impresión ante fallo antes de escribir. Los acuses repetidos no alteran otro intento.")
    print("✓ Cocina avanza estados y el plano avisa cuántos listos hay. La copia ESC/POS llega al receptor TCP local.")

    agotado = f"/carta/{DATOS['platillo']}/agotado"
    api(agotado, mesero, {"agotado": 1}, espera=403)
    _, huella, _ = carta()
    api(agotado, cocina, {"agotado": 1})
    assert carta(huella)[0] == 200 and api("/carta", caja)[0]["agotado"] == 1
    api(agotado, cocina, {"agotado": 0})
    assert api("/carta", caja)[0]["agotado"] == 0
    print("✓ Cocina marca disponibilidad sin tocar el precio. Cambia la huella de la carta y se rechaza al mesero.")

    turno = api("/caja/abrir", caja, {"fondo": "500.00"})["id"]
    assert "fondo" not in api("/caja", caja)["turno"]
    formas = {"propina": "20.00", "formas": [
        {"medio": "efectivo", "importe": "100.00", "recibido": "200.00"},
        {"medio": "tarjeta", "importe": "180.00", "referencia": "terminal-prueba"},
    ]}
    # Un platillo que entra después de calcular el cobro lo detiene, y además
    # regresa la cuenta a «ocupada» para pedir otra precuenta.
    vieja = api(f"/cuentas/{id_cuenta}", caja)["version"]
    api(f"/cuentas/{id_cuenta}/precuenta", mesero, {})
    assert api(f"/cuentas/{id_cuenta}", caja)["estado"] == "cuenta_pedida"
    tardio = api(f"/cuentas/{id_cuenta}/items", mesero, platillo, espera=201)["id_item"]
    assert api(f"/cuentas/{id_cuenta}", caja)["estado"] == "ocupada"
    rechazo = api(f"/cuentas/{id_cuenta}/cobro", caja, {**formas, "version": vieja}, espera=409)
    assert rechazo["estado_actual"]["motivo"] == "version"
    api(f"/cuentas/{id_cuenta}/estado-item", mesero, {"id_item": tardio, "estado": "cancelado", "motivo": "Prueba"})
    # La precuenta no cambia lo que se cobra: la versión tomada antes sigue valiendo.
    version = api(f"/cuentas/{id_cuenta}", caja)["version"]
    api(f"/cuentas/{id_cuenta}/precuenta", mesero, {})
    datos = {**formas, "version": version}
    cobros = en_paralelo([
        (f"/cuentas/{id_cuenta}/cobro", caja, datos, uuid.uuid4()) for _ in range(2)
    ], [201, 409])
    cobrado = next(d for e, d in cobros if e == 201)
    folio = f"{DATOS['publica']}-000001"
    assert cobrado["folio"] == folio and cobrado["cambio"] == "100.00" and cobrado["pagado"] == "280.00"
    assert cobrado["faltantes"] == []
    pagina = pide(cobrado["ticket"])[1]
    assert b"Ticket " + folio.encode() in pagina and b"Recibido" in pagina and b"Cambio" in pagina
    assert json.loads(fixture("comprueba")) == {"lotes": ["0.600", "1.000"], "rondas": 1, "pagos": 1}

    # Una receta sin existencia no detiene el cobro: lo que falta se registra.
    api(f"/cuentas/{otra}/items", mesero, {**platillo, "cantidad": 6}, espera=201)
    api(f"/cuentas/{otra}/rondas", mesero, {}, espera=201)
    version = api(f"/cuentas/{otra}", caja)["version"]
    tarjeta = {"version": version, "formas": [{"medio": "tarjeta", "importe": "1125.00", "referencia": "terminal-prueba"}]}
    api(f"/cuentas/{otra}/cobro", caja, {**tarjeta, "formas": [{**tarjeta["formas"][0], "recibido": "1200.00"}]}, espera=422)
    escaso = api(f"/cuentas/{otra}/cobro", caja, tarjeta, espera=201)
    assert escaso["folio"] == f"{DATOS['publica']}-000002" and escaso["cambio"] == "0.00"
    assert [f["cantidad"] for f in escaso["faltantes"]] == ["0.200"]
    assert json.loads(fixture("comprueba")) == {"lotes": ["0.000", "0.000"], "rondas": 2, "pagos": 2}

    cierre = api("/caja/cerrar", caja, {"id_turno": turno, "efectivo": "600.00"})
    assert cierre["esperado"] == "600.00" and cierre["diferencia"] == "0.00"
    assert cierre["resumen"]["formas"] == {"efectivo": "100.00", "tarjeta": "1305.00", "transferencia": "0.00"}
    assert cierre["resumen"]["cobros"] == 2 and cierre["resumen"]["propinas"] == "20.00"
    cerrada = api(f"/cuentas/{id_cuenta}/items", mesero, platillo, espera=409)
    assert cerrada["estado_actual"]["motivo"] == "cerrada"
    print("✓ Un solo cobro, pago mixto con cambio, propina, ticket con folio y corte desglosado. FEFO descuenta una sola vez.")
    print("✓ Folios consecutivos por sucursal. Cobrar sin existencia registra el faltante y no se detiene.")

    prueba_cuentas_separadas_y_mostrador(mesero, caja, cocina, mesas[4], platillo)
    prueba_promociones(mesero, caja, mesas[5], platillo)

    futuro = (datetime.now().astimezone() + timedelta(minutes=15)).strftime("%Y-%m-%dT%H:%M")
    reserva = {"sucursal": DATOS["publica"], "cliente": "Prueba", "telefono": "5512345678",
        "personas": "2", "desde": futuro, "nota": "Mesa cerca de la entrada"}
    folios = [api("/reservaciones", datos=reserva, espera=201)["folio"] for _ in range(6)]
    assert len(set(folios)) == 6 and all(f.startswith("RES-") for f in folios)
    fixture("confirma-reserva", mesas[7])
    assert api("/cuentas", mesero, {"id_mesa": mesas[7]}, espera=409)["estado_actual"]["estado"] == "reservada"
    assert b"Tostada de at" in pide("/menu/" + DATOS["publica"])[1]
    print("✓ Seis solicitudes válidas reciben folios distintos. Confirmar una reserva bloquea la mesa.")
    print("✓ La carta pública muestra el menú de su sucursal.")

    def sonda(_):
        inicio = time.perf_counter()
        for _ in range(5):
            api("/cambios?desde=0", mesero)
            time.sleep(.2)
        return (time.perf_counter() - inicio) / 5 - .2

    with ThreadPoolExecutor(max_workers=10) as grupo:
        tiempos = list(grupo.map(sonda, range(10)))
    print(f"✓ Sondeo con 10 clientes, 50 respuestas válidas. Mayor promedio por cliente: {max(tiempos) * 1000:.0f} ms.")


def prueba_cuentas_separadas_y_mostrador(mesero, caja, cocina, mesa, platillo):
    turno = api("/caja/abrir", caja, {"fondo": "0.00"})["id"]
    origen = api("/cuentas", mesero, {"id_mesa": mesa}, espera=201)["id"]

    def cuenta(id_cuenta=None):
        return api(f"/cuentas/{origen if id_cuenta is None else id_cuenta}", caja)

    def cambia(accion, datos, llave=None, espera=200):
        return api(f"/cuentas/{origen}/{accion}", mesero, {"version": cuenta()["version"], **datos}, llave, espera=espera)

    for asiento in [1, 2, 3]:
        api(f"/cuentas/{origen}/items", mesero, {**platillo, "asiento": asiento}, espera=201)
    api(f"/cuentas/{origen}/rondas", mesero, {}, espera=201)
    version = cuenta()["version"]
    llave = uuid.uuid4()
    por_asiento = {"version": version, "modo": "asiento", "asiento": 2}
    primera = cambia("separa", por_asiento, llave)["id_subcuenta"]
    assert cambia("separa", por_asiento, llave)["id_subcuenta"] == primera
    assert [i["asiento"] for i in cuenta(primera)["items"]] == [2]
    item = next(i["id"] for i in cuenta()["items"] if i["asiento"] == 3)
    segunda = cambia("separa", {"modo": "platillos", "items": [item]})["id_subcuenta"]
    assert [i["id"] for i in cuenta(segunda)["items"]] == [item]

    def versiones():
        return {str(f["id"]): f["version"] for f in cuenta()["grupo"] if f["id"] != origen}

    assert len(versiones()) == 2 and cuenta()["total"] == "125.00"
    assert cuenta(primera)["mesas"] == cuenta()["mesas"]
    cambia("reune", {"versiones": {str(primera): 0, str(segunda): 0}}, espera=409)
    cambia("reune", {"versiones": versiones()})
    assert cuenta()["total"] == "375.00" and len(cuenta()["items"]) == 3
    assert cuenta(primera)["abierta"] is None and cuenta(segunda)["abierta"] is None
    nuevas = cambia("reparte", {"partes": 7})["subcuentas_creadas"]
    assert [cuenta(id_cuenta)["total"] for id_cuenta in [origen, *nuevas]] == ["53.58"] + ["53.57"] * 6

    def cobra(id_cuenta):
        ficha = cuenta(id_cuenta)
        return api(f"/cuentas/{id_cuenta}/cobro", caja, {
            "version": ficha["version"], "formas": [{"medio": "efectivo", "importe": ficha["total"]}],
        }, espera=201)

    antes = json.loads(fixture("comprueba"))["pagos"]
    pago = cobra(origen)
    assert pago["id_siguiente"] == nuevas[0]
    assert any(m["id"] == mesa and m["id_cuenta"] == nuevas[0] for m in api("/plano", caja)["mesas"])
    assert [f["cantidad"] for f in pago["faltantes"]] == ["0.600"]
    for parte in nuevas:
        assert cobra(parte)["faltantes"] == []
    assert json.loads(fixture("comprueba"))["pagos"] == antes + 7
    assert any(m["id"] == mesa and m["estado"] == "por_limpiar" for m in api("/plano", caja)["mesas"])

    api(f"/mesas/{mesa}/limpia", mesero, {})
    origen = api("/cuentas", mesero, {"id_mesa": mesa}, espera=201)["id"]
    for asiento in [1, 2]:
        api(f"/cuentas/{origen}/items", mesero, {**platillo, "asiento": asiento}, espera=201)
    api(f"/cuentas/{origen}/rondas", mesero, {}, espera=201)
    hija = cambia("separa", {"modo": "asiento", "asiento": 2})["id_subcuenta"]
    assert cobra(hija)["id_siguiente"] is None
    assert any(m["id"] == mesa and m["id_cuenta"] == origen for m in api("/plano", caja)["mesas"])
    assert [f["cantidad"] for f in cobra(origen)["faltantes"]] == ["0.200"]
    print("✓ Separar por asiento y platillo, reunir, repartir a centavos y cobrar cada parte sin duplicar consumo.")

    antes = json.loads(fixture("comprueba"))
    platos = [{**platillo, "cantidad": 1}]
    llave = uuid.uuid4()
    datos = {"items": platos, "formas": [{"medio": "efectivo", "importe": "125.00", "recibido": "200.00"}]}
    api("/mostrador", mesero, datos, espera=403)
    api("/mostrador", caja, {**datos, "formas": [{"medio": "efectivo", "importe": "1.00"}]}, espera=422)
    assert json.loads(fixture("comprueba")) == antes
    vendido = api("/mostrador", caja, datos, llave, espera=201)
    assert vendido == api("/mostrador", caja, datos, llave, espera=201)
    assert vendido["cambio"] == "75.00" and b"Mostrador" in pide(vendido["ticket"])[1]
    assert json.loads(fixture("comprueba"))["pagos"] == antes["pagos"] + 1
    preparado = next(i for i in api("/cocina", cocina)["items"] if i["tipo"] == "mostrador")
    ronda = preparado["id_ronda"]
    for accion in ["preparar", "listo", "despachar"]:
        api(f"/cocina/{ronda}/{accion}", cocina, {"area": preparado["preparacion"]})
    assert all(i["id_ronda"] != ronda for i in api("/cocina", cocina)["items"])
    cierre = api("/caja/cerrar", caja, {"id_turno": turno, "efectivo": "750.00"})
    assert cierre["diferencia"] == "0.00" and cierre["resumen"]["cobros"] == 10
    print("✓ Mostrador cobra en una operación, revierte pagos inválidos, reintenta sin duplicar y llega a cocina para despacho.")


def prueba_promociones(mesero, caja, mesa, platillo):
    fixture("promocion", DATOS["platillo"])
    turno = api("/caja/abrir", caja, {"fondo": "0.00"})["id"]
    dos = [{**platillo, "cantidad": 2}]
    cotizacion = api("/mostrador/cotiza", caja, {"items": dos})
    assert cotizacion["total"] == "125.00", cotizacion
    assert cotizacion["items"][0]["descuento"] == "125.00" and "2x1" in cotizacion["items"][0]["promocion"]
    api("/mostrador", caja, {"items": dos, "formas": [{"medio": "efectivo", "importe": "250.00"}]}, espera=422)
    vendido = api("/mostrador", caja, {"items": dos, "formas": [{"medio": "efectivo", "importe": "125.00"}]}, espera=201)
    assert b"2x1" in pide(vendido["ticket"])[1]

    cuenta = api("/cuentas", mesero, {"id_mesa": mesa}, espera=201)["id"]
    for _ in range(3):
        api(f"/cuentas/{cuenta}/items", mesero, platillo, espera=201)
    ficha = api(f"/cuentas/{cuenta}", caja)
    assert ficha["total"] == "250.00" and sum(i["descuento"] == "125.00" for i in ficha["items"]) == 1, ficha["items"]
    api(f"/cuentas/{cuenta}/rondas", mesero, {}, espera=201)
    ficha = api(f"/cuentas/{cuenta}", caja)
    pago = api(f"/cuentas/{cuenta}/cobro", caja, {"version": ficha["version"],
        "formas": [{"medio": "efectivo", "importe": "250.00"}]}, espera=201)
    assert pago["pagado"] == "250.00" and b"2x1" in pide(pago["ticket"])[1]
    cierre = api("/caja/cerrar", caja, {"id_turno": turno, "efectivo": "375.00"})
    assert cierre["diferencia"] == "0.00" and cierre["resumen"]["promociones"] == "250.00", cierre["resumen"]
    print("✓ Un 2x1 se cotiza y cobra en mostrador y en mesa con el total exacto; ticket y corte lo muestran.")


with socket.socket() as s:
    s.bind(("127.0.0.1", 0))
    puerto = s.getsockname()[1]
BASE = f"http://127.0.0.1:{puerto}"
with tempfile.TemporaryFile() as registros:
    servidor = subprocess.Popen([PHP, "-S", f"127.0.0.1:{puerto}", "-t", str(RAIZ / "publico"),
                                 str(RAIZ / "pruebas/servidor-local.php")],
                                cwd=RAIZ, env=ENV, stderr=registros, stdout=registros, start_new_session=True)
    try:
        for _ in range(40):
            try:
                api("/salud")
                break
            except urllib.error.URLError:
                time.sleep(.1)
        else:
            raise RuntimeError("No inició el servidor concurrente.")
        DATOS = json.loads(fixture("prepara"))
        prueba()
    except Exception:
        registros.seek(0)
        mensajes = registros.read().decode(errors="replace")
        print("\n".join(mensajes.splitlines()[-18:]))
        raise
    finally:
        if servidor.poll() is None:
            os.killpg(servidor.pid, signal.SIGTERM)
        servidor.wait(timeout=5)
        fixture("limpia")
