<?php
declare(strict_types=1);

use Pruebas\Afirma;

/**
 * El candado de los textos (bitácora 115): lo que se recortó no vuelve a crecer.
 *
 * Lee el mapa que saca `pruebas/mapa-textos.php`, el mismo de la revisión, y hace
 * cumplir `docs/textos/guia-de-textos.md`. No alcanza con revisar una vez:
 * cada pantalla nueva agrega textos.
 *
 * Fuera del candado: el aviso de privacidad, que espera revisión legal; la landing
 * en los topes, porque es venta y no operación; y los catálogos en los topes, porque
 * son opciones sembradas, no redacción de pantalla.
 */

$raiz = dirname(__DIR__);

$filas = (static function () use ($raiz): array {
    $csv = tempnam(sys_get_temp_dir(), 'mapa-textos-');
    // La batería puede correr con otro PATH; el proyecto usa node@24.
    $ruta = '/opt/homebrew/opt/node@24/bin:' . (string) getenv('PATH');
    $orden = 'PATH=' . escapeshellarg($ruta) . ' ' . escapeshellarg(PHP_BINARY) . ' '
        . escapeshellarg($raiz . '/pruebas/mapa-textos.php') . ' ' . escapeshellarg((string) $csv) . ' 2>&1';
    exec($orden, $salida, $codigo);
    if ($codigo !== 0) {
        unlink((string) $csv);
        throw new RuntimeException('El mapa de textos no se generó: ' . implode(' ', $salida));
    }
    $hay = [];
    $h = fopen((string) $csv, 'r');
    fgetcsv($h, 0, ',', '"', '');
    while (($f = fgetcsv($h, 0, ',', '"', '')) !== false) {
        if (count($f) >= 6) {
            $hay[] = ['superficie' => $f[0], 'archivo' => $f[1], 'linea' => $f[2], 'tipo' => $f[3], 'texto' => $f[5]];
        }
    }
    fclose($h);
    unlink((string) $csv);
    return $hay;
})();

$legal = ['vistas/privacidad/aviso.php', 'landing/aviso-privacidad.html'];

/** Lo que nunca lee la gente de la operación: consola, tareas y formatos internos. */
$interno = ['nucleo/MigracionesEsquema', 'controladores/Sistema/', 'nucleo/TareaProgramada', 'nucleo/Exporta/Pdf',
    'nucleo/Seguridad/Totp', 'nucleo/Middleware/ExigePermiso', 'guiones/'];

$visibles = array_values(array_filter($filas, static function (array $f) use ($legal, $interno): bool {
    if (in_array($f['archivo'], $legal, true)) return false;
    foreach ($interno as $i) {
        if (str_starts_with($f['archivo'], $i)) return false;
    }
    return true;
}));

$operacion = array_values(array_filter($visibles, static fn (array $f): bool => !in_array($f['superficie'], ['landing', 'catalogos'], true)));

$cita = static fn (array $f): string => $f['archivo'] . ':' . $f['linea'] . ' «' . $f['texto'] . '»';

/** Sin los huecos de datos, que no se leen como palabras. */
$palabras = static function (string $t): int {
    $limpio = trim((string) preg_replace('/\{…\}/u', ' ', $t));
    return $limpio === '' ? 0 : count(preg_split('/\s+/u', $limpio) ?: []);
};

return [
    'el mapa alcanza a todas las superficies' => function () use ($filas): void {
        $hay = array_count_values(array_column($filas, 'superficie'));
        // La app (fase 5) y la landing (fase 11) entran al candado cuando existen.
        $raiz = dirname(__DIR__);
        $superficies = ['web', 'servidor', 'catalogos'];
        if (is_dir($raiz . '/app/src')) $superficies[] = 'app';
        if (is_dir($raiz . '/landing')) $superficies[] = 'landing';
        foreach ($superficies as $s) {
            $minimo = match ($s) {
                'catalogos' => 15,
                'landing' => 30,
                default => 50,
            };
            Afirma::cierto(($hay[$s] ?? 0) > $minimo, 'el mapa lee ' . $s);
        }
    },

    'en pantalla no hay jerga técnica' => function () use ($operacion, $cita): void {
        $jerga = '/\b(servidor|traza|geocerca|push|consola|token|sincroniz\w*|backend|payload|login|timeout|excepci[oó]n|json|sql)\b/iu';
        $hay = array_map($cita, array_filter($operacion, static fn (array $f): bool => $f['tipo'] !== 'lector' && preg_match($jerga, $f['texto']) === 1));
        Afirma::igual([], array_values($hay), 'jerga en lo visible');
    },

    'se trata de usted en todo lo visible' => function () use ($visibles, $cita): void {
        $tu = '/(?<![\p{L}])(tienes|puedes|debes|quieres|necesitas|tu|tus|ten|haz|pídelo|pídela|elige|escribe|pulsa|avisa|revisa|inténtalo|vuélvelo|configura|selecciona|toca|ingresa|espérate)(?![\p{L}])/iu';
        $hay = array_map($cita, array_filter($visibles, static fn (array $f): bool => preg_match($tu, $f['texto']) === 1));
        Afirma::igual([], array_values($hay), 'textos en «tú»');
    },

    'una palabra por concepto y «solo» sin tilde' => function () use ($visibles, $cita): void {
        // «Seleccione» y «Capture» desde la homologación (T7, 2026-11-05). La app
        // queda fuera de esa regla hasta su próximo APK: el plan no la toca.
        $hay = array_map($cita, array_filter($visibles, static fn (array $f): bool => preg_match('/(?<![\p{L}])sólo(?![\p{L}])/iu', $f['texto']) === 1
            || ($f['superficie'] !== 'app' && preg_match('/(?<![\p{L}])(elija|escriba)(?![\p{L}])/iu', $f['texto']) === 1)));
        Afirma::igual([], array_values($hay), 'variantes retiradas del glosario');
    },

    'cada tipo de texto respeta su tope' => function () use ($operacion, $cita, $palabras): void {
        $topes = ['boton' => 3, 'titulo' => 4, 'error' => 10, 'pista' => 8, 'ayuda' => 8, 'confirmacion' => 12, 'aviso' => 12, 'vacio' => 6, 'subtitulo' => 16];
        // Se dejaron largos a propósito, y cada uno debe poder defenderse.
        $excepciones = [
            'Rutas y días de visita',
            'Oferta y precios por oficina',
            'Sin clientes en esta vista',
            'Sin hoja en el teléfono',
            // Irreversible: dice qué se pierde.
            'Se borran los datos del día de este teléfono.',
        ];
        $hay = array_map($cita, array_filter($operacion, static function (array $f) use ($topes, $excepciones, $palabras): bool {
            $tope = $topes[$f['tipo']] ?? null;
            return $tope !== null && $palabras($f['texto']) > $tope && !in_array($f['texto'], $excepciones, true);
        }));
        Afirma::igual([], array_values($hay), 'textos sobre su tope');
    },

    'ningún texto de operación pasa de 11 palabras' => function () use ($operacion, $cita, $palabras): void {
        $hay = array_map($cita, array_filter($operacion, static function (array $f) use ($palabras): bool {
            // El subtítulo de pantalla tiene su propio tope (R14): es el texto aprobado de la ficha.
            if (in_array($f['tipo'], ['lector', 'subtitulo'], true) || $palabras($f['texto']) < 12) return false;
            // Subtítulo de su ficha que se elige por tipo de reporte: el mapa no lo ve como subtítulo.
            if ($f['archivo'] === 'vistas/reportes/operativos.php' && $f['texto'] === 'Diferencias entre el sistema y el conteo físico por producto en un periodo.') return false;
            // El aviso previo a la selfie y la ubicación debe decir para qué se usan.
            return !($f['archivo'] === 'movil/src/app/checada.tsx' && str_starts_with($f['texto'], 'Su selfie y su ubicación'));
        }));
        Afirma::igual([], array_values($hay), 'textos largos');
    },

    'el subtítulo de pantalla es una línea que termina en punto' => function () use ($operacion, $cita, $palabras): void {
        // Solo las frases completas: las fichas de detalle arman el suyo por partes
        // («Folio {…} · versión {…}»), y el mapa ve cada parte por separado.
        $hay = array_map($cita, array_filter($operacion, static fn (array $f): bool => $f['tipo'] === 'subtitulo'
            && $palabras($f['texto']) >= 4 && !str_starts_with($f['texto'], '·') && !str_contains($f['texto'], '{…}') && !str_ends_with($f['texto'], '.')));
        Afirma::igual([], array_values($hay), 'subtítulos sin punto final');
    },

    'la guía sigue diciendo lo que el candado exige' => function () use ($raiz): void {
        $guia = (string) file_get_contents($raiz . '/docs/textos/guia-de-textos.md');
        Afirma::contiene('ISO 24495-1', $guia, 'la norma de base');
        Afirma::contiene('Glosario', $guia, 'una palabra por concepto');
    },
];
