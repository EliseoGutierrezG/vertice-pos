<?php
declare(strict_types=1);

use Nucleo\BaseDatos;
use Nucleo\MigracionesEsquema;
use Pruebas\Afirma;

/**
 * Reglas que no son de una clase, sino del proyecto entero.
 *
 * Una regla que sólo vive en un comentario dura hasta que alguien con prisa no
 * lee el comentario. Éstas se comprueban.
 */

$raiz = dirname(__DIR__);

/** Todos los .php del proyecto, menos los de fuera y los de las pruebas. */
$archivos = static function (string $raiz): array {
    $fuera = ['/vendor/', '/node_modules/', '/pruebas/', '/docs/', '/almacenamiento/', '/entregables/'];
    $todos = [];

    $origen = new RecursiveDirectoryIterator($raiz, FilesystemIterator::SKIP_DOTS);
    $filtrado = new RecursiveCallbackFilterIterator(
        $origen,
        static function (SplFileInfo $archivo): bool {
            if (!$archivo->isDir()) return true;
            return !in_array($archivo->getFilename(), ['vendor', 'node_modules', 'pruebas', 'docs', 'almacenamiento', 'entregables', '.git'], true);
        }
    );
    $iterador = new RecursiveIteratorIterator($filtrado);

    foreach ($iterador as $archivo) {
        $ruta = $archivo->getPathname();

        if (!str_ends_with($ruta, '.php')) {
            continue;
        }

        foreach ($fuera as $carpeta) {
            if (str_contains($ruta, $carpeta)) {
                continue 2;
            }
        }

        $todos[] = $ruta;
    }

    sort($todos);

    return $todos;
};

return [
    'sólo el servicio de lotes escribe en los lotes y su libro' => function () use ($raiz, $archivos): void {
        // La regla de la v2 (D2). El lote es el inventario: su `extraido` dice
        // cuánto queda, y `movimiento_lote` es el libro del que sale el kardex.
        // Si dos lugares pudieran restarle a un lote, un día uno lo haría sin
        // asentarlo en el libro y el kardex dejaría de cuadrar sin que nadie
        // supiera desde cuándo. Leer, sí puede cualquiera: el inventario, el
        // kardex y los reportes leen.
        //
        // `servicios/Lotes.php` llega en la fase 6 (armado) y la 7 (entradas).
        // Hasta entonces nadie escribe, y eso también se comprueba.
        // La carga demo reconstruye una historia cerrada desde cero; no es una
        // ruta de aplicación y sólo existe en estos dos archivos nombrados.
        $permitidos = [
            $raiz . '/servicios/Lotes.php',
            $raiz . '/guiones/demo/catalogo.php',
            $raiz . '/guiones/demo/opera.php',
        ];
        $culpables  = [];

        foreach ($archivos($raiz) as $archivo) {
            if (in_array($archivo, $permitidos, true)) {
                continue;
            }

            $fuente = preg_replace('#//[^\n]*|/\*.*?\*/#s', '', file_get_contents($archivo) ?: '') ?? '';

            // La tabla, no la palabra: «lote» en un mensaje no cuenta.
            if (preg_match('/\b(INSERT\s+(IGNORE\s+)?INTO|UPDATE|DELETE\s+FROM)\s+(lote|movimiento_lote|lote_componente)\b/i', $fuente)) {
                $culpables[] = str_replace($raiz . '/', '', $archivo);
            }
        }

        Afirma::igual([], $culpables, 'archivos que escriben lotes por su cuenta');
    },

    'nadie toca el saldo de envases por su cuenta' => function () use ($raiz, $archivos): void {
        // El envase es el segundo flujo de inventario y se mueve al revés (D3).
        // Que lo escriba cualquiera es la manera de acabar con un saldo que no
        // se parece a lo que hay en la sucursal del cliente. El servicio que lo
        // mueva —con la entrega y la devolución, fases 11 y 15— se nombra aquí
        // cuando llegue, y ninguno más.
        $permitidos = [
            $raiz . '/servicios/Sincronizacion.php',
            $raiz . '/guiones/demo/opera.php',
        ];
        $culpables  = [];

        foreach ($archivos($raiz) as $archivo) {
            if (in_array($archivo, $permitidos, true)) {
                continue;
            }

            $fuente = preg_replace('#//[^\n]*|/\*.*?\*/#s', '', file_get_contents($archivo) ?: '') ?? '';

            if (preg_match('/\b(INSERT\s+(IGNORE\s+)?INTO|UPDATE|DELETE\s+FROM)\s+(cliente_envase|entrega_envase)\b/i', $fuente)) {
                $culpables[] = str_replace($raiz . '/', '', $archivo);
            }
        }

        Afirma::igual([], $culpables, 'archivos que mueven envases por su cuenta');
    },

    'el cálculo fiscal es el único que calcula impuestos' => function () use ($raiz, $archivos): void {
        // La fórmula fiscal existe UNA vez. Dos copias divergen, y divergen
        // callado: es exactamente lo que le pasó a la referencia.
        $permitidos = [$raiz . '/dominio/CalculoFiscal.php'];
        $culpables  = [];

        foreach ($archivos($raiz) as $archivo) {
            if (in_array($archivo, $permitidos, true)) {
                continue;
            }

            // Los comentarios se quitan primero: explicar que el neto se divide
            // entre 1.16 no es calcular un IVA a mano.
            $fuente = preg_replace('#//[^\n]*|/\*.*?\*/#s', '', file_get_contents($archivo) ?: '') ?? '';

            // Un 1.16 incrustado en el código es la señal clásica del IVA a mano.
            if (preg_match('/[^\d.]1\.16\b/', $fuente)) {
                $culpables[] = str_replace($raiz . '/', '', $archivo);
            }
        }

        Afirma::igual([], $culpables, 'archivos con el IVA incrustado');
    },

    'ninguna función flecha usa compact()' => function () use ($raiz, $archivos): void {
        // Una función flecha solo captura las variables que nombra. compact()
        // las nombra en texto, así que adentro no ve ninguna y la ficha truena
        // con «variable no definida» (le pasó a Ver platillo y a Recibir compra).
        $culpables = [];
        foreach ($archivos($raiz) as $archivo) {
            $piezas = token_get_all(file_get_contents($archivo) ?: '');
            foreach ($piezas as $i => $pieza) {
                if (!is_array($pieza) || $pieza[0] !== T_FN) continue;
                // Se salta la firma hasta la flecha y se recorre el cuerpo hasta
                // la coma, el punto y coma o el cierre que lo terminan.
                $j = $i + 1;
                while (isset($piezas[$j]) && !(is_array($piezas[$j]) && $piezas[$j][0] === T_DOUBLE_ARROW)) $j++;
                $hondura = 0;
                for ($j++; isset($piezas[$j]); $j++) {
                    $p = $piezas[$j];
                    $texto = is_array($p) ? $p[1] : $p;
                    if (in_array($texto, ['(', '[', '{'], true) || (is_array($p) && in_array($p[0], [T_CURLY_OPEN, T_DOLLAR_OPEN_CURLY_BRACES], true))) {
                        $hondura++;
                    } elseif (in_array($texto, [')', ']', '}'], true)) {
                        if ($hondura-- === 0) break;
                    } elseif ($hondura === 0 && in_array($texto, [',', ';'], true)) {
                        break;
                    } elseif (is_array($p) && $p[0] === T_STRING && strtolower($p[1]) === 'compact') {
                        $culpables[] = str_replace($raiz . '/', '', $archivo) . ':' . $p[2];
                    }
                }
            }
        }

        Afirma::igual([], $culpables, 'compact() dentro de una función flecha');
    },

    'el esquema no guarda dinero ni cantidades en coma flotante' => function () use ($raiz): void {
        // Un FLOAT guarda 0.1 como 0.100000001490116, y la suma de mil
        // renglones deja de dar lo que dice el ticket. El dinero va en
        // DECIMAL(12,4) por unidad y (14,2) por total, las cantidades en
        // DECIMAL(14,3), las coordenadas en DECIMAL(10,7): ninguna columna
        // tiene razón para ser aproximada.
        $guiones = glob($raiz . '/esquema/*.sql') ?: [];
        Afirma::cierto(count($guiones) >= 6, 'se leyeron ' . count($guiones) . ' guiones del esquema');

        $culpables = [];

        foreach ($guiones as $guion) {
            $fuente = preg_replace('/--[^\n]*|COMMENT\s*=?\s*\'(?:[^\'\\\\]|\\\\.)*\'/i', '', file_get_contents($guion) ?: '') ?? '';

            if (preg_match_all('/^\s*`?([a-z_0-9]+)`?\s+(FLOAT|DOUBLE|REAL)\b/mi', $fuente, $columnas) > 0) {
                foreach ($columnas[1] as $columna) {
                    $culpables[] = basename($guion) . ': ' . $columna;
                }
            }
        }

        Afirma::igual([], $culpables, 'columnas en coma flotante');
    },

    'la app nunca manda importes' => function () use ($raiz, $archivos): void {
        // La regla del paso 12.8 del prototipo, que la v2 conserva (fase 15):
        // el teléfono manda
        // presentación y cantidad, y el servidor contesta cuánto es. Si la API
        // aceptara un precio, el día que cambie una tasa habría 200 teléfonos
        // cobrando la anterior y nadie lo notaría hasta la declaración.
        $prohibidos = 'precio[a-z_]*|importe|subtotal|total|iva|ieps|descuento';
        $culpables  = [];

        foreach ($archivos($raiz) as $archivo) {
            if (!str_contains($archivo, '/controladores/Api/')) {
                continue;
            }

            $fuente = preg_replace('#//[^\n]*|/\*.*?\*/#s', '', file_get_contents($archivo) ?: '') ?? '';

            // Lo que se persigue es LEER un importe de lo que llegó: de los
            // datos de la petición, de un renglón suyo o de la cadena de
            // consulta. Devolver un total calculado aquí no es lo mismo.
            if (preg_match('/\$(datos|renglon|crudos|punto)\s*\[\s*.(' . $prohibidos . ').\s*\]/i', $fuente)
                || preg_match('/->consulta\(\s*.(' . $prohibidos . ')./i', $fuente)) {
                $culpables[] = str_replace($raiz . '/', '', $archivo);
            }
        }

        Afirma::igual([], $culpables, 'controladores de la API que aceptan un importe del teléfono');
    },

    'un reporte no escribe' => function () use ($raiz, $archivos): void {
        // La regla de la fase 16 del prototipo. Un reporte junta lo que ya pasó; el día que
        // uno escriba —"de paso marco esto como revisado"— dejará de poder
        // recargarse sin consecuencias, y nadie se enterará hasta que alguien
        // le dé a actualizar dos veces.
        $culpables = [];

        foreach ($archivos($raiz) as $archivo) {
            $corto = str_replace($raiz . '/', '', $archivo);

            // Los reportes de la v2 llegan en la fase 13 y se agregan aquí.
            $soloLectura = [
                // La bitácora se lee desde aquí y se escribe **sólo** desde
                // `Nucleo\Bitacora`, dentro de la transacción del cambio. Una
                // bitácora que la pantalla puede corregir no contesta nada.
                'modelos/Bitacora.php',
                'controladores/Web/BitacoraWeb.php',
            ];

            if (!in_array($corto, $soloLectura, true) && !str_contains($corto, 'nucleo/Exporta/')) {
                continue;
            }

            $fuente = preg_replace('#//[^\n]*|/\*.*?\*/#s', '', file_get_contents($archivo) ?: '') ?? '';

            if (preg_match('/\b(INSERT\s+INTO|UPDATE\s+\w|DELETE\s+FROM)\b/i', $fuente)
                || preg_match('/->(inserta|ejecuta|transaccion)\s*\(/', $fuente)) {
                $culpables[] = $corto;
            }
        }

        Afirma::igual([], $culpables, 'archivos de reporte que escriben en la base');
    },

    'sólo el núcleo escribe en la bitácora' => function () use ($raiz, $archivos): void {
        // La bitácora es la respuesta a «¿quién movió esto?». Si un módulo
        // pudiera escribirla —o peor, corregirla— por su cuenta, la respuesta
        // valdría lo que valga la buena fe de ese módulo.
        $permitidos = [$raiz . '/nucleo/Bitacora.php'];
        $culpables  = [];

        foreach ($archivos($raiz) as $archivo) {
            if (in_array($archivo, $permitidos, true)) {
                continue;
            }

            $fuente = preg_replace('#//[^\n]*|/\*.*?\*/#s', '', file_get_contents($archivo) ?: '') ?? '';

            if (preg_match('/\b(INSERT\s+INTO|UPDATE|DELETE\s+FROM)\s+bitacora\b/i', $fuente)) {
                $culpables[] = str_replace($raiz . '/', '', $archivo);
            }
        }

        Afirma::igual([], $culpables, 'archivos que escriben en la bitácora por su cuenta');
    },

    'los registros inmutables sólo se insertan' => function () use ($raiz, $archivos): void {
        // Fases 35 a 37: un corte de caja, una autorización, un cobro, un
        // reembolso o una versión del documento de transferencia valen porque
        // no cambian después. Si algo se corrige, se agrega otro registro (una
        // revisión del corte, una resolución, una versión nueva). Un UPDATE o
        // un DELETE sobre estas tablas en el código de la aplicación es,
        // siempre, alguien reescribiendo lo que ya se firmó.
        //
        // Las pruebas y sus limpiezas sí borran: no están en `$archivos`.
        $tablas = 'transferencia_documento|transferencia_documento_renglon|transferencia_resolucion|corte_caja'
            . '|corte_caja_revision|autorizacion_caja|pago_venta|movimiento_caja|reembolso|liquidacion_ajuste'
            . '|cambio_fisico_resultado|cambio_fisico_recepcion';
        $culpables = [];

        foreach ($archivos($raiz) as $archivo) {
            $fuente = preg_replace('#//[^\n]*|/\*.*?\*/#s', '', file_get_contents($archivo) ?: '') ?? '';

            if (preg_match('/\b(?:UPDATE|DELETE\s+FROM)\s+(?:' . $tablas . ')\b/i', $fuente, $hallado)) {
                $culpables[] = str_replace($raiz . '/', '', $archivo) . ': ' . $hallado[0];
            }
        }

        Afirma::igual([], $culpables, 'archivos que editan o borran un registro inmutable');
    },

    'toda ruta que escribe deja rastro en la bitácora' => function () use ($raiz, $archivos): void {
        // Fase 33. Cada POST, PUT, PATCH o DELETE debe llegar, por alguna de
        // sus llamadas, a `bitacora->registra`. Se recorre el método del
        // controlador, sus métodos propios y los de los servicios que recibe
        // por constructor (hasta seis saltos). Una llamada con nombre
        // dinámico (`$this->x->{$metodo}()`) no se puede seguir: escríbala
        // explícita. Las excepciones dicen por qué no escriben rastro.
        $excepciones = [
            'POST /api/v1/equipo/actividad' => 'sólo actualiza la ventana de inactividad de la sesión',
            'POST /clientes/geocodifica' => 'consulta un servicio de mapas; no escribe nada',
            'POST /api/v1/mostrador/cotiza' => 'solo calcula el total con las promociones vigentes; no escribe nada',
            'POST /api/v1/ubicaciones'   => 'telemetría GPS idempotente: ubicacion_usuario ya es el registro y duplicarlo en la bitácora la doblaría',
        ];

        $clases = [];
        foreach ($archivos($raiz) as $archivo) {
            if (!preg_match('#/(controladores|servicios|modelos|nucleo)/#', $archivo)) continue;
            $codigo = file_get_contents($archivo) ?: '';
            $espacio = preg_match('/^namespace\s+([\w\\\\]+);/m', $codigo, $ns) === 1 ? $ns[1] : '';
            $usos = [];
            preg_match_all('/^use\s+([\w\\\\]+)(?:\s+as\s+(\w+))?;/m', $codigo, $us, PREG_SET_ORDER);
            foreach ($us as $u) { $partes = explode('\\', $u[1]); $usos[$u[2] ?? end($partes)] = $u[1]; }
            $t = token_get_all($codigo);
            $n = count($t);
            $clase = null;
            $metodos = [];
            for ($i = 0; $i < $n; $i++) {
                if (!is_array($t[$i])) continue;
                if ($t[$i][0] === T_CLASS && $clase === null) {
                    for ($j = $i + 1; $j < $n; $j++) if (is_array($t[$j]) && $t[$j][0] === T_STRING) { $clase = $t[$j][1]; break; }
                    continue;
                }
                if ($t[$i][0] !== T_FUNCTION) continue;
                $nombre = null;
                for ($j = $i + 1; $j < $n && $t[$j] !== '('; $j++) {
                    if (is_array($t[$j]) && $t[$j][0] === T_STRING) { $nombre = $t[$j][1]; break; }
                }
                if ($nombre === null) continue;
                $firma = $cuerpo = '';
                $nivel = 0;
                for ($k = $j; $k < $n; $k++) {
                    $texto = is_array($t[$k]) ? $t[$k][1] : $t[$k];
                    $abre = $texto === '{' || (is_array($t[$k]) && in_array($t[$k][0], [T_CURLY_OPEN, T_DOLLAR_OPEN_CURLY_BRACES], true));
                    if ($nivel === 0) {
                        if ($texto === ';') break;
                        if ($abre) { $nivel = 1; continue; }
                        $firma .= $texto;
                        continue;
                    }
                    if ($abre) $nivel++;
                    if ($texto === '}' && --$nivel === 0) break;
                    $cuerpo .= $texto;
                }
                $metodos[$nombre] = ['firma' => $firma, 'cuerpo' => $cuerpo];
                $i = $k;
            }
            if ($clase === null) continue;
            $tipos = [];
            preg_match_all('/(?:private|protected|public)\s+(?:readonly\s+)?\??\\\\?([\w\\\\]+)\s+\$(\w+)/', $metodos['__construct']['firma'] ?? '', $m, PREG_SET_ORDER);
            foreach ($m as $x) {
                $tipos[$x[2]] = str_contains($x[1], '\\') ? $x[1] : ($usos[$x[1]] ?? $espacio . '\\' . $x[1]);
            }
            $clases[$espacio . '\\' . $clase] = ['metodos' => $metodos, 'tipos' => $tipos];
        }

        $visto = [];
        $audita = static function (string $clase, string $metodo, int $saltos) use (&$audita, &$clases, &$visto): bool {
            $llave = $clase . '::' . $metodo;
            if (isset($visto[$llave])) return $visto[$llave];
            $visto[$llave] = false;
            $cuerpo = $clases[$clase]['metodos'][$metodo]['cuerpo'] ?? null;
            if ($cuerpo === null || $saltos > 6) return false;
            if (preg_match('/bitacora\??->registra\(/', $cuerpo) === 1) return $visto[$llave] = true;
            preg_match_all('/\$this->(\w+)\(/', $cuerpo, $propios);
            foreach (array_unique($propios[1]) as $propio) {
                if ($audita($clase, $propio, $saltos + 1)) return $visto[$llave] = true;
            }
            preg_match_all('/\$this->(\w+)\??->(\w+)\(/', $cuerpo, $ajenos, PREG_SET_ORDER);
            foreach ($ajenos as $x) {
                $tipo = $clases[$clase]['tipos'][$x[1]] ?? null;
                if ($tipo !== null && $audita($tipo, $x[2], $saltos + 1)) return $visto[$llave] = true;
            }
            return false;
        };

        $sinRastro = [];
        $revisadas = 0;
        foreach (['web' => '', 'api' => '/api/v1'] as $archivo => $prefijo) {
            $texto = file_get_contents($raiz . '/rutas/' . $archivo . '.php') ?: '';
            $usos = [];
            preg_match_all('/^use\s+([\w\\\\]+)(?:\s+as\s+(\w+))?;/m', $texto, $us, PREG_SET_ORDER);
            foreach ($us as $u) { $partes = explode('\\', $u[1]); $usos[$u[2] ?? end($partes)] = $u[1]; }
            preg_match_all("/->(post|put|patch|delete)\(\s*'([^']+)',\s*\[(\w+)::class,\s*'(\w+)'\]/", $texto, $rutas, PREG_SET_ORDER);
            foreach ($rutas as $r) {
                $revisadas++;
                $nombre = strtoupper($r[1]) . ' ' . $prefijo . $r[2];
                if (isset($excepciones[$nombre])) continue;
                $clase = $usos[$r[3]] ?? $r[3];
                if (!isset($clases[$clase]['metodos'][$r[4]])) {
                    $sinRastro[] = $nombre . ' → ' . $clase . '::' . $r[4] . ' (no se encontró)';
                } elseif (!$audita($clase, $r[4], 0)) {
                    $sinRastro[] = $nombre . ' → ' . $clase . '::' . $r[4];
                }
            }
        }

        Afirma::cierto($revisadas > 25, 'el lector de rutas encontró las rutas que escriben');
        Afirma::igual([], $sinRastro, 'rutas que escriben sin llegar a la bitácora');
    },

    'ninguna consulta arma SQL pegando variables' => function () use ($raiz, $archivos): void {
        // Se buscan las dos formas de meter una variable dentro de la cadena:
        // la interpolación y el punto. Los parámetros van por bind, siempre.
        //
        // La única excepción es el guion de respaldo, cuyo trabajo **es**
        // producir texto SQL: ahí no hay consulta que preparar, porque lo que se
        // genera no se ejecuta, se escribe en un archivo. Va nombrado uno por
        // uno, y los valores pasan por `BaseDatos::escapa()`, que existe sólo
        // para eso y tiene su propia regla más abajo.
        $permitidos = [
            $raiz . '/guiones/respaldo.php',
            // Semillas privilegiadas y cerradas: todos sus valores siguen
            // viajando por los parámetros de BaseDatos; esta excepción evita
            // falsos positivos por literales SQL con comillas dobles.
            $raiz . '/guiones/demo/catalogo.php',
            $raiz . '/guiones/demo/opera.php',
        ];

        $culpables = [];

        foreach ($archivos($raiz) as $archivo) {
            if (in_array($archivo, $permitidos, true)) {
                continue;
            }
            $fuente = file_get_contents($archivo) ?: '';

            foreach (explode("\n", $fuente) as $numero => $linea) {
                // La etiqueta `<select>`, su clase `form-select` y el tipo de campo `'select'` de las
                // vistas no son SQL: contarlos señalaba formularios sanos.
                $sinHtml = (string) preg_replace('#</?select\b|form-select\b|[\x27"]select[\x27"]#i', '', $linea);
                if (!preg_match('/\b(SELECT|INSERT|UPDATE|DELETE)\b/i', $sinHtml)) {
                    continue;
                }

                if (preg_match('/"[^"]*\$[a-zA-Z_]/', $linea)) {
                    $culpables[] = str_replace($raiz . '/', '', $archivo) . ':' . ($numero + 1);
                }
            }
        }

        Afirma::igual([], $culpables, 'líneas de SQL con una variable dentro de la cadena');
    },

    'ningún nombre de variable se come el carácter que lo sigue' => function () use ($raiz): void {
        // Medido: `"el valor real de «$llave»"` no dice «clave», dice «». PHP 8
        // acepta los bytes de arriba de 127 dentro de un nombre de variable, así
        // que el `»` de cerrar se pega al nombre y la variable que se interpola
        // es `$llave»`, que no existe: sale un aviso y el mensaje se queda sin
        // el dato. Duele justo cuando la prueba falla, que es cuando hace falta.
        // Se escribe `{$llave}`.
        //
        // Esta regla mira también las pruebas —ahí estaban las dos— así que
        // recorre los archivos por su cuenta y no usa la lista de arriba.
        $fuera     = ['/vendor/', '/node_modules/', '/docs/', '/almacenamiento/', '/entregables/'];
        $culpables = [];

        $origen = new RecursiveDirectoryIterator($raiz, FilesystemIterator::SKIP_DOTS);
        $filtrado = new RecursiveCallbackFilterIterator(
            $origen,
            static function (SplFileInfo $archivo) use ($raiz): bool {
                if (!$archivo->isDir()) return true;
                $ruta = $archivo->getPathname() . '/';
                if (in_array($archivo->getFilename(), ['node_modules', '.git', '.expo', 'entregables'], true)) return false;
                if ($ruta === $raiz . '/almacenamiento/') return false;
                return $ruta !== $raiz . '/movil/android/' && $ruta !== $raiz . '/movil/ios/';
            }
        );
        $iterador = new RecursiveIteratorIterator($filtrado);

        foreach ($iterador as $archivo) {
            $ruta = $archivo->getPathname();

            if (!str_ends_with($ruta, '.php')) {
                continue;
            }

            foreach ($fuera as $carpeta) {
                if (str_contains($ruta, $carpeta)) {
                    continue 2;
                }
            }

            $fuente = file_get_contents($ruta) ?: '';

            foreach (explode("\n", $fuente) as $numero => $linea) {
                // Los comentarios se saltan: ahí no se interpola nada, y esta
                // misma regla lleva el ejemplo escrito en el suyo.
                $limpia = ltrim($linea);

                if (str_starts_with($limpia, '//') || str_starts_with($limpia, '*') || str_starts_with($limpia, '#')) {
                    continue;
                }

                if (preg_match('/\$[a-zA-Z_][a-zA-Z0-9_]*[^\x00-\x7F]/', $linea) === 1) {
                    $culpables[] = str_replace($raiz . '/', '', $ruta) . ':' . ($numero + 1);
                }
            }
        }

        Afirma::igual([], $culpables, 'variables pegadas a un carácter de más de un byte');
    },

    'ninguna consulta envuelve una columna de fecha en una función' => function () use ($raiz, $archivos): void {
        // ⚠️ Medido: las tres consultas del rastro de GPS pedían el día con
        // `DATE(momento) = ?`. Envolver la columna la saca del índice, y el
        // motor deja de poder acotar por fecha: con un año de jornadas de un
        // solo vendedor —162,000 puntos— contestaba `key=NULL`, leía los
        // 162,000 renglones y los ordenaba en disco para devolver 540. 33.9 ms
        // contra 0.9 por rango, y **el costo del día que se ve creciendo con
        // todo lo grabado desde que el sistema existe**. El panel en vivo, que
        // corre dos subconsultas correlacionadas por usuario activo, 59 contra
        // 14.
        //
        // Se escribe `momento >= ? AND momento < ? + INTERVAL 1 DAY`, que además
        // toma el día completo hasta su último segundo.
        //
        // Sólo se mira la columna dentro de la función, no la función: `DATE()`
        // sobre `NOW()` o sobre un parámetro no le quita el índice a nadie.
        $culpables = [];

        foreach ($archivos($raiz) as $archivo) {
            $fuente = file_get_contents($archivo) ?: '';

            foreach (explode("\n", $fuente) as $numero => $linea) {
                $limpia = ltrim($linea);

                if (str_starts_with($limpia, '//') || str_starts_with($limpia, '*')) {
                    continue;
                }

                // DATE(algo) o DATE(x.algo), donde «algo» no es NOW ni CURDATE
                // ni un parámetro. Las columnas del proyecto van en minúsculas.
                if (preg_match('/\bDATE\(\s*(?:[a-z_][a-z0-9_]*\.)?[a-z_][a-z0-9_]*\s*\)/', $limpia, $hallado)) {
                    $culpables[] = str_replace($raiz . '/', '', $archivo) . ':' . ($numero + 1) . ' → ' . $hallado[0];
                }
            }
        }

        Afirma::igual([], $culpables, 'columnas de fecha envueltas en una función');
    },

    'ninguna prueba manda un cuerpo JSON dentro de un argumento entrecomillado' => function () use ($raiz): void {
        // ⚠️ Medido, y es la trampa más fea de esta tanda: en bash,
        //
        //     juzga "..." "$(curl ... -d "{\"a\":1}" "$URL")" 422
        //
        // **no manda ese JSON**. Las comillas escapadas de dentro se las come el
        // entrecomillado de fuera, curl recibe pedazos como argumentos aparte,
        // **pide la URL cuatro veces**, y el servidor contesta «El cuerpo no es
        // JSON válido» —que también es 422—. La comprobación se pone verde sin
        // haber probado nada. Doce comprobaciones de `humo-api.sh` estaban así:
        // una de ellas decía comprobar que un producto que no es casco se
        // rechaza como envase, y lo que probaba era el 409 de otro estado.
        //
        // Se escribe en dos pasos, midiendo el código en una variable:
        //
        //     CODIGO=$(curl ... -o "$CUERPO" -w '%{http_code}' -d "{\"a\":1}" "$URL")
        //     juzga "..." "$CODIGO" 422
        //
        // La regla busca un `-d "{` dentro de una sustitución entrecomillada,
        // juntando las continuaciones de línea.
        $guiones   = glob($raiz . '/pruebas/*.sh') ?: [];
        $culpables = [];

        foreach ($guiones as $archivo) {
            $lineas = explode("\n", file_get_contents($archivo) ?: '');

            foreach ($lineas as $numero => $linea) {
                if (!str_contains($linea, '"$(curl')) {
                    continue;
                }

                // Se pegan las continuaciones para ver la orden completa.
                $orden = $linea;
                $i     = $numero;

                while (str_ends_with(rtrim($orden), '\\') && isset($lineas[$i + 1])) {
                    $i++;
                    $orden .= $lineas[$i];
                }

                if (preg_match('/-d "[^"]*\\\\"/', $orden) === 1) {
                    $culpables[] = 'pruebas/' . basename($archivo) . ':' . ($numero + 1);
                }
            }
        }

        Afirma::igual([], $culpables, 'cuerpos JSON metidos en un argumento entrecomillado');
    },

    'ninguna prueba de humo llama a un ayudante que no definió' => function () use ($raiz): void {
        // ⚠️ Medido: `humo-identidad.sh` llamaba dos veces a `dice`, que ese
        // guion no define —lo definen los otros once—. Bash escribió «dice:
        // command not found» en el error, siguió con la línea de abajo y el
        // guion terminó anunciando «25 comprobaciones, todas pasan», con dos
        // comprobaciones que nunca se hicieron. Una prueba que no corre no
        // avisa: se ve igual que una que pasa.
        //
        // Cada guion define sus ayudantes en su cabecera, copiados entre ellos.
        // El vocabulario común es la unión de todos; si un guion usa una de esas
        // palabras como orden y no la define, la comprobación se va a la nada.
        $guiones = glob($raiz . '/pruebas/*.sh') ?: [];

        // La v2 empezó con siete (fase 1) y suma una tanda por módulo; la fase 2
        // trajo la de organización y la 3 la de personal. El piso se sube cuando
        // llegan, nunca se baja para que pase.
        Afirma::cierto(count($guiones) >= 9, 'se encontraron ' . count($guiones) . ' guiones');

        $fuentes    = [];
        $definidos  = [];
        $vocabulario = [];

        foreach ($guiones as $archivo) {
            $nombre           = basename($archivo);
            $fuentes[$nombre] = file_get_contents($archivo) ?: '';

            preg_match_all('/^([a-z_][a-z0-9_]*)\(\)/m', $fuentes[$nombre], $hallados);
            $definidos[$nombre] = $hallados[1];
            $vocabulario        = array_merge($vocabulario, $hallados[1]);
        }

        $vocabulario = array_unique($vocabulario);
        $culpables   = [];

        foreach ($fuentes as $nombre => $fuente) {
            $ajenos = array_diff($vocabulario, $definidos[$nombre]);

            foreach (explode("\n", $fuente) as $numero => $linea) {
                $limpia = ltrim($linea);

                if ($limpia === '' || str_starts_with($limpia, '#')) {
                    continue;
                }

                foreach ($ajenos as $palabra) {
                    // La palabra como orden: al principio de la línea, después
                    // de `&&`, `||`, `;`, `(` o `$(`, y seguida de un espacio.
                    $patron = '/(?:^|&&|\|\||;|\(|\{)\s*' . preg_quote($palabra, '/') . '\s/';

                    if (preg_match($patron, $limpia)) {
                        $culpables[] = 'pruebas/' . $nombre . ':' . ($numero + 1) . ' usa «' . $palabra . '»';
                    }
                }
            }
        }

        Afirma::igual([], $culpables, 'llamadas a ayudantes que el guion no define');
    },

    'todo punto de entrada fija el reloj del negocio' => function () use ($raiz): void {
        // En la línea de comandos PHP corre en UTC si nadie le dice otra cosa,
        // y el cron del hospedaje es línea de comandos. Medido: cuatro guiones
        // —entre ellos el del respaldo— nombraban sus archivos y escribían sus
        // fechas seis horas adelantadas, mientras la aplicación web y la base
        // iban en la hora del negocio.
        //
        // Un punto de entrada es cada .php que se invoca directo: los de
        // `publico/` y los de `guiones/` (no los de `guiones/demo/`, que son
        // pedazos que `demo.php` incluye). Todos tienen que pasar por `Reloj`,
        // directo o a través de `Aplicacion`.
        $entradas = array_merge(
            glob($raiz . '/publico/*.php') ?: [],
            glob($raiz . '/guiones/*.php') ?: []
        );

        Afirma::cierto(count($entradas) >= 6, 'se encontraron ' . count($entradas) . ' puntos de entrada');

        $culpables = [];

        foreach ($entradas as $archivo) {
            $fuente = file_get_contents($archivo) ?: '';

            if (str_contains($fuente, 'Reloj::fijaLaZona') || str_contains($fuente, 'Aplicacion($raiz)')) {
                continue;
            }

            $culpables[] = str_replace($raiz . '/', '', $archivo);
        }

        Afirma::igual([], $culpables, 'puntos de entrada que corren en la zona que les toque');
    },

    'las contraseñas de las bases sólo aparecen en su configuración privada' => function () use ($raiz): void {
        // Se buscan los valores reales, no parecidos. La prueba los tiene en
        // memoria y nunca los imprime: si algo falla, informa el archivo y el
        // entorno al que pertenece la credencial, pero no revela su valor.
        $rutaBdNormal  = $raiz . '/config/bd.php';
        $rutaBdPruebas = $raiz . '/config/bd.pruebas.php';

        Afirma::cierto(is_file($rutaBdNormal), 'existe la configuración privada cotidiana');
        Afirma::cierto(is_file($rutaBdPruebas), 'existe la configuración privada de pruebas');

        /** @var array{clave:string} $normal */
        $normal = require $rutaBdNormal;
        /** @var array{clave:string} $pruebas */
        $pruebas = require $rutaBdPruebas;

        $claveNormal  = (string) ($normal['clave'] ?? '');
        $clavePruebas = (string) ($pruebas['clave'] ?? '');

        Afirma::cierto(strlen($claveNormal) >= 8, 'la contraseña local cotidiana es razonable');
        Afirma::cierto(strlen($clavePruebas) >= 8, 'la contraseña local de pruebas es razonable');
        Afirma::cierto(
            !hash_equals($claveNormal, $clavePruebas),
            'las bases cotidiana y de pruebas usan contraseñas distintas'
        );

        // ⚠️ Esta regla **no** usa la lista de archivos `.php` de arriba, y es a
        // propósito: una contraseña se filtra en un `.md`, en un `.sh`, en un
        // ejemplo de la documentación o en un registro de error, no en una clase.
        // Mirar sólo el código es mirar donde no pasa. Se revisa todo el
        // proyecto, incluido `docs/`, las plantillas y los otros archivos
        // privados. Cada contraseña se permite sólo en el archivo de base al
        // que pertenece; así también se detecta una reutilización accidental.
        $configuracionPrivada = [
            $rutaBdNormal,
            $raiz . '/config/app.php',
            $rutaBdPruebas,
            $raiz . '/config/app.pruebas.php',
        ];

        $credenciales = [
            'base cotidiana' => ['clave' => $claveNormal, 'rutaPermitida' => $rutaBdNormal],
            'base de pruebas' => ['clave' => $clavePruebas, 'rutaPermitida' => $rutaBdPruebas],
        ];

        $culpables = [];
        $revisados = 0;

        $origen = new RecursiveDirectoryIterator($raiz, FilesystemIterator::SKIP_DOTS);
        $filtrado = new RecursiveCallbackFilterIterator(
            $origen,
            static function (SplFileInfo $archivo) use ($raiz): bool {
                if (!$archivo->isDir()) return true;
                $ruta = $archivo->getPathname() . '/';
                if (in_array($archivo->getFilename(), ['node_modules', '.git', '.expo'], true)) return false;
                if ($ruta === $raiz . '/almacenamiento/') return false;
                return $ruta !== $raiz . '/movil/android/' && $ruta !== $raiz . '/movil/ios/';
            }
        );
        $iterador = new RecursiveIteratorIterator($filtrado);

        foreach ($iterador as $archivo) {
            $ruta = $archivo->getPathname();

            // Android e iOS los genera Expo y están ignorados por Git. Además
            // de no ser fuente del proyecto, `.cxx` contiene cientos de
            // artefactos nativos que pueden dejar esta auditoría leyendo el
            // resultado de una compilación durante minutos.
            if (preg_match('#/(node_modules|\.git|\.expo)/#', $ruta) === 1
                || str_contains($ruta, $raiz . '/movil/android/')
                || str_contains($ruta, $raiz . '/movil/ios/')) {
                continue;
            }

            // Un respaldo pesa y no trae la contraseña —`pruebas/respaldo.sh` lo
            // comprueba—; el tope es para no leer un archivo enorme por nada.
            if (!$archivo->isFile() || $archivo->getSize() > 5_000_000
                || preg_match('/\.(?:png|jpe?g|gif|webp|ico|pdf|zip|gz|woff2?|ttf|otf)$/i', $ruta) === 1) {
                continue;
            }

            $revisados++;

            $contenido = file_get_contents($ruta) ?: '';

            foreach ($credenciales as $entorno => $credencial) {
                if (
                    $ruta !== $credencial['rutaPermitida']
                    && str_contains($contenido, $credencial['clave'])
                ) {
                    $culpables[] = str_replace($raiz . '/', '', $ruta) . ' (' . $entorno . ')';
                }
            }
        }

        // Si un día esto revisa cuatro archivos, la regla se rompió sin avisar.
        Afirma::cierto($revisados > 200, 'la revisión alcanzó al proyecto entero');
        Afirma::igual([], $culpables, 'archivos con la contraseña adentro');

        // Si hay repositorio, ninguno de los cuatro archivos privados puede
        // estar dentro. Van nombrados uno por uno y no como `config/*.php`, para
        // que una configuración futura no quede exenta sin revisión explícita.
        if (!is_dir($raiz . '/.git')) {
            return;
        }

        // ⚠️ Los renglones se leen uno por uno y los comentarios se tiran. La
        // primera versión buscaba la ruta con `str_contains` sobre el archivo
        // entero, y al comprobarla —comentando el renglón que tapa la
        // configuración de pruebas— **siguió en verde**: la ruta seguía ahí,
        // dentro del comentario. Un `.gitignore` comentado no ignora nada.
        $ignorados = [];

        foreach (explode("\n", file_get_contents($raiz . '/.gitignore') ?: '') as $renglon) {
            $renglon = trim($renglon);

            if ($renglon === '' || str_starts_with($renglon, '#')) {
                continue;
            }

            $ignorados[ltrim($renglon, '/')] = true;
        }

        $sinTapar = [];

        foreach ($configuracionPrivada as $ruta) {
            if (!is_file($ruta)) {
                continue;
            }

            $corto = str_replace($raiz . '/', '', $ruta);

            if (!isset($ignorados[$corto])) {
                $sinTapar[] = $corto;
            }
        }

        Afirma::igual([], $sinTapar, 'archivos con secretos que el repositorio no ignora');
    },

    'toda consulta puede entrar a su tabla por un índice' => function () use ($raiz): void {
        // ⚠️ Esta regla nació de un arreglo a medias, hecho la noche anterior.
        // Se cambió `WHERE DATE(s.momento) = ?` por un rango, con la razón
        // correcta —una función sobre la columna le quita al motor el índice— y
        // **sin comprobar que hubiera un índice que usar**. No lo había:
        // `salida` tiene `(id_almacen, momento)` y esa consulta no filtra por
        // almacén, así que `momento` quedaba como segunda columna de un índice
        // cuya primera no aparece. Medido con 100,000 salidas: **97,562
        // renglones leídos para devolver 10**, 54.9 ms contra 0.4.
        //
        // Quitar la función es necesario y no suficiente. La otra regla vigila la
        // primera mitad; ésta la segunda.
        //
        // Lo que se exige es lo que evita el escaneo: que **la tabla del `FROM`**
        // pueda entrar por un índice con lo que esa consulta filtra de ella. Las
        // que llegan por `JOIN` no lo necesitan —entran por la llave de la
        // condición del `JOIN`, y lo que se les filtre encima cae sobre las pocas
        // filas ya unidas, que es el caso de `rc.dia_visita` en la cartera de un
        // vendedor—. Y basta con **una** columna que sirva: con esa el motor
        // entra, y el resto se resuelve sobre lo que queda.
        //
        // Se lee del esquema y no de la base: lo que tiene que estar bien es el
        // DDL que se despliega.
        $indices  = [];
        $columnas = [];

        foreach (glob($raiz . '/esquema/*.sql') ?: [] as $guion) {
            $sql = file_get_contents($guion) ?: '';

            preg_match_all('/CREATE TABLE(?:\s+IF NOT EXISTS)?\s+`?([a-z_0-9]+)`?\s*\(([\s\S]*?)\n\)/i', $sql, $tablas, PREG_SET_ORDER);

            foreach ($tablas as $tabla) {
                $nombre = strtolower($tabla[1]);

                foreach (explode("\n", $tabla[2]) as $linea) {
                    $linea = trim($linea);

                    if (preg_match('/^(?:PRIMARY\s+KEY|UNIQUE\s+KEY|UNIQUE|KEY|INDEX|CONSTRAINT|FOREIGN\s+KEY)/i', $linea) === 1) {
                        if (preg_match('/\(([^)]*)\)/', $linea, $entre) === 1) {
                            $cols = [];

                            foreach (explode(',', $entre[1]) as $col) {
                                $col = (string) preg_replace('/\(\d+\)$/', '', strtolower(trim($col, " `\t")));

                                if ($col !== '') {
                                    $cols[] = $col;
                                }
                            }

                            if ($cols !== []) {
                                $indices[$nombre][] = $cols;
                            }
                        }

                        continue;
                    }

                    if (preg_match('/^`?([a-z_0-9]+)`?\s+[A-Za-z]/', $linea, $col) === 1) {
                        $columnas[$nombre][strtolower($col[1])] = true;
                    }
                }
            }

            preg_match_all('/CREATE\s+(?:UNIQUE\s+)?INDEX\s+`?[a-z_0-9]+`?\s+ON\s+`?([a-z_0-9]+)`?\s*\(([^)]*)\)/i', $sql, $sueltos, PREG_SET_ORDER);

            foreach ($sueltos as $suelto) {
                $cols = [];

                foreach (explode(',', $suelto[2]) as $col) {
                    $col = strtolower(trim($col, " `\t"));

                    if ($col !== '') {
                        $cols[] = $col;
                    }
                }

                if ($cols !== []) {
                    $indices[strtolower($suelto[1])][] = $cols;
                }
            }

            // Las migraciones incrementales de MariaDB suelen añadir el
            // índice dentro de ALTER TABLE. Si la regla sólo leyera CREATE
            // INDEX, declararía un falso escaneo aunque el DDL desplegado sí
            // tenga una vía de acceso (028_indices_reportes.sql lo evidenció).
            // ⚠️ Un mismo ALTER TABLE puede añadir varios índices (040 añade
            // cuatro a la bitácora). Leer sólo el primero de cada sentencia
            // declaraba escaneos que no existen; se recorre la sentencia entera.
            preg_match_all('/ALTER\s+TABLE\s+`?([a-z_0-9]+)`?([\s\S]*?);[ \t]*(?:\n|$)/i', $sql, $alterados, PREG_SET_ORDER);
            foreach ($alterados as $alterado) {
                preg_match_all(
                    '/ADD\s+(?:UNIQUE\s+)?(?:KEY|INDEX)\s+(?:IF\s+NOT\s+EXISTS\s+)?`?[a-z_0-9]+`?\s*\(([^)]*)\)/i',
                    $alterado[2],
                    $agregados,
                    PREG_SET_ORDER
                );
                foreach ($agregados as $agregado) {
                    $cols = [];
                    foreach (explode(',', $agregado[1]) as $col) {
                        $col = (string) preg_replace('/\(\d+\)$/', '', strtolower(trim($col, " `\t")));
                        if ($col !== '') {
                            $cols[] = $col;
                        }
                    }
                    if ($cols !== []) {
                        $indices[strtolower($alterado[1])][] = $cols;
                    }
                }
            }
        }

        /**
         * ¿Puede el motor entrar a `$tabla` con estas columnas filtradas?
         *
         * Basta **una** que encabece un índice; si va más adentro de un índice
         * compuesto, todas las que tiene delante han de estar filtradas también,
         * porque un índice se recorre por su prefijo.
         *
         * @param array<string,true> $filtradas
         */
        $entra = static function (string $tabla, array $filtradas) use ($indices): bool {
            foreach (array_keys($filtradas) as $columna) {
                foreach ($indices[$tabla] as $cols) {
                    $donde = array_search($columna, $cols, true);

                    if ($donde === false) {
                        continue;
                    }

                    $antesTambien = true;

                    for ($i = 0; $i < $donde; $i++) {
                        if (!isset($filtradas[$cols[$i]])) {
                            $antesTambien = false;
                            break;
                        }
                    }

                    if ($antesTambien) {
                        return true;
                    }
                }
            }

            return false;
        };

        $culpables = [];

        foreach ([...glob($raiz . '/modelos/*.php') ?: [], ...glob($raiz . '/servicios/*.php') ?: []] as $archivo) {
            $texto = file_get_contents($archivo) ?: '';
            $corto = str_replace($raiz . '/', '', $archivo);

            // Un método por consulta, que es como está escrito este proyecto. Se
            // corta por método y no por punto y coma porque el `WHERE` se arma
            // concatenando: los trozos de un mismo `WHERE` viven en variables.
            foreach (preg_split('/\n    (?:public|private|protected) function /', $texto) ?: [] as $metodo) {
                preg_match_all('/\bFROM\s+([a-z_0-9]+)(?:\s+(?:AS\s+)?([a-z_]{1,4}))?(?![a-z_0-9])/i', $metodo, $desde, PREG_SET_ORDER);

                foreach ($desde as $uno) {
                    $tabla = strtolower($uno[1]);

                    if (!isset($columnas[$tabla]) || ($indices[$tabla] ?? []) === []) {
                        continue;
                    }

                    $alias = ($uno[2] ?? '') !== '' ? strtolower($uno[2]) : null;

                    // Lo que el método filtra de esa tabla. El valor comparado
                    // puede ser un `?`, un paréntesis o **la columna de otra
                    // tabla**: un predicado correlacionado como
                    // `y.id_usuario = u.id` sirve para entrar por índice igual
                    // que un parámetro, y no verlo así daba un falso positivo en
                    // el panel en vivo.
                    //
                    // ⚠️ Pero sólo si es de **otro** alias. `e.cantidad <=
                    // e.minimo` compara dos columnas de la misma fila: eso no es
                    // un predicado de acceso, no hay índice que lo pueda servir y
                    // contarlo señalaba una consulta que entra por `id_almacen` y
                    // está perfecta.
                    $valor = '(?:[?(]|[a-z_0-9]{1,20}\.[a-z_0-9]+)';

                    // ⚠️ El predicado no siempre va detrás de un `WHERE`: aquí se
                    // arma el `WHERE` juntando trozos, y un trozo es la cadena
                    // `'b.modulo = ?'` a secas. La primera versión de esta regla
                    // exigía `WHERE` o `AND` delante y **no vio el defecto que la
                    // hizo nacer**: la bitácora quedaba en verde.
                    //
                    // Y ahí está la otra mitad: un trozo entrecomillado es un
                    // filtro **opcional** —vive dentro de un `if`, se junta con
                    // `implode`—, así que puede llegar **solo**. Los que van
                    // detrás de un `WHERE` o un `AND` dentro de la consulta están
                    // siempre. La distinción importa porque `apuntes()` filtra
                    // por `momento`, que sí tiene índice, y con eso la bitácora
                    // pasaba en verde mientras la búsqueda por módulo —sola, que
                    // es como la usa la pantalla— leía la tabla entera.
                    $fijas   = [];
                    $sueltas = [];

                    foreach ([['/\b(?:WHERE|AND|OR)\s+/', &$fijas], ['/[\x27"]\s*/', &$sueltas]] as $par) {
                        [$antes, &$bolsa] = $par;

                        if ($alias !== null) {
                            $otroAlias = '(?!' . preg_quote($alias, '/') . '\.)';
                            $patron    = substr($antes, 0, -1) . preg_quote($alias, '/') . '\.([a-z_0-9]+)\s*(?:=|<|>|<=|>=|IN)\s*' . $otroAlias . $valor . '/i';
                        } else {
                            // Sin alias las columnas van sin prefijo, y eso sólo
                            // se puede leer sin ambigüedad cuando la consulta no
                            // une nada: con un `JOIN` de por medio no se sabe de
                            // quién es cada columna, y adivinarlo daría falsos
                            // positivos.
                            if (stripos($metodo, 'JOIN') !== false) {
                                continue 2;
                            }

                            $patron = substr($antes, 0, -1) . '([a-z_0-9]+)\s*(?:=|<|>|<=|>=|IN)\s*' . $valor . '/i';
                        }

                        preg_match_all($patron, $metodo, $hallados);

                        foreach ($hallados[1] as $columna) {
                            $columna = strtolower($columna);

                            if (isset($columnas[$tabla][$columna])) {
                                $bolsa[$columna] = true;
                            }
                        }

                        unset($bolsa);
                    }

                    $sueltas = array_diff_key($sueltas, $fijas);

                    if ($fijas === [] && $sueltas === []) {
                        continue;
                    }

                    // Con los filtros fijos basta: si con ellos entra, cualquier
                    // opcional que se añada encima sólo afina lo que ya entró.
                    if ($entra($tabla, $fijas)) {
                        continue;
                    }

                    if ($sueltas === []) {
                        $nombres = array_keys($fijas);
                        sort($nombres);
                        $culpables[$corto . ': ' . $tabla . ', filtrando por ' . implode(', ', $nombres)] = true;

                        continue;
                    }

                    // Si no, la consulta depende de los opcionales, y cada uno
                    // tiene que valer por sí mismo: la pantalla que sólo pide
                    // módulo no trae nada más con que entrar.
                    foreach (array_keys($sueltas) as $columna) {
                        if (!$entra($tabla, $fijas + [$columna => true])) {
                            $culpables[$corto . ': ' . $tabla . ', filtrando sólo por ' . $columna] = true;
                        }
                    }
                }
            }
        }

        // Si un día esto no lee ningún índice, la regla se rompió sin avisar.
        Afirma::cierto(count($indices) > 20, 'se leyeron los índices del esquema');
        Afirma::igual([], array_keys($culpables), 'consultas que no pueden entrar a su tabla por un índice');
    },

    'la base tiene exactamente las tablas que el esquema declara' => function () use ($raiz): void {
        // ⚠️ La cuenta se cuadra sola, y por eso no se cuenta: a una base a la
        // que le **falte** una tabla del negocio y le **sobre** una de basura le
        // salen los mismos 45 que declara el esquema. Medido: una prueba dejaba
        // `prueba_andamiaje` olvidada —el corredor hace `require` de todos los
        // archivos antes de filtrar, así que una corrida filtrada la creaba sin
        // correr la prueba que la tira— y el diagnóstico decía «Todo en orden»
        // con 46 contra 45. La basura tapa el hueco que esa página existe para
        // ver, que es un guion del esquema sin aplicar en el servidor.
        //
        // Aquí se comparan los nombres en las dos direcciones. Lo que falta es
        // un guion sin aplicar; lo que sobra es basura de alguna prueba o de
        // algún arreglo a mano, y en local también importa: es la base contra la
        // que se mide todo lo demás.
        //
        // ⚠️ **Y se revisan las dos bases, no la del entorno en curso.** Cuando
        // las pruebas pasaron a correr contra `pruebas`, esta regla se fue con
        // ellas y **dejó sin vigilancia la base que sirve el navegador**. Medido:
        // tres guiones del esquema aplicados a la de pruebas y no a la diaria —45
        // tablas contra 46—, y el sitio **roto**: una contraseña equivocada
        // contestaba **500** («Table 'timon.intento_acceso' doesn't exist»)
        // en vez de decirle a la persona que se equivocó. Estuvo así toda la
        // noche, con la tanda entera en verde.
        //
        // La lección, que ya es la de varias noches: **una comprobación que se
        // muda deja de mirar lo que miraba**. Aquí se mira cada base que el
        // proyecto configura, y la que no exista se salta.
        $bases = [];

        // En una revisión previa a migrar, la base cotidiana puede ir en la
        // versión anterior. La corrida normal conserva ambas comprobaciones.
        $entornos = getenv('PB_ESQUEMA_AISLADO') === '1' ? ['pruebas'] : ['local', 'pruebas'];
        foreach ($entornos as $entorno) {
            $archivo = $raiz . '/config/bd' . ($entorno === 'local' ? '' : '.' . $entorno) . '.php';

            if (!is_file($archivo)) {
                continue;
            }

            /** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
            $config = require $archivo;
            $bases[(string) $config['base']] = $config;
        }

        Afirma::cierto($bases !== [], 'hay al menos una base configurada que revisar');

        $delEsquema = [];

        // La misma lectura que `aplica-esquema.php` y el diagnóstico: una tabla
        // de trabajo que el guion crea y borra no es del esquema.
        $guiones = glob($raiz . '/esquema/*.sql') ?: [];
        sort($guiones, SORT_STRING);
        $delEsquema = array_fill_keys(MigracionesEsquema::tablasDeclaradas($guiones), true);

        // Si un día esto compara dos listas vacías, la regla se rompió sin avisar.
        Afirma::cierto(count($delEsquema) > 20, 'se leyeron las tablas del esquema');

        foreach ($bases as $nombre => $config) {
            $bd       = new BaseDatos($config);
            $deLaBase = [];

            foreach ($bd->filas(
                "SELECT table_name AS t FROM information_schema.tables
                 WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'"
            ) as $fila) {
                $deLaBase[strtolower((string) $fila['t'])] = true;
            }

            Afirma::igual(
                [],
                array_values(array_diff(array_keys($delEsquema), array_keys($deLaBase))),
                "tablas del esquema que no están en «{$nombre}»"
            );
            Afirma::igual(
                [],
                array_values(array_diff(array_keys($deLaBase), array_keys($delEsquema))),
                "tablas de «{$nombre}» que el esquema no declara"
            );
        }
    },

    'todo parámetro del catálogo tiene quien lo lea, y al revés' => function () use ($raiz): void {
        // ⚠️ Ya pasó una vez, y durante todo el proyecto: `dias_retencion_ubicacion`
        // estaba en el catálogo desde el primer guion del esquema, con su
        // descripción, y **no tenía un solo lector**. La documentación daba la
        // purga por hecha. Un parámetro sin lector es una promesa escrita que el
        // sistema no cumple, y no se delata: la pantalla de parámetros lo enseña
        // igual, y alguien lo cambia creyendo que sirve de algo.
        //
        // Al revés cuesta lo mismo y duele parecido: una clave mal escrita en el
        // código —`minutos_sesion_inactivo`— se va al valor por omisión, en
        // silencio, y el número del catálogo deja de mandar sin que nadie lo note.
        $claves = [];

        foreach (glob($raiz . '/esquema/*.sql') ?: [] as $guion) {
            $sql = file_get_contents($guion) ?: '';

            if (preg_match_all('/INSERT INTO parametro[\s\S]*?;/i', $sql, $bloques) === 0) {
                continue;
            }

            foreach ($bloques[0] as $bloque) {
                // También la forma `INSERT ... SELECT 'clave', ... WHERE NOT EXISTS`,
                // que es como se agregan parámetros a una base ya poblada (043).
                preg_match_all("/(?:\(|SELECT)\s*'([a-z_]+)'\s*,/", $bloque, $encontradas);

                foreach ($encontradas[1] as $clave) {
                    $claves[$clave] = str_replace($raiz . '/', '', $guion);
                }
            }
        }

        $codigo   = '';
        $iterador = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($raiz, FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterador as $archivo) {
            $ruta = $archivo->getPathname();

            if (!str_ends_with($ruta, '.php')) {
                continue;
            }

            // El esquema declara y los documentos cuentan: ninguno lee.
            if (str_contains($ruta, '/node_modules/') || str_contains($ruta, '/esquema/') || str_contains($ruta, '/docs/')) {
                continue;
            }

            $codigo .= file_get_contents($ruta) . "\n";
        }

        preg_match_all("/->(?:valor|entero|decimal|bandera)\(\s*'([a-z_]+)'/", $codigo, $pedidas);
        $pedidas = array_values(array_unique($pedidas[1]));

        $sinLector = [];

        foreach ($claves as $clave => $guion) {
            if (!in_array($clave, $pedidas, true)) {
                $sinLector[] = $clave . ' (' . $guion . ')';
            }
        }

        $sinCatalogo = [];

        foreach ($pedidas as $clave) {
            if (!isset($claves[$clave])) {
                $sinCatalogo[] = $clave;
            }
        }

        // Si un día esto no encuentra ninguna clave, la regla se rompió sin avisar.
        Afirma::cierto($claves !== [], 'se encontraron las claves del catálogo');
        Afirma::igual([], $sinLector, 'parámetros del catálogo que nadie lee');
        Afirma::igual([], $sinCatalogo, 'claves que el código pide y no están en el catálogo');
    },

    'ninguna plantilla imprime un dato sin escaparlo' => function () use ($raiz): void {
        // `Nucleo\Vista` le pasa `$e()` a cada plantilla y dice que no hay forma
        // de imprimir sin ella «salvo escribiéndolo a propósito, que entonces se
        // ve en la revisión». **La revisión es lo que no escala**, y esta misma
        // noche cuatro comprobaciones en verde no comprobaban lo que decían. Un
        // Un `<?=` que imprime `$c['nombre']` crudo es un nombre de cliente —que
        // lo escribe un vendedor en el teléfono— saliendo tal cual en la
        // pantalla del dueño.
        //
        // ⚠️ Los comentarios de esta prueba **no escriben el cierre de PHP**:
        // un `?` con `>` dentro de un `//` cierra el bloque igual, y el resto
        // del archivo se sirve como texto. Costó un error de sintaxis.
        //
        // De cada salida corta sólo importa **lo que puede llegar a imprimirse**:
        // la condición de un ternario no se imprime, así que la regla se queda
        // con las ramas. Sobre cada rama borra lo que ya es seguro —`$e(...)`,
        // los ayudantes `pb_*` que generan HTML escapado, los literales, los
        // casts numéricos, `count`, `date`, `number_format`,
        // `sprintf`— y lo que sobra no puede tocar un `$algo['clave']` ni una
        // variable que la cabecera declare `string`.
        //
        // Tres formas quedan permitidas, y las tres se declaran en la plantilla:
        //
        //  1. Un ayudante local que **recibe `$e`**: `$campos`, `$linea`, `$lista`
        //     arman HTML y escapan dentro. Se exige el `use ($e)` en su firma.
        //  2. Una variable marcada **`HTML ya pintado`** en su `@var`: la pantalla
        //     que la plantilla base mete dentro, o los filtros de un reporte. La
        //     excepción vive en la plantilla, no en esta prueba, porque el riesgo
        //     está allá.
        //  3. Un cast, que ya no es el dato.
        $vistas = [];
        $iterador = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($raiz . '/vistas', FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterador as $archivo) {
            if (str_ends_with($archivo->getPathname(), '.php')) {
                $vistas[] = $archivo->getPathname();
            }
        }

        sort($vistas);

        /** Parte un ternario y devuelve sólo las ramas: la condición no se imprime. */
        $ramas = static function (string $expr) use (&$ramas): array {
            $nivel   = 0;
            $comilla = '';
            $largo   = strlen($expr);

            for ($i = 0; $i < $largo; $i++) {
                $c = $expr[$i];

                if ($comilla !== '') {
                    if ($c === $comilla && $expr[$i - 1] !== '\\') {
                        $comilla = '';
                    }
                    continue;
                }

                if ($c === "'" || $c === '"') {
                    $comilla = $c;
                    continue;
                }

                if ($c === '(' || $c === '[') {
                    $nivel++;
                    continue;
                }

                if ($c === ')' || $c === ']') {
                    $nivel--;
                    continue;
                }

                if ($nivel !== 0 || $c !== '?') {
                    continue;
                }

                // `??` no es un ternario.
                if (($expr[$i + 1] ?? '') === '?') {
                    $i++;
                    continue;
                }

                $sub     = 0;
                $comilla = '';

                for ($j = $i + 1; $j < $largo; $j++) {
                    $d = $expr[$j];

                    if ($comilla !== '') {
                        if ($d === $comilla && $expr[$j - 1] !== '\\') {
                            $comilla = '';
                        }
                        continue;
                    }

                    if ($d === "'" || $d === '"') {
                        $comilla = $d;
                        continue;
                    }

                    if ($d === '(' || $d === '[' || $d === '?') {
                        $sub++;
                        continue;
                    }

                    if ($d === ')' || $d === ']') {
                        $sub--;
                        continue;
                    }

                    if ($sub === 0 && $d === ':') {
                        return [
                            ...$ramas(substr($expr, $i + 1, $j - $i - 1)),
                            ...$ramas(substr($expr, $j + 1)),
                        ];
                    }

                    if ($d === ':') {
                        $sub--;
                    }
                }

                break;
            }

            return [$expr];
        };

        /** Borra de una rama todo lo que ya no puede ser un dato crudo. */
        $pela = static function (string $rama) use (&$ayudantes): string {
            // Cada llamada completa, contando paréntesis: un regex no los
            // balancea. Los `pb_*` enumerados viven en piezas.php y su contrato
            // es escapar cada dato antes de devolver HTML. Sus parámetros
            // `...Html` (las acciones de `pb_modulo`, el lado derecho de
            // `pb_resumen`) reciben la salida de otro `pb_*`, nunca un dato.
            foreach ([
                '$e', 'pb_aviso', 'pb_ico', 'pb_insignia', 'pb_vacio', 'pb_campo',
                'pb_estatus', 'pb_boton', 'pb_accion', 'pb_resumen', 'pb_modulo', 'pb_encabezado',
                'pb_seccion', 'pb_tabla', 'pb_tabla_captura', 'pb_fila_vacia', 'pb_dinero',
                // Los del modal y la baja (fase 2). Su `$marcaHtml` es
                // `$csrf->campo()`, que ya es HTML y lo arma el núcleo.
                'pb_modal', 'pb_abre_modal', 'pb_filtro_estatus',
                // El QR del segundo factor (bitácora 97): escapa la etiqueta y el
                // texto sólo se vuelve coordenadas del trazo, nunca HTML.
                'pb_qr',
                // Los de la homologación (guía §3 a §5): escapan cada dato con
                // `pb_escapa`; `pb_acciones` y el `$derechaHtml` de
                // `pb_registros` reciben la salida de otros `pb_*`, como `pb_resumen`.
                'pb_filtros', 'pb_filtros_fin', 'pb_registros', 'pb_acciones', 'pb_accion_modal', 'pb_accion_detalle',
                'pb_accion_post', 'pb_dar_baja', 'pb_detalle', 'pb_exportar', 'pb_rango', 'pb_agregar', 'pb_verbo', 'pb_accion_abre',
            ] as $segura) {
                while (($donde = strpos($rama, $segura . '(')) !== false) {
                    $nivel = 0;
                    $fin   = strlen($rama) - 1;

                    for ($i = $donde + strlen($segura), $largo = strlen($rama); $i < $largo; $i++) {
                        if ($rama[$i] === '(') {
                            $nivel++;
                        }

                        if ($rama[$i] === ')') {
                            $nivel--;

                            if ($nivel === 0) {
                                $fin = $i;
                                break;
                            }
                        }
                    }

                    $rama = substr($rama, 0, $donde) . ' ESCAPADO ' . substr($rama, $fin + 1);
                }
            }

            // Los ayudantes de la plantilla que reciben `$e` escapan adentro.
            foreach ($ayudantes as $ayudante) {
                $rama = (string) preg_replace('/\$' . $ayudante . '\s*\(.*$/', ' ESCAPADO ', $rama);
            }

            $rama = (string) preg_replace('/\'[^\']*\'|"[^"]*"/', ' ESCAPADO ', $rama);
            $rama = (string) preg_replace(
                '/\((?:int|float)\)\s*(?:\([^()]*\)|\$?[A-Za-z_][A-Za-z0-9_]*(?:\s*\[[^\]]*\]|->[A-Za-z0-9_]+)*)/',
                ' ESCAPADO ',
                $rama
            );
            $rama = (string) preg_replace('/\b(?:count|intdiv|date|str_repeat)\s*\([^()]*\)/', ' ESCAPADO ', $rama);

            return (string) preg_replace('/\b(?:number_format|sprintf)\s*\(.*$/', ' ESCAPADO ', $rama);
        };

        $culpables = [];

        foreach ($vistas as $vista) {
            $texto = file_get_contents($vista) ?: '';
            $corto = str_replace($raiz . '/', '', $vista);

            // Las variables que la cabecera declara cadena, menos las que ella
            // misma marca como HTML ya pintado.
            preg_match_all('/@var\s+\??string\s+\$([a-z_][a-z0-9_]*)(.*)$/im', $texto, $declaradas);

            $cadenas = [];

            foreach ($declaradas[1] as $i => $nombre) {
                if (!str_contains($declaradas[2][$i], 'HTML ya pintado')) {
                    $cadenas[] = $nombre;
                }
            }

            // Los ayudantes locales que reciben `$e`: escapan por contrato.
            preg_match_all(
                '/\$([a-z_][a-z0-9_]*)\s*=\s*static\s+(?:fn|function)[^;]*?\buse\s*\(([^)]*)\)/i',
                $texto,
                $firmas
            );

            $ayudantes = [];

            foreach ($firmas[1] as $i => $nombre) {
                if (preg_match('/\$e\b/', $firmas[2][$i]) === 1) {
                    $ayudantes[] = $nombre;
                }
            }

            foreach (explode("\n", $texto) as $numero => $linea) {
                if (preg_match_all('/<\?=(.+?)\?>/', $linea, $salidas) === 0) {
                    continue;
                }

                foreach ($salidas[1] as $expresion) {
                    foreach ($ramas(trim($expresion)) as $rama) {
                        $resto = $pela($rama);
                        $crudo = preg_match('/\$[a-z_][a-z0-9_]*\s*\[/i', $resto) === 1;

                        foreach ($cadenas as $cadena) {
                            if (preg_match('/\$' . $cadena . '\b/', $resto) === 1) {
                                $crudo = true;
                                break;
                            }
                        }

                        if ($crudo) {
                            $culpables[$corto . ':' . ($numero + 1) . '  ' . trim($expresion)] = true;
                        }
                    }
                }
            }
        }

        // Si un día esto revisa menos plantillas de las que hay, la regla se
        // rompió sin avisar. La v2 arrancó con diez (fase 1) y la fase 2 sumó
        // cinco, la 3 otras cinco y clientes suma tres en la fase 4; el piso
        // sube con cada módulo.
        Afirma::cierto(count($vistas) >= 23, 'la revisión alcanzó a todas las plantillas');
        Afirma::igual([], array_keys($culpables), 'salidas que imprimen un dato sin escaparlo');
    },

    'ningún guion sale con un mensaje en vez de un código' => function () use ($raiz, $archivos): void {
        // ⚠️ **`exit("algo salió mal")` imprime el mensaje y sale con código 0.**
        // Había 24 así, en los seis guiones, y el que importa es el del cron: un
        // respaldo que no pudo abrir su archivo decía que no pudo **y reportaba
        // éxito**, así que un `|| avísame` nunca se dispara y el respaldo deja de
        // existir sin que nadie se entere hasta el día que hace falta. El de
        // restaurar era igual, incluido el caso de fallar a la mitad, y es el
        // guion que el runbook manda usar para comprobar que el respaldo sirve.
        //
        // Se descubrió porque `pruebas/respaldo.sh` se puso en rojo por otra cosa
        // —la base de la restauración cambió de nombre y el usuario de MariaDB no
        // tiene permisos ahí— y su comprobación «la restauración corre» seguía en
        // **verde** sobre una restauración que no restauró nada.
        //
        // La regla no juzga qué es una falla: exige que el código sea explícito.
        // Un `exit` con cadena no lo es, y el único caso legítimo del proyecto
        // —el parámetro que dice que no se borre nada— quedó escrito como un
        // `echo` y un `exit(0)` a propósito, que es lo que se lee de un vistazo.
        $culpables = [];

        foreach ($archivos($raiz) as $archivo) {
            $fuente = file_get_contents($archivo) ?: '';

            foreach (explode("\n", $fuente) as $numero => $renglon) {
                if (preg_match('/\bexit\s*\(\s*(?:[\x27"]|sprintf\s*\()/', $renglon) === 1) {
                    $culpables[] = str_replace($raiz . '/', '', $archivo) . ':' . ($numero + 1);
                }
            }
        }

        Afirma::igual([], $culpables, 'salidas que dicen un mensaje y no un código');
    },

    'el HTML de fuera de las vistas son estos dos archivos y no más' => function () use ($raiz): void {
        // La regla de escapado de arriba mira `vistas/`, que es donde vive el
        // HTML de este proyecto. Pero hay dos archivos que pintan HTML sin ser
        // plantillas, porque tienen que funcionar cuando la plantilla no se puede
        // usar: la página de error —que aparece justo cuando algo se rompió— y el
        // diagnóstico. Los dos escapan a mano, revisado uno por uno.
        //
        // Lo que esta regla evita no es que esos dos estén mal: es que aparezca un
        // tercero y quede fuera de las dos vigilancias a la vez. Si hace falta uno
        // nuevo, se agrega aquí **a propósito**, y al agregarlo hay que mirar cómo
        // escapa.
        $permitidos = [
            'controladores/Sistema/Diagnostico.php',
            'nucleo/ManejadorErrores.php',
        ];

        $conHtml  = [];
        $iterador = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($raiz, FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterador as $archivo) {
            $ruta = $archivo->getPathname();

            if (!str_ends_with($ruta, '.php')) {
                continue;
            }

            $corto = str_replace($raiz . '/', '', $ruta);

            // Las vistas las vigila la otra regla; las pruebas pintan HTML para
            // comprobar cómo se pinta, y eso nunca sale por el cable.
            if (str_starts_with($corto, 'vistas/') || str_starts_with($corto, 'pruebas/')
                || str_starts_with($corto, 'entregables/')
                || str_starts_with($corto, 'tmp/') || str_starts_with($corto, 'output/')
                || str_contains($corto, '/node_modules/')) {
                continue;
            }

            $texto = file_get_contents($ruta) ?: '';

            if (stripos($texto, '<!doctype') !== false || stripos($texto, '<html') !== false) {
                $conHtml[] = $corto;
            }
        }

        sort($conHtml);
        sort($permitidos);

        Afirma::igual($permitidos, $conHtml, 'los archivos que pintan HTML sin ser plantillas');

        // Y que sigan escapando: los dos tienen que nombrar `htmlspecialchars`.
        foreach ($permitidos as $corto) {
            Afirma::contiene(
                'htmlspecialchars',
                file_get_contents($raiz . '/' . $corto) ?: '',
                $corto . ' escapa lo que pinta'
            );
        }
    },

    'la configuración no es alcanzable desde el navegador' => function () use ($raiz): void {
        // No basta con que esté fuera de publico/: hay que poder afirmarlo.
        Afirma::falso(
            str_starts_with(realpath($raiz . '/config') ?: '', realpath($raiz . '/publico') ?: 'x'),
            'config/ dentro de publico/'
        );

        Afirma::igual(
            '0600',
            substr(sprintf('%o', fileperms($raiz . '/config/bd.php')), -4),
            'los permisos de config/bd.php'
        );
    },
];
