#!/usr/bin/env bash
# Todo: las pruebas de dentro y las de fuera.
#
#   pruebas/todo.sh
#
# Las de dentro no necesitan servidor. Las de humo sí: comprueban lo que sale
# por el cable, que es lo único que ve la app y el navegador.
#
# `respaldo.sh` no necesita servidor pero sí crea y borra la base exclusiva
# `timon_restauracion_pruebas`, donde comprueba que el respaldo sirve.
#
# Cada módulo trae su tanda `humo-*.sh` y se agrega aquí al terminar su fase.
# Ninguna tanda borra la base entera: cada una siembra y limpia lo suyo.

set -u
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
PHP=/opt/homebrew/opt/php@8.3/bin/php
BASE="${1:-http://127.0.0.1:8081}"
export APP_ENTORNO="${APP_ENTORNO:-pruebas}"
. "$RAIZ/pruebas/exige-entorno.sh"

fallas=0

# La corrida empieza reconstruyendo el esquema: las pruebas unitarias
# arrancan sin datos de corridas anteriores.
BASE_PRUEBAS=$("$PHP" -r 'require $argv[1]."/nucleo/Autocargador.php";Nucleo\Autocargador::registrar($argv[1]);echo Nucleo\Configuracion::baseDatos($argv[1])["base"];' "$RAIZ")
# Dos tandas completas no pueden compartir la misma base: cada una la
# reconstruye y la otra empezaría a ver tablas a medio crear. Además de dar
# falsos rojos, eso duplica innecesariamente el consumo de CPU y memoria. El
# directorio se crea de forma atómica y se libera aun cuando la tanda falle.
CERROJO_TODO="${TMPDIR:-/tmp}/app-todo-${BASE_PRUEBAS}.lock"
if ! mkdir "$CERROJO_TODO" 2>/dev/null; then
  PID_TODO=$(sed -n '1p' "$CERROJO_TODO/pid" 2>/dev/null || true)
  if [[ "$PID_TODO" =~ ^[0-9]+$ ]] && kill -0 "$PID_TODO" 2>/dev/null; then
    printf 'Ya corre pruebas/todo.sh contra %s (PID %s). No se inició otra tanda.\n' \
      "$BASE_PRUEBAS" "$PID_TODO" >&2
    exit 75
  fi

  # Si la máquina o la terminal se cerraron a la fuerza puede quedar un
  # cerrojo huérfano. Sólo se retiran sus dos rutas exactas y se intenta una
  # vez más; cualquier contenido inesperado lo deja cerrado por seguridad.
  rm -f "$CERROJO_TODO/pid"
  if ! rmdir "$CERROJO_TODO" 2>/dev/null || ! mkdir "$CERROJO_TODO" 2>/dev/null; then
    printf 'No se pudo tomar el cerrojo de la suite: %s\n' "$CERROJO_TODO" >&2
    exit 75
  fi
fi
printf '%s\n' "$$" > "$CERROJO_TODO/pid"
libera_cerrojo_todo() {
  rm -f "$CERROJO_TODO/pid"
  rmdir "$CERROJO_TODO" 2>/dev/null || true
}
trap libera_cerrojo_todo EXIT
trap 'exit 130' INT
trap 'exit 143' HUP TERM

# Las migraciones se prueban sobre datos, no sobre una base vacía. La
# reconstrucción de abajo la deja otra vez limpia.
"$RAIZ/pruebas/migraciones.sh" || fallas=$((fallas + 1))
echo
"$PHP" "$RAIZ/guiones/aplica-esquema.php" "--acepto=$BASE_PRUEBAS" || exit 1

"$PHP" "$RAIZ/pruebas/correr.php" || fallas=$((fallas + 1))
echo
"$RAIZ/pruebas/humo.sh" "$BASE" || fallas=$((fallas + 1))
echo
"$RAIZ/pruebas/humo-identidad.sh" "$BASE" || fallas=$((fallas + 1))
echo
# Sucursales.
"$RAIZ/pruebas/humo-organizacion.sh" "$BASE" || fallas=$((fallas + 1))
echo
# Personal, usuarios, equipos y avisos.
"$RAIZ/pruebas/humo-personal.sh" "$BASE" || fallas=$((fallas + 1))
echo
# Concurrencia real de comanda, caja y cola de impresión en localhost.
TZ=America/Mexico_City python3 "$RAIZ/pruebas/humo-comanda.py" || fallas=$((fallas + 1))
echo
# Un central y una computadora de sucursal: la sucursal opera sin internet y se pone al día.
TZ=America/Mexico_City python3 "$RAIZ/pruebas/humo-sucursal.py" || fallas=$((fallas + 1))
echo
node "$RAIZ/guiones/genera-marca.mjs" --verifica || fallas=$((fallas + 1))
node --test "$RAIZ/pruebas/app-compatibilidad.mjs" || fallas=$((fallas + 1))
echo
# Los candados del endurecimiento vistos desde fuera: cabeceras, acceso de
# soporte con caducidad, revisión de accesos y sello de la bitácora.
"$RAIZ/pruebas/seguridad.sh" "$BASE" || fallas=$((fallas + 1))
echo
# El respaldo y su restauración. No necesita servidor, pero sí tocar la base:
# crea `timon_restauracion_pruebas`, restaura ahí y la borra al salir.
"$RAIZ/pruebas/respaldo.sh" || fallas=$((fallas + 1))
echo
# La limpieza de lo que se acumula. Va después del respaldo, igual que en el
# cron: si algo borrara más de lo que debe, la copia ya está escrita.
"$RAIZ/pruebas/mantenimiento.sh" || fallas=$((fallas + 1))
echo
# Arma los paquetes del hospedaje en un temporal y mira dentro: lleva el cron
# y la copia cifrada, ninguna llave de aquí, y un id de liberación coherente.
"$RAIZ/pruebas/paquete.sh" || fallas=$((fallas + 1))
echo
# La compuerta final, sobre un paquete extraído y estados de cron en un
# temporal. Lee la base aislada y no toca el hospedaje.
"$RAIZ/pruebas/cierre-host.sh" || fallas=$((fallas + 1))

echo
if [ "$fallas" -eq 0 ]; then
  echo $'\033[32mTodo pasa.\033[0m'
  exit 0
fi
echo $'\033[31m'"$fallas tandas con fallas."$'\033[0m'
exit 1
