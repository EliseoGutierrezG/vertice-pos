#!/usr/bin/env python3
"""Una venta de demostración en staging, con dos equipos concurrentes y cocina.

Uso: python3 pruebas/staging-comanda.py ARCHIVO_PRIVADO --ejecutar
Deja el ticket de prueba en la bitácora y retira sus tres equipos al finalizar.
No importa esquemas, no vacía tablas y no envía a una impresora física.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from html import unescape
import json
from pathlib import Path
import re
import runpy
import sys
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import uuid

ORIGEN = 'https://staging-timon.verticesoftware.com.mx'


def main():
    argumentos = argparse.ArgumentParser(description=__doc__)
    argumentos.add_argument('credenciales', type=Path)
    argumentos.add_argument('--ejecutar', action='store_true', required=True)
    args = argumentos.parse_args()
    util = runpy.run_path(str(Path(__file__).with_name('staging-personal.py')))
    texto = args.credenciales.read_text()
    clave = re.search(r'^Contraseña de todos:\s*(.+)$', texto, re.M)[1].strip()
    pin = re.search(r'^PIN de todos en la app:\s*(.+)$', texto, re.M)[1].strip()
    usuario = re.search(r'^(\S+)\s+gerente\s+', texto, re.M)[1]
    web = util['Sesion'](ORIGEN)
    _, _, html = web.pide('/entrar')
    marca = util['Formulario'](html).marca
    estado, _, _ = web.pide('/entrar', {'_marca': marca, 'usuario': usuario, 'clave': clave})
    assert estado == 302, 'No se completó el acceso de gerencia.'
    _, _, html = web.pide('/areas')
    formulario = util['Formulario'](html)
    sucursal = formulario.sucursales[0]
    marca = formulario.marca
    prefijo = 'Validación Codex ' + uuid.uuid4().hex[:8]
    equipos, tokens = [], []
    cuenta, mesa, turno_nuevo, pagada, total = None, None, None, False, '0.00'
    pasadas = 0

    def comprueba(condicion, mensaje):
        nonlocal pasadas
        assert condicion, mensaje
        pasadas += 1
        print('  ✓ ' + mensaje, flush=True)

    def api(ruta, token=None, datos=None, llave=None, secreto=None, espera=200):
        cabeceras = {'Accept': 'application/json'}
        if token:
            cabeceras['Authorization'] = 'Bearer ' + token
        if secreto:
            cabeceras['X-Equipo'] = secreto
        if datos is not None:
            cabeceras['Content-Type'] = 'application/json'
            cabeceras['Idempotency-Key'] = llave or str(uuid.uuid4())
        solicitud = Request(ORIGEN + '/api/v1' + ruta, headers=cabeceras,
                            data=json.dumps(datos).encode() if datos is not None else None)
        try:
            respuesta = urlopen(solicitud, timeout=25)
        except HTTPError as error:
            respuesta = error
        with respuesta:
            estado, crudo = respuesta.code, respuesta.read()
        assert espera is None or estado == espera, f'API {ruta}: esperaba {espera}, recibió {estado}.'
        contenido = json.loads(crudo)
        return estado, contenido.get('datos') if contenido.get('ok') else contenido.get('error')

    def datos(ruta, token=None, cuerpo=None, **opciones):
        return api(ruta, token, cuerpo, **opciones)[1]

    def post_web(ruta, cuerpo):
        estado, _, _ = web.pide(ruta, {'_marca': marca, '_envio': str(uuid.uuid4()), 'sucursal': sucursal, **cuerpo})
        assert estado == 302, f'Panel {ruta}: HTTP {estado}.'

    try:
        for numero, tipo in enumerate(['gerencia', 'gerencia', 'cocina']):
            nombre = f'{prefijo} {numero + 1}'
            registro = datos('/equipo', cuerpo={'nombre': nombre, 'plataforma': 'web'}, espera=201)
            api('/equipo/entrar', datos={'usuario': usuario, 'pin': pin}, secreto=registro['secreto'], espera=403)
            post_web('/equipos-comanda', {'codigo': registro['codigo'], 'tipo': tipo})
            _, _, html = web.pide('/equipos-comanda')
            fila = next(fila for fila in re.findall(r'<tr\b.*?</tr>', html, re.S) if nombre in fila)
            id_equipo = int(re.search(r'/equipos-comanda/(\d+)/retirar', fila)[1])
            equipos.append(id_equipo)
            comprueba(datos('/equipo', secreto=registro['secreto'])['autorizado'], f'equipo {numero + 1} espera aprobación y queda autorizado')
            token = datos('/equipo/entrar', cuerpo={'usuario': usuario, 'pin': pin}, secreto=registro['secreto'])['token']
            tokens.append(token)

        primero, segundo, cocina = tokens
        plano = datos('/plano', primero)
        mesa = next(int(m['id']) for m in reversed(plano['mesas']) if m['estado'] == 'libre' and m['id_cuenta'] is None)
        inicio = time.monotonic()
        with ThreadPoolExecutor(max_workers=2) as grupo:
            futuros = [grupo.submit(api, '/cuentas', token, {'id_mesa': mesa}, espera=None) for token in [primero, segundo]]
            aperturas = [f.result() for f in futuros]
        cuenta = next(d['id'] for e, d in aperturas if e == 201)
        comprueba(sorted(e for e, _ in aperturas) == [201, 409], 'dos aperturas simultáneas: una cuenta y un conflicto')
        comprueba(any(int(m.get('id_cuenta') or 0) == cuenta for m in datos('/plano', segundo)['mesas']),
                   'el segundo equipo ve la mesa ocupada')
        print(f'  Visibilidad de la cuenta desde el otro equipo: {time.monotonic() - inicio:.2f} s.', flush=True)
        carta = datos('/carta', primero)
        platillo = next(p for p in carta if not int(p['agotado']) and p.get('preparacion') in ['caliente', 'fria'])
        llave = str(uuid.uuid4())
        captura = {'id_platillo': int(platillo['id']), 'cantidad': 1, 'nota': prefijo, 'tiempo': 'entrada', 'modificadores': []}
        a = datos(f'/cuentas/{cuenta}/items', primero, captura, llave=llave, espera=201)
        b = datos(f'/cuentas/{cuenta}/items', primero, captura, llave=llave, espera=201)
        comprueba(a['id_item'] == b['id_item'] and len(datos(f'/cuentas/{cuenta}', primero)['items']) == 1,
                   'reintentar la captura conserva un solo platillo')
        llave = str(uuid.uuid4())
        a = datos(f'/cuentas/{cuenta}/rondas', primero, {}, llave=llave, espera=201)
        b = datos(f'/cuentas/{cuenta}/rondas', primero, {}, llave=llave, espera=201)
        ronda = a['id_ronda']
        comprueba(ronda == b['id_ronda'], 'reintentar el envío conserva una sola ronda')
        listado = datos('/cocina', cocina)['items']
        item = next(i for i in listado if int(i['id_ronda']) == ronda)
        comprueba(item['nota'] == prefijo, 'cocina recibe el platillo y su nota')
        for accion in ['preparar', 'listo', 'despachar']:
            datos(f'/cocina/{ronda}/{accion}', cocina, {'area': item['preparacion']})
        comprueba(not any(int(i['id_ronda']) == ronda for i in datos('/cocina', cocina)['items']),
                   'cocina prepara, termina y despacha la ronda de prueba')
        datos(f'/cuentas/{cuenta}/precuenta', primero, {})
        ficha = datos(f'/cuentas/{cuenta}', primero)
        total = ficha['total']
        caja = datos('/caja', primero)
        if caja['turno'] is None:
            turno_nuevo = datos('/caja/abrir', primero, {'fondo': '0.00'})['id']
        formas = [{'medio': 'efectivo', 'importe': total, 'recibido': str(Decimal(total) + Decimal('20.00'))}]
        api(f'/cuentas/{cuenta}/cobro', primero, {'version': 1, 'formas': formas}, espera=409)
        llave = str(uuid.uuid4())
        cuerpo = {'version': ficha['version'], 'formas': formas}
        pago = datos(f'/cuentas/{cuenta}/cobro', primero, cuerpo, llave=llave, espera=201)
        pagada = True
        repetido = datos(f'/cuentas/{cuenta}/cobro', segundo, cuerpo, llave=llave, espera=201)
        comprueba(pago['id_pago'] == repetido['id_pago'] and pago['cambio'] == '20.00',
                   'el cobro repetido conserva el pago y devuelve el cambio correcto')
        estado, _, ticket = web.pide(pago['ticket'])
        comprueba(estado == 200 and pago['folio'] in ticket and platillo['nombre'] in unescape(ticket),
                   'el ticket público muestra el folio y el platillo cobrado')
        comprueba(datos(f'/cuentas/{cuenta}', primero)['estado'] == 'pagada', 'la cuenta queda pagada')
        trabajos = datos('/impresiones', primero)
        comprueba(bool(trabajos), 'la cola de impresión está disponible (sin enviar a hardware)')
        print(f'  Ticket de demostración: {pago["folio"]}; importe ${total}; cuenta {cuenta}.', flush=True)
    finally:
        if cuenta is not None and tokens and not pagada:
            ficha = datos(f'/cuentas/{cuenta}', tokens[0])
            for item in ficha['items']:
                if item['estado'] != 'cancelado':
                    datos(f'/cuentas/{cuenta}/estado-item', tokens[0], {'id_item': int(item['id']), 'estado': 'cancelado',
                          'motivo': prefijo, 'autorizacion': {'usuario': usuario, 'clave': clave}})
            ficha = datos(f'/cuentas/{cuenta}', tokens[0])
            datos(f'/cuentas/{cuenta}/cancelar', tokens[0], {'version': ficha['version']})
        if mesa is not None and tokens:
            datos(f'/mesas/{mesa}/limpia', tokens[0], {})
            comprueba(any(int(m['id']) == mesa and m['estado'] == 'libre' for m in datos('/plano', tokens[0])['mesas']),
                       'la mesa de prueba vuelve a estar libre')
        if turno_nuevo is not None:
            datos('/caja/cerrar', tokens[0], {'id_turno': turno_nuevo, 'efectivo': total if pagada else '0.00'})
        for id_equipo in equipos:
            post_web(f'/equipos-comanda/{id_equipo}/retirar', {})
        for token in tokens:
            api('/plano', token, espera=401)
        comprueba(len(equipos) == len(tokens) == 3, 'los tres equipos de prueba quedan retirados y sin acceso')
        web.pide('/salir', {'_marca': marca})
    print(f'\n{pasadas} comprobaciones de comanda aprobadas.', flush=True)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print(f'Prueba interrumpida: {error if isinstance(error, AssertionError) else type(error).__name__}', file=sys.stderr)
        sys.exit(1)
