#!/usr/bin/env bash
# La limpieza de la base, corrida de verdad.
#
#   pruebas/mantenimiento.sh
#
# Una limpieza que no está enganchada a nada se lee igual que una que corre,
# y la diferencia se ve en el disco un año después. Aquí se siembran tokens y
# contadores de acceso viejos y nuevos, se corre el guion y se comprueba que
# se fueron los viejos y **sólo** los viejos. Lo suyo lleva marca y se borra
# al salir, pase lo que pase.

set -u
PHP=/opt/homebrew/opt/php@8.3/bin/php
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
. "$RAIZ/pruebas/exige-entorno.sh"

verde=$'\033[32m'; rojo=$'\033[31m'; gris=$'\033[90m'; nada=$'\033[0m'
pasadas=0; fallas=0

ok()    { printf "  %s✓%s %s\n" "$verde" "$nada" "$1"; pasadas=$((pasadas + 1)); }
mal()   { printf "  %s✗%s %s\n" "$rojo" "$nada" "$1"; fallas=$((fallas + 1)); }
juzga() { if [ "$2" = "$3" ]; then ok "$1"; else mal "$1 — esperaba $3, llegó $2"; fi; }
dice()  { if printf '%s' "$2" | grep -q -- "$3"; then ok "$1"; else mal "$1"; fi; }

php_bd() { "$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  Nucleo\Reloj::fijaLaZona("'"$RAIZ"'");
  require_once "'"$RAIZ"'/pruebas/Semilla.php";
  $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
  '"$1"'' "${@:2}"; }

limpia() {
  php_bd '
    $bd->ejecuta("DELETE FROM token_acceso WHERE token_hash LIKE \"mant%\"");
    $bd->ejecuta("DELETE FROM intento_acceso WHERE ambito LIKE \"mant_prueba_%\"");
    Pruebas\Semilla::borraUsuarios($bd, "mant.prueba");
  ' > /dev/null 2>&1
}
trap 'limpia' EXIT
limpia

IDENTIDAD=$(php_bd '
  $id = Pruebas\Semilla::usuario($bd, "mant.prueba", "mesero", "contraseña-larga-mant");
  $d = (new Modelos\Dispositivos($bd))->registraOEncuentra($id, "mant-dispositivo", "Prueba mantenimiento");
  echo $id, "|", (int) $d["id"];
')
ID_USUARIO=${IDENTIDAD%%|*}
ID_DISPOSITIVO=${IDENTIDAD##*|}

printf "\n%sSe siembra lo viejo y lo nuevo%s\n" "$gris" "$nada"

# Dos tokens: uno caducado hace mucho y uno vivo. Y dos contadores de acceso.
php_bd '
  $id   = (int) $argv[1];
  $dispositivo = (int) $argv[2];
  $bd->ejecuta(
      "INSERT INTO token_acceso (id_usuario, id_dispositivo, token_hash, expira_en) VALUES (?, ?, \"mant-viejo\", DATE_SUB(NOW(), INTERVAL 40 DAY))",
      [$id, $dispositivo]
  );
  $bd->ejecuta(
      "INSERT INTO token_acceso (id_usuario, id_dispositivo, token_hash, expira_en) VALUES (?, ?, \"mant-vivo\", DATE_ADD(NOW(), INTERVAL 10 DAY))",
      [$id, $dispositivo]
  );
  $intentos = new Modelos\IntentosAcceso($bd);
  $intentos->falla("mant_prueba_viejo", "cuenta", "192.0.2.80");
  $intentos->falla("mant_prueba_vivo", "cuenta", "192.0.2.81");
  $bd->ejecuta(
      "UPDATE intento_acceso SET actualizado_en = DATE_SUB(NOW(), INTERVAL 31 DAY) WHERE ambito = \"mant_prueba_viejo\""
  );
' "$ID_USUARIO" "$ID_DISPOSITIVO"
juzga "quedaron dos tokens sembrados"     "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM token_acceso WHERE token_hash LIKE \"mant%\"");')" 2
juzga "y cuatro contadores de acceso"      "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM intento_acceso WHERE ambito LIKE \"mant_prueba_%\"");')" 4

BITACORA_ANTES=$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM bitacora");')
BITACORA_TOPE=$(php_bd 'echo (int) $bd->valor("SELECT COALESCE(MAX(id),0) FROM bitacora");')

printf "\n%sEl ensayo no borra nada%s\n" "$gris" "$nada"

ENSAYO=$("$PHP" "$RAIZ/guiones/mantenimiento.php" --ensayo 2>&1)
juzga "el ensayo corre"              "$?" 0
dice  "y dice que es un ensayo"      "$ENSAYO" 'es un ensayo'
juzga "y los dos tokens también"     "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM token_acceso WHERE token_hash LIKE \"mant%\"");')" 2
juzga "y los cuatro contadores también" "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM intento_acceso WHERE ambito LIKE \"mant_prueba_%\"");')" 4

printf "\n%sLa limpieza de verdad%s\n" "$gris" "$nada"

SALIDA=$("$PHP" "$RAIZ/guiones/mantenimiento.php" 2>&1)
juzga "la limpieza corre"                     "$?" 0
dice  "y cuántos tokens"                      "$SALIDA" 'token_acceso: *[0-9,]* muertos'
juzga "el token caducado hace 40 días se fue" "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM token_acceso WHERE token_hash = \"mant-viejo\"");')" 0
juzga "y el token vivo sigue vivo"            "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM token_acceso WHERE token_hash = \"mant-vivo\"");')" 1
juzga "los contadores viejos se fueron"       "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM intento_acceso WHERE ambito = \"mant_prueba_viejo\"");')" 0
juzga "y los contadores vigentes siguen"      "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM intento_acceso WHERE ambito = \"mant_prueba_vivo\"");')" 2

printf "\n%sCorrerla dos veces no cambia nada%s\n" "$gris" "$nada"

"$PHP" "$RAIZ/guiones/mantenimiento.php" > /dev/null 2>&1
juzga "y el token vivo también"           "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM token_acceso WHERE token_hash = \"mant-vivo\"");')" 1
juzga "y los contadores vigentes también" "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM intento_acceso WHERE ambito = \"mant_prueba_vivo\"");')" 2

printf "\n%sLo que a propósito no se toca%s\n" "$gris" "$nada"

# `operacion_sincronizada` es el registro de «esto ya se hizo»: borrar una llave
# le abre la puerta a que una subida vieja se aplique otra vez. Y la bitácora es
# el rastro de quién hizo qué.
dice "el guion dice que no toca la bitácora"    "$(cat "$RAIZ/guiones/mantenimiento.php")" 'bitacora'
juzga "la bitácora sigue completa"              "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM bitacora WHERE id<=?",[(int)$argv[1]]);' "$BITACORA_TOPE")" "$BITACORA_ANTES"
# Cada purga que borró algo deja su apunte, del canal «tarea»; nada más se
# agrega.
juzga "y lo nuevo son sólo apuntes de la tarea" "$(php_bd 'echo (int) $bd->valor("SELECT COUNT(*) FROM bitacora WHERE id>? AND COALESCE(canal,\"\")<>\"tarea\"",[(int)$argv[1]]);' "$BITACORA_TOPE")" 0

echo
if [ "$fallas" -eq 0 ]; then
  echo "$verde$pasadas comprobaciones, todas pasan.$nada"
  exit 0
fi
echo "$rojo$fallas de $((pasadas + fallas)) fallan.$nada"
exit 1
