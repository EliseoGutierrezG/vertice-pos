#!/usr/bin/env bash
# El respaldo, restaurado de verdad (paso 20.5).
#
#   pruebas/respaldo.sh
#
# **Un respaldo que nunca se restauró no es un respaldo, es un archivo.** Aquí se
# respalda la base, se restaura en otra aparte y se comparan las dos: las mismas
# tablas, los mismos renglones en cada una, y la misma suma de comprobación en
# las que llevan dinero y existencias. Después se tira la base de prueba.
#
# La base de restauración termina en `_pruebas` y tiene un permiso explícito;
# no depende del privilegio público histórico sobre nombres `test_%`.
#
# ⚠️ No toca la base de trabajo. Lo único que escribe es un archivo de respaldo
# en `almacenamiento/respaldos/`, que es donde tienen que estar.

set -u
PHP=/opt/homebrew/opt/php@8.3/bin/php
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
. "$RAIZ/pruebas/exige-entorno.sh"
# ⚠️ El prefijo `test_` no es adorno: MariaDB recién instalado concede a todo el
# mundo permisos sobre `test` y `test\_%`, y **sobre nada más**. Con
# `timon_restauracion_pruebas` la restauración creaba la base y después
# `SELECT command denied`, así que la copia salía con cero tablas; una
# comprobación de respaldo que necesita a un administrador para crear su base no
# se corre nunca, que es tanto como no tenerla. El sufijo `_pruebas` lo exige el
# cerrojo de abajo, y el nombre cumple las dos cosas. En el hospedaje, donde las
# bases se crean en el panel, se pasa el nombre con `PB_BASE_RESTAURACION`.
PRUEBA="${PB_BASE_RESTAURACION:-test_timon_restauracion_pruebas}"
case "$PRUEBA" in
  *_pruebas|*_test) ;;
  *) echo "CERROJO: la base de restauración debe terminar en _pruebas o _test" >&2; exit 1 ;;
esac

verde=$'\033[32m'; rojo=$'\033[31m'; gris=$'\033[90m'; nada=$'\033[0m'
pasadas=0; fallas=0

ok()    { printf "  %s✓%s %s\n" "$verde" "$nada" "$1"; pasadas=$((pasadas + 1)); }
# `grep -q` cierra la tubería al primer acierto y `printf` se queja de que ya no
# hay quién lea: es ruido del shell, no de la comprobación.
busca() { { printf '%s' "$1" | grep -q -- "$2"; } 2>/dev/null; }
buscaf() { { printf '%s' "$1" | grep -qF -- "$2"; } 2>/dev/null; }
mal()   { printf "  %s✗%s %s\n" "$rojo" "$nada" "$1"; fallas=$((fallas + 1)); }
juzga() { if [ "$2" = "$3" ]; then ok "$1"; else mal "$1 — esperaba $3, llegó $2"; fi; }

# Se conecta sin base para poder mirar las dos.
sql() { "$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  Nucleo\Reloj::fijaLaZona("'"$RAIZ"'");
  $c = Nucleo\Configuracion::baseDatos("'"$RAIZ"'");
  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
  $m = new mysqli($c["host"], $c["usuario"], $c["clave"], "", (int) $c["puerto"]);
  $m->set_charset("utf8mb4");
  $r = $m->query($argv[1]);
  if ($r instanceof mysqli_result) {
      while ($f = $r->fetch_array(MYSQLI_NUM)) { echo implode("|", array_map(static fn ($v) => (string) $v, $f)), "\n"; }
  }
' "$1"; }

BASE=$("$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  $c = Nucleo\Configuracion::baseDatos("'"$RAIZ"'");
  echo $c["base"];
')

limpia() { sql "DROP DATABASE IF EXISTS $PRUEBA" > /dev/null 2>&1; }
trap 'limpia' EXIT
limpia

printf "\n%sSe respalda «%s»%s\n" "$gris" "$BASE" "$nada"

HORA_ANTES_RESPALDO=$("$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  Nucleo\Reloj::fijaLaZona("'"$RAIZ"'");
  echo date("Y-m-d-H");
')
SALIDA=$("$PHP" "$RAIZ/guiones/respaldo.php" 2>&1)
CODIGO_RESPALDO=$?
HORA_DESPUES_RESPALDO=$("$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  Nucleo\Reloj::fijaLaZona("'"$RAIZ"'");
  echo date("Y-m-d-H");
')
juzga "el respaldo corre"          "$CODIGO_RESPALDO" 0
ARCHIVO=$(ls -t "$RAIZ"/almacenamiento/respaldos/*.sql.gz 2>/dev/null | head -1)
juzga "y dejó un archivo"          "$( [ -s "$ARCHIVO" ] && echo si || echo no )" si
if busca "$SALIDA" 'tablas,'; then ok "diciendo qué respaldó"; else mal "diciendo qué respaldó"; fi

# Comprimido, porque un respaldo diario sin comprimir llena el disco del
# hospedaje mucho antes de lo que nadie espera.
juzga "está comprimido de verdad" \
  "$(head -c 2 "$ARCHIVO" | od -An -tx1 | tr -d ' \n')" '1f8b'

CRUDO=$("$PHP" -r 'echo gzdecode(file_get_contents($argv[1]));' "$ARCHIVO")
if busca "$CRUDO" 'FOREIGN_KEY_CHECKS = 0'; then
  ok "apaga las llaves para no depender del orden de las tablas"
else mal "apaga las llaves para no depender del orden de las tablas"; fi
if busca "$CRUDO" 'Fin del respaldo'; then ok "y termina con su marca de fin"; else mal "y termina con su marca de fin"; fi

# Lo que NO puede llevar: la contraseña de la base.
CLAVE_BD=$("$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  $c = Nucleo\Configuracion::baseDatos("'"$RAIZ"'");
  echo $c["clave"];
')
if [ -n "$CLAVE_BD" ] && buscaf "$CRUDO" "$CLAVE_BD"; then
  mal "el respaldo NO lleva la contraseña de la base"
else ok "el respaldo no lleva la contraseña de la base"; fi

printf "\n%sSe restaura en «%s»%s\n" "$gris" "$PRUEBA" "$nada"

"$PHP" "$RAIZ/guiones/restaura.php" "$ARCHIVO" --base="$PRUEBA" > /dev/null 2>&1
juzga "la restauración corre" "$?" 0

TABLAS_ORIGEN=$(sql "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '$BASE' AND table_type = 'BASE TABLE'")
TABLAS_COPIA=$(sql  "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '$PRUEBA' AND table_type = 'BASE TABLE'")
juzga "están todas las tablas" "$TABLAS_COPIA" "$TABLAS_ORIGEN"

printf "\n%sY se comparan renglón por renglón%s\n" "$gris" "$nada"

DISTINTAS=0
REVISADAS=0

for TABLA in $(sql "SELECT table_name FROM information_schema.tables WHERE table_schema = '$BASE' AND table_type = 'BASE TABLE' ORDER BY table_name"); do
  A=$(sql "SELECT COUNT(*) FROM \`$BASE\`.\`$TABLA\`")
  B=$(sql "SELECT COUNT(*) FROM \`$PRUEBA\`.\`$TABLA\`")
  REVISADAS=$((REVISADAS + 1))

  if [ "$A" != "$B" ]; then
    mal "$TABLA: el original tiene $A y la copia $B"
    DISTINTAS=$((DISTINTAS + 1))
  fi
done

juzga "ninguna tabla cambió de tamaño al restaurar" "$DISTINTAS" 0
if [ "$REVISADAS" -gt 20 ]; then ok "se revisaron las $REVISADAS tablas"; else mal "sólo se revisaron $REVISADAS tablas"; fi

# El tamaño no basta: dos tablas pueden tener los mismos renglones y distintos
# valores. CHECKSUM compara el contenido, y se hace donde duele: quién entra,
# con qué puesto, en qué sucursal, con qué reglas, y la bitácora. Las fases del
# giro suman aquí sus tablas de dinero: cuentas, cobros, caja e inventario.
for TABLA in sucursal personal usuario puesto_permiso parametro bitacora; do
  A=$(sql "CHECKSUM TABLE \`$BASE\`.\`$TABLA\` EXTENDED" | cut -d'|' -f2)
  B=$(sql "CHECKSUM TABLE \`$PRUEBA\`.\`$TABLA\` EXTENDED" | cut -d'|' -f2)
  juzga "$TABLA llega con el mismo contenido, no sólo con la misma cuenta" "$B" "$A"
done

# Y una comprobación de negocio: las mismas cuentas, con el mismo puesto.
CUENTAS="SELECT GROUP_CONCAT(u.usuario, ':', p.id_puesto ORDER BY u.usuario) FROM %s.usuario u JOIN %s.personal p ON p.id = u.id_personal"
CUENTAS_A=$(sql "$(printf "$CUENTAS" "\`$BASE\`" "\`$BASE\`")")
CUENTAS_B=$(sql "$(printf "$CUENTAS" "\`$PRUEBA\`" "\`$PRUEBA\`")")
juzga "y cada cuenta llega con su mismo puesto" "$CUENTAS_B" "$CUENTAS_A"

printf "\n%sLo que el respaldo conserva de la estructura%s\n" "$gris" "$nada"

LLAVES_A=$(sql "SELECT COUNT(*) FROM information_schema.key_column_usage WHERE table_schema = '$BASE' AND referenced_table_name IS NOT NULL")
LLAVES_B=$(sql "SELECT COUNT(*) FROM information_schema.key_column_usage WHERE table_schema = '$PRUEBA' AND referenced_table_name IS NOT NULL")
juzga "las llaves ajenas siguen ahí" "$LLAVES_B" "$LLAVES_A"

AUTO_A=$(sql "SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = '$BASE' AND extra LIKE '%auto_increment%'")
AUTO_B=$(sql "SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = '$PRUEBA' AND extra LIKE '%auto_increment%'")
juzga "y los contadores automáticos también" "$AUTO_B" "$AUTO_A"

# Restaurar dos veces seguidas tiene que dar lo mismo: es lo que va a pasar el
# día que alguien no esté seguro de si la primera funcionó.
"$PHP" "$RAIZ/guiones/restaura.php" "$ARCHIVO" --base="$PRUEBA" > /dev/null 2>&1
juzga "restaurar dos veces no rompe nada" "$?" 0
juzga "y deja los mismos renglones" \
  "$(sql "SELECT COUNT(*) FROM \`$PRUEBA\`.usuario")" "$(sql "SELECT COUNT(*) FROM \`$BASE\`.usuario")"

printf "\n%sEl reloj y la rotación%s\n" "$gris" "$nada"

# El nombre del archivo lo escribe un reloj, y este guion lo corre el cron: en
# la línea de comandos PHP arranca en UTC si nadie le dice otra cosa. Medido
# antes del arreglo: el respaldo de las 18:30 de la noche se llamaba como si
# fueran las 00:30 del día siguiente. Se conserva la hora justo antes y justo
# después de crear el archivo: comparar varios segundos más tarde vuelve la
# prueba intermitente cuando la restauración cruza el cambio de hora.
HORA_ARCHIVO=$(basename "$ARCHIVO" | sed -E 's/^.*-([0-9]{4}-[0-9]{2}-[0-9]{2}-[0-9]{2})[0-9]{4}\.sql.*$/\1/')
if [ "$HORA_ARCHIVO" = "$HORA_ANTES_RESPALDO" ] || [ "$HORA_ARCHIVO" = "$HORA_DESPUES_RESPALDO" ]; then
  ok "el nombre del respaldo lleva la hora del negocio"
else
  mal "el nombre del respaldo lleva la hora del negocio — esperaba $HORA_ANTES_RESPALDO o $HORA_DESPUES_RESPALDO, llegó $HORA_ARCHIVO"
fi

# La rotación tiene que tirar los viejos de verdad, no los que quedan últimos en
# orden alfabético. Se prueba con el caso que las delata: un archivo con nombre
# «alto» y fecha vieja junto a otro con nombre «bajo» y fecha reciente, que es
# exactamente lo que dejó el cambio de reloj de arriba.
#
# ⚠️ Esta comprobación aparta las copias que había y las devuelve al terminar,
# porque la rotación borra de esa misma carpeta.
CARPETA="$RAIZ/almacenamiento/respaldos"
GUARDA=$(mktemp -d)
mv "$CARPETA"/* "$GUARDA"/ 2>/dev/null

: > "$CARPETA/$BASE-2026-01-01-2300.sql.gz"   # nombre alto, archivo viejo
: > "$CARPETA/$BASE-2026-01-01-0100.sql.gz"   # nombre bajo, archivo nuevo
touch -t 202601010900 "$CARPETA/$BASE-2026-01-01-2300.sql.gz"
touch -t 202601011000 "$CARPETA/$BASE-2026-01-01-0100.sql.gz"

"$PHP" "$RAIZ/guiones/respaldo.php" --cuantos=2 > /dev/null 2>&1

if [ -f "$CARPETA/$BASE-2026-01-01-0100.sql.gz" ]; then
  ok "la rotación conserva la copia más nueva, aunque su nombre quede al final"
else mal "la rotación conserva la copia más nueva, aunque su nombre quede al final"; fi

if [ -f "$CARPETA/$BASE-2026-01-01-2300.sql.gz" ]; then
  mal "y tira la más vieja, aunque su nombre quede al principio"
else ok "y tira la más vieja, aunque su nombre quede al principio"; fi

rm -f "$CARPETA/$BASE-2026-01-01-"*.sql.gz
rm -f "$CARPETA"/*.sql.gz 2>/dev/null
mv "$GUARDA"/* "$CARPETA"/ 2>/dev/null
rmdir "$GUARDA" 2>/dev/null
DEVUELTAS=$(ls "$CARPETA" | wc -l | tr -d ' ')
if [ "$DEVUELTAS" -gt 0 ]; then
  ok "y las copias que había volvieron a su carpeta ($DEVUELTAS)"
else mal "y las copias que había volvieron a su carpeta"; fi

printf "\n%sEl cerrojo%s\n" "$gris" "$nada"

NEGADO=$("$PHP" "$RAIZ/guiones/restaura.php" "$ARCHIVO" 2>&1)
if busca "$NEGADO" '--acepto'; then
  ok "sin --acepto no se restaura encima de la base de trabajo"
else mal "sin --acepto no se restaura encima de la base de trabajo"; fi

NEGADO=$("$PHP" "$RAIZ/guiones/restaura.php" "$ARCHIVO" --base='mala; DROP' 2>&1)
if busca "$NEGADO" 'no es válido'; then
  ok "y un nombre de base con sorpresas se rechaza"
else mal "y un nombre de base con sorpresas se rechaza"; fi

printf "\n%sLa copia cifrada y el cron que avisa (fase 29)%s\n" "$gris" "$nada"

ALERTAS="$RAIZ/almacenamiento/alertas"
ANTES_ALERTAS=$(ls "$ALERTAS" 2>/dev/null | sort)
TEMPORAL=$(mktemp -d)
SALIDA_AVISO=$("$PHP" "$RAIZ/guiones/tarea.php" prueba-aviso 2>&1)
juzga "el aviso operativo se puede probar sin romper una tarea" "$?" 0
NUEVA_PRUEBA=$(comm -13 <(printf '%s\n' "$ANTES_ALERTAS") <(ls "$ALERTAS" 2>/dev/null | sort) | tail -1)
AVISO_PRUEBA=$( [ -n "$NUEVA_PRUEBA" ] && cat "$ALERTAS/$NUEVA_PRUEBA" )
if busca "$AVISO_PRUEBA" 'El Timón: aviso de prueba'; then ok "y queda identificado como prueba"; else mal "y queda identificado como prueba"; fi
[ -n "$NUEVA_PRUEBA" ] && rm -f "$ALERTAS/$NUEVA_PRUEBA"
ANTES_ALERTAS=$(ls "$ALERTAS" 2>/dev/null | sort)
SALIDA=$("$PHP" "$RAIZ/guiones/tarea.php" respaldo --cifrar 2>&1)
juzga "el cron corre el respaldo cifrado" "$?" 0
CLARO=$(ls -t "$RAIZ"/almacenamiento/respaldos/*.sql.gz 2>/dev/null | head -1)
COPIA=$(ls -t "$RAIZ"/almacenamiento/respaldos/cifrados/*.sgr 2>/dev/null | head -1)
juzga "y dejó la copia que sale del hospedaje" "$( [ -s "$COPIA" ] && echo si || echo no )" si
if busca "$SALIDA" 'cifrada y verificada'; then ok "diciendo que la verificó"; else mal "diciendo que la verificó"; fi
juzga "la copia empieza con su firma, no con gzip" "$(head -c 15 "$COPIA")" 'BASE-RESPALDO-1'
if buscaf "$(cat "$COPIA" | LC_ALL=C tr -dc '[:print:]')" 'INSERT INTO'; then mal "la copia no deja ver SQL en claro"; else ok "la copia no deja ver SQL en claro"; fi
if busca "$(cat "$RAIZ/almacenamiento/tareas/respaldo.json")" '"codigo": 0'; then ok "el estado del cron registra la corrida buena"; else mal "el estado del cron registra la corrida buena"; fi

VERIFICA=$("$PHP" "$RAIZ/guiones/descifra-respaldo.php" "$COPIA" --verifica 2>&1)
juzga "la copia se verifica con la llave" "$?" 0
HUELLA=$(printf '%s\n' "$VERIFICA" | sed -n 's/^SHA-256 del respaldo: //p')
juzga "y su contenido es exactamente el respaldo" "$HUELLA" "$(shasum -a 256 "$CLARO" | cut -d' ' -f1)"

"$PHP" "$RAIZ/guiones/descifra-respaldo.php" "$COPIA" --salida="$TEMPORAL/vuelta.sql.gz" > /dev/null 2>&1
juzga "se descifra a un archivo" "$?" 0
"$PHP" "$RAIZ/guiones/restaura.php" "$TEMPORAL/vuelta.sql.gz" --base="$PRUEBA" > /dev/null 2>&1
juzga "y ese archivo se restaura" "$?" 0
juzga "con los mismos usuarios que la base" \
  "$(sql "SELECT COUNT(*) FROM \`$PRUEBA\`.usuario")" "$(sql "SELECT COUNT(*) FROM \`$BASE\`.usuario")"

# La base desechable del hospedaje tiene su propio usuario: el archivo de
# credenciales aparte. Aquí apunta a la misma base de prueba, con su nombre.
printf '<?php return ["base" => "%s"] + require "%s";\n' "$PRUEBA" "$RAIZ/config/bd.pruebas.php" > "$TEMPORAL/bd-desechable.php"
sql "DROP DATABASE IF EXISTS \`$PRUEBA\`" > /dev/null
"$PHP" "$RAIZ/guiones/restaura.php" "$TEMPORAL/vuelta.sql.gz" --credenciales="$TEMPORAL/bd-desechable.php" > /dev/null 2>&1
juzga "se restaura con las credenciales de la base desechable" "$?" 0
juzga "en la base que esas credenciales nombran" \
  "$(sql "SELECT COUNT(*) FROM \`$PRUEBA\`.usuario")" "$(sql "SELECT COUNT(*) FROM \`$BASE\`.usuario")"
printf '<?php return ["base" => "%s"] + require "%s";\n' "$BASE" "$RAIZ/config/bd.pruebas.php" > "$TEMPORAL/bd-trampa.php"
TRAMPA=$("$PHP" "$RAIZ/guiones/restaura.php" "$TEMPORAL/vuelta.sql.gz" --credenciales="$TEMPORAL/bd-trampa.php" 2>&1)
juzga "otras credenciales no saltan el cerrojo de la base de trabajo" "$?" 1
if busca "$TRAMPA" 'BORRARÍA'; then ok "y el que lo detiene es el cerrojo"; else mal "y el que lo detiene es el cerrojo"; fi
printf '<?php return ["base" => "x"];\n' > "$TEMPORAL/bd-incompleta.php"
"$PHP" "$RAIZ/guiones/restaura.php" "$TEMPORAL/vuelta.sql.gz" --credenciales="$TEMPORAL/bd-incompleta.php" > /dev/null 2>&1
juzga "y unas credenciales incompletas se rechazan" "$?" 1

"$PHP" -r 'require "'"$RAIZ"'/nucleo/Autocargador.php"; Nucleo\Autocargador::registrar("'"$RAIZ"'"); file_put_contents($argv[1], "<?php return [\"llave\" => \"" . Nucleo\Seguridad\CifradorArchivo::generaLlave() . "\"];");' "$TEMPORAL/otra-llave.php"
PB_LLAVE_RESPALDO_ARCHIVO="$TEMPORAL/otra-llave.php" "$PHP" "$RAIZ/guiones/descifra-respaldo.php" "$COPIA" --verifica > /dev/null 2>&1
juzga "otra llave no la abre" "$?" 1

printf '<?php echo "se rompió el respaldo\\n"; exit(4);\n' > "$TEMPORAL/falla.php"
SALIDA=$(PB_TAREA_GUION="$TEMPORAL/falla.php" "$PHP" "$RAIZ/guiones/tarea.php" respaldo 2>&1)
juzga "un respaldo que falla conserva su código en el cron" "$?" 4
NUEVA=$(comm -13 <(printf '%s\n' "$ANTES_ALERTAS") <(ls "$ALERTAS" 2>/dev/null | sort) | tail -1)
AVISO=$( [ -n "$NUEVA" ] && cat "$ALERTAS/$NUEVA" )
if busca "$AVISO" 'falló la tarea «respaldo»'; then ok "y deja un aviso para una persona"; else mal "y deja un aviso para una persona"; fi
if busca "$AVISO" 'se rompió el respaldo'; then ok "con lo que dijo la tarea"; else mal "con lo que dijo la tarea"; fi
if busca "$(cat "$RAIZ/almacenamiento/tareas/respaldo.json")" '"ultima_buena": "20'; then ok "el estado conserva cuándo fue la última corrida buena"; else mal "el estado conserva cuándo fue la última corrida buena"; fi
NEGADO=$("$PHP" "$RAIZ/guiones/tarea.php" otro 2>&1)
juzga "el cron sólo corre tareas de la lista" "$?" 2

for archivo in $(comm -13 <(printf '%s\n' "$ANTES_ALERTAS") <(ls "$ALERTAS" 2>/dev/null | sort)); do rm -f "$ALERTAS/$archivo"; done
rm -rf "$TEMPORAL"

echo
if [ "$fallas" -eq 0 ]; then
  echo "$verde$pasadas comprobaciones, todas pasan.$nada"
  exit 0
fi
echo "$rojo$fallas de $((pasadas + fallas)) fallan.$nada"
exit 1
