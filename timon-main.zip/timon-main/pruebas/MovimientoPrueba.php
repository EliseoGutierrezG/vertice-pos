<?php
declare(strict_types=1);

use Pruebas\Afirma;

/**
 * El movimiento del panel y de la landing (D25.3). Se prueba leyendo los
 * archivos: que el revelado solo corra en la carga y nunca deje puesto un
 * `transform` (rompería los modales dentro de una tarjeta), que haya versión
 * quieta y que las cifras conserven su valor para el lector de pantalla. El
 * movimiento en sí se revisa con capturas.
 */

$raiz = dirname(__DIR__);
$lee  = static fn (string $ruta): string => (string) file_get_contents($raiz . '/' . $ruta);

return [
    'el panel revela solo en la carga y nunca deja el transform puesto' => function () use ($lee): void {
        $css = $lee('publico/recursos/tema.css');
        Afirma::contiene('Movimiento (D25.3)', $css, 'tema.css');
        Afirma::contiene('@keyframes pb-revela', $css, 'tema.css');
        Afirma::contiene(':root:not(.pb-revelado) .app-main :is(', $css, 'el revelado se apaga después de la carga');
        Afirma::cierto(
            (bool) preg_match('/animation:\s*pb-revela\b[^;]*\bbackwards;/', $css),
            'el revelado usa backwards'
        );
        Afirma::falso(
            (bool) preg_match('/animation:\s*pb-(revela|orilla)\b[^;]*\b(both|forwards)\b/', $css),
            'ninguna animación del revelado se queda con su último cuadro'
        );
        Afirma::contiene('calc(min(var(--pb-i, 0), 7) * var(--pb-paso-revela))', $css, 'la cascada tiene tope');
    },

    'los modales usan la curva de los diálogos y el fondo marino' => function () use ($lee): void {
        $css = $lee('publico/recursos/tema.css');
        Afirma::cierto(
            (bool) preg_match('/\.modal\.fade \.modal-dialog\s*\{[^}]*translateY\(8px\) scale\(\.97\)[^}]*var\(--pb-curva-entra\)/', $css),
            'el modal sube 8 px y crece con la curva de entrada'
        );
        Afirma::contiene('--bs-backdrop-bg: #0F1F36', $css, 'el fondo es marino');
        Afirma::contiene('.btn:active:not(:disabled):not(.disabled)', $css, 'los botones ceden al pulsar');
    },

    'con movimiento reducido el panel queda quieto' => function () use ($lee): void {
        $css = $lee('publico/recursos/tema.css');
        // La regla general apaga duraciones y retrasos: cubre el revelado, la orilla y los modales.
        Afirma::cierto(
            (bool) preg_match('/@media \(prefers-reduced-motion: reduce\)\s*\{\s*\*,[^}]*animation-duration:\s*\.01ms !important[^}]*transition-duration/', $css),
            'la regla general de movimiento reducido sigue en el tema'
        );
        $js = $lee('publico/recursos/plantilla.js');
        Afirma::contiene("matchMedia?.('(prefers-reduced-motion: reduce)')", $js, 'las cifras saltan al valor final');
    },

    'las cifras ruedan sin esconder el valor real' => function () use ($lee): void {
        $js = $lee('publico/recursos/plantilla.js');
        foreach (['window.pbCifras = { lee: leeCifras, inicia: iniciaCifras }', "oculto.className = 'visually-hidden'",
            "visible.setAttribute('aria-hidden', 'true')", 'IntersectionObserver', 'numeraRevelados(document)',
            "classList.add('pb-revelado')"] as $pieza) {
            Afirma::contiene($pieza, $js, 'plantilla.js');
        }
    },

    'el panel pide las versiones nuevas de la hoja y los scripts' => function () use ($lee): void {
        Afirma::contiene('/recursos/tema.css?v=20261118.1', $lee('vistas/plantilla/estilos.php'), 'estilos.php');
        Afirma::contiene('/recursos/tema.css?v=20261118.1', $lee('nucleo/ManejadorErrores.php'), 'la página de error');
        $scripts = $lee('vistas/plantilla/scripts.php');
        Afirma::contiene('/recursos/plantilla.js?v=20261118.1', $scripts, 'scripts.php');
    },

    // La landing llega en la fase 11 con su propia prueba de movimiento.
];
