<?php
declare(strict_types=1);

/**
 * Saca todos los textos que ve la gente: web, servidor, app, catálogos y landing.
 *
 *   php pruebas/mapa-textos.php docs/textos/mapa-textos.csv [raíz]
 *
 * `raíz` permite medir otra copia del sistema, como la del respaldo, y comparar.
 * ⚠️ El CSV es generado: no se edita a mano. Lo que se cuida es el código.
 *
 * Los JS y TSX los lee `mapa-textos-js.mjs` con el compilador de TypeScript, para
 * saber en qué propiedad o llamada está cada cadena en vez de adivinarlo.
 */

$raiz = rtrim($argv[2] ?? dirname(__DIR__), '/');
$salida = $argv[1] ?? 'php://stdout';
$filas = [];

const COMODIN = "\u{E000}";

function apunta(array &$filas, string $superficie, string $archivo, int $linea, string $tipo, string $texto): void
{
    $texto = trim(preg_replace('/\s+/u', ' ', str_replace(COMODIN, '{…}', $texto)) ?? '');
    if (!esVisible($texto)) return;
    $filas[] = [$superficie, $archivo, $linea, $tipo, cuentaPalabras($texto), $texto];
}

function cuentaPalabras(string $t): int
{
    return count(preg_split('/\s+/u', trim($t)) ?: []);
}

function esVisible(string $t): bool
{
    $letras = str_replace('{…}', '', $t);
    if (mb_strlen($letras) < 2 || !preg_match('/\p{L}{2}/u', $letras)) return false;
    // Clases, iconos, rutas, claves, formatos y nombres de código.
    if (preg_match('/^(bi|fa|btn|col|row|mt|mb|ms|me|mx|my|pt|pb|px|py|d|text|bg|table|form|fw|data|aria|lb|app|is|has|modal|nav|input|flex|align|justify|border|small)-/', $t)) return false;
    if (preg_match('/^(https?:|mailto:|tel:|\/|\.|#|\$|<|&|%[sd]$)/', $t)) return false;
    if (preg_match('/^[a-z0-9_\-.\/:*]+$/', $t)) return false;
    if (preg_match('/^[a-z0-9_\-]+( [a-z0-9_\-]+)+$/', $t) && str_contains($t, '-') && !preg_match('/[áéíóúñ]/u', $t)) return false;
    if (preg_match('/\b(SELECT|INSERT|UPDATE|DELETE|WHERE|JOIN|ORDER BY|GROUP BY|VALUES|BEGIN|COMMIT|ROLLBACK|PRAGMA|CREATE TABLE|DROP TABLE)\b/', $t)) return false;
    if (preg_match('/^(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS|UTF-8|ASC|DESC|NULL|JSON|HTML|CSV|PDF|PNG|JPEG|SHA-256|HS256|sha256|Bearer|Authorization|Content-[A-Za-z]+|X-[A-Za-z-]+|Cache-Control|America\/.*)$/', $t)) return false;
    if (preg_match('/^[A-Z][A-Za-z]+(\\\\[A-Za-z]+)+/', $t)) return false;
    if (preg_match('/^(Y-m-d|H:i|d\/m|d-m|D, d)/', $t)) return false;
    // Trozos de SQL, de PDF y de cabeceras HTTP.
    if (preg_match('/( = \?|=\?|\bAND\b|\bIS (NOT )?NULL\b|\bCOALESCE\b|\bCONCAT\(|\bCASE\b|\bCURDATE\(|DAY\)\)|\bNOT IN\b| Tf | Tj |\/Contents|^> ?stream|\{ ?margin|^(Accept|User-Agent|Content|Referrer|Pragma|ETag|Lax|DENY|Orientation|Windows-1252|ASCII\/\/))/', $t)) return false;
    if (preg_match('/^(first day of|[A-Z0-9]{20,}$|BASE-RESPALDO|cli-server)/', $t)) return false;
    if (preg_match('/^[A-Z_]{3,}$/', $t) && str_contains($t, '_')) return false;
    if (preg_match('/^[a-z]+[A-Z][A-Za-z]*$/', $t)) return false;
    return true;
}

/** Qué clase de texto es cada argumento de las piezas de `vistas/partes/piezas.php`. */
function tipoDeArgumento(string $f, int $i): ?string
{
    $mapa = [
        'pb_modulo' => [1 => 'titulo', 2 => 'subtitulo'],
        'pb_encabezado' => [0 => 'titulo', 1 => 'titulo', 2 => 'ayuda'],
        'pb_seccion' => [1 => 'titulo', 2 => 'ayuda'],
        'pb_campo' => [1 => 'campo'],
        'pb_aviso' => [1 => 'aviso'],
        'pb_vacio' => [0 => 'vacio', 1 => 'vacio'],
        'pb_fila_vacia' => [1 => 'vacio'],
        'pb_boton' => [1 => 'boton'],
        'pb_accion' => [1 => 'boton'],
        'pb_abre_modal' => [],
        'pb_modal' => [1 => 'titulo'],
        'pb_modal_fin' => [0 => 'boton'],
        'pb_resumen' => [0 => 'texto'],
        'pb_tabla' => [0 => 'lector'],
        'pb_tabla_captura' => [0 => 'lector'],
        'pb_insignia' => [1 => 'insignia'],
        'pb_estatus' => [1 => 'insignia', 2 => 'insignia'],
        'pb_qr' => [1 => 'lector'],
    ];
    return $mapa[$f][$i] ?? null;
}

/** Según su clave en un arreglo: `'ayuda' => '…'`. Null si la clave nunca es visible. */
function tipoDeClave(string $clave): ?string
{
    return match (true) {
        in_array($clave, ['ayuda', 'descripcion', 'detalle', 'explica', 'subtitulo', 'nota'], true) => 'ayuda',
        in_array($clave, ['placeholder', 'etiqueta', 'label', 'etiquetaSi', 'etiquetaNo'], true) => 'campo',
        in_array($clave, ['titulo', 'title', 'confirmaTitulo', 'data-confirma-titulo'], true) => 'titulo',
        in_array($clave, ['texto', 'mensaje', 'message', 'cuerpo', 'motivo', 'aviso'], true) => 'mensaje',
        in_array($clave, ['aria-label'], true) => 'lector',
        in_array($clave, ['nombre', 'columna', 'encabezado', 'vacio', 'valor', 'opciones', 'tipo_texto'], true) => 'texto',
        str_starts_with($clave, 'data-confirma') || str_starts_with($clave, 'data-pb-confirma') => 'confirmacion',
        in_array($clave, ['clase', 'class', 'icono', 'tipo', 'type', 'name', 'id', 'for', 'href', 'ruta', 'accept', 'pattern', 'autocomplete',
            'inputmode', 'min', 'max', 'step', 'estilo', 'tono', 'modo', 'clave', 'orden', 'formato', 'target', 'rel', 'style', 'value', 'capture'], true) => null,
        default => 'texto',
    };
}

/** Las cadenas de una vista, un controlador o un servicio. */
function dePhp(array &$filas, string $raiz, string $relativo, bool $esVista): void
{
    $tokens = token_get_all((string) file_get_contents($raiz . '/' . $relativo));
    $superficie = $esVista ? 'web' : 'servidor';
    $html = '';
    $marcas = [];
    $marcos = [];
    $anterior = '';
    $n = count($tokens);

    for ($k = 0; $k < $n; $k++) {
        $t = $tokens[$k];
        if (!is_array($t)) {
            if ($t === '(' || $t === '[') { $marcos[] = ['f' => $t === '(' ? $anterior : '', 'i' => 0, 'clave' => null]; }
            elseif ($t === ')' || $t === ']') { array_pop($marcos); }
            elseif ($t === ',' && $marcos) { $marcos[count($marcos) - 1]['i']++; $marcos[count($marcos) - 1]['clave'] = null; }
            $anterior = '';
            continue;
        }
        [$id, $texto, $linea] = $t;
        if ($id === T_INLINE_HTML) {
            $marcas[] = [strlen($html), $linea];
            $html .= $texto;
            continue;
        }
        if ($id === T_OPEN_TAG || $id === T_OPEN_TAG_WITH_ECHO) {
            $html .= COMODIN;
            continue;
        }
        if (in_array($id, [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT, T_CLOSE_TAG], true)) continue;
        if ($id === T_ATTRIBUTE) { $marcos[] = ['f' => '#', 'i' => 0, 'clave' => null]; continue; }
        if ($id === T_STRING || $id === T_NAME_QUALIFIED || $id === T_NAME_FULLY_QUALIFIED) {
            $previo = $k >= 2 && is_array($tokens[$k - 1]) && $tokens[$k - 1][0] === T_DOUBLE_COLON ? (is_array($tokens[$k - 2]) ? $tokens[$k - 2][1] : '') : '';
            $anterior = $previo !== '' ? $previo . '::' . $texto : $texto;
            continue;
        }
        if ($id === T_DOUBLE_COLON || $id === T_OBJECT_OPERATOR || $id === T_NULLSAFE_OBJECT_OPERATOR) continue;
        if ($id !== T_CONSTANT_ENCAPSED_STRING && $id !== T_ENCAPSED_AND_WHITESPACE) { $anterior = ''; continue; }
        $anterior = '';

        $valor = $id === T_CONSTANT_ENCAPSED_STRING ? stripcslashes(substr($texto, 1, -1)) : $texto;

        // Una clave de arreglo no se ve: decide cómo se trata su valor.
        $j = $k + 1;
        while ($j < $n && is_array($tokens[$j]) && $tokens[$j][0] === T_WHITESPACE) $j++;
        if ($j < $n && is_array($tokens[$j]) && $tokens[$j][0] === T_DOUBLE_ARROW) {
            if ($marcos) $marcos[count($marcos) - 1]['clave'] = $valor;
            continue;
        }

        // Comparaciones y usos internos, nunca un texto.
        $a = $k - 1;
        while ($a >= 0 && is_array($tokens[$a]) && $tokens[$a][0] === T_WHITESPACE) $a--;
        if ($a >= 0 && is_array($tokens[$a]) && in_array($tokens[$a][0], [T_IS_EQUAL, T_IS_IDENTICAL, T_IS_NOT_EQUAL, T_IS_NOT_IDENTICAL, T_CASE], true)) continue;
        if ($j < $n && is_array($tokens[$j]) && in_array($tokens[$j][0], [T_IS_EQUAL, T_IS_IDENTICAL, T_IS_NOT_EQUAL, T_IS_NOT_IDENTICAL], true)) continue;

        $marco = $marcos ? $marcos[count($marcos) - 1] : ['f' => '', 'i' => 0, 'clave' => null];
        $funcion = '';
        $indice = 0;
        foreach (array_reverse($marcos) as $m) {
            if ($m['f'] !== '') { $funcion = $m['f']; $indice = $m['i']; break; }
        }
        if ($funcion === '#') continue;

        $tipo = clasifica($marcos, $funcion, $indice, $marco['clave'] ?? null, $esVista);
        if ($tipo === null) continue;
        if (!$esVista && $tipo === 'dato' && !pareceFrase($valor)) continue;
        if ($esVista && $tipo === 'dato' && !pareceFrase($valor)) continue;
        if ($tipo === 'dato') $tipo = 'texto';

        if (preg_match('/[<>]|="/', $valor)) {
            foreach (deFragmento($valor) as [$sub, $tipoHtml]) apunta($filas, $superficie, $relativo, $linea, $tipoHtml, $sub);
            continue;
        }
        apunta($filas, $superficie, $relativo, $linea, $tipo, $valor);
    }

    if ($esVista && trim(str_replace(COMODIN, '', $html)) !== '') {
        deHtml($filas, $superficie, $relativo, $html, $marcas);
    }
}

function clasifica(array $marcos, string $funcion, int $indice, ?string $clave, bool $esVista): ?string
{
    // ¿Va dentro de un mensaje al usuario, aunque sea por un sprintf?
    foreach (array_reverse($marcos) as $m) {
        $f = $m['f'];
        if (str_starts_with($f, 'Errores::') || $f === 'ErrorHttp' || $f === 'ErrorNegocio') {
            if ($m['clave'] !== null && !in_array($m['clave'], ['campo', 'campos'], true)) return 'error';
            return 'error';
        }
        if ($f === 'hecho' || $f === 'aviso' || $f === 'conAviso') return 'mensaje';
    }
    // Internos: el manejador los cambia por un mensaje genérico o no se muestran.
    if (preg_match('/(Exception|Error|Registro::|error_log|trigger_error|header|preg_|define|ini_set|date|DateTime|strtotime|json_|array_key|in_array|str_|strpos|explode|implode|ruta|redireccion|pinta|parcial|fetch|ejecuta|consulta|valor|fila|filas|sql|query|prepare|config|getenv|registra|hash|substr|setcookie|class_exists|function_exists|bitacora|anota|Bitacora|auditoria|escribe)/i', $funcion) && !str_starts_with($funcion, 'pb_')) return null;
    if ($clave !== null) {
        $t = tipoDeClave($clave);
        if ($t === null) return null;
        return $t === 'texto' ? 'dato' : $t;
    }
    if (str_starts_with($funcion, 'pb_')) {
        $t = tipoDeArgumento($funcion, $indice);
        if ($t !== null) return $t;
        if (in_array($funcion, ['pb_ico', 'pb_escapa', 'pb_tono', 'pb_legible', 'pb_llave', 'pb_dinero', 'pb_fecha', 'pb_cantidad'], true)) return null;
    }
    return 'dato';
}

/** Lo que se ve de una cadena sin etiquetas: una frase, no un nombre de código. */
function pareceFrase(string $t): bool
{
    if (preg_match('/[<>]/', $t)) return true;
    $t = trim($t);
    if (preg_match('/^[\p{Lu}¿¡]/u', $t) || preg_match('/[áéíóúñÁÉÍÓÚÑ]/u', $t)) return true;
    return (bool) preg_match('/^\p{Ll}+ \p{Ll}+/u', $t) && !str_contains($t, '_');
}

/** Una cadena de PHP con HTML, entero o a medias: `'<a title="' . $x . '">Abrir</a>'`. */
function deFragmento(string $h): array
{
    $hay = [];
    if (preg_match_all('/\b(placeholder|title|aria-label|alt|data-pb-confirma[a-z-]*|data-confirma[a-z-]*)="([^"]+)"/u', $h, $m, PREG_SET_ORDER)) {
        foreach ($m as $a) $hay[] = [$a[2], tipoDeAtributo($a[1])];
    }
    // El resto de una etiqueta abierta en otra cadena, y el inicio de la que sigue.
    $h = preg_replace('/^[^<]*?>/su', '', $h, 1) ?? $h;
    $h = preg_replace('/<[^>]*$/su', '', $h) ?? $h;
    foreach (preg_split('/<[^>]*>/u', $h) ?: [] as $trozo) {
        $trozo = trim(html_entity_decode($trozo, ENT_QUOTES, 'UTF-8'));
        if ($trozo !== '' && !str_contains($trozo, '="')) $hay[] = [$trozo, 'texto'];
    }
    return $hay;
}

function tipoDeAtributo(string $a): string
{
    return match (true) {
        $a === 'placeholder' => 'pista',
        $a === 'title' => 'pista',
        $a === 'aria-label', $a === 'alt' => 'lector',
        default => 'confirmacion',
    };
}

/** El HTML de la vista, cosido con un comodín donde había PHP, para no partir atributos. */
function deHtml(array &$filas, string $superficie, string $relativo, string $html, array $marcas): void
{
    $lineaDe = static function (int $pos) use ($html, $marcas): int {
        $base = 1;
        $desde = 0;
        foreach ($marcas as [$o, $l]) {
            if ($o > $pos) break;
            $base = $l;
            $desde = $o;
        }
        return $base + substr_count(substr($html, $desde, $pos - $desde), "\n");
    };
    $limpio = preg_replace_callback('#<(script|style)\b.*?</\1>#su', static fn ($m) => str_repeat(' ', strlen($m[0])), $html) ?? $html;
    $limpio = preg_replace_callback('#<!--.*?-->#su', static fn ($m) => str_repeat(' ', strlen($m[0])), $limpio) ?? $limpio;

    if (!preg_match_all('/<[a-zA-Z\/!][^>]*>|[^<]+/su', $limpio, $m, PREG_OFFSET_CAPTURE)) return;
    $ultima = '';
    $esBoton = false;
    foreach ($m[0] as [$trozo, $pos]) {
        if ($trozo[0] === '<') {
            if (preg_match_all('/\b(placeholder|title|aria-label|alt|data-pb-confirma[a-z-]*|data-confirma[a-z-]*)="([^"]*)"/u', $trozo, $a, PREG_SET_ORDER)) {
                foreach ($a as $x) apunta($filas, $superficie, $relativo, $lineaDe($pos), tipoDeAtributo($x[1]), $x[2]);
            }
            if (preg_match('/^<([a-zA-Z0-9]+)/', $trozo, $e)) {
                $ultima = strtolower($e[1]);
                $esBoton = $ultima === 'button' || ($ultima === 'a' && str_contains($trozo, 'btn'));
                if ($ultima === 'small' || str_contains($trozo, 'text-muted') || str_contains($trozo, 'form-text')) $ultima = 'nota';
            }
            continue;
        }
        $t = trim(html_entity_decode($trozo, ENT_QUOTES, 'UTF-8'));
        if ($t === '' || str_contains($t, '<?')) continue;
        $tipo = match (true) {
            $esBoton => 'boton',
            $ultima === 'th' => 'columna',
            $ultima === 'label' || $ultima === 'legend' => 'campo',
            $ultima === 'option' => 'opcion',
            in_array($ultima, ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'title', 'caption'], true) => 'titulo',
            $ultima === 'nota' => 'nota',
            default => 'texto',
        };
        apunta($filas, $superficie, $relativo, $lineaDe($pos), $tipo, $t);
    }
}

/** Landing: HTML puro. El aviso de privacidad se mide, pero no se toca (revisión legal). */
function deLanding(array &$filas, string $raiz, string $relativo): void
{
    $html = (string) file_get_contents($raiz . '/' . $relativo);
    deHtml($filas, 'landing', $relativo, $html, [[0, 1]]);
}

/** Lo sembrado en la base que acaba en pantalla: catálogos, puestos, motivos, parámetros. */
function deEsquema(array &$filas, string $raiz, string $relativo): void
{
    $sql = (string) file_get_contents($raiz . '/' . $relativo);
    $visibles = '/^(puesto|permiso|parametro|estatus|cat_[a-z_]+|catalogo[a-z_]*|tipo_[a-z_]+|motivo[a-z_]*|concepto[a-z_]*|canal[a-z_]*|forma_pago|condicion[a-z_]*|categoria[a-z_]*|grupo[a-z_]*|unidad[a-z_]*|presentacion[a-z_]*|impuesto[a-z_]*|modulo[a-z_]*)$/';
    if (!preg_match_all('/INSERT(?:\s+IGNORE)?\s+INTO\s+`?([a-z_]+)`?\s*\(([^)]*)\)\s*VALUES\s*(.*?);\s*$/msi', $sql, $m, PREG_SET_ORDER | PREG_OFFSET_CAPTURE)) return;
    foreach ($m as $i) {
        $tabla = strtolower($i[1][0]);
        if (!preg_match($visibles, $tabla)) continue;
        $columnas = array_map(static fn ($c) => trim($c, " `\n\r\t"), explode(',', $i[2][0]));
        $linea = substr_count(substr($sql, 0, $i[0][1]), "\n") + 1;
        if (!preg_match_all("/\(((?:[^()']|'(?:[^']|'')*'|\([^()]*\))*)\)/s", $i[3][0], $tuplas)) continue;
        foreach ($tuplas[1] as $tupla) {
            if (!preg_match_all("/'((?:[^']|'')*)'|[^,\s][^,]*/s", $tupla, $v, PREG_SET_ORDER)) continue;
            foreach ($v as $n => $val) {
                if (!isset($val[1]) || $val[1] === '') continue;
                $col = $columnas[$n] ?? '';
                if (!in_array($col, ['nombre', 'descripcion', 'etiqueta', 'titulo', 'texto', 'motivo'], true)) continue;
                apunta($filas, 'catalogos', $relativo, $linea, $col === 'descripcion' ? 'ayuda' : 'opcion', str_replace("''", "'", $val[1]));
            }
        }
    }
}

$recorre = static function (string $carpeta, string $patron) use ($raiz): array {
    if (!is_dir($raiz . '/' . $carpeta)) return [];
    $hay = [];
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($raiz . '/' . $carpeta, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        $r = substr($f->getPathname(), strlen($raiz) + 1);
        if (str_contains($r, '/._') || str_starts_with(basename($r), '._')) continue;
        if (preg_match($patron, $r) && !str_contains($r, '/pruebas/') && !str_contains($r, '/vendor/') && !str_contains($r, '/historico-v1/')) $hay[] = $r;
    }
    sort($hay);
    return $hay;
};

foreach ($recorre('vistas', '/\.php$/') as $r) dePhp($filas, $raiz, $r, true);
foreach (['controladores', 'servicios', 'modelos', 'nucleo', 'dominio'] as $c) foreach ($recorre($c, '/\.php$/') as $r) dePhp($filas, $raiz, $r, false);
foreach ($recorre('esquema', '/\.sql$/') as $r) deEsquema($filas, $raiz, $r);
// Un guion aplicado no se modifica: lo que se ve de un catálogo es su última corrección.
$corregidos = [];
foreach ($recorre('esquema', '/\.sql$/') as $r) {
    $sql = (string) file_get_contents($raiz . '/' . $r);
    if (preg_match_all("/UPDATE\s+(?:permiso|parametro)\s+SET\s+descripcion\s*=\s*'((?:[^']|'')*)'\s+WHERE\s+descripcion\s*=\s*'((?:[^']|'')*)'/i", $sql, $m, PREG_SET_ORDER)) {
        foreach ($m as $u) $corregidos[str_replace("''", "'", $u[2])] = str_replace("''", "'", $u[1]);
    }
}
foreach ($filas as &$f) {
    if ($f[0] === 'catalogos' && isset($corregidos[$f[5]])) {
        $f[5] = $corregidos[$f[5]];
        $f[4] = cuentaPalabras($f[5]);
    }
}
unset($f);
foreach ($recorre('landing', '/\.html$/') as $r) deLanding($filas, $raiz, $r);

// Los JS y TSX. Se cuentan aparte porque los lee Node con el compilador de TypeScript.
$js = dirname(__DIR__) . '/pruebas/mapa-textos-js.mjs';
$tuberia = popen('node ' . escapeshellarg($js) . ' ' . escapeshellarg($raiz), 'r');
if ($tuberia === false) { fprintf(STDERR, "No se pudo correr %s\n", $js); exit(1); }
while (($l = fgets($tuberia)) !== false) {
    $o = json_decode($l, true);
    if (is_array($o)) apunta($filas, $o[0], $o[1], (int) $o[2], $o[3], $o[4]);
}
if (pclose($tuberia) !== 0) { fprintf(STDERR, "Falló %s\n", $js); exit(1); }

$vistos = [];
$unicas = [];
foreach ($filas as $f) {
    $k = $f[1] . '|' . $f[2] . '|' . $f[5];
    if (isset($vistos[$k])) continue;
    $vistos[$k] = true;
    $unicas[] = $f;
}

$h = fopen($salida, 'w');
fputcsv($h, ['superficie', 'archivo', 'linea', 'tipo', 'palabras', 'texto'], ',', '"', '');
foreach ($unicas as $f) fputcsv($h, $f, ',', '"', '');
fclose($h);
fprintf(STDERR, "%d textos\n", count($unicas));
