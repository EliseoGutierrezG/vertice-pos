<?php
declare(strict_types=1);

use Nucleo\Aplicacion;
use Nucleo\BaseDatos;
use Nucleo\Contenedor;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Pruebas\Afirma;
use Pruebas\Semilla;
use Controladores\Web\Restaurante;
use Servicios\HorariosRestaurante;
use Servicios\MenuRestaurante;
use Servicios\Reservaciones;

/**
 * Corre la prueba dentro de una transacción que se deshace al final: el sitio
 * público lee sucursales publicadas y no debe quedar ninguna de prueba.
 */
$conDatos = static function (callable $prueba): void {
    $contenedor = (new Aplicacion(dirname(__DIR__, 2)))->contenedor();
    $bd = $contenedor->obtiene(BaseDatos::class);
    $revertir = new RuntimeException('Retirar los datos de la prueba');
    try {
        $bd->transaccion(static function () use ($contenedor, $bd, $prueba, $revertir): void {
            $sufijo = strtoupper(bin2hex(random_bytes(3)));
            $sucursal = $bd->inserta("INSERT INTO sucursal (nombre, clave, telefono, cp) VALUES (?, ?, '6690000000', '82000')",
                ['Sitio ' . $sufijo, 'S' . $sufijo]);
            $prueba($contenedor, $bd, $sucursal, 'S' . $sufijo);
            throw $revertir;
        });
    } catch (RuntimeException $error) {
        if ($error !== $revertir) {
            throw $error;
        }
    }
};

return [
    'la ficha de reservación conserva la intención de confirmar y permite cancelar después' => static function () use ($conDatos): void {
        $conDatos(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, string $clave): void {
            $contenedor->obtiene(Identidad::class)->establece(Semilla::usuario($bd, 'reserva.' . $clave, 'administrador'));
            $area = $bd->inserta('INSERT INTO area (id_sucursal,nombre) VALUES (?, ?)', [$sucursal, 'Prueba de reserva']);
            $mesa = $bd->inserta("INSERT INTO mesa (id_sucursal,id_area,numero,capacidad) VALUES (?, ?, 'R1', 2)", [$sucursal, $area]);
            $reservaciones = $contenedor->obtiene(Reservaciones::class);
            $folio = $reservaciones->manual($sucursal, ['cliente' => 'Prueba de confirmación', 'telefono' => '0000000000',
                'personas' => 2, 'desde' => (new DateTimeImmutable('+2 days'))->format('Y-m-d') . 'T15:00']);
            $id = (int) $bd->valor('SELECT id FROM reservacion WHERE folio = ? AND id_sucursal = ?', [$folio, $sucursal]);

            $globales = [$_GET, $_POST, $_SERVER];
            try {
                $_GET = ['sucursal' => $sucursal];
                $_POST = [];
                $_SERVER['REQUEST_METHOD'] = 'GET';
                $_SERVER['REQUEST_URI'] = '/reservaciones/' . $id;
                $_SERVER['HTTP_ACCEPT'] = 'application/json';
                $peticion = Peticion::desdeGlobales()->conParametros(['id' => (string) $id]);
                $respuesta = $contenedor->obtiene(Restaurante::class)->verReserva($peticion);
                $datos = json_decode($respuesta->cuerpo(), true, flags: JSON_THROW_ON_ERROR)['datos'];
            } finally {
                [$_GET, $_POST, $_SERVER] = $globales;
            }

            Afirma::cierto(str_contains($datos['html'], 'Solicitada'), 'Ver conserva el estado actual en la ficha');
            // El llenado del modal asigna cada dato que coincide con un campo.
            // La transición es fija; el estado actual no debe convertirse en su destino.
            $forma = ['estado' => 'confirmada', 'id_mesa' => $mesa];
            foreach ($datos['registro'] as $campo => $valor) {
                if (array_key_exists($campo, $forma)) {
                    $forma[$campo] = $valor;
                }
            }
            $forma['id_mesa'] = $mesa; // La persona elige una mesa después de cargar la ficha.
            Afirma::igual('confirmada', $forma['estado'], 'la ficha no sobrescribe el destino de la transición');
            $reservaciones->cambia($sucursal, $id, $forma);
            Afirma::igual('confirmada', $reservaciones->detalle($sucursal, $id)['estado']);
            $reservaciones->cambia($sucursal, $id, ['estado' => 'cancelada']);
            Afirma::igual('cancelada', $reservaciones->detalle($sucursal, $id)['estado']);
        });
    },

    'el cierre se calcula también cuando el servicio sigue después de medianoche' => static function (): void {
        $horarios = [['dia' => 1, 'abre' => '18:00', 'cierra' => '02:00']];
        $lunes = new DateTimeImmutable('2026-11-16 20:00:00');
        $madrugada = new DateTimeImmutable('2026-11-17 01:00:00');
        $cierre = new DateTimeImmutable('2026-11-17 02:00:00');
        Afirma::igual('2026-11-17 02:00', HorariosRestaurante::cierre($horarios, $lunes)?->format('Y-m-d H:i'));
        Afirma::igual('02:00', HorariosRestaurante::cierre($horarios, $madrugada)?->format('H:i'));
        Afirma::igual(null, HorariosRestaurante::cierre($horarios, $cierre));
    },

    'las sucursales públicas traen teléfono, horario por día y si están abiertas' => static function () use ($conDatos): void {
        $conDatos(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, string $clave): void {
            $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Sin clave ' . $clave]);
            for ($dia = 1; $dia <= 7; $dia++) {
                $bd->ejecuta("INSERT INTO sucursal_horario (id_sucursal, dia, abre, cierra) VALUES (?, ?, '00:00', '23:59')", [$sucursal, $dia]);
            }
            $publicas = array_column($contenedor->obtiene(Reservaciones::class)->sucursalesPublicas(), null, 'clave');
            Afirma::cierto(isset($publicas[$clave]), 'la sucursal con clave se publica');
            Afirma::cierto(!in_array('Sin clave ' . $clave, array_column($publicas, 'nombre'), true), 'sin clave no se publica');
            $publica = $publicas[$clave];
            Afirma::igual('6690000000', $publica['telefono']);
            Afirma::igual('82000', $publica['cp']);
            Afirma::igual(7, count($publica['horarios']), 'los siete días');
            Afirma::igual(['dia' => 1, 'abre' => '00:00', 'cierra' => '23:59'],
                ['dia' => (int) $publica['horarios'][0]['dia'], 'abre' => $publica['horarios'][0]['abre'], 'cierra' => $publica['horarios'][0]['cierra']]);
            Afirma::igual(true, $publica['abierta'], 'abierta todo el día');
        });
    },

    'la solicitud pública devuelve un folio y guarda la nota' => static function () use ($conDatos): void {
        $conDatos(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, string $clave): void {
            $reservaciones = $contenedor->obtiene(Reservaciones::class);
            $datos = ['sucursal' => $clave, 'cliente' => 'Ana Prueba', 'telefono' => '669 123 4567', 'personas' => '4',
                'desde' => (new DateTimeImmutable('+2 days'))->format('Y-m-d') . 'T14:00', 'nota' => 'Terraza'];
            $ip = '10.' . random_int(0, 255) . '.' . random_int(0, 255) . '.' . random_int(1, 254);
            $folio = $reservaciones->solicita($datos, $ip);
            Afirma::cierto(is_string($folio) && preg_match('/^RES-\d{6}$/', $folio) === 1, 'folio con prefijo y seis dígitos');
            $fila = $bd->fila('SELECT nota, estado, personas FROM reservacion WHERE folio = ? AND id_sucursal = ?', [$folio, $sucursal]);
            Afirma::igual(['nota' => 'Terraza', 'estado' => 'solicitada', 'personas' => 4],
                ['nota' => $fila['nota'], 'estado' => $fila['estado'], 'personas' => (int) $fila['personas']]);

            $antes = (int) $bd->valor('SELECT COUNT(*) FROM reservacion WHERE id_sucursal = ?', [$sucursal]);
            Afirma::igual(null, $reservaciones->solicita($datos + ['sitio_web' => 'https://spam.example'], $ip), 'el señuelo no responde folio');
            Afirma::igual($antes, (int) $bd->valor('SELECT COUNT(*) FROM reservacion WHERE id_sucursal = ?', [$sucursal]), 'el señuelo no guarda');
        });
    },

    'una solicitud con fecha pasada se rechaza en el campo de la fecha' => static function () use ($conDatos): void {
        $conDatos(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, string $clave): void {
            $campos = [];
            try {
                $contenedor->obtiene(Reservaciones::class)->solicita(['sucursal' => $clave, 'cliente' => 'Ana', 'telefono' => '6691234567',
                    'personas' => '2', 'desde' => '2020-01-01T14:00'], '10.0.0.' . random_int(1, 254));
            } catch (ErrorHttp $error) {
                $campos = $error->campos();
            }
            Afirma::cierto(isset($campos['desde']), 'el error señala la fecha');
        });
    },

    'el menú QR solo nombra la mesa si es de esa sucursal y sigue activa' => static function () use ($conDatos): void {
        $conDatos(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, string $clave): void {
            $area = $bd->inserta('INSERT INTO area (id_sucursal, nombre) VALUES (?, ?)', [$sucursal, 'Terraza']);
            $mesa = $bd->inserta("INSERT INTO mesa (id_sucursal, id_area, numero, capacidad) VALUES (?, ?, 'T5', 4)", [$sucursal, $area]);
            $baja = $bd->inserta("INSERT INTO mesa (id_sucursal, id_area, numero, capacidad, activa) VALUES (?, ?, 'T6', 4, 0)", [$sucursal, $area]);
            $otra = $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Otra ' . $clave]);
            $menu = $contenedor->obtiene(MenuRestaurante::class);
            Afirma::igual('T5', $menu->mesaPublica($sucursal, $mesa));
            Afirma::igual(null, $menu->mesaPublica($sucursal, $baja), 'una mesa dada de baja');
            Afirma::igual(null, $menu->mesaPublica($otra, $mesa), 'una mesa de otra sucursal');
            Afirma::igual(null, $menu->mesaPublica($sucursal, 0), 'sin mesa');
        });
    },

    'el menú público lista solo platillos con precio en la sucursal y marca las especialidades' => static function () use ($conDatos): void {
        $conDatos(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, string $clave): void {
            $categoria = $bd->inserta('INSERT INTO categoria_menu (nombre) VALUES (?)', ['Sitio ' . $clave]);
            $conPrecio = $bd->inserta("INSERT INTO platillo (id_categoria, nombre, preparacion, especialidad) VALUES (?, 'Aguachile', 'fria', 1)", [$categoria]);
            $bd->inserta("INSERT INTO platillo (id_categoria, nombre, preparacion) VALUES (?, 'Sin precio', 'fria')", [$categoria]);
            $bd->ejecuta('INSERT INTO platillo_sucursal (id_platillo, id_sucursal, precio) VALUES (?, ?, ?)', [$conPrecio, $sucursal, '245.00']);
            $menu = $contenedor->obtiene(MenuRestaurante::class)->publica($clave);
            $propios = array_values(array_filter($menu['platillos'], static fn (array $p): bool => $p['categoria'] === 'Sitio ' . $clave));
            Afirma::igual(['Aguachile'], array_column($propios, 'nombre'));
            Afirma::igual('245.00', $propios[0]['precio']);
            Afirma::igual(1, (int) $propios[0]['especialidad']);
        });
    },
];
