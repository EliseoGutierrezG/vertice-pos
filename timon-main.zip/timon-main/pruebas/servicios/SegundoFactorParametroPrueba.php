<?php
declare(strict_types=1);

use Dominio\Totp;
use Modelos\Parametros;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Configuracion;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Registro;
use Nucleo\Seguridad\Cifrador;
use Pruebas\Afirma;
use Servicios\SegundoFactor;

/**
 * El segundo factor se enciende y se apaga con `segundo_factor_web` (bitácora 98).
 *
 * Apagado deja de pedirse el código al entrar y nada más. Las autorizaciones
 * de caja y descuentos, que también lo piden, traen sus casos con la fase 7. Se prueba contra el catálogo de
 * verdad, como `SesionQuietaPrueba`: un renglón con fecha de hoy gana al del
 * esquema, y al final la clave queda exactamente como estaba.
 */

$raiz = dirname(__DIR__, 2);
$bd   = new BaseDatos(Configuracion::baseDatos($raiz));
$ip   = '127.0.0.1';

$prefijo = 'sfparam.';
$limpia  = static function () use ($bd, $prefijo): void {
    Pruebas\Semilla::borraUsuarios($bd, $prefijo);
};
$limpia();
$supervisor = Pruebas\Semilla::usuario($bd, $prefijo . 'gerente', 'gerente', 'contraseña-super-x');
$dueno      = Pruebas\Semilla::usuario($bd, $prefijo . 'dueno', 'administrador', 'contraseña-dueno-x');

$bitacora = new Bitacora($bd, new Registro(sys_get_temp_dir() . '/app-totp-pruebas', false));
$cifrador = new Cifrador((string) Configuracion::seguridad($raiz)['llave_totp']);
$totp     = new Totp();

const CLAVE_SF = 'segundo_factor_web';

$renglones = $bd->filas('SELECT clave, valor, descripcion, vigente_desde, vigente_hasta FROM parametro WHERE clave = ?', [CLAVE_SF]);
$restaura  = static function () use ($bd, $renglones): void {
    $bd->ejecuta('DELETE FROM parametro WHERE clave = ?', [CLAVE_SF]);
    foreach ($renglones as $r) {
        $bd->ejecuta(
            'INSERT INTO parametro (clave, valor, descripcion, vigente_desde, vigente_hasta) VALUES (?, ?, ?, ?, ?)',
            [$r['clave'], $r['valor'], $r['descripcion'], $r['vigente_desde'], $r['vigente_hasta']]
        );
    }
};
register_shutdown_function($restaura);

/** Un servicio nuevo por caso: `Parametros` recuerda lo leído. */
$conValor = static function (?string $valor) use ($bd, $cifrador, $totp, $bitacora, $restaura): SegundoFactor {
    $restaura();
    if ($valor === null) {
        $bd->ejecuta('DELETE FROM parametro WHERE clave = ?', [CLAVE_SF]);
    } else {
        $bd->ejecuta('DELETE FROM parametro WHERE clave = ? AND vigente_desde = CURDATE()', [CLAVE_SF]);
        $bd->ejecuta(
            'INSERT INTO parametro (clave, valor, descripcion, vigente_desde) VALUES (?, ?, ?, CURDATE())',
            [CLAVE_SF, $valor, 'Prueba del segundo factor apagado']
        );
    }

    return new SegundoFactor($bd, $cifrador, $totp, $bitacora, new Parametros($bd));
};

return [
    'encendido, los puestos sensibles lo necesitan al entrar' => function () use ($conValor, $dueno, $supervisor): void {
        $sf = $conValor('1');
        Afirma::cierto($sf->activo());
        Afirma::cierto($sf->requiere($dueno), 'administrador');
        Afirma::cierto($sf->requiere($supervisor), 'gerente');
    },

    'apagado, nadie lo necesita al entrar y no se puede iniciar un alta' => function () use ($conValor, $dueno, $ip): void {
        $sf = $conValor('0');
        Afirma::falso($sf->activo());
        Afirma::falso($sf->requiere($dueno));
        $error = Afirma::lanza(ErrorHttp::class, fn () => $sf->prepara($dueno, $ip));
        Afirma::contiene('apagado', $error->getMessage());
    },

    'si falta el renglón, se pide: el valor por omisión es el seguro' => function () use ($conValor, $dueno): void {
        $sf = $conValor(null);
        Afirma::cierto($sf->activo());
        Afirma::cierto($sf->requiere($dueno));
    },

    'apagarlo no toca las altas: al encenderlo, el código de antes sirve' => function () use ($bd, $conValor, $totp, $dueno, $ip): void {
        $sf = $conValor('1');
        $alta = $sf->prepara($dueno, $ip);
        $sf->confirma($dueno, $totp->codigo($alta['secreto'], time() - 30), $ip);
        $confirmado = $bd->valor('SELECT totp_confirmado_en FROM usuario WHERE id = ?', [$dueno]);

        $conValor('0');
        $sf = $conValor('1');
        Afirma::igual($confirmado, $bd->valor('SELECT totp_confirmado_en FROM usuario WHERE id = ?', [$dueno]));
        Afirma::cierto($sf->configurado($dueno));
        $sf->valida($dueno, $totp->codigo($alta['secreto']), 'prueba', $ip);
    },

    'al terminar, la clave queda como estaba' => function () use ($bd, $restaura, $renglones, $limpia): void {
        $restaura();
        Afirma::igual(
            count($renglones),
            (int) $bd->valor('SELECT COUNT(*) FROM parametro WHERE clave = ?', [CLAVE_SF])
        );
        $limpia();
    },

    'el esquema lo deja encendido' => function () use ($bd): void {
        Afirma::igual('1', (string) $bd->valor(
            "SELECT valor FROM parametro WHERE clave = ? AND vigente_desde = '2026-01-01'",
            [CLAVE_SF]
        ));
    },
];
