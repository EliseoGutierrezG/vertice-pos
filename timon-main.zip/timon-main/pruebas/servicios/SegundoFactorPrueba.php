<?php
declare(strict_types=1);

use Dominio\Totp;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Configuracion;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Registro;
use Nucleo\Seguridad\Cifrador;
use Pruebas\Afirma;
use Servicios\SegundoFactor;

$raiz = dirname(__DIR__, 2);
$bd = new BaseDatos(Configuracion::baseDatos($raiz));
$prefijo = 'totp.';
$limpia = static fn () => Pruebas\Semilla::borraUsuarios($bd, $prefijo);
$limpia();
$usuario = Pruebas\Semilla::usuario($bd, $prefijo . 'sensible', 'administrador');
$actor = Pruebas\Semilla::usuario($bd, $prefijo . 'actor', 'administrador');
$bitacora = new Bitacora($bd, new Registro(sys_get_temp_dir() . '/app-totp-pruebas', false));
$totp = new Totp();
$servicio = new SegundoFactor(
    $bd,
    new Cifrador((string) Configuracion::seguridad($raiz)['llave_totp']),
    $totp,
    $bitacora,
    new Modelos\Parametros($bd)
);
$estado = [];

return [
    'el alta cifra el secreto y confirma con desfase menos uno' => function () use ($bd, $servicio, $totp, $usuario, &$estado): void {
        Afirma::cierto($servicio->requiere($usuario));
        $estado['alta'] = $servicio->prepara($usuario, '127.0.0.1');
        $sobre = (string) $bd->valor('SELECT totp_secreto_cifrado FROM usuario WHERE id=?', [$usuario]);
        Afirma::falso(str_contains($sobre, $estado['alta']['secreto']));
        $estado['recuperaciones'] = $servicio->confirma(
            $usuario, $totp->codigo($estado['alta']['secreto'], time() - 30), '127.0.0.1'
        );
        Afirma::igual(8, count($estado['recuperaciones']));
        Afirma::igual(8, (int) $bd->valor('SELECT COUNT(*) FROM totp_codigo_recuperacion WHERE id_usuario=?', [$usuario]));
        Afirma::falso(str_contains((string) $bd->valor('SELECT codigo_hash FROM totp_codigo_recuperacion WHERE id_usuario=? LIMIT 1', [$usuario]), $estado['recuperaciones'][0]));
    },
    'un TOTP entra una vez y su reuso se bloquea' => function () use ($servicio, $totp, $usuario, &$estado): void {
        $codigo = $totp->codigo($estado['alta']['secreto']);
        $servicio->valida($usuario, $codigo, 'prueba', '127.0.0.1');
        $error = Afirma::lanza(ErrorHttp::class, fn () => $servicio->valida($usuario, $codigo, 'prueba', '127.0.0.1'));
        Afirma::igual(422, $error->estado());
    },
    'un código de recuperación entra una vez y sólo existe como hash' => function () use ($servicio, $usuario, &$estado): void {
        $codigo = $estado['recuperaciones'][0];
        $servicio->valida($usuario, strtolower($codigo), 'recuperacion', '127.0.0.1');
        $error = Afirma::lanza(ErrorHttp::class, fn () => $servicio->valida($usuario, $codigo, 'recuperacion', '127.0.0.1'));
        Afirma::igual(422, $error->estado());
    },
    'restablecer revoca la versión de sesión, borra factores y queda auditado' => function () use ($bd, $servicio, $usuario, $actor, $limpia): void {
        $version = (int) $bd->valor('SELECT sesion_version FROM usuario WHERE id=?', [$usuario]);
        $servicio->restablece($usuario, $actor, '127.0.0.1');
        $fila = $bd->fila('SELECT sesion_version,totp_secreto_cifrado,totp_confirmado_en FROM usuario WHERE id=?', [$usuario]);
        Afirma::igual($version + 1, (int) $fila['sesion_version']);
        Afirma::igual(null, $fila['totp_secreto_cifrado']);
        Afirma::igual(0, (int) $bd->valor('SELECT COUNT(*) FROM totp_codigo_recuperacion WHERE id_usuario=?', [$usuario]));
        Afirma::igual(1, (int) $bd->valor("SELECT COUNT(*) FROM bitacora WHERE id_usuario=? AND modulo='segundo_factor' AND accion='restablece'", [$actor]));
        $limpia();
    },
];

