<?php
declare(strict_types=1);

use Nucleo\Aplicacion;
use Nucleo\BaseDatos;
use Nucleo\Identidad;
use Pruebas\Afirma;
use Pruebas\Semilla;
use Servicios\InventarioRestaurante;

return [
    'el consumo usa primero el lote próximo a vencer y registra solo lo que falta' => static function (): void {
        $contenedor = (new Aplicacion(dirname(__DIR__, 2)))->contenedor();
        $bd = $contenedor->obtiene(BaseDatos::class);
        $revertir = new RuntimeException('Retirar los datos de la prueba');
        try {
            $bd->transaccion(static function () use ($contenedor, $bd, $revertir): void {
                $sufijo = bin2hex(random_bytes(4));
                $usuario = Semilla::usuario($bd, 'consumo.' . $sufijo, 'administrador');
                $contenedor->obtiene(Identidad::class)->establece($usuario);
                $sucursal = $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Consumo ' . $sufijo]);
                $categoria = $bd->inserta('INSERT INTO categoria_menu (nombre) VALUES (?)', ['Consumo ' . $sufijo]);
                $platillo = $bd->inserta("INSERT INTO platillo (id_categoria,nombre,preparacion) VALUES (?, 'Platillo de prueba', 'fria')", [$categoria]);
                $insumo = $bd->inserta("INSERT INTO insumo (id_sucursal,nombre,unidad) VALUES (?, 'Atún', 'kg')", [$sucursal]);
                $bd->ejecuta('INSERT INTO receta_insumo (id_sucursal,id_platillo,id_insumo,cantidad) VALUES (?, ?, ?, ?)',
                    [$sucursal, $platillo, $insumo, '0.600']);
                $sinVence = $bd->inserta('INSERT INTO lote_insumo (id_insumo,saldo) VALUES (?, ?)', [$insumo, '0.200']);
                $vence = $bd->inserta('INSERT INTO lote_insumo (id_insumo,saldo,vence) VALUES (?, ?, DATE_ADD(CURDATE(), INTERVAL 1 DAY))',
                    [$insumo, '0.300']);
                $vencido = $bd->inserta('INSERT INTO lote_insumo (id_insumo,saldo,vence) VALUES (?, ?, DATE_SUB(CURDATE(), INTERVAL 1 DAY))',
                    [$insumo, '1.000']);
                $cuenta = $bd->inserta("INSERT INTO cuenta (id_sucursal,id_mesero,tipo) VALUES (?, ?, 'llevar')", [$sucursal, $usuario]);
                $bd->ejecuta("INSERT INTO cuenta_item (id_cuenta,id_platillo,platillo,preparacion,cantidad,precio,modificadores,estado)
                    VALUES (?, ?, 'Platillo de prueba', 'fria', 1, 10, '[]', 'enviado')", [$cuenta, $platillo]);
                $faltantes = $contenedor->obtiene(InventarioRestaurante::class)->consumeCuenta($sucursal, $cuenta);
                Afirma::igual([['insumo' => 'Atún', 'cantidad' => '0.100']], $faltantes, 'la falta real');
                $movimientos = $bd->filas('SELECT id_lote, cantidad FROM kardex_insumo WHERE id_cuenta = ? ORDER BY id', [$cuenta]);
                Afirma::igual([$vence, $sinVence], array_map('intval', array_column($movimientos, 'id_lote')), 'el orden por caducidad');
                Afirma::igual(['-0.300', '-0.200'], array_column($movimientos, 'cantidad'), 'el consumo');
                Afirma::igual('1.000', $bd->valor('SELECT saldo FROM lote_insumo WHERE id = ?', [$vencido]), 'se conserva lo vencido');
                throw $revertir;
            });
        } catch (RuntimeException $error) {
            if ($error !== $revertir) {
                throw $error;
            }
        }
    },
];
