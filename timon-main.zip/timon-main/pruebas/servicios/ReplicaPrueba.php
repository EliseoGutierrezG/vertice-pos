<?php
declare(strict_types=1);

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Nucleo\Instalacion;
use Nucleo\Registro;
use Pruebas\Afirma;
use Servicios\Instalaciones;
use Servicios\OperacionRestaurante;
use Servicios\Replica;

/**
 * La réplica vista desde el central, contra la base de pruebas: registrar la
 * computadora de una sucursal, la huella del catálogo y lo que acepta (y lo
 * que rechaza) al recibir la subida.
 *
 * El humo con dos instalaciones de verdad es `pruebas/humo-sucursal.sh`.
 * Todo lo sembrado cuelga de sucursales «Réplica …» y de usuarios `rep.`.
 */
$config = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd     = new BaseDatos($config);

$limpia = static function () use ($bd): void {
    $sucursales = array_map(
        static fn (array $f): int => (int) $f['id'],
        $bd->filas("SELECT id FROM sucursal WHERE nombre LIKE 'Réplica %'")
    );
    foreach ($sucursales as $id) {
        $bd->ejecuta('DELETE FROM gasto_sucursal WHERE id_sucursal = ?', [$id]);
        $bd->ejecuta('DELETE m FROM mesa m WHERE m.id_sucursal = ?', [$id]);
        $bd->ejecuta('DELETE FROM area WHERE id_sucursal = ?', [$id]);
        $bd->ejecuta('DELETE FROM instalacion WHERE id_sucursal = ?', [$id]);
        $bd->ejecuta('DELETE FROM evento_sucursal WHERE id_sucursal = ?', [$id]);
    }
    Pruebas\Semilla::borraUsuarios($bd, 'rep.');
    foreach ($sucursales as $id) {
        $bd->ejecuta('DELETE FROM sucursal WHERE id = ?', [$id]);
    }
};

$limpia();

$s = substr(bin2hex(random_bytes(3)), 0, 6);
$idAdmin   = Pruebas\Semilla::usuario($bd, 'rep.admin.' . $s, 'administrador');
$bitacora  = new Bitacora($bd, new Registro(sys_get_temp_dir() . '/timon-pruebas', false));
$identidad = new Identidad($bd);
$identidad->establece($idAdmin);
$central   = new Instalacion(['tipo' => 'central', 'desplazamiento' => 1, 'id_sucursal' => null, 'url_central' => null, 'secreto' => null]);
$instalaciones = new Instalaciones($bd, $bitacora, $identidad, $central);
$operacion = new OperacionRestaurante($bd, $bitacora, $identidad, $instalaciones);
$replica   = new Replica($bd, $bitacora);

$sucursal = $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Réplica ' . $s]);
$otra     = $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Réplica ajena ' . $s]);
$area     = $bd->inserta('INSERT INTO area (id_sucursal, nombre) VALUES (?, ?)', [$sucursal, 'Terraza']);
$mesa     = $bd->inserta('INSERT INTO mesa (id_sucursal, id_area, numero, capacidad) VALUES (?, ?, ?, ?)', [$sucursal, $area, 7, 4]);

// Un id que solo podría haber generado la sucursal: muy arriba y con su desplazamiento.
$idDeSucursal = static function (string $tabla, int $desplazamiento) use ($bd): int {
    $tope = (int) $bd->valor('SELECT COALESCE(MAX(id), 0) FROM ' . $tabla);
    return (intdiv($tope, 100) + 1000) * 100 + $desplazamiento;
};

$estado = [];

$gasto = static fn (int $id, int $suc, string $concepto, string $importe) => [
    'tabla' => 'gasto_sucursal', 'llave' => ['id' => $id],
    'fila' => ['id' => $id, 'id_sucursal' => $suc, 'id_usuario' => $idAdmin, 'concepto' => $concepto, 'importe' => $importe],
];

return [
    'un catálogo de esquema posterior espera antes de intentar escribir columnas nuevas' => function () use ($replica, $sucursal, $bd): void {
        $antes = $bd->valor('SELECT nombre FROM sucursal WHERE id = ?', [$sucursal]);
        Afirma::nulo($replica->aplicaBajada($sucursal, ['esquema' => $replica->esquema() + 1,
            'cambio' => true, 'tablas' => ['sucursal' => [['id' => $sucursal, 'nombre' => 'No debe cambiar', 'columna_nueva' => 1]]]]));
        Afirma::igual($antes, $bd->valor('SELECT nombre FROM sucursal WHERE id = ?', [$sucursal]));
    },
    'sin declararse central no registra computadoras' => function () use ($bd, $bitacora, $identidad, $sucursal): void {
        $sola = new Instalaciones($bd, $bitacora, $identidad, new Instalacion(null));
        $error = Afirma::lanza(ErrorHttp::class, fn () => $sola->registra($sucursal, 'Mini PC'));

        Afirma::igual(409, $error->estado(), 'el código');
        Afirma::igual('central', $bd->valor('SELECT servidor FROM sucursal WHERE id = ?', [$sucursal]), 'la sucursal sigue en el central');
    },

    'registrar pasa la sucursal a local y da una llave de un solo uso' => function () use ($bd, $instalaciones, $sucursal, &$estado): void {
        $hecho = $instalaciones->registra($sucursal, 'Mini PC de caja');
        $estado = $hecho;

        Afirma::cierto(preg_match('/^[a-f0-9]{64}$/D', $hecho['secreto']) === 1, 'la llave son 64 hexadecimales');
        Afirma::cierto($hecho['desplazamiento'] >= 2 && $hecho['desplazamiento'] <= 99, 'el desplazamiento va de 2 a 99');
        Afirma::igual('local', $bd->valor('SELECT servidor FROM sucursal WHERE id = ?', [$sucursal]), 'la sucursal pasó a local');
        Afirma::igual(hash('sha256', $hecho['secreto']), $bd->valor('SELECT secreto_hash FROM instalacion WHERE id = ?', [$hecho['id']]), 'solo queda el SHA-256');
        Afirma::igual($sucursal, $instalaciones->autentica($hecho['secreto'])['id_sucursal'] ?? null, 'la llave autentica a su sucursal');
        Afirma::nulo($instalaciones->autentica(str_repeat('0', 64)), 'otra llave no autentica');
    },

    'una sucursal solo tiene una computadora' => function () use ($instalaciones, $sucursal): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $instalaciones->registra($sucursal, 'Otra'));
        Afirma::igual(409, $error->estado(), 'el código');
    },

    'el central ya no escribe la operación de la sucursal local' => function () use ($operacion, $sucursal, $otra): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $operacion->exigeOperaAqui($sucursal));
        Afirma::igual(409, $error->estado(), 'la local se rechaza');
        Afirma::contiene('opera en su computadora', $error->getMessage(), 'el aviso');
        $operacion->exigeOperaAqui($otra);
    },

    'el catálogo solo cambia de huella si cambió algo' => function () use ($bd, $replica, $sucursal): void {
        $primera = $replica->catalogo($sucursal);
        Afirma::igual($primera['huella'], $replica->catalogo($sucursal)['huella'], 'la misma huella sin cambios');
        Afirma::cierto(isset($primera['tablas']['mesa']), 'baja la mesa');

        $bd->ejecuta('UPDATE mesa SET estado = ? WHERE id_sucursal = ?', ['por_limpiar', $sucursal]);
        Afirma::igual($primera['huella'], $replica->catalogo($sucursal)['huella'], 'el estado de la mesa no cuenta en la huella');
        $bd->ejecuta('UPDATE mesa SET estado = ? WHERE id_sucursal = ?', ['libre', $sucursal]);

        $bd->ejecuta('UPDATE area SET nombre = ? WHERE id_sucursal = ?', ['Terraza alta', $sucursal]);
        Afirma::falso($primera['huella'] === $replica->catalogo($sucursal)['huella'], 'la huella cambió con el área');
    },

    'la subida aplica la operación y repetirla no duplica' => function () use ($bd, $replica, $sucursal, $gasto, $idDeSucursal, &$estado): void {
        $instalacion = ['id' => $estado['id'], 'id_sucursal' => $sucursal];
        $id = $idDeSucursal('gasto_sucursal', $estado['desplazamiento']);
        $estado['gasto'] = $id;
        $lote = [$gasto($id, $sucursal, 'Hielo', '180.00')];

        Afirma::igual(1, $replica->aplicaSubida($instalacion, $lote)['filas'], 'entró una fila');
        $replica->aplicaSubida($instalacion, $lote);
        Afirma::igual(1, (int) $bd->valor('SELECT COUNT(*) FROM gasto_sucursal WHERE id = ?', [$id]), 'sigue siendo una');

        $replica->aplicaSubida($instalacion, [$gasto($id, $sucursal, 'Hielo', '210.00')]);
        Afirma::igual('210.00', $bd->valor('SELECT importe FROM gasto_sucursal WHERE id = ?', [$id]), 'la foto nueva reemplaza a la anterior');
        Afirma::cierto($bd->valor("SELECT 1 FROM bitacora WHERE modulo = 'replica' AND accion = 'subida' AND id_entidad = ?", [$estado['id']]) !== null,
            'la subida deja su apunte');
    },

    'una fila de otra sucursal detiene el lote completo' => function () use ($bd, $replica, $sucursal, $otra, $gasto, $idDeSucursal, &$estado): void {
        $instalacion = ['id' => $estado['id'], 'id_sucursal' => $sucursal];
        $buena = $idDeSucursal('gasto_sucursal', $estado['desplazamiento']) + 100;
        $ajena = $buena + 100;

        Afirma::lanza(ErrorHttp::class, fn () => $replica->aplicaSubida($instalacion, [
            $gasto($buena, $sucursal, 'Gas', '90.00'),
            $gasto($ajena, $otra, 'Intruso', '1.00'),
        ]));
        Afirma::nulo($bd->valor('SELECT id FROM gasto_sucursal WHERE id IN (?, ?)', [$buena, $ajena]), 'no entró ninguna de las dos');
    },

    'de la mesa solo sube el estado' => function () use ($bd, $replica, $sucursal, $mesa, &$estado): void {
        $instalacion = ['id' => $estado['id'], 'id_sucursal' => $sucursal];
        $replica->aplicaSubida($instalacion, [[
            'tabla' => 'mesa', 'llave' => ['id' => $mesa],
            'fila' => ['id' => $mesa, 'id_sucursal' => $sucursal, 'estado' => 'bloqueada', 'capacidad' => 99],
        ]]);
        $fila = $bd->fila('SELECT estado, capacidad FROM mesa WHERE id = ?', [$mesa]);

        Afirma::igual('bloqueada', $fila['estado'], 'el estado subió');
        Afirma::igual(4, (int) $fila['capacidad'], 'la capacidad es del central');
    },

    'una tabla que no sube se rechaza' => function () use ($replica, $sucursal, &$estado): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $replica->aplicaSubida(['id' => $estado['id'], 'id_sucursal' => $sucursal], [[
            'tabla' => 'usuario_sucursal', 'llave' => ['id_usuario' => 1, 'id_sucursal' => $sucursal], 'fila' => ['id_usuario' => 1, 'id_sucursal' => $sucursal],
        ]]));
        Afirma::igual(422, $error->estado(), 'el código');
    },

    'la bitácora de la sucursal entra con id nuevo y una sola vez' => function () use ($bd, $replica, $sucursal, $idAdmin, &$estado): void {
        $instalacion = ['id' => $estado['id'], 'id_sucursal' => $sucursal];
        $origen = 777700 + $estado['desplazamiento'];
        $apunte = ['tabla' => 'bitacora', 'llave' => ['id' => $origen], 'fila' => [
            'id' => $origen, 'id_usuario' => $idAdmin, 'momento' => '2026-11-18 13:05:00.000', 'modulo' => 'caja',
            'accion' => 'cobra', 'entidad' => 'cuenta', 'id_entidad' => 1, 'canal' => 'api', 'id_dispositivo' => 55,
        ]];

        Afirma::igual(1, $replica->aplicaSubida($instalacion, [$apunte])['bitacora'], 'entró el apunte');
        Afirma::igual(0, $replica->aplicaSubida($instalacion, [$apunte])['bitacora'], 'repetido no entra');
        $fila = $bd->fila('SELECT id, momento, id_dispositivo FROM bitacora WHERE origen_instalacion = ? AND origen_id = ?', [$estado['id'], $origen]);

        Afirma::falso((int) $fila['id'] === $origen, 'el id es del central');
        Afirma::contiene('2026-11-18 13:05:00', (string) $fila['momento'], 'conserva su momento');
        Afirma::nulo($fila['id_dispositivo'], 'el dispositivo de allá no se copia');
    },

    'el lote manda a los padres primero aunque se anotaran después' => function () use ($bd, $replica): void {
        $bd->ejecuta('DELETE FROM cambio_replica');
        $anota = static fn (string $tabla, int $id) => $bd->inserta(
            'INSERT INTO cambio_replica (tabla, llave, momento) VALUES (?, ?, NOW(3) - INTERVAL 1 MINUTE)', [$tabla, json_encode(['id' => $id])]);
        $anota('bitacora', 1);
        for ($i = 1; $i <= Replica::LOTE + 5; $i++) {
            $anota('cuenta_item', 900000 + $i);
        }
        $dosVeces = [$anota('ronda', 42), $anota('ronda', 42)];
        $reciente = $bd->inserta('INSERT INTO cambio_replica (tabla, llave) VALUES (?, ?)', ['proveedor', json_encode(['id' => 7])]);

        $lote = $replica->lotePendiente();
        Afirma::igual(Replica::LOTE, count($lote['filas']), 'un lote lleno');
        Afirma::igual('ronda', $lote['filas'][0]['tabla'], 'la ronda sube antes que sus platillos');
        Afirma::igual('cuenta_item', $lote['filas'][1]['tabla'], 'luego los platillos');
        Afirma::cierto(!in_array('bitacora', array_column($lote['filas'], 'tabla'), true), 'la bitácora espera al final');
        Afirma::cierto(!array_diff($dosVeces, $lote['cambios']), 'los dos cambios de la ronda quedan cubiertos');
        Afirma::cierto(!in_array($reciente, $lote['cambios'], true), 'lo de hace un instante espera');

        $replica->marcaEnviados($lote['cambios']);
        $resto = $replica->lotePendiente();
        Afirma::igual(['cuenta_item', 'bitacora'], array_values(array_unique(array_column($resto['filas'], 'tabla'))), 'el segundo lote trae lo que faltó');
        $bd->ejecuta('DELETE FROM cambio_replica');
    },

    'un periodo del segundo factor adelantado se recorta a hoy' => function () use ($bd, $replica, $sucursal, $idAdmin, &$estado): void {
        $instalacion = ['id' => $estado['id'], 'id_sucursal' => $sucursal];
        $ahora = intdiv(time(), 30);
        $sube = static fn (int $periodo) => $replica->aplicaSubida($instalacion, [[
            'tabla' => 'usuario', 'llave' => ['id' => $idAdmin], 'fila' => ['id' => $idAdmin, 'totp_ultimo_periodo' => $periodo],
        ]]);

        $sube($ahora - 1);
        Afirma::igual($ahora - 1, (int) $bd->valor('SELECT totp_ultimo_periodo FROM usuario WHERE id = ?', [$idAdmin]), 'un periodo normal sube tal cual');
        $sube($ahora + 1000000);
        Afirma::cierto((int) $bd->valor('SELECT totp_ultimo_periodo FROM usuario WHERE id = ?', [$idAdmin]) <= $ahora + 3, 'el adelantado no pasa de ahora');
        $sube(5);
        Afirma::cierto((int) $bd->valor('SELECT totp_ultimo_periodo FROM usuario WHERE id = ?', [$idAdmin]) >= $ahora, 'uno viejo no lo regresa');
    },

    'regresar al central exige que no quede nada por subir' => function () use ($bd, $instalaciones, $sucursal, &$estado): void {
        $instalaciones->anota($estado['id'], 'subida', 3, 'prueba');
        $error = Afirma::lanza(ErrorHttp::class, fn () => $instalaciones->regresaAlCentral($estado['id']));
        Afirma::igual(409, $error->estado(), 'con pendientes se rechaza');

        $instalaciones->anota($estado['id'], 'subida', 0, 'prueba');
        $instalaciones->regresaAlCentral($estado['id']);
        Afirma::igual('central', $bd->valor('SELECT servidor FROM sucursal WHERE id = ?', [$sucursal]), 'la sucursal volvió al central');
        Afirma::nulo($instalaciones->autentica($estado['secreto']), 'la llave ya no autentica');
    },

    'al final se limpia lo sembrado' => function () use ($limpia, $bd): void {
        $limpia();
        Afirma::igual(0, (int) $bd->valor("SELECT COUNT(*) FROM sucursal WHERE nombre LIKE 'Réplica %'"), 'sin sucursales de prueba');
    },
];
