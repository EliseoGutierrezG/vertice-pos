<?php
declare(strict_types=1);

use Modelos\Parametros;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Registro;
use Pruebas\Afirma;
use Servicios\DerechosTitular;

/**
 * Derechos del titular: la cancelación quita lo que identifica y las cuentas siguen.
 *
 * Hoy se exportan y anonimizan los datos del personal. La solicitud de un
 * cliente se registra y se atiende a mano hasta que llegue la fase que guarda
 * sus datos (domicilio y reservaciones), que agrega aquí sus casos.
 */

$raiz = dirname(__DIR__, 2);
$bd = new BaseDatos(Nucleo\Configuracion::baseDatos($raiz));
$bitacora = new Bitacora($bd, new Registro(sys_get_temp_dir() . '/timon-pruebas', false));
$derechos = new DerechosTitular($bd, $bitacora, new Parametros($bd));

$prefijo = 'prbderechos.';
Pruebas\Semilla::borraUsuarios($bd, $prefijo);
$admin = Pruebas\Semilla::usuario($bd, $prefijo . 'admin', 'administrador');
$empleado = Pruebas\Semilla::usuario($bd, $prefijo . 'empleado', 'administrador', 'frase-larga-del-empleado');
$idPersonal = (int) $bd->valor('SELECT id_personal FROM usuario WHERE id = ?', [$empleado]);
$limpia = static function () use ($bd, $prefijo, $admin): void {
    $bd->ejecuta('DELETE FROM solicitud_arco WHERE registrada_por = ?', [$admin]);
    Pruebas\Semilla::borraUsuarios($bd, $prefijo);
};
register_shutdown_function($limpia);

return [
    'una solicitud se registra con su fecha límite y sin datos personales en la bitácora' => function () use ($bd, $derechos, $admin, $idPersonal): void {
        $id = $derechos->registra([
            'tipo' => 'acceso', 'titular_tipo' => 'empleado', 'id_titular' => (string) $idPersonal, 'solicitante' => 'Solicitante de Prueba',
            'contacto' => 'contacto-de-prueba', 'detalle' => 'Quiere ver sus datos', 'recibida_en' => '2026-11-01',
        ], $admin, '127.0.0.1');

        Afirma::igual('2026-11-21', $bd->valor('SELECT vence_en FROM solicitud_arco WHERE id = ?', [$id]), 'veinte días después');
        $apunte = (string) $bd->valor("SELECT despues FROM bitacora WHERE accion = 'registra_solicitud' AND id_entidad = ?", [$id]);
        Afirma::cierto(!str_contains($apunte, 'Solicitante de Prueba'), 'el nombre no va a la bitácora');
    },

    'la solicitud de un cliente se registra sin número de titular' => function () use ($bd, $derechos, $admin): void {
        $id = $derechos->registra([
            'tipo' => 'cancelacion', 'titular_tipo' => 'cliente', 'id_titular' => '123', 'solicitante' => 'Cliente de Prueba',
            'detalle' => 'Que borren su teléfono', 'recibida_en' => '2026-11-01',
        ], $admin, '127.0.0.1');
        Afirma::nulo($bd->valor('SELECT id_titular FROM solicitud_arco WHERE id = ?', [$id]), 'se atiende a mano');
    },

    'una solicitud incompleta o de un titular inexistente se rechaza' => function () use ($derechos, $admin): void {
        $base = ['tipo' => 'acceso', 'titular_tipo' => 'empleado', 'id_titular' => '999999999', 'solicitante' => 'Alguien', 'detalle' => 'Algo', 'recibida_en' => '2026-11-01'];
        Afirma::igual(422, Afirma::lanza(ErrorHttp::class, fn () => $derechos->registra($base, $admin, '127.0.0.1'))->estado(), 'titular');
        Afirma::igual(422, Afirma::lanza(ErrorHttp::class, fn () => $derechos->registra(['tipo' => 'x'] + $base, $admin, '127.0.0.1'))->estado(), 'tipo');
        Afirma::igual(422, Afirma::lanza(ErrorHttp::class, fn () => $derechos->registra(['recibida_en' => '2999-01-01', 'titular_tipo' => 'otro'] + $base, $admin, '127.0.0.1'))->estado(), 'fecha futura');
    },

    'una solicitud se cierra una sola vez y con respuesta' => function () use ($bd, $derechos, $admin): void {
        $id = (int) $bd->valor('SELECT MAX(id) FROM solicitud_arco WHERE registrada_por = ?', [$admin]);
        Afirma::igual(422, Afirma::lanza(ErrorHttp::class, fn () => $derechos->cierra($id, 'atendida', 'corta', $admin, '127.0.0.1'))->estado(), 'sin respuesta');
        $derechos->cierra($id, 'atendida', 'Se entregó la exportación de sus datos', $admin, '127.0.0.1');
        Afirma::igual('atendida', $bd->valor('SELECT estado FROM solicitud_arco WHERE id = ?', [$id]));
        Afirma::igual(409, Afirma::lanza(ErrorHttp::class, fn () => $derechos->cierra($id, 'rechazada', 'Otra respuesta cualquiera', $admin, '127.0.0.1'))->estado(), 'segunda vez');
    },

    'la exportación trae los datos del titular y ningún secreto' => function () use ($derechos, $admin, $idPersonal, $bd): void {
        $persona = json_encode($derechos->exporta('empleado', $idPersonal, $admin, '127.0.0.1'), JSON_UNESCAPED_UNICODE);
        Afirma::contiene('prbderechos.empleado', (string) $persona, 'su cuenta');
        foreach (['clave_hash', 'totp', 'token', '$2y$', '$argon'] as $secreto) {
            Afirma::cierto(!str_contains((string) $persona, $secreto), 'no lleva ' . $secreto);
        }
        Afirma::cierto((int) $bd->valor("SELECT COUNT(*) FROM bitacora WHERE accion = 'exporta_titular' AND id_usuario = ?", [$admin]) >= 1, 'queda como lectura');
    },

    'a un empleado activo no se le anonimiza' => function () use ($derechos, $admin, $idPersonal): void {
        Afirma::igual(409, Afirma::lanza(ErrorHttp::class, fn () => $derechos->anonimizaEmpleado($idPersonal, $admin, '127.0.0.1'))->estado(), 'sigue activo');
    },

    'anonimizar a un ex empleado le quita lo que identifica, y ya no puede entrar' => function () use ($bd, $derechos, $admin, $empleado, $idPersonal, $prefijo): void {
        $bd->ejecuta('UPDATE personal SET id_estatus = 3, fecha_baja = CURDATE() WHERE id = ?', [$idPersonal]);
        $bd->ejecuta("INSERT INTO dispositivo (id_usuario, identificador, nombre, token_push, autorizado) VALUES (?, 'telefono-de-prueba', 'Teléfono', 'token-de-prueba', 1)", [$empleado]);

        $derechos->anonimizaEmpleado($idPersonal, $admin, '127.0.0.1');

        Afirma::igual('Ex empleado', $bd->valor('SELECT nombre FROM personal WHERE id = ?', [$idPersonal]), 'el nombre');
        Afirma::igual('anonimo.' . $idPersonal, $bd->valor('SELECT usuario FROM usuario WHERE id = ?', [$empleado]), 'la cuenta');
        Afirma::nulo((new Modelos\Usuarios($bd))->autentica($prefijo . 'empleado', 'frase-larga-del-empleado'), 'no entra');
        Afirma::nulo($bd->valor('SELECT token_push FROM dispositivo WHERE id_usuario = ?', [$empleado]), 'el token del equipo');
        Afirma::igual(409, Afirma::lanza(ErrorHttp::class, fn () => $derechos->anonimizaEmpleado($idPersonal, $admin, '127.0.0.1'))->estado(), 'dos veces');

        $bd->ejecuta('DELETE FROM dispositivo WHERE id_usuario = ?', [$empleado]);
        $bd->ejecuta("UPDATE usuario SET usuario = ? WHERE id = ?", [$prefijo . 'empleado', $empleado]);
    },

    'anonimizar ex empleados no arranca solo y el aviso nace en borrador' => function () use ($bd): void {
        $parametros = new Parametros($bd);
        Afirma::igual(0, $parametros->entero('dias_anonimizar_ex_personal', -1), 'los ex empleados');
        Afirma::igual(0, $parametros->entero('aviso_privacidad_aprobado', -1), 'el aviso sigue en borrador');
    },
];
