<?php
declare(strict_types=1);

use Nucleo\Aplicacion;
use Nucleo\BaseDatos;
use Nucleo\Identidad;
use Pruebas\Afirma;
use Pruebas\Semilla;
use Servicios\HistoriasRestaurante;

return [
    'la página y el XLS usan los mismos filtros y el mismo orden' => static function (): void {
        $contenedor = (new Aplicacion(dirname(__DIR__, 2)))->contenedor();
        $bd = $contenedor->obtiene(BaseDatos::class);
        $revertir = new RuntimeException('Retirar los datos de la prueba');
        try {
            $bd->transaccion(static function () use ($contenedor, $bd, $revertir): void {
                $sufijo = bin2hex(random_bytes(4));
                $usuario = Semilla::usuario($bd, 'historias.' . $sufijo, 'administrador');
                $contenedor->obtiene(Identidad::class)->establece($usuario);
                $sucursal = $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Historias ' . $sufijo]);
                $proveedor = $bd->inserta('INSERT INTO proveedor (id_sucursal,nombre) VALUES (?, ?)', [$sucursal, 'Puerto Azul']);
                for ($i = 1; $i <= 201; $i++) {
                    $texto = 'Compra de atún ' . $i;
                    $bd->inserta('INSERT INTO compra_insumo (id_sucursal,id_proveedor,id_usuario,referencia,creada_en)
                        VALUES (?, ?, ?, ?, ?)', [$sucursal, $proveedor, $usuario, $texto, '2026-01-15 12:00:00']);
                }
                $bd->inserta('INSERT INTO compra_insumo (id_sucursal,id_proveedor,id_usuario,referencia,creada_en)
                    VALUES (?, ?, ?, ?, ?)', [$sucursal, $proveedor, $usuario, 'Compra de atún posterior', '2026-01-16 00:00:00']);
                $filtros = ['desde' => '2026-01-15', 'hasta' => '2026-01-15', 'catalogo' => $proveedor,
                    'estado' => 'ordenada', 'buscar' => 'AZUL atún'];
                $servicio = $contenedor->obtiene(HistoriasRestaurante::class);
                $pagina = $servicio->pagina($sucursal, 'compras', $filtros, 2, 100);
                $exporta = iterator_to_array($servicio->exporta($sucursal, 'compras', $filtros));
                Afirma::igual(201, $pagina['total'], 'todos los registros del periodo');
                Afirma::igual(3, $pagina['paginas'], 'el total de páginas');
                Afirma::igual(100, count($pagina['filas']), 'límite de la segunda página');
                Afirma::igual(201, count($exporta), 'XLS con el conjunto completo');
                Afirma::igual('Compra de atún 201', $exporta[0][0], 'el primer renglón');
                Afirma::igual($exporta[100][0], $pagina['filas'][0]['referencia'], 'el mismo orden');
                Afirma::igual('Compra de atún 1', $exporta[200][0], 'el último renglón');
                throw $revertir;
            });
        } catch (RuntimeException $error) {
            if ($error !== $revertir) {
                throw $error;
            }
        }
    },
];
