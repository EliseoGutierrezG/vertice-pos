<?php
declare(strict_types=1);

use Modelos\Dispositivos;
use Nucleo\Aplicacion;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Pruebas\Afirma;
use Servicios\Notificaciones;

$raiz=dirname(__DIR__,2);$app=new Aplicacion($raiz);
/** @var BaseDatos $bd */$bd=$app->contenedor()->obtiene(BaseDatos::class);
/** @var Identidad $identidad */$identidad=$app->contenedor()->obtiene(Identidad::class);
/** @var Bitacora $bitacora */$bitacora=$app->contenedor()->obtiene(Bitacora::class);
$dispositivos=new Dispositivos($bd);$prefijo='push19.';$e=[];
$limpia=static function()use($bd,$prefijo):void{
    $usuarios=array_map('intval',array_column($bd->filas('SELECT id FROM usuario WHERE usuario LIKE ?',[$prefijo.'%']),'id'));
    if($usuarios!==[]){$m=implode(',',array_fill(0,count($usuarios),'?'));$bd->ejecuta('DELETE FROM notificacion WHERE id_usuario IN ('.$m.')',$usuarios);}
    Pruebas\Semilla::borraUsuarios($bd,$prefijo);
};
$prepara=static function()use(&$e,$limpia,$bd,$prefijo,$dispositivos,$identidad):void{
    if($e!==[])return;$limpia();$admin=Pruebas\Semilla::usuario($bd,$prefijo.'admin','administrador');$campo=Pruebas\Semilla::usuario($bd,$prefijo.'campo','mesero');
    $telefono=$dispositivos->registraOEncuentra($campo,'push-prueba','Teléfono push');$dispositivos->autoriza((int)$telefono['id']);
    $dispositivos->actualizaPush((int)$telefono['id'],$campo,'ExponentPushToken[prueba_123]','android');$identidad->establece($admin);$e=compact('admin','campo','telefono');
};
register_shutdown_function(static function()use(&$e,$limpia):void{if($e!==[])$limpia();});


// Avisos a varios. Todo dentro de una sucursal propia y con un gerente de esa
// sucursal, para que el alcance deje fuera el resto de la base.
$pa='aviso67.';$av=[];
$limpiaAvisos=static function()use($bd,$pa):void{
    Pruebas\Semilla::borraUsuarios($bd,$pa);
    $sucursales=array_map('intval',array_column($bd->filas('SELECT id FROM sucursal WHERE nombre LIKE ?',['Prueba Avisos %']),'id'));
    foreach($sucursales as $b)$bd->ejecuta('DELETE FROM sucursal WHERE id=?',[$b]);
};
$preparaAvisos=static function()use(&$av,$limpiaAvisos,$bd,$pa,$dispositivos,$identidad):void{
    if($av!==[])return;$limpiaAvisos();$s=bin2hex(random_bytes(3));
    $sucursal=$bd->inserta('INSERT INTO sucursal(nombre)VALUES(?)',['Prueba Avisos sucursal '.$s]);
    $usuario=static fn(string $n,string $puesto,?int $b)=>Pruebas\Semilla::usuario($bd,$pa.$n,$puesto,idSucursal:$b);
    $telefono=static function(int $u,string $id,bool $autoriza=true,bool $token=true)use($dispositivos):int{
        $t=$dispositivos->registraOEncuentra($u,$id,'Teléfono '.$id);if($autoriza)$dispositivos->autoriza((int)$t['id']);
        if($token)$dispositivos->actualizaPush((int)$t['id'],$u,'ExponentPushToken['.$id.']','android');return (int)$t['id'];
    };
    $sup=$usuario('sup','gerente',$sucursal);
    $p1=$usuario('p1','mesero',$sucursal);$telefono($p1,'av-p1a');$telefono($p1,'av-p1b');
    $p2=$usuario('p2','mesero',$sucursal);$telefono($p2,'av-p2');
    $rep=$usuario('rep','cocina',$sucursal);$telefono($rep,'av-rep');
    $espera=$usuario('espera','mesero',$sucursal);$telefono($espera,'av-espera',false);
    $sinAvisos=$usuario('sinavisos','mesero',$sucursal);$telefono($sinAvisos,'av-sin',true,false);
    $fuera=$usuario('fuera','mesero',null);$telefono($fuera,'av-fuera');
    $identidad->establece($sup);
    $mesero=(int)$bd->valor('SELECT id FROM puesto WHERE clave="mesero"');
    $otra=(int)$bd->valor('SELECT MIN(id) FROM sucursal WHERE id<>?',[$sucursal]);
    $av=compact('sucursal','otra','sup','p1','p2','rep','espera','sinAvisos','fuera','mesero','telefono');
};
register_shutdown_function(static function()use(&$av,$limpiaAvisos):void{if($av!==[])$limpiaAvisos();});
$cuenta=static function(Notificaciones $n,string $valor):?array{
    foreach($n->opcionesAviso() as $o)if($o['valor']===$valor)return [$o['personas'],$o['telefonos']];
    return null;
};

return [
    'el token push sólo se actualiza en el equipo de la sesión'=>function()use($prepara,$dispositivos,&$e,$bd):void{
        $prepara();
        // Registrar otra vez el mismo token debe ser idempotente: MySQL puede
        // reportar cero filas modificadas aunque la pareja sí exista.
        $dispositivos->actualizaPush((int)$e['telefono']['id'],$e['campo'],'ExponentPushToken[prueba_123]','android');
        $error=Afirma::lanza(ErrorHttp::class,fn()=>$dispositivos->actualizaPush((int)$e['telefono']['id'],$e['admin'],'ExpoPushToken[ajeno]','android'));
        Afirma::igual(404,$error->estado());
        Afirma::igual('ExponentPushToken[prueba_123]',$bd->valor('SELECT token_push FROM dispositivo WHERE id=?',[(int)$e['telefono']['id']]));
    },
    'el aviso enviado queda auditado y marcado como entregado a Expo'=>function()use($prepara,&$e,$bd,$identidad,$bitacora):void{
        $prepara();$mandado=[];
        $servicio=Notificaciones::paraPruebas($bd,$identidad,$bitacora,static function(array $mensaje)use(&$mandado):array{$mandado=$mensaje;return ['data'=>['status'=>'ok','id'=>'ticket']];});
        $id=$servicio->envia((int)$e['telefono']['id'],'Cocina','Pase a cocina',['pantalla'=>'inicio'],'127.0.0.1');
        $fila=$bd->fila('SELECT enviado_en,error FROM notificacion WHERE id=?',[$id]);
        Afirma::igual('ExponentPushToken[prueba_123]',$mandado['to']);Afirma::igual('Cocina',$mandado['title']);Afirma::cierto($fila['enviado_en']!==null);Afirma::igual(null,$fila['error']);
    },
    'un envío repetido no duplica la notificación ni el transporte'=>function()use($prepara,&$e,$bd,$identidad,$bitacora):void{
        $prepara(); $transportes=0; $titulo='Idempotencia '.bin2hex(random_bytes(4));
        $servicio=Notificaciones::paraPruebas($bd,$identidad,$bitacora,static function(array $mensaje)use(&$transportes):array{
            $transportes++; return ['data'=>['status'=>'ok','id'=>'ticket']];
        });
        $middleware=new Nucleo\Middleware\ExigeEnvioUnico($bd,$identidad,new Nucleo\Sesion(false));
        $peticion=static function(string $llave): Nucleo\Peticion {
            $_SERVER['REQUEST_METHOD']='POST'; $_SERVER['REQUEST_URI']='/dispositivos/notificacion';
            $_SERVER['REMOTE_ADDR']='127.0.0.1'; $_SERVER['HTTP_ACCEPT']='application/json';
            unset($_SERVER['HTTP_X_ENVIO']); $_GET=[]; $_POST=$llave===''?[]:['_envio'=>$llave];
            return Nucleo\Peticion::desdeGlobales()->conDestino([Controladores\Web\DispositivosWeb::class,'notifica']);
        };
        $trabajo=static function()use($servicio,&$e,$titulo):Nucleo\Respuesta{
            $servicio->envia((int)$e['telefono']['id'],$titulo,'Mensaje de prueba',[],'127.0.0.1');
            return Nucleo\Respuesta::json(['redirige'=>'/dispositivos']);
        };
        $llave=Pruebas\Semilla::llave();
        $primera=$middleware->maneja($peticion($llave),$trabajo);
        $segunda=$middleware->maneja($peticion($llave),$trabajo);
        Afirma::igual($primera->cuerpo(),$segunda->cuerpo());
        Afirma::igual(1,$transportes);
        Afirma::igual(1,(int)$bd->valor('SELECT COUNT(*) FROM notificacion WHERE titulo=?',[$titulo]));
        $error=Afirma::lanza(ErrorHttp::class,fn()=>$middleware->maneja($peticion(''),$trabajo));
        Afirma::igual(422,$error->estado());
        $middleware->maneja($peticion(Pruebas\Semilla::llave()),$trabajo);
        Afirma::igual(2,$transportes);
        Afirma::igual(2,(int)$bd->valor('SELECT COUNT(*) FROM notificacion WHERE titulo=?',[$titulo]));
    },
    'un rechazo de Expo se conserva para diagnóstico'=>function()use($prepara,&$e,$bd,$identidad,$bitacora):void{
        $prepara();$servicio=Notificaciones::paraPruebas($bd,$identidad,$bitacora,static fn(array $mensaje):array=>['data'=>['status'=>'error','message'=>'DeviceNotRegistered']]);
        $error=Afirma::lanza(ErrorHttp::class,fn()=>$servicio->envia((int)$e['telefono']['id'],'Ruta','Prueba',[],'127.0.0.1'));
        Afirma::igual(503,$error->estado());Afirma::igual('DeviceNotRegistered',$bd->valor('SELECT error FROM notificacion WHERE id_usuario=? ORDER BY id DESC LIMIT 1',[$e['campo']]));
    },

    'cada destino cuenta solo a los equipos autorizados con avisos de su sucursal'=>function()use($preparaAvisos,&$av,$bd,$identidad,$bitacora,$cuenta):void{
        $preparaAvisos();$n=new Notificaciones($bd,$identidad,$bitacora);
        Afirma::igual([3,4],$cuenta($n,'todos'),'todos: tres personas, cuatro teléfonos');
        Afirma::igual([2,3],$cuenta($n,'puesto:'.$av['mesero']),'el puesto de mesero');
        Afirma::igual([3,4],$cuenta($n,'sucursal:'.$av['sucursal']),'la sucursal');
        Afirma::igual([1,2],$cuenta($n,'persona:'.$av['p1']),'una persona con dos teléfonos');
        Afirma::igual(null,$cuenta($n,'persona:'.$av['espera']),'un teléfono sin autorizar no cuenta');
        Afirma::igual(null,$cuenta($n,'persona:'.$av['sinAvisos']),'ni uno sin avisos');
        Afirma::igual(null,$cuenta($n,'persona:'.$av['fuera']),'ni alguien fuera de la sucursal');
        Afirma::igual(422,Afirma::lanza(ErrorHttp::class,fn()=>$n->destinatarios('persona:'.$av['fuera']))->estado(),'y no se le puede mandar');
        Afirma::igual(422,Afirma::lanza(ErrorHttp::class,fn()=>$n->destinatarios('ruta:1'))->estado(),'un destino desconocido se rechaza');
        if($av['otra']>0)Afirma::igual(422,Afirma::lanza(ErrorHttp::class,fn()=>$n->destinatarios('sucursal:'.$av['otra']))->estado(),'ni otra sucursal');
        Afirma::igual(422,Afirma::lanza(ErrorHttp::class,fn()=>$n->destinatarios('todos:3'))->estado(),'todos no lleva id');
    },
    'un aviso a un puesto deja su registro, una notificación por teléfono y su bitácora'=>function()use($preparaAvisos,&$av,$bd,$identidad,$bitacora):void{
        $preparaAvisos();$llamadas=[];
        $n=Notificaciones::paraPruebas($bd,$identidad,$bitacora,static function(array $tanda)use(&$llamadas):array{
            $llamadas[]=$tanda;return ['data'=>array_map(static fn(array $m):array=>str_contains($m['to'],'p1b')?['status'=>'error','message'=>'DeviceNotRegistered']:['status'=>'ok','id'=>'t'],$tanda)];
        });
        Afirma::igual(422,Afirma::lanza(ErrorHttp::class,fn()=>$n->enviaAviso(['destino'=>'puesto:'.$av['mesero'],'titulo'=>'','cuerpo'=>'x'],'127.0.0.1'))->estado(),'sin título no sale');
        Afirma::igual([],$llamadas,'y no toca el transporte');
        $r=$n->enviaAviso(['destino'=>'puesto:'.$av['mesero'],'titulo'=>'Junta','cuerpo'=>'A las 8 en la sucursal'],'127.0.0.1');
        Afirma::igual(['id'=>$r['id'],'telefonos'=>3,'aceptados'=>2,'fallidos'=>1],$r,'el resumen');
        Afirma::igual(1,count($llamadas),'tres teléfonos van en una sola tanda');
        Afirma::cierto(array_is_list($llamadas[0])&&$llamadas[0][0]['data']['id_aviso']===$r['id'],'cada mensaje lleva su aviso');
        $aviso=$bd->fila('SELECT * FROM aviso WHERE id=?',[$r['id']]);
        Afirma::igual(['puesto',(int)$av['mesero'],2,3,2,1,(int)$av['sucursal']],[$aviso['destino_tipo'],(int)$aviso['destino_id'],(int)$aviso['personas'],(int)$aviso['telefonos'],(int)$aviso['aceptados'],(int)$aviso['fallidos'],(int)$aviso['id_sucursal']],'el aviso guarda destino, conteos y alcance');
        Afirma::igual(3,(int)$bd->valor('SELECT COUNT(*) FROM notificacion WHERE id_aviso=? AND id_dispositivo IS NOT NULL',[$r['id']]),'una notificación por teléfono');
        Afirma::igual('DeviceNotRegistered',$bd->valor('SELECT error FROM notificacion WHERE id_aviso=? AND error IS NOT NULL',[$r['id']]),'el rechazo queda para diagnóstico');
        Afirma::igual(1,(int)$bd->valor('SELECT COUNT(*) FROM bitacora WHERE modulo="notificaciones" AND accion="envia_aviso" AND id_entidad=?',[$r['id']]),'y su bitácora');
        $ficha=$n->aviso($r['id']);Afirma::igual(3,count($ficha['telefonos_detalle']),'la ficha trae cada teléfono');
        Afirma::cierto(in_array($r['id'],array_map('intval',array_column($n->avisos(date('Y-m-d'),date('Y-m-d')),'id')),true),'y el historial lo lista');
    },
    'si Expo no contesta, el aviso cuenta todos como fallidos y no se pierde'=>function()use($preparaAvisos,&$av,$bd,$identidad,$bitacora):void{
        $preparaAvisos();
        $n=Notificaciones::paraPruebas($bd,$identidad,$bitacora,static function(array $tanda):array{throw new RuntimeException('sin red');});
        $r=$n->enviaAviso(['destino'=>'persona:'.$av['rep'],'titulo'=>'Cocina','cuerpo'=>'Falta hielo'],'127.0.0.1');
        Afirma::igual([1,0,1],[$r['telefonos'],$r['aceptados'],$r['fallidos']]);
        Afirma::igual(1,(int)$bd->valor('SELECT COUNT(*) FROM notificacion WHERE id_aviso=? AND enviado_en IS NULL AND error IS NOT NULL',[$r['id']]));
    },
    'más de cien teléfonos salen en tandas de cien'=>function()use($preparaAvisos,&$av,$bd,$identidad,$bitacora,$pa):void{
        $preparaAvisos();
        $muchos=Pruebas\Semilla::usuario($bd,$pa.'muchos','mesero',idSucursal:$av['sucursal']);
        for($i=0;$i<=Notificaciones::TANDA;$i++)($av['telefono'])($muchos,'av-m'.$i);
        $tandas=[];
        $n=Notificaciones::paraPruebas($bd,$identidad,$bitacora,static function(array $tanda)use(&$tandas):array{
            $tandas[]=count($tanda);return ['data'=>array_fill(0,count($tanda),['status'=>'ok'])];
        });
        $r=$n->enviaAviso(['destino'=>'persona:'.$muchos,'titulo'=>'Inventario','cuerpo'=>'Mañana se cuenta'],'127.0.0.1');
        Afirma::igual([100,1],$tandas,'ciento uno salen en dos tandas');
        Afirma::igual([101,101,0],[$r['telefonos'],$r['aceptados'],$r['fallidos']]);
    },
];
