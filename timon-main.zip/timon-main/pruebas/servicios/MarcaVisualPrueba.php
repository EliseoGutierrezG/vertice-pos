<?php
declare(strict_types=1);

use Pruebas\Afirma;
use Servicios\MarcaVisual;

/**
 * La marca visual de la instalación (2026-11-09, D24; paleta D25 el 2026-11-10). Lo que entra aquí
 * termina dentro de una hoja de estilos y de la respuesta de la app, así que
 * todo lo raro se rechaza y la pantalla vuelve a El Timón.
 */
$carpeta = static function (): string {
    $dir = sys_get_temp_dir() . '/marca-visual-' . bin2hex(random_bytes(4));
    mkdir($dir);
    return $dir;
};
// Un PNG de 1×1 válido.
$png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==');
$borra = static function (string $dir): void {
    foreach (glob($dir . '/*') ?: [] as $f) {
        unlink($f);
    }
    rmdir($dir);
};

return [
    'sin archivo es El Timón y no hay nada que validar' => function () use ($carpeta, $borra): void {
        $dir = $carpeta();
        $m = new MarcaVisual(null, $dir);
        $m->valida();
        Afirma::falso($m->personalizada());
        Afirma::igual(MarcaVisual::BASE, $m->vigente());
        Afirma::nulo($m->logo());
        Afirma::igual('El Timón', $m->manifiesto()['nombre_corto']);
        $borra($dir);
    },
    'la marca de la casa cumple sus propios contrastes' => function (): void {
        $c = MarcaVisual::BASE['colores'];
        Afirma::cierto(MarcaVisual::contraste($c['tinta'], $c['fondo']) >= 4.5, 'tinta sobre fondo');
        Afirma::cierto(MarcaVisual::contraste('#FFFFFF', $c['primario']) >= 4.5, 'blanco sobre marino');
        Afirma::cierto(MarcaVisual::contraste($c['acento'], $c['superficie']) >= 2.5, 'oro sobre blanco');
        Afirma::contiene('--app-accent-dark: #', (new MarcaVisual(null, sys_get_temp_dir()))->css());
        Afirma::cierto(MarcaVisual::contraste('#5B6675', $c['fondo']) >= 4.5, 'gris secundario sobre fondo');
        // D25 (2026-11-10): la paleta del panel de El Timón.
        Afirma::igual(['#F5F7F8', '#1C3F94', '#C8372D'], [$c['fondo'], $c['primario'], $c['acento']], 'fondo, cobalto y salsa roja');
        (new MarcaVisual(MarcaVisual::BASE, sys_get_temp_dir()))->valida();
    },
    'una marca propia válida cambia nombre, colores y revisión' => function () use ($carpeta, $borra): void {
        $dir = $carpeta();
        $m = new MarcaVisual(['nombre' => 'Distribuidora Ejemplo', 'nombre_corto' => 'Ejemplo', 'colores' => ['primario' => '#14532d']], $dir);
        Afirma::cierto($m->personalizada());
        Afirma::igual('Ejemplo', $m->vigente()['nombre_corto']);
        Afirma::igual('#14532D', $m->vigente()['colores']['primario'], 'el color se guarda en mayúsculas');
        Afirma::igual(MarcaVisual::BASE['colores']['fondo'], $m->vigente()['colores']['fondo'], 'lo que no se puso se queda como El Timón');
        Afirma::cierto((new MarcaVisual(null, $dir))->revision() !== $m->revision(), 'la revisión cambia');
        Afirma::contiene('--app-primary: #14532D;', $m->css());
        $borra($dir);
    },
    'un color con inyección se rechaza y la pantalla vuelve a El Timón' => function () use ($carpeta, $borra): void {
        $dir = $carpeta();
        foreach (['red', '#fff', 'red;}body{display:none', '#14532d;x', 'url(https://x.example/a.png)', '14532d', ' #14532d'] as $malo) {
            $m = new MarcaVisual(['colores' => ['primario' => $malo]], $dir);
            Afirma::lanza(InvalidArgumentException::class, fn () => $m->valida(), "el color «{$malo}»");
            Afirma::falso($m->personalizada());
            Afirma::igual(MarcaVisual::BASE, $m->vigente());
            Afirma::cierto(!str_contains($m->css(), $malo), 'el valor no llega a la hoja');
            Afirma::noNulo($m->problema());
        }
        $borra($dir);
    },
    'llaves y colores desconocidos se rechazan' => function () use ($carpeta, $borra): void {
        $dir = $carpeta();
        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['fuente' => 'Comic'], $dir))->valida());
        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['colores' => ['texto' => '#000000']], $dir))->valida());
        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['_ilegible' => true], $dir))->valida());
        $borra($dir);
    },
    'los textos tienen tope y no aceptan etiquetas' => function () use ($carpeta, $borra): void {
        $dir = $carpeta();
        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['nombre' => str_repeat('a', 61)], $dir))->valida());
        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['nombre_corto' => '<script>'], $dir))->valida());
        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['lema' => ''], $dir))->valida());
        $borra($dir);
    },
    'un contraste bajo se rechaza con la medida' => function () use ($carpeta, $borra): void {
        $dir = $carpeta();
        $e = Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['colores' => ['primario' => '#F2C14E']], $dir))->valida());
        Afirma::contiene('blanco sobre el primario', $e->getMessage());
        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['colores' => ['tinta' => '#C0C6CE']], $dir))->valida());
        $borra($dir);
    },
    'el logotipo vive en su carpeta, es PNG o WebP y pesa poco' => function () use ($carpeta, $borra, $png): void {
        $dir = $carpeta();
        file_put_contents($dir . '/logo.png', $png);
        $m = new MarcaVisual(['logo' => 'logo.png'], $dir);
        Afirma::igual('image/png', $m->logo()['tipo'] ?? null);
        Afirma::igual(hash('sha256', $png), $m->manifiesto()['logo']['sha256'] ?? null);
        Afirma::cierto(!isset($m->manifiesto()['logo']['ruta']), 'la app no recibe rutas del servidor');

        foreach (['../logo.png', '/etc/passwd', 'logo.svg', 'logo.php', '.logo.png', 'sub/logo.png'] as $malo) {
            Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['logo' => $malo], $dir))->valida(), "el logo «{$malo}»");
        }

        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['logo' => 'falta.png'], $dir))->valida(), 'un archivo que no existe');

        file_put_contents($dir . '/disfraz.png', "<?php echo 'hola';");
        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['logo' => 'disfraz.png'], $dir))->valida(), 'un PHP con extensión .png');

        file_put_contents($dir . '/grande.png', $png . str_repeat("\0", MarcaVisual::LOGO_MAXIMO));
        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['logo' => 'grande.png'], $dir))->valida(), 'más de 512 KB');
        $borra($dir);
    },
    'un enlace que sale de la carpeta no cuenta como logotipo' => function () use ($carpeta, $borra, $png): void {
        $dir = $carpeta();
        $fuera = $carpeta();
        file_put_contents($fuera . '/ajeno.png', $png);
        symlink($fuera . '/ajeno.png', $dir . '/enlace.png');
        Afirma::lanza(InvalidArgumentException::class, fn () => (new MarcaVisual(['logo' => 'enlace.png'], $dir))->valida());
        $borra($dir);
        $borra($fuera);
    },
    'las tablas y tarjetas de una marca propia van en su superficie, no en el fondo' => function (): void {
        $css = (new MarcaVisual(null, sys_get_temp_dir()))->css();
        Afirma::contiene('--bs-body-bg: #FFFFFF;', $css, 'Bootstrap pinta tarjetas y campos con --bs-body-bg');
        Afirma::contiene('--app-bg: #F5F7F8;', $css, 'el lienzo sigue siendo el fondo');
    },
    'la hoja sólo lleva variables con valores saneados' => function (): void {
        $css = (new MarcaVisual(null, sys_get_temp_dir()))->css();
        foreach (explode("\n", trim($css)) as $linea) {
            Afirma::cierto(
                preg_match('~^(/\*[^*]*\*/|:root \{|\}|    --[a-z0-9-]+: (#[0-9A-F]{6}|rgb\(\d+ \d+ \d+ / \d+%\)|\d+, \d+, \d+);)$~', $linea) === 1,
                "renglón inesperado en la hoja: {$linea}"
            );
        }
    },
];
