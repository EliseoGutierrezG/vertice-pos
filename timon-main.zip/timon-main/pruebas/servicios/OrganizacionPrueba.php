<?php
declare(strict_types=1);

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Nucleo\Registro;
use Pruebas\Afirma;
use Servicios\Organizacion;

/**
 * Las sucursales, contra la base de pruebas.
 *
 * Lo que aquí se cuida es lo que el esquema no puede cuidar solo: nombre y
 * clave únicos entre las activas, que una sucursal con personal activo no se
 * dé de baja, que sólo el administrador dé de alta, y el alcance por sucursal.
 *
 * Todo lo sembrado lo crean usuarios `org.`: al final se borra lo que ellos
 * dieron de alta, y nada más.
 */
$config = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd     = new BaseDatos($config);

$sembrado = static function (BaseDatos $bd): array {
    return array_map(
        static fn (array $f): int => (int) $f['id'],
        $bd->filas("SELECT id FROM usuario WHERE usuario LIKE 'org.%'")
    );
};

$limpia = static function () use ($bd, $sembrado): void {
    $usuarios = $sembrado($bd);

    if ($usuarios !== []) {
        $marcas  = implode(', ', array_fill(0, count($usuarios), '?'));
        $sucursales = array_map(
            static fn (array $f): int => (int) $f['id'],
            $bd->filas('SELECT id FROM sucursal WHERE creado_por IN (' . $marcas . ')', $usuarios)
        );

        // El personal de alcance apunta a una sucursal sembrada: se va antes que ella.
        Pruebas\Semilla::borraUsuarios($bd, 'org.');

        if ($sucursales !== []) {
            $bd->ejecuta(
                'DELETE FROM sucursal WHERE id IN (' . implode(', ', array_fill(0, count($sucursales), '?')) . ')',
                $sucursales
            );
        }
    }

    Pruebas\Semilla::borraUsuarios($bd, 'org.');
};

$limpia();

$idAdmin = Pruebas\Semilla::usuario($bd, 'org.admin', 'administrador');

$bitacora = new Bitacora($bd, new Registro(sys_get_temp_dir() . '/timon-pruebas', false));

$servicioDe = static function (int $idUsuario) use ($bd, $bitacora): Organizacion {
    $identidad = new Identidad($bd);
    $identidad->establece($idUsuario);

    return new Organizacion($bd, $bitacora, $identidad);
};

$org = $servicioDe($idAdmin);
$ip  = '127.0.0.1';

// Un sufijo por corrida: si una corrida anterior murió a medias, sus nombres
// no chocan con los de ésta.
$s = substr(bin2hex(random_bytes(3)), 0, 6);

/** La queja de un 422 en un campo. */
$quejaEn = static function (string $campo, callable $trabajo, string $que = ''): string {
    $error = Afirma::lanza(ErrorHttp::class, $trabajo, $que);
    Afirma::igual(422, $error->estado(), 'el código de ' . ($que ?: $campo));
    Afirma::cierto(isset($error->campos()[$campo]), 'la queja en ' . $campo . ': ' . json_encode($error->campos(), JSON_UNESCAPED_UNICODE));

    return (string) $error->campos()[$campo];
};

$estado = static fn (callable $trabajo): int => Afirma::lanza(ErrorHttp::class, $trabajo)->estado();

// Lo que las pruebas comparten: la sucursal del primer caso.
$ids = [];

return [
    'una sucursal se da de alta con su dirección y el teléfono se limpia' => function () use ($org, $bd, $ip, $s, &$ids): void {
        $ids['sucursal'] = $org->guardaSucursal(null, [
            'nombre'    => '  Sucursal   Centro ' . $s,
            'clave'     => 'c' . $s,
            'calle'     => 'Av. Juárez',
            'numero'    => '120',
            'cp'        => '72000',
            'id_estado' => '21',
            'telefono'  => '+52 (222) 123-4567',
        ], $ip);

        $fila = $bd->fila('SELECT nombre, clave, telefono, cp, id_estado, id_estatus FROM sucursal WHERE id = ?', [$ids['sucursal']]);
        Afirma::igual('Sucursal Centro ' . $s, $fila['nombre'], 'los espacios de más se quitan');
        Afirma::igual(strtoupper('c' . $s), $fila['clave'], 'la clave va en mayúsculas');
        Afirma::igual('2221234567', $fila['telefono'], 'el teléfono sin lada de país ni signos');
        Afirma::igual(4, (int) $fila['id_estatus'], 'nace activa');
    },

    'la sucursal rechaza nombre vacío, código postal y teléfono mal escritos, todos a la vez' => function () use ($org, $ip): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $org->guardaSucursal(null, [
            'nombre'   => '   ',
            'cp'       => '720',
            'telefono' => '12345',
        ], $ip));

        Afirma::igual(422, $error->estado());
        Afirma::igual(['nombre', 'cp', 'telefono'], array_keys($error->campos()), 'los tres campos');
    },

    'dos sucursales activas no se llaman igual, pero una dada de baja libera el nombre' => function () use ($org, $ip, $s, $quejaEn): void {
        $quejaEn('nombre', fn () => $org->guardaSucursal(null, ['nombre' => 'Sucursal Centro ' . $s], $ip), 'el duplicado');

        $otra = $org->guardaSucursal(null, ['nombre' => 'Sucursal Vieja ' . $s], $ip);
        $org->cambiaEstatusSucursal($otra, false, $ip);
        $nueva = $org->guardaSucursal(null, ['nombre' => 'Sucursal Vieja ' . $s], $ip);

        Afirma::cierto($nueva !== $otra, 'es otra sucursal');
        Afirma::lanza(ErrorHttp::class, fn () => $org->cambiaEstatusSucursal($otra, true, $ip), 'reactivar la vieja choca con la nueva');
    },

    'la clave de tickets es corta, sin espacios, y no se repite entre las activas' => function () use ($org, $ip, $s, $quejaEn): void {
        $quejaEn('clave', fn () => $org->guardaSucursal(null, ['nombre' => 'Clave Mala ' . $s, 'clave' => 'con espacio'], $ip), 'el espacio');
        $quejaEn('clave', fn () => $org->guardaSucursal(null, ['nombre' => 'Clave Larga ' . $s, 'clave' => 'NUEVECAR9'], $ip), 'nueve caracteres');
        $quejaEn('clave', fn () => $org->guardaSucursal(null, ['nombre' => 'Clave Repetida ' . $s, 'clave' => 'C' . $s], $ip), 'la repetida');
    },

    'la edición cambia los datos y queda en la bitácora con el antes y el después' => function () use ($org, $bd, $ip, $s, $idAdmin, &$ids): void {
        $org->guardaSucursal($ids['sucursal'], [
            'nombre'   => 'Sucursal Centro ' . $s,
            'clave'    => 'C' . $s,
            'telefono' => '2229876543',
        ], $ip);

        $asiento = $bd->fila(
            "SELECT antes, despues FROM bitacora
             WHERE entidad = 'sucursal' AND id_entidad = ? AND accion = 'edita_sucursal' AND id_usuario = ?
             ORDER BY id DESC LIMIT 1",
            [$ids['sucursal'], $idAdmin]
        );

        Afirma::noNulo($asiento, 'el asiento');
        Afirma::igual('••••••••67', json_decode((string) $asiento['antes'], true)['telefono'], 'el antes, enmascarado');
        Afirma::igual('••••••••43', json_decode((string) $asiento['despues'], true)['telefono'], 'el después, enmascarado');
    },

    'la baja y la reactivación quedan en la bitácora' => function () use ($org, $bd, $ip, &$ids): void {
        $org->cambiaEstatusSucursal($ids['sucursal'], false, $ip);
        Afirma::igual(3, (int) $bd->valor('SELECT id_estatus FROM sucursal WHERE id = ?', [$ids['sucursal']]), 'dada de baja');
        $org->cambiaEstatusSucursal($ids['sucursal'], true, $ip);
        Afirma::igual(4, (int) $bd->valor('SELECT id_estatus FROM sucursal WHERE id = ?', [$ids['sucursal']]), 'otra vez activa');
        Afirma::igual(1, (int) $bd->valor(
            "SELECT COUNT(*) FROM bitacora WHERE entidad = 'sucursal' AND id_entidad = ? AND accion = 'da_de_baja_sucursal'",
            [$ids['sucursal']]
        ), 'la baja');
    },

    'una sucursal con personal activo no se da de baja' => function () use ($org, $bd, $ip, $s): void {
        $sola = $org->guardaSucursal(null, ['nombre' => 'Sucursal Con Gente ' . $s], $ip);
        Pruebas\Semilla::usuario($bd, 'org.almacen.' . $s, 'almacen', 'contraseña-larga-x', $sola);

        $error = Afirma::lanza(ErrorHttp::class, fn () => $org->cambiaEstatusSucursal($sola, false, $ip));
        Afirma::contiene('una persona del personal', $error->getMessage());
    },

    'quien no es administrador sólo ve su sucursal y no toca las demás' => function () use ($org, $bd, $ip, $s, $servicioDe, $estado, &$ids): void {
        $suya = $org->guardaSucursal(null, ['nombre' => 'Sucursal Propia ' . $s], $ip);
        $idSup = Pruebas\Semilla::usuario($bd, 'org.gerente.' . $s, 'gerente', 'contraseña-larga-x', $suya);
        $sup   = $servicioDe($idSup);

        Afirma::igual([$suya], array_map('intval', array_column($sup->sucursales('todas'), 'id')), 'la lista');

        Afirma::igual(403, $estado(fn () => $sup->sucursal($ids['sucursal'])), 'la ficha de otra');
        Afirma::igual(403, $estado(fn () => $sup->guardaSucursal($ids['sucursal'], ['nombre' => 'Otra ' . $s], $ip)), 'editar otra');
        Afirma::igual(403, $estado(fn () => $sup->cambiaEstatusSucursal($ids['sucursal'], false, $ip)), 'dar de baja otra');
        Afirma::igual(403, $estado(fn () => $sup->guardaSucursal(null, ['nombre' => 'Intrusa ' . $s], $ip)), 'dar de alta una sucursal');
        Afirma::igual($suya, $sup->guardaSucursal($suya, ['nombre' => 'Sucursal Propia ' . $s, 'telefono' => '2221112233'], $ip), 'editar la suya');
    },

    'se limpia lo que la prueba creó' => function () use ($bd, $limpia, $s): void {
        $limpia();

        Afirma::igual(0, (int) $bd->valor("SELECT COUNT(*) FROM usuario WHERE usuario LIKE 'org.%'"), 'los usuarios');
        Afirma::igual(0, (int) $bd->valor('SELECT COUNT(*) FROM sucursal WHERE nombre LIKE ?', ['% ' . $s]), 'las sucursales');
    },
];
