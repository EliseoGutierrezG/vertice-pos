<?php
declare(strict_types=1);

use Modelos\Dispositivos;
use Modelos\Tokens;
use Modelos\Usuarios;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Nucleo\Registro;
use Pruebas\Afirma;
use Servicios\Personal;

/**
 * Personal, usuarios y equipos, contra la base de pruebas.
 *
 * El criterio: **no se puede crear un usuario sin personal**. Aquí se prueba
 * por las dos puertas —el servicio y la base— y lo que lo rodea: la
 * contraseña temporal, la baja que se bloquea, los equipos y el alcance.
 *
 * Lo sembrado lo crean usuarios `per.` o lleva el sufijo de la corrida; al
 * final se borra eso y nada más.
 */
$config = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd     = new BaseDatos($config);

$s = substr(bin2hex(random_bytes(3)), 0, 6);

// La organización se siembra a mano: no es lo que se prueba aquí.
$org = [];

$limpia = static function () use ($bd, &$org): void {
    $actores = array_map('intval', array_column($bd->filas("SELECT id FROM usuario WHERE usuario LIKE 'per.%'"), 'id'));

    if ($actores !== []) {
        $m = implode(', ', array_fill(0, count($actores), '?'));

        $personas = array_map('intval', array_column($bd->filas('SELECT id FROM personal WHERE creado_por IN (' . $m . ')', $actores), 'id'));
        if ($personas !== []) {
            $mp = implode(', ', array_fill(0, count($personas), '?'));
            $bd->ejecuta('UPDATE personal SET id_superior = NULL WHERE id IN (' . $mp . ')', $personas);
        }

        Pruebas\Semilla::borraUsuarios($bd, 'per.');

        if ($personas !== []) {
            $bd->ejecuta('DELETE FROM personal WHERE id IN (' . $mp . ')', $personas);
        }
    }

    Pruebas\Semilla::borraUsuarios($bd, 'per.');

    foreach (['sucursal'] as $tabla) {
        foreach ($org[$tabla] ?? [] as $id) {
            $bd->ejecuta('DELETE FROM ' . $tabla . ' WHERE id = ?', [$id]);
        }
    }
};

$bitacora = new Bitacora($bd, new Registro(sys_get_temp_dir() . '/timon-pruebas', false));
$usuarios = new Usuarios($bd);

$servicioDe = static function (int $idUsuario) use ($bd, $bitacora, $usuarios): Personal {
    $identidad = new Identidad($bd);
    $identidad->establece($idUsuario);

    return new Personal($bd, $bitacora, $identidad, $usuarios, new Dispositivos($bd));
};

/*
 * Lo sembrado se crea con la primera prueba que corre, no al cargar el
 * archivo: `correr.php` carga todos los archivos aunque se le pida uno solo,
 * y una siembra al cargar se quedaba en la base cada vez que el filtro dejaba
 * fuera la prueba que limpia.
 */
$idAdmin = 0;
$per     = null;

$siembra = static function () use ($bd, $s, $limpia, &$org, &$idAdmin, &$per, $servicioDe): void {
    if ($per !== null) {
        return;
    }

    $limpia();

    $org['sucursal'] = [
        'a' => $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Sucursal A ' . $s]),
        'b' => $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Sucursal B ' . $s]),
    ];

    $idAdmin = Pruebas\Semilla::usuario($bd, 'per.admin', 'administrador');
    $per     = $servicioDe($idAdmin);
};

$ip  = '127.0.0.1';

$puesto = static fn (string $clave): string => (string) $bd->valor('SELECT id FROM puesto WHERE clave = ?', [$clave]);

$quejaEn = static function (string $campo, callable $trabajo, string $que = ''): string {
    $error = Afirma::lanza(ErrorHttp::class, $trabajo, $que);
    Afirma::igual(422, $error->estado(), 'el código de ' . ($que ?: $campo));
    Afirma::cierto(isset($error->campos()[$campo]), 'la queja en ' . $campo . ': ' . json_encode($error->campos(), JSON_UNESCAPED_UNICODE));

    return (string) $error->campos()[$campo];
};

$estado = static fn (callable $trabajo): int => Afirma::lanza(ErrorHttp::class, $trabajo)->estado();

/** Una persona con lo mínimo. */
$persona = static function (string $nombre, string $clavePuesto, ?int $idSucursal, array $mas = []) use (&$per, $ip, $s, $puesto): int {
    return $per->guardaPersona(null, [
        'nombre'           => $nombre,
        'apellido_paterno' => 'Prueba' . $s,
        'id_puesto'        => $puesto($clavePuesto),
        'id_sucursal'        => $idSucursal === null ? '' : (string) $idSucursal,
        'fecha_ingreso'    => '2026-09-01',
    ] + $mas, $ip);
};

$ids = [];

$pruebas = [
    'una persona se da de alta con sus datos limpios' => function () use ($persona, $bd, &$org, &$ids): void {
        $ids['mesero'] = $persona('  Ana   María ', 'mesero', $org['sucursal']['a'], [
            'telefono' => '+52 222 555 0101',
            'correo'   => 'Ana@Ejemplo.MX',
        ]);

        $fila = $bd->fila('SELECT nombre, telefono, correo, id_estatus FROM personal WHERE id = ?', [$ids['mesero']]);
        Afirma::igual('Ana María', $fila['nombre']);
        Afirma::igual('2225550101', $fila['telefono']);
        Afirma::igual('ana@ejemplo.mx', $fila['correo']);
        Afirma::igual(4, (int) $fila['id_estatus']);
    },

    'el alta rechaza todo lo que falta o está mal, de una vez' => function () use (&$per, $ip): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $per->guardaPersona(null, [
            'nombre'        => ' ',
            'correo'        => 'sin-arroba',
            'telefono'      => '123',
            'fecha_ingreso' => '2026-02-30',
        ], $ip));

        Afirma::igual(422, $error->estado());
        Afirma::igual(
            ['apellido_paterno', 'correo', 'fecha_ingreso', 'id_puesto', 'nombre', 'telefono'],
            (static function (array $c): array { $k = array_keys($c); sort($k); return $k; })($error->campos())
        );
    },

    'quien no es administrador trabaja en una sucursal; el administrador puede no tener' => function () use (&$per, $ip, $s, $puesto, $quejaEn, $persona, &$ids): void {
        $quejaEn('id_sucursal', fn () => $per->guardaPersona(null, [
            'nombre' => 'Sin', 'apellido_paterno' => 'Sucursal' . $s, 'id_puesto' => $puesto('gerente'), 'fecha_ingreso' => '2026-09-01',
        ], $ip));

        $ids['otroAdmin'] = $persona('Beto', 'administrador', null);
        Afirma::cierto($ids['otroAdmin'] > 0);
    },

    'no se puede crear un usuario sin personal: la base lo impide' => function () use ($bd): void {
        Afirma::lanza(Throwable::class, fn () => $bd->ejecuta(
            'INSERT INTO usuario (id_personal, usuario, clave_hash) VALUES (NULL, ?, ?)',
            ['per.huerfano', 'x']
        ), 'sin persona');

        Afirma::lanza(Throwable::class, fn () => $bd->ejecuta(
            'INSERT INTO usuario (id_personal, usuario, clave_hash) VALUES (?, ?, ?)',
            [999999999, 'per.fantasma', 'x']
        ), 'con una persona que no existe');

        Afirma::igual(0, (int) $bd->valor("SELECT COUNT(*) FROM usuario WHERE usuario IN ('per.huerfano', 'per.fantasma')"));
    },

    'ni el servicio: sin persona es 404' => function () use (&$per, $ip, $estado): void {
        Afirma::igual(404, $estado(fn () => $per->creaUsuario(999999999, 'per.nadie', $ip)));
    },

    'el usuario nace de la persona con una contraseña temporal que no queda en la bitácora' => function () use (&$per, $bd, $usuarios, $ip, &$ids): void {
        $clave = $per->creaUsuario($ids['mesero'], ' Per.Ana ', $ip);

        Afirma::cierto(preg_match('/^[a-hj-km-np-z2-9]{4}-[a-hj-km-np-z2-9]{4}-[a-hj-km-np-z2-9]{4}$/', $clave) === 1, 'el formato: ' . $clave);

        $usuario = $usuarios->porPersonal($ids['mesero']);
        Afirma::igual('per.ana', $usuario['usuario'], 'en minúsculas');
        Afirma::igual(1, (int) $usuario['cambiar_clave'], 'temporal');
        Afirma::noNulo($usuarios->autentica('per.ana', $clave), 'la temporal sirve para entrar');

        $rastro = (string) $bd->valor(
            "SELECT despues FROM bitacora WHERE entidad = 'usuario' AND id_entidad = ? AND accion = 'crea_usuario'",
            [$usuario['id']]
        );
        Afirma::falso(str_contains($rastro, $clave), 'la bitácora no guarda la contraseña');
        Afirma::contiene('temporal', $rastro);

        $ids['usrMesero'] = (int) $usuario['id'];
    },

    'una persona tiene un solo usuario, con nombre válido y que no se repite' => function () use (&$per, $ip, $estado, $quejaEn, $persona, &$org, &$ids): void {
        Afirma::igual(409, $estado(fn () => $per->creaUsuario($ids['mesero'], 'per.otra', $ip)), 'un segundo usuario');

        $ids['cocinero'] = $persona('Carlos', 'cocina', $org['sucursal']['a']);
        $quejaEn('usuario', fn () => $per->creaUsuario($ids['cocinero'], 'per.ana', $ip), 'repetido');
        $quejaEn('usuario', fn () => $per->creaUsuario($ids['cocinero'], 'Per Carlos!', $ip), 'con espacios y signos');
        $quejaEn('usuario', fn () => $per->creaUsuario($ids['cocinero'], 'pe', $ip), 'muy corto');

        $per->creaUsuario($ids['cocinero'], 'per.carlos', $ip);
    },

    'se propone un nombre de usuario sin acentos que no existe' => function () use (&$per): void {
        Afirma::igual('jnunez', $per->sugiereUsuario(['nombre' => 'Júlio', 'apellido_paterno' => 'Núñez']));
    },

    'restablecer la contraseña emite otra temporal y corta los equipos' => function () use (&$per, $bd, $usuarios, $ip, &$ids): void {
        $telefono = (new Dispositivos($bd))->registraOEncuentra($ids['usrMesero'], 'per-tel-' . $ids['usrMesero'], 'Moto');
        $token    = (new Tokens($bd))->emite($ids['usrMesero'], (int) $telefono['id']);
        $ids['telefono'] = (int) $telefono['id'];

        $nueva = $per->restableceClave($ids['mesero'], $ip);

        Afirma::noNulo($usuarios->autentica('per.ana', $nueva), 'la nueva sirve');
        Afirma::nulo((new Tokens($bd))->resuelve($token), 'el token de antes ya no vale');
        Afirma::igual(1, (int) $usuarios->porPersonal($ids['mesero'])['cambiar_clave'], 'sigue siendo temporal');
    },

    'la contraseña propia pide la actual, doce caracteres y no el nombre de usuario' => function () use ($servicioDe, &$per, $usuarios, $ip, $quejaEn, &$ids): void {
        $temporal = $per->restableceClave($ids['mesero'], $ip);
        $ana      = $servicioDe($ids['usrMesero']);

        $quejaEn('actual', fn () => $ana->cambiaClavePropia('no-es-esa', 'una frase bastante larga', 'una frase bastante larga', $ip));
        $quejaEn('nueva', fn () => $ana->cambiaClavePropia($temporal, 'corta', 'corta', $ip), 'corta');
        $quejaEn('nueva', fn () => $ana->cambiaClavePropia($temporal, 'soy per.ana y ya', 'soy per.ana y ya', $ip), 'con su usuario');
        $quejaEn('nueva', fn () => $ana->cambiaClavePropia($temporal, $temporal, $temporal, $ip), 'la misma');
        $quejaEn('confirma', fn () => $ana->cambiaClavePropia($temporal, 'una frase bastante larga', 'otra frase distinta', $ip), 'sin coincidir');

        $ana->cambiaClavePropia($temporal, 'una frase bastante larga', 'una frase bastante larga', $ip);

        Afirma::igual(0, (int) $usuarios->porPersonal($ids['mesero'])['cambiar_clave'], 'ya no es temporal');
        Afirma::noNulo($usuarios->autentica('per.ana', 'una frase bastante larga'), 'la nueva sirve');
        Afirma::nulo($usuarios->autentica('per.ana', $temporal), 'la temporal ya no');
    },

    'otra persona de la misma sucursal' => function () use (&$per, $ip, $persona, &$org, &$ids): void {
        $ids['mesero2'] = $persona('Diana', 'mesero', $org['sucursal']['a']);
        $per->creaUsuario($ids['mesero2'], 'per.diana', $ip);
        Afirma::cierto($ids['mesero2'] > 0);
    },

    'el superior no cierra un círculo' => function () use (&$per, $ip, $s, $puesto, $quejaEn, $persona, &$org, &$ids): void {
        $ids['gerente'] = $persona('Elena', 'gerente', $org['sucursal']['a']);
        $base = ['apellido_paterno' => 'Prueba' . $s, 'fecha_ingreso' => '2026-09-01', 'id_sucursal' => (string) $org['sucursal']['a']];

        $per->guardaPersona($ids['mesero2'], $base + ['nombre' => 'Diana', 'id_puesto' => $puesto('mesero'), 'id_superior' => (string) $ids['gerente']], $ip);

        $quejaEn('id_superior', fn () => $per->guardaPersona($ids['gerente'], $base + [
            'nombre' => 'Elena', 'id_puesto' => $puesto('gerente'), 'id_superior' => (string) $ids['mesero2'],
        ], $ip), 'jefe de su jefe');
        $quejaEn('id_superior', fn () => $per->guardaPersona($ids['gerente'], $base + [
            'nombre' => 'Elena', 'id_puesto' => $puesto('gerente'), 'id_superior' => (string) $ids['gerente'],
        ], $ip), 'su propio superior');
    },

    'la baja se bloquea con gente a su cargo' => function () use (&$per, $ip, &$ids): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $per->cambiaEstatusPersona($ids['gerente'], false, $ip));
        Afirma::igual(409, $error->estado());
        Afirma::contiene('una persona a su cargo', $error->getMessage());
    },

    'al darse de baja pierde el acceso y sus tokens' => function () use (&$per, $bd, $usuarios, $ip, &$org, &$ids): void {
        $telefono = (new Dispositivos($bd))->registraOEncuentra($ids['usrMesero'], 'per-tel-' . $ids['usrMesero'], 'Moto');
        $token    = (new Tokens($bd))->emite($ids['usrMesero'], (int) $telefono['id']);

        $per->cambiaEstatusPersona($ids['mesero'], false, $ip);

        Afirma::igual(3, (int) $bd->valor('SELECT id_estatus FROM personal WHERE id = ?', [$ids['mesero']]));
        Afirma::noNulo($bd->valor('SELECT fecha_baja FROM personal WHERE id = ?', [$ids['mesero']]), 'la fecha de baja');
        Afirma::igual(3, (int) $usuarios->porPersonal($ids['mesero'])['id_estatus'], 'el usuario');
        Afirma::nulo((new Tokens($bd))->resuelve($token), 'el token');
        Afirma::nulo($usuarios->autentica('per.ana', 'una frase bastante larga'), 'ya no entra');
    },

    'al reactivarla, el acceso vuelve aparte y con una contraseña nueva' => function () use (&$per, $usuarios, $ip, $estado, &$ids): void {
        $per->cambiaEstatusPersona($ids['mesero'], true, $ip);
        Afirma::igual(3, (int) $usuarios->porPersonal($ids['mesero'])['id_estatus'], 'el acceso sigue bloqueado');
        Afirma::igual(409, $estado(fn () => $per->restableceClave($ids['mesero'], $ip)), 'no se restablece bloqueado');

        $clave = (string) $per->cambiaEstatusUsuario($ids['mesero'], true, $ip);

        Afirma::nulo($usuarios->autentica('per.ana', 'una frase bastante larga'), 'la de antes no');
        Afirma::noNulo($usuarios->autentica('per.ana', $clave), 'la nueva sí');
    },

    'nadie se da de baja, se bloquea ni se cambia el puesto a sí mismo' => function () use (&$per, $bd, $ip, $s, $puesto, $estado, $quejaEn, &$idAdmin): void {
        $yo = (int) $bd->valor('SELECT id_personal FROM usuario WHERE id = ?', [$idAdmin]);

        Afirma::igual(409, $estado(fn () => $per->cambiaEstatusPersona($yo, false, $ip)), 'la baja');
        Afirma::igual(409, $estado(fn () => $per->cambiaEstatusUsuario($yo, false, $ip)), 'el bloqueo');
        Afirma::igual(409, $estado(fn () => $per->restableceClave($yo, $ip)), 'el restablecimiento');
        $quejaEn('id_puesto', fn () => $per->guardaPersona($yo, [
            'nombre' => 'Prueba', 'apellido_paterno' => 'per.admin', 'id_puesto' => $puesto('gerente'),
            'id_sucursal' => (string) $bd->valor('SELECT MIN(id) FROM sucursal WHERE id_estatus = 4'), 'fecha_ingreso' => '2026-09-01',
        ], $ip), 'el puesto');
    },

    'un equipo sólo se autoriza a quien trabaja con la app' => function () use (&$per, $bd, $ip, $estado, $persona, &$org, &$ids): void {
        // El almacén trabaja en el panel, no en la app.
        $ids['almacen'] = $persona('Fer', 'almacen', $org['sucursal']['a']);
        $per->creaUsuario($ids['almacen'], 'per.fer', $ip);
        $idAlmacen = (int) $bd->valor('SELECT id FROM usuario WHERE id_personal = ?', [$ids['almacen']]);

        $delAlmacen = (new Dispositivos($bd))->registraOEncuentra($idAlmacen, 'per-tel-alm', 'Del almacén');
        Afirma::igual(409, $estado(fn () => $per->autorizaDispositivo((int) $delAlmacen['id'], $ip)), 'almacén');

        $per->autorizaDispositivo($ids['telefono'], $ip);
        Afirma::igual(1, (int) $bd->valor('SELECT autorizado FROM dispositivo WHERE id = ?', [$ids['telefono']]));

        $per->retiraDispositivo($ids['telefono'], $ip);
        Afirma::igual(0, (int) $bd->valor('SELECT autorizado FROM dispositivo WHERE id = ?', [$ids['telefono']]));
    },

    'quien no es administrador sólo ve y toca la gente de su sucursal' => function () use (&$per, $servicioDe, $ip, $s, $puesto, $estado, &$org, &$ids): void {
        $idSup = (int) Pruebas\Semilla::usuario(new BaseDatos(Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2))), 'per.jefe.' . $s, 'gerente', 'contraseña-larga-x', $org['sucursal']['b']);
        $jefe  = $servicioDe($idSup);

        $sucursales = array_unique(array_map('intval', array_column($jefe->personas('todas'), 'id_sucursal')));
        Afirma::igual([$org['sucursal']['b']], array_values($sucursales), 'la lista');

        Afirma::igual(403, $estado(fn () => $jefe->persona($ids['mesero'])), 'la ficha de otra sucursal');
        Afirma::igual(403, $estado(fn () => $jefe->persona($ids['otroAdmin'])), 'la de un administrador');
        Afirma::igual(403, $estado(fn () => $jefe->guardaPersona(null, [
            'nombre' => 'Intruso', 'apellido_paterno' => 'Prueba' . $s, 'id_puesto' => $puesto('mesero'),
            'id_sucursal' => (string) $org['sucursal']['a'], 'fecha_ingreso' => '2026-09-01',
        ], $ip)), 'dar de alta en otra sucursal');
        Afirma::igual(403, $estado(fn () => $jefe->guardaPersona(null, [
            'nombre' => 'Intruso', 'apellido_paterno' => 'Prueba' . $s, 'id_puesto' => $puesto('administrador'),
            'id_sucursal' => (string) $org['sucursal']['b'], 'fecha_ingreso' => '2026-09-01',
        ], $ip)), 'dar el puesto de administrador');
        Afirma::falso(in_array('Administrador', $jefe->opcionesPuesto(), true), 'ni se lo ofrece');
    },

    'se limpia lo que la prueba creó' => function () use ($bd, $limpia, $s): void {
        $limpia();

        Afirma::igual(0, (int) $bd->valor("SELECT COUNT(*) FROM usuario WHERE usuario LIKE 'per.%'"), 'los usuarios');
        Afirma::igual(0, (int) $bd->valor('SELECT COUNT(*) FROM personal WHERE apellido_paterno LIKE ?', ['%' . $s]), 'el personal');
        Afirma::igual(0, (int) $bd->valor('SELECT COUNT(*) FROM sucursal WHERE nombre LIKE ?', ['% ' . $s]), 'las sucursales');
    },
];

return array_map(static fn (callable $prueba): Closure => static function () use ($prueba, $siembra): void {
    $siembra();
    $prueba();
}, $pruebas);
