<?php
declare(strict_types=1);

use Pruebas\Afirma;
use Servicios\AppMovil;

return [
    'salud anuncia la versión mínima y solo ofrece un APK que existe' => function (): void {
        $raiz = sys_get_temp_dir() . '/timon-app-movil-' . bin2hex(random_bytes(4));
        mkdir($raiz . '/config', 0700, true);
        mkdir($raiz . '/movil', 0700);
        try {
            Afirma::nulo(AppMovil::datos($raiz)['apk']);
            file_put_contents($raiz . '/config/app-movil.php', "<?php return ['version'=>'1.10.0','minima'=>'1.9.0'];");
            file_put_contents($raiz . '/movil/comanda.apk', 'paquete de prueba');
            Afirma::igual(['app_minima' => '1.9.0', 'app_version' => '1.10.0', 'apk' => '/api/v1/app/apk'], AppMovil::datos($raiz));
            file_put_contents($raiz . '/config/app-movil.php', "<?php return ['version'=>'1.0.0','minima'=>'2.0.0'];");
            Afirma::lanza(RuntimeException::class, fn () => AppMovil::datos($raiz));
        } finally {
            unlink($raiz . '/config/app-movil.php');
            unlink($raiz . '/movil/comanda.apk');
            rmdir($raiz . '/config');
            rmdir($raiz . '/movil');
            rmdir($raiz);
        }
    },
];
