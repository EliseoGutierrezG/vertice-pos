<?php
declare(strict_types=1);

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Nucleo\Registro;
use Nucleo\Seguridad\FirmaLiberacion;
use Pruebas\Afirma;
use Servicios\Actualizador;
use Servicios\Liberaciones;

/**
 * Las actualizaciones de las computadoras de sucursal: la firma de los
 * paquetes, su registro y asignación en el central, y el actualizador que los
 * instala por versiones (`liberaciones/<id>` y el enlace `actual`).
 *
 * El actualizador trabaja en una carpeta temporal y con los guiones simulados:
 * lo que se prueba es el orden, la firma y el regreso a la versión anterior.
 */
$bd = new BaseDatos(Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2)));
$tmp = sys_get_temp_dir() . '/timon-liberaciones-' . bin2hex(random_bytes(3));
mkdir($tmp, 0700, true);

$limpia = static function () use ($bd): void {
    $bd->ejecuta("UPDATE instalacion SET liberacion_asignada = NULL WHERE nombre LIKE 'Liberación %'");
    $bd->ejecuta("DELETE FROM liberacion WHERE notas LIKE 'prueba-liberacion%'");
    $bd->ejecuta("DELETE i FROM instalacion i JOIN sucursal s ON s.id = i.id_sucursal WHERE s.nombre LIKE 'Liberación %'");
    $bd->ejecuta("DELETE FROM sucursal WHERE nombre LIKE 'Liberación %'");
    Pruebas\Semilla::borraUsuarios($bd, 'lib.');
};
$borraCarpeta = static function (string $ruta) use (&$borraCarpeta): void {
    if (is_link($ruta) || is_file($ruta)) {
        unlink($ruta);
        return;
    }
    foreach (is_dir($ruta) ? (scandir($ruta) ?: []) : [] as $n) {
        if ($n !== '.' && $n !== '..') {
            $borraCarpeta($ruta . '/' . $n);
        }
    }
    if (is_dir($ruta)) {
        rmdir($ruta);
    }
};
$limpia();

$s = bin2hex(random_bytes(3));
$idAdmin = Pruebas\Semilla::usuario($bd, 'lib.admin.' . $s, 'administrador');
$identidad = new Identidad($bd);
$identidad->establece($idAdmin);
$bitacora = new Bitacora($bd, new Registro($tmp . '/registros', false));
$par = FirmaLiberacion::generaPar();
$otro = FirmaLiberacion::generaPar();
$liberaciones = new Liberaciones($bd, $bitacora, $identidad, $tmp . '/central', $par['publica']);

$libres = array_diff(range(2, 99), array_map('intval', array_column($bd->filas('SELECT desplazamiento FROM instalacion'), 'desplazamiento')));
$instalacion = static function (string $nombre) use ($bd, &$libres): int {
    $sucursal = $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', [$nombre]);
    return $bd->inserta('INSERT INTO instalacion (nombre, id_sucursal, desplazamiento, secreto_hash) VALUES (?, ?, ?, ?)',
        [$nombre, $sucursal, array_shift($libres), hash('sha256', random_bytes(16))]);
};
$una = $instalacion('Liberación una ' . $s);
$otraInst = $instalacion('Liberación otra ' . $s);

/**
 * Un paquete como el de `prepara-liberacion-sucursal.sh`: la carpeta timon/
 * con su `config/liberacion.php`, empacada y firmada.
 *
 * @return array{0:string,1:array<string,mixed>}
 */
$paquete = static function (string $id, int $esquema, string $privada) use ($tmp, $par, $borraCarpeta): array {
    $fuente = $tmp . '/fuente-' . bin2hex(random_bytes(3));
    mkdir($fuente . '/timon/config', 0700, true);
    mkdir($fuente . '/timon/almacenamiento', 0700, true);
    file_put_contents($fuente . '/timon/config/liberacion.php',
        "<?php\nreturn " . var_export(['id' => $id, 'creada_en' => null, 'fuente_sha256' => null, 'esquema' => $esquema], true) . ";\n");
    file_put_contents($fuente . '/timon/config/firma-liberaciones.pub', $par['publica'] . "\n");
    file_put_contents($fuente . '/timon/LEEME', 'versión ' . $id);
    $tar = $tmp . '/' . str_replace(':', '_', $id) . '-' . bin2hex(random_bytes(2)) . '.tar';
    $archivo = new PharData($tar);
    $archivo->buildFromDirectory($fuente);
    $archivo->compress(Phar::GZ);
    unset($archivo);
    unlink($tar);
    $borraCarpeta($fuente);

    return [$tar . '.gz', FirmaLiberacion::firma($id, $esquema, $tar . '.gz', $privada)];
};

[$p1, $d1] = $paquete('20261120T100000Z-aaaaaaaaaaaa', 26, $par['privada']);

return [
    'la firma liga el paquete a su nombre y a su llave' => function () use ($p1, $d1, $par, $otro): void {
        Afirma::cierto(FirmaLiberacion::verifica($d1, $par['publica']), 'la firma buena pasa');
        Afirma::falso(FirmaLiberacion::verifica($d1, $otro['publica']), 'con otra llave no');
        Afirma::falso(FirmaLiberacion::verifica(['id' => 'otro-nombre'] + $d1, $par['publica']), 'con otro nombre no');
        Afirma::falso(FirmaLiberacion::verifica(['esquema' => 99] + $d1, $par['publica']), 'con otro esquema no');
        FirmaLiberacion::verificaPaquete($d1, $p1, $par['publica']);
        $alterado = $p1 . '.alterado';
        copy($p1, $alterado);
        $f = fopen($alterado, 'r+');
        fseek($f, 100);
        fwrite($f, 'X');
        fclose($f);
        Afirma::lanza(RuntimeException::class, fn () => FirmaLiberacion::verificaPaquete($d1, $alterado, $par['publica']), 'un byte cambiado');
        unlink($alterado);
    },

    'el central solo registra paquetes firmados con su llave' => function () use ($liberaciones, $paquete, $p1, $d1, $otro): void {
        [$ajeno, $dAjeno] = $paquete('20261120T110000Z-bbbbbbbbbbbb', 26, $otro['privada']);
        $error = Afirma::lanza(ErrorHttp::class, fn () => $liberaciones->registra($ajeno, $dAjeno, 'prueba-liberacion'));
        Afirma::igual(422, $error->estado(), 'firma ajena');

        Afirma::igual($d1['id'], $liberaciones->registra($p1, $d1, 'prueba-liberacion uno'), 'la buena entra');
        Afirma::igual($d1['id'], $liberaciones->registra($p1, $d1, 'prueba-liberacion uno'), 'repetirla no hace nada');
        Afirma::lanza(ErrorHttp::class, fn () => $liberaciones->registra($ajeno, ['id' => $d1['id']] + $dAjeno, 'prueba-liberacion'),
            'otro paquete con el mismo nombre');
    },

    'cada computadora baja solo la versión que se le asignó' => function () use ($liberaciones, $una, $otraInst, $d1): void {
        Afirma::nulo($liberaciones->asignada($una), 'sin asignar, se queda como está');
        $liberaciones->asigna($una, $d1['id']);
        Afirma::igual($d1, $liberaciones->asignada($una), 'trae el descriptor firmado');
        Afirma::cierto(is_file($liberaciones->paqueteDe($una, $d1['id'])), 'a la asignada le da el paquete');
        Afirma::lanza(ErrorHttp::class, fn () => $liberaciones->paqueteDe($otraInst, $d1['id']), 'a otra computadora no');
        Afirma::lanza(ErrorHttp::class, fn () => $liberaciones->asigna($una, 'no-existe-1'), 'una versión que no existe');

        $liberaciones->anota($una, 'Versión lista. Espera a que cierren las cuentas.', false);
        $liberaciones->asigna($una, null);
        Afirma::nulo($liberaciones->asignada($una), 'se puede quitar');
    },

    'el actualizador instala por versiones y enlaza lo compartido' => function () use ($tmp, $bd, $par, $paquete, $p1, $d1): void {
        $base = $tmp . '/sucursal';
        mkdir($base . '/compartido/config', 0700, true);
        mkdir($base . '/compartido/almacenamiento/respaldos', 0700, true);
        $config = "<?php\nreturn ['host' => '127.0.0.1', 'base' => 'base_de_sucursal', 'usuario' => 'u', 'clave' => 'c', 'puerto' => 3306];\n";
        file_put_contents($base . '/compartido/config/bd.php', $config);
        file_put_contents($base . '/compartido/config/bd.pruebas.php', $config);
        $llamadas = [];
        $ejecuta = static function (array $orden) use (&$llamadas, $base): array {
            $llamadas[] = basename($orden[0]) . (isset($orden[2]) ? ' ' . $orden[2] : '');
            if (basename($orden[0]) === 'respaldo.php') {
                file_put_contents($base . '/compartido/almacenamiento/respaldos/r-' . count($llamadas) . '.sql.gz', 'respaldo');
            }
            return [str_contains($orden[1] ?? '', 'rompe') ? 1 : 0, 'salida simulada'];
        };
        $actualizador = new Actualizador($base, $bd, null, $ejecuta, static fn (): int => 4);

        $actualizador->instala($p1, $d1, $par['publica'], false);
        Afirma::igual($d1['id'], $actualizador->instalada(), 'la primera queda instalada');
        Afirma::igual([], $llamadas, 'la primera no toca la base');
        Afirma::cierto(is_link($base . '/actual/config/bd.php'), 'la configuración se enlaza');
        Afirma::cierto(is_link($base . '/actual/almacenamiento') && is_dir($base . '/actual/almacenamiento/respaldos'), 'el almacenamiento es el compartido');

        [$p2, $d2] = $paquete('20261121T100000Z-cccccccccccc', 27, $par['privada']);
        $actualizador->instala($p2, $d2, $par['publica']);
        Afirma::igual($d2['id'], $actualizador->instalada(), 'la segunda queda instalada');
        Afirma::igual(['respaldo.php', 'migraciones.php --acepto=base_de_sucursal', 'disparadores-replica.php', 'actualiza.php'],
            $llamadas, 'respaldo, migraciones, disparadores y comprobación, en ese orden');
        Afirma::cierto(is_file($base . '/compartido/recarga'), 'pide recargar Apache');
        Afirma::cierto(is_dir($base . '/liberaciones/' . Actualizador::carpeta($d1['id'])), 'la anterior se conserva para regresar');
    },

    'si la versión nueva no arranca, regresa sola a la anterior' => function () use ($tmp, $bd, $par, $paquete): void {
        $base = $tmp . '/sucursal';
        $ejecuta = static function (array $orden) use ($base): array {
            if (basename($orden[0]) === 'respaldo.php') {
                file_put_contents($base . '/compartido/almacenamiento/respaldos/r-rompe.sql.gz', 'respaldo');
            }
            return [basename($orden[0]) === 'actualiza.php' && str_contains($orden[1] ?? '', 'dddddddddddd') ? 1 : 0, 'Se esperaba otra versión'];
        };
        $actualizador = new Actualizador($base, $bd, null, $ejecuta, static fn (): int => 4);
        $antes = $actualizador->instalada();
        [$p3, $d3] = $paquete('20261122T100000Z-dddddddddddd', 27, $par['privada']);

        $error = Afirma::lanza(RuntimeException::class, fn () => $actualizador->instala($p3, $d3, $par['publica']));
        Afirma::contiene('se regresó a la anterior', $error->getMessage(), 'lo dice');
        Afirma::igual($antes, $actualizador->instalada(), 'sigue la que funcionaba');
    },

    'un paquete alterado no se instala' => function () use ($tmp, $bd, $par, $paquete): void {
        $base = $tmp . '/sucursal';
        $actualizador = new Actualizador($base, $bd, null, static fn (array $o): array => [0, '']);
        $antes = $actualizador->instalada();
        [$p4, $d4] = $paquete('20261123T100000Z-eeeeeeeeeeee', 27, $par['privada']);
        file_put_contents($p4, 'basura', FILE_APPEND);

        Afirma::lanza(RuntimeException::class, fn () => $actualizador->instala($p4, $d4, $par['publica']));
        Afirma::igual($antes, $actualizador->instalada(), 'no se movió');
        Afirma::falso(is_dir($base . '/liberaciones/' . Actualizador::carpeta($d4['id'])), 'ni se extrajo');
    },

    'con movimiento a media tarde, espera' => function () use ($tmp, $bd, $bitacora, $idAdmin): void {
        $bitacora->registra('prueba', 'movimiento', idUsuario: $idAdmin);
        $media = new Actualizador($tmp . '/sucursal', $bd, null, null, static fn (): int => 16);
        Afirma::noNulo($media->esperaPor(), 'a las 16 con movimiento');
        $madrugada = (new Actualizador($tmp . '/sucursal', $bd, null, null, static fn (): int => 4))->esperaPor();
        Afirma::cierto($madrugada === null || !str_contains($madrugada, 'minutos'), 'de madrugada no espera el rato quieto');
    },

    'al final se limpia lo sembrado' => function () use ($limpia, $borraCarpeta, $tmp, $bd): void {
        $limpia();
        $borraCarpeta($tmp);
        Afirma::igual(0, (int) $bd->valor("SELECT COUNT(*) FROM sucursal WHERE nombre LIKE 'Liberación %'"), 'sin sucursales de prueba');
    },
];
