<?php
declare(strict_types=1);

use Dominio\Totp;
use Modelos\IntentosAcceso;
use Modelos\Parametros;
use Modelos\Usuarios;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Configuracion;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Registro;
use Nucleo\Seguridad\Cifrador;
use Pruebas\Afirma;
use Servicios\SegundoFactor;
use Servicios\Seguridad;

/**
 * El interruptor del segundo factor en la pantalla «Seguridad» (bitácora 98).
 *
 * Lo que importa es lo que **no** deja hacer: con la sesión abierta, pero sin
 * la contraseña o sin el código, no se apaga. Contra el catálogo de verdad,
 * como `SegundoFactorParametroPrueba`; al final la clave queda como estaba.
 */

$raiz = dirname(__DIR__, 2);
$bd   = new BaseDatos(Configuracion::baseDatos($raiz));
$ip   = '127.0.0.1';

$prefijo = 'segpant.';
$limpia  = static function () use ($bd, $prefijo): void {
    $bd->ejecuta("DELETE FROM intento_acceso WHERE ambito = 'seguridad'");
    Pruebas\Semilla::borraUsuarios($bd, $prefijo);
};
$limpia();
$admin      = Pruebas\Semilla::usuario($bd, $prefijo . 'admin', 'administrador', 'contraseña-admin-x');
$supervisor = Pruebas\Semilla::usuario($bd, $prefijo . 'gerente', 'gerente', 'contraseña-super-x');

$bitacora = new Bitacora($bd, new Registro(sys_get_temp_dir() . '/app-totp-pruebas', false));
$cifrador = new Cifrador((string) Configuracion::seguridad($raiz)['llave_totp']);
$totp     = new Totp();

$renglones = $bd->filas('SELECT clave, valor, descripcion, vigente_desde, vigente_hasta FROM parametro WHERE clave = ?', [SegundoFactor::PARAMETRO]);
$restaura  = static function () use ($bd, $renglones): void {
    $bd->ejecuta('DELETE FROM parametro WHERE clave = ?', [SegundoFactor::PARAMETRO]);
    foreach ($renglones as $r) {
        $bd->ejecuta(
            'INSERT INTO parametro (clave, valor, descripcion, vigente_desde, vigente_hasta) VALUES (?, ?, ?, ?, ?)',
            [$r['clave'], $r['valor'], $r['descripcion'], $r['vigente_desde'], $r['vigente_hasta']]
        );
    }
};
register_shutdown_function($restaura);
$restaura();

/** Servicios nuevos en cada caso, que comparten `Parametros` como en el contenedor. */
$arma = static function () use ($bd, $cifrador, $totp, $bitacora): array {
    $parametros = new Parametros($bd);
    $sf = new SegundoFactor($bd, $cifrador, $totp, $bitacora, $parametros);

    return [new Seguridad($bd, $parametros, $sf, new Usuarios($bd), new IntentosAcceso($bd), $bitacora), $sf];
};
$valorHoy = static fn (): string => (string) (new Parametros($bd))->valor(SegundoFactor::PARAMETRO, '1');

// El administrador tiene Authenticator, como cualquiera que entró con él encendido.
[, $sf] = $arma();
$alta = $sf->prepara($admin, $ip);
$sf->confirma($admin, $totp->codigo($alta['secreto'], time() - 30), $ip);
$secreto = $alta['secreto'];

$sinCambio = static function () use ($valorHoy): void {
    Afirma::igual('1', $valorHoy(), 'sigue encendido');
};

return [
    'sólo el administrador tiene el permiso' => function () use ($bd, $admin, $supervisor): void {
        $usuarios = new Usuarios($bd);
        Afirma::cierto($usuarios->puede($admin, 'seguridad_admin'));
        Afirma::falso($usuarios->puede($supervisor, 'seguridad_admin'));
    },

    'encendido, sin contraseña ni código no se apaga' => function () use ($arma, $admin, $ip, $sinCambio): void {
        [$seguridad] = $arma();
        $error = Afirma::lanza(ErrorHttp::class, fn () => $seguridad->cambiaSegundoFactor(false, $admin, [], $ip));
        Afirma::igual(422, $error->estado());
        Afirma::igual(['clave', 'codigo'], array_keys($error->campos()));
        $sinCambio();
    },

    'encendido, la contraseña sola no basta' => function () use ($arma, $admin, $ip, $sinCambio): void {
        [$seguridad] = $arma();
        $error = Afirma::lanza(ErrorHttp::class, fn () => $seguridad->cambiaSegundoFactor(false, $admin, ['clave' => 'contraseña-admin-x'], $ip));
        Afirma::igual(422, $error->estado());
        Afirma::igual(['codigo'], array_keys($error->campos()));
        $sinCambio();
    },

    'la contraseña equivocada se rechaza' => function () use ($arma, $admin, $ip, $totp, $secreto, $sinCambio): void {
        [$seguridad] = $arma();
        $error = Afirma::lanza(ErrorHttp::class, fn () => $seguridad->cambiaSegundoFactor(
            false, $admin, ['clave' => 'otra-cosa-x', 'codigo' => $totp->codigo($secreto)], $ip
        ));
        Afirma::igual(422, $error->estado());
        Afirma::igual(['clave'], array_keys($error->campos()));
        $sinCambio();
    },

    'el código equivocado se rechaza' => function () use ($arma, $admin, $ip, $totp, $secreto, $sinCambio): void {
        [$seguridad] = $arma();
        $error = Afirma::lanza(ErrorHttp::class, fn () => $seguridad->cambiaSegundoFactor(
            false, $admin, ['clave' => 'contraseña-admin-x', 'codigo' => $totp->codigo($secreto, time() + 3600)], $ip
        ));
        Afirma::igual(422, $error->estado());
        Afirma::igual(['codigo'], array_keys($error->campos()));
        $sinCambio();
    },

    'con contraseña y código se apaga, y queda quién lo hizo' => function () use ($bd, $arma, $admin, $ip, $totp, $secreto, $valorHoy): void {
        [$seguridad, $sf] = $arma();
        $seguridad->cambiaSegundoFactor(false, $admin, ['clave' => 'contraseña-admin-x', 'codigo' => $totp->codigo($secreto)], $ip);
        Afirma::igual('0', $valorHoy());
        Afirma::falso($sf->activo(), 'el mismo servicio ya lo ve apagado');
        Afirma::igual(1, (int) $bd->valor(
            "SELECT COUNT(*) FROM bitacora WHERE modulo = 'seguridad' AND accion = 'apaga_segundo_factor' AND id_usuario = ?",
            [$admin]
        ));
    },

    'apagado, apagarlo otra vez es conflicto' => function () use ($arma, $admin, $ip): void {
        [$seguridad] = $arma();
        $error = Afirma::lanza(ErrorHttp::class, fn () => $seguridad->cambiaSegundoFactor(false, $admin, ['clave' => 'contraseña-admin-x'], $ip));
        Afirma::igual(409, $error->estado());
    },

    'apagado, se enciende con la contraseña y el mismo día corrige su renglón' => function () use ($bd, $arma, $admin, $ip, $valorHoy): void {
        [$seguridad] = $arma();
        $seguridad->cambiaSegundoFactor(true, $admin, ['clave' => 'contraseña-admin-x'], $ip);
        Afirma::igual('1', $valorHoy());
        Afirma::igual(1, (int) $bd->valor(
            'SELECT COUNT(*) FROM parametro WHERE clave = ? AND vigente_desde = CURDATE()',
            [SegundoFactor::PARAMETRO]
        ), 'un solo renglón de hoy');
        Afirma::cierto((string) $bd->valor(
            'SELECT descripcion FROM parametro WHERE clave = ? AND vigente_desde = CURDATE()',
            [SegundoFactor::PARAMETRO]
        ) !== '', 'conserva la descripción');
    },

    'la pantalla enseña los dos cambios y la cobertura' => function () use ($arma, $prefijo): void {
        [$seguridad] = $arma();
        $estado = $seguridad->estado();
        Afirma::cierto($estado['activo']);
        $nuestros = array_values(array_filter($estado['cambios'], fn (array $c): bool => str_starts_with((string) $c['usuario'], $prefijo)));
        Afirma::igual(2, count($nuestros));
        Afirma::igual('1', json_decode((string) $nuestros[0]['despues'], true)['valor'], 'el más reciente primero');
        Afirma::cierto($estado['cobertura']['configurados'] >= 1 && $estado['cobertura']['total'] >= 2);
    },

    'al terminar, la clave queda como estaba' => function () use ($bd, $restaura, $renglones, $limpia): void {
        $restaura();
        Afirma::igual(count($renglones), (int) $bd->valor('SELECT COUNT(*) FROM parametro WHERE clave = ?', [SegundoFactor::PARAMETRO]));
        $limpia();
    },
];
