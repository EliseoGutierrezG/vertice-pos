<?php
declare(strict_types=1);

use Nucleo\Aplicacion;
use Nucleo\BaseDatos;
use Nucleo\Contenedor;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Pruebas\Afirma;
use Pruebas\Semilla;
use Servicios\CartaImpresa;
use Servicios\Promociones;

/**
 * La carta impresa se arma con lo que hay en el panel: orden, leyenda,
 * porción, preparaciones, promociones y textos del pie. Todo dentro de una
 * transacción que se deshace al final.
 */
$conCarta = static function (callable $prueba): void {
    $contenedor = (new Aplicacion(dirname(__DIR__, 2)))->contenedor();
    $bd = $contenedor->obtiene(BaseDatos::class);
    $revertir = new RuntimeException('Retirar los datos de la prueba');
    try {
        $bd->transaccion(static function () use ($contenedor, $bd, $prueba, $revertir): void {
            $sufijo = bin2hex(random_bytes(4));
            $contenedor->obtiene(Identidad::class)->establece(Semilla::usuario($bd, 'carta.' . $sufijo, 'administrador'));
            $sucursal = $bd->inserta('INSERT INTO sucursal (nombre, clave, telefono, id_estatus) VALUES (?, ?, ?, 4)',
                ['Carta ' . $sufijo, 'K' . strtoupper(substr($sufijo, 0, 5)), '2221841728']);
            $pescados = $bd->inserta('INSERT INTO categoria_menu (nombre, orden, descripcion) VALUES (?, 2, ?)',
                ['Pescados ' . $sufijo, 'Acompañados de lechugas frescas.']);
            $entradas = $bd->inserta('INSERT INTO categoria_menu (nombre, orden) VALUES (?, 1)', ['Entradas ' . $sufijo]);
            $ids = [];
            foreach ([
                ['zz', $entradas, 'Ceviche de pescado', '', 1, 220],
                ['aa', $entradas, 'Empanada de camarón', '3 pzas', 2, 138],
                ['mojarra', $pescados, 'Mojarra', '600 gr', 1, 220],
            ] as [$llave, $categoria, $nombre, $porcion, $orden, $precio]) {
                $ids[$llave] = $bd->inserta("INSERT INTO platillo (id_categoria, nombre, porcion, orden, preparacion) VALUES (?, ?, ?, ?, 'caliente')",
                    [$categoria, $nombre, $porcion, $orden]);
                $bd->ejecuta('INSERT INTO platillo_sucursal (id_sucursal, id_platillo, precio) VALUES (?, ?, ?)', [$sucursal, $ids[$llave], $precio]);
            }
            foreach ([['Frita', 0], ['Mojo', 0], ['Con pulpo extra', 20]] as [$nombre, $suplemento]) {
                $bd->ejecuta('INSERT INTO modificador_platillo (id_platillo, nombre, suplemento) VALUES (?, ?, ?)', [$ids['mojarra'], $nombre, $suplemento]);
            }
            $prueba($contenedor, $bd, $sucursal, $ids);
            throw $revertir;
        });
    } catch (RuntimeException $error) {
        if ($error !== $revertir) {
            throw $error;
        }
    }
};
$hoy = static fn (): string => (new DateTimeImmutable())->format('Y-m-d');

return [
    'la carta sigue el orden capturado y lleva leyenda, porción y preparaciones' => static function () use ($conCarta): void {
        $conCarta(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal): void {
            $carta = $contenedor->obtiene(CartaImpresa::class)->arma($sucursal);
            $nombres = array_map(static fn (array $c): string => strtok($c['nombre'], ' '), $carta['categorias']);
            Afirma::igual(['Entradas', 'Pescados'], $nombres, 'las categorías por su orden');
            Afirma::igual(['Ceviche de pescado', 'Empanada de camarón'], array_column($carta['categorias'][0]['platillos'], 'nombre'),
                'los platillos por su orden, no por nombre');
            Afirma::igual('3 pzas', $carta['categorias'][0]['platillos'][1]['porcion'], 'la porción');
            Afirma::igual('Acompañados de lechugas frescas.', $carta['categorias'][1]['leyenda'], 'la leyenda de la categoría');
            Afirma::igual('Frita + mojo + con pulpo extra +$20', $carta['categorias'][1]['platillos'][0]['preparaciones'],
                'las preparaciones en el orden capturado, con su suplemento');
            Afirma::igual('Sabor único', $carta['textos']['carta_sello'], 'los textos del pie');
        });
    },

    'una promoción vigente sale en el platillo y en el recuadro; sin promociones no' => static function () use ($conCarta, $hoy): void {
        $conCarta(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, array $ids) use ($hoy): void {
            $contenedor->obtiene(Promociones::class)->guarda(0, ['nombre' => 'Mojarra del martes', 'tipo' => 'precio', 'precio_especial' => '180',
                'desde' => $hoy(), 'dias' => range(1, 7), 'platillos' => [$ids['mojarra']], 'sucursales' => [$sucursal]]);
            $servicio = $contenedor->obtiene(CartaImpresa::class);
            $carta = $servicio->arma($sucursal);
            $mojarra = $carta['categorias'][1]['platillos'][0];
            Afirma::igual('180.00', $mojarra['promocion']['precio_promocion'], 'el precio con promoción');
            Afirma::igual('220.00', $mojarra['precio'], 'el precio de lista se conserva para tacharlo');
            Afirma::igual(['Mojarra'], $carta['promociones'][0]['platillos'], 'el recuadro dice a qué platillos aplica');
            Afirma::igual('Todos los días', $carta['promociones'][0]['horario'], 'y cuándo');

            $sin = $servicio->arma($sucursal, false);
            Afirma::igual([], $sin['promociones'], 'sin promociones no hay recuadro');
            Afirma::igual(null, $sin['categorias'][1]['platillos'][0]['promocion'], 'ni insignia');
        });
    },

    'la huella cambia cuando cambia algo de la hoja' => static function () use ($conCarta): void {
        $conCarta(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, array $ids): void {
            $servicio = $contenedor->obtiene(CartaImpresa::class);
            $antes = $servicio->huella($sucursal);
            Afirma::igual($antes, $servicio->huella($sucursal), 'sin cambios, la misma huella');
            $bd->ejecuta('UPDATE platillo_sucursal SET precio = 140 WHERE id_platillo = ? AND id_sucursal = ?', [$ids['aa'], $sucursal]);
            Afirma::cierto($antes !== $servicio->huella($sucursal), 'un precio nuevo cambia la huella');
        });
    },

    'los textos del pie se validan y quedan con su historia' => static function () use ($conCarta): void {
        $conCarta(static function (Contenedor $contenedor, BaseDatos $bd): void {
            $servicio = $contenedor->obtiene(CartaImpresa::class);
            $textos = $servicio->textos();
            $error = Afirma::lanza(ErrorHttp::class, static fn () => $servicio->guardaTextos(['carta_fundacion' => '20'] + $textos),
                'un año de dos cifras no pasa');
            Afirma::contiene('cuatro cifras', json_encode($error->campos(), JSON_UNESCAPED_UNICODE), 'el mensaje junto al campo');
            $servicio->guardaTextos(['carta_lema' => 'Frescura del puerto'] + $textos);
            Afirma::igual('Frescura del puerto', $servicio->textos()['carta_lema'], 'el lema nuevo');
        });
    },

    'la carta del PDF trae datos que el panel acepta' => static function (): void {
        $carta = require dirname(__DIR__) . '/fixtures/carta-el-timon.php';
        Afirma::igual(9, count($carta), 'las nueve categorías del PDF');
        $categorias = [];
        foreach ($carta as [$categoria, $orden, $leyenda, $platillos]) {
            $categorias[] = $categoria;
            Afirma::cierto(mb_strlen($leyenda) <= 300, 'leyenda de ' . $categoria);
            $nombres = array_column($platillos, 0);
            Afirma::igual(count($nombres), count(array_unique($nombres)), 'sin platillos repetidos en ' . $categoria);
            foreach ($platillos as [$nombre, $porcion, $precio, $area]) {
                Afirma::cierto(mb_strlen($nombre) <= 100 && mb_strlen($porcion) <= 40, 'medidas de ' . $nombre);
                Afirma::cierto(preg_match('/^\d+(\.\d{2})?$/D', $precio) === 1 && (float) $precio > 0, 'precio de ' . $nombre);
                Afirma::cierto(in_array($area, ['fria', 'caliente', 'barra'], true), 'área de ' . $nombre);
            }
        }
        Afirma::igual(count($categorias), count(array_unique($categorias)), 'sin categorías repetidas');
    },
];
