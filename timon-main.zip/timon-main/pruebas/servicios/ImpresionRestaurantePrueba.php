<?php
declare(strict_types=1);

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Nucleo\Registro;
use Pruebas\Afirma;
use Servicios\ImpresionRestaurante;
use Servicios\OperacionRestaurante;

/**
 * Las impresoras de una sucursal, contra la base de pruebas.
 *
 * Cada área tiene una sola impresora. Lo que aquí se cuida es que actualizar
 * una no pise la de otra área: el guardado va por `id` y el área se decide
 * al agregar.
 *
 * Todo lo sembrado cuelga de sucursales «Impresión …» y de usuarios `imp.`.
 */
$config = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd     = new BaseDatos($config);

$limpia = static function () use ($bd): void {
    $sucursales = array_map(
        static fn (array $f): int => (int) $f['id'],
        $bd->filas("SELECT id FROM sucursal WHERE nombre LIKE 'Impresión %'")
    );
    foreach ($sucursales as $id) {
        $bd->ejecuta('DELETE FROM trabajo_impresion WHERE id_sucursal = ? ORDER BY id DESC', [$id]);
        $bd->ejecuta('DELETE FROM impresora WHERE id_sucursal = ?', [$id]);
        $bd->ejecuta('DELETE FROM evento_sucursal WHERE id_sucursal = ?', [$id]);
    }
    Pruebas\Semilla::borraUsuarios($bd, 'imp.');
    foreach ($sucursales as $id) {
        $bd->ejecuta('DELETE FROM sucursal WHERE id = ?', [$id]);
    }
};

$limpia();

$s = substr(bin2hex(random_bytes(3)), 0, 6);
$idAdmin  = Pruebas\Semilla::usuario($bd, 'imp.admin.' . $s, 'administrador');
$bitacora = new Bitacora($bd, new Registro(sys_get_temp_dir() . '/timon-pruebas', false));
$identidad = new Identidad($bd);
$identidad->establece($idAdmin);
$impresion = new ImpresionRestaurante($bd, new OperacionRestaurante($bd, $bitacora, $identidad,
    new Servicios\Instalaciones($bd, $bitacora, $identidad, new Nucleo\Instalacion(null))));

$sucursal = $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Impresión ' . $s]);
$otra     = $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Impresión ajena ' . $s]);

$fila = static fn (int $id): ?array => $bd->fila('SELECT nombre, ip, puerto, ancho, destino, activa FROM impresora WHERE id = ?', [$id]);

$ids = [];

return [
    'una impresora se agrega en su área' => function () use ($impresion, $sucursal, $fila, &$ids): void {
        $ids['fria'] = $impresion->registra($sucursal, 0, ['nombre' => 'Fría', 'ip' => '192.168.10.15', 'destino' => 'fria']);
        $ids['caja'] = $impresion->registra($sucursal, 0, ['nombre' => 'Caja', 'ip' => '192.168.10.16', 'destino' => 'caja', 'ancho' => '58']);

        Afirma::igual('fria', $fila($ids['fria'])['destino'], 'el área de la primera');
        Afirma::igual('58', $fila($ids['caja'])['ancho'], 'el rollo de la segunda');
        Afirma::igual(2, count($impresion->lista($sucursal)), 'las dos en la lista');
    },

    'un área no admite una segunda impresora' => function () use ($impresion, $sucursal, $fila, &$ids): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $impresion->registra(
            $sucursal, 0, ['nombre' => 'Intrusa', 'ip' => '192.168.10.99', 'destino' => 'fria']
        ));

        Afirma::igual(422, $error->estado(), 'el código');
        Afirma::cierto(isset($error->campos()['destino']), 'la queja va en el área');
        Afirma::igual('Fría', $fila($ids['fria'])['nombre'], 'la impresora del área no se pisó');
    },

    'actualizar conserva el área aunque llegue otra' => function () use ($impresion, $sucursal, $fila, &$ids): void {
        $impresion->registra($sucursal, $ids['fria'], [
            'nombre' => 'Fría nueva', 'ip' => '10.0.0.8', 'puerto' => 9101, 'destino' => 'caja', 'activa' => 0,
        ]);

        $fria = $fila($ids['fria']);
        Afirma::igual('Fría nueva', $fria['nombre'], 'el nombre');
        Afirma::igual('10.0.0.8', $fria['ip'], 'la dirección');
        Afirma::igual(9101, (int) $fria['puerto'], 'el puerto');
        Afirma::igual(0, (int) $fria['activa'], 'el estado');
        Afirma::igual('fria', $fria['destino'], 'el área sigue siendo la suya');

        $caja = $fila($ids['caja']);
        Afirma::igual('Caja', $caja['nombre'], 'la impresora de caja quedó intacta');
        Afirma::igual('192.168.10.16', $caja['ip'], 'con su dirección');
    },

    'una impresora de otra sucursal no se actualiza' => function () use ($impresion, $otra, $fila, &$ids): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $impresion->registra(
            $otra, $ids['caja'], ['nombre' => 'Ajena', 'ip' => '192.168.10.20']
        ));

        Afirma::igual(404, $error->estado(), 'el código');
        Afirma::igual('Caja', $fila($ids['caja'])['nombre'], 'no cambió');
    },

    'la dirección tiene que ser de la red privada' => function () use ($impresion, $sucursal): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $impresion->registra(
            $sucursal, 0, ['nombre' => 'Pública', 'ip' => '8.8.8.8', 'destino' => 'barra']
        ));

        Afirma::igual(422, $error->estado(), 'el código');
        Afirma::cierto(isset($error->campos()['ip']), 'la queja va en la dirección');
    },

    'se limpia lo que la prueba creó' => function () use ($bd, $limpia): void {
        $limpia();

        Afirma::igual(0, (int) $bd->valor("SELECT COUNT(*) FROM sucursal WHERE nombre LIKE 'Impresión %'"), 'las sucursales');
        Afirma::igual(0, (int) $bd->valor("SELECT COUNT(*) FROM usuario WHERE usuario LIKE 'imp.%'"), 'los usuarios');
    },
];
