<?php
declare(strict_types=1);

use Nucleo\Aplicacion;
use Nucleo\BaseDatos;
use Nucleo\Contenedor;
use Nucleo\Identidad;
use Pruebas\Afirma;
use Pruebas\Semilla;
use Servicios\Comandas;
use Servicios\Promociones;

/**
 * Las promociones dentro de la comanda: se fijan al capturar y lo que rebajan
 * se recalcula cuando cambian los renglones. Todo dentro de una transacción
 * que se deshace al final.
 */
$conDatos = static function (callable $prueba): void {
    $contenedor = (new Aplicacion(dirname(__DIR__, 2)))->contenedor();
    $bd = $contenedor->obtiene(BaseDatos::class);
    $revertir = new RuntimeException('Retirar los datos de la prueba');
    try {
        $bd->transaccion(static function () use ($contenedor, $bd, $prueba, $revertir): void {
            $sufijo = bin2hex(random_bytes(4));
            $usuario = Semilla::usuario($bd, 'promo.' . $sufijo, 'administrador');
            $contenedor->obtiene(Identidad::class)->establece($usuario);
            $sucursal = $bd->inserta('INSERT INTO sucursal (nombre, clave) VALUES (?, ?)',
                ['Promo ' . $sufijo, 'P' . strtoupper(substr($sufijo, 0, 5))]);
            $categoria = $bd->inserta('INSERT INTO categoria_menu (nombre) VALUES (?)', ['Promo ' . $sufijo]);
            $taco = $bd->inserta("INSERT INTO platillo (id_categoria,nombre,preparacion) VALUES (?, 'Taco de pulpo', 'caliente')", [$categoria]);
            $ceviche = $bd->inserta("INSERT INTO platillo (id_categoria,nombre,preparacion) VALUES (?, 'Ceviche', 'fria')", [$categoria]);
            $bd->ejecuta('INSERT INTO platillo_sucursal (id_sucursal,id_platillo,precio) VALUES (?, ?, 125), (?, ?, 220)',
                [$sucursal, $taco, $sucursal, $ceviche]);
            $extra = $bd->inserta("INSERT INTO modificador_platillo (id_platillo,nombre,suplemento) VALUES (?, 'Con queso', 20)", [$taco]);
            $prueba($contenedor, $bd, $sucursal, ['taco' => $taco, 'ceviche' => $ceviche, 'extra' => $extra]);
            throw $revertir;
        });
    } catch (RuntimeException $error) {
        if ($error !== $revertir) {
            throw $error;
        }
    }
};
$hoy = static fn (): string => (new DateTimeImmutable())->format('Y-m-d');

return [
    'un 2x1 se aplica solo al capturar y se recalcula al cambiar la cantidad' => static function () use ($conDatos, $hoy): void {
        $conDatos(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, array $p) use ($hoy): void {
            $promos = $contenedor->obtiene(Promociones::class);
            $promos->guarda(0, ['nombre' => 'Tacos al 2x1', 'tipo' => 'nxm', 'lleva' => '2', 'paga' => '1', 'desde' => $hoy(),
                'dias' => range(1, 7), 'platillos' => [$p['taco']], 'sucursales' => [$sucursal]]);
            $comandas = $contenedor->obtiene(Comandas::class);
            $cuenta = $comandas->abrir($sucursal, Semilla::llave(), ['tipo' => 'llevar', 'cliente' => 'Ana'])['id'];
            $uno = $comandas->agregar($sucursal, $cuenta, Semilla::llave(), ['id_platillo' => $p['taco'], 'cantidad' => 1]);
            Afirma::igual('Tacos al 2x1', $uno['promocion'], 'el renglón recibe la promoción');
            Afirma::igual('125.00', $comandas->cuenta($sucursal, $cuenta)['total'], 'una pieza paga completo');

            $comandas->agregar($sucursal, $cuenta, Semilla::llave(), ['id_platillo' => $p['taco'], 'cantidad' => 1, 'modificadores' => [$p['extra']]]);
            $ficha = $comandas->cuenta($sucursal, $cuenta);
            Afirma::igual('145.00', $ficha['total'], 'la pieza gratis es la más barata');

            $comandas->editaItem($sucursal, $cuenta, Semilla::llave(), ['id_item' => $uno['id_item'], 'cantidad' => 3]);
            Afirma::igual('270.00', $comandas->cuenta($sucursal, $cuenta)['total'], 'cuatro piezas, salen gratis las dos más baratas');

            $comandas->cambiaItem($sucursal, $cuenta, Semilla::llave(), ['id_item' => $uno['id_item'], 'estado' => 'cancelado', 'motivo' => 'Prueba'], '127.0.0.1');
            Afirma::igual('145.00', $comandas->cuenta($sucursal, $cuenta)['total'], 'cancelar quita la pieza gratis');
        });
    },

    'el porcentaje y el precio especial rebajan por unidad; gana el mayor' => static function () use ($conDatos, $hoy): void {
        $conDatos(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, array $p) use ($hoy): void {
            $promos = $contenedor->obtiene(Promociones::class);
            $promos->guarda(0, ['nombre' => 'Diez por ciento', 'tipo' => 'porcentaje', 'porcentaje' => '10', 'desde' => $hoy(),
                'dias' => range(1, 7), 'platillos' => [$p['ceviche']], 'sucursales' => [$sucursal]]);
            $segunda = $promos->guarda(0, ['nombre' => 'Ceviche a 180', 'tipo' => 'precio', 'precio_especial' => '180', 'desde' => $hoy(),
                'dias' => range(1, 7), 'platillos' => [$p['ceviche']], 'sucursales' => [$sucursal]]);
            Afirma::igual(1, count($segunda['avisos']), 'avisa del empalme');

            $comandas = $contenedor->obtiene(Comandas::class);
            $cuenta = $comandas->abrir($sucursal, Semilla::llave(), ['tipo' => 'llevar', 'cliente' => 'Ana'])['id'];
            $comandas->agregar($sucursal, $cuenta, Semilla::llave(), ['id_platillo' => $p['ceviche'], 'cantidad' => 2]);
            $ficha = $comandas->cuenta($sucursal, $cuenta);
            Afirma::igual('360.00', $ficha['total'], 'gana el precio especial');
            Afirma::contiene('Ceviche a 180', $ficha['items'][0]['promocion'], 'el nombre queda en el renglón');
        });
    },

    'una promoción pausada, de otro día o de otra sucursal no aplica' => static function () use ($conDatos, $hoy): void {
        $conDatos(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, array $p) use ($hoy): void {
            $promos = $contenedor->obtiene(Promociones::class);
            $otroDia = (int) (new DateTimeImmutable())->modify('+1 day')->format('N');
            $promos->guarda(0, ['nombre' => 'Mañana', 'tipo' => 'porcentaje', 'porcentaje' => '50', 'desde' => $hoy(),
                'dias' => [$otroDia], 'platillos' => [$p['taco']], 'sucursales' => [$sucursal]]);
            $pausada = $promos->guarda(0, ['nombre' => 'Pausada', 'tipo' => 'porcentaje', 'porcentaje' => '50', 'desde' => $hoy(),
                'dias' => range(1, 7), 'platillos' => [$p['taco']], 'sucursales' => [$sucursal]]);
            $promos->cambiaEstado($pausada['id'], 'pausar');
            $otra = $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', ['Otra ' . $sucursal]);
            $promos->guarda(0, ['nombre' => 'Otra sucursal', 'tipo' => 'porcentaje', 'porcentaje' => '50', 'desde' => $hoy(),
                'dias' => range(1, 7), 'platillos' => [$p['taco']], 'sucursales' => [$otra]]);
            Afirma::igual([], $promos->vigentesPara($sucursal, new DateTimeImmutable()), 'ninguna vigente aquí');
            Afirma::igual('pausada', $promos->ficha($pausada['id'])['estado'], 'el estado de la pausada');
        });
    },

    'al separar un 2x1 cada cuenta calcula su parte' => static function () use ($conDatos, $hoy): void {
        $conDatos(static function (Contenedor $contenedor, BaseDatos $bd, int $sucursal, array $p) use ($hoy): void {
            $contenedor->obtiene(Promociones::class)->guarda(0, ['nombre' => 'Tacos al 2x1', 'tipo' => 'nxm', 'lleva' => '2', 'paga' => '1',
                'desde' => $hoy(), 'dias' => range(1, 7), 'platillos' => [$p['taco']], 'sucursales' => [$sucursal]]);
            $comandas = $contenedor->obtiene(Comandas::class);
            $cuenta = $comandas->abrir($sucursal, Semilla::llave(), ['tipo' => 'llevar', 'cliente' => 'Ana'])['id'];
            $comandas->agregar($sucursal, $cuenta, Semilla::llave(), ['id_platillo' => $p['taco'], 'cantidad' => 1]);
            $comandas->agregar($sucursal, $cuenta, Semilla::llave(), ['id_platillo' => $p['taco'], 'cantidad' => 1]);
            Afirma::igual('125.00', $comandas->cuenta($sucursal, $cuenta)['total'], 'juntas pagan una');

            $area = $bd->inserta('INSERT INTO area (id_sucursal, nombre) VALUES (?, ?)', [$sucursal, 'Salón']);
            $mesa = $bd->inserta("INSERT INTO mesa (id_sucursal, id_area, numero, capacidad) VALUES (?, ?, '1', 4)", [$sucursal, $area]);
            $enMesa = $comandas->abrir($sucursal, Semilla::llave(), ['tipo' => 'mesa', 'id_mesa' => $mesa])['id'];
            $origen = $comandas->cuenta($sucursal, $cuenta)['items'][1]['id'];
            $comandas->agregar($sucursal, $enMesa, Semilla::llave(), ['id_platillo' => $p['ceviche'], 'cantidad' => 1]);
            $version = (int) $comandas->cuenta($sucursal, $cuenta)['version'];
            $comandas->transfiere($sucursal, $cuenta, $version, Semilla::llave(), ['id_item' => $origen, 'id_destino' => $enMesa]);
            Afirma::igual('125.00', $comandas->cuenta($sucursal, $cuenta)['total'], 'al quedarse sola paga completa');
            Afirma::igual('345.00', $comandas->cuenta($sucursal, $enMesa)['total'], 'la que la recibe tampoco regala');
        });
    },
];
