#!/usr/bin/env python3
"""La sucursal sigue operando sin internet: un central y una computadora de sucursal en esta Mac.

- El central corre sobre `timon_pruebas`, desde este proyecto.
- La sucursal corre sobre `timon_sucursal_pruebas`, desde una copia del código
  con su propia configuración (la base, `config/instalacion.pruebas.php`).

Se registra la sucursal, baja el catálogo, **se apaga el central** y en la
sucursal se abre una mesa, se envía a cocina, se imprime, se cobra con folio y
se hace el corte. Mientras, en el central cambia un precio y entra una
reservación del sitio. Al volver el central, la subida deja en el central las
mismas cuentas, pagos, folio y corte, y la bajada trae a la sucursal el precio
y la reservación. El central rechaza escribir la operación de esa sucursal.

Las llaves solo viven en la memoria de este guion y en la copia temporal.
"""

from datetime import datetime
import json
import importlib.util
import os
from pathlib import Path
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import uuid

RAIZ = Path(__file__).resolve().parents[1]
PHP = "/opt/homebrew/opt/php@8.3/bin/php"
MARIADB = "/opt/homebrew/opt/mariadb@10.11/bin/mariadb"
BASE_SUCURSAL = "timon_sucursal_pruebas"
LOTE = secrets.token_hex(3)
ENV = {**os.environ, "APP_ENTORNO": "pruebas", "PHP_CLI_SERVER_WORKERS": "4"}
CENTRAL_DECLARADO = RAIZ / "config/instalacion.pruebas.php"
COPIA = Path(tempfile.mkdtemp(prefix="timon-sucursal-"))


def libre():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


PUERTO_CENTRAL, PUERTO_SUCURSAL = libre(), libre()
CENTRAL, SUCURSAL = f"http://127.0.0.1:{PUERTO_CENTRAL}", f"http://127.0.0.1:{PUERTO_SUCURSAL}"


def php(raiz, *args, revisa=True):
    r = subprocess.run([PHP, *map(str, args)], cwd=raiz, env=ENV, capture_output=True, text=True)
    if revisa and r.returncode != 0:
        raise AssertionError(f"{args[0]} salió con {r.returncode}: {(r.stdout + r.stderr)[-400:]}")
    return r


def fixture(raiz, archivo, modo, *args):
    return php(raiz, raiz / f"pruebas/fixtures/{archivo}.php", modo, LOTE, *args).stdout


def fijo(raiz, modo):
    return json.loads(fixture(raiz, "sucursal", modo))


def pide(base, ruta, token=None, datos=None, secreto=None, espera=200):
    cabeceras = {"Accept": "application/json"}
    if token:
        cabeceras["Authorization"] = f"Bearer {token}"
    if secreto:
        cabeceras["X-Equipo"] = secreto
    if datos is not None:
        cabeceras["Content-Type"] = "application/json"
        cabeceras["Idempotency-Key"] = str(uuid.uuid4())
    solicitud = urllib.request.Request(base + "/api/v1" + ruta, json.dumps(datos).encode() if datos is not None else None, cabeceras)
    try:
        respuesta = urllib.request.urlopen(solicitud, timeout=15)
    except urllib.error.HTTPError as error:
        respuesta = error
    with respuesta:
        estado, crudo = respuesta.status, respuesta.read()
    if espera is not None and estado != espera:
        raise AssertionError(f"{ruta}: esperaba {espera}, recibió {estado}: {crudo[:240]!r}")
    salida = json.loads(crudo)
    return salida.get("datos", salida.get("error"))


def levanta(raiz, puerto):
    registros = tempfile.TemporaryFile()
    proceso = subprocess.Popen([PHP, "-S", f"127.0.0.1:{puerto}", "-t", str(raiz / "publico"), str(raiz / "pruebas/servidor-local.php")],
                               cwd=raiz, env=ENV, stdout=registros, stderr=registros, start_new_session=True)
    for _ in range(60):
        try:
            pide(f"http://127.0.0.1:{puerto}", "/salud")
            return proceso, registros
        except (urllib.error.URLError, ConnectionError):
            time.sleep(.1)
    raise RuntimeError(f"No inició el servidor en {puerto}.")


def apaga(servidor):
    if servidor and servidor[0].poll() is None:
        os.killpg(servidor[0].pid, signal.SIGTERM)
        servidor[0].wait(timeout=5)


def sincroniza():
    return php(COPIA, "guiones/sincroniza.php", "--una-vez", revisa=False)


def estado_replica():
    return json.loads((COPIA / "almacenamiento/replica/estado.json").read_text())


def sql(orden):
    subprocess.run([MARIADB, "-e", orden], check=True, capture_output=True, text=True)


def prepara_copia():
    for carpeta in ["controladores", "dominio", "modelos", "nucleo", "servicios", "vistas", "rutas", "publico", "guiones", "esquema", "pruebas"]:
        shutil.copytree(RAIZ / carpeta, COPIA / carpeta, symlinks=True)
    (COPIA / "config").mkdir()
    for archivo in (RAIZ / "config").glob("*.php"):
        if archivo.name.endswith(".pruebas.php") and not archivo.name.startswith("instalacion") or archivo.name == "giro.php":
            shutil.copy2(archivo, COPIA / "config" / archivo.name)
    for carpeta in ["registros", "sesiones-pruebas", "tareas", "alertas", "replica", "imagenes-pruebas", "marca"]:
        (COPIA / "almacenamiento" / carpeta).mkdir(parents=True, exist_ok=True)
    # La misma conexión de pruebas, otra base. Se reescribe sin leer la clave aquí.
    php(RAIZ, "-r", '$c = require $argv[1]; $c["base"] = $argv[2]; file_put_contents($argv[3], "<?php\\nreturn " . var_export($c, true) . ";\\n");',
        RAIZ / "config/bd.pruebas.php", BASE_SUCURSAL, COPIA / "config/bd.pruebas.php")
    usuario = php(RAIZ, "-r", '$c = require $argv[1]; echo $c["usuario"];', RAIZ / "config/bd.pruebas.php").stdout.strip()
    assert usuario.replace("_", "").isalnum(), "usuario de pruebas inesperado"
    sql(f"CREATE DATABASE IF NOT EXISTS {BASE_SUCURSAL} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci; "
        f"GRANT ALL PRIVILEGES ON {BASE_SUCURSAL}.* TO '{usuario}'@'localhost'")
    php(COPIA, "guiones/aplica-esquema.php", f"--acepto={BASE_SUCURSAL}")


def instala_sucursal(registro):
    (COPIA / "config/instalacion.pruebas.php").write_text(
        "<?php\nreturn " + json.dumps({
            "tipo": "sucursal", "desplazamiento": registro["desplazamiento"], "id_sucursal": registro["sucursal"],
            "url_central": CENTRAL, "secreto": registro["secreto"],
        }).replace("{", "[").replace("}", "]").replace('":', '" =>') + ";\n")
    os.chmod(COPIA / "config/instalacion.pruebas.php", 0o600)
    php(COPIA, "guiones/disparadores-replica.php")


def equipo(tipo, rol, datos, plataforma="web"):
    registro = pide(SUCURSAL, "/equipo", datos={"nombre": f"Sucursal {tipo}", "plataforma": plataforma}, espera=201)
    fixture(COPIA, "comanda", "autoriza", registro["codigo"], tipo)
    return pide(SUCURSAL, "/equipo/entrar", datos={"usuario": f"{datos['prefijo']}{rol}", "pin": datos["pin"]},
                secreto=registro["secreto"])["token"]


def prueba():
    prepara_copia()
    CENTRAL_DECLARADO.write_text("<?php\nreturn ['tipo' => 'central'];\n")
    central = levanta(RAIZ, PUERTO_CENTRAL)
    servidores.append(central)
    datos = json.loads(fixture(RAIZ, "comanda", "prepara"))
    registro = fijo(RAIZ, "registra")
    assert registro["desplazamiento"] >= 2
    instala_sucursal(registro)
    print("✓ La sucursal se registra en el central y su copia instala los disparadores.")

    r = sincroniza()
    assert r.returncode == 0, r.stdout + r.stderr
    estado = estado_replica()
    assert estado["arranque"] and estado["alcanzable"], estado
    local = fijo(COPIA, "resumen")
    assert local["precio"] == "125.00" and len(local["mesas"]) == 8, local
    print("✓ Baja el catálogo y lo vivo de la sucursal en el arranque.")

    sucursal = levanta(COPIA, PUERTO_SUCURSAL)
    servidores.append(sucursal)
    apaga(central)
    print("· Se apaga el central: desde aquí la sucursal opera sola.")

    mesero, caja = equipo("mesero", "mesero", datos), equipo("caja", "cajero", datos)
    cocina, impresor = equipo("cocina", "cocina", datos), equipo("impresor", "gerente", datos, "android")
    mesa = datos["mesas"][0]
    cuenta = pide(SUCURSAL, "/cuentas", mesero, {"id_mesa": mesa}, espera=201)["id"]
    assert cuenta % 100 == registro["desplazamiento"], f"el id {cuenta} no es de la sucursal"
    version = pide(SUCURSAL, f"/cuentas/{cuenta}", caja)["version"]
    item = pide(SUCURSAL, f"/cuentas/{cuenta}/items", mesero, {"version": version, "id_platillo": datos["platillo"], "cantidad": 2}, espera=201)
    pide(SUCURSAL, f"/cuentas/{cuenta}/rondas", mesero, {"version": item["version"]}, espera=201)
    assert len(pide(SUCURSAL, "/cocina", cocina)["items"]) == 1
    trabajo = pide(SUCURSAL, "/impresiones/tomar", impresor, {})
    pide(SUCURSAL, f"/impresiones/{trabajo['id']}/confirmar", impresor, {"impreso": True, "intento": trabajo["intento"]})
    print("✓ Sin central: se abre la mesa, se envía a cocina y se imprime.")

    turno = pide(SUCURSAL, "/caja/abrir", caja, {"fondo": "500.00"})["id"]
    version = pide(SUCURSAL, f"/cuentas/{cuenta}", caja)["version"]
    cobrado = pide(SUCURSAL, f"/cuentas/{cuenta}/cobro", caja, {"version": version, "propina": "0.00",
                   "formas": [{"medio": "efectivo", "importe": "250.00", "recibido": "300.00"}]}, espera=201)
    assert cobrado["folio"] == f"{datos['publica']}-000001", cobrado
    cierre = pide(SUCURSAL, "/caja/cerrar", caja, {"id_turno": turno, "efectivo": "750.00"})
    assert cierre["diferencia"] == "0.00", cierre
    print("✓ Sin central: se cobra con folio y el corte cuadra.")

    r = sincroniza()
    estado = estado_replica()
    assert not estado["alcanzable"] and fijo(COPIA, "resumen")["por_subir"] > 0, estado
    salud = pide(SUCURSAL, "/salud")
    assert salud["central"]["alcanzable"] is False and salud["central"]["pendientes"] > 0, salud
    print("✓ La sucursal sabe que no alcanza al central y cuántos cambios esperan.")

    cambio = fijo(RAIZ, "cambia-catalogo")
    central = levanta(RAIZ, PUERTO_CENTRAL)
    servidores.append(central)
    # Simula la versión de esquema anterior sin cambiar columnas: todavía
    # puede subir su operación, pero no debe aplicar el catálogo más reciente.
    ultima = php(COPIA, '-r', 'require "nucleo/Autocargador.php"; Nucleo\\Autocargador::registrar(getcwd()); '
                 '$b=new Nucleo\\BaseDatos(Nucleo\\Configuracion::baseDatos(getcwd())); '
                 '$f=$b->fila("SELECT * FROM migracion_esquema ORDER BY numero DESC LIMIT 1"); '
                 '$b->ejecuta("DELETE FROM migracion_esquema WHERE numero=?",[$f["numero"]]); echo json_encode($f);').stdout
    for _ in range(4):
        r = sincroniza()
        if fijo(COPIA, "resumen")["por_subir"] == 0 and estado_replica()["alcanzable"]:
            break
        time.sleep(2.2)  # La subida deja pasar 2 s por si una transacción sigue abierta.
    else:
        raise AssertionError(f"no terminó de subir: {estado_replica()} {r.stdout[-300:]} {r.stderr[-300:]}")
    print("· Vuelve el central y la sucursal sincroniza.")

    allá, aquí = fijo(RAIZ, "resumen"), fijo(COPIA, "resumen")
    for parte in ["cuentas", "items", "pagos", "turnos", "folio"]:
        assert allá[parte] == aquí[parte], (parte, allá[parte], aquí[parte])
    assert allá["pagos"][0]["folio"] == cobrado["folio"] and not allá["turnos"][0]["abierto"], (allá["pagos"], allá["turnos"])
    assert allá["apuntes_de_sucursal"] > 0
    print("✓ El central tiene las mismas cuentas, pagos, folio y corte que la sucursal, y su bitácora.")

    assert estado_replica()['espera_actualizacion'] and aquí['precio'] == '125.00', estado_replica()
    print('✓ Con esquema atrasado sigue subiendo la operación y espera la actualización antes de bajar el catálogo.')
    php(COPIA, '-r', 'require "nucleo/Autocargador.php"; Nucleo\\Autocargador::registrar(getcwd()); '
        '$b=new Nucleo\\BaseDatos(Nucleo\\Configuracion::baseDatos(getcwd())); $f=json_decode($argv[1],true); '
        '$b->ejecuta("INSERT INTO migracion_esquema (numero,nombre,sha256,aplicada_en) VALUES (?,?,?,?)",'
        '[$f["numero"],$f["nombre"],$f["sha256"],$f["aplicada_en"]]);', ultima)

    r = sincroniza()
    aquí = fijo(COPIA, "resumen")
    assert aquí["precio"] == "140.00" and cambio["reservacion"] in aquí["reservaciones"], aquí
    print("✓ La sucursal recibe el precio nuevo y la reservación del sitio.")

    assert fijo(RAIZ, "escribe")["estado"] == 409
    registro_central = pide(CENTRAL, "/equipo", datos={"nombre": "Equipo en el central", "plataforma": "web"}, espera=201)
    autoriza = php(RAIZ, RAIZ / "pruebas/fixtures/comanda.php", "autoriza", LOTE, registro_central["codigo"], "mesero", revisa=False)
    assert autoriza.returncode != 0, "el central autorizó un equipo de una sucursal local"
    print("✓ El central rechaza escribir la operación de la sucursal local (409).")

    especificacion = importlib.util.spec_from_file_location('actualizaciones_sucursal', RAIZ / 'pruebas/actualizaciones-sucursal.py')
    actualizaciones = importlib.util.module_from_spec(especificacion)
    especificacion.loader.exec_module(actualizaciones)
    actualizaciones.comprueba(sys.modules[__name__], registro, datos)

    verifica = php(RAIZ, "guiones/verifica-bitacora.php", revisa=False)
    assert verifica.returncode == 0, verifica.stdout[-400:] + verifica.stderr[-400:]
    print("✓ La bitácora del central sigue íntegra.")


servidores = []
try:
    prueba()
    print("\nLa sucursal opera sin internet y se pone al día al volver.")
except Exception:
    for proceso, registros in servidores:
        registros.seek(0)
        print("\n".join(registros.read().decode(errors="replace").splitlines()[-12:]))
    raise
finally:
    for servidor in servidores:
        apaga(servidor)
    try:
        fixture(RAIZ, "sucursal", "desregistra")
        fixture(RAIZ, "comanda", "limpia")
    finally:
        CENTRAL_DECLARADO.unlink(missing_ok=True)
        subprocess.run([MARIADB, "-e", f"DROP DATABASE IF EXISTS {BASE_SUCURSAL}"], capture_output=True)
        shutil.rmtree(COPIA, ignore_errors=True)
