"""Ensayo del actualizador real; se invoca desde humo-sucursal.py con su copia aislada."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import urllib.error
import urllib.request


def comprueba(humo, registro, datos):
    # El servidor anterior apunta a la copia fija. Se crea otro servidor con un
    # router estable que resuelve `actual` en cada petición, como Apache.
    base = humo.COPIA.parent / (humo.COPIA.name + '-versiones')
    base.mkdir()
    try:
        _comprueba(humo, registro, datos, base)
    finally:
        shutil.rmtree(base, ignore_errors=True)


def _comprueba(h, registro, datos, base):
    fuente = base / 'fuente'
    shutil.copytree(h.COPIA, fuente)
    compartido = base / 'compartido'
    compartido.mkdir()
    shutil.move(str(fuente / 'config'), compartido / 'config')
    shutil.move(str(fuente / 'almacenamiento'), compartido / 'almacenamiento')
    (fuente / 'config').mkdir()
    shutil.copy2(compartido / 'config/giro.php', fuente / 'config/giro.php')
    # Claves de prueba efímeras: privadas fuera del código y del paquete.
    privada, publica = base / 'firma.llave', fuente / 'config/firma-liberaciones.pub'
    h.php(h.RAIZ, '-r', 'require $argv[1]."/nucleo/Autocargador.php"; Nucleo\\Autocargador::registrar($argv[1]); '
          '$p=Nucleo\\Seguridad\\FirmaLiberacion::generaPar(); file_put_contents($argv[2],$p["privada"]); '
          'chmod($argv[2],0600); file_put_contents($argv[3],$p["publica"]);', h.RAIZ, privada, publica)
    puerto = h.libre()
    url = f'http://127.0.0.1:{puerto}'
    h.php(h.RAIZ, '-r', '$p=$argv[1]; $c=require $p; $c["url_publica"]=$argv[2]; '
          '$c["registros"]=$argv[3]; file_put_contents($p,"<?php\nreturn ".var_export($c,true).";\n");',
          compartido / 'config/app.pruebas.php', url, compartido / 'almacenamiento/registros')
    # La firma por sí sola no da acceso al paquete: la descarga exige la llave
    # registrada y la versión asignada a esa sucursal.
    central_paquetes = h.RAIZ / 'almacenamiento/liberaciones-pruebas'
    central_paquetes.mkdir(exist_ok=True)
    artefactos_central = []

    def paquete(nombre, rota=False):
        arbol = base / nombre / 'timon'
        shutil.copytree(fuente, arbol)
        if rota:
            salud = arbol / 'controladores/Api/Salud.php'
            salud.write_text(salud.read_text().replace("'liberacion' => (string) $this->contenedor->config('liberacion', 'sin-identificar')",
                                                     "'liberacion' => 'salud-rota'"))
        # El paquete de prueba también entrega un APK ficticio para comprobar
        # el transporte local. No se instala en ningún dispositivo.
        (arbol / 'movil').mkdir(exist_ok=True)
        (arbol / 'movil/comanda.apk').write_bytes(b'APK de prueba, no instalable')
        (arbol / 'config/app-movil.php').write_text("<?php return ['version'=>'1.0.1','minima'=>'1.0.0'];")
        (arbol / 'instalacion').mkdir(exist_ok=True)
        identificador = h.php(h.RAIZ, h.RAIZ / 'guiones/genera-liberacion.php', arbol, arbol / 'config', arbol / 'instalacion').stdout.strip()
        salida = base / f'{nombre}.tar.gz'
        with tarfile.open(salida, 'w:gz') as tar:
            tar.add(arbol, arcname='timon')
        # firma-paquete.php exige la llave pública de la raíz: se firma con la
        # clase, sin introducir la llave efímera en el proyecto del usuario.
        firma = base / f'{nombre}.firma.json'
        h.php(h.RAIZ, '-r', 'require $argv[1]."/nucleo/Autocargador.php"; Nucleo\\Autocargador::registrar($argv[1]); '
              '$d=Nucleo\\Seguridad\\FirmaLiberacion::firma($argv[2],(int)$argv[6],$argv[3],trim(file_get_contents($argv[4]))); '
              'file_put_contents($argv[5],json_encode($d));', h.RAIZ, identificador, salida, privada, firma,
              json.loads((arbol / 'instalacion/LIBERACION.json').read_text())['esquema'])
        return salida, firma, identificador

    p1, f1, v1 = paquete('inicial')
    (base / 'liberaciones').mkdir()
    with tarfile.open(p1) as tar:
        tar.extractall(base / 'primera', filter='data')
    shutil.move(base / 'primera/timon', base / 'liberaciones' / v1)
    for config in (compartido / 'config').glob('*.php'):
        destino = base / 'liberaciones' / v1 / 'config' / config.name
        if not destino.exists(): destino.symlink_to(config)
    (base / 'liberaciones' / v1 / 'almacenamiento').symlink_to(compartido / 'almacenamiento')
    (base / 'actual').symlink_to('liberaciones/' + v1)
    router = base / 'router.php'
    router.write_text("<?php clearstatcache(true); $codigo = realpath(__DIR__ . '/actual'); require $codigo . '/publico/index.php';")
    logs = h.tempfile.TemporaryFile()
    proceso = subprocess.Popen([h.PHP, '-S', f'127.0.0.1:{puerto}', '-t', str(base / 'actual/publico'), str(router)],
                               env=h.ENV, stdout=logs, stderr=logs, start_new_session=True)
    servidor = proceso, logs
    h.servidores.append(servidor)
    actual = base / 'actual'

    def ciclo():
        return h.php(actual, actual / 'guiones/actualiza.php', revisa=False)

    def asigna(paquete, firma, identificador):
        h.fixture(h.RAIZ, 'sucursal', 'asigna-liberacion', paquete, firma, central_paquetes, publica)
        artefactos_central.append(central_paquetes / (identificador + '.tar.gz'))

    def descarga(cabeceras, espera, identificador, desde=None):
        headers = dict(cabeceras)
        if desde is not None: headers['Range'] = f'bytes={desde}-'
        req = urllib.request.Request(h.CENTRAL + '/api/v1/replica/liberacion/paquete?id=' + identificador, headers=headers)
        try: respuesta = urllib.request.urlopen(req, timeout=10)
        except urllib.error.HTTPError as e: respuesta = e
        with respuesta:
            assert respuesta.status == espera, (respuesta.status, espera)
            return respuesta.read()

    try:
        for _ in range(50):
            try:
                if h.pide(url, '/salud')['liberacion'] == v1: break
            except urllib.error.URLError: h.time.sleep(.1)
        else: raise AssertionError('No arrancó la instalación por versiones')
        p2, f2, v2 = paquete('siguiente')
        asigna(p2, f2, v2)
        descarga({}, 401, v2)
        descarga({'X-Instalacion': registro['secreto']}, 404, v1)
        assert descarga({'X-Instalacion': registro['secreto']}, 206, v2, 100) == p2.read_bytes()[100:]
        assert descarga({'X-Instalacion': registro['secreto']}, 206, v2, 0) == p2.read_bytes()
        print('✓ La descarga exige la llave de instalación, solo entrega la versión asignada y reanuda con Range.')

        mesero = h.equipo('mesero', 'mesero', datos)
        cuenta = h.pide(h.SUCURSAL, '/cuentas', mesero, {'id_mesa': datos['mesas'][1]}, espera=201)['id']
        r = ciclo()
        assert 'cierren las cuentas' in r.stdout and h.pide(url, '/salud')['liberacion'] == v1, r.stdout + r.stderr
        print('✓ Con una cuenta abierta descarga la versión pero espera, sin cambiar el código.')
        # Solo en esta base aislada, se prepara el estado de cuenta cerrada.
        h.php(actual, '-r', 'require "nucleo/Autocargador.php"; Nucleo\\Autocargador::registrar(getcwd()); '
              '$b=new Nucleo\\BaseDatos(Nucleo\\Configuracion::baseDatos(getcwd())); '
              '$b->ejecuta("UPDATE cuenta SET abierta=NULL, estado=? WHERE id=?",["cancelada",(int)$argv[1]]);', cuenta)
        h.fijo(actual, 'quieta')
        r = ciclo()
        assert r.returncode == 0 and h.pide(url, '/salud')['liberacion'] == v2, r.stdout + r.stderr
        assert list((compartido / 'almacenamiento/respaldos/cifrados').glob('*.sgr')), 'faltó respaldo cifrado'
        salud = h.pide(url, '/salud')
        assert salud['app_minima'] == '1.0.0' and salud['apk'] == '/api/v1/app/apk', salud
        with urllib.request.urlopen(url + salud['apk']) as apk: assert apk.read() == b'APK de prueba, no instalable'
        print('✓ Con todo cerrado instala N+1, verifica salud por HTTP, respalda cifrado y sirve el APK por la red local.')
        p3, f3, v3 = paquete('defectuosa', rota=True)
        asigna(p3, f3, v3)
        h.fijo(actual, 'quieta')
        r = ciclo()
        salud_final = h.pide(url, '/salud')
        assert 'se regresó a la anterior' in r.stdout and salud_final['liberacion'] == v2, (r.stdout + r.stderr, salud_final, str(actual.resolve()), v2)
        print('✓ Si la salud web de N+2 falla, el enlace regresa automáticamente a N+1.')
    finally:
        h.apaga(servidor)
        for ruta in artefactos_central: ruta.unlink(missing_ok=True)
