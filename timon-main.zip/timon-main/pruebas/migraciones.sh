#!/usr/bin/env bash
# Migraciones incrementales y la instalación limpia, sobre la misma base.
#
#   pruebas/migraciones.sh
#
# Arma la base hasta el penúltimo guion y aplica el resto con `migraciones.php`,
# como en el hospedaje. Después instala el SQL consolidado de despliegue sobre
# la base vacía y comprueba que los dos caminos dejan la misma firma de
# esquema: columnas, índices, llaves foráneas y CHECK.
#
# Cada guion nuevo que cambie datos agrega aquí lo que debe quedar cierto
# después de aplicarlo sobre una base con datos.
#
# ⚠️ Borra `timon_pruebas`. Va antes de la reconstrucción de `todo.sh`.

set -u
PHP=/opt/homebrew/opt/php@8.3/bin/php
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
. "$RAIZ/pruebas/exige-entorno.sh"

verde=$'\033[32m'; rojo=$'\033[31m'; gris=$'\033[90m'; nada=$'\033[0m'
pasadas=0; fallas=0
ok()    { printf "  %s✓%s %s\n" "$verde" "$nada" "$1"; pasadas=$((pasadas + 1)); }
mal()   { printf "  %s✗%s %s\n" "$rojo" "$nada" "$1"; fallas=$((fallas + 1)); }
juzga() { if [ "$2" = "$3" ]; then ok "$1"; else mal "$1 — esperaba $3, llegó $2"; fi; }

BASE_PRUEBAS=$("$PHP" -r 'require $argv[1]."/nucleo/Autocargador.php";Nucleo\Autocargador::registrar($argv[1]);echo Nucleo\Configuracion::baseDatos($argv[1])["base"];' "$RAIZ")
ULTIMA=$("$PHP" -r 'require $argv[1]."/nucleo/Autocargador.php";Nucleo\Autocargador::registrar($argv[1]);$i=Nucleo\MigracionesEsquema::inventario($argv[1]."/esquema");echo (int) array_key_last($i);' "$RAIZ")
# Una carpeta, no `mktemp …XXXXXX.sql`: el mktemp de macOS sólo cambia las X
# del final, así que ese nombre era fijo y una corrida interrumpida lo dejaba
# tomado para la siguiente.
CARPETA_CONSOLIDADO=$(mktemp -d "${TMPDIR:-/tmp}/app-consolidado.XXXXXX")
CONSOLIDADO="$CARPETA_CONSOLIDADO/consolidado.sql"
trap 'rm -rf "$CARPETA_CONSOLIDADO"' EXIT

# Consulta de un valor, con las llaves foráneas apagadas para sembrar sin
# armar todo el catálogo alrededor.
sql() {
  "$PHP" -r '
    require $argv[1]."/nucleo/Autocargador.php";
    Nucleo\Autocargador::registrar($argv[1]);
    $c = Nucleo\Configuracion::baseDatos($argv[1]);
    $m = new mysqli($c["host"], $c["usuario"], $c["clave"], $c["base"], (int) $c["puerto"]);
    $m->set_charset("utf8mb4");
    $m->query("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    $m->query("SET FOREIGN_KEY_CHECKS = 0");
    $r = $m->query($argv[2]);
    if ($r instanceof mysqli_result) { $f = $r->fetch_row(); echo $f[0] ?? ""; }
  ' "$RAIZ" "$1"
}

# La firma del esquema: columnas, índices, llaves foráneas y CHECK, ordenados.
# La base migrada por partes y la instalada de cero deben quedar idénticas.
firma_esquema() {
  "$PHP" -r '
    require $argv[1]."/nucleo/Autocargador.php";
    Nucleo\Autocargador::registrar($argv[1]);
    $b=new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos($argv[1]));
    $partes=[];
    foreach([
      "SELECT table_name,column_name,ordinal_position,column_type,is_nullable,COALESCE(column_default,\"∅\"),extra,COALESCE(collation_name,\"\") FROM information_schema.columns WHERE table_schema=DATABASE() ORDER BY 1,3",
      "SELECT table_name,index_name,non_unique,seq_in_index,column_name,COALESCE(sub_part,0) FROM information_schema.statistics WHERE table_schema=DATABASE() ORDER BY 1,2,4",
      "SELECT k.table_name,k.constraint_name,k.column_name,k.referenced_table_name,k.referenced_column_name,r.update_rule,r.delete_rule FROM information_schema.key_column_usage k JOIN information_schema.referential_constraints r ON r.constraint_schema=k.constraint_schema AND r.constraint_name=k.constraint_name AND r.table_name=k.table_name WHERE k.table_schema=DATABASE() ORDER BY 1,2,k.ordinal_position",
      "SELECT table_name,constraint_name,check_clause FROM information_schema.check_constraints WHERE constraint_schema=DATABASE() ORDER BY 1,2",
    ] as $consulta){
      foreach($b->filas($consulta) as $fila)$partes[]=implode("|",array_map("strval",array_values($fila)));
    }
    echo hash("sha256",implode("\n",$partes));
  ' "$RAIZ"
}
PENULTIMA=$((10#$ULTIMA - 1))

printf "%sHasta el %03d por migración, sobre una base existente%s\n" "$gris" "$ULTIMA" "$nada"
"$PHP" "$RAIZ/guiones/aplica-esquema.php" "--acepto=$BASE_PRUEBAS" "--hasta=$(printf '%03d' "$PENULTIMA")" > /dev/null 2>&1
juzga "se arma la base hasta el $(printf '%03d' "$PENULTIMA")" "$?" 0
juzga "y el libro no anota guiones que no se aplicaron" \
  "$(sql "SELECT COUNT(*) FROM migracion_esquema WHERE numero > $PENULTIMA")" 0

APP_ENTORNO="$APP_ENTORNO" "$PHP" "$RAIZ/guiones/migraciones.php" > "${TMPDIR:-/tmp}/migraciones-estado.log" 2>&1
juzga "sin --aplicar sólo consulta" "$(sql "SELECT COUNT(*) FROM migracion_esquema WHERE numero = $ULTIMA")" 0

APP_ENTORNO="$APP_ENTORNO" "$PHP" "$RAIZ/guiones/migraciones.php" --aplicar "--acepto=$BASE_PRUEBAS" > "${TMPDIR:-/tmp}/migraciones-aplica.log" 2>&1
juzga "migraciones.php aplica lo pendiente" "$?" 0
juzga "y deja registrado el último guion" "$(sql "SELECT COUNT(*) FROM migracion_esquema WHERE numero = $ULTIMA")" 1
APP_ENTORNO="$APP_ENTORNO" "$PHP" "$RAIZ/guiones/migraciones.php" --aplicar "--acepto=$BASE_PRUEBAS" > "${TMPDIR:-/tmp}/migraciones-segunda.log" 2>&1
juzga "una segunda aplicación es inocua" "$?" 0
juzga "el puesto administrador existe" "$(sql "SELECT COUNT(*) FROM puesto WHERE clave = 'administrador'")" 1
juzga "y tiene todos los permisos" \
  "$(sql "SELECT (SELECT COUNT(*) FROM permiso) = (SELECT COUNT(*) FROM puesto_permiso pp JOIN puesto p ON p.id = pp.id_puesto WHERE p.clave = 'administrador')")" 1

FIRMA_INCREMENTAL=$(firma_esquema)
juzga "la base migrada por partes tiene firma" "${#FIRMA_INCREMENTAL}" 64

printf "\n%sSQL consolidado como importación nueva%s\n" "$gris" "$nada"
"$PHP" "$RAIZ/guiones/genera-sql-despliegue.php" "$CONSOLIDADO" > /dev/null 2>&1
juzga "se genera el consolidado" "$?" 0
TABLAS_ESPERADAS=$("$PHP" -r '$j=json_decode((string)file_get_contents($argv[1]),true,512,JSON_THROW_ON_ERROR);echo (int)$j["cantidad_tablas"];' "$CONSOLIDADO.json")
GUIONES_ESPERADOS=$("$PHP" -r '$j=json_decode((string)file_get_contents($argv[1]),true,512,JSON_THROW_ON_ERROR);echo (int)$j["cantidad_guiones"];' "$CONSOLIDADO.json")

"$PHP" -r '
  require $argv[1]."/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar($argv[1]);
  $c=Nucleo\Configuracion::baseDatos($argv[1]);
  $m=new mysqli($c["host"],$c["usuario"],$c["clave"],$c["base"],(int)$c["puerto"]);
  $m->set_charset("utf8mb4");
  $m->query("SET FOREIGN_KEY_CHECKS=0");
  $r=$m->query("SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE()");
  foreach($r->fetch_all(MYSQLI_NUM) as $fila){
    $tabla=(string)$fila[0];
    if(preg_match("/^[a-z0-9_]+$/i",$tabla)!==1)throw new RuntimeException("Tabla inesperada");
    $m->query("DROP TABLE `".$tabla."`");
  }
  $contenido=file_get_contents($argv[2]);
  if($contenido===false)throw new RuntimeException("No se leyó el consolidado");
  $m->multi_query($contenido);
  do{if($resultado=$m->store_result())$resultado->free();}while($m->more_results()&&$m->next_result());
' "$RAIZ" "$CONSOLIDADO" > /dev/null 2>&1
juzga "se importa como lo haría phpMyAdmin" "$?" 0
juzga "el consolidado crea sus $TABLAS_ESPERADAS tablas declaradas" \
  "$(sql 'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type="BASE TABLE"')" "$TABLAS_ESPERADAS"
juzga "y registra sus $GUIONES_ESPERADOS guiones" "$(sql 'SELECT COUNT(*) FROM migracion_esquema')" "$GUIONES_ESPERADOS"
juzga "la instalación limpia y la incremental convergen a la misma firma" "$(firma_esquema)" "$FIRMA_INCREMENTAL"

APP_ENTORNO="$APP_ENTORNO" "$PHP" "$RAIZ/guiones/migraciones.php" --estado > "${TMPDIR:-/tmp}/migraciones-consolidado.log" 2>&1
juzga "el aplicador reconoce el consolidado al día" "$?" 0

echo
if [ "$fallas" -eq 0 ]; then
  echo "$verde$pasadas comprobaciones, todas pasan.$nada"
else
  echo "$rojo$fallas de $((pasadas + fallas)) fallan.$nada"
  exit 1
fi
