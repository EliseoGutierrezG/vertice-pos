<?php
declare(strict_types=1);

namespace Pruebas;

use RuntimeException;

/**
 * Las afirmaciones. Sin dependencias: el proyecto no las tiene y no va a
 * empezar ahora por las pruebas.
 *
 * Una afirmación que falla lanza y dice QUÉ esperaba y QUÉ llegó. Un mensaje
 * de "falló" a secas obliga a depurar la prueba en lugar del código.
 */
final class Afirma
{
    public static function igual(mixed $esperado, mixed $real, string $que = ''): void
    {
        if ($esperado !== $real) {
            throw new RuntimeException(sprintf(
                '%sse esperaba %s y llegó %s',
                $que === '' ? '' : $que . ': ',
                self::describe($esperado),
                self::describe($real)
            ));
        }
    }

    public static function cierto(bool $condicion, string $que = 'la condición'): void
    {
        if (!$condicion) {
            throw new RuntimeException($que . ' resultó falsa');
        }
    }

    public static function falso(bool $condicion, string $que = 'la condición'): void
    {
        if ($condicion) {
            throw new RuntimeException($que . ' resultó cierta');
        }
    }

    public static function nulo(mixed $valor, string $que = 'el valor'): void
    {
        if ($valor !== null) {
            throw new RuntimeException($que . ' no es nulo: ' . self::describe($valor));
        }
    }

    public static function noNulo(mixed $valor, string $que = 'el valor'): void
    {
        if ($valor === null) {
            throw new RuntimeException($que . ' es nulo');
        }
    }

    public static function contiene(string $aguja, string $pajar, string $que = ''): void
    {
        if (!str_contains($pajar, $aguja)) {
            throw new RuntimeException(sprintf(
                '%sno contiene %s. Es: %s',
                $que === '' ? '' : $que . ': ',
                self::describe($aguja),
                self::describe($pajar)
            ));
        }
    }

    /**
     * Espera que el trabajo lance, y devuelve lo lanzado para seguir mirándolo.
     *
     * @param class-string<\Throwable> $clase
     */
    public static function lanza(string $clase, callable $trabajo, string $que = ''): \Throwable
    {
        try {
            $trabajo();
        } catch (\Throwable $e) {
            if (!$e instanceof $clase) {
                throw new RuntimeException(sprintf(
                    '%sse esperaba %s y llegó %s: %s',
                    $que === '' ? '' : $que . ': ',
                    $clase,
                    $e::class,
                    $e->getMessage()
                ));
            }
            return $e;
        }

        throw new RuntimeException(
            ($que === '' ? '' : $que . ': ') . 'no lanzó nada, y se esperaba ' . $clase
        );
    }

    private static function describe(mixed $valor): string
    {
        return match (true) {
            is_string($valor) => '"' . $valor . '"',
            is_bool($valor)   => $valor ? 'true' : 'false',
            is_null($valor)   => 'null',
            is_array($valor)  => json_encode($valor, JSON_UNESCAPED_UNICODE) ?: 'array',
            is_object($valor) => $valor::class,
            default           => (string) $valor,
        };
    }
}
