<?php
declare(strict_types=1);

use Modelos\IntentosAcceso;
use Nucleo\BaseDatos;
use Pruebas\Afirma;

/** Los límites persistentes de entrada y autorización. */

$bd = new BaseDatos(Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2)));
$intentos = new IntentosAcceso($bd);
$prefijo = 'prueba_limite_';

$limpia = static fn (): int => $bd->ejecuta(
    'DELETE FROM intento_acceso WHERE ambito LIKE ?',
    [$prefijo . '%']
);

$limpia();

return [
    'cinco fallos de una cuenta y dirección bloquean quince minutos' =>
    function () use ($intentos, $limpia, $prefijo): void {
        $limpia();
        $ambito = $prefijo . 'entrada';

        for ($i = 1; $i <= 4; $i++) {
            Afirma::igual(0, $intentos->falla($ambito, 'Persona@Ejemplo', '192.0.2.10'), "fallo {$i}");
        }

        $segundos = $intentos->falla($ambito, 'persona@ejemplo', '192.0.2.10');
        Afirma::cierto($segundos >= 890 && $segundos <= 900, 'el bloqueo dura cerca de quince minutos');
        $limpia();
    },

    'un acierto limpia sólo la pareja cuenta dirección' =>
    function () use ($bd, $intentos, $limpia, $prefijo): void {
        $limpia();
        $ambito = $prefijo . 'acierto';
        $intentos->falla($ambito, 'cuenta', '192.0.2.11');
        $intentos->acierta($ambito, 'cuenta', '192.0.2.11');

        Afirma::igual(
            0,
            (int) $bd->valor('SELECT COUNT(*) FROM intento_acceso WHERE ambito = ? AND tipo = ?', [$ambito, 'cuenta_ip']),
            'la pareja'
        );
        Afirma::igual(
            1,
            (int) $bd->valor('SELECT COUNT(*) FROM intento_acceso WHERE ambito = ? AND tipo = ?', [$ambito, 'ip']),
            'el contador de dirección se conserva'
        );
        $limpia();
    },

    'treinta cuentas desde una dirección bloquean esa dirección media hora' =>
    function () use ($intentos, $limpia, $prefijo): void {
        $limpia();
        $ambito = $prefijo . 'direccion';

        for ($i = 1; $i <= 30; $i++) {
            $intentos->falla($ambito, 'cuenta-' . $i, '198.51.100.20');
        }

        $segundos = $intentos->reintento($ambito, 'cuenta-nueva', '198.51.100.20');
        Afirma::cierto($segundos >= 1790 && $segundos <= 1800, 'el bloqueo dura cerca de treinta minutos');
        $limpia();
    },

    'entrada y descuentos tienen contadores separados' =>
    function () use ($intentos, $limpia, $prefijo): void {
        $limpia();
        $entrada = $prefijo . 'ent';
        $descuento = $prefijo . 'desc';

        for ($i = 0; $i < 5; $i++) {
            $intentos->falla($entrada, 'cuenta', '203.0.113.30');
        }

        Afirma::cierto($intentos->reintento($entrada, 'cuenta', '203.0.113.30') > 0, 'entrada quedó bloqueada');
        Afirma::igual(0, $intentos->reintento($descuento, 'cuenta', '203.0.113.30'), 'descuento sigue libre');
        $limpia();
    },

    'la ventana vencida empieza de nuevo en un intento' =>
    function () use ($bd, $intentos, $limpia, $prefijo): void {
        $limpia();
        $ambito = $prefijo . 'ventana';
        $intentos->falla($ambito, 'cuenta', '203.0.113.31');
        $bd->ejecuta(
            'UPDATE intento_acceso SET ventana_desde = DATE_SUB(NOW(), INTERVAL 16 MINUTE) WHERE ambito = ?',
            [$ambito]
        );
        $intentos->falla($ambito, 'cuenta', '203.0.113.31');

        $maximo = (int) $bd->valor('SELECT MAX(intentos) FROM intento_acceso WHERE ambito = ?', [$ambito]);
        Afirma::igual(1, $maximo, 'los dos contadores reiniciaron');
        $limpia();
    },

    'la tabla sólo conserva hashes y no los identificadores en claro' =>
    function () use ($bd, $intentos, $limpia, $prefijo): void {
        $limpia();
        $ambito = $prefijo . 'hash';
        $cuenta = 'nombre-muy-reconocible';
        $ip = '203.0.113.32';
        $intentos->falla($ambito, $cuenta, $ip);

        foreach ($bd->filas('SELECT clave_hash FROM intento_acceso WHERE ambito = ?', [$ambito]) as $fila) {
            $hash = (string) $fila['clave_hash'];
            Afirma::cierto(preg_match('/^[a-f0-9]{64}$/', $hash) === 1, 'es SHA-256 hexadecimal');
            Afirma::falso(str_contains($hash, $cuenta) || str_contains($hash, $ip), 'no guarda el identificador');
        }
        $limpia();
    },

    'la purga elimina contadores vencidos después de treinta días' =>
    function () use ($bd, $intentos, $limpia, $prefijo): void {
        $limpia();
        $ambito = $prefijo . 'purga';
        $intentos->falla($ambito, 'cuenta', '203.0.113.33');
        $bd->ejecuta(
            'UPDATE intento_acceso SET actualizado_en = DATE_SUB(NOW(), INTERVAL 31 DAY) WHERE ambito = ?',
            [$ambito]
        );

        Afirma::igual(2, $intentos->purga(), 'los dos contadores eliminados');
        Afirma::igual(0, (int) $bd->valor('SELECT COUNT(*) FROM intento_acceso WHERE ambito = ?', [$ambito]), 'no quedó ninguno');
    },
];
