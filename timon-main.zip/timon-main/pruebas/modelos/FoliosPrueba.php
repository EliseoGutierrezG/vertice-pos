<?php
declare(strict_types=1);

use Modelos\Folios;
use Nucleo\BaseDatos;
use Pruebas\Afirma;

/**
 * Quien reparte los folios.
 *
 * ⚠️ Antes el folio se armaba con `MAX(folio) + 1` en cada servicio. Medido con
 * ocho pedidos subiendo al mismo instante —lo que pasa cuando varios vendedores
 * recuperan señal al salir del mismo pueblo—: **entró uno y siete recibieron
 * 409**, y un 409 es lo único que la app llama «rechazo», así que marca la
 * operación atorada y detiene la cola. La prueba con procesos de verdad está en
 * `pruebas/concurrencia.sh`; aquí se comprueba lo que se puede comprobar en
 * fila, que es lo demás.
 *
 * Las series de esta prueba empiezan con `zz_` y se borran al final.
 */

/** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
$config = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd     = new BaseDatos($config);
$folios = new Folios($bd);

$limpia = function () use ($bd): void {
    $bd->ejecuta('DELETE FROM folio_serie WHERE serie LIKE ?', ['zz_%']);
};
$limpia();

return [
    'una serie nueva empieza en uno' => function () use ($folios, $limpia): void {
        $limpia();

        Afirma::igual('ZZ-00001', $folios->siguiente('zz_nueva', 'ZZ', 5), 'el primer folio');
        $limpia();
    },

    'cada folio es el siguiente, y no se repite' => function () use ($folios, $limpia): void {
        $limpia();

        $tres = [
            $folios->siguiente('zz_seguidos', 'ZZ', 5),
            $folios->siguiente('zz_seguidos', 'ZZ', 5),
            $folios->siguiente('zz_seguidos', 'ZZ', 5),
        ];

        Afirma::igual(['ZZ-00001', 'ZZ-00002', 'ZZ-00003'], $tres, 'los tres folios');
        $limpia();
    },

    'cada serie lleva su propia cuenta' => function () use ($folios, $limpia): void {
        $limpia();
        $folios->siguiente('zz_una', 'ZA', 5);
        $folios->siguiente('zz_una', 'ZA', 5);

        Afirma::igual('ZB-00001', $folios->siguiente('zz_otra', 'ZB', 5), 'la otra serie');
        Afirma::igual(2, $folios->ultimo('zz_una'), 'y la primera sigue en dos');
        $limpia();
    },

    'el ancho lo pide quien lo usa' => function () use ($folios, $limpia): void {
        // El pedido va con seis dígitos y los demás con cinco. No es adorno: el
        // folio del pedido se le dice al cliente por teléfono.
        $limpia();

        Afirma::igual('PZ-000001', $folios->siguiente('zz_ancho', 'PZ', 6), 'con seis');
        $limpia();
    },

    'el número no depende de cuántos documentos haya' => function () use ($bd, $folios, $limpia): void {
        // Es la diferencia con `MAX(folio) + 1`: si el documento se borra —una
        // demostración recargada, un renglón cancelado y limpiado—, el contador
        // no vuelve atrás y ningún folio se repite.
        $limpia();
        $folios->siguiente('zz_borrado', 'ZC', 5);
        $folios->siguiente('zz_borrado', 'ZC', 5);

        Afirma::igual(2, $folios->ultimo('zz_borrado'), 'lo repartido');
        Afirma::igual('ZC-00003', $folios->siguiente('zz_borrado', 'ZC', 5), 'el siguiente');
        $limpia();
    },

    'se limpia lo que la prueba creó' => function () use ($bd, $limpia): void {
        $limpia();

        Afirma::igual(
            0,
            (int) $bd->valor('SELECT COUNT(*) FROM folio_serie WHERE serie LIKE ?', ['zz_%']),
            'las series de la prueba'
        );
    },
];
