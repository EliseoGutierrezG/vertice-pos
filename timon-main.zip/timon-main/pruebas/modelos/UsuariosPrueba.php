<?php
declare(strict_types=1);

use Modelos\Usuarios;
use Nucleo\BaseDatos;
use Nucleo\Identidad;
use Pruebas\Afirma;
use Pruebas\Semilla;

/**
 * Usuarios, contraseñas y permisos.
 *
 * Lo que aquí se comprueba es lo que sostiene todo lo demás: que la
 * contraseña no exista en claro en ningún lado, y que los permisos salgan de
 * la base en una sola consulta: los del **puesto** de la persona.
 */

/** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
$config   = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd       = new BaseDatos($config);
$usuarios = new Usuarios($bd);

/** Siembra a alguien con su puesto. En la v2 no hay usuario sin personal. */
$crea = fn (string $usuario, string $clave, string $puesto = 'administrador'): int
    => Semilla::usuario($bd, $usuario, $puesto, $clave);

/** Borra los usuarios que estas pruebas crean, y sólo ésos. */
$limpia = fn () => Semilla::borraUsuarios($bd, 'prueba.');

return [
    'autentica devuelve el usuario cuando los dos datos están bien' => function () use ($usuarios, $limpia, $crea): void {
        $limpia();
        $crea('prueba.tiempo', 'contraseña-larga-9');

        $registro = $usuarios->autentica('prueba.tiempo', 'contraseña-larga-9');

        Afirma::cierto($registro !== null, 'no devolvió el usuario');
        Afirma::igual('prueba.tiempo', (string) ($registro['usuario'] ?? ''), 'el usuario');
        $limpia();
    },

    'autentica no distingue la contraseña mala del usuario que no existe' => function () use ($usuarios, $limpia, $crea): void {
        $limpia();
        $crea('prueba.tiempo', 'contraseña-larga-9');

        Afirma::nulo($usuarios->autentica('prueba.tiempo', 'la que no es'), 'con la contraseña mala');
        Afirma::nulo($usuarios->autentica('prueba.no.existe', 'la que no es'), 'con un usuario inventado');
        Afirma::nulo($usuarios->autentica('', 'la que no es'), 'sin usuario');
        $limpia();
    },

    'un usuario dado de baja no entra, ni se nota que existe' => function () use ($bd, $usuarios, $limpia, $crea): void {
        $limpia();
        $crea('prueba.tiempo', 'contraseña-larga-9');
        $bd->ejecuta("UPDATE usuario SET id_estatus = 3 WHERE usuario = 'prueba.tiempo'");

        Afirma::nulo($usuarios->autentica('prueba.tiempo', 'contraseña-larga-9'), 'con la contraseña buena');
        $limpia();
    },

    'comprobar un usuario que no existe cuesta lo mismo que uno que sí' => function () use ($usuarios, $limpia, $crea): void {
        // ⚠️ La prueba del reloj. Medido contra `/api/v1/entrar` antes del
        // arreglo: **73 ms** con un usuario que existe y **6 ms** con uno que
        // no, doce veces menos, porque sin renglón no había `password_verify`
        // que hacer. Los dos controladores cuidan dar el mismo mensaje pase lo
        // que pase; el tiempo lo desmentía, y con eso se arma la lista de
        // usuarios válidos.
        //
        // Se comparan los dos tiempos entre sí, no contra un número fijo: en
        // otra máquina bcrypt tarda otra cosa, pero la proporción es la misma.
        $limpia();
        $crea('prueba.tiempo', 'contraseña-larga-9');

        $cuantoTarda = static function (callable $que): float {
            $mejor = INF;

            // Tres vueltas y se toma la más rápida: la más rápida es la que no
            // lleva ruido de la máquina.
            for ($i = 0; $i < 3; $i++) {
                $arranque = microtime(true);
                $que();
                $mejor = min($mejor, microtime(true) - $arranque);
            }

            return $mejor;
        };

        $conUsuario = $cuantoTarda(fn () => $usuarios->autentica('prueba.tiempo', 'la que no es'));
        $sinUsuario = $cuantoTarda(fn () => $usuarios->autentica('prueba.no.existe', 'la que no es'));

        $limpia();

        // Que los dos hagan el bcrypt se nota en que ninguno es casi gratis.
        Afirma::cierto(
            $sinUsuario > $conUsuario / 3,
            sprintf('el que no existe tardó %.1f ms y el que sí %.1f ms', $sinUsuario * 1000, $conUsuario * 1000)
        );
    },

    'el hash de relleno cuesta lo mismo que los que se guardan' => function (): void {
        // Cada versión soportada de PHP elige un hash con el costo que usa su
        // `PASSWORD_DEFAULT`; si cambia, el reloj no debe volver a delatar.
        $reflejo = new ReflectionClass(Usuarios::class);
        /** @var string $relleno */
        $relleno = $reflejo->getMethod('hashDeRelleno')->invoke(null);

        $delRelleno = password_get_info($relleno)['options']['cost'] ?? null;
        $deAhora    = password_get_info(password_hash('x', PASSWORD_DEFAULT))['options']['cost'] ?? null;

        Afirma::igual($deAhora, $delRelleno, 'el costo del hash de relleno');
        Afirma::falso(password_verify('', $relleno), 'el relleno no abre con la cadena vacía');
    },

    'la contraseña no se guarda en claro' => function () use ($bd, $usuarios, $limpia, $crea): void {
        $limpia();
        $crea('prueba.uno', 'contraseña-larga-1');

        $guardado = (string) $bd->valor("SELECT clave_hash FROM usuario WHERE usuario = 'prueba.uno'");

        Afirma::falso(str_contains($guardado, 'contraseña'), 'la contraseña aparece en la columna');
        Afirma::cierto(str_starts_with($guardado, '$2y$') || str_starts_with($guardado, '$argon'),
            'el hash tiene forma de password_hash');
        $limpia();
    },

    'la contraseña correcta se reconoce y la incorrecta no' => function () use ($usuarios, $limpia, $crea): void {
        $limpia();
        $crea('prueba.dos', 'contraseña-larga-2');
        $registro = $usuarios->porUsuario('prueba.dos');

        Afirma::noNulo($registro, 'el usuario');
        Afirma::cierto($usuarios->claveCorrecta($registro, 'contraseña-larga-2'), 'la correcta');
        Afirma::falso($usuarios->claveCorrecta($registro, 'contraseña-larga-3'), 'una incorrecta');
        Afirma::falso($usuarios->claveCorrecta($registro, ''), 'la vacía');
        $limpia();
    },

    'dos usuarios con la misma contraseña tienen hashes distintos' => function () use ($bd, $usuarios, $limpia, $crea): void {
        $limpia();
        $crea('prueba.a', 'la-misma-contraseña');
        $crea('prueba.b', 'la-misma-contraseña');

        $a = $bd->valor("SELECT clave_hash FROM usuario WHERE usuario = 'prueba.a'");
        $b = $bd->valor("SELECT clave_hash FROM usuario WHERE usuario = 'prueba.b'");

        Afirma::falso($a === $b, 'los hashes salieron iguales: falta la sal');
        $limpia();
    },

    'un usuario repetido se rechaza' => function () use ($usuarios, $limpia, $crea): void {
        $limpia();
        $crea('prueba.tres', 'contraseña-larga-3');

        Afirma::lanza(
            Throwable::class,
            fn () => $crea('prueba.tres', 'contraseña-larga-4')
        );
        $limpia();
    },

    'los permisos del puesto llegan completos' => function () use ($bd, $limpia, $crea): void {
        $limpia();
        $id = $crea('prueba.admin', 'contraseña-larga-5');

        $identidad = new Identidad($bd);
        $identidad->establece($id);

        // Se compara contra la matriz de la base, no contra un número: cada
        // permiso nuevo cambiaría la cuenta sin que nada estuviera mal.
        $cuantos = (int) $bd->valor(
            "SELECT COUNT(*) FROM puesto_permiso pp JOIN puesto p ON p.id = pp.id_puesto WHERE p.clave = 'administrador'"
        );

        Afirma::igual($cuantos, count($identidad->permisos()), 'los permisos del administrador');
        Afirma::cierto($identidad->puede('personal_admin'), 'puede dar de alta personal');
        Afirma::cierto($identidad->puede('bitacora_ver'), 'puede ver la bitácora');
        Afirma::cierto($identidad->esAdministrador(), 'es administrador');
        $limpia();
    },

    'un gerente no puede lo que no le toca' => function () use ($bd, $limpia, $crea): void {
        $limpia();
        $id = $crea('prueba.gerente', 'contraseña-larga-6', 'gerente');

        $identidad = new Identidad($bd);
        $identidad->establece($id);

        Afirma::cierto($identidad->puede('personal_ver'), 've a su personal');
        Afirma::falso($identidad->puede('organizacion_admin'), 'no da de alta sucursales');
        Afirma::falso($identidad->puede('seguridad_admin'), 'no cambia la seguridad');
        Afirma::falso($identidad->esAdministrador(), 'no es administrador');
        $limpia();
    },

    'quitar el permiso en la base bloquea la acción, sin tocar código' => function () use ($bd, $limpia, $crea): void {
        $limpia();
        $id = $crea('prueba.quita', 'contraseña-larga-7', 'gerente');

        $antes = new Identidad($bd);
        $antes->establece($id);
        Afirma::cierto($antes->puede('avisos_ver'), 'antes sí podía');

        $idPuesto  = (int) $bd->valor("SELECT id FROM puesto WHERE clave = 'gerente'");
        $idPermiso = (int) $bd->valor("SELECT id FROM permiso WHERE clave = 'avisos_ver'");
        $bd->ejecuta('DELETE FROM puesto_permiso WHERE id_puesto = ? AND id_permiso = ?', [$idPuesto, $idPermiso]);

        try {
            $despues = new Identidad($bd);
            $despues->establece($id);
            Afirma::falso($despues->puede('avisos_ver'), 'después ya no puede');

            $error = Afirma::lanza(
                Nucleo\Errores\ErrorHttp::class,
                fn () => $despues->exige('avisos_ver')
            );
            Afirma::igual(403, $error->getCode(), 'el código');
        } finally {
            // Se devuelve el permiso a su sitio pase lo que pase.
            $bd->ejecuta(
                'INSERT INTO puesto_permiso (id_puesto, id_permiso) VALUES (?, ?)',
                [$idPuesto, $idPermiso]
            );
            $limpia();
        }
    },

    'los permisos se traen una vez, no una consulta por comprobación' => function () use ($bd, $limpia, $crea): void {
        $limpia();
        $id = $crea('prueba.cuenta', 'contraseña-larga-8');

        $identidad = new Identidad($bd);
        $identidad->establece($id);

        $lectura = fn (): int => (int) ($bd->fila("SHOW SESSION STATUS LIKE 'Questions'")['Value'] ?? 0);

        $inicio = $lectura();
        for ($i = 0; $i < 50; $i++) {
            $identidad->puede('personal_admin');
            $identidad->alcanzaSucursal(1);
        }
        $fin = $lectura();

        // Las dos lecturas del contador son consultas; 100 comprobaciones no.
        Afirma::cierto($fin - $inicio <= 2, '100 comprobaciones dispararon consultas: ' . ($fin - $inicio));
        $limpia();
    },

    'la baja es lógica: el usuario sigue existiendo' => function () use ($bd, $usuarios, $limpia, $crea): void {
        $limpia();
        $id = $crea('prueba.baja', 'contraseña-larga-9');

        $usuarios->desactiva($id);

        Afirma::igual(
            1,
            (int) $bd->valor('SELECT COUNT(*) FROM usuario WHERE id = ?', [$id]),
            'la fila sigue ahí'
        );
        Afirma::igual(3, (int) $bd->valor('SELECT id_estatus FROM usuario WHERE id = ?', [$id]), 'con el estatus inactivo');
        $limpia();
    },

    'un usuario desactivado no puede establecer identidad' => function () use ($bd, $usuarios, $limpia, $crea): void {
        $limpia();
        $id = $crea('prueba.fuera', 'contraseña-lar-10');
        $usuarios->desactiva($id);

        $error = Afirma::lanza(
            Nucleo\Errores\ErrorHttp::class,
            fn () => (new Identidad($bd))->establece($id)
        );

        Afirma::igual(401, $error->getCode(), 'el código');
        $limpia();
    },

    'una persona dada de baja ya no entra, aunque su usuario siga activo' => function () use ($bd, $limpia, $crea): void {
        // D12: el usuario cuelga de la persona. Dar de baja al personal tiene
        // que bastar para cerrarle la puerta, sin acordarse del usuario.
        $limpia();
        $id = $crea('prueba.exempleado', 'contraseña-lar-11');
        $bd->ejecuta('UPDATE personal SET id_estatus = 3 WHERE id = (SELECT id_personal FROM usuario WHERE id = ?)', [$id]);

        $error = Afirma::lanza(
            Nucleo\Errores\ErrorHttp::class,
            fn () => (new Identidad($bd))->establece($id)
        );

        Afirma::igual(401, $error->getCode(), 'el código');
        $limpia();
    },

    'cambiar el puesto de la persona cambia lo que puede' => function () use ($bd, $limpia, $crea): void {
        $limpia();
        $id = $crea('prueba.cambio', 'contraseña-lar-12', 'mesero');

        $bd->ejecuta(
            "UPDATE personal SET id_puesto = (SELECT id FROM puesto WHERE clave = 'gerente')
             WHERE id = (SELECT id_personal FROM usuario WHERE id = ?)",
            [$id]
        );

        $identidad = new Identidad($bd);
        $identidad->establece($id);

        Afirma::cierto($identidad->puede('tablero_ver'), 'ahora ve el tablero');
        Afirma::falso($identidad->puede('seguridad_admin'), 'y no cambia la seguridad');
        Afirma::igual('gerente', $identidad->puesto(), 'el puesto');
        $limpia();
    },

    'no hay usuario sin personal' => function () use ($bd, $usuarios): void {
        $inexistente = (int) $bd->valor('SELECT COALESCE(MAX(id), 0) + 1000 FROM personal');

        Afirma::lanza(
            Throwable::class,
            fn () => $usuarios->crea($inexistente, 'prueba.huerfano', 'contraseña-lar-13')
        );
        Afirma::igual(0, (int) $bd->valor("SELECT COUNT(*) FROM usuario WHERE usuario = 'prueba.huerfano'"), 'no se creó');
    },

    'una persona tiene un solo usuario' => function () use ($bd, $usuarios, $limpia, $crea): void {
        $limpia();
        $id = $crea('prueba.unico', 'contraseña-lar-14');
        $personal = (int) $bd->valor('SELECT id_personal FROM usuario WHERE id = ?', [$id]);

        Afirma::lanza(
            Throwable::class,
            fn () => $usuarios->crea($personal, 'prueba.unico.dos', 'contraseña-lar-15')
        );
        $limpia();
    },

    'el usuario nace con la contraseña temporal' => function () use ($bd, $usuarios, $limpia): void {
        $limpia();
        $idPuesto   = (int) $bd->valor("SELECT id FROM puesto WHERE clave = 'cocina'");
        $idPersonal = $bd->inserta(
            'INSERT INTO personal (nombre, apellido_paterno, id_puesto, fecha_ingreso) VALUES (?, ?, ?, CURDATE())',
            ['Prueba', 'Temporal', $idPuesto]
        );
        $id = $usuarios->crea($idPersonal, 'prueba.temporal', 'contraseña-lar-16');

        Afirma::igual(1, (int) $bd->valor('SELECT cambiar_clave FROM usuario WHERE id = ?', [$id]), 'nace temporal');

        $usuarios->cambiaClave($id, 'la-que-eligio-el');
        Afirma::igual(0, (int) $bd->valor('SELECT cambiar_clave FROM usuario WHERE id = ?', [$id]), 'deja de serlo al cambiarla');
        $limpia();
    },
];
