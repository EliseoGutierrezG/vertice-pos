<?php
declare(strict_types=1);

use Modelos\Dispositivos;
use Modelos\Tokens;
use Modelos\Usuarios;
use Nucleo\BaseDatos;
use Pruebas\Afirma;

/**
 * Tokens y dispositivos: la puerta de la app de campo.
 */

/** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
$config       = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd           = new BaseDatos($config);
$usuarios     = new Usuarios($bd);
$dispositivos = new Dispositivos($bd);
$tokens       = new Tokens($bd);

$limpia = fn () => Pruebas\Semilla::borraUsuarios($bd, 'token.');

/** Deja listo un preventa con su teléfono. @return array{0:int,1:array<string,mixed>} */
$prepara = function (string $sufijo) use ($bd, $dispositivos): array {
    $id = Pruebas\Semilla::usuario($bd, 'token.' . $sufijo, 'mesero');
    $telefono = $dispositivos->registraOEncuentra($id, 'telefono-' . $sufijo, 'Teléfono de prueba');

    return [$id, $telefono];
};

return [
    'el token dura 14 días y se renueva con el uso, no en cada petición' => function () use ($bd, $tokens, $prepara, $limpia): void {
        [$idUsuario, $telefono] = $prepara('renueva');
        $token = $tokens->emite($idUsuario, (int) $telefono['id']);
        $dias = static fn (): int => (int) $bd->valor('SELECT TIMESTAMPDIFF(HOUR, NOW(), expira_en) FROM token_acceso WHERE id_usuario = ?', [$idUsuario]);

        Afirma::cierto($dias() >= 14 * 24 - 1 && $dias() <= 14 * 24, 'nace con 14 días');

        $bd->ejecuta('UPDATE token_acceso SET expira_en = DATE_ADD(NOW(), INTERVAL 5 DAY) WHERE id_usuario = ?', [$idUsuario]);
        Afirma::noNulo($tokens->resuelve($token), 'sigue valiendo');
        Afirma::cierto($dias() >= 14 * 24 - 1, 'usarlo lo renueva');

        $bd->ejecuta('UPDATE token_acceso SET expira_en = DATE_ADD(NOW(), INTERVAL 30 DAY) WHERE id_usuario = ?', [$idUsuario]);
        $tokens->resuelve($token);
        Afirma::cierto($dias() > 14 * 24, 'al que traía más días no se le acorta');

        $bd->ejecuta('UPDATE token_acceso SET expira_en = DATE_SUB(NOW(), INTERVAL 1 MINUTE) WHERE id_usuario = ?', [$idUsuario]);
        Afirma::nulo($tokens->resuelve($token), 'vencido ya no se revive');
        $limpia();
    },

    'el token se guarda como hash, nunca en claro' => function () use ($bd, $tokens, $prepara, $limpia): void {
        $limpia();
        [$idUsuario, $telefono] = $prepara('uno');

        $token = $tokens->emite($idUsuario, (int) $telefono['id']);
        $guardado = (string) $bd->valor('SELECT token_hash FROM token_acceso WHERE id_usuario = ?', [$idUsuario]);

        Afirma::falso($guardado === $token, 'el token está guardado tal cual');
        Afirma::igual(hash('sha256', $token), $guardado, 'lo guardado es el sha256 del token');
        $limpia();
    },

    'un token válido resuelve a su usuario' => function () use ($tokens, $prepara, $limpia): void {
        $limpia();
        [$idUsuario, $telefono] = $prepara('dos');

        $acceso = $tokens->resuelve($tokens->emite($idUsuario, (int) $telefono['id']));

        Afirma::noNulo($acceso, 'el acceso');
        Afirma::igual($idUsuario, (int) $acceso['id_usuario'], 'el usuario');
        $limpia();
    },

    'un token inventado no resuelve a nada' => function () use ($tokens, $limpia): void {
        $limpia();
        Afirma::nulo($tokens->resuelve(bin2hex(random_bytes(32))), 'el acceso');
    },

    'un token revocado deja de valer en el acto' => function () use ($tokens, $prepara, $limpia): void {
        $limpia();
        [$idUsuario, $telefono] = $prepara('tres');
        $token = $tokens->emite($idUsuario, (int) $telefono['id']);

        Afirma::noNulo($tokens->resuelve($token), 'antes de revocar');
        $tokens->revoca($token);
        Afirma::nulo($tokens->resuelve($token), 'después de revocar');
        $limpia();
    },

    'un token vencido no vale' => function () use ($bd, $tokens, $prepara, $limpia): void {
        $limpia();
        [$idUsuario, $telefono] = $prepara('cuatro');
        $token = $tokens->emite($idUsuario, (int) $telefono['id']);

        $bd->ejecuta(
            'UPDATE token_acceso SET expira_en = DATE_SUB(NOW(), INTERVAL 1 DAY) WHERE id_usuario = ?',
            [$idUsuario]
        );

        Afirma::nulo($tokens->resuelve($token), 'el acceso');
        $limpia();
    },

    'desactivar al usuario invalida sus tokens' => function () use ($usuarios, $tokens, $prepara, $limpia): void {
        $limpia();
        [$idUsuario, $telefono] = $prepara('cinco');
        $token = $tokens->emite($idUsuario, (int) $telefono['id']);

        $usuarios->desactiva($idUsuario);

        Afirma::nulo($tokens->resuelve($token), 'el acceso');
        $limpia();
    },

    'un teléfono nuevo nace sin autorizar' => function () use ($prepara, $limpia): void {
        $limpia();
        [, $telefono] = $prepara('seis');

        Afirma::igual(0, (int) $telefono['autorizado'], 'la autorización');
        $limpia();
    },

    'registrar dos veces el mismo teléfono no lo duplica' => function () use ($bd, $dispositivos, $prepara, $limpia): void {
        $limpia();
        [$idUsuario] = $prepara('siete');

        $dispositivos->registraOEncuentra($idUsuario, 'telefono-siete', 'Otro nombre');

        Afirma::igual(
            1,
            (int) $bd->valor("SELECT COUNT(*) FROM dispositivo WHERE identificador = 'telefono-siete'"),
            'los dispositivos'
        );
        $limpia();
    },

    'el mismo aparato queda pendiente para un usuario distinto' => function () use ($bd, $dispositivos, $limpia): void {
        $limpia();
        $uno = Pruebas\Semilla::usuario($bd, 'token.once.a', 'mesero');
        $dos = Pruebas\Semilla::usuario($bd, 'token.once.b', 'mesero');

        $primero = $dispositivos->registraOEncuentra($uno, 'telefono-compartido', 'Teléfono compartido');
        $dispositivos->autoriza((int) $primero['id']);
        $segundo = $dispositivos->registraOEncuentra($dos, 'telefono-compartido', 'Teléfono compartido');

        Afirma::igual(2, (int) $bd->valor("SELECT COUNT(*) FROM dispositivo WHERE identificador = 'telefono-compartido'"), 'las parejas');
        Afirma::igual(0, (int) $segundo['autorizado'], 'la segunda pareja');
        $limpia();
    },

    'autorizar el teléfono se ve al resolver el token' => function () use ($dispositivos, $tokens, $prepara, $limpia): void {
        $limpia();
        [$idUsuario, $telefono] = $prepara('ocho');
        $token = $tokens->emite($idUsuario, (int) $telefono['id']);

        Afirma::igual(0, (int) $tokens->resuelve($token)['autorizado'], 'antes');
        $dispositivos->autoriza((int) $telefono['id']);
        Afirma::igual(1, (int) $tokens->resuelve($token)['autorizado'], 'después');
        $limpia();
    },

    'retirar la autorización corta los tokens del teléfono' => function () use ($dispositivos, $tokens, $prepara, $limpia): void {
        $limpia();
        [$idUsuario, $telefono] = $prepara('nueve');
        $dispositivos->autoriza((int) $telefono['id']);
        $token = $tokens->emite($idUsuario, (int) $telefono['id']);

        Afirma::noNulo($tokens->resuelve($token), 'antes de retirar');
        $dispositivos->retira((int) $telefono['id']);
        Afirma::nulo($tokens->resuelve($token), 'después de retirar');
        $limpia();
    },

    'dos tokens seguidos no se parecen' => function () use ($tokens, $prepara, $limpia): void {
        $limpia();
        [$idUsuario, $telefono] = $prepara('diez');

        $uno = $tokens->emite($idUsuario, (int) $telefono['id']);
        $dos = $tokens->emite($idUsuario, (int) $telefono['id']);

        Afirma::falso($uno === $dos, 'salieron iguales');
        Afirma::igual(64, strlen($uno), 'la longitud en caracteres');
        $limpia();
    },
];
