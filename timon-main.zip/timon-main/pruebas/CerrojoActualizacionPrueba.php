<?php
declare(strict_types=1);

use Nucleo\CerrojoActualizacion;
use Nucleo\Errores\ErrorHttp;
use Pruebas\Afirma;

return [
    'una actualización excluye peticiones y espera que terminen las anteriores' => function (): void {
        $base = sys_get_temp_dir() . '/timon-cerrojo-' . bin2hex(random_bytes(4));
        mkdir($base . '/liberaciones/una', 0700, true);
        mkdir($base . '/liberaciones/dos', 0700, true);
        mkdir($base . '/compartido', 0700);
        symlink('liberaciones/una', $base . '/actual');
        $lectura = CerrojoActualizacion::lectura($base . '/actual');
        $escritura = fopen($base . '/compartido/operacion.candado', 'c');
        try {
            Afirma::falso(flock($escritura, LOCK_EX | LOCK_NB), 'una petición en curso detiene la actualización');
            CerrojoActualizacion::libera($lectura);
            $lectura = null;
            Afirma::cierto(flock($escritura, LOCK_EX | LOCK_NB), 'cuando termina puede instalar');
            $error = Afirma::lanza(ErrorHttp::class, fn () => CerrojoActualizacion::lectura($base . '/actual'));
            Afirma::igual('ocupado', $error->clave(), 'la petición nueva puede reintentarse');
            flock($escritura, LOCK_UN);
            unlink($base . '/actual');
            symlink('liberaciones/dos', $base . '/actual');
            clearstatcache(true);
            Afirma::lanza(ErrorHttp::class, fn () => CerrojoActualizacion::lectura($base . '/liberaciones/una'), 'no escribe el código viejo');
        } finally {
            CerrojoActualizacion::libera($lectura);
            CerrojoActualizacion::libera($escritura);
            unlink($base . '/actual');
            unlink($base . '/compartido/operacion.candado');
            rmdir($base . '/compartido');
            rmdir($base . '/liberaciones/una');
            rmdir($base . '/liberaciones/dos');
            rmdir($base . '/liberaciones');
            rmdir($base);
        }
    },
];
