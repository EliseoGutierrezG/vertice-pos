#!/usr/bin/env python3
"""Acceso, permisos y alcance de las cuentas de demostración en staging.

Lee el archivo privado indicado; no imprime claves ni nombres. Crea sesiones
en memoria, consulta pantallas y las cierra. No reconstruye ni siembra bases.
"""

import argparse
from html.parser import HTMLParser
from http.cookiejar import CookieJar
from pathlib import Path
import re
import sys
from urllib.error import HTTPError
from urllib.parse import urlencode, urlsplit
from urllib.request import build_opener, HTTPCookieProcessor, HTTPRedirectHandler, Request
import uuid


class SinRedireccion(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Formulario(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.marca = None
        self.sucursales = []
        self.selector = False
        self.feed(html)

    def handle_starttag(self, tag, atributos):
        datos = dict(atributos)
        if tag == 'meta' and datos.get('name') == 'csrf-token':
            self.marca = datos.get('content')
        if tag == 'input' and datos.get('name') == '_marca':
            self.marca = datos.get('value')
        if tag == 'select' and datos.get('name') == 'sucursal':
            self.selector = True
        if tag == 'option' and self.selector and datos.get('value', '').isdigit():
            self.sucursales.append(int(datos['value']))

    def handle_endtag(self, tag):
        if tag == 'select':
            self.selector = False


class Sesion:
    def __init__(self, origen):
        self.origen = origen
        self.cookies = CookieJar()
        self.http = build_opener(HTTPCookieProcessor(self.cookies), SinRedireccion())

    def pide(self, ruta, datos=None):
        solicitud = Request(self.origen + ruta, data=urlencode(datos).encode() if datos is not None else None)
        try:
            respuesta = self.http.open(solicitud, timeout=20)
        except HTTPError as error:
            respuesta = error
        with respuesta:
            return respuesta.code, respuesta.headers, respuesta.read().decode('utf-8')


def main():
    argumentos = argparse.ArgumentParser(description=__doc__)
    argumentos.add_argument('origen')
    argumentos.add_argument('credenciales', type=Path)
    args = argumentos.parse_args()
    origen = args.origen.rstrip('/')
    if origen != 'https://staging-timon.verticesoftware.com.mx':
        argumentos.error('Este guion solo acepta el staging de Timón.')
    texto = args.credenciales.read_text()
    coincidencia = re.search(r'^Contraseña de todos:\s*(.+)$', texto, re.M)
    if not coincidencia:
        argumentos.error('No se encontró la contraseña común en el archivo privado.')
    clave = coincidencia[1].strip()
    cuentas = re.findall(r'^(\S+)\s+(gerente|cajero|mesero|cocina|barra|almacen)\s+(.+)$', texto, re.M)
    if not cuentas:
        argumentos.error('No hay cuentas de demostración reconocidas.')
    rutas = {
        '/panel': {'gerente', 'cajero', 'mesero', 'cocina', 'barra', 'almacen'},
        '/areas': {'gerente', 'cajero', 'mesero'},
        '/platillos': {'gerente'},
        '/equipos-comanda': {'gerente'},
        '/caja/turnos': {'gerente', 'cajero'},
        '/inventario/insumos': {'gerente', 'almacen'},
        '/personal': {'gerente'},
        '/sistema/diagnostico': set(),
        '/servidores': set(),
    }
    pasadas, fallas = 0, []
    alcances = {}

    def comprueba(condicion, descripcion):
        nonlocal pasadas
        if condicion:
            pasadas += 1
        else:
            fallas.append(descripcion)
            print('  ✗ ' + descripcion, flush=True)

    for numero, (usuario, rol, nombre) in enumerate(cuentas, 1):
        sesion = Sesion(origen)
        estado, _, html = sesion.pide('/entrar')
        marca = Formulario(html).marca
        if estado != 200 or not marca:
            raise RuntimeError('No se obtuvo el formulario de acceso.')
        anterior = {c.name: c.value for c in sesion.cookies}
        estado, cabeceras, _ = sesion.pide('/entrar', {'_marca': marca, 'usuario': usuario, 'clave': clave})
        if estado != 302 or urlsplit(cabeceras.get('Location', '')).path != '/panel':
            raise RuntimeError(f'Acceso no completado en cuenta {numero} ({rol}), HTTP {estado}. Se detiene sin reintentar.')
        comprueba(anterior != {c.name: c.value for c in sesion.cookies}, f'cuenta {numero}: sesión renovada')
        marca_actual = None
        for ruta, roles in rutas.items():
            estado, _, html = sesion.pide(ruta)
            # Diagnóstico se oculta en entorno produccion, incluso con sesión.
            esperado = 404 if ruta == '/sistema/diagnostico' else (200 if rol in roles else 403)
            comprueba(estado == esperado, f'cuenta {numero} ({rol}) {ruta}: esperaba {esperado}, recibió {estado}')
            if estado == 200:
                formulario = Formulario(html)
                marca_actual = formulario.marca or marca_actual
                if ruta == '/areas':
                    comprueba(len(formulario.sucursales) == 1, f'cuenta {numero}: solo su sucursal en el selector')
                    if rol == 'gerente' and len(formulario.sucursales) == 1:
                        alcances[formulario.sucursales[0]] = (sesion, marca_actual)
        # Sin marca se rechaza antes de que exista una escritura de negocio.
        estado, _, _ = sesion.pide('/areas', {})
        comprueba(estado == 419, f'cuenta {numero}: POST sin CSRF rechazado')
        if rol != 'gerente':
            estado, _, _ = sesion.pide('/promociones', {'_marca': marca_actual, '_envio': str(uuid.uuid4())})
            comprueba(estado == 403, f'cuenta {numero}: crear promoción sin permiso rechazado')
        if rol != 'gerente':
            estado, _, _ = sesion.pide('/salir', {'_marca': marca_actual})
            comprueba(estado == 302, f'cuenta {numero}: sesión cerrada')
            comprueba(sesion.pide('/panel')[0] == 302, f'cuenta {numero}: panel pide sesión después de salir')
        print(f'  Cuenta {numero}/{len(cuentas)} · {rol}: comprobada', flush=True)

    comprueba(len(alcances) == 2, 'las dos gerencias tienen sucursales distintas')
    for propia, (sesion, marca) in alcances.items():
        for ajena in alcances:
            if propia != ajena:
                estado, _, html = sesion.pide(f'/areas?sucursal={ajena}')
                formulario = Formulario(html)
                comprueba(estado in (403, 404) or (estado == 200 and formulario.sucursales == [propia]),
                           'el filtro de sucursal no amplía el alcance de gerencia')
        sesion.pide('/salir', {'_marca': marca})
    print(f'\n{len(cuentas)} cuentas; {pasadas} comprobaciones aprobadas; {len(fallas)} fallas.', flush=True)
    return int(bool(fallas))


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        # Los errores HTTP y de parsing no vuelcan respuestas ni credenciales.
        print(f'Validación interrumpida: {error if isinstance(error, RuntimeError) else type(error).__name__}', file=sys.stderr)
        sys.exit(1)
