#!/usr/bin/env bash
# Prueba de humo de identidad y permisos, contra el servidor de verdad.
#
#   pruebas/humo-identidad.sh
#
# Crea dos usuarios temporales, recorre entrar/salir, comprueba la marca CSRF,
# los 403 por permiso y la puerta del dispositivo en la API. Al terminar borra
# lo que creó, pase lo que pase.

set -u
BASE="${1:-http://127.0.0.1:8081}"
PHP=/opt/homebrew/opt/php@8.3/bin/php
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
. "$RAIZ/pruebas/exige-entorno.sh"
. "$RAIZ/pruebas/fixtures/entra-segundo-factor.sh"
GALLETAS=$(mktemp -d)/galletas

verde=$'\033[32m'; rojo=$'\033[31m'; gris=$'\033[90m'; nada=$'\033[0m'
pasadas=0; fallas=0

ok()   { printf "  %s✓%s %s\n" "$verde" "$nada" "$1"; pasadas=$((pasadas + 1)); }
mal()  { printf "  %s✗%s %s\n" "$rojo" "$nada" "$1"; fallas=$((fallas + 1)); }
juzga() { if [ "$2" = "$3" ]; then ok "$1"; else mal "$1 — esperaba $3, llegó $2"; fi; }
dice()  { if printf '%s' "$2" | grep -q -- "$3"; then ok "$1"; else mal "$1"; fi; }
calla() { if printf '%s' "$2" | grep -q -- "$3"; then mal "$1"; else ok "$1"; fi; }

# Borra sólo lo de la base. Separada de la del tarro de galletas a propósito:
# juntas, la limpieza inicial se llevaba por delante el directorio donde curl
# guarda la sesión, y todo el guion fallaba con 419 por culpa del guion.
limpia_bd() {
  "$PHP" -r '
    require "'"$RAIZ"'/nucleo/Autocargador.php";
    Nucleo\Autocargador::registrar("'"$RAIZ"'");
    Nucleo\Reloj::fijaLaZona("'"$RAIZ"'");
    require "'"$RAIZ"'/pruebas/Semilla.php";
    $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
    $bd->ejecuta("DELETE FROM intento_acceso");
    $bd->ejecuta("DELETE FROM parametro WHERE clave = \"segundo_factor_web\" AND descripcion = \"humo.identidad\"");
    Pruebas\Semilla::borraUsuarios($bd, "humo.identidad.");
  '
}

limpia() {
  limpia_bd
  rm -rf "$(dirname "$GALLETAS")"
}
trap limpia EXIT

# La contraseña de prueba se genera aquí, vive en esta variable y muere con el
# guion. No se escribe en ningún archivo ni en ningún registro.
CLAVE="prueba-$(head -c 12 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9')"

limpia_bd
"$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  require "'"$RAIZ"'/pruebas/Semilla.php";
  $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
  // En la v2 no hay usuario sin personal (D12): la semilla da de alta a la
  // persona con su puesto y, desde ella, al usuario.
  Pruebas\Semilla::usuario($bd, "humo.identidad.dueno", "administrador", $argv[1]);
  Pruebas\Semilla::usuario($bd, "humo.identidad.mesero", "mesero", $argv[1]);
' "$CLAVE"

echo "${gris}Contra ${BASE}${nada}"

# --- sin sesión ------------------------------------------------------------
echo "${gris}sin sesión${nada}"
RAIZ_HTTP=$(curl -s -m 10 -o /dev/null -w '%{http_code} %{redirect_url}' "$BASE/")
if [ "$RAIZ_HTTP" = "200 " ]; then
  dice "la raíz muestra la landing pública" "$(curl -s -m 10 "$BASE/")" 'Mariscos frescos, servicio de puerto'
else
  juzga "la raíz manda al panel si el sitio está desactivado" "$RAIZ_HTTP" "302 $BASE/panel"
  juzga "y conserva la consulta" "$(curl -s -m 10 -o /dev/null -w '%{redirect_url}' "$BASE/?fecha=2026-11-08")" "$BASE/panel?fecha=2026-11-08"
fi
juzga "el panel sin sesión manda a entrar" "$(curl -s -m 10 -o /dev/null -w '%{http_code} %{redirect_url}' "$BASE/panel")" "302 $BASE/entrar"
juzga "la pantalla de entrada abre"   "$(curl -s -m 10 -o /dev/null -w '%{http_code}' "$BASE/entrar")" 200
juzga "la bitácora pide sesión"       "$(curl -s -m 10 -o /dev/null -w '%{http_code}' "$BASE/bitacora")" 302
juzga "la API responde 401 sin token" "$(curl -s -m 10 -o /dev/null -w '%{http_code}' "$BASE/api/v1/yo")" 401

# --- entrar ----------------------------------------------------------------
echo "${gris}entrar${nada}"
saca_marca() { curl -s -m 10 -c "$GALLETAS" -b "$GALLETAS" "$BASE/entrar" \
  | grep -o 'name="\(_marca\|csrf-token\)" \(value\|content\)="[a-f0-9]*"' | head -1 | sed 's/.*="//;s/"//'; }

MARCA=$(saca_marca)
[ -n "$MARCA" ] && ok "el formulario trae su marca CSRF" || mal "el formulario trae su marca CSRF"

juzga "la contraseña equivocada da 401" \
  "$(curl -s -m 10 -c "$GALLETAS" -b "$GALLETAS" -o /dev/null -w '%{http_code}' \
     -d "_marca=$MARCA&usuario=humo.identidad.dueno&clave=no-es-esa" "$BASE/entrar")" 401

juzga "el POST sin marca da 419" \
  "$(curl -s -m 10 -c "$GALLETAS" -b "$GALLETAS" -o /dev/null -w '%{http_code}' \
     -d "usuario=humo.identidad.dueno&clave=$CLAVE" "$BASE/entrar")" 419

MARCA=$(saca_marca)
# El identificador de sesión de antes de entrar. `Sesion::renueva()` lo cambia
# al entrar, y esa línea no la vigilaba nadie: si alguien la borra, el sistema
# sigue funcionando y una sesión fijada de antemano por quien la pueda plantar
# —un enlace con el identificador, una galleta puesta desde otra pestaña— sigue
# valiendo después de que el dueño teclee su contraseña.
ANTES=$(grep -i 'sesion\|PHPSESSID' "$GALLETAS" | awk '{print $NF}' | tail -1)
juzga "la contraseña correcta entra" \
  "$(curl -s -m 10 -c "$GALLETAS" -b "$GALLETAS" -o /dev/null -w '%{http_code}' \
     -d "_marca=$MARCA&usuario=humo.identidad.dueno&clave=$CLAVE" "$BASE/entrar")" 302
DESPUES=$(grep -i 'sesion\|PHPSESSID' "$GALLETAS" | awk '{print $NF}' | tail -1)
if [ -n "$ANTES" ] && [ -n "$DESPUES" ] && [ "$ANTES" != "$DESPUES" ]; then
  ok "y el identificador de la sesión ya no es el de antes"
else
  mal "y el identificador de la sesión ya no es el de antes — antes «${ANTES}», después «${DESPUES}»"
fi
if completa_segundo_factor_web "$BASE" "$PHP" "$RAIZ" humo.identidad.dueno "$GALLETAS"; then
  ok "el dueño completa el segundo factor antes de recibir identidad"
else
  mal "el dueño completa el segundo factor antes de recibir identidad"
fi

# --- con sesión de dueño ---------------------------------------------------
echo "${gris}con sesión de dueño${nada}"
juzga "el tablero abre"  "$(curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' "$BASE/panel")" 200
juzga "la bitácora abre" "$(curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' "$BASE/bitacora")" 200
# Fase 33: el CSV sale en flujo, con su encabezado y los filtros de la pantalla.
CSV=$(curl -s -m 20 -b "$GALLETAS" -D "$(dirname "$GALLETAS")/cabeceras-bitacora" "$BASE/bitacora.csv?canal=web")
dice "el CSV de la bitácora trae su encabezado" "$CSV" 'Referencia'
dice "y se descarga como archivo" "$(cat "$(dirname "$GALLETAS")/cabeceras-bitacora")" 'attachment; filename="bitacora-'
BITACORA=$(curl -s -m 10 -b "$GALLETAS" "$BASE/bitacora")
dice "y el botón Exportar XLS se ofrece" "$BITACORA" 'href="/bitacora.xlsx'
dice "con Buscar y Limpiar filtro" "$BITACORA" 'Limpiar filtro'
dice "abre con el mes en curso" "$BITACORA" "value=\"$(date +%Y-%m-01)\""
dice "y cuenta sus registros" "$BITACORA" ' registro'
APUNTE=$(printf '%s' "$BITACORA" | grep -o 'modal-detalle-apunte" data-pb-modo="ver" data-pb-id="[0-9]*' | head -1 | sed 's/.*id="//')
dice "Ver abre el antes y el después" "$(curl -s -m 10 -b "$GALLETAS" -H 'Accept: application/json' "$BASE/bitacora/$APUNTE")" 'Después'
dice "el XLS de la bitácora baja como archivo" "$(curl -s -m 30 -b "$GALLETAS" -D - -o /dev/null "$BASE/bitacora.xlsx")" 'bitacora_'
# El título es «Tablero», como el menú, y lleva su subtítulo.
curl -s -m 10 -b "$GALLETAS" "$BASE/panel" | grep -q 'Tablero</h1><p>Lo que hay que atender hoy' \
  && ok "el tablero se titula como el menú" || mal "el tablero se titula como el menú"
# El puesto viene de personal → puesto, no de un perfil suelto en el usuario.
curl -s -m 10 -b "$GALLETAS" "$BASE/perfil" | grep -q 'Administrador' \
  && ok "su perfil dice que es administrador" || mal "su perfil dice que es administrador"

# El diagnóstico se comprobaba sólo por su 302 sin sesión: la página que dice
# «todo en orden» nadie le preguntaba si lo decía. ⚠️ Y contaba las tablas contra
# un **44 escrito a mano** mientras el esquema ya declaraba 45. Eso no la ponía
# en rojo —45 ≥ 44—, la dejaba ciega: con el tope congelado, un guion del
# esquema sin aplicar en el servidor seguiría diciendo «Todo en orden».
#
# ⚠️ Y contar tampoco bastaba. La cuenta se cuadra sola: a una base a la que le
# falte una tabla del negocio y le sobre una de basura le salen los mismos 45, y
# la basura tapa el hueco. Ahora compara **nombres** y dice cuál falta.
DIAGNOSTICO=$(curl -s -m 10 -b "$GALLETAS" "$BASE/sistema/diagnostico")
dice "el diagnóstico dice que todo está en orden" "$DIAGNOSTICO" 'Todo en orden'
dice "y compara las tablas contra las del esquema" "$DIAGNOSTICO" 'tablas del esquema'
calla "y no le falta ninguna"                      "$DIAGNOSTICO" 'faltan:'
if printf '%s' "$DIAGNOSTICO" | grep -q '❌'; then
  mal "ninguna comprobación del diagnóstico está en rojo"
else ok "ninguna comprobación del diagnóstico está en rojo"; fi

# --- con sesión de mesero -------------------------------------------------
echo "${gris}con sesión de mesero${nada}"
rm -f "$GALLETAS"
MARCA=$(saca_marca)
curl -s -m 10 -c "$GALLETAS" -b "$GALLETAS" -o /dev/null \
  -d "_marca=$MARCA&usuario=humo.identidad.mesero&clave=$CLAVE" "$BASE/entrar"

juzga "el tablero abre"                "$(curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' "$BASE/panel")" 200
juzga "la bitácora le da 403"          "$(curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' "$BASE/bitacora")" 403
juzga "y su CSV también"               "$(curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' "$BASE/bitacora.csv")" 403
curl -s -m 10 -b "$GALLETAS" "$BASE/panel" | grep -q 'href="/bitacora"' \
  && mal "el menú no le ofrece la bitácora" || ok "el menú no le ofrece la bitácora"
juzga "la pantalla de seguridad le da 403" "$(curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' "$BASE/seguridad")" 403
curl -s -m 10 -b "$GALLETAS" "$BASE/panel" | grep -q 'href="/seguridad"' \
  && mal "el menú no le ofrece Seguridad" || ok "el menú no le ofrece Seguridad"
dice "el tablero le muestra su acceso a mesas" "$(curl -s -m 10 -b "$GALLETAS" "$BASE/panel")" '/mesas'

# --- la API ----------------------------------------------------------------
echo "${gris}la API y el dispositivo${nada}"
RESPUESTA=$(curl -s -m 10 -H 'Content-Type: application/json' \
  -d "{\"usuario\":\"humo.identidad.mesero\",\"clave\":\"$CLAVE\",\"dispositivo\":{\"identificador\":\"humo-telefono-1\",\"nombre\":\"Teléfono de humo\"}}" \
  "$BASE/api/v1/entrar")

# La puerta de la app no dice cuál de los dos datos falló, ni en el mensaje ni
# en el tiempo. ⚠️ Medido antes del arreglo: 73 ms con un usuario que existe y
# 6 ms con uno que no, porque sin renglón no había `password_verify` que hacer.
# Aquí se comprueba lo que un shell puede comprobar sin ponerse quisquilloso con
# el reloj —que las dos respuestas sean idénticas—; la del tiempo, que compara
# las dos medidas entre sí, está en `pruebas/modelos/UsuariosPrueba.php`.
FALLA_CLAVE=$(curl -s -m 10 -w '|%{http_code}' -H 'Content-Type: application/json' \
  -d "{\"usuario\":\"humo.identidad.mesero\",\"clave\":\"no-es-esa\",\"dispositivo\":{\"identificador\":\"humo-telefono-1\"}}" \
  "$BASE/api/v1/entrar")
FALLA_USUARIO=$(curl -s -m 10 -w '|%{http_code}' -H 'Content-Type: application/json' \
  -d "{\"usuario\":\"no.existe.nadie\",\"clave\":\"no-es-esa\",\"dispositivo\":{\"identificador\":\"humo-telefono-1\"}}" \
  "$BASE/api/v1/entrar")

juzga "la contraseña mala por la API da 401" "${FALLA_CLAVE##*|}" 401
juzga "y el usuario que no existe contesta exactamente lo mismo" "$FALLA_USUARIO" "$FALLA_CLAVE"

TOKEN=$(printf '%s' "$RESPUESTA" | sed -n 's/.*"token":"\([a-f0-9]*\)".*/\1/p')
[ -n "$TOKEN" ] && ok "el acceso por la API entrega token" || mal "el acceso por la API entrega token"

printf '%s' "$RESPUESTA" | grep -q '"autorizado":false' \
  && ok "el teléfono nuevo llega sin autorizar" || mal "el teléfono nuevo llega sin autorizar"

juzga "con token, saber quién soy funciona" \
  "$(curl -s -m 10 -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $TOKEN" "$BASE/api/v1/yo")" 200

juzga "sin autorizar el teléfono, no opera" \
  "$(curl -s -m 10 -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $TOKEN" "$BASE/api/v1/estado")" 403

juzga "un token inventado da 401" \
  "$(curl -s -m 10 -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $(head -c 32 /dev/urandom | xxd -p -c 64)" "$BASE/api/v1/yo")" 401

# Se autoriza el teléfono desde la base, que es lo que hace el botón de la web.
"$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
  $d  = new Modelos\Dispositivos($bd);
  $t  = $d->porIdentificador("humo-telefono-1");
  $d->autoriza((int) $t["id"]);
'

juzga "autorizado, ya opera" \
  "$(curl -s -m 10 -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $TOKEN" "$BASE/api/v1/estado")" 200

curl -s -m 10 -X POST -H "Authorization: Bearer $TOKEN" "$BASE/api/v1/salir" >/dev/null
juzga "después de salir, el token no vale" \
  "$(curl -s -m 10 -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $TOKEN" "$BASE/api/v1/yo")" 401

# --- límite persistente compartido ----------------------------------------
echo "$gris""el límite persistente compartido""$nada"

# Se parte de cero para que esta prueba mida exactamente cuatro rechazos web y
# uno por API. La base está aislada y el cerrojo de arriba ya comprobó el sufijo
# y el entorno antes de permitir cualquier borrado.
limpia_intentos() {
  "$PHP" -r '
    require "'"$RAIZ"'/nucleo/Autocargador.php";
    Nucleo\Autocargador::registrar("'"$RAIZ"'");
    $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
    $bd->ejecuta("DELETE FROM intento_acceso");
  '
}

CUERPO_LIMITE_1="$(dirname "$GALLETAS")/limite-1.json"
CUERPO_LIMITE_2="$(dirname "$GALLETAS")/limite-2.json"
CABECERAS_LIMITE="$(dirname "$GALLETAS")/limite-cabeceras"
CODIGO_LIMITE=""
COOKIES_LIMITE=""
MARCA_LIMITE=""

bloquea_con_web_y_api() {
  local cuenta="$1"
  local cuerpo="$2"
  local nombre_cookies
  local cookies
  local marca
  local codigo
  local intento

  nombre_cookies=$(printf '%s' "$cuenta" | tr '.' '-')
  cookies="$(dirname "$GALLETAS")/limite-$nombre_cookies.cookies"
  marca=$(curl -s -m 10 -c "$cookies" -b "$cookies" "$BASE/entrar" \
    | grep -o 'name="\(_marca\|csrf-token\)" \(value\|content\)="[a-f0-9]*"' | head -1 | sed 's/.*="//;s/"//')

  for intento in 1 2 3 4; do
    codigo=$(curl -s -m 10 -c "$cookies" -b "$cookies" -o /dev/null -w '%{http_code}' \
      -d "_marca=$marca&usuario=$cuenta&clave=deliberadamente-incorrecta" "$BASE/entrar")
    juzga "el rechazo web $intento de $cuenta aún da 401" "$codigo" 401
  done

  CODIGO_LIMITE=$(curl -s -m 10 -D "$CABECERAS_LIMITE" -o "$cuerpo" -w '%{http_code}' \
    -H 'Content-Type: application/json' \
    -d "{\"usuario\":\"$cuenta\",\"clave\":\"deliberadamente-incorrecta\",\"dispositivo\":{\"identificador\":\"humo-limite\"}}" \
    "$BASE/api/v1/entrar")
  COOKIES_LIMITE="$cookies"
  MARCA_LIMITE="$marca"
}

limpia_intentos
bloquea_con_web_y_api "humo.no.existe" "$CUERPO_LIMITE_1"
juzga "el quinto rechazo compartido por web y API da 429" "$CODIGO_LIMITE" 429
grep -Eiq '^Retry-After: [1-9][0-9]*\r?$' "$CABECERAS_LIMITE" \
  && ok "el 429 incluye Retry-After en segundos" || mal "el 429 incluye Retry-After en segundos"
dice "el 429 de la API usa la clave estable" "$(cat "$CUERPO_LIMITE_1")" '"clave":"demasiados_intentos"'

juzga "el bloqueo creado por la API también se aplica en la web" \
  "$(curl -s -m 10 -c "$COOKIES_LIMITE" -b "$COOKIES_LIMITE" -o /dev/null -w '%{http_code}' \
     -d "_marca=$MARCA_LIMITE&usuario=humo.no.existe&clave=otra" "$BASE/entrar")" 429

# El cuerpo 429 debe ser idéntico exista o no la cuenta. Se restablece sólo el
# contador y se repite la misma secuencia con un usuario real.
limpia_intentos
bloquea_con_web_y_api "humo.identidad.dueno" "$CUERPO_LIMITE_2"
juzga "una cuenta existente también queda bloqueada en el quinto rechazo" "$CODIGO_LIMITE" 429
if cmp -s "$CUERPO_LIMITE_1" "$CUERPO_LIMITE_2"; then
  ok "el 429 no revela si la cuenta existe"
else
  mal "el 429 no revela si la cuenta existe"
fi
limpia_intentos

# --- la sesión quieta ------------------------------------------------------
echo "${gris}la sesión que lleva mucho quieta${nada}"

# `pruebas/nucleo/SesionQuietaPrueba.php` prueba el tope con el intermediario en
# la mano. Lo que sólo se ve aquí es el camino de verdad: que el sello se escriba
# en la sesión **de un navegador**, que el sistema la cierre, y que la pantalla
# de entrada diga por qué.
#
# El sello se envejece en el archivo de la sesión, que es donde vive. Si el
# archivo no aparece, esto **falla**: una comprobación que no puede correr no
# tiene por qué ponerse verde.
QUIETA=$(mktemp -d)/quieta
entra_web_segura "$BASE" "$PHP" "$RAIZ" humo.identidad.dueno "$CLAVE" "$QUIETA" \
  || mal "el dueño vuelve a completar contraseña y segundo factor"
juzga "la sesión recién hecha entra al tablero" \
  "$(curl -s -m 10 -c "$QUIETA" -b "$QUIETA" -o /dev/null -w '%{http_code}' "$BASE/panel")" 200

SESION_ID=$(grep -i 'sesion' "$QUIETA" | awk '{print $NF}' | tail -1)
ARCHIVO=""
# Desde el `048` la sesión vive en la carpeta propia del sistema, no en la
# temporal de PHP, cuyo barrido la borraba a los 24 minutos.
for D in "$RAIZ/almacenamiento/sesiones-pruebas" "$RAIZ/almacenamiento/sesiones"; do
  [ -f "$D/sess_$SESION_ID" ] && { ARCHIVO="$D/sess_$SESION_ID"; break; }
done

if [ -z "$ARCHIVO" ]; then
  mal "se encuentra el archivo de la sesión para envejecerlo — sin él no se puede comprobar el cierre"
else
  ok "se encuentra el archivo de la sesión para envejecerlo"

  dice "y el sistema le escribió su sello de último uso" "$(cat "$ARCHIVO")" 'ultimo_uso'

  envejece() { "$PHP" -r '
    $t = file_get_contents($argv[1]);
    $n = preg_replace_callback("/ultimo_uso\|i:(\d+);/",
      fn ($m) => "ultimo_uso|i:" . ((int) $m[1] - (int) $argv[2]) . ";", $t, 1, $cuantos);
    file_put_contents($argv[1], $n);
    exit($cuantos ? 0 : 1);' "$ARCHIVO" "$1"; }

  # El dueño es administrador, un puesto sensible: su tope son 60 minutos desde
  # el `057` (D19; antes 30, del `053`). El día del `048` sigue siendo el de los
  # demás puestos, y ése lo comprueba `pruebas/nucleo/SesionQuietaPrueba.php`.
  envejece $((59 * 60))
  juzga "un puesto sensible quieto 59 minutos sigue adentro" \
    "$(curl -s -m 10 -c "$QUIETA" -b "$QUIETA" -o /dev/null -w '%{http_code}' "$BASE/panel")" 200

  # Y esa petición volvió a poner el sello: hay que envejecerlo otra vez.
  envejece $((61 * 60))
  juzga "quieto 61 minutos, a la calle" \
    "$(curl -s -m 10 -c "$QUIETA" -b "$QUIETA" -o /dev/null -w '%{http_code}' "$BASE/panel")" 302

  # ⚠️ Sin `-L`: seguir la redirección **consume el aviso**, que se borra al
  # leerse, y esto diría que no existe.
  dice "y la pantalla de entrada dice por qué" \
    "$(curl -s -m 10 -c "$QUIETA" -b "$QUIETA" "$BASE/entrar")" 'Sesión vencida'

  juzga "con la sesión cerrada, el tablero ya no abre" \
    "$(curl -s -m 10 -c "$QUIETA" -b "$QUIETA" -o /dev/null -w '%{http_code}' "$BASE/panel")" 302
fi
rm -rf "$(dirname "$QUIETA")"

# --- el segundo factor apagado ------------------------------------------------
echo "${gris}el segundo factor apagado${nada}"

# Bitácora 98: `segundo_factor_web` en 0 quita el código al entrar y en las
# autorizaciones. `SegundoFactorParametroPrueba` lo prueba en los servicios; aquí
# se ve el camino de verdad: la entrada y la pantalla. Un renglón de hoy gana al
# del esquema; `limpia_bd` lo quita pase lo que pase.
sf_web() { "$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  Nucleo\Reloj::fijaLaZona("'"$RAIZ"'");
  $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
  $bd->ejecuta("DELETE FROM parametro WHERE clave = \"segundo_factor_web\" AND descripcion = \"humo.identidad\"");
  if ($argv[1] !== "") {
    $bd->ejecuta("INSERT INTO parametro (clave, valor, descripcion, vigente_desde) VALUES (\"segundo_factor_web\", ?, \"humo.identidad\", CURDATE())", [$argv[1]]);
  }' "$1"; }

APAGADO=$(mktemp -d)/apagado
sf_web 0
MARCA=$(curl -s -m 10 -c "$APAGADO" -b "$APAGADO" "$BASE/entrar" \
  | grep -o 'name="\(_marca\|csrf-token\)" \(value\|content\)="[a-f0-9]*"' | head -1 | sed 's/.*="//;s/"//')
juzga "apagado, el dueño entra con usuario y contraseña directo al tablero" \
  "$(curl -s -m 10 -c "$APAGADO" -b "$APAGADO" -o /dev/null -w '%{redirect_url}' \
     -d "_marca=$MARCA&usuario=humo.identidad.dueno&clave=$CLAVE" "$BASE/entrar")" "$BASE/panel"
juzga "y el tablero abre" "$(curl -s -m 10 -b "$APAGADO" -o /dev/null -w '%{http_code}' "$BASE/panel")" 200
# Las autorizaciones de caja y descuentos, que también lo piden, traen su caso con la fase 7.

sf_web ""
rm -f "$APAGADO"
MARCA=$(curl -s -m 10 -c "$APAGADO" -b "$APAGADO" "$BASE/entrar" \
  | grep -o 'name="\(_marca\|csrf-token\)" \(value\|content\)="[a-f0-9]*"' | head -1 | sed 's/.*="//;s/"//')
# A `/segundo-factor`, o a `/segundo-factor/configurar` si no tenía alta.
dice "y al entrar de nuevo se pide el código" \
  "$(curl -s -m 10 -c "$APAGADO" -b "$APAGADO" -o /dev/null -w '%{redirect_url}' \
     -d "_marca=$MARCA&usuario=humo.identidad.dueno&clave=$CLAVE" "$BASE/entrar")" "^$BASE/segundo-factor"
calla "y no al tablero" \
  "$(curl -s -m 10 -c "$APAGADO" -b "$APAGADO" -o /dev/null -w '%{http_code}' "$BASE/panel")" '^200$'
rm -rf "$(dirname "$APAGADO")"
limpia_intentos 2>/dev/null || true

# --- la pantalla de seguridad ------------------------------------------------
echo "${gris}la pantalla de seguridad${nada}"

# El interruptor de la web. Que la contraseña y el código se exijan de verdad lo
# prueba `SeguridadPrueba`; aquí, que la pantalla exista para el dueño y que
# un envío sin código no apague nada.
SEGURA=$(mktemp -d)/segura
entra_web_segura "$BASE" "$PHP" "$RAIZ" humo.identidad.dueno "$CLAVE" "$SEGURA" \
  || mal "el dueño entra con contraseña y segundo factor para ver Seguridad"
PANTALLA=$(curl -s -m 10 -b "$SEGURA" "$BASE/seguridad")
dice "el dueño abre Seguridad y ve cómo apagarlo" "$PANTALLA" 'Apagar código'
dice "y el menú se la ofrece" "$PANTALLA" 'href="/seguridad"'
MARCA_SEG=$(printf '%s' "$PANTALLA" | grep -o 'name="\(_marca\|csrf-token\)" \(value\|content\)="[a-f0-9]*"' | head -1 | sed 's/.*="//;s/"//')
juzga "apagarlo con la contraseña pero sin código se rechaza" \
  "$(curl -s -m 10 -b "$SEGURA" -o /dev/null -w '%{http_code}' -H 'Accept: application/json' \
     --data-urlencode "_marca=$MARCA_SEG" --data-urlencode "encender=0" --data-urlencode "clave=$CLAVE" \
     "$BASE/seguridad/segundo-factor")" 422
dice "y sigue encendido" "$(curl -s -m 10 -b "$SEGURA" "$BASE/seguridad")" 'Apagar código'
rm -rf "$(dirname "$SEGURA")"

# Un identificador que este servidor nunca emitió no se adopta. Se pone desde el
# código y no desde el `php.ini`, porque el `php.ini` del hospedaje es de otro.
INVENTADO=$(head -c 40 /dev/urandom | base64 | tr -dc 'a-z0-9' | head -c 26)
dice "un identificador de sesión inventado no se adopta" \
  "$(curl -s -m 10 -o /dev/null -D - -H "Cookie: sesion=$INVENTADO" "$BASE/entrar")" 'Set-Cookie: sesion='

echo
if [ "$fallas" -eq 0 ]; then
  echo "${verde}${pasadas} comprobaciones, todas pasan.${nada}"
  exit 0
fi
echo "${rojo}${fallas} de $((pasadas + fallas)) fallan.${nada}"
exit 1
