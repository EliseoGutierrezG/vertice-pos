<?php
declare(strict_types=1);

/**
 * Prepara un código TOTP consumible por una prueba HTTP.
 *
 * Nunca imprime el secreto. Sólo funciona con la base aislada de pruebas y,
 * si el periodo actual ya se consumió, renueva el factor del usuario temporal
 * para no introducir esperas de treinta segundos en la suite.
 */

$raiz = dirname(__DIR__, 2);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);
Nucleo\CerrojoPruebas::exige($raiz);

$nombre = trim((string) ($argv[1] ?? ''));
if ($nombre === '') {
    fwrite(STDERR, "Uso: php totp-web.php USUARIO\n");
    exit(2);
}

$bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos($raiz));
$usuario = $bd->fila('SELECT id,totp_secreto_cifrado,totp_confirmado_en,totp_ultimo_periodo FROM usuario WHERE usuario=?', [$nombre]);
if ($usuario === null) {
    fwrite(STDERR, "El usuario temporal no existe\n");
    exit(3);
}

$registro = new Nucleo\Registro(sys_get_temp_dir() . '/timon-pruebas', false);
$bitacora = new Nucleo\Bitacora($bd, $registro);
$totp = new Dominio\Totp();
$cifrador = new Nucleo\Seguridad\Cifrador((string) Nucleo\Configuracion::seguridad($raiz)['llave_totp']);
$segundo = new Servicios\SegundoFactor($bd, $cifrador, $totp, $bitacora, new Modelos\Parametros($bd));
$id = (int) $usuario['id'];

if (!$segundo->requiere($id)) {
    echo "NO_TOTP\n";
    exit(0);
}

$periodoActual = intdiv(time(), 30);
$ultimo = $usuario['totp_ultimo_periodo'] === null ? null : (int) $usuario['totp_ultimo_periodo'];
if ($usuario['totp_confirmado_en'] !== null && $ultimo !== null && $ultimo >= $periodoActual) {
    $bd->transaccion(function (Nucleo\BaseDatos $bd) use ($id): void {
        $bd->ejecuta('DELETE FROM totp_codigo_recuperacion WHERE id_usuario=?', [$id]);
        $bd->ejecuta(
            'UPDATE usuario SET totp_secreto_cifrado=NULL,totp_confirmado_en=NULL,totp_ultimo_periodo=NULL,sesion_version=sesion_version+1 WHERE id=?',
            [$id]
        );
    });
    $usuario['totp_secreto_cifrado'] = null;
    $usuario['totp_confirmado_en'] = null;
}

if ($usuario['totp_confirmado_en'] === null) {
    $alta = $segundo->prepara($id, '127.0.0.1');
    $segundo->confirma($id, $totp->codigo($alta['secreto'], time() - 30), '127.0.0.1');
    $secreto = $alta['secreto'];
} else {
    $sobre = (string) $usuario['totp_secreto_cifrado'];
    if ($sobre === '') {
        fwrite(STDERR, "El segundo factor confirmado no tiene secreto\n");
        exit(4);
    }
    $secreto = $cifrador->descifra($sobre);
}

echo $totp->codigo($secreto) . "\n";
