<?php
declare(strict_types=1);

/**
 * Lo que `pruebas/humo-sucursal.py` necesita hacer directo en una base: en el
 * central (registrar, cambiar el catálogo, intentar escribir la operación) o
 * en la copia de la sucursal (resumir lo que tiene). Trabaja sobre la
 * sucursal «Humo <clave>» que siembra `pruebas/fixtures/comanda.php`.
 *
 *   php pruebas/fixtures/sucursal.php (registra|cambia-catalogo|escribe|resumen|desregistra) <clave>
 */

use Nucleo\Aplicacion;
use Nucleo\Autocargador;
use Nucleo\BaseDatos;
use Nucleo\CerrojoPruebas;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Nucleo\Reloj;

$raiz = dirname(__DIR__, 2);
require $raiz . '/nucleo/Autocargador.php';
Autocargador::registrar($raiz);
CerrojoPruebas::exige($raiz);
Reloj::fijaLaZona($raiz);
$c = (new Aplicacion($raiz))->contenedor();
$bd = $c->obtiene(BaseDatos::class);
$modo = $argv[1] ?? '';
$clave = $argv[2] ?? '';
if (!preg_match('/^[a-f0-9]{6}$/D', $clave)) {
    exit(2);
}
$publica = 'H' . strtoupper($clave);
$sucursal = (int) $bd->valor('SELECT id FROM sucursal WHERE clave = ?', [$publica]);
if ($sucursal === 0 && $modo !== 'desregistra') {
    exit(3);
}
$comoAdmin = static function () use ($bd, $c, $clave): void {
    $c->obtiene(Identidad::class)->establece((int) $bd->valor('SELECT id FROM usuario WHERE usuario = ?', ['humo.comanda.' . $clave . '.admin']));
};
$sale = static function (array $datos): never {
    echo json_encode($datos, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
    exit;
};

if ($modo === 'registra') {
    $comoAdmin();
    $sale(['sucursal' => $sucursal] + $c->obtiene(Servicios\Instalaciones::class)->registra($sucursal, 'Humo ' . $clave));
}

if ($modo === 'cambia-catalogo') {
    $comoAdmin();
    $bd->ejecuta('UPDATE platillo_sucursal SET precio = ? WHERE id_sucursal = ?', ['140.00', $sucursal]);
    $reservacion = $bd->inserta('INSERT INTO reservacion (id_sucursal, cliente, telefono, personas, desde, hasta) VALUES (?, ?, ?, ?, ?, ?)',
        [$sucursal, 'Cliente del sitio', '5500000000', 4, date('Y-m-d 14:00:00', strtotime('+2 days')), date('Y-m-d 16:00:00', strtotime('+2 days'))]);
    $sale(['reservacion' => $reservacion]);
}

if ($modo === 'escribe') {
    try {
        $c->obtiene(Servicios\OperacionRestaurante::class)->exigeOperaAqui($sucursal);
        $sale(['estado' => 200]);
    } catch (ErrorHttp $e) {
        $sale(['estado' => $e->estado()]);
    }
}

if ($modo === 'resumen') {
    $hay = static fn (string $tabla): bool => $bd->valor('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', [$tabla]) !== null;
    $sale([
        'cuentas' => $bd->filas('SELECT id, estado, abierta FROM cuenta WHERE id_sucursal = ? ORDER BY id', [$sucursal]),
        'items' => (int) $bd->valor('SELECT COUNT(*) FROM cuenta_item i JOIN cuenta c ON c.id = i.id_cuenta WHERE c.id_sucursal = ?', [$sucursal]),
        'pagos' => $bd->filas('SELECT p.id, p.folio, p.total, p.propina FROM pago_cuenta p JOIN cuenta c ON c.id = p.id_cuenta WHERE c.id_sucursal = ? ORDER BY p.id', [$sucursal]),
        'turnos' => $bd->filas('SELECT id, abierto, fondo, efectivo_declarado, efectivo_esperado FROM turno_caja WHERE id_sucursal = ? ORDER BY id', [$sucursal]),
        'folio' => $bd->valor('SELECT ultimo FROM folio_serie WHERE serie = ?', ['ticket:' . $sucursal]),
        'mesas' => $bd->filas('SELECT id, estado FROM mesa WHERE id_sucursal = ? ORDER BY id', [$sucursal]),
        'precio' => $bd->valor('SELECT precio FROM platillo_sucursal WHERE id_sucursal = ? LIMIT 1', [$sucursal]),
        'reservaciones' => array_map('intval', array_column($bd->filas('SELECT id FROM reservacion WHERE id_sucursal = ? ORDER BY id', [$sucursal]), 'id')),
        'apuntes_de_sucursal' => (int) $bd->valor('SELECT COUNT(*) FROM bitacora WHERE origen_instalacion IS NOT NULL'),
        'por_subir' => $hay('cambio_replica') ? (int) $bd->valor('SELECT COUNT(*) FROM cambio_replica WHERE enviado = 0') : null,
    ]);
}

if ($modo === 'desregistra') {
    if ($sucursal !== 0) {
        $bd->ejecuta('DELETE FROM instalacion WHERE id_sucursal = ?', [$sucursal]);
        $bd->ejecuta('DELETE FROM liberacion WHERE notas = ?', ['humo-' . $clave]);
        $bd->ejecuta('UPDATE sucursal SET servidor = ? WHERE id = ?', ['central', $sucursal]);
        $bd->ejecuta('DELETE a FROM asiento_caja a JOIN turno_caja t ON t.id = a.id_turno WHERE t.id_sucursal = ?', [$sucursal]);
    }
    exit;
}

if ($modo === 'asigna-liberacion') {
    $comoAdmin();
    $descriptor = json_decode((string) file_get_contents($argv[4]), true, flags: JSON_THROW_ON_ERROR);
    // Llave efímera exclusiva de esta prueba; nunca cambia la de la instalación.
    $servicio = new Servicios\Liberaciones($bd, $c->obtiene(Nucleo\Bitacora::class), $c->obtiene(Identidad::class),
        $argv[5], trim((string) file_get_contents($argv[6])));
    $id = $servicio->registra($argv[3], $descriptor, 'humo-' . $clave);
    $servicio->asigna((int) $bd->valor('SELECT id FROM instalacion WHERE id_sucursal = ? AND activa = 1', [$sucursal]), $id);
    $sale(['id' => $id]);
}

if ($modo === 'quieta') {
    // Solo la copia aislada: permite probar la ventana segura a cualquier hora.
    $bd->ejecuta('UPDATE bitacora SET momento = NOW() - INTERVAL 1 DAY');
    $sale(['lista' => true]);
}

exit(2);
