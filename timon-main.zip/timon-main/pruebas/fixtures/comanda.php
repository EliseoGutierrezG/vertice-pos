<?php
declare(strict_types=1);

use Nucleo\Aplicacion;
use Nucleo\Autocargador;
use Nucleo\BaseDatos;
use Nucleo\CerrojoPruebas;
use Nucleo\Identidad;
use Nucleo\Reloj;
use Pruebas\Semilla;
use Servicios\ImpresionRestaurante;
use Servicios\InventarioRestaurante;

$raiz = dirname(__DIR__, 2);
require $raiz . '/nucleo/Autocargador.php';
Autocargador::registrar($raiz);
require $raiz . '/pruebas/Semilla.php';
CerrojoPruebas::exige($raiz);
Reloj::fijaLaZona($raiz);
$c = (new Aplicacion($raiz))->contenedor();
$bd = $c->obtiene(BaseDatos::class);
$modo = $argv[1] ?? '';
$clave = $argv[2] ?? '';
if (!preg_match('/^[a-f0-9]{6}$/D', $clave)) {
    exit(2);
}
$prefijo = 'humo.comanda.' . $clave . '.';
$nombre = 'Humo ' . $clave;
$publica = 'H' . strtoupper($clave);

if ($modo === 'prepara') {
    $datos = $bd->transaccion(function () use ($bd, $c, $nombre, $publica, $prefijo): array {
        $sucursal = $bd->inserta('INSERT INTO sucursal (nombre, clave) VALUES (?, ?)', [$nombre, $publica]);
        $area = $bd->inserta('INSERT INTO area (id_sucursal,nombre) VALUES (?, ?)', [$sucursal, 'Salón']);
        $mesas = [];
        for ($n = 1; $n <= 8; $n++) {
            $mesas[] = $bd->inserta('INSERT INTO mesa (id_sucursal,id_area,numero,capacidad,x,y) VALUES (?, ?, ?, 4, ?, ?)',
                [$sucursal, $area, (string) $n, ($n % 4) * 28 + 8, $n <= 4 ? 30 : 68]);
        }
        $admin = Semilla::usuario($bd, $prefijo . 'admin', 'administrador');
        $identidad = $c->obtiene(Identidad::class);
        $identidad->establece($admin);
        $categoria = $bd->inserta('INSERT INTO categoria_menu (nombre) VALUES (?)', [$nombre]);
        $platillo = $bd->inserta("INSERT INTO platillo (id_categoria,nombre,preparacion) VALUES (?, 'Tostada de atún', 'fria')", [$categoria]);
        $bd->ejecuta('INSERT INTO platillo_sucursal (id_sucursal,id_platillo,precio) VALUES (?, ?, 125)', [$sucursal, $platillo]);
        $modificador = $bd->inserta("INSERT INTO modificador_platillo (id_platillo,nombre,suplemento) VALUES (?, 'Salsa aparte', 5)", [$platillo]);
        $c->obtiene(ImpresionRestaurante::class)->registra($sucursal, 0,
            ['nombre' => 'Térmica de prueba', 'ip' => '192.168.10.15', 'destino' => 'fria']);
        $inventario = $c->obtiene(InventarioRestaurante::class);
        $inventario->guarda($sucursal, 'insumo', ['nombre' => 'Atún de prueba', 'unidad' => 'kg']);
        $inventario->guarda($sucursal, 'proveedor', ['nombre' => 'Proveedor de prueba']);
        $insumo = $bd->valor('SELECT id FROM insumo WHERE id_sucursal = ?', [$sucursal]);
        $proveedor = $bd->valor('SELECT id FROM proveedor WHERE id_sucursal = ?', [$sucursal]);
        foreach ([2, 7] as $dias) {
            $inventario->guarda($sucursal, 'compra', ['id_proveedor' => $proveedor, 'referencia' => 'Lote ' . $dias,
                'id_insumo' => $insumo, 'cantidad' => '1.000', 'costo' => '80.00', 'vence' => date('Y-m-d', strtotime('+' . $dias . ' days'))]);
            $compra = $bd->valor('SELECT MAX(id) FROM compra_insumo WHERE id_sucursal = ?', [$sucursal]);
            $inventario->guarda($sucursal, 'recibir', ['id_compra' => $compra]);
        }
        $inventario->guarda($sucursal, 'receta', ['id_platillo' => $platillo, 'id_insumo' => $insumo, 'cantidad' => '0.200']);

        $pin = (string) random_int(100000, 999999);
        foreach (['mesero','cajero','cocina','gerente'] as $rol) {
            $usuario = Semilla::usuario($bd, $prefijo . $rol, $rol, idSucursal: $sucursal);
            $bd->ejecuta('UPDATE usuario SET pin_hash = ? WHERE id = ?', [password_hash($pin, PASSWORD_DEFAULT), $usuario]);
        }
        return compact('sucursal','mesas','platillo','modificador','pin','prefijo','publica');
    });
    echo json_encode($datos, JSON_THROW_ON_ERROR);
    exit;
}

if ($modo === 'autoriza') {
    $sucursal = (int) $bd->valor('SELECT id FROM sucursal WHERE clave = ?', [$publica]);
    $admin = (int) $bd->valor('SELECT id FROM usuario WHERE usuario = ?', [$prefijo . 'admin']);
    $c->obtiene(Identidad::class)->establece($admin);
    $c->obtiene(\Servicios\EquiposRestaurante::class)->autoriza($sucursal, $argv[3], $argv[4]);
    exit;
}

if ($modo === 'confirma-reserva') {
    $sucursal = (int) $bd->valor('SELECT id FROM sucursal WHERE clave = ?', [$publica]);
    $admin = (int) $bd->valor('SELECT id FROM usuario WHERE usuario = ?', [$prefijo . 'admin']);
    $c->obtiene(Identidad::class)->establece($admin);
    $id = (int) $bd->valor('SELECT MAX(id) FROM reservacion WHERE id_sucursal = ?', [$sucursal]);
    $c->obtiene(\Servicios\Reservaciones::class)->cambia($sucursal, $id, ['estado' => 'confirmada', 'id_mesa' => $argv[3]]);
    exit;
}

if ($modo === 'promocion') {
    // Un 2x1 vigente todo el día para el platillo de la prueba.
    $sucursal = (int) $bd->valor('SELECT id FROM sucursal WHERE clave = ?', [$publica]);
    $admin = (int) $bd->valor('SELECT id FROM usuario WHERE usuario = ?', [$prefijo . 'admin']);
    $c->obtiene(Identidad::class)->establece($admin);
    echo $c->obtiene(\Servicios\Promociones::class)->guarda(0, ['nombre' => 'Humo al 2x1', 'tipo' => 'nxm', 'lleva' => '2', 'paga' => '1',
        'desde' => date('Y-m-d'), 'dias' => range(1, 7), 'platillos' => [(int) $argv[3]], 'sucursales' => [$sucursal]])['id'];
    exit;
}

if ($modo === 'demora-impresion') {
    $sucursal = (int) $bd->valor('SELECT id FROM sucursal WHERE clave = ?', [$publica]);
    $bd->ejecuta(
        "UPDATE trabajo_impresion SET creado_en = DATE_SUB(NOW(), INTERVAL 21 SECOND)
         WHERE id_sucursal = ? AND estado = 'pendiente'",
        [$sucursal]
    );
    exit;
}

if ($modo === 'comprueba') {
    $sucursal = (int) $bd->valor('SELECT id FROM sucursal WHERE clave = ?', [$publica]);
    $insumo = (int) $bd->valor('SELECT id FROM insumo WHERE id_sucursal = ?', [$sucursal]);
    echo json_encode([
        'lotes' => array_column($bd->filas('SELECT saldo FROM lote_insumo WHERE id_insumo = ? ORDER BY vence', [$insumo]), 'saldo'),
        'rondas' => (int) $bd->valor('SELECT COUNT(*) FROM ronda r JOIN cuenta c ON c.id = r.id_cuenta WHERE c.id_sucursal = ?', [$sucursal]),
        'pagos' => (int) $bd->valor('SELECT COUNT(*) FROM pago_cuenta p JOIN cuenta c ON c.id = p.id_cuenta WHERE c.id_sucursal = ?', [$sucursal]),
    ], JSON_THROW_ON_ERROR);
    exit;
}

if ($modo !== 'limpia') {
    exit(2);
}
$sucursal = $bd->valor('SELECT id FROM sucursal WHERE clave = ?', [$publica]);
if ($sucursal === null) {
    exit;
}
$bd->transaccion(function () use ($bd, $sucursal, $nombre, $prefijo): void {
    $p = [$sucursal];
    $bd->ejecuta('DELETE k FROM kardex_insumo k JOIN lote_insumo l ON l.id = k.id_lote
        JOIN insumo i ON i.id = l.id_insumo WHERE i.id_sucursal = ?', $p);
    $bd->ejecuta('DELETE l FROM lote_insumo l JOIN insumo i ON i.id = l.id_insumo WHERE i.id_sucursal = ?', $p);
    $bd->ejecuta('DELETE l FROM compra_insumo_linea l JOIN compra_insumo c ON c.id = l.id_compra WHERE c.id_sucursal = ?', $p);
    $bd->ejecuta('DELETE f FROM pago_cuenta_forma f JOIN pago_cuenta p ON p.id = f.id_pago
        JOIN cuenta c ON c.id = p.id_cuenta WHERE c.id_sucursal = ?', $p);
    $bd->ejecuta('DELETE p FROM pago_cuenta p JOIN cuenta c ON c.id = p.id_cuenta WHERE c.id_sucursal = ?', $p);
    $bd->ejecuta('DELETE FROM faltante_insumo WHERE id_sucursal = ?', $p);
    $bd->ejecuta('DELETE i FROM cuenta_item i JOIN cuenta c ON c.id = i.id_cuenta WHERE c.id_sucursal = ?', $p);
    $bd->ejecuta('DELETE r FROM ronda r JOIN cuenta c ON c.id = r.id_cuenta WHERE c.id_sucursal = ?', $p);
    $promos = array_column($bd->filas('SELECT id_promocion FROM promocion_sucursal WHERE id_sucursal = ?', $p), 'id_promocion');
    foreach ($promos as $promo) {
        $bd->ejecuta('DELETE FROM promocion_platillo WHERE id_promocion = ?', [$promo]);
        $bd->ejecuta('DELETE FROM promocion_sucursal WHERE id_promocion = ?', [$promo]);
        $bd->ejecuta('DELETE FROM promocion WHERE id = ?', [$promo]);
    }
    $bd->ejecuta('DELETE se FROM sesion_equipo se JOIN equipo e ON e.id = se.id_equipo WHERE e.id_sucursal = ?', $p);
    $bd->ejecuta('DELETE FROM trabajo_impresion WHERE id_sucursal = ? ORDER BY id DESC', $p);
    $bd->ejecuta('DELETE FROM cuenta_mesa WHERE id_sucursal = ?', $p);
    $bd->ejecuta('DELETE FROM cuenta WHERE id_sucursal = ? AND id_cuenta_madre IS NOT NULL', $p);
    foreach (['impresora','cuenta','turno_caja','evento_sucursal','reservacion',
        'receta_insumo','platillo_sucursal','compra_insumo','proveedor','insumo','mesa','area','equipo'] as $tabla) {
        $bd->ejecuta('DELETE FROM ' . $tabla . ' WHERE id_sucursal = ?', $p);
    }
    $bd->ejecuta('DELETE m FROM modificador_platillo m JOIN platillo p ON p.id = m.id_platillo
        JOIN categoria_menu c ON c.id = p.id_categoria WHERE c.nombre = ?', [$nombre]);
    $bd->ejecuta('DELETE p FROM platillo p JOIN categoria_menu c ON c.id = p.id_categoria WHERE c.nombre = ?', [$nombre]);
    $bd->ejecuta('DELETE FROM categoria_menu WHERE nombre = ?', [$nombre]);
    Semilla::borraUsuarios($bd, $prefijo);
    $bd->ejecuta('DELETE FROM sucursal WHERE id = ?', $p);
});
