#!/usr/bin/env bash

# Inicio de sesión HTTP compartido por las pruebas de humo. Los puestos
# sensibles completan la contraseña y el segundo factor; los demás conservan
# el flujo de una sola pantalla. Requiere que el llamador haya pasado ya por
# pruebas/exige-entorno.sh.
entra_web_segura() {
  local base="$1"
  local php="$2"
  local raiz="$3"
  local usuario="$4"
  local clave="$5"
  local cookies="$6"
  local marca=""
  local codigo_http=""
  local codigo_totp=""

  rm -f "$cookies"
  marca=$(curl -sS -m 15 -c "$cookies" -b "$cookies" "$base/entrar" \
    | grep -o 'name="\(_marca\|csrf-token\)" \(value\|content\)="[a-f0-9]*"' \
    | head -1 | sed 's/.*="//;s/"//')
  if [ -z "$marca" ]; then
    printf 'No se obtuvo la marca CSRF de /entrar para %s\n' "$usuario" >&2
    return 1
  fi

  codigo_http=$(curl -sS -m 15 -c "$cookies" -b "$cookies" -o /dev/null -w '%{http_code}' \
    --data-urlencode "_marca=$marca" --data-urlencode "usuario=$usuario" \
    --data-urlencode "clave=$clave" "$base/entrar")
  if [ "$codigo_http" != 302 ]; then
    printf 'El acceso de %s devolvió HTTP %s\n' "$usuario" "$codigo_http" >&2
    return 1
  fi

  completa_segundo_factor_web "$base" "$php" "$raiz" "$usuario" "$cookies"
}

# Completa una sesión que ya pasó correctamente por POST /entrar. Se expone
# aparte porque humo-identidad inspecciona el cambio de identificador justo
# entre la contraseña y el segundo factor.
completa_segundo_factor_web() {
  local base="$1"
  local php="$2"
  local raiz="$3"
  local usuario="$4"
  local cookies="$5"
  local codigo_totp=""
  local marca=""
  local codigo_http=""

  codigo_totp=$("$php" "$raiz/pruebas/fixtures/totp-web.php" "$usuario") || return 1
  if [ "$codigo_totp" = NO_TOTP ]; then
    return 0
  fi

  marca=$(curl -sS -m 15 -c "$cookies" -b "$cookies" "$base/segundo-factor" \
    | grep -o 'name="\(_marca\|csrf-token\)" \(value\|content\)="[a-f0-9]*"' \
    | head -1 | sed 's/.*="//;s/"//')
  if [ -z "$marca" ]; then
    printf 'No se obtuvo la marca CSRF del segundo factor para %s\n' "$usuario" >&2
    return 1
  fi

  codigo_http=$(curl -sS -m 15 -c "$cookies" -b "$cookies" -o /dev/null -w '%{http_code}' \
    --data-urlencode "_marca=$marca" --data-urlencode "codigo=$codigo_totp" \
    "$base/segundo-factor")
  if [ "$codigo_http" != 302 ]; then
    printf 'El segundo factor de %s devolvió HTTP %s\n' "$usuario" "$codigo_http" >&2
    return 1
  fi
}
