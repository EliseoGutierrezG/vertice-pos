#!/usr/bin/env bash
# El navegador manda `_envio` en cada POST del panel (plantilla.js, esquema/062):
# una llave nueva por cada intención de guardar. Las pruebas de humo hacen lo
# mismo con este `curl`, que la agrega a cada POST de formulario que no la
# traiga. Así cada llamada es un envío distinto, como un clic distinto.
#
# No toca el JSON de la app (`Content-Type: application/json`, `/api/`), que
# tiene su propia llave. Para probar el rechazo sin llave: `command curl`, o
# `PB_SIN_ENVIO=1`.
#
# `PB_DOBLE=1` simula el doble clic en todas las pruebas a la vez: cada POST de
# formulario sale dos veces con la **misma** llave. La prueba recibe la primera
# respuesta; la segunda se manda en silencio, sin seguir redirecciones ni tocar
# las cookies, y su código queda en `PB_DOBLE_REGISTRO` (ruta, código). Si el
# servidor hiciera el trabajo dos veces, las comprobaciones de cada prueba
# (existencias, conteos, folios) lo delatan.

curl() {
  local a forma=0 datos=0 post=0 tiene=0 json=0
  for a in "$@"; do
    case "$a" in
      -F|--form|--form-string) forma=1 ;;
      -d|--data|--data-urlencode|--data-raw|--data-binary|--data-ascii|-d?*|--data=*|--data-urlencode=*) datos=1 ;;
      POST) post=1 ;;
      *_envio=*) tiene=1 ;;
      */api/*) json=1 ;;
      [Cc]ontent-[Tt]ype:*json*) json=1 ;;
    esac
  done
  if [ "$tiene" = 0 ] && [ "$json" = 0 ] && [ "${PB_SIN_ENVIO:-}" != 1 ]; then
    local llave
    llave=$(uuidgen | tr 'A-Z' 'a-z')
    if [ "$forma" = 1 ]; then
      command curl "$@" -F "_envio=$llave"
      local salida=$?
      _lb_repite "$llave" -F "$@"
      return $salida
    fi
    if [ "$datos" = 1 ] || [ "$post" = 1 ]; then
      command curl "$@" --data-urlencode "_envio=$llave"
      local salida=$?
      _lb_repite "$llave" --data-urlencode "$@"
      return $salida
    fi
  fi
  command curl "$@"
}

# Las rutas de las acciones `#[Accion(..., unaVez: true)]` del panel.
_LB_RUTAS_UNA_VEZ='^/(bajas|sucursales|oficinas|compras|transferencias|personal|pedidos|venta-sucursal|inicio-operaciones|cambios-fisicos|cambios-fisicos/[0-9]+/recibir|caja/abrir|caja/[0-9]+/(movimientos|cerrar)|caja/cortes/[0-9]+/revisiones|devoluciones-comerciales/[0-9]+|devoluciones/repartidores/[0-9]+|devoluciones/productos/[0-9]+/cancelar|dispositivos/(notificacion|reglas)|avisos|transferencias/[0-9]+/(recibir|incidencias/[0-9]+/resolver)|personal/[0-9]+/usuario(/clave|/reactiva)?|privacidad/solicitudes|presentaciones/[0-9]+/precios|armado-paquetes/(arma|desarma)|salidas/repartidores/[0-9]+/concluir|seguridad/accesos/revision|pedidos/[0-9]+/ticket-publico)$'

# El segundo clic de `PB_DOBLE=1`: mismos datos, misma llave, sin salida.
_lb_repite() {
  [ "${PB_DOBLE:-}" = 1 ] || return 0
  local llave=$1 campo=$2 a salta=0 url='' codigo
  shift 2
  local args=()
  for a in "$@"; do
    if [ "$salta" = 1 ]; then salta=0; continue; fi
    case "$a" in
      -G|--get) return 0 ;;
      -o|--output|-w|--write-out|-D|--dump-header|-c|--cookie-jar) salta=1; continue ;;
      -L|--location) continue ;;
      http://*|https://*) url=$a ;;
    esac
    args+=("$a")
  done
  # Solo las acciones `unaVez`: otros POST (Entrar, por ejemplo) no pasan por
  # el envío único y repetirlos falsearía sus propias pruebas.
  local ruta="/${url#*//*/}"
  ruta="${ruta%%\?*}"
  [[ "$ruta" =~ $_LB_RUTAS_UNA_VEZ ]] || return 0
  codigo=$(command curl "${args[@]}" "$campo" "_envio=$llave" -s -o /dev/null -w '%{http_code}')
  if [ -n "${PB_DOBLE_REGISTRO:-}" ]; then
    printf '%s\t%s\n' "$ruta" "$codigo" >> "$PB_DOBLE_REGISTRO"
  fi
  return 0
}
