<?php
declare(strict_types=1);

// Trabajador aislado de EnvioUnicoPrueba: reserva y mantiene el envío abierto.
$raiz = dirname(__DIR__, 2);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\CerrojoPruebas::exige($raiz);
Nucleo\Reloj::fijaLaZona($raiz);
$bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos($raiz));
$identidad = new Nucleo\Identidad($bd);
$identidad->establece((int) $argv[1]);
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SERVER['REQUEST_URI'] = '/pedidos';
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';
$_SERVER['HTTP_ACCEPT'] = 'application/json';
$_GET = [];
$_POST = ['_envio' => $argv[2]];
$peticion = Nucleo\Peticion::desdeGlobales();
$middleware = new Nucleo\Middleware\ExigeEnvioUnico($bd, $identidad, new Nucleo\Sesion(false));
$middleware->maneja($peticion, static function () use ($argv): Nucleo\Respuesta {
    file_put_contents($argv[3], "una\n", FILE_APPEND | LOCK_EX);
    usleep(2000000);
    return Nucleo\Respuesta::json(['redirige' => '/pedidos']);
});
