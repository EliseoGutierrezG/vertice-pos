<?php
declare(strict_types=1);

/**
 * Lo que pruebas/seguridad.sh necesita tener en la base. Sólo pruebas.
 *   prepara CLAVE | limpia | sella | altera | restaura | vence USUARIO | estado USUARIO | bitacora ACCION
 */

$raiz = dirname(__DIR__, 2);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);
require dirname(__DIR__) . '/Semilla.php';

use Nucleo\BaseDatos;

$bd = new BaseDatos(Nucleo\Configuracion::baseDatos($raiz));
$prefijo = 'humo.seguridad.';
$soporte = 'humo.soporte';

$limpia = static function () use ($bd, $prefijo, $soporte): void {
    $bd->ejecuta('DELETE FROM bitacora_sello');
    $bd->ejecuta(
        'DELETE r FROM revision_acceso r JOIN usuario u ON u.id = r.revisado_por WHERE u.usuario LIKE ?',
        [$prefijo . '%']
    );
    Pruebas\Semilla::borraUsuarios($bd, $prefijo);
    Pruebas\Semilla::borraUsuarios($bd, $soporte);
    $bd->ejecuta("DELETE FROM personal WHERE nombre = 'Humo' AND apellido_paterno = 'Soporte'");
    $bd->ejecuta("DELETE FROM intento_acceso WHERE ambito = 'web'");
    $bd->ejecuta("DELETE FROM sucursal WHERE nombre = 'Sucursal de humo de seguridad'");
};

switch ($argv[1] ?? '') {
    case 'prepara':
        $limpia();
        $clave = (string) ($argv[2] ?? '');
        // Una sucursal propia: la base de pruebas recién creada no trae ninguna.
        $sucursal = $bd->inserta("INSERT INTO sucursal (nombre) VALUES ('Sucursal de humo de seguridad')");
        Pruebas\Semilla::usuario($bd, $prefijo . 'admin', 'administrador', $clave);
        Pruebas\Semilla::usuario($bd, $prefijo . 'almacen', 'almacen', $clave, $sucursal);
        // Un nombre que un Excel ejecutaría si el CSV no lo neutraliza.
        $id = Pruebas\Semilla::usuario($bd, $prefijo . 'formula', 'almacen', $clave, $sucursal);
        $bd->ejecuta(
            "UPDATE personal p JOIN usuario u ON u.id_personal = p.id SET p.nombre = '=HYPERLINK(1)' WHERE u.id = ?",
            [$id]
        );
        break;

    case 'limpia':
        $limpia();
        break;

    case 'sella':
        echo (new Servicios\SelloBitacora($bd, Nucleo\Configuracion::llaveSello($raiz)))
            ->sella(date('Y-m-d', strtotime('+1 day')));
        break;

    case 'altera':
        $bd->ejecuta('UPDATE bitacora SET accion = CONCAT(accion, "!") WHERE id = (SELECT hasta_id FROM bitacora_sello ORDER BY id LIMIT 1)');
        break;

    case 'restaura':
        $bd->ejecuta('UPDATE bitacora SET accion = TRIM(TRAILING "!" FROM accion) WHERE id = (SELECT hasta_id FROM bitacora_sello ORDER BY id LIMIT 1)');
        break;

    case 'vence':
        $bd->ejecuta('UPDATE usuario SET acceso_hasta = DATE_SUB(NOW(), INTERVAL 1 MINUTE) WHERE usuario = ?', [$argv[2] ?? '']);
        break;

    case 'estado':
        echo (int) $bd->valor('SELECT id_estatus FROM usuario WHERE usuario = ?', [$argv[2] ?? '']);
        break;

    case 'bitacora':
        echo (int) $bd->valor('SELECT COUNT(*) FROM bitacora WHERE accion = ?', [$argv[2] ?? '']);
        break;

    default:
        fwrite(STDERR, "Orden desconocida\n");
        exit(2);
}
