<?php
declare(strict_types=1);

/**
 * La carta de El Timón tal como viene en el PDF que entregó el dueño
 * (El_Timon_Restaurante.pdf, 2026-11-18): categorías en su orden, leyenda,
 * platillos con porción, precio y preparaciones.
 *
 * La usan `guiones/carga-carta.php` y las pruebas de la carta impresa.
 *
 * Cambios contra el PDF, para que la comanda y la cocina no se confundan:
 * - «Talla», «Mojo», «Diabla»… se repiten en Camarones y Filetes. Aquí llevan
 *   el nombre completo: «Camarones a la talla», «Filete a la talla».
 * - Las abreviaturas se escriben completas: «cam.» es camarón, «c/» es con.
 *
 * Pendiente de confirmar con el dueño (docs/salida.md): el cóctel grande a
 * $145, más barato que el mediano a $200; el tarro michelado a $15; y si los
 * tamaños de cóctel son platillos o modificadores.
 *
 * Cada platillo: [nombre, porción, precio, área, preparaciones]. El área es la
 * de la comanda (`fria`, `caliente` o `barra`). Las preparaciones son
 * modificadores sin costo, salvo los que traen [nombre, suplemento].
 */
$acompanados = 'Acompañados de una mezcla de lechugas frescas y texturas de temporada aderezado con un toque de miel y mostaza.';
$pulpoExtra = [['Con pulpo extra', '20']];

return [
    ['Entradas', 1, '', [
        ['Empanada de camarón', '3 pzas', '138', 'caliente', []],
        ['Ceviche mixto (camarón y pescado)', '', '230', 'fria', []],
        ['Ceviche de pescado', '', '220', 'fria', []],
        ['Ceviche de camarón', '', '220', 'fria', []],
        ['Aguachile de camarón (verde o negro)', '', '230', 'fria', []],
        ['Cóctel chico (camarón y ostión)', '', '115', 'fria', $pulpoExtra],
        ['Cóctel mediano (camarón y ostión)', '', '200', 'fria', $pulpoExtra],
        ['Cóctel grande (camarón y ostión)', '', '145', 'fria', $pulpoExtra],
        ['Almejas', '6 pzas', '165', 'fria', []],
        ['Torre de mariscos', '', '265', 'fria', []],
        ['Medio caldo de camarón', '', '100', 'caliente', []],
        ['Botana mixta (camarón y almeja)', '', '265', 'fria', []],
    ]],
    ['Tostadas', 2, '', [
        ['Tostada de camarón en forma de almeja', '1 pza', '95', 'fria', []],
        ['Tostada de pescado', '1 pza', '95', 'fria', []],
        ['Doraditos de atún', '3 pzas', '135', 'fria', []],
        ['Tostada de aguachile (verde o negro)', '', '110', 'fria', []],
        ['Tostada ¡Capi! (pescado y camarón curtido con camarón cocido)', '', '220', 'fria', []],
        ['Tostada de atún', '', '110', 'fria', []],
        ['Tostada de camarón y pulpo', '', '110', 'fria', []],
        ['Torta de camarón enchipotlado o al ajillo', '', '95', 'caliente', []],
    ]],
    ['Tacos', 3, '', [
        ['Taco de camarón empanizado', '1 pza', '95', 'caliente', []],
        ['Taco de jaiba placero', '1 pza', '125', 'caliente', []],
        ['Taco de chicharrón de pescado', '1 pza', '95', 'caliente', []],
        ['Taco de pulpo', '1 pza', '125', 'caliente', []],
    ]],
    ['Camarones', 4, $acompanados, [
        ['Camarones a la talla', '', '210', 'caliente', []],
        ['Camarones al coco', '', '265', 'caliente', []],
        ['Camarones al mojo', '', '199', 'caliente', []],
        ['Camarones al ajillo', '', '210', 'caliente', []],
        ['Camarones empanizados', '', '210', 'caliente', []],
        ['Camarones a la diabla', '', '210', 'caliente', []],
        ['Camarones enchipotlados', '', '199', 'caliente', []],
        ['Camarones a la mantequilla', '', '199', 'caliente', []],
        ['Camarones para pelar', '', '199', 'caliente', []],
    ]],
    ['Filetes', 5, $acompanados, [
        ['Filete al mojo', '', '125', 'caliente', []],
        ['Filete al ajillo', '', '135', 'caliente', []],
        ['Filete a la diabla', '', '135', 'caliente', []],
        ['Filete empanizado', '', '135', 'caliente', []],
        ['Filete enchipotlado', '', '125', 'caliente', []],
        ['Filete a la mantequilla', '', '125', 'caliente', []],
        ['Filete empapelado', '', '125', 'caliente', []],
        ['Filete a la talla', '', '125', 'caliente', []],
    ]],
    ['Caldos', 6, '', [
        ['Caldo de camarón', '', '220', 'caliente', []],
        ['Caldo de pescado', '', '220', 'caliente', []],
        ['Caldo de camarón y pescado', '', '230', 'caliente', []],
    ]],
    ['Pescados', 7, $acompanados, [
        ['Mojarra', '600 gr', '220', 'caliente', ['Frita', 'Mojo', 'Ajillo', 'Diabla', 'Enchipotlada']],
        ['Huachinango', '600 gr', '390', 'caliente', ['Frito', 'Mojo', 'Ajillo', 'Diabla', 'Enchipotlado']],
        ['Pulpo estrella', '', '395', 'caliente', ['Mojo', 'Ajillo', 'Diabla', 'Enchipotlado', 'Mantequilla']],
        ['Salmón', '', '275', 'caliente', ['Mojo', 'Ajillo', 'Diabla', 'Enchipotlado', 'Mantequilla', 'Finas hierbas', 'Plancha']],
        ['Pechuga de pollo o nuggets', '', '95', 'caliente', []],
    ]],
    ['Bebidas', 8, '', [
        ['Agua del día', '', '45', 'barra', []],
        ['Refresco', '', '40', 'barra', []],
        ['Cerveza Corona o Victoria', '', '45', 'barra', []],
        ['Cerveza Pacífico, Negra Modelo o Modelo Especial', '', '50', 'barra', []],
        ['Tarro michelado o chelado', '', '15', 'barra', []],
        ['Clamato con cerveza', '', '95', 'barra', []],
        ['Camaronera', '', '125', 'barra', []],
        ['Expreso', '', '60', 'barra', []],
        ['Expreso doble', '', '85', 'barra', []],
        ['Capuchino', '', '60', 'barra', []],
        ['Americano', '', '60', 'barra', []],
        ['Carajillo', '', '130', 'barra', []],
    ]],
    ['Postres', 9, '', [
        ['Flan', '', '60', 'fria', []],
        ['Pastel de elote', '', '95', 'fria', []],
        ['Plátanos con helado', '', '95', 'fria', []],
    ]],
];
