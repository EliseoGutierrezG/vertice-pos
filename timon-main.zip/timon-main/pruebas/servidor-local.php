<?php
declare(strict_types=1);

/**
 * Enrutador para `php -S` durante humo y revisión visual.
 *
 * Apache aplica `.htaccess`: sirve los recursos que existen y manda las rutas
 * limpias a `index.php`. El servidor integrado no lee ese archivo; sin esta
 * pieza entregaría la página 404 de la aplicación en lugar de cada CSS, JS o
 * imagen y una prueba visual dejaría de probar el producto real.
 */
$ruta = rawurldecode((string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH));
$publico = dirname(__DIR__) . '/publico';
$giro = require dirname($publico) . '/config/giro.php';
if ($ruta === '/' && $giro['restaurante'] && $giro['sitio_publico'] && is_file(dirname($publico) . '/landing/index.html')) {
    header('Content-Type: text/html; charset=utf-8');
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; base-uri 'none'; frame-ancestors 'none'");
    header('X-Frame-Options: DENY');
    readfile(dirname($publico) . '/landing/index.html');
    return true;
}

if ($giro['restaurante'] && ($ruta === '/app' || str_starts_with($ruta, '/app/'))) {
    if ($ruta === '/app') {
        header('Location: /app/', true, 308);
        return true;
    }
    $dist = realpath(dirname($publico) . '/app/dist');
    $relativo = substr($ruta, strlen('/app/'));
    $recurso = $dist === false ? false : realpath($dist . '/' . ($relativo === '' ? 'index.html' : $relativo));
    if ($recurso !== false && str_starts_with($recurso, $dist . DIRECTORY_SEPARATOR) && is_file($recurso)) {
        $tipos = ['html' => 'text/html; charset=utf-8', 'js' => 'text/javascript; charset=utf-8',
            'css' => 'text/css; charset=utf-8', 'png' => 'image/png', 'ico' => 'image/x-icon',
            'svg' => 'image/svg+xml', 'webmanifest' => 'application/manifest+json'];
        header('Content-Type: ' . ($tipos[pathinfo($recurso, PATHINFO_EXTENSION)] ?? 'application/octet-stream'));
        header('X-Content-Type-Options: nosniff');
        readfile($recurso);
        return true;
    }
}

$archivo = realpath($publico . $ruta);

if ($ruta !== '/' && $archivo !== false && str_starts_with($archivo, $publico . DIRECTORY_SEPARATOR) && is_file($archivo)) {
    return false;
}

require $publico . '/index.php';
