#!/usr/bin/env bash
# Compuerta de publicación de sólo lectura.
#
#   pruebas/publicacion.sh https://dominio.example \
#     entregables/despliegue/app-subdominio-candidato.tar.gz
#
# Lee del candidato la liberación y el esquema que deben quedar públicos,
# comprueba primero la huella local del archivo y después delega las defensas
# HTTP a humo.sh. No inicia sesión ni escribe en la base o en el servidor.

set -u

RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
PHP=/opt/homebrew/opt/php@8.3/bin/php
BASE="${1:-}"
PAQUETE="${2:-$RAIZ/entregables/despliegue/app-subdominio-candidato.tar.gz}"

if [ "$#" -lt 1 ] || [ "$#" -gt 2 ]; then
  echo "Uso: $0 https://DOMINIO [PAQUETE.tar.gz]" >&2
  exit 2
fi
case "$BASE" in
  https://*) ;;
  http://127.0.0.1:*|http://localhost:*) ;;
  *) echo "La publicación sólo se comprueba por HTTPS o contra el servidor local." >&2; exit 2 ;;
esac
if [ ! -f "$PAQUETE" ]; then
  echo "No existe el paquete: $PAQUETE" >&2
  exit 2
fi
if [ ! -f "$PAQUETE.sha256" ]; then
  echo "Falta la huella del paquete: $PAQUETE.sha256" >&2
  exit 2
fi
if [ ! -x "$PHP" ]; then
  echo "No se encontró PHP 8.3 en $PHP" >&2
  exit 2
fi

esperada=$(awk 'NR == 1 { print $1 }' "$PAQUETE.sha256")
real=$(shasum -a 256 "$PAQUETE" | awk '{ print $1 }')
esperada=$(printf '%s' "$esperada" | tr 'A-F' 'a-f')
real=$(printf '%s' "$real" | tr 'A-F' 'a-f')
if ! [[ "$esperada" =~ ^[0-9a-f]{64}$ ]] || [ "$esperada" != "$real" ]; then
  echo "La huella SHA-256 del paquete no coincide." >&2
  exit 1
fi

descriptores=$(tar -tzf "$PAQUETE" | grep -E '(^|/)instalacion/LIBERACION\.json$' || true)
cantidad=$(printf '%s\n' "$descriptores" | awk 'NF { n++ } END { print n + 0 }')
if [ "$cantidad" -ne 1 ]; then
  echo "El paquete debe contener exactamente un instalacion/LIBERACION.json." >&2
  exit 1
fi
descriptor=$(printf '%s\n' "$descriptores" | sed -n '1p')

datos=$(tar -xOzf "$PAQUETE" "$descriptor" | "$PHP" -r '
  $datos = json_decode(stream_get_contents(STDIN), true);
  $id = $datos["id"] ?? null;
  $esquema = $datos["esquema"] ?? null;
  if (!is_string($id) || preg_match("/^[A-Za-z0-9._:-]{3,100}$/", $id) !== 1
      || $id === "sin-identificar" || !is_int($esquema) || $esquema < 1) {
      fwrite(STDERR, "El descriptor de liberación del paquete no es válido.\n");
      exit(1);
  }
  echo $id, "\n", $esquema, "\n";
') || exit $?

LIBERACION=$(printf '%s\n' "$datos" | sed -n '1p')
ESQUEMA=$(printf '%s\n' "$datos" | sed -n '2p')

printf 'Paquete íntegro. Se espera liberación %s y esquema %s.\n' \
  "$LIBERACION" "$ESQUEMA"
exec "$RAIZ/pruebas/humo.sh" "$BASE" "$LIBERACION" "$ESQUEMA"
