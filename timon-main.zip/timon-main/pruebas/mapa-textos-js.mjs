// Los textos de los JS de la web y de los TSX de la app, leídos con el compilador
// de TypeScript: así se sabe en qué propiedad o llamada está cada cadena.
//
//   node pruebas/mapa-textos-js.mjs [raíz]
//
// Saca una línea JSON por texto: [superficie, archivo, línea, tipo, texto].
// Lo llama `mapa-textos.php`; no se usa por separado.

import { createRequire } from 'node:module';
import { readdirSync, readFileSync, statSync, existsSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const aqui = dirname(fileURLToPath(import.meta.url));
const raiz = process.argv[2] ?? join(aqui, '..');
const require = createRequire(join(aqui, '..', 'package.json'));
const ts = require('typescript');

/** Atributos JSX y propiedades con texto visible, y qué clase de texto llevan. */
const VISIBLES = new Map(Object.entries({
  title: 'titulo', titulo: 'titulo', headerTitle: 'titulo', tabBarLabel: 'titulo',
  label: 'campo', etiqueta: 'campo', placeholder: 'campo',
  detalle: 'ayuda', ayuda: 'ayuda', explica: 'ayuda', subtitulo: 'ayuda', descripcion: 'ayuda', nota: 'ayuda', texto: 'mensaje',
  message: 'mensaje', mensaje: 'mensaje', aviso: 'mensaje', motivo: 'mensaje', error: 'error',
  textoBoton: 'boton', boton: 'boton', accion: 'boton', confirmar: 'boton', cancelar: 'boton', textoConfirmar: 'boton', textoCancelar: 'boton',
  accessibilityLabel: 'lector', accessibilityHint: 'lector',
  sSearch: 'campo', searchPlaceholder: 'campo', lengthMenu: 'campo', zeroRecords: 'vacio', emptyTable: 'vacio', info: 'texto', infoEmpty: 'vacio',
  textContent: 'texto', innerText: 'texto', vacio: 'vacio',
}));

/** Propiedades y atributos que nunca se ven. */
const OCULTOS = new Set(['style', 'key', 'testID', 'name', 'icono', 'icon', 'href', 'id', 'source', 'contentFit', 'keyboardType', 'autoCapitalize',
  'autoComplete', 'textContentType', 'returnKeyType', 'role', 'accessibilityRole', 'tono', 'variante', 'tipo', 'type', 'estado', 'clave', 'color',
  'backgroundColor', 'pointerEvents', 'resizeMode', 'presentation', 'animation', 'mode', 'behavior', 'ruta', 'url', 'method', 'scope', 'className', 'selector', 'codigo', 'code']);

/** Funciones cuyo argumento nunca es un texto visible. */
const INTERNAS = /^(require|import|fetch|console\.|setItemAsync|getItemAsync|deleteItemAsync|SecureStore\.|AsyncStorage\.|router\.|navigation\.|Linking\.|querySelector|querySelectorAll|closest|matches|getAttribute|setAttribute|removeAttribute|hasAttribute|addEventListener|removeEventListener|getElementById|createElement|classList\.|\w+\.classList\.|dataset|startsWith|endsWith|includes|indexOf|split|replace|replaceAll|match|padStart|padEnd|join|ejecuta|filas|fila|inserta|guion|prepareAsync|execAsync|runAsync|getAllAsync|getFirstAsync|exec|test|RegExp|Date|JSON\.|Number|parseInt|parseFloat|toLocale|Intl\.|apunta|registra|expect|describe|it|Symbol|defineTask|TaskManager\.|Location\.|Notifications\.|Stack\.|useFocusEffect|useLocalSearchParams|new Headers|Headers|FormData|append|set|get|has|delete|hrefDe|ruta|pide|pideApi|api|peticion|sube)/;

const superficies = [
  ['publico/recursos', /\.js$/, 'web'],
  ['app/src', /\.tsx?$/, 'app'],
];

function archivos(carpeta, patron) {
  const hay = [];
  const base = join(raiz, carpeta);
  if (!existsSync(base)) return hay;
  const camina = (d) => {
    for (const n of readdirSync(d)) {
      if (n.startsWith('._') || n === 'vendor' || n === 'pruebas' || n === 'node_modules') continue;
      const c = join(d, n);
      if (statSync(c).isDirectory()) camina(c);
      else if (patron.test(n) && !n.includes('.min.') && !n.endsWith('.d.ts')) hay.push(c);
    }
  };
  camina(base);
  return hay.sort();
}

function nombreLlamada(llamada) {
  const e = llamada.expression;
  if (ts.isIdentifier(e)) return e.text;
  if (ts.isPropertyAccessExpression(e)) {
    const izq = ts.isIdentifier(e.expression) ? e.expression.text : '';
    return izq ? `${izq}.${e.name.text}` : e.name.text;
  }
  return '';
}

function parece(t) {
  const s = t.trim();
  if (s.length < 2 || !/\p{L}{2}/u.test(s)) return false;
  if (/[;{}]\s*$|=>|^\[|^\.|^#|^\/|^\$|\bnode_modules\b|\.db$|\.(png|jpg|js|ts|tsx|php)$/.test(s)) return false;
  if (/^[a-z0-9_\-.:\/*]+$/.test(s)) return false;
  if (/^[a-z]+[A-Z]/.test(s) && !s.includes(' ')) return false;
  if (/^[a-z-]+(\s*,\s*[a-z-]+|\s+[a-z.#\[\]-]+)+$/.test(s) && !/[áéíóúñ]/u.test(s)) return false;
  return /^[\p{Lu}¿¡]/u.test(s) || /[áéíóúñ]/u.test(s) || /^\p{Ll}+ \p{Ll}+/u.test(s) || s.startsWith('{…}');
}

function tipoPorContexto(nodo) {
  for (let p = nodo.parent, salto = 0; p && salto < 8; p = p.parent, salto++) {
    if (ts.isJsxAttribute(p)) {
      const n = p.name.getText();
      if (OCULTOS.has(n)) return null;
      return VISIBLES.get(n) ?? 'texto';
    }
    if (ts.isPropertyAssignment(p)) {
      const n = p.name.getText().replace(/^['"]|['"]$/g, '');
      if (OCULTOS.has(n)) return null;
      if (VISIBLES.has(n)) return VISIBLES.get(n);
    }
    if (ts.isBinaryExpression(p) && p.operatorToken.kind === ts.SyntaxKind.EqualsToken) {
      const n = p.left.getText();
      const ult = n.split('.').pop();
      if (ult === 'textContent' || ult === 'innerText') return 'texto';
      if (ult === 'title' || ult === 'placeholder') return 'pista';
      if (ult === 'className' || ult === 'href' || ult === 'hidden' || ult === 'value' || ult === 'type' || ult === 'id' || n.includes('.style')) return null;
    }
    if (ts.isNewExpression(p) && /Error$/.test(p.expression.getText())) return 'error';
    if (ts.isCallExpression(p)) {
      const n = nombreLlamada(p);
      if (n === 'setAttribute') {
        const clave = p.arguments[0]?.getText().replace(/['"`]/g, '') ?? '';
        if (clave === 'aria-label') return 'lector';
        if (clave === 'title' || clave === 'placeholder') return 'pista';
        return null;
      }
      if (INTERNAS.test(n)) return null;
      if (n === 'Alert.alert') return 'mensaje';
      if (/error|fall[oa]|rechaz/i.test(n)) return 'error';
      if (/aviso|avisa|mensaje|anuncia|exito|toast|nota/i.test(n)) return 'mensaje';
      if (/(^|\.)(set|pon)[A-Z]/.test(n)) return /Error/.test(n) ? 'error' : 'mensaje';
    }
    if (ts.isReturnStatement(p)) return 'texto';
    if (ts.isBlock(p)) break;
  }
  return 'texto';
}

function interno(nodo) {
  for (let p = nodo.parent; p; p = p.parent) {
    if (ts.isImportDeclaration(p) || ts.isExportDeclaration(p) || ts.isTypeNode(p) || ts.isTypeAliasDeclaration(p) || ts.isInterfaceDeclaration(p)) return true;
    if (ts.isCallExpression(p) && nombreLlamada(p) === 'StyleSheet.create') return true;
    if (ts.isElementAccessExpression(p) && p.argumentExpression === nodo) return true;
    if (ts.isBinaryExpression(p)) {
      const k = p.operatorToken.kind;
      if ([ts.SyntaxKind.EqualsEqualsEqualsToken, ts.SyntaxKind.ExclamationEqualsEqualsToken, ts.SyntaxKind.EqualsEqualsToken, ts.SyntaxKind.ExclamationEqualsToken, ts.SyntaxKind.InKeyword, ts.SyntaxKind.InstanceOfKeyword].includes(k)) return true;
    }
    if (ts.isCaseClause(p) && p.expression === nodo) return true;
    if (ts.isPropertyAssignment(p) && p.name === nodo) return true;
    if (ts.isBlock(p) || ts.isSourceFile(p)) break;
  }
  return false;
}

function textoDePlantilla(n) {
  let t = n.head.text;
  for (const s of n.templateSpans) t += '{…}' + s.literal.text;
  return t;
}

for (const [carpeta, patron, superficie] of superficies) {
  for (const ruta of archivos(carpeta, patron)) {
    const rel = relative(raiz, ruta);
    const codigo = readFileSync(ruta, 'utf8');
    const tipoScript = ruta.endsWith('.tsx') ? ts.ScriptKind.TSX : ruta.endsWith('.ts') ? ts.ScriptKind.TS : ts.ScriptKind.JS;
    const fuente = ts.createSourceFile(ruta, codigo, ts.ScriptTarget.Latest, true, tipoScript);
    const saca = (nodo, tipo, texto) => {
      const { line } = fuente.getLineAndCharacterOfPosition(nodo.getStart());
      console.log(JSON.stringify([superficie, rel, line + 1, tipo, texto]));
    };
    const visita = (n) => {
      if (ts.isJsxText(n)) {
        const t = n.getText().replace(/\s+/g, ' ').trim();
        if (t && /\p{L}{2}/u.test(t)) saca(n, 'texto', t);
      } else if (ts.isStringLiteral(n) || ts.isNoSubstitutionTemplateLiteral(n)) {
        if (!interno(n) && parece(n.text)) {
          const tipo = tipoPorContexto(n);
          if (tipo) saca(n, tipo, n.text);
        }
      } else if (ts.isTemplateExpression(n)) {
        const t = textoDePlantilla(n);
        if (!interno(n) && parece(t)) {
          const tipo = tipoPorContexto(n);
          if (tipo) saca(n, tipo, t);
        }
      }
      ts.forEachChild(n, visita);
    };
    visita(fuente);
  }
}
