<?php
declare(strict_types=1);

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);

try {
    Nucleo\CerrojoPruebas::exige($raiz, $argv[1] ?? null);
    echo "Entorno destructivo verificado.\n";
} catch (Throwable $e) {
    fwrite(STDERR, "CERROJO: " . $e->getMessage() . "\n");
    exit(1);
}
