<?php
declare(strict_types=1);

use Dominio\Totp;
use Pruebas\Afirma;

$totp = new Totp();
$secretoRfc = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';

return [
    'produce el vector RFC 6238 truncado a seis dígitos' => function () use ($totp, $secretoRfc): void {
        Afirma::igual('287082', $totp->codigo($secretoRfc, 59));
    },
    'acepta el periodo anterior y siguiente, pero no dos periodos de distancia' => function () use ($totp, $secretoRfc): void {
        $ahora = 1234567890;
        Afirma::cierto($totp->verifica($secretoRfc, $totp->codigo($secretoRfc, $ahora - 30), $ahora) !== null);
        Afirma::cierto($totp->verifica($secretoRfc, $totp->codigo($secretoRfc, $ahora + 30), $ahora) !== null);
        Afirma::igual(null, $totp->verifica($secretoRfc, $totp->codigo($secretoRfc, $ahora + 60), $ahora));
    },
    'genera secretos base32 y una URI compatible con Authenticator' => function () use ($totp): void {
        $secreto = $totp->generaSecreto();
        Afirma::cierto((bool) preg_match('/^[A-Z2-7]{32}$/', $secreto));
        $uri = $totp->uri($secreto, 'dueño@example.test');
        Afirma::cierto(str_starts_with($uri, 'otpauth://totp/'));
        Afirma::cierto(str_contains($uri, 'digits=6&period=30'));
    },
];

