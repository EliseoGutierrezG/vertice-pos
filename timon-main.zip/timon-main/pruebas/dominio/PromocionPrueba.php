<?php
declare(strict_types=1);

use Dominio\Dinero;
use Dominio\Promocion;
use Nucleo\Errores\ErrorHttp;
use Pruebas\Afirma;

/**
 * Las reglas de las promociones de platillo: vigencia, rebaja por unidad y
 * N×M sobre los renglones de una cuenta. No toca la base.
 */
$d = static fn (string $pesos): Dinero => Dinero::deCadena($pesos);
$promo = static fn (array $campos): array => $campos + [
    'tipo' => 'porcentaje', 'valor' => '10.00', 'lleva' => null, 'paga' => null, 'desde' => '2026-11-01',
    'hasta' => null, 'dias' => 127, 'hora_inicio' => null, 'hora_fin' => null, 'activa' => 1, 'baja' => 0,
];
$momento = static fn (string $cuando): DateTimeImmutable => new DateTimeImmutable($cuando);

return [
    'la vigencia respeta fechas, días y la pausa' => function () use ($promo, $momento): void {
        $martes = $promo(['dias' => Promocion::bitDia(2), 'hasta' => '2026-11-30']);
        Afirma::cierto(Promocion::vigente($martes, $momento('2026-11-17 12:00')), 'martes dentro de fechas');
        Afirma::falso(Promocion::vigente($martes, $momento('2026-11-18 12:00')), 'miércoles');
        Afirma::falso(Promocion::vigente($martes, $momento('2026-12-01 12:00')), 'después de la fecha final');
        Afirma::falso(Promocion::vigente($promo(['desde' => '2026-11-20']), $momento('2026-11-17 12:00')), 'antes del inicio');
        Afirma::falso(Promocion::vigente($promo(['activa' => 0]), $momento('2026-11-17 12:00')), 'pausada');
        Afirma::cierto(Promocion::vencida($martes, $momento('2026-12-01 00:00')), 'vencida');
    },

    'un horario que cruza la medianoche pertenece al día en que empieza' => function () use ($promo, $momento): void {
        $noche = $promo(['dias' => Promocion::bitDia(2), 'hora_inicio' => '22:00:00', 'hora_fin' => '02:00:00']);
        Afirma::cierto(Promocion::vigente($noche, $momento('2026-11-17 23:00')), 'martes en la noche');
        Afirma::cierto(Promocion::vigente($noche, $momento('2026-11-18 01:30')), 'miércoles de madrugada');
        Afirma::falso(Promocion::vigente($noche, $momento('2026-11-18 02:00')), 'al cierre');
        Afirma::falso(Promocion::vigente($noche, $momento('2026-11-17 01:00')), 'madrugada del martes');
        $tarde = $promo(['hora_inicio' => '13:00', 'hora_fin' => '17:00']);
        Afirma::cierto(Promocion::vigente($tarde, $momento('2026-11-17 13:00')), 'a la hora de inicio');
        Afirma::falso(Promocion::vigente($tarde, $momento('2026-11-17 17:00')), 'a la hora final');
    },

    'el porcentaje rebaja precio y suplementos; el precio especial solo el base' => function () use ($promo, $d): void {
        Afirma::igual('34.50', Promocion::descuentoUnitario($promo(['valor' => '15.00']), $d('210'), $d('20'))->aPesos(), 'quince por ciento de 230');
        $especial = $promo(['tipo' => 'precio', 'valor' => '199.00']);
        Afirma::igual('31.00', Promocion::descuentoUnitario($especial, $d('230'), $d('20'))->aPesos(), 'de 230 a 199');
        Afirma::igual('0.00', Promocion::descuentoUnitario($especial, $d('180'), $d('0'))->aPesos(), 'un especial más caro no aplica');
        Afirma::igual('199.00', Promocion::precioPromocion($especial, $d('230'))?->aPesos(), 'el precio con promoción');
        Afirma::nulo(Promocion::precioPromocion($promo(['tipo' => 'nxm', 'lleva' => 2, 'paga' => 1]), $d('230')), 'un 2x1 no tiene precio unitario');
    },

    'un 2x1 con tres piezas regala una, la más barata' => function () use ($promo, $d): void {
        $dosPorUno = $promo(['tipo' => 'nxm', 'valor' => null, 'lleva' => 2, 'paga' => 1]);
        $descuentos = Promocion::descuentosNxM($dosPorUno, [
            ['id' => 10, 'precio' => $d('125'), 'cantidad' => 2],
            ['id' => 11, 'precio' => $d('95'), 'cantidad' => 1],
        ]);
        Afirma::igual('0.00', $descuentos[10]->aPesos(), 'el renglón caro no se regala');
        Afirma::igual('95.00', $descuentos[11]->aPesos(), 'la pieza más barata sale gratis');
        Afirma::igual(1, Promocion::unidadesGratis(3, 2, 1), 'tres piezas, una gratis');
    },

    'un 3x2 regala una de cada tres y reparte entre renglones' => function () use ($promo, $d): void {
        $tresPorDos = $promo(['tipo' => 'nxm', 'valor' => null, 'lleva' => 3, 'paga' => 2]);
        $descuentos = Promocion::descuentosNxM($tresPorDos, [
            ['id' => 'a', 'precio' => $d('100'), 'cantidad' => 4],
            ['id' => 'b', 'precio' => $d('100'), 'cantidad' => 2],
        ]);
        Afirma::igual('200.00', $descuentos['a']->aPesos(), 'a igual precio, primero el renglón más antiguo');
        Afirma::igual('0.00', $descuentos['b']->aPesos(), 'el segundo renglón paga completo');
        Afirma::igual(0, Promocion::unidadesGratis(2, 3, 2), 'dos piezas no alcanzan');
    },

    'entre dos promociones gana la de mayor rebaja' => function () use ($promo, $d): void {
        $dosPorUno = $promo(['tipo' => 'nxm', 'lleva' => 2, 'paga' => 1]);
        $diez = $promo(['valor' => '10.00']);
        Afirma::cierto(Promocion::rebajaEstimada($dosPorUno, $d('100'), $d('0')) > Promocion::rebajaEstimada($diez, $d('100'), $d('0')), 'el 2x1 rebaja más');
    },

    'la etiqueta y el horario se leen en palabras' => function () use ($promo): void {
        Afirma::igual('2x1', Promocion::etiqueta($promo(['tipo' => 'nxm', 'lleva' => 2, 'paga' => 1])));
        Afirma::igual('−15 %', Promocion::etiqueta($promo(['valor' => '15.00'])));
        Afirma::igual('$199.00', Promocion::etiqueta($promo(['tipo' => 'precio', 'valor' => '199.00'])));
        $dias = Promocion::bitDia(2) | Promocion::bitDia(4);
        Afirma::igual('Martes y jueves, de 13:00 a 17:00', Promocion::horario($promo(['dias' => $dias, 'hora_inicio' => '13:00:00', 'hora_fin' => '17:00:00'])));
        Afirma::igual('De lunes a viernes', Promocion::horario($promo(['dias' => 31])));
        Afirma::igual('Todos los días', Promocion::horario($promo([])));
    },

    'lo capturado se valida campo por campo' => function (): void {
        $limpio = Promocion::normaliza(['nombre' => 'Martes de aguachile', 'tipo' => 'nxm', 'lleva' => '2', 'paga' => '1',
            'desde' => '2026-11-17', 'dias' => ['2'], 'hora_inicio' => '13:00', 'hora_fin' => '17:00']);
        Afirma::igual(2, $limpio['dias'], 'la máscara del martes');
        Afirma::igual(null, $limpio['valor'], 'un N×M sin valor');
        $error = Afirma::lanza(ErrorHttp::class, static fn () => Promocion::normaliza(['nombre' => '', 'tipo' => 'nxm',
            'lleva' => '2', 'paga' => '2', 'desde' => '2026-11-17', 'hasta' => '2026-11-01', 'dias' => []]));
        foreach (['nombre', 'paga', 'hasta', 'dias'] as $campo) {
            Afirma::cierto(isset($error->campos()[$campo]), 'señala ' . $campo);
        }
        Afirma::lanza(ErrorHttp::class, static fn () => Promocion::normaliza(['nombre' => 'X', 'tipo' => 'porcentaje',
            'porcentaje' => '95', 'desde' => '2026-11-17', 'dias' => ['1']]), 'más de 90 %');
    },
];
