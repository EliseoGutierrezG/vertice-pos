<?php
declare(strict_types=1);

use Dominio\CalculoFiscal;
use Dominio\Cantidad;
use Dominio\Dinero;
use Dominio\Impuesto;
use Dominio\Tasa;
use Pruebas\Afirma;

/**
 * El desglose fiscal, contra números calculados a mano.
 *
 * Los resultados esperados de estas pruebas NO salieron de correr el código:
 * se calcularon aparte y se escribieron aquí. Una prueba que copia lo que el
 * código devuelve sólo comprueba que el código no cambió, no que esté bien.
 *
 * Caso 2, paso a paso, para que se pueda seguir:
 *   neto  = 100.0000, IVA 16 %, IEPS 26.5 %
 *   sin IVA = 100 / 1.16       = 86.2069   (redondeado a la diezmilésima)
 *   bruto   = 86.2069 / 1.265  = 68.1477
 *   IEPS    = 68.1477 × 0.265  = 18.0591
 *   IVA     = 100 − 68.1477 − 18.0591 = 13.7932
 *   suma    = 68.1477 + 18.0591 + 13.7932 = 100.0000 ✓
 */

$calculo = new CalculoFiscal();

/** IVA del 16 %, sin IEPS. Agua, refresco. */
$soloIva = new Impuesto(Tasa::deCadena('0.1600'), Tasa::cero(), Dinero::cero(), 'IVA 16%');

/** Cerveza: IVA 16 % e IEPS de tasa 26.5 %. */
$cerveza = new Impuesto(Tasa::deCadena('0.1600'), Tasa::deCadena('0.2650'), Dinero::cero(), 'Cerveza');

/** Con cuota por litro, que es lo que distingue a las bebidas. */
$conCuota = new Impuesto(
    Tasa::deCadena('0.1600'),
    Tasa::deCadena('0.2650'),
    Dinero::deCadena('1.4500'),
    'Con cuota'
);

/** Exento: ni IVA ni IEPS. */
$exento = Impuesto::exento();

return [
    'con IVA solo, el bruto es el neto entre 1.16' => function () use ($calculo, $soloIva): void {
        $d = $calculo->desglosa(Dinero::deCadena('116.00'), $soloIva, Cantidad::cero());

        Afirma::igual('100.0000', $d->bruto->aCadena(), 'el bruto');
        Afirma::igual('16.0000',  $d->iva->aCadena(),   'el IVA');
        Afirma::igual('0.0000',   $d->ieps->aCadena(),  'el IEPS');
        Afirma::cierto($d->cuadra(), 'las partes suman el neto');
    },

    'con IVA e IEPS de tasa, el desglose cuadra al centavo' => function () use ($calculo, $cerveza): void {
        $d = $calculo->desglosa(Dinero::deCadena('100.00'), $cerveza, Cantidad::cero());

        Afirma::igual('68.1477', $d->bruto->aCadena(), 'el bruto');
        Afirma::igual('18.0591', $d->ieps->aCadena(),  'el IEPS de tasa');
        Afirma::igual('13.7932', $d->iva->aCadena(),   'el IVA');
        Afirma::cierto($d->cuadra(), 'las partes suman el neto');
    },

    'la base del IVA incluye el IEPS' => function () use ($calculo, $cerveza): void {
        $d = $calculo->desglosa(Dinero::deCadena('100.00'), $cerveza, Cantidad::cero());

        // 68.1477 + 18.0591 = 86.2068, no 68.1477.
        Afirma::igual('86.2068', $d->baseDelIva()->aCadena(), 'la base del IVA');

        // Y si NO lo incluyera, el IVA sería 10.9036 en vez de 13.7932.
        Afirma::falso($d->iva->aCadena() === '10.9036', 'el IVA se calculó sin el IEPS');
    },

    'la cuota por litro no depende del precio, sino del volumen' => function () use ($calculo, $conCuota): void {
        // 0.355 L por unidad × 24 unidades = 8.520 L; × 1.45 = 12.3540
        $litros = Cantidad::deCadena('0.355')->por(Cantidad::deEntero(24));

        Afirma::igual('8.520', $litros->aCadena(), 'los litros');

        $barato = $calculo->desglosa(Dinero::deCadena('300.00'), $conCuota, $litros);
        $caro   = $calculo->desglosa(Dinero::deCadena('600.00'), $conCuota, $litros);

        Afirma::igual('12.3540', $barato->iepsPorLitro->aCadena(), 'la cuota en el barato');
        Afirma::igual('12.3540', $caro->iepsPorLitro->aCadena(),   'la cuota en el caro');
    },

    'con los tres impuestos, el desglose sigue cuadrando' => function () use ($calculo, $conCuota): void {
        $litros = Cantidad::deCadena('0.355')->por(Cantidad::deEntero(24));
        $d      = $calculo->desglosa(Dinero::deCadena('300.00'), $conCuota, $litros);

        Afirma::igual('194.6772', $d->bruto->aCadena(),        'el bruto');
        Afirma::igual('51.5895',  $d->ieps->aCadena(),         'el IEPS de tasa');
        Afirma::igual('12.3540',  $d->iepsPorLitro->aCadena(), 'el IEPS por litro');
        Afirma::igual('41.3793',  $d->iva->aCadena(),          'el IVA');
        Afirma::cierto($d->cuadra(), 'las partes suman el neto');
    },

    'sin impuestos, el bruto es el neto' => function () use ($calculo, $exento): void {
        $d = $calculo->desglosa(Dinero::deCadena('47.50'), $exento, Cantidad::cero());

        Afirma::igual('47.5000', $d->bruto->aCadena(), 'el bruto');
        Afirma::igual('0.0000',  $d->iva->aCadena(),   'el IVA');
        Afirma::cierto($d->cuadra(), 'las partes suman el neto');
    },

    'la ida y la vuelta se encuentran' => function () use ($calculo, $conCuota): void {
        $litros = Cantidad::deCadena('0.355')->por(Cantidad::deEntero(24));
        $bruto  = Dinero::deCadena('194.6772');

        $neto = $calculo->neto($bruto, $conCuota, $litros);
        $d    = $calculo->desglosa($neto, $conCuota, $litros);

        // Puede bailar una diezmilésima por el redondeo de dos caminos
        // distintos; más que eso sería un error de fórmula.
        $diferencia = abs($d->bruto->diezmilesimas() - $bruto->diezmilesimas());
        Afirma::cierto($diferencia <= 1, 'la vuelta no devolvió el bruto: bailó ' . $diferencia);
    },

    'la suma de las partes es EXACTAMENTE el neto, en cien precios seguidos' => function () use ($calculo, $conCuota): void {
        $litros = Cantidad::deCadena('0.355')->por(Cantidad::deEntero(12));

        for ($centavos = 1; $centavos <= 100; $centavos++) {
            $neto = Dinero::deDiezmilesimas($centavos * 10000 + 7 * $centavos);
            $d    = $calculo->desglosa($neto, $conCuota, $litros);

            Afirma::cierto($d->cuadra(), 'no cuadra con neto ' . $neto->aCadena());
        }
    },

    'el desglose sigue cuadrando con dos decimales, que es como se guarda' => function () use ($calculo, $soloIva, $cerveza, $conCuota): void {
        // Las columnas `pedido_detalle.importe_*` son DECIMAL(14,2), así que lo
        // que se guarda es el desglose a dos decimales. Redondeando cada parte
        // por su cuenta, la igualdad se rompía: con IEPS en una de cada cuatro
        // ventas y con cuota por litro en casi la mitad. Y lo que se guarda mal
        // se guarda mal para siempre: la factura que se haga el año que viene
        // sale de estas columnas y no puede repararlas.
        $litros = Cantidad::deCadena('0.355');
        $rotos  = 0;

        foreach ([$soloIva, $cerveza, $conCuota] as $impuesto) {
            // De un peso a cincuenta, centavo por centavo: 4 900 importes por
            // impuesto. El barrido es a propósito: los que fallaban no eran
            // casos raros, eran uno de cada cuatro.
            for ($centavos = 100; $centavos <= 5000; $centavos++) {
                $d = $calculo->desglosa(Dinero::deDiezmilesimas($centavos * 100), $impuesto, $litros)->enCentavos();

                if (!$d->cuadra()) {
                    $rotos++;
                }
            }
        }

        Afirma::igual(0, $rotos, 'importes cuyo desglose a centavos no suma el neto');

        // Y un caso a mano, del que falla si se redondea parte por parte:
        //   neto 1.08, cerveza → bruto 0.7358, IEPS 0.1950, IVA 0.1490
        //   redondeando cada uno: 0.74 + 0.20 + 0.15 = 1.09, un centavo de más.
        $d = $calculo->desglosa(Dinero::deCadena('1.08'), $cerveza, Cantidad::cero())->enCentavos();

        Afirma::igual('1.08', $d->neto->aPesos(),  'el neto es lo que se cobra');
        Afirma::igual('0.74', $d->bruto->aPesos(), 'la base va redondeada');
        Afirma::igual('0.20', $d->ieps->aPesos(),  'y el IEPS también');
        Afirma::igual('0.14', $d->iva->aPesos(),   'y el IVA carga con el redondeo de las otras dos');
        Afirma::cierto($d->cuadra(), 'las tres partes suman el neto');
    },

    'el desglose en centavos no se desvía más de un centavo y medio' => function () use ($calculo, $conCuota): void {
        // El IVA absorbe el redondeo de las otras tres partes, así que hay que
        // saber cuánto puede absorber. Si esta cota creciera, querría decir que
        // se metió otra parte al desglose sin pensar en el redondeo.
        $litros = Cantidad::deCadena('0.355');
        $peor   = 0;

        for ($centavos = 100; $centavos <= 20000; $centavos++) {
            $exacto = $calculo->desglosa(Dinero::deDiezmilesimas($centavos * 100), $conCuota, $litros);
            $peor   = max($peor, abs($exacto->enCentavos()->iva->diezmilesimas() - $exacto->iva->diezmilesimas()));
        }

        Afirma::cierto(
            $peor <= Dinero::deCadena('0.015')->diezmilesimas(),
            'el IVA se desvió ' . Dinero::deDiezmilesimas($peor)->aCadena() . ', más de centavo y medio'
        );
    },

    'cambiar la tasa cambia el resultado: no hay ningún 1.16 escondido' => function () use ($calculo): void {
        $alDieciseis = new Impuesto(Tasa::deCadena('0.1600'), Tasa::cero(), Dinero::cero());
        $alOcho      = new Impuesto(Tasa::deCadena('0.0800'), Tasa::cero(), Dinero::cero());

        $a = $calculo->desglosa(Dinero::deCadena('116.00'), $alDieciseis, Cantidad::cero());
        $b = $calculo->desglosa(Dinero::deCadena('116.00'), $alOcho, Cantidad::cero());

        Afirma::igual('100.0000', $a->bruto->aCadena(), 'al 16 %');
        Afirma::igual('107.4074', $b->bruto->aCadena(), 'al 8 %');
        Afirma::falso($a->iva->igualA($b->iva), 'el IVA salió igual con dos tasas distintas');
    },

    'la frontera norte al 8 % da lo que debe' => function () use ($calculo): void {
        // 108.00 / 1.08 = 100.0000 exacto.
        $frontera = new Impuesto(Tasa::deCadena('0.0800'), Tasa::cero(), Dinero::cero());
        $d = $calculo->desglosa(Dinero::deCadena('108.00'), $frontera, Cantidad::cero());

        Afirma::igual('100.0000', $d->bruto->aCadena(), 'el bruto');
        Afirma::igual('8.0000',   $d->iva->aCadena(),   'el IVA');
    },

    'un neto de cero da un desglose de ceros' => function () use ($calculo, $conCuota): void {
        $d = $calculo->desglosa(Dinero::cero(), $conCuota, Cantidad::cero());

        Afirma::igual('0.0000', $d->bruto->aCadena(), 'el bruto');
        Afirma::igual('0.0000', $d->iva->aCadena(),   'el IVA');
        Afirma::cierto($d->cuadra(), 'cuadra');
    },
];
