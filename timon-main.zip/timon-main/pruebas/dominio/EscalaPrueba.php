<?php
declare(strict_types=1);

use Dominio\Cantidad;
use Dominio\Dinero;
use Dominio\Escala;
use Pruebas\Afirma;

/**
 * La frontera por donde pasan todos los pesos y todas las unidades.
 *
 * ⚠️ **Este archivo estaba vacío.** El corredor hacía `require` y le devolvía 1
 * en vez de un arreglo; soltaba un aviso por el error estándar y seguía, así que
 * el hueco llevaba ahí no se sabe cuántas corridas, enterrado entre trescientas
 * líneas verdes. `Escala` tenía **una** prueba, y escrita en el archivo de
 * `Dinero`. Ahora el corredor se pone en rojo cuando un archivo de pruebas no se
 * puede leer, porque uno que no se lee se ve igual que uno que pasa.
 *
 * Y el hueco tapaba algo: ⚠️ `(int)` de una cadena que no cabe en un entero
 * **no falla, se pega al tope**. Medido: «9999999999999999» con escala 1000
 * devolvía 9223372036854775807, o sea 9223372036854775.807 unidades, un número
 * distinto del que se recibió y sin un solo aviso. Lo peligroso no era el tope:
 * era que lo que después se validaba ya no era lo que alguien había mandado.
 */

return [
    'una cadena decimal se vuelve entero escalado' => function (): void {
        Afirma::igual(255000, Escala::aEntero('25.5', 10000), '25.5 en diezmilésimas');
        Afirma::igual(12000,  Escala::aEntero('12', 1000),    '12 en milésimas');
        Afirma::igual(0,      Escala::aEntero('0', 10000),    'el cero');
        Afirma::igual(1,      Escala::aEntero('0.0001', 10000), 'la diezmilésima más chica');
    },

    'los decimales que sobran se redondean, no se recortan' => function (): void {
        // Recortar sesga todos los importes hacia abajo, y el sesgo se nota al
        // sumar mil renglones. Media unidad hacia arriba, como todo el sistema.
        Afirma::igual(2, Escala::aEntero('0.15', 10), 'un décimo y medio sube');
        Afirma::igual(1, Escala::aEntero('0.14', 10), 'y 0.14 se queda');
        Afirma::igual(3, Escala::aEntero('0.25', 10), '0.25 sube a 0.3');
    },

    'el signo se conserva y el redondeo se aleja del cero' => function (): void {
        Afirma::igual(-32500, Escala::aEntero('-3.25', 10000), 'un negativo');
        Afirma::igual(-2,     Escala::aEntero('-0.15', 10),    'y su redondeo se aleja del cero');
    },

    'lo que no es un número decimal se rechaza' => function (): void {
        foreach (['1e3', '0x10', '5,5', '+5', '', ' ', 'doce', '1.2.3', '--5', '.5'] as $malo) {
            Afirma::lanza(
                InvalidArgumentException::class,
                fn () => Escala::aEntero($malo, 1000),
                'se rechaza «' . $malo . '»'
            );
        }

        // Y lo que sí se acepta, dicho a propósito: el punto sin decimales
        // detrás. «5.» es un cinco; no hay dos lecturas.
        Afirma::igual(5000, Escala::aEntero('5.', 1000), '«5.» se lee como cinco');
    },

    'un número que no cabe en un entero se rechaza en vez de pegarse al tope' => function (): void {
        // El caso que estaba suelto. Sin esto, cada uno de estos devolvía
        // PHP_INT_MAX y el sistema seguía trabajando con otro número.
        foreach (['9999999999999999', '99999999999999999999', str_repeat('9', 40)] as $enorme) {
            Afirma::lanza(
                InvalidArgumentException::class,
                fn () => Cantidad::deCadena($enorme),
                'se rechaza una cantidad de ' . strlen($enorme) . ' dígitos'
            );
        }

        Afirma::lanza(
            InvalidArgumentException::class,
            fn () => Cantidad::deCadena('-9999999999999999'),
            'y también el negativo'
        );
    },

    'el último número que sí cabe, cabe' => function (): void {
        // La frontera exacta, por los dos lados: PHP_INT_MAX son 9223372036854775807
        // milésimas, o sea 9223372036854775.807 unidades.
        $justo = '9223372036854775.807';
        Afirma::igual($justo, Cantidad::deCadena($justo)->aCadena(), 'el tope exacto pasa');
        Afirma::lanza(
            InvalidArgumentException::class,
            fn () => Cantidad::deCadena('9223372036854775.808'),
            'y una milésima más, no'
        );
    },

    'el redondeo no puede empujarlo por encima del tope' => function (): void {
        // Un dígito de más que redondea hacia arriba justo en el límite: sin la
        // segunda comprobación, el resultado daba la vuelta a negativo.
        Afirma::lanza(
            InvalidArgumentException::class,
            fn () => Cantidad::deCadena('9223372036854775.8075'),
            'el tope con un dígito de más que sube'
        );
    },

    'de entero escalado a cadena, con los decimales que se piden' => function (): void {
        Afirma::igual('25.5000', Escala::aCadena(255000, 10000, 4), 'cuatro decimales');
        Afirma::igual('25.50',   Escala::aCadena(255000, 10000, 2), 'dos, redondeando');
        Afirma::igual('26',      Escala::aCadena(255000, 10000, 0), 'ninguno, redondeando');
        Afirma::igual('-3.2500', Escala::aCadena(-32500, 10000, 4), 'un negativo');
        Afirma::igual('0.0000',  Escala::aCadena(0, 10000, 4),      'el cero no lleva signo');
    },

    'el cero negativo no existe' => function (): void {
        // -0.00004 redondeado a cuatro decimales es cero, y «-0.0000» no es un
        // importe: es una pantalla que se ve mal.
        Afirma::igual('0.00', Escala::aCadena(0, 10000, 2), 'cero a dos decimales');
        Afirma::igual('0.00', Dinero::deCadena('-0.000049')->aPesos(), 'un negativo que redondea a cero');
    },

    'la ida y la vuelta no pierden nada' => function (): void {
        foreach (['0', '1', '25.5', '0.0001', '999999.9999', '-3.25'] as $valor) {
            $ida    = Escala::aEntero($valor, 10000);
            $vuelta = Escala::aCadena($ida, 10000, 4);

            Afirma::igual($ida, Escala::aEntero($vuelta, 10000), 'ida y vuelta de ' . $valor);
        }

        // El tope va con su escala: 9223372036854775.807 cabe en milésimas y
        // **no** cabe en diezmilésimas, que es lo correcto y vale decirlo.
        $tope = '9223372036854775.807';
        Afirma::igual(PHP_INT_MAX, Escala::aEntero($tope, 1000), 'el tope en milésimas');
        Afirma::lanza(
            InvalidArgumentException::class,
            fn () => Escala::aEntero($tope, 10000),
            'el mismo número en diezmilésimas ya no cabe'
        );
    },
    'Cantidad::aTexto habla sin ceros de más' => function (): void {
        Afirma::igual('23', Cantidad::deCadena('23.000')->aTexto(), 'las unidades enteras');
        Afirma::igual('1.5', Cantidad::deCadena('1.500')->aTexto(), 'los decimales que sí importan');
        Afirma::igual('1,234', Cantidad::deCadena('1234.000')->aTexto(), 'con separador de miles');
        Afirma::igual('-0.25', Cantidad::deCadena('-0.250')->aTexto(), 'y el signo no se pierde');
        Afirma::igual('0', Cantidad::cero()->aTexto(), 'el cero');
    },
];
