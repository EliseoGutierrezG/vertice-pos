<?php
declare(strict_types=1);

use Dominio\Dinero;
use Dominio\Reparto;
use Nucleo\Errores\ErrorHttp;
use Pruebas\Afirma;

return [
    'el reparto conserva los centavos y asigna primero el excedente' => static function (): void {
        $cuotas = Reparto::divide(Dinero::deCadena('125.00'), 3);
        Afirma::igual(['41.67', '41.67', '41.66'], array_map(static fn (Dinero $cuota) => $cuota->aPesos(), $cuotas));
    },
    'el reparto exige al menos dos partes con importe' => static function (): void {
        Afirma::lanza(ErrorHttp::class, static fn () => Reparto::divide(Dinero::deCadena('100.00'), 1));
        Afirma::lanza(ErrorHttp::class, static fn () => Reparto::divide(Dinero::deCadena('100.00'), 21));
        Afirma::lanza(ErrorHttp::class, static fn () => Reparto::divide(Dinero::deCadena('0.02'), 3));
    },
];
