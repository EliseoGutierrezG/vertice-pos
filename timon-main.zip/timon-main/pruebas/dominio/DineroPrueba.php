<?php
declare(strict_types=1);

use Dominio\Cantidad;
use Dominio\Dinero;
use Dominio\Escala;
use Dominio\Redondeo;
use Dominio\Tasa;
use Pruebas\Afirma;

/**
 * El dinero, que es entero por dentro.
 *
 * Aquí se comprueba lo que motivó la decisión: que sumar diez centavos cien
 * veces dé diez pesos clavados, y no 9.999999999999998 como daría con
 * números de punto flotante.
 */

return [
    'sumar diez centavos cien veces da diez pesos clavados' => function (): void {
        $total = Dinero::cero();
        for ($i = 0; $i < 100; $i++) {
            $total = $total->mas(Dinero::deCadena('0.10'));
        }

        Afirma::igual('10.0000', $total->aCadena(), 'el total');
    },

    'lo que con decimales de máquina no cuadra, aquí sí' => function (): void {
        // 0.1 + 0.2 === 0.3 es falso con números de punto flotante.
        $conFlotantes = (0.1 + 0.2) === 0.3;
        Afirma::falso($conFlotantes, 'los flotantes de PHP cambiaron de comportamiento');

        $suma = Dinero::deCadena('0.10')->mas(Dinero::deCadena('0.20'));
        Afirma::cierto($suma->igualA(Dinero::deCadena('0.30')), 'con enteros sí cuadra');
    },

    'una cadena de la base se lee tal cual' => function (): void {
        Afirma::igual('25.5000', Dinero::deCadena('25.5000')->aCadena(), 'con ceros');
        Afirma::igual('25.5000', Dinero::deCadena('25.5')->aCadena(),    'sin ceros');
        Afirma::igual('25.0000', Dinero::deCadena('25')->aCadena(),      'entero');
        Afirma::igual('0.0001',  Dinero::deCadena('0.0001')->aCadena(),  'la diezmilésima');
    },

    'los decimales de más se redondean, no se recortan' => function (): void {
        // Recortar sesga todos los importes hacia abajo, y el sesgo se nota
        // al sumar mil renglones.
        Afirma::igual('0.0002', Dinero::deCadena('0.00015')->aCadena(), 'medio arriba');
        Afirma::igual('0.0001', Dinero::deCadena('0.00014')->aCadena(), 'menos de medio');
    },

    'a pesos son dos decimales, redondeados' => function (): void {
        Afirma::igual('25.50', Dinero::deCadena('25.5000')->aPesos(), 'exacto');
        Afirma::igual('25.51', Dinero::deCadena('25.5050')->aPesos(), 'medio arriba');
        Afirma::igual('25.50', Dinero::deCadena('25.5049')->aPesos(), 'menos de medio');
    },

    'multiplicar por una cantidad entera es exacto' => function (): void {
        $total = Dinero::deCadena('18.50')->por(Cantidad::deEntero(24));

        Afirma::igual('444.0000', $total->aCadena(), 'el total');
    },

    'multiplicar por una cantidad con decimales redondea una sola vez' => function (): void {
        // 18.50 × 2.5 = 46.25
        $total = Dinero::deCadena('18.50')->por(Cantidad::deCadena('2.5'));

        Afirma::igual('46.2500', $total->aCadena(), 'el total');
    },

    'aplicar una tasa da lo esperado' => function (): void {
        Afirma::igual(
            '16.0000',
            Dinero::deCadena('100.00')->porTasa(Tasa::deCadena('0.1600'))->aCadena(),
            'el 16 % de 100'
        );
    },

    'dividir entre una tasa deshace el camino' => function (): void {
        Afirma::igual(
            '100.0000',
            Dinero::deCadena('116.00')->entreTasa(Tasa::deCadena('0.1600')->masUno())->aCadena(),
            '116 entre 1.16'
        );
    },

    'el redondeo es medio hacia arriba, y en los negativos hacia abajo' => function (): void {
        Afirma::igual(4,  Redondeo::divide(7, 2),   '7/2');
        Afirma::igual(3,  Redondeo::divide(5, 2),   '5/2');
        Afirma::igual(2,  Redondeo::divide(4, 2),   '4/2');
        Afirma::igual(-4, Redondeo::divide(-7, 2),  '-7/2 se aleja del cero');
        Afirma::igual(0,  Redondeo::divide(1, 3),   '1/3');
    },

    'dividir entre cero se queja en vez de dar cualquier cosa' => function (): void {
        Afirma::lanza(DivisionByZeroError::class, fn () => Redondeo::divide(10, 0));
    },

    'una cadena que no es un número se rechaza' => function (): void {
        Afirma::lanza(InvalidArgumentException::class, fn () => Dinero::deCadena('veinticinco'));
        Afirma::lanza(InvalidArgumentException::class, fn () => Dinero::deCadena('25,50'));
        Afirma::lanza(InvalidArgumentException::class, fn () => Dinero::deCadena(''));
    },

    'los negativos van y vuelven enteros' => function (): void {
        $devolucion = Dinero::deCadena('25.50')->negado();

        Afirma::igual('-25.5000', $devolucion->aCadena(), 'la cadena');
        Afirma::cierto($devolucion->esNegativo(), 'es negativo');
        Afirma::igual('0.0000', $devolucion->mas(Dinero::deCadena('25.50'))->aCadena(), 'se cancela');
    },

    'una caja de 24 son 24 unidades base' => function (): void {
        $caja = Cantidad::deCadena('24');
        $tres = Cantidad::deEntero(3);

        Afirma::igual('72.000', $tres->por($caja)->aCadena(), 'tres cajas');
        Afirma::igual(72, $tres->por($caja)->aEntero(), 'como entero');
    },

    'un six de una caja de 24 son 6 unidades' => function (): void {
        Afirma::igual(6, Cantidad::deEntero(1)->por(Cantidad::deCadena('6'))->aEntero(), 'un six');
        Afirma::igual(30, Cantidad::deEntero(5)->por(Cantidad::deCadena('6'))->aEntero(), 'cinco six');
    },

    'pedir media pieza se rechaza en vez de redondearse en silencio' => function (): void {
        // Redondear aquí convierte un error de captura en un error de
        // inventario, que es mucho más caro de encontrar.
        Afirma::lanza(InvalidArgumentException::class, fn () => Cantidad::deCadena('2.5')->aEntero());
    },

    'la escala convierte en los dos sentidos sin perder nada' => function (): void {
        foreach (['0', '1', '25.5', '0.0001', '999999.9999', '-3.25'] as $valor) {
            $ida = Escala::aEntero($valor, 10000);
            $vuelta = Escala::aCadena($ida, 10000, 4);

            Afirma::igual(
                Escala::aEntero($valor, 10000),
                Escala::aEntero($vuelta, 10000),
                'ida y vuelta de ' . $valor
            );
        }
    },

    'un importe grande no se desborda' => function (): void {
        // Nueve millones de pesos: mucho más de lo que mueve la distribuidora
        // en un año, y el entero ni se inmuta.
        //
        // ⚠️ Y esta prueba, cierta, **no podía encontrar el defecto de al lado**:
        // nueve millones por una tasa no se acerca al borde. Es la tercera vez en
        // dos noches que una comprobación verdadera sobre datos que no llegan
        // hasta donde duele deja pasar lo que existía para ver. Las dos que
        // siguen sí van al borde.
        $grande = Dinero::deCadena('9000000.00');

        Afirma::igual('9000000.0000', $grande->aCadena(), 'el importe');
        Afirma::igual(
            '1440000.0000',
            $grande->porTasa(Tasa::deCadena('0.1600'))->aCadena(),
            'su 16 %'
        );
    },

    'multiplicar dos importes que caben, y no caber, se dice' => function (): void {
        // ⚠️ El caso exacto que daba 500 en `/mostrador/agrega`: un precio de
        // 99,999,999.9999 —que el sistema aceptaba por su propia pantalla, 302—
        // por un renglón de 100,000 unidades. Las dos escalas multiplicadas pasan
        // de `PHP_INT_MAX`, PHP vuelve el producto `float` y `Redondeo::divide()`
        // lo rechazaba con un `TypeError`, que es un 500.
        //
        // Ahora se queja el dominio, en su idioma, y quien recibe la queja puede
        // convertirla en un 422. Lo que **no** puede seguir pasando es que el
        // número cambie en silencio.
        $error = Afirma::lanza(
            InvalidArgumentException::class,
            static fn (): Dinero => Dinero::deCadena('99999999.9999')->por(Cantidad::deEntero(100000)),
            'el producto que no cabe'
        );

        Afirma::contiene('no cabe en un entero', $error->getMessage(), 'la queja');

        // Y lo mismo multiplicando cantidades: son la otra mitad del cálculo
        // —unidades base, litros— y estaban igual de desprotegidas.
        Afirma::lanza(
            InvalidArgumentException::class,
            static fn (): Cantidad => Cantidad::deEntero(9000000000)->por(Cantidad::deEntero(9000000000)),
            'las cantidades que no caben'
        );
    },

    'la venta más grande que el sistema permite sí cabe' => function (): void {
        // El otro lado de la misma moneda, y la razón de que el tope sea 100,000
        // pesos por unidad y no el de la columna: el peor caso **legal** —el tope
        // de precio por el tope de renglón— tiene que salir bien. Diez mil
        // millones de pesos, que es absurdo como venta y cabe de sobra.
        $peorCaso = Dinero::deCadena('100000.0000')->por(Cantidad::deEntero(100000));

        Afirma::igual('10000000000.0000', $peorCaso->aCadena(), 'el tope por el tope');
    },
];
