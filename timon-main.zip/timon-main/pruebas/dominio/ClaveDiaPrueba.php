<?php
declare(strict_types=1);

use Dominio\ClaveDia;
use Pruebas\Afirma;

$clave=new ClaveDia(str_repeat('k',32));

return [
    'la misma ruta y fecha producen siempre la misma clave' => function()use($clave):void{
        Afirma::igual($clave->ruta(7,'2026-09-30'),$clave->ruta(7,'2026-09-30'));
        Afirma::cierto((bool)preg_match('/^\d{8}$/',$clave->ruta(7,'2026-09-30')));
    },
    'la clave cambia al cambiar la fecha' => function()use($clave):void{
        Afirma::falso($clave->ruta(7,'2026-09-30')===$clave->ruta(7,'2026-10-01'));
    },
    'ruta y cliente separan sus dominios aunque compartan id' => function()use($clave):void{
        Afirma::falso($clave->ruta(7,'2026-09-30')===$clave->cliente(7,'2026-09-30'));
    },
    'la comprobación usa la derivación exacta' => function()use($clave):void{
        Afirma::cierto($clave->compruebaCliente(3,'2026-09-30',$clave->cliente(3,'2026-09-30')));
        Afirma::falso($clave->compruebaCliente(3,'2026-09-30','00000000'));
    },
    'la app puede comprobar huellas sin transportar la clave legible' => function()use($clave):void{
        $fecha='2026-09-30';
        $ruta=hash('sha256',$clave->ruta(7,$fecha));
        $cliente=hash('sha256',$clave->cliente(7,$fecha));
        Afirma::cierto($clave->compruebaHuellaRuta(7,$fecha,$ruta));
        Afirma::cierto($clave->compruebaHuellaCliente(7,$fecha,$cliente));
        Afirma::falso($clave->compruebaHuellaRuta(7,$fecha,$cliente));
        Afirma::falso($clave->compruebaHuellaCliente(7,$fecha,'no-es-sha-256'));
    },
];
