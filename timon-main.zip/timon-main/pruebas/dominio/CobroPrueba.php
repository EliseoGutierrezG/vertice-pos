<?php
declare(strict_types=1);

use Dominio\Cobro;
use Dominio\Dinero;
use Nucleo\Errores\ErrorHttp;
use Pruebas\Afirma;

/**
 * Las cuentas del cobro: descuento, propina, suma de pagos y cambio.
 *
 * No toca la base. Lo que aquí se cuida es que la app y el servicio lleguen al
 * mismo centavo, y que el cambio nunca salga de un pago que no es efectivo.
 */
$d = static fn (string $pesos): Dinero => Dinero::deCadena($pesos);
$forma = static fn (string $medio, string $importe, ?string $recibido = null): array => [
    'medio' => $medio, 'importe' => Dinero::deCadena($importe),
    'recibido' => $recibido === null ? null : Dinero::deCadena($recibido),
];
$campo = static function (callable $accion): string {
    $error = Afirma::lanza(ErrorHttp::class, $accion);
    Afirma::igual(422, $error->estado(), 'el código');
    return (string) array_key_first($error->campos());
};

return [
    'el efectivo de más regresa como cambio' => function () use ($d, $forma): void {
        $c = Cobro::calcula($d('260'), $d('0'), $d('0'), null, [$forma('efectivo', '260.00', '500.00')]);

        Afirma::igual('260.00', $c['total']->aPesos(), 'el total');
        Afirma::igual('240.00', $c['cambio']->aPesos(), 'el cambio');
        Afirma::igual('240.00', $c['formas'][0]['cambio']->aPesos(), 'el cambio de la forma');
    },

    'la propina se suma después del descuento' => function () use ($d, $forma): void {
        $c = Cobro::calcula($d('300'), $d('30'), $d('50'), null, [$forma('tarjeta', '280.00')]);

        Afirma::igual('50.00', $c['descuento']->aPesos(), 'el descuento');
        Afirma::igual('250.00', $c['venta']->aPesos(), 'la venta');
        Afirma::igual('280.00', $c['total']->aPesos(), 'el total');
        Afirma::igual('0.00', $c['cambio']->aPesos(), 'sin cambio');
    },

    'el descuento en porcentaje redondea el medio centavo hacia arriba' => function () use ($d): void {
        Afirma::igual('26.00', Cobro::porcentaje($d('260'), 10)->aPesos(), 'diez por ciento');
        Afirma::igual('0.02', Cobro::porcentaje($d('0.15'), 10)->aPesos(), 'centavo y medio sube');
        Afirma::igual('0.01', Cobro::porcentaje($d('0.14'), 10)->aPesos(), 'centavo y cuatro décimas baja');
        Afirma::igual('330.00', Cobro::porcentaje($d('999.99'), 33)->aPesos(), 'treinta y tres por ciento');
    },

    'un pago mixto reparte el cambio sólo en el efectivo' => function () use ($d, $forma): void {
        $c = Cobro::calcula($d('260'), $d('20'), $d('0'), null, [
            $forma('efectivo', '100.00', '200.00'), $forma('tarjeta', '180.00'),
        ]);

        Afirma::igual('100.00', $c['cambio']->aPesos(), 'el cambio');
        Afirma::igual('0.00', $c['formas'][1]['cambio']->aPesos(), 'la tarjeta no da cambio');
    },

    'el efectivo sin recibido se toma como exacto' => function () use ($d, $forma): void {
        $c = Cobro::calcula($d('125'), $d('0'), $d('0'), null, [$forma('efectivo', '125.00')]);

        Afirma::igual('0.00', $c['cambio']->aPesos(), 'sin cambio');
        Afirma::cierto($c['formas'][0]['recibido'] === null, 'no se inventa lo recibido');
    },

    'una cortesía completa no pide formas de pago' => function () use ($d): void {
        $c = Cobro::calcula($d('125'), $d('0'), $d('0'), 100, []);

        Afirma::igual('125.00', $c['descuento']->aPesos(), 'el descuento');
        Afirma::igual('0.00', $c['total']->aPesos(), 'el total');
    },

    'lo que no cuadra se rechaza con su campo' => function () use ($d, $forma, $campo): void {
        Afirma::igual('formas', $campo(fn () => Cobro::calcula($d('260'), $d('0'), $d('0'), null, [$forma('efectivo', '250.00')])), 'la suma');
        Afirma::igual('formas', $campo(fn () => Cobro::calcula($d('260'), $d('0'), $d('0'), null, [$forma('efectivo', '260.00', '200.00')])), 'recibido corto');
        Afirma::igual('formas', $campo(fn () => Cobro::calcula($d('260'), $d('0'), $d('0'), null, [$forma('tarjeta', '260.00', '300.00')])), 'tarjeta con recibido');
        Afirma::igual('formas', $campo(fn () => Cobro::calcula($d('260'), $d('0'), $d('0'), null, [$forma('efectivo', '260.00'), $forma('tarjeta', '0')])), 'pago en cero');
        Afirma::igual('descuento', $campo(fn () => Cobro::calcula($d('260'), $d('0'), $d('300'), null, [])), 'descuento mayor');
        Afirma::igual('descuento', $campo(fn () => Cobro::calcula($d('260'), $d('0'), $d('10'), 10, [])), 'dos descuentos');
        Afirma::igual('descuento_porcentaje', $campo(fn () => Cobro::calcula($d('260'), $d('0'), $d('0'), 101, [])), 'porcentaje fuera de rango');
    },
];
