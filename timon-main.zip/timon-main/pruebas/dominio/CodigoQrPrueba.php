<?php
declare(strict_types=1);

use Dominio\CodigoQr;
use Pruebas\Afirma;

/**
 * El código QR del alta del segundo factor (bitácora 97).
 *
 * La lectura real se comprobó al escribirlo: 17 códigos, de la versión 1 a la
 * 15 y con acentos y «€», decodificados por el lector nativo de Chrome
 * (`BarcodeDetector`) con el texto exacto. Aquí quedan fijos los vectores de
 * la norma y la huella de ese resultado, para que un cambio que lo rompa se
 * note sin tener un lector a la mano.
 */

require_once dirname(__DIR__, 2) . '/vistas/partes/piezas.php';

$uriEjemplo = 'otpauth://totp/Base%3Aui.revision?secret=ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'
    . '&issuer=Base&algorithm=SHA1&digits=6&period=30';

return [
    'la corrección Reed-Solomon da el vector conocido' => function (): void {
        // «HELLO WORLD» 1-Q: sus 13 palabras de datos y las 13 de corrección.
        $datos = [32, 91, 11, 120, 209, 114, 220, 77, 67, 64, 236, 17, 236];
        Afirma::igual(
            [168, 72, 22, 82, 217, 54, 156, 0, 46, 15, 180, 122, 16],
            CodigoQr::residuoReedSolomon($datos, CodigoQr::divisorReedSolomon(13))
        );
    },

    'la tabla de bloques cuadra con los módulos de cada versión' => function (): void {
        for ($version = 1; $version <= 15; $version++) {
            Afirma::igual(CodigoQr::palabrasTotales($version), CodigoQr::palabrasDeTabla($version), 'versión ' . $version);
        }
    },

    'elige la versión más chica en la que cabe' => function () use ($uriEjemplo): void {
        Afirma::igual(1, CodigoQr::codifica('hola')->version());
        Afirma::igual(21, CodigoQr::codifica('hola')->tamano());
        Afirma::igual(7, CodigoQr::codifica($uriEjemplo)->version(), 'una URI de Authenticator');
        Afirma::igual(15, CodigoQr::codifica(str_repeat('x', 412))->version(), 'lo más que cabe');
    },

    'lo que no cabe se rechaza en vez de cortarse' => function (): void {
        Afirma::lanza(InvalidArgumentException::class, fn() => CodigoQr::codifica(str_repeat('x', 413)));
    },

    'los patrones fijos están donde dice la norma' => function () use ($uriEjemplo): void {
        $qr = CodigoQr::codifica($uriEjemplo);
        $n = $qr->tamano();
        foreach ([[0, 0], [0, $n - 7], [$n - 7, 0]] as [$fila, $columna]) {
            Afirma::cierto($qr->oscuro($fila, $columna) && $qr->oscuro($fila + 3, $columna + 3), 'localizador oscuro');
            Afirma::cierto(!$qr->oscuro($fila + 1, $columna + 1), 'anillo claro del localizador');
        }
        Afirma::cierto($qr->oscuro($n - 8, 8), 'el módulo oscuro fijo');
        for ($i = 8; $i < $n - 8; $i++) Afirma::igual($i % 2 === 0, $qr->oscuro(6, $i), 'patrón de tiempo en ' . $i);
    },

    'la matriz de la URI de ejemplo no cambia' => function () use ($uriEjemplo): void {
        // Huella de la matriz que el lector de Chrome leyó con el texto exacto.
        Afirma::igual('685c50a80e50ad18decf1cac7bffc434fec493704552b695c95362a9d2e74e2c', hash('sha256', CodigoQr::codifica($uriEjemplo)->comoTexto()));
    },

    'pb_qr dibuja un SVG con nombre y sin el texto a la vista' => function () use ($uriEjemplo): void {
        $svg = pb_qr($uriEjemplo, 'Código para <Prueba>');
        Afirma::cierto(str_starts_with($svg, '<svg class="pb-qr"'));
        Afirma::contiene('viewBox="0 0 53 53"', $svg, 'la versión 7 mide 45 más 8 de silencio');
        Afirma::contiene('role="img"', $svg);
        Afirma::contiene('aria-label="Código para &lt;Prueba&gt;"', $svg, 'la etiqueta se escapa');
        Afirma::cierto(!str_contains($svg, 'ABCDEFGH'), 'el secreto no queda como texto en el SVG');
    },
];
