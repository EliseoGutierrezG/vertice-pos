<?php
declare(strict_types=1);

use Dominio\AnchoTicket;
use Pruebas\Afirma;

/**
 * Los rollos del ticket (2026-11-08, C3): 58, 80 y 76 mm, elegidos al imprimir.
 */
return [
    'los tres rollos se aceptan tal cual' => function (): void {
        Afirma::igual('58', AnchoTicket::normaliza('58'));
        Afirma::igual('80', AnchoTicket::normaliza('80'));
        Afirma::igual('76', AnchoTicket::normaliza(' 76 '));
    },
    'el 78 de antes se lee como 80 para no romper enlaces guardados' => function (): void {
        Afirma::igual('80', AnchoTicket::normaliza('78'));
    },
    'lo que no es un rollo sale en 58' => function (): void {
        Afirma::igual('58', AnchoTicket::normaliza(''));
        Afirma::igual('58', AnchoTicket::normaliza(null));
        Afirma::igual('58', AnchoTicket::normaliza('carta'));
        Afirma::igual('58', AnchoTicket::normaliza('999'));
    },
    'la carta no es ticket' => function (): void {
        Afirma::cierto(AnchoTicket::esTicket('76'));
        Afirma::falso(AnchoTicket::esTicket('carta'));
        Afirma::falso(AnchoTicket::esTicket('78'), 'el 78 ya no es un rollo propio');
    },
    'los botones salen en el orden de la lista' => function (): void {
        Afirma::igual(['58' => '58 mm', '80' => '80 mm', '76' => '76 mm'], AnchoTicket::nombres());
    },
];
