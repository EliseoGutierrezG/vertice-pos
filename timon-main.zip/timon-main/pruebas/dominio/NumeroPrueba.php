<?php
declare(strict_types=1);

use Dominio\Numero;
use Pruebas\Afirma;

/**
 * El número que escribió una persona.
 *
 * La regla que esto sostiene no es de formato, es de **honestidad**: cuando un
 * texto tiene dos lecturas plausibles, se pregunta en lugar de adivinar.
 *
 * «18,50» son dos cosas a la vez: mil ochocientos cincuenta para quien usa la
 * coma de miles, y dieciocho cincuenta para quien la usa de decimales. El
 * código que había le quitaba la coma a todo, así que elegía la primera **en
 * silencio**: medido contra el servidor, un precio de compra de «18,50» quedaba
 * guardado como 1850.0000 con respuesta 302. Cien veces más, sin una señal, y
 * alimentando el costo promedio del producto.
 */
return [
    'un decimal normal pasa tal cual' => function (): void {
        Afirma::igual('25.50', Numero::escrito('25.50'), 'el precio');
        Afirma::igual('12', Numero::escrito('12'), 'un entero');
        Afirma::igual('12.500', Numero::escrito('12.500'), 'con ceros de relleno');
    },

    'los adornos se quitan: el signo de pesos y los espacios' => function (): void {
        // Quien teclea «$ 1,250.00» escribió un importe. Pedirle que lo repita
        // sin adornos no protege de nada.
        Afirma::igual('1250.00', Numero::escrito('$ 1,250.00'), 'con pesos y espacios');
        Afirma::igual('18.50', Numero::escrito('  18.50  '), 'con espacios alrededor');
        Afirma::igual('18.50', Numero::escrito("18.50\u{00a0}"), 'con espacio duro, del copiar y pegar');
    },

    'la coma vale de miles sólo cuando el punto decimal también está' => function (): void {
        Afirma::igual('1250.75', Numero::escrito('1,250.75'), 'con decimales');
        Afirma::igual('1234567.89', Numero::escrito('1,234,567.89'), 'dos separadores');
        Afirma::igual('1250.00', Numero::escrito('1,250.00'), 'con centavos redondos');
    },

    'y NO vale de separador decimal: ahí se pregunta' => function (): void {
        // Éste es el caso que importa: cada uno de estos se aceptaba y se
        // guardaba multiplicado por diez o por cien.
        //
        // «1,250» y «12,345» entran en la lista aunque parezcan miles legítimos:
        // sin punto decimal no hay manera de saber si son 1250 o 1.250, y en un
        // campo de cantidad —que lleva milésimas— eso son mil veces.
        foreach (['18,50', '25,5', '1,25', '0,99', '12,345', '1,250'] as $texto) {
            Afirma::lanza(
                InvalidArgumentException::class,
                fn () => Numero::escrito($texto),
                'adivinó la coma de "' . $texto . '"'
            );
        }
    },

    'el espacio sí se quita: nunca es un separador decimal' => function (): void {
        // A diferencia de la coma, un espacio no tiene dos lecturas: nadie
        // escribe «1 5» queriendo decir uno y medio.
        Afirma::igual('1000', Numero::escrito('1 000'), 'con espacio de miles');
        Afirma::igual('12345.67', Numero::escrito('12 345.67'), 'con espacio y decimales');
    },

    'lo que no es un número se rechaza' => function (): void {
        foreach (['doce', '', '.5', '1e2', '1.2.3', '12-', '--3', '$', '1.', '+5'] as $texto) {
            Afirma::lanza(
                InvalidArgumentException::class,
                fn () => Numero::escrito($texto),
                'aceptó "' . $texto . '"'
            );
        }
    },

    'el negativo pasa, y quien llame decide si lo acepta' => function (): void {
        // El signo no se juzga aquí: un ajuste de inventario puede ser negativo
        // y un precio no. Esa regla es de cada campo, no de la lectura.
        Afirma::igual('-12.5', Numero::escrito('-12.5'), 'un negativo');
        Afirma::igual('-1250.00', Numero::escrito('-1,250.00'), 'un negativo con miles');
    },

    'un separador de miles a medias no se acepta' => function (): void {
        // «12,34» no es un agrupamiento de miles ni un decimal con punto. Que no
        // sea ninguna de las dos cosas es la razón de rechazarlo.
        foreach (['12,34', '1,2345', '1,23,456', ',250.00', '1,250,.00'] as $texto) {
            Afirma::lanza(
                InvalidArgumentException::class,
                fn () => Numero::escrito($texto),
                'aceptó el agrupamiento roto "' . $texto . '"'
            );
        }
    },
];
