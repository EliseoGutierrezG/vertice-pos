#!/usr/bin/env bash
# Prueba de humo del personal y sus usuarios.
#
#   pruebas/humo-personal.sh
#
# El criterio de la fase: **no se puede crear un usuario sin personal** y
# **cada puesto ve sólo su menú**, con el recorrido de los siete. Además, el
# ciclo completo de un acceso: la persona se da de alta, se le crea el usuario
# con una contraseña temporal que se ve una vez, al entrar se le obliga a
# cambiarla —en la web y en la API—, su teléfono se autoriza, se restablece,
# se bloquea, se reactiva y se da de baja.
#
# Al terminar borra lo que creó, pase lo que pase.

set -u
BASE="${1:-http://127.0.0.1:8081}"
PHP=/opt/homebrew/opt/php@8.3/bin/php
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
. "$RAIZ/pruebas/exige-entorno.sh"
. "$RAIZ/pruebas/fixtures/entra-segundo-factor.sh"
TARRO=$(mktemp -d)
GALLETAS="$TARRO/galletas"

verde=$'\033[32m'; rojo=$'\033[31m'; gris=$'\033[90m'; nada=$'\033[0m'
pasadas=0; fallas=0

ok()   { printf "  %s✓%s %s\n" "$verde" "$nada" "$1"; pasadas=$((pasadas + 1)); }
mal()  { printf "  %s✗%s %s\n" "$rojo" "$nada" "$1"; fallas=$((fallas + 1)); }
juzga() { if [ "$2" = "$3" ]; then ok "$1"; else mal "$1 — esperaba $3, llegó $2"; fi; }
dice()  { if printf '%s' "$2" | grep -q -- "$3"; then ok "$1"; else mal "$1"; fi; }
calla() { if printf '%s' "$2" | grep -q -- "$3"; then mal "$1"; else ok "$1"; fi; }

# Lo que dieron de alta los usuarios `humo.per.`, y después ellos. Primero los
# usuarios —se llevan a su persona—, luego el personal que quedó sin usuario y
# al final las sucursales.
limpia_bd() {
  "$PHP" -r '
    require "'"$RAIZ"'/nucleo/Autocargador.php";
    Nucleo\Autocargador::registrar("'"$RAIZ"'");
    Nucleo\Reloj::fijaLaZona("'"$RAIZ"'");
    require "'"$RAIZ"'/pruebas/Semilla.php";
    $bd  = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
    $ids = array_map("intval", array_column($bd->filas("SELECT id FROM usuario WHERE usuario LIKE ?", ["humo.per.%"]), "id"));
    $sucursales = []; $personas = [];
    if ($ids !== []) {
      $m = implode(", ", array_fill(0, count($ids), "?"));
      $sucursales  = array_map("intval", array_column($bd->filas("SELECT id FROM sucursal WHERE creado_por IN ($m)", $ids), "id"));
      $personas = array_map("intval", array_column($bd->filas("SELECT id FROM personal WHERE creado_por IN ($m)", $ids), "id"));
      if ($personas !== []) {
        $bd->ejecuta("UPDATE personal SET id_superior = NULL WHERE id IN (" . implode(", ", $personas) . ")");
      }
    }
    $bd->ejecuta("DELETE FROM intento_acceso");
    Pruebas\Semilla::borraUsuarios($bd, "humo.per.");
    if ($personas !== []) {
      $bd->ejecuta("DELETE FROM personal WHERE id IN (" . implode(", ", $personas) . ")");
    }
    if ($sucursales !== []) {
      $bd->ejecuta("DELETE FROM sucursal WHERE id IN (" . implode(", ", $sucursales) . ")");
    }
  '
}

limpia() {
  limpia_bd
  rm -rf "$TARRO"
}
trap limpia EXIT

# Las contraseñas viven en estas variables y mueren con el guion.
CLAVE="prueba-$(head -c 12 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9')"
PROPIA="propia-$(head -c 12 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9')"
S=$(head -c 3 /dev/urandom | xxd -p)
HOY=$(date +%Y-%m-%d)

limpia_bd
# Los siete puestos, cada uno con su usuario. Imprime la persona del administrador.
YO=$("$PHP" -r '
  require "'"$RAIZ"'/nucleo/Autocargador.php";
  Nucleo\Autocargador::registrar("'"$RAIZ"'");
  require "'"$RAIZ"'/pruebas/Semilla.php";
  $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
  $admin = Pruebas\Semilla::usuario($bd, "humo.per.administrador", "administrador", $argv[1]);
  foreach (["gerente", "cajero", "mesero", "cocina", "barra", "almacen"] as $puesto) {
    Pruebas\Semilla::usuario($bd, "humo.per." . $puesto, $puesto, $argv[1]);
  }
  echo $bd->valor("SELECT id_personal FROM usuario WHERE id = ?", [$admin]);
' "$CLAVE")

echo "${gris}Contra ${BASE}${nada}"

marca_de() { curl -s -m 10 -c "$GALLETAS" -b "$GALLETAS" "$BASE$1" \
  | grep -o 'name="\(_marca\|csrf-token\)" \(value\|content\)="[a-f0-9]*"' | head -1 | sed 's/.*="//;s/"//'; }

# entra USUARIO [CONTRASEÑA] [PANTALLA DE DONDE SACAR LA MARCA]
entra() {
  entra_web_segura "$BASE" "$PHP" "$RAIZ" "$1" "${2:-$CLAVE}" "$GALLETAS" || return 1
  MARCA=$(marca_de "${3:-/panel}")
}

postea() { curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code} %{redirect_url}' \
  --data-urlencode "_marca=$MARCA" "${@:2}" "$BASE$1"; }
postea_json() { curl -s -m 10 -b "$GALLETAS" -w '|%{http_code}' -H 'Accept: application/json' \
  --data-urlencode "_marca=$MARCA" "${@:2}" "$BASE$1"; }
codigo() { curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' "$BASE$1"; }
manda_a() { curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code} %{redirect_url}' "$BASE$1"; }
pagina() { curl -s -m 10 -b "$GALLETAS" "$BASE$1"; }
ficha_modal() { curl -s -m 10 -b "$GALLETAS" -H "Accept: application/json" "$BASE/personal-detalle/$1${2:-}" | "$PHP" -r '$j=json_decode(stream_get_contents(STDIN),true);echo $j["datos"]["html"] ?? "";'; }
# Las entradas del menú, en orden y en un renglón.
menu() { pagina /panel | sed -n '/<nav class="app-menu"/,/<\/nav>/p' | grep -o 'href="[^"]*"' | sed 's/href="//;s/"$//' | tr '\n' ' ' | sed 's/ $//'; }
# La contraseña temporal que muestra la ficha, si la muestra.
temporal_de() { printf '%s' "$1" | grep -o 'fs-5 ms-1">[a-z0-9-]*<' | sed 's/.*">//;s/<$//'; }
api_entra() { curl -s -m 10 -w '|%{http_code}' -H 'Content-Type: application/json' \
  -d "{\"usuario\":\"$1\",\"clave\":\"$2\",\"dispositivo\":{\"identificador\":\"humo-per-$S\",\"nombre\":\"Teléfono de humo\"}}" \
  "$BASE/api/v1/entrar"; }

# --- el recorrido de los siete --------------------------------------------
echo "${gris}cada puesto ve sólo su menú${nada}"
esperado() {
  case "$1" in
    administrador) echo "/panel /areas /mesas /mesas/plano /reservaciones /categorias-menu /platillos /promociones /carta /equipos-comanda /impresoras /gastos /caja/turnos /reportes /inventario/insumos /inventario/lotes /inventario/compras /inventario/proveedores /inventario/recetas /inventario/movimientos /inventario/faltantes /sucursales /servidores /personal /dispositivos /avisos /seguridad /seguridad/accesos /bitacora /privacidad" ;;
    gerente)       echo "/panel /areas /mesas /mesas/plano /reservaciones /platillos /promociones /carta /equipos-comanda /impresoras /gastos /caja/turnos /reportes /inventario/insumos /inventario/lotes /inventario/compras /inventario/proveedores /inventario/recetas /inventario/movimientos /inventario/faltantes /sucursales /personal /dispositivos /avisos /bitacora" ;;
    cajero)        echo "/panel /areas /mesas /mesas/plano /gastos /caja/turnos" ;;
    mesero)        echo "/panel /areas /mesas /mesas/plano" ;;
    almacen)       echo "/panel /inventario/insumos /inventario/lotes /inventario/compras /inventario/proveedores /inventario/recetas /inventario/movimientos /inventario/faltantes" ;;
    *)             echo "/panel" ;;
  esac
}
for puesto in administrador gerente cajero mesero cocina barra almacen; do
  entra "humo.per.$puesto"
  juzga "$puesto: su menú" "$(menu)" "$(esperado "$puesto")"
  # Quien ve una opción, entra (R2.3): ninguna da 403 ni 500.
  for destino in $(menu); do
    c=$(codigo "$destino"); [ "$c" = 200 ] || mal "$puesto: $destino abre — llegó $c"
  done
  case "$puesto" in
    administrador|gerente)
      juzga "$puesto: abre personal"     "$(codigo /personal)" 200
      juzga "$puesto: abre dispositivos" "$(codigo /dispositivos)" 200
      juzga "$puesto: abre sucursales"   "$(codigo /sucursales)" 200 ;;
    *)
      juzga "$puesto: personal le da 403"     "$(codigo /personal)" 403
      juzga "$puesto: dispositivos le da 403" "$(codigo /dispositivos)" 403
      juzga "$puesto: sucursales le da 403"   "$(codigo /sucursales)" 403 ;;
  esac
done

# --- administrador: la sucursal para trabajar -----------------------------
entra humo.per.administrador
R=$(postea /sucursales --data-urlencode "nombre=Sucursal Per $S" --data-urlencode "clave=P$S")
SUCURSAL=$(printf '%s' "$R" | grep -o '[0-9]*$')
[ -n "$SUCURSAL" ] && ok "la sucursal de trabajo existe" || mal "la sucursal de trabajo existe"

# --- alta de la persona ---------------------------------------------------
echo "${gris}alta de personal${nada}"
R=$(postea_json /personal --data-urlencode "nombre=Julia" --data-urlencode "apellido_paterno=Humo$S" --data-urlencode "fecha_ingreso=$HOY")
juzga "sin puesto se rechaza con 422" "${R##*|}" 422
dice  "y la queja va en id_puesto" "$R" '"id_puesto":'

puesto_id() { "$PHP" -r 'require "'"$RAIZ"'/nucleo/Autocargador.php"; Nucleo\Autocargador::registrar("'"$RAIZ"'");
  echo (new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'")))->valor("SELECT id FROM puesto WHERE clave = ?", [$argv[1]]);' "$1"; }
MESERO=$(puesto_id mesero)
COCINA=$(puesto_id cocina)
R=$(postea_json /personal --data-urlencode "nombre=Julia" --data-urlencode "apellido_paterno=Humo$S" --data-urlencode "fecha_ingreso=$HOY" --data-urlencode "id_puesto=$MESERO")
juzga "un mesero sin sucursal se rechaza con 422" "${R##*|}" 422
dice  "y la queja va en id_sucursal" "$R" '"id_sucursal":'

R=$(postea /personal --data-urlencode "nombre=Julia" --data-urlencode "apellido_paterno=Humo$S" --data-urlencode "fecha_ingreso=$HOY" \
  --data-urlencode "id_puesto=$MESERO" --data-urlencode "id_sucursal=$SUCURSAL" --data-urlencode "telefono=222 555 0000")
PERSONA=$(printf '%s' "$R" | grep -o '/personal/[0-9]*$' | grep -o '[0-9]*')
[ -n "$PERSONA" ] && ok "con puesto y sucursal se da de alta y manda a su ficha" || mal "con puesto y sucursal se da de alta y manda a su ficha — llegó $R"
FICHA=$(ficha_modal "$PERSONA")
juzga "la URL anterior abre el listado con el modal" "$(manda_a "/personal/$PERSONA")" "302 $BASE/personal?ver=$PERSONA"
dice "la ficha la nombra" "$FICHA" "Julia Humo$S"
dice "y ofrece crearle el usuario" "$FICHA" "action=\"/personal/$PERSONA/usuario\""
RESUMEN=$(curl -s -m 10 -b "$GALLETAS" -H 'Accept: application/json' "$BASE/personal-detalle/$PERSONA")
dice "el modal consulta el nombre de la persona" "$RESUMEN" "Julia Humo$S"
dice "y permite crear el usuario desde el modal" "$RESUMEN" 'Crear usuario'
dice "el modal ofrece los datos actuales para actualizar" "$RESUMEN" '"registro":'
juzga "un detalle de persona inexistente da 404" "$(codigo /personal-detalle/999999999)" 404
juzga "sin sesión no se consulta el detalle" "$(curl -s -m 10 -o /dev/null -w '%{http_code}' -H 'Accept: application/json' "$BASE/personal-detalle/$PERSONA")" 401
dice "la lista la muestra sin usuario" "$(pagina /personal)" 'Sin usuario'
LISTA_PERSONAL=$(pagina "/personal?sucursal=$SUCURSAL")
dice "Personal ofrece exportar con el filtro aplicado" "$LISTA_PERSONAL" "href=\"/personal.xlsx?sucursal=$SUCURSAL\""
dice "Acción es la primera columna" "$LISTA_PERSONAL" '<th data-pb-acciones>Acción</th>'
dice "Actualizar consulta la persona al abrir" "$LISTA_PERSONAL" "data-pb-registro-url=\"/personal-detalle/$PERSONA\""
juzga "sin sesión no se descarga el XLS" "$(curl -s -m 10 -o /dev/null -w '%{http_code}' -H 'Accept: application/json' "$BASE/personal.xlsx")" 401
curl -s -m 10 -b "$GALLETAS" "$BASE/personal.xlsx?sucursal=$SUCURSAL" -o "$TARRO/personal.xlsx"
if unzip -p "$TARRO/personal.xlsx" xl/worksheets/sheet1.xml 2>/dev/null | grep -q "Julia Humo$S"; then ok "el XLS trae la persona del filtro"; else mal "el XLS trae la persona del filtro"; fi

R=$(postea_json /personal --data-urlencode "nombre=Rodrigo" --data-urlencode "apellido_paterno=Humo$S" --data-urlencode "fecha_ingreso=$HOY" \
  --data-urlencode "id_puesto=$COCINA" --data-urlencode "id_sucursal=$SUCURSAL")
juzga "alguien de cocina por JSON contesta 200" "${R##*|}" 200
COCINERO=$(printf '%s' "$R" | sed -n 's/.*"redirige":"\/personal\/\([0-9]*\)".*/\1/p')

# --- el usuario nace de la persona ----------------------------------------
echo "${gris}no hay usuario sin personal${nada}"
juzga "crear usuario para una persona que no existe da 404" \
  "$(postea_json /personal/65000/usuario --data-urlencode "usuario=humo.per.nadie" | sed 's/.*|//')" 404
juzga "y no hay otra puerta para crear usuarios" \
  "$(postea_json /usuarios --data-urlencode "usuario=humo.per.nadie" | sed 's/.*|//')" 404

R=$(postea "/personal/$PERSONA/usuario" --data-urlencode "usuario=humo.per.julia")
juzga "el usuario se crea desde la ficha" "$R" "302 $BASE/personal/$PERSONA"
LISTA_ACTIVA=$(pagina /personal)
dice "la fila ofrece restablecer la contraseña" "$LISTA_ACTIVA" "data-pb-post=\"/personal/$PERSONA/usuario/clave\""
dice "la fila ofrece bloquear el acceso" "$LISTA_ACTIVA" "data-pb-post=\"/personal/$PERSONA/usuario/baja\""
dice "la fila ofrece dar de baja a la persona" "$LISTA_ACTIVA" "data-pb-post=\"/personal/$PERSONA/baja\""
YO_PERSONAL=$YO
calla "no ofrece bloquear el propio acceso" "$LISTA_ACTIVA" "data-pb-post=\"/personal/$YO_PERSONAL/usuario/baja\""
calla "no ofrece dar de baja a la propia persona" "$LISTA_ACTIVA" "data-pb-post=\"/personal/$YO_PERSONAL/baja\""
curl -s -m 10 -b "$GALLETAS" -H 'Accept: application/json' "$BASE/personal-detalle/$PERSONA" >/dev/null
juzga "la URL anterior señala la credencial pendiente" "$(manda_a "/personal/$PERSONA")" "302 $BASE/personal?ver=$PERSONA&credencial=1"
OTRO=$(ficha_modal "$COCINERO" '?credencial=1')
calla "otra persona no recibe la contraseña" "$OTRO" 'data-pb-clave-temporal'
curl -s -m 10 -b "$GALLETAS" -H 'Accept: application/json' -D "$TARRO/cabeceras" -o "$TARRO/ficha.json" "$BASE/personal-detalle/$PERSONA?credencial=1"
FICHA_CLAVE=$("$PHP" -r '$j=json_decode(file_get_contents($argv[1]),true);echo $j["datos"]["html"] ?? "";' "$TARRO/ficha.json")
TEMPORAL=$(temporal_de "$FICHA_CLAVE")
[ -n "$TEMPORAL" ] && ok "la ficha muestra la contraseña temporal" || mal "la ficha muestra la contraseña temporal"
dice  "sin que se guarde en ninguna caché" "$(cat "$TARRO/cabeceras")" 'no-store'
calla "una sola vez" "$(ficha_modal "$PERSONA" "?credencial=1")" 'data-pb-clave-temporal'
calla "y la bitácora no la tiene" "$(pagina '/bitacora?modulo=personal')" "$TEMPORAL"

R=$(postea_json "/personal/$PERSONA/usuario" --data-urlencode "usuario=humo.per.otro")
juzga "una persona no tiene dos usuarios: 409" "${R##*|}" 409
R=$(postea_json "/personal/$COCINERO/usuario" --data-urlencode "usuario=humo.per.julia")
juzga "un nombre de usuario ya ocupado da 422" "${R##*|}" 422
dice  "con la queja en el campo" "$R" '"usuario":"Ese nombre de usuario ya existe'
juzga "al de cocina se le crea el suyo" "$(postea "/personal/$COCINERO/usuario" --data-urlencode "usuario=humo.per.rodrigo" | cut -c1-3)" 302

# --- la contraseña temporal obliga a cambiarla ----------------------------
echo "${gris}contraseña temporal${nada}"
R=$(api_entra humo.per.julia "$TEMPORAL")
juzga "la app no entra con la temporal: 403" "${R##*|}" 403
dice  "y dice por qué" "$R" '"clave":"clave_temporal"'

entra humo.per.julia "$TEMPORAL" /cambiar-clave
juzga "en la web entra, pero el tablero la manda a cambiarla" "$(manda_a /panel)" "302 $BASE/cambiar-clave"
juzga "igual que cualquier otra pantalla" "$(manda_a /perfil)" "302 $BASE/cambiar-clave"
R=$(curl -s -m 10 -b "$GALLETAS" -w '|%{http_code}' -H 'Accept: application/json' "$BASE/panel")
juzga "quien pide JSON recibe 403" "${R##*|}" 403
dice  "con la clave clave_temporal" "$R" '"clave":"clave_temporal"'
dice  "la pantalla de cambio lo explica" "$(pagina /cambiar-clave)" 'temporal'

R=$(postea_json /cambiar-clave --data-urlencode "actual=$TEMPORAL" --data-urlencode "nueva=corta" --data-urlencode "confirma=corta")
juzga "una contraseña corta se rechaza" "${R##*|}" 422
R=$(postea_json /cambiar-clave --data-urlencode "actual=$TEMPORAL" --data-urlencode "nueva=$PROPIA" --data-urlencode "confirma=$PROPIA")
juzga "la suya se acepta" "${R##*|}" 200
juzga "y ya abre el tablero" "$(codigo /panel)" 200
juzga "la app ya entra con la suya" "$(api_entra humo.per.julia "$PROPIA" | sed 's/.*|//')" 200

# --- teléfono -------------------------------------------------------------
echo "${gris}teléfono${nada}"
entra humo.per.administrador
TELEFONOS=$(pagina /dispositivos)
TELEFONO=$(printf '%s' "$TELEFONOS" | grep -o 'data-pb-post="/dispositivos/[0-9]*/autoriza"' | head -1 | grep -o '[0-9]*')
[ -n "$TELEFONO" ] && ok "su teléfono espera autorización" || mal "su teléfono espera autorización"
dice "Teléfonos lleva Exportar XLS" "$TELEFONOS" 'href="/dispositivos.xlsx'
dice "y cuenta sus registros" "$TELEFONOS" 'registro'
dice "y su filtro dice Buscar" "$TELEFONOS" 'Limpiar filtro'
dice "Ver del teléfono muestra a la persona" "$(curl -s -m 10 -b "$GALLETAS" -H 'Accept: application/json' "$BASE/dispositivos/$TELEFONO")" "Julia Humo$S"
dice "el XLS de equipos baja como archivo" "$(curl -s -m 20 -b "$GALLETAS" -D - -o /dev/null "$BASE/dispositivos.xlsx")" 'filename="equipos_'
TOKEN=$(api_entra humo.per.julia "$PROPIA" | sed -n 's/.*"token":"\([a-f0-9]*\)".*/\1/p')
juzga "sin autorizar no opera" \
  "$(curl -s -m 10 -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $TOKEN" "$BASE/api/v1/estado")" 403
juzga "se autoriza" "$(postea_json "/dispositivos/$TELEFONO/autoriza" | sed 's/.*|//')" 200
juzga "y ya opera" \
  "$(curl -s -m 10 -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $TOKEN" "$BASE/api/v1/estado")" 200
dice "la lista de autorizados lo tiene" "$(pagina '/dispositivos?filtro=autorizados')" "Julia Humo$S"
dice "y ofrece Revocar acceso" "$(pagina '/dispositivos?filtro=autorizados')" "data-pb-post=\"/dispositivos/$TELEFONO/retira\""

# --- avisos a varios teléfonos ---------------------------------------------
# Solo lo que se rechaza antes de hablar con Expo: el humo nunca manda un
# aviso real. El envío y sus tandas los prueba NotificacionesPrueba.
echo "${gris}avisos${nada}"
llave() { uuidgen | tr 'A-Z' 'a-z'; }
AVISOS=$(pagina /avisos)
dice "Avisos abre con su historial" "$AVISOS" 'Avisos del panel a los teléfonos'
juzga "y exporta su XLS" "$(codigo /avisos.xlsx)" 200
R=$(postea_json /avisos --data-urlencode "_envio=$(llave)" --data-urlencode "destino=todos" --data-urlencode "titulo=" --data-urlencode "cuerpo=Prueba")
juzga "un aviso sin título se rechaza con 422" "${R##*|}" 422
R=$(postea_json /avisos --data-urlencode "_envio=$(llave)" --data-urlencode "destino=sucursal:1" --data-urlencode "titulo=El Timón" --data-urlencode "cuerpo=Prueba")
juzga "y uno a un destino que no existe" "${R##*|}" 422
dice "con la queja en el destino" "$R" '"destino"'
R=$(postea_json /avisos --data-urlencode "titulo=El Timón" --data-urlencode "cuerpo=Prueba" --data-urlencode "destino=todos")
juzga "sin llave de envío no sale" "${R##*|}" 422

# --- restablecer, bloquear, reactivar -------------------------------------
echo "${gris}el acceso${nada}"
hash_temporal() {
  "$PHP" -r '
    require "'"$RAIZ"'/nucleo/Autocargador.php";
    Nucleo\Autocargador::registrar("'"$RAIZ"'");
    $bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos("'"$RAIZ"'"));
    echo $bd->valor("SELECT clave_hash FROM usuario WHERE id_personal = ?", [$argv[1]]);
  ' "$PERSONA"
}
ENVIO_CLAVE=$(uuidgen | tr 'A-Z' 'a-z')
R=$(postea "/personal/$PERSONA/usuario/clave" --data-urlencode "_envio=$ENVIO_CLAVE")
HASH_PRIMERO=$(hash_temporal)
R_REPETIDO=$(postea "/personal/$PERSONA/usuario/clave" --data-urlencode "_envio=$ENVIO_CLAVE")
HASH_REPETIDO=$(hash_temporal)
juzga "restablecer la contraseña regresa a la ficha" "$R" "302 $BASE/personal/$PERSONA"
juzga "repetir el envío de clave devuelve el mismo destino" "$R_REPETIDO" "$R"
[ "$HASH_PRIMERO" = "$HASH_REPETIDO" ] && ok "repetir el envío no genera otra contraseña" || mal "repetir el envío no genera otra contraseña"
R_SIN_LLAVE=$(PB_SIN_ENVIO=1 postea_json "/personal/$PERSONA/usuario/clave")
juzga "restablecer sin llave se rechaza" "${R_SIN_LLAVE##*|}" 422
ENVIO_NUEVO=$(uuidgen | tr 'A-Z' 'a-z')
R_NUEVO=$(postea "/personal/$PERSONA/usuario/clave" --data-urlencode "_envio=$ENVIO_NUEVO")
HASH_NUEVO=$(hash_temporal)
[ "$HASH_PRIMERO" != "$HASH_NUEVO" ] && [ "$R_NUEVO" = "$R" ] && ok "otra intención genera otra contraseña" || mal "otra intención genera otra contraseña"
unset HASH_PRIMERO HASH_REPETIDO HASH_NUEVO
OTRA=$(temporal_de "$(ficha_modal "$PERSONA" "?credencial=1")")
[ -n "$OTRA" ] && [ "$OTRA" != "$TEMPORAL" ] && ok "con otra temporal" || mal "con otra temporal"
juzga "la de antes ya no sirve" "$(api_entra humo.per.julia "$PROPIA" | sed 's/.*|//')" 401
juzga "y el teléfono tiene que volver a entrar" \
  "$(curl -s -m 10 -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $TOKEN" "$BASE/api/v1/yo")" 401

R=$(postea_json "/personal/$PERSONA/usuario/baja" --data-urlencode 'volver=/seguridad/accesos')
juzga "el acceso se bloquea" "${R##*|}" 200
dice "y vuelve a revisión de accesos cuando se solicita" "$R" '"redirige":"\/seguridad\/accesos"'
dice "el listado ofrece desbloquear la cuenta" "$(pagina /personal)" "data-pb-post=\"/personal/$PERSONA/usuario/reactiva\""
dice  "y la lista lo dice" "$(pagina /personal)" 'Bloqueado'
juzga "bloqueado no restablece: 409" "$(postea_json "/personal/$PERSONA/usuario/clave" | sed 's/.*|//')" 409
R=$(postea "/personal/$PERSONA/usuario/reactiva")
juzga "se reactiva" "$R" "302 $BASE/personal/$PERSONA"
NUEVA=$(temporal_de "$(pagina "/personal/$PERSONA?sinjs=1")")
[ -n "$NUEVA" ] && [ "$NUEVA" != "$OTRA" ] && ok "con una temporal nueva" || mal "con una temporal nueva"

# --- baja ---------------------------------------------------------------
echo "${gris}baja${nada}"
juzga "nadie se da de baja a sí mismo: 409" "$(postea_json "/personal/$YO/baja" | sed 's/.*|//')" 409
juzga "la persona se da de baja" "$(postea_json "/personal/$PERSONA/baja" | sed 's/.*|//')" 200
calla "no sale entre los activos" "$(pagina /personal)" "Julia Humo$S"
dice  "pero sí entre los dados de baja" "$(pagina '/personal?estatus=inactivas')" "Julia Humo$S"
entra humo.per.julia "$NUEVA" /entrar
juzga "ya no entra a la web" "$(manda_a /panel)" "302 $BASE/entrar"

entra humo.per.administrador
juzga "se reactiva la persona" "$(postea_json "/personal/$PERSONA/reactiva" | sed 's/.*|//')" 200
dice  "con el acceso todavía bloqueado" "$(pagina /personal)" 'Bloqueado'

echo "${gris}sin la marca${nada}"
juzga "un POST sin marca da 419" \
  "$(curl -s -m 10 -b "$GALLETAS" -o /dev/null -w '%{http_code}' -d "nombre=Sin marca" "$BASE/personal")" 419

# --- quien no administra no escribe ---------------------------------------
echo "${gris}cajero${nada}"
entra humo.per.cajero
juzga "dar de alta personal le da 403" \
  "$(postea_json /personal --data-urlencode "nombre=Intrusa" --data-urlencode "apellido_paterno=Humo$S" --data-urlencode "fecha_ingreso=$HOY" | sed 's/.*|//')" 403
juzga "crear un usuario, también" \
  "$(postea_json "/personal/$COCINERO/usuario" --data-urlencode "usuario=humo.per.intruso" | sed 's/.*|//')" 403
juzga "y autorizar un teléfono" "$(postea_json "/dispositivos/$TELEFONO/autoriza" | sed 's/.*|//')" 403
juzga "no ve los avisos" "$(codigo /avisos)" 403
juzga "ni los manda" \
  "$(postea_json /avisos --data-urlencode "_envio=$(uuidgen | tr 'A-Z' 'a-z')" --data-urlencode "destino=todos" --data-urlencode "titulo=El Timón" --data-urlencode "cuerpo=Prueba" | sed 's/.*|//')" 403

echo
if [ "$fallas" -eq 0 ]; then
  echo "${verde}${pasadas} comprobaciones, todas pasan.${nada}"
else
  echo "${rojo}${fallas} de $((pasadas + fallas)) fallan.${nada}"
  exit 1
fi
