<?php
declare(strict_types=1);

use Nucleo\Atributos\Accion;
use Nucleo\BaseDatos;
use Nucleo\Middleware\ExigeMarca;
use Nucleo\Middleware\ExigePermiso;
use Nucleo\Middleware\ExigeToken;
use Nucleo\Middleware\ExigeEquipo;
use Nucleo\Middleware\ExigeInstalacion;
use Nucleo\Router;
use Pruebas\Afirma;

/**
 * La tabla de rutas entera, mirada de una vez.
 *
 * `PermisoPrueba` comprueba que el intermediario haga su trabajo: que una acción
 * sin atributo se rechace, que sin el permiso no corra. Lo que **no** puede
 * comprobar es que ese intermediario esté puesto en las 98 rutas. Eso es lo que
 * se mira aquí, y es el descuido plausible: alguien agrega una ruta nueva fuera
 * del grupo y nadie lo nota, porque la ruta funciona —funciona **de más**—.
 *
 * Las tres preguntas:
 *  - ¿Toda ruta pasa por `ExigePermiso`?
 *  - ¿Toda acción existe y declara su `#[Accion]`?
 *  - ¿Todo permiso que una acción exige **existe en la tabla**? Un permiso mal
 *    escrito no falla: se lo niega a todo el mundo, en silencio, para siempre.
 */

$raiz = dirname(__DIR__);

/** Un árbol solo: 'web' o 'api'. */
$arbol = static function (string $cual) use ($raiz): array {
    $router = new Router();
    (require $raiz . "/rutas/$cual.php")($router);

    return $router->rutas();
};

$tabla = static fn (): array => [...$arbol('web'), ...$arbol('api')];

/** @return list<string> los permisos que exige una acción */
$permisosDe = static function (Accion $accion): array {
    $permisos = [];

    // Un atributo puede pedir varios permisos separados por coma: la pantalla
    // se ve con cualquiera de ellos.
    foreach (explode(',', $accion->permiso) as $permiso) {
        if (trim($permiso) !== '') {
            $permisos[] = trim($permiso);
        }
    }

    return $permisos;
};

return [
    'toda ruta pasa por el intermediario de permisos' => function () use ($tabla): void {
        $sueltas = [];
        $cuantas = 0;

        foreach ($tabla() as $ruta) {
            $cuantas++;

            if (!in_array(ExigePermiso::class, $ruta->intermediarios(), true)) {
                $sueltas[] = $ruta->metodo() . ' ' . $ruta->patron();
            }
        }

        // El piso sube con cada fase del plan v2: la entrada, el tablero, el
        // perfil, la bitácora, el diagnóstico y la puerta de la app (fase 1), y
        // sucursales, oficinas y rutas (fase 2), personal y dispositivos (fase
        // 3), clientes con geocodificación (fase 4) y productos (fase 5).
        Afirma::cierto($cuantas >= 60, "se revisaron $cuantas rutas");
        Afirma::igual([], $sueltas, 'rutas que nadie obliga a declarar permiso');
    },

    'toda acción existe y declara qué exige' => function () use ($tabla): void {
        $problemas = [];

        foreach ($tabla() as $ruta) {
            [$clase, $metodo] = $ruta->destino();
            $donde            = $ruta->metodo() . ' ' . $ruta->patron();

            if (!method_exists($clase, $metodo)) {
                $problemas[] = "$donde apunta a $clase::$metodo, que no existe";
                continue;
            }

            $atributos = (new ReflectionMethod($clase, $metodo))->getAttributes(Accion::class);

            if ($atributos === []) {
                $problemas[] = "$donde no declara #[Accion]";
                continue;
            }

            $accion = $atributos[0]->newInstance();

            if (!$accion->publica && trim($accion->permiso) === '') {
                $problemas[] = "$donde no dice permiso ni se declara pública";
            }
        }

        Afirma::igual([], $problemas, 'acciones mal declaradas');
    },

    'ningún permiso exigido está mal escrito' => function () use ($raiz, $tabla, $permisosDe): void {
        /** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
        $config = Nucleo\Configuracion::baseDatos($raiz);
        $bd     = new BaseDatos($config);

        $enLaTabla = array_column($bd->filas('SELECT clave FROM permiso'), 'clave');

        Afirma::cierto(count($enLaTabla) > 8, 'la tabla de permisos está cargada');

        $fantasmas = [];

        foreach ($tabla() as $ruta) {
            [$clase, $metodo] = $ruta->destino();

            if (!method_exists($clase, $metodo)) {
                continue;
            }

            foreach ((new ReflectionMethod($clase, $metodo))->getAttributes(Accion::class) as $atributo) {
                foreach ($permisosDe($atributo->newInstance()) as $permiso) {
                    if (!in_array($permiso, $enLaTabla, true)) {
                        $fantasmas[] = $ruta->metodo() . ' ' . $ruta->patron() . " exige «{$permiso}»";
                    }
                }
            }
        }

        Afirma::igual([], $fantasmas, 'permisos que ninguna fila de la tabla concede');
    },

    'los permisos que ninguna ruta exige están ahí a propósito' => function () use ($raiz, $tabla, $permisosDe): void {
        /** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
        $config = Nucleo\Configuracion::baseDatos($raiz);
        $bd     = new BaseDatos($config);

        // Un permiso que nadie exige es, casi siempre, una pantalla que se
        // quedó sin proteger o un permiso que sobró. Los que se exigen dentro
        // del código y no en la puerta de la ruta van nombrados aquí, con el
        // archivo donde se exigen. La autorización de descuentos comprueba
        // el permiso del *otro* usuario que firma, no el de la ruta/capturista.
        $aMano = [
            // El panel abre para todos; las fichas del resumen sólo con el permiso.
            'tablero_ver' => '/controladores/Web/Tablero.php',
        ];

        // Un permiso sembrado antes que su pantalla espera aquí, con la fase
        // que lo trae; **al llegar, sale de esta lista**.
        $porLlegar = [];

        $usados = [];

        foreach ($tabla() as $ruta) {
            [$clase, $metodo] = $ruta->destino();

            if (!method_exists($clase, $metodo)) {
                continue;
            }

            foreach ((new ReflectionMethod($clase, $metodo))->getAttributes(Accion::class) as $atributo) {
                foreach ($permisosDe($atributo->newInstance()) as $permiso) {
                    $usados[$permiso] = true;
                }
            }
        }

        $todos   = array_column($bd->filas('SELECT clave FROM permiso ORDER BY clave'), 'clave');
        $huerfanos = array_values(array_diff($todos, array_keys($usados), array_keys($aMano), array_keys($porLlegar)));

        Afirma::igual([], $huerfanos, 'permisos que ninguna ruta exige y que nadie explicó');

        // Y al revés: lo que ya tiene ruta no puede seguir «por llegar». Si no,
        // la lista crece y tapa para siempre al que de verdad se olvidó.
        $yaLlegaron = array_values(array_intersect(array_keys($porLlegar), array_keys($usados)));
        Afirma::igual([], $yaLlegaron, 'permisos que ya tienen ruta y siguen en la lista de por llegar');

        // Y que la lista no nombre permisos que no existen.
        Afirma::igual([], array_values(array_diff(array_keys($porLlegar), $todos)), 'permisos por llegar que no están en la tabla');

        foreach ($aMano as $permiso => $archivo) {
            Afirma::contiene(
                $permiso,
                file_get_contents($raiz . $archivo) ?: '',
                "$permiso se sigue exigiendo en " . ltrim($archivo, '/')
            );
        }
    },

    'cada árbol lleva la protección que le toca' => function () use ($arbol): void {
        // Son dos árboles con protecciones distintas, y la diferencia no es un
        // descuido: la web va con sesión en cookie, y una cookie la manda el
        // navegador sola —de ahí la marca CSRF—. La app va con token en la
        // cabecera, que nadie manda por accidente, así que ahí la marca no
        // protege de nada y lo que hace falta es que el token exista.
        $sinMarca = [];

        foreach ($arbol('web') as $ruta) {
            if ($ruta->metodo() === 'GET') {
                continue;
            }

            if (!in_array(ExigeMarca::class, $ruta->intermediarios(), true)) {
                $sinMarca[] = $ruta->metodo() . ' ' . $ruta->patron();
            }
        }

        Afirma::igual([], $sinMarca, 'rutas web que cambian algo sin marca CSRF');

        // En la app, las tres de la puerta son públicas a propósito: salud, la
        // que entrega el token, y salir —que revoca el token que traiga quien
        // llame, así que sin token no hace nada—.
        // `/cambiar-clave` se identifica con la contraseña temporal, como
        // `/entrar`: quien la tiene todavía no recibe token.
        $deLaPuerta = ['/api/v1/salud', '/api/v1/app/apk', '/api/v1/entrar', '/api/v1/salir', '/api/v1/cambiar-clave', '/api/v1/equipo', '/api/v1/equipo/entrar', '/api/v1/sucursales-publicas', '/api/v1/reservaciones', '/api/v1/redes', '/api/v1/menu-publico/{sucursal:[a-zA-Z0-9]+}'];
        $sinToken   = [];

        foreach ($arbol('api') as $ruta) {
            if (in_array($ruta->patron(), $deLaPuerta, true)) {
                continue;
            }

            if (!in_array(ExigeToken::class, $ruta->intermediarios(), true)
                && !in_array(ExigeEquipo::class, $ruta->intermediarios(), true)
                && !in_array(ExigeInstalacion::class, $ruta->intermediarios(), true)) {
                $sinToken[] = $ruta->metodo() . ' ' . $ruta->patron();
            }
        }

        Afirma::igual([], $sinToken, 'rutas de la app sin exigir token');
    },

    'ninguna acción de GET escribe' => function () use ($tabla): void {
        // Un GET que escribe es dos problemas en uno: no lleva marca CSRF
        // —porque no hace falta en las de leer— y cualquier cosa que recorra
        // enlaces, desde un antivirus hasta el navegador precargando, lo
        // dispara. El clásico es `/algo/{id}/borra` puesto como GET.
        //
        // ⚠️ Con precisión sobre lo que esta regla ve: mira **el cuerpo del
        // método**, no lo que llame dentro. No es una garantía de que un GET no
        // acabe escribiendo tres saltos más abajo; es que el error más común
        // —el UPDATE escrito ahí mismo— no pueda entrar sin que algo se ponga
        // rojo. Lo profundo lo sostienen las reglas de `ArquitecturaPrueba`.
        $escriben = [];
        $mirados  = 0;

        $senales = '/->(ejecuta|inserta)\(|\b(INSERT\s+INTO|UPDATE\s|DELETE\s+FROM)\b/i';

        foreach ($tabla() as $ruta) {
            if ($ruta->metodo() !== 'GET') {
                continue;
            }

            [$clase, $metodo] = $ruta->destino();

            if (!method_exists($clase, $metodo)) {
                continue;
            }

            $mirados++;
            $reflejo = new ReflectionMethod($clase, $metodo);
            $lineas  = file((string) $reflejo->getFileName()) ?: [];
            $cuerpo  = implode('', array_slice(
                $lineas,
                $reflejo->getStartLine() - 1,
                $reflejo->getEndLine() - $reflejo->getStartLine() + 1
            ));

            if (preg_match($senales, $cuerpo) === 1) {
                $escriben[] = $ruta->patron() . " → $clase::$metodo";
            }
        }

        Afirma::cierto($mirados >= 13, "se miraron $mirados acciones de GET");
        Afirma::igual([], $escriben, 'acciones de GET que escriben en la base');
    },
];
