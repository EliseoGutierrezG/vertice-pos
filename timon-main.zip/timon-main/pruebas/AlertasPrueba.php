<?php
declare(strict_types=1);

use Pruebas\Afirma;

/**
 * Los diálogos de El Timón (D25.2): SweetAlert2 con la disposición, los iconos y
 * el movimiento de la casa. Se prueba leyendo los archivos: el orden de carga,
 * que el bloque de estilos traiga su versión con movimiento reducido y que la
 * confirmación lleve el verbo y el tono. El aspecto se revisa con capturas.
 */

$raiz = dirname(__DIR__);
$lee  = static fn (string $ruta): string => (string) file_get_contents($raiz . '/' . $ruta);

return [
    'alertas.js se carga después de SweetAlert2 y antes de main.js y plantilla.js' => function () use ($lee): void {
        $scripts = $lee('vistas/plantilla/scripts.php');
        $swal    = strpos($scripts, 'sweetalert2.min.js');
        $propio  = strpos($scripts, '/recursos/alertas.js?v=');
        Afirma::cierto($swal !== false && $propio !== false, 'scripts.php carga SweetAlert2 y alertas.js');
        Afirma::cierto($propio > $swal, 'alertas.js va después de SweetAlert2');
        Afirma::cierto($propio < strpos($scripts, 'plantilla/main.js'), 'alertas.js va antes de main.js');
        Afirma::cierto($propio < strpos($scripts, '/recursos/plantilla.js'), 'alertas.js va antes de plantilla.js');
    },

    'alertas.js sustituye Swal por una subclase con las clases y el movimiento propios' => function () use ($lee): void {
        $js = $lee('publico/recursos/alertas.js');
        foreach ([
            'Base.mixin(', 'buttonsStyling: false', "'pb-alerta--entra'", "'pb-alerta--sale'",
            "'pb-fondo--entra'", "'pb-fondo--sale'", 'extends Mezcla', 'window.Swal = SwalPlantilla',
            "'btn btn-danger'", "'btn btn-primary'", "'btn btn-outline-secondary'",
        ] as $pieza) {
            Afirma::contiene($pieza, $js, 'alertas.js');
        }
        Afirma::falso(str_contains($js, 'toast'), 'alertas.js no usa toasts (D11)');
    },

    'el tema trae el bloque de diálogos, su fondo y la versión con movimiento reducido' => function () use ($lee): void {
        $css = $lee('publico/recursos/tema.css');
        Afirma::contiene('Diálogos (D25.2)', $css, 'tema.css');
        foreach (['.pb-fondo--entra', '@keyframes pb-alerta-entra', '@keyframes pb-alerta-sale', '@keyframes pb-palomita'] as $pieza) {
            Afirma::contiene($pieza, $css, 'tema.css');
        }
        // Al sustituir `swal2-backdrop-show`, el fondo lo pone la clase propia.
        Afirma::cierto(
            (bool) preg_match('/\.pb-fondo--entra\s*\{[^}]*background-color/', $css),
            'el fondo propio define su color'
        );
        Afirma::cierto(
            (bool) preg_match('/@media \(prefers-reduced-motion: reduce\)\s*\{[^@]*pb-alerta--entra/', $css),
            'los diálogos tienen versión con movimiento reducido'
        );
        Afirma::falso(str_contains($css, 'swal2-toast'), 'no quedan reglas de toast');
    },

    'la confirmación repite el verbo del botón y se pone roja en lo destructivo' => function () use ($lee): void {
        $js = $lee('publico/recursos/plantilla.js');
        Afirma::contiene('confirmButtonText: verbo', $js, 'plantilla.js');
        Afirma::contiene("tono: esPeligro(forma, disparador) ? 'peligro' : undefined", $js, 'plantilla.js');
        Afirma::contiene('focusCancel: true', $js, 'plantilla.js');
        Afirma::contiene("'Volver'", $js, 'plantilla.js');
        Afirma::falso((bool) preg_match('/toast\s*:\s*true/', $js), 'plantilla.js no usa toasts (D11)');
    },
];
