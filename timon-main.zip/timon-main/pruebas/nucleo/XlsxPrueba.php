<?php
declare(strict_types=1);

use Nucleo\Exporta\Xlsx;
use Pruebas\Afirma;

/**
 * «Exportar XLS» (homologación D18, D20): el XLSX propio.
 *
 * Como con el CSV, lo que importa no es el formato sino que **el archivo diga
 * lo que la pantalla dijo**: que un importe sume, que una fecha ordene, que una
 * clave con ceros no pierda sus ceros y que un nombre no se convierta en
 * fórmula. Se abre el zip con lo que trae PHP, sin `ext-zip`, igual que se
 * escribió.
 */

/** @return array<string,string> cada parte del zip por su nombre */
$abre = static function (string $zip): array {
    $partes = [];
    $fin = strrpos($zip, "PK\x05\x06");
    Afirma::cierto($fin !== false, 'falta el cierre del directorio central');

    $cierre  = unpack('Vfirma/vdisco/vdiscoDir/vaqui/vtotal/Vtamano/Vdesde/vcomentario', substr($zip, (int) $fin, 22));
    $central = substr($zip, $cierre['desde'], $cierre['tamano']);
    $p = 0;

    for ($i = 0; $i < $cierre['total']; $i++) {
        $e = unpack('Vfirma/vhecho/vpide/vbandera/vmetodo/vhora/vfecha/Vcrc/Vcomprimido/Voriginal/vnombre/vextra/vcomentario/vdisco/vinternos/Vexternos/Vdesde', substr($central, $p, 46));
        Afirma::igual(0x02014b50, $e['firma'], 'firma del directorio central');
        $nombre = substr($central, $p + 46, $e['nombre']);
        $p += 46 + $e['nombre'] + $e['extra'] + $e['comentario'];

        $local = unpack('Vfirma/vpide/vbandera/vmetodo/vhora/vfecha/Vcrc/Vcomprimido/Voriginal/vnombre/vextra', substr($zip, $e['desde'], 30));
        Afirma::igual(0x04034b50, $local['firma'], 'firma local de ' . $nombre);
        $datos = gzinflate(substr($zip, $e['desde'] + 30 + $local['nombre'] + $local['extra'], $e['comprimido']));
        Afirma::cierto($datos !== false, 'no se pudo descomprimir ' . $nombre);
        Afirma::igual($e['crc'], crc32((string) $datos), 'el CRC de ' . $nombre);
        Afirma::igual($e['original'], strlen((string) $datos), 'el tamaño de ' . $nombre);

        $partes[$nombre] = (string) $datos;
    }

    return $partes;
};

$columnas = [
    ['titulo' => 'Cliente'],
    ['titulo' => 'Clave', 'tipo' => Xlsx::CLAVE],
    ['titulo' => 'Piezas', 'tipo' => Xlsx::ENTERO],
    ['titulo' => 'Importe', 'tipo' => Xlsx::IMPORTE],
    ['titulo' => 'Fecha', 'tipo' => Xlsx::FECHA],
    ['titulo' => 'Registrado', 'tipo' => Xlsx::FECHAHORA],
];

return [
    'es un zip que se abre, con las partes que Excel busca' => function () use ($abre, $columnas): void {
        $partes = $abre(Xlsx::de('Clientes', $columnas, [['Tienda', '001', 3, '10.50', '2026-11-05', '2026-11-05 08:30:00']]));

        foreach (['[Content_Types].xml', '_rels/.rels', 'xl/workbook.xml', 'xl/_rels/workbook.xml.rels', 'xl/styles.xml', 'xl/worksheets/sheet1.xml'] as $parte) {
            Afirma::cierto(isset($partes[$parte]), 'falta ' . $parte);
            Afirma::cierto(simplexml_load_string($partes[$parte]) !== false, $parte . ' no es XML válido');
        }

        Afirma::contiene('name="Clientes"', $partes['xl/workbook.xml'], 'el nombre de la hoja');
    },

    'los números son números y las fechas son fechas' => function () use ($abre, $columnas): void {
        $hoja = $abre(Xlsx::de('Clientes', $columnas, [['Tienda', '001', 3, '1234.50', '2026-11-05', '2026-11-05 12:00:00']]))['xl/worksheets/sheet1.xml'];

        Afirma::contiene('<c r="C2" s="3"><v>3</v></c>', $hoja, 'el entero');
        Afirma::contiene('<c r="D2" s="5"><v>1234.5</v></c>', $hoja, 'el importe');
        // 05/11/2026 es el día 46331 de Excel; las 12:00 son medio día.
        Afirma::contiene('<c r="E2" s="6"><v>46331</v></c>', $hoja, 'la fecha');
        Afirma::contiene('<c r="F2" s="7"><v>46331.5</v></c>', $hoja, 'la fecha y hora');
    },

    'los formatos son los de la guía' => function () use ($abre, $columnas): void {
        $estilos = $abre(Xlsx::de('Clientes', $columnas, []))['xl/styles.xml'];

        Afirma::contiene('formatCode="#,##0.00"', $estilos, 'el importe');
        Afirma::contiene('formatCode="dd/mm/yyyy"', $estilos, 'la fecha');
        Afirma::contiene('formatCode="dd/mm/yyyy hh:mm"', $estilos, 'la fecha y hora');
    },

    'una clave con ceros sigue siendo texto' => function () use ($abre, $columnas): void {
        $hoja = $abre(Xlsx::de('Clientes', $columnas, [['Tienda', '00123', 1, '1', '2026-11-05', '']]))['xl/worksheets/sheet1.xml'];

        Afirma::contiene('<c r="B2" t="inlineStr" s="2"><is><t xml:space="preserve">00123</t></is></c>', $hoja);
    },

    'ningún texto se evalúa como fórmula' => function () use ($abre, $columnas): void {
        // En el CSV hubo que anteponer un apóstrofo; aquí el texto va como
        // `inlineStr`, que Excel nunca calcula, y sale tal cual.
        $hoja = $abre(Xlsx::de('Clientes', $columnas, [['=1+1', '', '', '', '', ''], ['- sin ruta -', '', '', '', '', '']]))['xl/worksheets/sheet1.xml'];

        Afirma::contiene('<t xml:space="preserve">=1+1</t>', $hoja, 'el nombre «=1+1»');
        Afirma::contiene('<t xml:space="preserve">- sin ruta -</t>', $hoja, 'el nombre «- sin ruta -»');
        Afirma::falso(str_contains($hoja, '<f>'), 'apareció una fórmula');
        Afirma::falso(str_contains($hoja, "'="), 'se agregó un apóstrofo que no hace falta');
    },

    'los acentos y los signos se escapan' => function () use ($abre, $columnas): void {
        $hoja = $abre(Xlsx::de('Clientes', $columnas, [['Abarrotes «Doña Ñeli» & <hijos>', '', '', '', '', '']]))['xl/worksheets/sheet1.xml'];

        Afirma::contiene('Abarrotes «Doña Ñeli» &amp; &lt;hijos&gt;', $hoja);
        Afirma::cierto(simplexml_load_string($hoja) !== false, 'la hoja dejó de ser XML');
    },

    'el encabezado queda fijo y con filtro' => function () use ($abre, $columnas): void {
        $hoja = $abre(Xlsx::de('Clientes', $columnas, [['A', '', '', '', '', ''], ['B', '', '', '', '', '']]))['xl/worksheets/sheet1.xml'];

        Afirma::contiene('state="frozen"', $hoja, 'el encabezado fijo');
        Afirma::contiene('<autoFilter ref="A1:F3"/>', $hoja, 'el autofiltro');
        Afirma::contiene('<c r="A1" t="inlineStr" s="1">', $hoja, 'el estilo del encabezado');
    },

    'una celda vacía no se escribe, ni como cero' => function () use ($abre, $columnas): void {
        $hoja = $abre(Xlsx::de('Clientes', $columnas, [['Tienda', '', null, '', '', '']]))['xl/worksheets/sheet1.xml'];

        Afirma::falso(str_contains($hoja, 'r="C2"'), 'la cantidad vacía salió como celda');
    },

    'el nombre del archivo lleva la pantalla y la fecha' => function (): void {
        Afirma::igual('rutas_2026-11-05.xlsx', Xlsx::archivo('Rutas', '2026-11-05'));
        Afirma::igual('kardex_2026-11-01_2026-11-30.xlsx', Xlsx::archivo('Kárdex', '2026-11-01', '2026-11-30'));
        Afirma::igual('precios_por_oficina_' . date('Y-m-d') . '.xlsx', Xlsx::archivo('Precios por oficina'));
    },

    'el nombre de la hoja respeta lo que Excel admite' => function () use ($abre): void {
        $libro = $abre(Xlsx::de('Ventas: 01/11 [todas] y algo más que pasa de treinta y uno', [['titulo' => 'A']], []))['xl/workbook.xml'];

        Afirma::falso((bool) preg_match('/name="[^"]*[:\/\[\]]/', $libro), 'quedó un signo que Excel rechaza');
        preg_match('/name="([^"]*)"/', $libro, $m);
        Afirma::cierto(mb_strlen(html_entity_decode($m[1] ?? '')) <= 31, 'el nombre pasa de 31 caracteres');
    },
];
