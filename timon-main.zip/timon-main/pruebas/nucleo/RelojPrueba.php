<?php
declare(strict_types=1);

use Nucleo\BaseDatos;
use Nucleo\Reloj;
use Pruebas\Afirma;

/**
 * El reloj del negocio, con las dos mitades a la vez.
 *
 * Lo que se comprueba aquí no es que PHP sepa la hora: es que **PHP y MariaDB
 * contesten el mismo día**. Por eso las pruebas van contra la base de verdad.
 *
 * Medido antes del arreglo: `BaseDatos` le ponía al motor «-06:00» escrito a
 * mano mientras PHP tomaba la zona de `config/app.php` —y en los guiones de la
 * línea de comandos, de ninguna parte: UTC—. Los dos datos decían lo mismo por
 * casualidad, no por construcción.
 */

$raiz = dirname(__DIR__, 2);

/** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
$config = Nucleo\Configuracion::baseDatos($raiz);
$bd     = new BaseDatos($config);

return [
    'los dos relojes contestan el mismo día' => function () use ($bd): void {
        // Si esto falla, el catálogo muestra el precio de un día y la venta
        // cobra el de otro. Es el defecto que el arreglo cierra.
        Afirma::igual(
            date('Y-m-d'),
            (string) $bd->valor('SELECT CURDATE()'),
            'CURDATE() contra date()'
        );
    },

    'la sesión del motor va en el desplazamiento de PHP' => function () use ($bd): void {
        Afirma::igual(
            date('P'),
            (string) $bd->valor('SELECT @@session.time_zone'),
            'la zona de la sesión'
        );
    },

    'NOW() y PHP dan la misma hora' => function () use ($bd): void {
        $delMotor = strtotime((string) $bd->valor('SELECT NOW()'));
        Afirma::cierto(
            abs($delMotor - time()) <= 2,
            'los dos relojes van a ' . abs($delMotor - time()) . ' segundos'
        );
    },

    'si PHP cambia de zona, el motor la sigue' => function () use ($config): void {
        // La prueba de que el desplazamiento se calcula y no está escrito: se
        // mueve PHP a una zona distinta y la conexión nueva tiene que nacer ahí.
        // Se devuelve la zona a su sitio pase lo que pase: si se queda movida,
        // las pruebas que siguen corren en otro día.
        $antes = date_default_timezone_get();

        try {
            Reloj::fijaLaZonaConNombre('UTC');
            $otra = new BaseDatos($config);

            Afirma::igual('+00:00', (string) $otra->valor('SELECT @@session.time_zone'), 'la zona de la sesión');
            Afirma::igual(date('Y-m-d'), (string) $otra->valor('SELECT CURDATE()'), 'y el día sigue siendo el mismo');
        } finally {
            Reloj::fijaLaZonaConNombre($antes);
        }
    },

    'la zona se lee de la configuración, no del servidor' => function () use ($raiz): void {
        /** @var array<string,mixed> $app */
        $app   = Nucleo\Configuracion::aplicacion($raiz);
        $antes = date_default_timezone_get();

        try {
            Reloj::fijaLaZonaConNombre('UTC');
            Reloj::fijaLaZona($raiz);

            Afirma::igual((string) $app['zona_horaria'], date_default_timezone_get(), 'la zona');
        } finally {
            Reloj::fijaLaZonaConNombre($antes);
        }
    },

    'una zona que no existe se rechaza con nombre y todo' => function (): void {
        $error = Afirma::lanza(
            RuntimeException::class,
            fn () => Reloj::fijaLaZonaConNombre('America/Ciudad_Inventada')
        );

        Afirma::contiene('America/Ciudad_Inventada', $error->getMessage(), 'el mensaje dice cuál');
    },

    'el desplazamiento tiene la forma que el motor entiende' => function (): void {
        Afirma::cierto(
            preg_match('/^[+-]\d{2}:\d{2}$/', Reloj::desplazamiento()) === 1,
            'el desplazamiento es «' . Reloj::desplazamiento() . '»'
        );
    },
];
