<?php
declare(strict_types=1);

use Nucleo\Atributos\Accion;
use Nucleo\BaseDatos;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;
use Nucleo\Middleware\ExigeEnvioUnico;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Pruebas\Afirma;

/**
 * El envío único del panel (`ExigeEnvioUnico`, esquema/062).
 *
 * Lo que tiene que pasar: el mismo envío dos veces hace el trabajo **una** vez
 * y contesta lo mismo; un error suelta la llave para corregir y reintentar; la
 * llave es de quien la mandó y para la ruta que la mandó; y de la respuesta
 * solo se guarda a dónde fue y el aviso, nunca el cuerpo.
 */

final class ControladorEnvioUnicoPrueba
{
    #[Accion('personal_admin')]
    public function libre(Peticion $p): Respuesta
    {
        return Respuesta::json(['llegó' => true]);
    }

    #[Accion('personal_admin', unaVez: true)]
    public function unaVez(Peticion $p): Respuesta
    {
        return Respuesta::json(['llegó' => true]);
    }
}

$config = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd     = new BaseDatos($config);

Pruebas\Semilla::borraUsuarios($bd, 'envio.unico.');
$idUno  = Pruebas\Semilla::usuario($bd, 'envio.unico.uno', 'administrador', 'contraseña-larga-e');
$idOtro = Pruebas\Semilla::usuario($bd, 'envio.unico.otro', 'administrador', 'contraseña-larga-e');

$intermediario = function (int $idUsuario) use ($bd): ExigeEnvioUnico {
    $identidad = new Identidad($bd);
    $identidad->establece($idUsuario);

    return new ExigeEnvioUnico($bd, $identidad, new Sesion(false));
};

/** @param array<string,string> $datos */
$peticion = function (string $ruta, string $destino, array $datos = [], bool $json = true, string $metodo = 'POST'): Peticion {
    $_SERVER['REQUEST_METHOD'] = $metodo;
    $_SERVER['REQUEST_URI']    = $ruta;
    $_SERVER['REMOTE_ADDR']    = '127.0.0.1';
    unset($_SERVER['HTTP_X_ENVIO']);
    if ($json) {
        $_SERVER['HTTP_ACCEPT'] = 'application/json';
    } else {
        unset($_SERVER['HTTP_ACCEPT']);
    }
    $_GET  = [];
    $_POST = $datos;

    return Peticion::desdeGlobales()->conDestino([ControladorEnvioUnicoPrueba::class, $destino]);
};

$llave = static fn (): string => sprintf(
    '%08x-%04x-4%03x-%04x-%012x',
    random_int(0, 0xffffffff),
    random_int(0, 0xffff),
    random_int(0, 0xfff),
    random_int(0x8000, 0xbfff),
    random_int(0, 0xffffffffffff)
);

/**
 * Un trabajo que cuenta cuántas veces corrió y deja su aviso en la sesión,
 * como `Controlador::hecho()`.
 */
$trabajo = function (int &$veces, string $destino = '/pedidos?ver=7', string $aviso = 'Pedido guardado.'): callable {
    return function (Peticion $p) use (&$veces, $destino, $aviso): Respuesta {
        $veces++;
        (new Sesion(false))->avisa($aviso);

        return $p->esperaJson()
            ? Respuesta::json(['redirige' => $destino, 'clave' => 'secreto-que-no-se-guarda'])
            : Respuesta::redireccion($destino);
    };
};

$limpia = static function () use ($bd, $idUno, $idOtro): void {
    $bd->ejecuta('DELETE FROM envio_panel WHERE id_usuario IN (?, ?)', [$idUno, $idOtro]);
    $_SESSION = [];
};

return [
    'lo que no cambia nada pasa sin llave' => function () use ($intermediario, $peticion, $idUno): void {
        $respuesta = $intermediario($idUno)->maneja(
            $peticion('/pedidos', 'unaVez', [], true, 'GET'),
            static fn (): Respuesta => Respuesta::json(['llegó' => true])
        );

        Afirma::igual(200, $respuesta->estado());
    },

    'sin llave, una acción libre corre y una de una sola vez se rechaza' => function () use ($intermediario, $peticion, $idUno): void {
        $veces = 0;
        $cuenta = function () use (&$veces): Respuesta { $veces++; return Respuesta::json(['redirige' => '/']); };

        $intermediario($idUno)->maneja($peticion('/pedidos', 'libre'), $cuenta);
        Afirma::igual(1, $veces, 'la libre corre');

        $error = Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez'), $cuenta));
        Afirma::igual(422, $error->getCode(), 'sin llave, 422');
        Afirma::igual(1, $veces, 'y el trabajo no corrió');
    },

    'una llave mal formada se rechaza' => function () use ($intermediario, $peticion, $idUno): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idUno)->maneja(
            $peticion('/pedidos', 'libre', ['_envio' => 'no-es-un-uuid']),
            static fn (): Respuesta => Respuesta::json([])
        ));

        Afirma::igual(422, $error->getCode());
    },

    'el mismo envío dos veces hace el trabajo una vez y contesta lo mismo' => function () use ($intermediario, $peticion, $llave, $trabajo, $idUno, $bd, $limpia): void {
        $veces = 0;
        $k     = $llave();

        $primera = $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]), $trabajo($veces));
        $_SESSION = [];
        $segunda = $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]), $trabajo($veces));

        Afirma::igual(1, $veces, 'el trabajo corrió una sola vez');
        Afirma::igual(200, $segunda->estado());
        Afirma::igual('/pedidos?ver=7', json_decode($segunda->cuerpo(), true)['datos']['redirige'] ?? null, 'el mismo destino');
        Afirma::igual('Pedido guardado.', $_SESSION['aviso']['texto'] ?? null, 'y el mismo aviso para la pantalla siguiente');
        Afirma::igual(200, $primera->estado());

        $fila = $bd->fila('SELECT * FROM envio_panel WHERE llave = ?', [$k]);
        Afirma::igual('hecho', $fila['estado'] ?? null);
        Afirma::igual('POST /pedidos', $fila['ruta'] ?? null);
        Afirma::falso(str_contains((string) json_encode($fila), 'secreto-que-no-se-guarda'), 'el cuerpo no se guarda');
        $limpia();
    },

    'sin JavaScript la repetición redirige al mismo destino' => function () use ($intermediario, $peticion, $llave, $trabajo, $idUno, $limpia): void {
        $veces = 0;
        $k     = $llave();

        $intermediario($idUno)->maneja($peticion('/personal/4/usuario/clave', 'unaVez', ['_envio' => $k], false), $trabajo($veces, '/personal?ver=4'));
        $segunda = $intermediario($idUno)->maneja($peticion('/personal/4/usuario/clave', 'unaVez', ['_envio' => $k], false), $trabajo($veces, '/personal?ver=4'));

        Afirma::igual(1, $veces, 'no se genera otra contraseña');
        Afirma::igual(302, $segunda->estado());
        Afirma::igual('/personal?ver=4', $segunda->cabeceras()['Location'] ?? null);
        $limpia();
    },

    'la cabecera X-Envio vale igual que el campo' => function () use ($intermediario, $peticion, $llave, $trabajo, $idUno, $limpia): void {
        $veces = 0;
        $k     = $llave();

        $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]), $trabajo($veces));
        $p = $peticion('/pedidos', 'unaVez');
        $_SERVER['HTTP_X_ENVIO'] = strtoupper($k);
        $p = Peticion::desdeGlobales()->conDestino([ControladorEnvioUnicoPrueba::class, 'unaVez']);
        $intermediario($idUno)->maneja($p, $trabajo($veces));
        unset($_SERVER['HTTP_X_ENVIO']);

        Afirma::igual(1, $veces);
        $limpia();
    },

    'la llave es de quien la mandó y de su ruta' => function () use ($intermediario, $peticion, $llave, $trabajo, $idUno, $idOtro, $limpia): void {
        $veces = 0;
        $k     = $llave();
        $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]), $trabajo($veces));

        $deOtro = Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idOtro)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]), $trabajo($veces)));
        Afirma::igual(409, $deOtro->getCode(), 'de otro usuario');

        $deOtraRuta = Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idUno)->maneja($peticion('/compras', 'unaVez', ['_envio' => $k]), $trabajo($veces)));
        Afirma::igual(409, $deOtraRuta->getCode(), 'de otra ruta');
        Afirma::igual(1, $veces, 'ninguna de las dos corrió');
        $limpia();
    },

    'mientras el primero no termina, el segundo espera' => function () use ($intermediario, $peticion, $llave, $trabajo, $idUno, $bd, $limpia): void {
        $veces = 0;
        $k     = $llave();
        $bd->ejecuta('INSERT INTO envio_panel (llave, id_usuario, ruta) VALUES (?, ?, ?)', [$k, $idUno, 'POST /pedidos']);

        $error = Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]), $trabajo($veces)));

        Afirma::igual(409, $error->getCode());
        Afirma::contiene('Espere', $error->getMessage());
        Afirma::igual(0, $veces);
        $limpia();
    },

    'dos procesos con la misma llave ejecutan el efecto una sola vez' => function () use ($intermediario, $peticion, $llave, $idUno, $limpia): void {
        $k = $llave();
        $marca = tempnam(sys_get_temp_dir(), 'pb-envio-');
        Afirma::cierto(is_string($marca));
        $proceso = proc_open(
            [PHP_BINARY, dirname(__DIR__) . '/fixtures/envio-concurrente.php', (string)$idUno, $k, $marca],
            [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']],
            $tubos
        );
        Afirma::cierto(is_resource($proceso), 'iniciar el segundo proceso');
        fclose($tubos[0]);
        try {
            $limite = microtime(true) + 8;
            do {
                clearstatcache(true, $marca);
                if (filesize($marca) > 0) break;
                usleep(25000);
            } while (microtime(true) < $limite);
            Afirma::cierto(filesize($marca) > 0, 'el primer proceso reservó la llave');
            $error = Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idUno)->maneja(
                $peticion('/pedidos', 'unaVez', ['_envio' => $k]),
                static function () use ($marca): Respuesta {
                    file_put_contents($marca, "dos\n", FILE_APPEND | LOCK_EX);
                    return Respuesta::json(['redirige' => '/pedidos']);
                }
            ));
            Afirma::igual(409, $error->estado());
        } finally {
            $salida = stream_get_contents($tubos[1]);
            $errores = stream_get_contents($tubos[2]);
            fclose($tubos[1]); fclose($tubos[2]);
            $codigo = proc_close($proceso);
            $efecto = file_get_contents($marca);
            unlink($marca);
            $limpia();
        }
        Afirma::igual(0, $codigo, 'el primer proceso terminó: ' . $salida . $errores);
        Afirma::igual("una\n", $efecto);
    },

    'un error suelta la llave y el reintento corre' => function () use ($intermediario, $peticion, $llave, $trabajo, $idUno, $bd, $limpia): void {
        $veces = 0;
        $k     = $llave();

        Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idUno)->maneja(
            $peticion('/pedidos', 'unaVez', ['_envio' => $k]),
            static function (): Respuesta { throw Errores::datosInvalidos(['cliente' => 'Seleccione el cliente']); }
        ));
        Afirma::nulo($bd->fila('SELECT llave FROM envio_panel WHERE llave = ?', [$k]), 'la excepción soltó la llave');

        $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]), static fn (): Respuesta => Respuesta::jsonError(409, 'conflicto', 'Ya cambió'));
        Afirma::nulo($bd->fila('SELECT llave FROM envio_panel WHERE llave = ?', [$k]), 'una respuesta de error también la suelta');

        $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]), $trabajo($veces));
        Afirma::igual(1, $veces, 'corregido, el reintento con la misma llave corre');
        $limpia();
    },

    'un fallo inesperado conserva la reserva y evita repetir efectos' => function () use ($intermediario, $peticion, $llave, $idUno, $bd, $limpia): void {
        $k = $llave();
        $veces = 0;
        Afirma::lanza(RuntimeException::class, function () use ($intermediario, $idUno, $peticion, $k, &$veces): void {
            $intermediario($idUno)->maneja(
                $peticion('/pedidos', 'unaVez', ['_envio' => $k]),
                function () use (&$veces): Respuesta { $veces++; throw new RuntimeException('fallo después del efecto'); }
            );
        });
        Afirma::igual('en_curso', $bd->fila('SELECT estado FROM envio_panel WHERE llave = ?', [$k])['estado']);
        Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idUno)->maneja(
            $peticion('/pedidos', 'unaVez', ['_envio' => $k]),
            function () use (&$veces): Respuesta { $veces++; return Respuesta::json([]); }
        ));
        Afirma::igual(1, $veces);
        $limpia();
    },

    'una respuesta 500 conserva la reserva' => function () use ($intermediario, $peticion, $llave, $idUno, $bd, $limpia): void {
        $k = $llave();
        $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]),
            static fn (): Respuesta => Respuesta::jsonError(500, 'error', 'No confirmado'));
        Afirma::igual('en_curso', $bd->fila('SELECT estado FROM envio_panel WHERE llave = ?', [$k])['estado']);
        $limpia();
    },

    'sin destino que repetir, la repetición dice que ya se guardó' => function () use ($intermediario, $peticion, $llave, $idUno, $limpia): void {
        $veces = 0;
        $k     = $llave();
        $sinDestino = function () use (&$veces): Respuesta { $veces++; return Respuesta::json(['total' => 3]); };

        $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]), $sinDestino);
        $error = Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idUno)->maneja($peticion('/pedidos', 'unaVez', ['_envio' => $k]), $sinDestino));

        Afirma::igual(409, $error->getCode());
        Afirma::igual(1, $veces);
        $limpia();
    },

    'un destino que no cabe no se recorta: la repetición dice que ya se guardó' => function () use ($intermediario, $peticion, $llave, $idUno, $bd, $limpia): void {
        // Como el WhatsApp del ticket: un enlace largo recortado abriría un mensaje a medias.
        $largo = 'https://wa.me/?text=' . str_repeat('Ticket%20', 40);
        foreach ([true, false] as $json) {
            $veces = 0;
            $k     = $llave();
            $trabajo = function () use (&$veces, $largo, $json): Respuesta {
                $veces++;
                return $json ? Respuesta::json(['redirige' => $largo]) : Respuesta::redireccion($largo, 303);
            };

            $primera = $intermediario($idUno)->maneja($peticion('/pedidos/7/ticket-publico', 'unaVez', ['_envio' => $k], $json), $trabajo);
            Afirma::igual($json ? 200 : 303, $primera->estado(), 'la primera vez sí va');
            Afirma::igual(null, $bd->fila('SELECT redirige FROM envio_panel WHERE llave = ?', [$k])['redirige'], 'no se guarda recortado');

            $error = Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idUno)->maneja($peticion('/pedidos/7/ticket-publico', 'unaVez', ['_envio' => $k], $json), $trabajo));
            Afirma::igual(409, $error->getCode());
            Afirma::contiene('Ya se guardó', $error->getMessage());
            Afirma::igual(1, $veces, 'y no genera otro enlace');
        }
        $limpia();
    },

    'cada acción marcada exige llave y repite sin ejecutar otra vez' => function () use ($intermediario, $peticion, $llave, $idUno, $limpia): void {
        $acciones = [];
        foreach (glob(dirname(__DIR__, 2) . '/controladores/Web/*.php') as $archivo) {
            $clase = 'Controladores\\Web\\' . basename($archivo, '.php');
            if (!class_exists($clase)) continue;
            foreach ((new ReflectionClass($clase))->getMethods(ReflectionMethod::IS_PUBLIC) as $metodo) {
                $atributos = $metodo->getAttributes(Accion::class);
                if ($atributos !== [] && $atributos[0]->newInstance()->unaVez) $acciones[] = [$clase, $metodo->getName()];
            }
        }
        Afirma::cierto(count($acciones) >= 8, 'encontrar las acciones protegidas');
        try {
            foreach ($acciones as $indice => [$clase, $metodo]) {
                $ruta = '/prueba-envio/' . $indice;
                $destino = static fn (array $datos): Peticion => $peticion($ruta, 'libre', $datos)->conDestino([$clase, $metodo]);
                $cuenta = 0;
                $trabajo = static function () use (&$cuenta): Respuesta {
                    $cuenta++;
                    return Respuesta::json(['redirige' => '/prueba-envio']);
                };
                $error = Afirma::lanza(ErrorHttp::class, fn () => $intermediario($idUno)->maneja($destino([]), $trabajo));
                Afirma::igual(422, $error->estado(), $clase . '::' . $metodo);
                $k = $llave();
                $primera = $intermediario($idUno)->maneja($destino(['_envio' => $k]), $trabajo);
                $repetida = $intermediario($idUno)->maneja($destino(['_envio' => $k]), $trabajo);
                Afirma::igual(1, $cuenta, $clase . '::' . $metodo);
                Afirma::igual($primera->cuerpo(), $repetida->cuerpo(), $clase . '::' . $metodo);
            }
        } finally {
            $limpia();
        }
    },

    'las acciones que duplican en el panel exigen la llave' => function (): void {
        $deben = [
            [Controladores\Web\PersonalWeb::class, 'crea'],
            [Controladores\Web\PersonalWeb::class, 'restableceClave'],
            [Controladores\Web\PersonalWeb::class, 'reactivaUsuario'],
            [Controladores\Web\Sucursales::class, 'crea'],
            [Controladores\Web\DispositivosWeb::class, 'notifica'],
            [Controladores\Web\PrivacidadWeb::class, 'registra'],
            [Controladores\Web\SeguridadWeb::class, 'registraRevision'],
        ];
        $faltan = [];
        foreach ($deben as [$clase, $metodo]) {
            $atributos = (new ReflectionMethod($clase, $metodo))->getAttributes(Accion::class);
            if ($atributos === [] || !$atributos[0]->newInstance()->unaVez) {
                $faltan[] = $clase . '::' . $metodo;
            }
        }

        Afirma::igual([], $faltan);
    },

    'la prueba limpia lo suyo' => function () use ($bd, $limpia): void {
        $limpia();
        Pruebas\Semilla::borraUsuarios($bd, 'envio.unico.');
        Afirma::igual(0, (int) $bd->valor("SELECT COUNT(*) FROM usuario WHERE usuario LIKE 'envio.unico.%'"));
    },
];
