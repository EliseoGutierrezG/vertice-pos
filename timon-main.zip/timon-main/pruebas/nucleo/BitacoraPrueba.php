<?php
declare(strict_types=1);

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Registro;
use Pruebas\Afirma;

/**
 * La bitácora: quién, cuándo, qué había antes y qué quedó.
 *
 * Es la respuesta 9.3 del cuestionario. Si esto no funciona, la pregunta
 * "¿quién movió esto?" se contesta con suposiciones.
 */

/** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
$config   = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd       = new BaseDatos($config);
$carpetaRegistro = sys_get_temp_dir() . '/timon-pruebas';
$registro = new Registro($carpetaRegistro, false);
$bitacora = new Bitacora($bd, $registro);

// Fuerza los dos errores reintentables que puede devolver MariaDB al escribir
// la bitácora. El disparador vive únicamente durante este grupo de pruebas.
$bd->ejecuta('DROP TRIGGER IF EXISTS prueba_bitacora_falla');
$bd->ejecuta(
    "CREATE TRIGGER prueba_bitacora_falla BEFORE INSERT ON bitacora
     FOR EACH ROW
     BEGIN
       IF NEW.modulo = 'prueba_1213' THEN
         SIGNAL SQLSTATE '40001' SET MYSQL_ERRNO = 1213, MESSAGE_TEXT = 'interbloqueo provocado por la prueba';
       ELSEIF NEW.modulo = 'prueba_1205' THEN
         SIGNAL SQLSTATE 'HY000' SET MYSQL_ERRNO = 1205, MESSAGE_TEXT = 'espera provocada por la prueba';
       END IF;
     END"
);
register_shutdown_function(static function () use ($bd): void {
    $bd->ejecuta('DROP TRIGGER IF EXISTS prueba_bitacora_falla');
});

/** Borra lo que estas pruebas escriben, y sólo eso. */
$limpia = fn () => $bd->ejecuta("DELETE FROM bitacora WHERE modulo = 'prueba'");

return [
    'un cambio queda registrado con su módulo y su acción' => function () use ($bd, $bitacora, $limpia): void {
        $limpia();
        $bitacora->registra('prueba', 'crea', 'producto', 7);

        $fila = $bd->fila("SELECT * FROM bitacora WHERE modulo = 'prueba'");

        Afirma::noNulo($fila, 'el apunte');
        Afirma::igual('crea', $fila['accion'], 'la acción');
        Afirma::igual('producto', $fila['entidad'], 'la entidad');
        Afirma::igual(7, (int) $fila['id_entidad'], 'el id de la entidad');
        $limpia();
    },

    'guarda qué había antes y qué quedó después' => function () use ($bd, $bitacora, $limpia): void {
        $limpia();
        $bitacora->registra(
            'prueba',
            'edita',
            'precio',
            3,
            antes:   ['neto' => '25.0000'],
            despues: ['neto' => '27.5000']
        );

        $fila = $bd->fila("SELECT antes, despues FROM bitacora WHERE modulo = 'prueba'");

        Afirma::igual(['neto' => '25.0000'], json_decode((string) $fila['antes'], true), 'el antes');
        Afirma::igual(['neto' => '27.5000'], json_decode((string) $fila['despues'], true), 'el después');
        $limpia();
    },

    'el momento se llena solo' => function () use ($bd, $bitacora, $limpia): void {
        $limpia();
        $bitacora->registra('prueba', 'crea');

        $momento = (string) $bd->valor("SELECT momento FROM bitacora WHERE modulo = 'prueba'");

        Afirma::cierto($momento !== '', 'el momento');
        Afirma::igual(date('Y-m-d'), substr($momento, 0, 10), 'la fecha de hoy');
        $limpia();
    },

    'guarda la dirección desde la que se hizo' => function () use ($bd, $bitacora, $limpia): void {
        $limpia();
        $bitacora->registra('prueba', 'entra', ip: '192.0.2.10');

        Afirma::igual(
            '192.0.2.10',
            $bd->valor("SELECT ip FROM bitacora WHERE modulo = 'prueba'"),
            'la ip'
        );
        $limpia();
    },

    'los acentos del apunte se conservan' => function () use ($bd, $bitacora, $limpia): void {
        $limpia();
        $bitacora->registra('prueba', 'crea', 'perfil', 1, despues: ['nombre' => 'Dueño']);

        $despues = json_decode(
            (string) $bd->valor("SELECT despues FROM bitacora WHERE modulo = 'prueba'"),
            true
        );

        Afirma::igual('Dueño', $despues['nombre'], 'el nombre');
        $limpia();
    },

    'el apunte se deshace junto con el cambio que describe' => function () use ($bd, $bitacora, $limpia): void {
        $limpia();

        try {
            $bd->transaccion(function () use ($bitacora): void {
                $bitacora->registra('prueba', 'crea', 'producto', 99);
                throw new RuntimeException('el cambio no cuajó');
            });
        } catch (RuntimeException $e) {
            // Se esperaba.
        }

        Afirma::igual(
            0,
            (int) $bd->valor("SELECT COUNT(*) FROM bitacora WHERE modulo = 'prueba'"),
            'apuntes de un cambio que nunca ocurrió'
        );
    },

    'una bitácora que falla fuera de transacción se propaga' => function () use ($bd, $registro): void {
        // Módulo de 41 caracteres en una columna de 40: el motor lo rechaza.
        $bitacora = new Bitacora($bd, $registro);

        Afirma::lanza(
            Throwable::class,
            fn () => $bitacora->registra(str_repeat('x', 41), 'crea'),
            'la falla de auditoría'
        );
    },

    'una bitácora que falla revierte la operación completa' => function () use ($bd, $registro, $limpia): void {
        $limpia();
        $bitacora = new Bitacora($bd, $registro);

        Afirma::lanza(Throwable::class, function () use ($bd, $bitacora): void {
            $bd->transaccion(function () use ($bd, $bitacora): void {
                $bd->ejecuta(
                    "INSERT INTO bitacora (modulo, accion, entidad) VALUES ('prueba', 'antes', 'operacion')"
                );
                $bitacora->registra(str_repeat('x', 41), 'crea');
            });
        }, 'la transacción sin auditoría');

        Afirma::igual(
            0,
            (int) $bd->valor("SELECT COUNT(*) FROM bitacora WHERE modulo = 'prueba'"),
            'quedó parte de la operación'
        );
    },

    'un timeout 1205 de bitácora fuera de transacción se conserva como reintentable' =>
    function () use ($bitacora, $carpetaRegistro): void {
        $archivo = $carpetaRegistro . '/' . date('Y-m-d') . '.log';
        @unlink($archivo);

        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => $bitacora->registra('prueba_1205', 'secreto-que-no-debe-aparecer'),
            'el timeout de auditoría'
        );

        Afirma::igual(409, $error->estado(), 'el estado reintentable');
        Afirma::contiene('en curso', $error->getMessage(), 'la explicación');

        $registro = file_get_contents($archivo) ?: '';
        Afirma::contiene('No se pudo escribir en la bitácora', $registro, 'la falla técnica quedó registrada');
        Afirma::falso(str_contains($registro, 'secreto-que-no-debe-aparecer'), 'el registro no repite argumentos');
    },

    'un interbloqueo 1213 de bitácora revierte la transacción y conserva la causa' =>
    function () use ($bd, $bitacora, $limpia): void {
        $limpia();

        $error = Afirma::lanza(ErrorHttp::class, function () use ($bd, $bitacora): void {
            $bd->transaccion(function () use ($bd, $bitacora): void {
                $bd->ejecuta(
                    "INSERT INTO bitacora (modulo, accion, entidad) VALUES ('prueba', 'antes', 'operacion')"
                );
                $bitacora->registra('prueba_1213', 'crea');
            });
        }, 'el interbloqueo de auditoría');

        Afirma::igual(409, $error->estado(), 'el estado reintentable');
        Afirma::contiene('Intente de nuevo', $error->getMessage(), 'la explicación original');
        Afirma::igual(
            0,
            (int) $bd->valor("SELECT COUNT(*) FROM bitacora WHERE modulo = 'prueba'"),
            'la operación quedó completamente revertida'
        );
    },
];
