<?php
declare(strict_types=1);

use Nucleo\Atributos\Accion;
use Nucleo\BaseDatos;
use Nucleo\Csrf;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Nucleo\Middleware\ExigeMarca;
use Nucleo\Middleware\ExigePermiso;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Pruebas\Afirma;

/**
 * Los atributos leídos por reflexión, y la marca CSRF.
 *
 * El punto de la fase: **una acción sin atributo se rechaza**. Olvidar
 * declarar el permiso no puede traducirse en "entonces cualquiera puede".
 */

final class ControladorDePrueba
{
    #[Accion('seguridad_admin')]
    public function conPermiso(Peticion $p): Respuesta
    {
        return Respuesta::json(['llegó' => true]);
    }

    #[Accion('seguridad_admin,avisos_ver')]
    public function conPermisoAlternativo(Peticion $p): Respuesta
    {
        return Respuesta::json(['llegó' => true]);
    }

    #[Accion(publica: true)]
    public function publica(Peticion $p): Respuesta
    {
        return Respuesta::json(['llegó' => true]);
    }

    #[Accion]
    public function atributoVacio(Peticion $p): Respuesta
    {
        return Respuesta::json(['llegó' => true]);
    }

    // A propósito sin atributo: tiene que fallar cerrado.
    public function olvidada(Peticion $p): Respuesta
    {
        return Respuesta::json(['llegó' => true]);
    }
}

/**
 * Identidades de verdad, contra la base.
 *
 * Se pensó en una identidad falsa, pero `Identidad` es final a propósito y
 * aflojarlo para una prueba es cambiar el diseño por comodidad. Además, así
 * se comprueba lo que de veras va a correr.
 */
/** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
$config   = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd       = new BaseDatos($config);
$usuarios = new Modelos\Usuarios($bd);

Pruebas\Semilla::borraUsuarios($bd, 'permiso.');

// Los nombres de variable se quedan: «dueño» es quien puede todo y
// «vendedor» quien no. En la v2 son el administrador y un preventa.
$idDueno    = Pruebas\Semilla::usuario($bd, 'permiso.dueno', 'administrador', 'contraseña-larga-p');
$idVendedor = Pruebas\Semilla::usuario($bd, 'permiso.vendedor', 'gerente', 'contraseña-larga-p');

$identidadDe = function (int $id) use ($bd): Identidad {
    $identidad = new Identidad($bd);
    $identidad->establece($id);

    return $identidad;
};

$peticion = function (string $metodo, string $metodoDestino): Peticion {
    $_SERVER['REQUEST_METHOD'] = $metodo;
    $_SERVER['REQUEST_URI']    = '/lo-que-sea';
    $_SERVER['REMOTE_ADDR']    = '127.0.0.1';
    $_GET = [];
    $_POST = [];

    return Peticion::desdeGlobales()->conDestino([ControladorDePrueba::class, $metodoDestino]);
};

$sigue = static fn (Peticion $p): Respuesta => Respuesta::json(['llegó' => true]);

return [
    'una acción sin atributo #[Accion] se rechaza' => function () use ($peticion, $sigue, $identidadDe, $idDueno, $idVendedor): void {
        $intermediario = new ExigePermiso($identidadDe($idDueno));

        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => $intermediario->maneja($peticion('GET', 'olvidada'), $sigue)
        );

        Afirma::igual(403, $error->getCode(), 'el código');
        Afirma::contiene('#[Accion]', $error->getMessage(), 'el mensaje dice qué falta');
    },

    'un atributo que no dice qué permiso exige también se rechaza' => function () use ($peticion, $sigue, $identidadDe, $idDueno, $idVendedor): void {
        $intermediario = new ExigePermiso($identidadDe($idDueno));

        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => $intermediario->maneja($peticion('GET', 'atributoVacio'), $sigue)
        );

        Afirma::igual(403, $error->getCode(), 'el código');
    },

    'con el permiso declarado, la acción corre' => function () use ($peticion, $sigue, $identidadDe, $idDueno, $idVendedor): void {
        $intermediario = new ExigePermiso($identidadDe($idDueno));

        $respuesta = $intermediario->maneja($peticion('GET', 'conPermiso'), $sigue);

        Afirma::igual(200, $respuesta->estado(), 'el estado');
    },

    'sin el permiso, la acción no corre' => function () use ($peticion, $sigue, $identidadDe, $idDueno, $idVendedor): void {
        $intermediario = new ExigePermiso($identidadDe($idVendedor));

        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => $intermediario->maneja($peticion('GET', 'conPermiso'), $sigue)
        );

        Afirma::igual(403, $error->getCode(), 'el código');
        Afirma::igual('seguridad_admin', $error->detalle(), 'el registro sabe qué permiso falta');
        Afirma::falso(str_contains($error->getMessage(), 'seguridad_admin'), 'la pantalla no enseña la clave interna');
    },

    'con cualquiera de los permisos alternativos, la acción corre' => function () use ($peticion, $sigue, $identidadDe, $idVendedor): void {
        $intermediario = new ExigePermiso($identidadDe($idVendedor));

        $respuesta = $intermediario->maneja($peticion('GET', 'conPermisoAlternativo'), $sigue);

        Afirma::igual(200, $respuesta->estado(), 'el estado');
    },

    'una acción marcada como pública corre sin permisos' => function () use ($peticion, $sigue, $identidadDe, $idDueno, $idVendedor): void {
        $intermediario = new ExigePermiso($identidadDe($idVendedor));

        $respuesta = $intermediario->maneja($peticion('GET', 'publica'), $sigue);

        Afirma::igual(200, $respuesta->estado(), 'el estado');
    },

    'una ruta sin destino declarado se rechaza' => function () use ($sigue, $identidadDe, $idDueno): void {
        $_SERVER['REQUEST_METHOD'] = 'GET';
        $_SERVER['REQUEST_URI']    = '/lo-que-sea';
        $_SERVER['REMOTE_ADDR']    = '127.0.0.1';
        $_GET = [];

        $intermediario = new ExigePermiso($identidadDe($idDueno));

        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => $intermediario->maneja(Peticion::desdeGlobales(), $sigue)
        );

        Afirma::igual(403, $error->getCode(), 'el código');
    },

    'se limpia lo que la prueba creó' => function () use ($bd): void {
        Pruebas\Semilla::borraUsuarios($bd, 'permiso.');

        Afirma::igual(
            0,
            (int) $bd->valor("SELECT COUNT(*) FROM usuario WHERE usuario LIKE 'permiso.%'"),
            'los usuarios de prueba'
        );
    },
];
