<?php
declare(strict_types=1);

use Modelos\Parametros;
use Nucleo\BaseDatos;
use Nucleo\Identidad;
use Nucleo\Middleware\ExigeSesion;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Pruebas\Afirma;

/**
 * La sesión que lleva mucho tiempo quieta.
 *
 * ⚠️ **No se cerraba nunca.** Medido contra el sistema corriendo, envejeciendo
 * el archivo de sesión: quieta treinta días seguía contestando 200.
 * `session.gc_maxlifetime` es un barrido de basura que corre una de cada mil
 * veces, no una caducidad.
 *
 * Y donde duele es el mostrador: una computadora de un local, que no se apaga ni
 * cambia de navegador. El siguiente turno queda dentro de la sesión del anterior,
 * vende, cobra, y la bitácora lo firma con el nombre del otro.
 *
 * Aquí se comprueba el tope; que el sello se escriba de verdad en una sesión de
 * navegador lo comprueba `pruebas/humo-identidad.sh`.
 */

$raiz = dirname(__DIR__, 2);
$bd   = new BaseDatos(Nucleo\Configuracion::baseDatos($raiz));

/** Una identidad de verdad: el intermediario la establece, así que tiene que existir. */
$usuarioPrueba = 'prbsesion.identidad';
$limpiaUsuario = static function () use ($bd, $usuarioPrueba): void {
    Pruebas\Semilla::borraUsuarios($bd, $usuarioPrueba);
};
$limpiaUsuario();
$alguien = Pruebas\Semilla::usuario($bd, $usuarioPrueba, 'mesero', 'contraseña-larga-sesion');

$peticion = static function (bool $json = false): Peticion {
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['REQUEST_URI']    = '/clientes';
    $_SERVER['REMOTE_ADDR']    = '127.0.0.1';
    $_GET  = [];
    $_POST = [];
    unset($_SERVER['HTTP_ACCEPT']);

    if ($json) {
        $_SERVER['HTTP_ACCEPT'] = 'application/json';
    }

    return Peticion::desdeGlobales();
};

$sigue = static fn (Peticion $p): Respuesta => Respuesta::json(['llegó' => true]);

/**
 * Pone el tope en el catálogo de verdad, no en un doble.
 *
 * `Parametros` es `final` y no se desfinaliza por una prueba. Usar el catálogo
 * real tiene además su propio valor: comprueba que la clave que lee el
 * intermediario es **la misma** que trae `esquema/006`, que es un acoplamiento
 * que nadie más vigila. Un renglón con `vigente_desde` de hoy gana al del
 * esquema, y al final se deja el renglón de hoy como estaba: si un guion puso
 * el suyo hoy (el `048`, el 2026-10-06), la prueba no se lo lleva.
 */
const CLAVE_TOPE = 'minutos_sesion_inactiva';

$deHoy = $bd->fila('SELECT valor, descripcion, vigente_hasta FROM parametro WHERE clave = ? AND vigente_desde = CURDATE()', [CLAVE_TOPE]);
$vigenteAntes = (string) $bd->valor(
    'SELECT valor FROM parametro WHERE clave = ? AND vigente_desde <= CURDATE() AND (vigente_hasta IS NULL OR vigente_hasta >= CURDATE())
     ORDER BY vigente_desde DESC LIMIT 1',
    [CLAVE_TOPE]
);
$restauraTope = static function () use ($bd, $deHoy): void {
    $bd->ejecuta('DELETE FROM parametro WHERE clave = ? AND vigente_desde = CURDATE()', [CLAVE_TOPE]);
    if ($deHoy !== null) {
        $bd->ejecuta(
            'INSERT INTO parametro (clave, valor, descripcion, vigente_desde, vigente_hasta) VALUES (?, ?, ?, CURDATE(), ?)',
            [CLAVE_TOPE, $deHoy['valor'], $deHoy['descripcion'], $deHoy['vigente_hasta']]
        );
    }
};
register_shutdown_function($restauraTope);

$topeDe = static function (int $minutos) use ($bd): Parametros {
    $bd->ejecuta('DELETE FROM parametro WHERE clave = ? AND vigente_desde = CURDATE()', [CLAVE_TOPE]);
    $bd->ejecuta(
        'INSERT INTO parametro (clave, valor, descripcion, vigente_desde) VALUES (?, ?, ?, CURDATE())',
        [CLAVE_TOPE, (string) $minutos, 'Prueba de la sesión quieta']
    );

    // Una instancia nueva por caso: `Parametros` recuerda lo leído.
    return new Parametros($bd);
};


$conSesion = static function (int $minutos, ?int $selloHace) use ($bd, $topeDe, $alguien): array {
    $sesion = new Sesion(soloHttps: false);
    $sesion->pon('id_usuario', $alguien);

    if ($selloHace !== null) {
        $sesion->pon('ultimo_uso', time() - $selloHace);
    } else {
        $sesion->quita('ultimo_uso');
    }

    return [$sesion, new ExigeSesion($sesion, new Identidad($bd), $topeDe($minutos))];
};

$usuarioSensible = 'prbsesion.sensible';
Pruebas\Semilla::borraUsuarios($bd, $usuarioSensible);
$sensible = Pruebas\Semilla::usuario($bd, $usuarioSensible, 'almacen', 'contraseña-larga-sensible');
register_shutdown_function(static fn () => Pruebas\Semilla::borraUsuarios($bd, $usuarioSensible));

return [
    // Un turno largo de restaurante: 12 horas desde la entrada (esquema 006).
    'pasadas las 12 horas de entrar, a la calle aunque siga en uso' => function () use ($conSesion, $peticion, $sigue): void {
        [$sesion, $exige] = $conSesion(1440, 60);
        $sesion->pon(ExigeSesion::ENTRADA, time() - 12 * 3600 - 60);

        Afirma::igual(302, $exige->maneja($peticion(), $sigue)->estado(), 'el estado');
        Afirma::contiene('12 horas', (string) ($sesion->aviso()['texto'] ?? ''), 'el motivo');
    },

    'once horas después de entrar sigue adentro' => function () use ($conSesion, $peticion, $sigue): void {
        [$sesion, $exige] = $conSesion(1440, 60);
        $sesion->pon(ExigeSesion::ENTRADA, time() - 11 * 3600);

        Afirma::igual(200, $exige->maneja($peticion(), $sigue)->estado(), 'el estado');
    },

    'un puesto sensible sale a los 60 minutos quieto y otro no' => function () use ($bd, $conSesion, $topeDe, $peticion, $sigue, $sensible): void {
        [, $exige] = $conSesion(120, 61 * 60);
        Afirma::igual(200, $exige->maneja($peticion(), $sigue)->estado(), 'el de mesero');

        $sesion = new Sesion(soloHttps: false);
        $sesion->pon('id_usuario', $sensible);
        $sesion->pon('ultimo_uso', time() - 59 * 60);
        $sesion->pon(ExigeSesion::ENTRADA, time() - 3600);
        $exige = new ExigeSesion($sesion, new Identidad($bd), $topeDe(120));
        Afirma::igual(200, $exige->maneja($peticion(), $sigue)->estado(), 'el de almacén, quieto 59 minutos');

        $sesion->pon('ultimo_uso', time() - 61 * 60);
        $exige = new ExigeSesion($sesion, new Identidad($bd), $topeDe(120));
        Afirma::igual(302, $exige->maneja($peticion(), $sigue)->estado(), 'el de almacén, quieto 61 minutos');
    },

    // §S: el aviso pregunta cuánto queda, y preguntar no puede alargar la sesión.
    'consultar el estado de la sesión no cuenta como uso' => function () use ($conSesion, $sigue): void {
        [$sesion, $exige] = $conSesion(120, 600);
        $antes = (int) $sesion->saca('ultimo_uso');
        $_SERVER['REQUEST_METHOD'] = 'GET';
        $_SERVER['REQUEST_URI']    = '/sesion/estado';
        $_SERVER['HTTP_ACCEPT']    = 'application/json';
        $_GET = [];

        Afirma::igual(200, $exige->maneja(Peticion::desdeGlobales(), $sigue)->estado(), 'el estado');
        Afirma::igual($antes, (int) $sesion->saca('ultimo_uso'), 'el sello de uso');
        unset($_SERVER['HTTP_ACCEPT']);
    },

    'lo que queda es el tope más cercano' => function () use ($bd, $topeDe, $sensible): void {
        $sesion = new Sesion(soloHttps: false);
        $sesion->pon('id_usuario', $sensible);
        $sesion->pon(ExigeSesion::ENTRADA, time() - 3600);
        $sesion->pon(ExigeSesion::SELLO, time() - 600);
        $identidad = new Identidad($bd);
        $identidad->establece($sensible);

        // Almacén: 60 minutos sin uso ganan a las 12 horas de turno.
        $queda = (new Nucleo\VidaSesion($sesion, $identidad, $topeDe(1440)))->restante();
        Afirma::cierto($queda !== null && abs($queda - 50 * 60) <= 2, 'quedan 50 minutos');

        // Con uso reciente y casi al final de la jornada, gana la jornada.
        $sesion->pon(ExigeSesion::ENTRADA, time() - 12 * 3600 + 120);
        $sesion->pon(ExigeSesion::SELLO, time());
        $queda = (new Nucleo\VidaSesion($sesion, $identidad, $topeDe(1440)))->restante();
        Afirma::cierto($queda !== null && abs($queda - 120) <= 2, 'quedan 2 minutos');
    },

    'a la entrada solo se vuelve a una pantalla de este sitio' => function (): void {
        $valida = [Controladores\Web\Entrada::class, 'vueltaValida'];
        Afirma::igual('/pedidos?fecha=2026-11-05', $valida('/pedidos?fecha=2026-11-05'), 'una pantalla con su consulta');
        Afirma::igual('cerrar', $valida('cerrar'), 'la pestaña que solo se cierra');
        foreach (['//otro.sitio', '/\\otro.sitio', 'https://otro.sitio', 'pedidos', '/entrar', '/salir', '/sesion/estado', '/a b', ''] as $mala) {
            Afirma::nulo($valida($mala), 'rechaza ' . $mala);
        }
        Afirma::igual('/panel', Controladores\Web\Entrada::destino(null), 'sin vuelta, al tablero');
        Afirma::igual('/sesion/lista', Controladores\Web\Entrada::destino('cerrar'), 'la pestaña de vuelta');
    },

    'la recarga sola del Tablero no cuenta como uso' => function () use ($conSesion, $peticion, $sigue): void {
        [$sesion, $exige] = $conSesion(120, 60);
        $antes = (int) $sesion->saca('ultimo_uso');
        $peticion();
        $_GET = ['sondeo' => '1'];
        $p = Peticion::desdeGlobales();
        Afirma::igual(200, $exige->maneja($p, $sigue)->estado(), 'el estado');
        Afirma::igual($antes, (int) $sesion->saca('ultimo_uso'), 'el sello de uso');
        $_GET = [];
    },

    'una sesión en uso sigue adentro' => function () use ($conSesion, $peticion, $sigue): void {
        [, $exige] = $conSesion(120, 60);

        Afirma::igual(200, $exige->maneja($peticion(), $sigue)->estado(), 'el estado');
    },

    'un minuto antes del tope, adentro todavía' => function () use ($conSesion, $peticion, $sigue): void {
        [, $exige] = $conSesion(120, 120 * 60 - 60);

        Afirma::igual(200, $exige->maneja($peticion(), $sigue)->estado(), 'el estado');
    },

    'pasado el tope, a la calle' => function () use ($conSesion, $peticion, $sigue): void {
        [$sesion, $exige] = $conSesion(120, 120 * 60 + 60);

        $respuesta = $exige->maneja($peticion(), $sigue);
        Afirma::igual(302, $respuesta->estado(), 'el estado');
        // §S.9: la entrada sabe a qué pantalla volver.
        Afirma::igual('/entrar?vuelta=%2Fclientes', $respuesta->cabeceras()['Location'] ?? '', 'a dónde');
        Afirma::nulo($sesion->saca('id_usuario'), 'lo que queda de la identidad en la sesión');
    },

    'y se le dice por qué, que si no parece que el sistema se cayó' => function () use ($conSesion, $peticion, $sigue): void {
        [$sesion, $exige] = $conSesion(120, 999999);
        $exige->maneja($peticion(), $sigue);

        $aviso = $sesion->aviso();

        Afirma::noNulo($aviso, 'el aviso');
        Afirma::contiene('vencida', $aviso['texto'] ?? '', 'el texto del aviso');
        Afirma::igual('mal', $aviso['tono'] ?? '', 'el tono');
    },

    'a quien pide JSON se le dice 401, no una redirección que no sabe leer' => function () use ($conSesion, $peticion, $sigue): void {
        [, $exige] = $conSesion(120, 999999);

        $error = Afirma::lanza(
            \Nucleo\Errores\ErrorHttp::class,
            fn () => $exige->maneja($peticion(json: true), $sigue)
        );

        Afirma::igual(401, $error->estado(), 'el estado');
        Afirma::igual('Su sesión terminó.', $error->getMessage(), 'el mensaje que muestra la pantalla');
    },

    // ⚠️ Bitácora 97: dar de baja a alguien con la sesión abierta dejaba esa
    // computadora en «401 · Entre al sistema» sin formulario —la entrada
    // ve un `id_usuario` y manda al tablero, y el tablero lo rechaza—, y nadie
    // más podía entrar en ella hasta que venciera la sesión: un día entero.
    'una cuenta dada de baja a media sesión se vacía y va a la entrada' => function () use ($bd, $topeDe, $peticion, $sigue): void {
        $baja = Pruebas\Semilla::usuario($bd, 'prbsesion.baja', 'almacen', 'contraseña-larga-sesion');
        try {
            $sesion = new Sesion(soloHttps: false);
            $sesion->pon('id_usuario', $baja);
            $sesion->pon('ultimo_uso', time());
            $bd->ejecuta('UPDATE usuario SET id_estatus = 3, sesion_version = sesion_version + 1 WHERE id = ?', [$baja]);

            $respuesta = (new ExigeSesion($sesion, new Identidad($bd), $topeDe(120)))->maneja($peticion(), $sigue);

            Afirma::igual(302, $respuesta->estado(), 'el estado');
            Afirma::igual('/entrar?vuelta=%2Fclientes', $respuesta->cabeceras()['Location'] ?? '', 'a dónde');
            Afirma::nulo($sesion->saca('id_usuario'), 'lo que queda de la identidad en la sesión');
            Afirma::contiene('inactiva', $sesion->aviso()['texto'] ?? '', 'el aviso');
        } finally {
            Pruebas\Semilla::borraUsuarios($bd, 'prbsesion.baja');
        }
    },

    'cada petición refresca el sello: trabajar no echa a nadie' => function () use ($conSesion, $peticion, $sigue): void {
        [$sesion, $exige] = $conSesion(120, 119 * 60);
        $exige->maneja($peticion(), $sigue);

        $sello = $sesion->saca('ultimo_uso');

        Afirma::cierto(is_int($sello) && time() - $sello < 5, 'el sello quedó recién puesto');
    },

    'una sesión sin sello no se echa: sería un susto al desplegar' => function () use ($conSesion, $peticion, $sigue): void {
        [$sesion, $exige] = $conSesion(120, null);

        Afirma::igual(200, $exige->maneja($peticion(), $sigue)->estado(), 'el estado');
        Afirma::cierto(is_int($sesion->saca('ultimo_uso')), 'y ya quedó con sello');
    },

    'un cero la deja abierta, porque eso también se decide a propósito' => function () use ($conSesion, $peticion, $sigue): void {
        [, $exige] = $conSesion(0, 999999);

        Afirma::igual(200, $exige->maneja($peticion(), $sigue)->estado(), 'el estado');
    },

    'cambiar la versión revoca una sesión ya emitida' => function () use ($bd, $topeDe, $alguien, $peticion, $sigue): void {
        $sesion = new Sesion(soloHttps: false);
        $version = (int) $bd->valor('SELECT sesion_version FROM usuario WHERE id=?', [$alguien]);
        $sesion->pon('id_usuario', $alguien);
        $sesion->pon('sesion_version', $version);
        $sesion->pon('ultimo_uso', time());
        $bd->ejecuta('UPDATE usuario SET sesion_version=sesion_version+1 WHERE id=?', [$alguien]);
        $exige = new ExigeSesion($sesion, new Identidad($bd), $topeDe(120));

        $respuesta = $exige->maneja($peticion(), $sigue);
        Afirma::igual(302, $respuesta->estado());
        Afirma::nulo($sesion->saca('id_usuario'));
        Afirma::contiene('cerrada', (string) ($sesion->aviso()['texto'] ?? ''));
    },

    'el tope que probamos se va, y queda el que había' => function () use ($bd, $limpiaUsuario, $restauraTope, $vigenteAntes): void {
        $restauraTope();

        Afirma::igual(
            $vigenteAntes,
            (string) $bd->valor(
                'SELECT valor FROM parametro WHERE clave = ? AND vigente_desde <= CURDATE() AND (vigente_hasta IS NULL OR vigente_hasta >= CURDATE())
                 ORDER BY vigente_desde DESC LIMIT 1',
                [CLAVE_TOPE]
            ),
            'el tope que queda vigente'
        );
        $limpiaUsuario();
    },

    'el esquema deja la sesión quieta en medio día' => function () use ($bd): void {
        Afirma::igual('720', (string) $bd->valor(
            "SELECT valor FROM parametro WHERE clave = ? AND vigente_desde = '2026-01-01'",
            [CLAVE_TOPE]
        ));
    },
];
