<?php
declare(strict_types=1);

use Nucleo\AvisoOperativo;
use Nucleo\TareaProgramada;
use Pruebas\Afirma;

$raiz = sys_get_temp_dir() . '/app-tarea-' . bin2hex(random_bytes(4));
mkdir($raiz . '/registros', 0700, true);
register_shutdown_function(static function () use ($raiz): void {
    $iterador = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($raiz, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($iterador as $archivo) {
        $archivo->isDir() ? @rmdir($archivo->getPathname()) : @unlink($archivo->getPathname());
    }
    @rmdir($raiz);
});
$umbrales = ['espacio_minimo_mb' => 100, 'registros_maximo_mb' => 1];
$tareas = new TareaProgramada($raiz, $raiz . '/registros', $umbrales);

return [
    'la tarea conserva su código de salida y su salida' => function () use ($tareas): void {
        $r = $tareas->corre([PHP_BINARY, '-r', 'echo "renglón uno\n"; fwrite(STDERR, "error visible\n"); exit(3);']);
        Afirma::igual(3, $r['codigo']);
        Afirma::cierto(str_contains($r['salida'], 'renglón uno'));
        Afirma::cierto(str_contains($r['salida'], 'error visible'), 'la salida de error también llega al aviso');
    },
    'el estado recuerda la última corrida buena aunque la siguiente falle' => function () use ($tareas, $raiz): void {
        $bien = $tareas->corre([PHP_BINARY, '-r', 'exit(0);']);
        $tareas->guardaEstado('respaldo', $bien, []);
        $mal = $tareas->corre([PHP_BINARY, '-r', 'exit(1);']);
        $tareas->guardaEstado('respaldo', $mal, ['algo']);
        $estado = json_decode((string) file_get_contents($raiz . '/almacenamiento/tareas/respaldo.json'), true);
        Afirma::igual(1, $estado['codigo']);
        Afirma::igual($bien['fin'], $estado['ultima_buena']);
        Afirma::igual(['algo'], $estado['avisos']);
    },
    'poco disco y registros grandes producen avisos' => function () use ($tareas, $raiz): void {
        Afirma::igual([], $tareas->revisaHospedaje(500 * 1048576.0));
        $avisos = $tareas->revisaHospedaje(50 * 1048576.0);
        Afirma::igual(1, count($avisos));
        Afirma::cierto(str_contains($avisos[0], 'Quedan 50 MB'), $avisos[0]);
        file_put_contents($raiz . '/registros/enorme.log', str_repeat('x', 2 * 1048576));
        $avisos = $tareas->revisaHospedaje(500 * 1048576.0);
        Afirma::cierto(str_contains($avisos[0] ?? '', 'registros ocupan 2 MB'), $avisos[0] ?? 'sin aviso');
        unlink($raiz . '/registros/enorme.log');
    },
    'el aviso lleva la cola de la salida y no más' => function (): void {
        $salida = implode("\n", array_map(static fn (int $i): string => 'línea ' . $i, range(1, 100)));
        $cuerpo = TareaProgramada::cuerpo('respaldo', ['codigo' => 1, 'salida' => $salida, 'inicio' => 'a', 'fin' => 'b', 'segundos' => 1.0], ['poco disco']);
        Afirma::cierto(str_contains($cuerpo, 'línea 100'));
        Afirma::falso(str_contains($cuerpo, "línea 60\n"));
        Afirma::cierto(str_contains($cuerpo, '- poco disco'));
        Afirma::cierto(str_contains($cuerpo, 'Código de salida: 1'));
    },
    'el transporte archivo deja el aviso sin saltos en el asunto' => function () use ($raiz): void {
        $aviso = new AvisoOperativo(['correo' => 'a@b.test', 'remitente' => 'c@b.test', 'transporte' => 'archivo'], $raiz . '/alertas');
        $ruta = $aviso->envia("Falló\r\nBcc: intruso@x.test", 'cuerpo');
        $texto = (string) file_get_contents($ruta);
        Afirma::cierto(str_contains($texto, 'Asunto: Falló Bcc: intruso@x.test'));
        Afirma::falso(str_contains($texto, "\nBcc:"));
    },
    'un correo inválido no se intenta y el aviso queda en archivo' => function () use ($raiz): void {
        $aviso = new AvisoOperativo(['correo' => 'no-es-correo', 'remitente' => 'c@b.test', 'transporte' => 'mail'], $raiz . '/alertas-mal');
        Afirma::lanza(\RuntimeException::class, fn () => $aviso->envia('Falló', 'cuerpo'));
        Afirma::igual(1, count(glob($raiz . '/alertas-mal/*.txt') ?: []));
    },
];
