<?php
declare(strict_types=1);

use Pruebas\Afirma;

/**
 * `pb_campo`, el campo de todos los formularios.
 *
 * Las dos cosas que sostiene esta prueba salieron de la auditoría de interfaz
 * del 2026-10-06 (bitácora 95) y fallaban sin que nada se rompiera a la vista:
 * una etiqueta que enfocaba el campo equivocado y un monto con centavos que el
 * navegador rechazaba.
 */

require_once dirname(__DIR__, 2) . '/vistas/partes/piezas.php';

return [
    'el título de la pantalla es su h1, con el aspecto del h2 de RhToroV1, y lleva subtítulo' => function (): void {
        // Homologación §2: `module-heading` → título + `p`. Desde el 2026-11-09 el
        // título es el h1 de la página: sin él no hay dónde empieza (barrido web).
        $pantalla = pb_modulo('bi-box', 'Inventario', 'Existencias por sucursal.');

        Afirma::contiene('<h1>Inventario</h1><p>Existencias por sucursal.</p>', $pantalla, 'título y subtítulo');
    },

    'una pantalla sin subtítulo no se pinta fuera de producción' => function (): void {
        $error = null;
        try {
            pb_modulo('bi-box', 'Inventario', '');
        } catch (\RuntimeException $e) {
            $error = $e->getMessage();
        }

        Afirma::cierto($error !== null, 'se pintó sin subtítulo');
    },

    'Ver y Actualizar abren el modal con su modo y su enlace propio' => function (): void {
        $ver = pb_accion_modal('modalRuta', 'ver', 7, '/rutas/7', 'Ver ruta', ['nombre' => 'Ruta «101»']);
        $act = pb_accion_modal('modalRuta', 'actualizar', 7, '/rutas/7', 'Actualizar ruta', []);

        Afirma::contiene('href="?ver=7"', $ver, 'el enlace para otra pestaña');
        Afirma::contiene('data-pb-modo="ver"', $ver);
        Afirma::contiene('fa-newspaper-o', $ver, 'el icono de Ver');
        Afirma::contiene('data-pb-modo="actualizar"', $act);
        Afirma::contiene('fa-edit', $act, 'el icono de Actualizar');
        Afirma::contiene('Ruta «101»', html_entity_decode($ver), 'el registro viaja escapado');
    },

    'Dar de baja es un enlace, no un formulario en la fila' => function (): void {
        $baja = pb_dar_baja('/rutas', 7, true, 'Ruta 101', '/rutas');
        $alta = pb_dar_baja('/rutas', 7, false, 'Ruta 101');

        Afirma::falso(str_contains($baja, '<form'), 'quedó un formulario');
        Afirma::contiene('data-pb-post="/rutas/7/baja"', $baja);
        Afirma::contiene('fa-close', $baja, 'el icono de cierre');
        Afirma::contiene('¿Dar de baja «Ruta 101»?', html_entity_decode($baja), 'la confirmación nombra el registro');
        Afirma::contiene('data-pb-post="/rutas/7/reactiva"', $alta);
    },

    'el modal no se cierra solo, no lleva Cancelar y marca lo opcional' => function (): void {
        $html = pb_modal('modalPrueba', 'Agregar ruta', '/rutas', '')
            . pb_campo('prueba_nombre', 'Nombre', ['requerido' => true])
            . pb_campo('prueba_notas', 'Notas')
            . pb_modal_fin();

        Afirma::contiene('data-bs-backdrop="static"', $html, 'clic fuera');
        Afirma::contiene('data-bs-keyboard="false"', $html, 'Esc');
        Afirma::contiene('aria-labelledby="modalPrueba-titulo"', $html);
        Afirma::contiene('data-pb-instruccion', $html, 'la instrucción del encabezado');
        Afirma::falso(str_contains($html, 'Cancelar'), 'quedó Cancelar');
        Afirma::contiene('fa-save', $html, 'Guardar');
        Afirma::contiene('Notas <span class="text-secondary">(Opcional)</span>', $html, 'el campo opcional');
        Afirma::falso(str_contains(explode('prueba_notas', $html)[0], '(Opcional)'), 'el obligatorio salió como opcional');
    },

    'el filtro dice Buscar y Limpiar filtro, y el conteo, N registros' => function (): void {
        $fin = pb_filtros_fin('/rutas');

        Afirma::contiene('fa-search', $fin);
        Afirma::contiene('Buscar', $fin);
        Afirma::contiene('Limpiar filtro', $fin);
        Afirma::contiene('1 registro<', pb_registros(1));
        Afirma::contiene('1,250 registros', pb_registros(1250));
    },

    'el mismo nombre dos veces en la página no repite el id' => function (): void {
        // Los filtros y el modal de alta comparten `id_oficina` en pedidos:
        // con dos `c-id_oficina`, la etiqueta del modal enfocaba el filtro.
        $filtro = pb_campo('prueba_oficina', 'Oficina');
        $modal  = pb_campo('prueba_oficina', 'Oficina de precio');

        Afirma::contiene('id="c-prueba_oficina"', $filtro, 'el primero');
        Afirma::contiene('id="c-prueba_oficina-2"', $modal, 'el segundo');
        Afirma::contiene('for="c-prueba_oficina-2"', $modal, 'la etiqueta del segundo');
    },

    'los nombres de HTML valen como los propios' => function (): void {
        // `'step' => '0.01'` se ignoraba: el efectivo de la liquidación salía
        // sin `step`, el navegador ponía 1 y rechazaba «150.50».
        $campo = pb_campo('prueba_efectivo', 'Efectivo', [
            'tipo' => 'numero', 'min' => '0', 'step' => '0.01', 'maxlength' => '12', 'placeholder' => '0.00',
        ]);

        Afirma::contiene('type="number"', $campo, 'el tipo «numero»');
        Afirma::contiene('step="0.01"', $campo, 'el paso');
        Afirma::contiene('min="0"', $campo, 'el mínimo');
        Afirma::contiene('placeholder="0.00"', $campo, 'el marcador');
    },

    'el nombre propio gana si vienen los dos' => function (): void {
        $campo = pb_campo('prueba_paso', 'Cantidad', ['tipo' => 'number', 'paso' => '0.001', 'step' => '1']);

        Afirma::contiene('step="0.001"', $campo);
    },

    'las cantidades se leen sin ceros de sobra y sin redondear' => function (): void {
        // Revisión de flujos (bitácora 96): la base guarda tres decimales y la
        // pantalla mostraba «12.000» en el pedido, la carga y el inventario.
        Afirma::igual('102', pb_cantidad('102.000'));
        Afirma::igual('1,500.5', pb_cantidad('1500.500'));
        Afirma::igual('0.25', pb_cantidad('0.250'));
        Afirma::igual('-12', pb_cantidad('-12.000'), 'la merma');
        Afirma::igual('0.125', pb_cantidad('0.125'), 'sin redondeo');
        Afirma::igual('', pb_cantidad(null));
    },

    'las fechas se leen como en mostrador' => function (): void {
        Afirma::igual('07 oct 2026, 13:45', pb_fecha('2026-10-07 13:45:12'));
        Afirma::igual('07 oct 2026', pb_fecha('2026-10-07'));
        Afirma::igual('', pb_fecha(null), 'vacío queda vacío');
        Afirma::igual('Sin fecha', pb_fecha('Sin fecha'), 'lo que no es fecha se queda');
    },
];
