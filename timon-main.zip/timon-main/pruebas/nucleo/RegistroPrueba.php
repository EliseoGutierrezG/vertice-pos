<?php
declare(strict_types=1);

use Nucleo\Registro;
use Pruebas\Afirma;

/**
 * El registro de errores, que es el archivo que nadie mira hasta que hace falta.
 *
 * Lo que se comprueba aquí es la frontera que su propio comentario declara —lo
 * de dentro puede llevar traza, lo que sale por HTTP no— y una que faltaba: **la
 * traza dice por dónde pasó, no con qué**.
 *
 * Medido antes del arreglo: `getTraceAsString()` escribe los argumentos de cada
 * llamada, los de texto con sus primeros quince caracteres. Una contraseña de
 * diecisiete quedaba escrita como `'Timon2026segu...'` y una de seis, entera.
 * Por esos marcos pasan los tres secretos del sistema: la contraseña, el token
 * de la API y el teléfono.
 *
 * Cada prueba escribe en su propia carpeta temporal y la borra.
 */

/** Alguien recibe un secreto como argumento y algo falla más abajo. */
function registro_prueba_adentro(array $usuario, string $secreto): bool
{
    throw new RuntimeException('la base se cayó a media comprobación');
}

function registro_prueba_entrar(string $usuario, string $secreto): void
{
    registro_prueba_adentro(['id' => 1], $secreto);
}

/** @return array{0:Registro,1:string,2:callable} */
$enUnaCarpeta = static function (bool $conTraza): array {
    $carpeta = sys_get_temp_dir() . '/pb-registro-' . bin2hex(random_bytes(6));

    $lee   = static fn (): string => (string) @file_get_contents($carpeta . '/' . date('Y-m-d') . '.log');
    $borra = static function () use ($carpeta): void {
        foreach (glob($carpeta . '/*') ?: [] as $archivo) {
            unlink($archivo);
        }
        if (is_dir($carpeta)) {
            rmdir($carpeta);
        }
    };

    return [new Registro($carpeta, $conTraza), $carpeta, $lee, $borra];
};

/** La falla, ya atrapada, con el secreto en la pila. */
$conElSecreto = static function (string $secreto): Throwable {
    try {
        registro_prueba_entrar('gerente', $secreto);
    } catch (Throwable $e) {
        return $e;
    }

    throw new LogicException('la falla no llegó');
};

return [
    'la traza dice por dónde pasó y no con qué' => function () use ($enUnaCarpeta, $conElSecreto): void {
        [$registro, , $lee, $borra] = $enUnaCarpeta(true);

        $registro->error('Falla no prevista', ['ruta' => 'POST /entrar'], $conElSecreto('Timon2026segura'));
        $texto = $lee();
        $borra();

        Afirma::falso(str_contains($texto, 'Timon2026'), 'se escribió el secreto');
        Afirma::cierto(str_contains($texto, 'registro_prueba_adentro'), 'no se escribió por dónde pasó');
        Afirma::cierto(str_contains($texto, '{main}'), 'la traza quedó a medias');
    },

    'un secreto corto tampoco se escribe entero' => function () use ($enUnaCarpeta, $conElSecreto): void {
        // El de diecisiete se cortaba a los quince; éste cabía completo.
        [$registro, , $lee, $borra] = $enUnaCarpeta(true);

        $registro->error('Falla no prevista', [], $conElSecreto('abc123'));
        $texto = $lee();
        $borra();

        Afirma::falso(str_contains($texto, 'abc123'), 'se escribió el secreto corto');
    },

    'sin depurar no se escribe traza' => function () use ($enUnaCarpeta, $conElSecreto): void {
        [$registro, , $lee, $borra] = $enUnaCarpeta(false);

        $registro->error('Falla no prevista', [], $conElSecreto('abc123'));
        $texto = $lee();
        $borra();

        Afirma::falso(str_contains($texto, '{main}'), 'se escribió la traza');
        Afirma::cierto(str_contains($texto, 'la base se cayó'), 'y el mensaje de la falla sí va');
    },

    'el mensaje lleva la fecha, el nivel y el contexto legible' => function () use ($enUnaCarpeta): void {
        [$registro, , $lee, $borra] = $enUnaCarpeta(false);

        $registro->aviso('Acceso fallido', ['usuario' => 'dueño', 'ip' => '203.0.113.7']);
        $texto = $lee();
        $borra();

        Afirma::cierto(str_contains($texto, '[' . date('Y-m-d')), 'la fecha');
        Afirma::cierto(str_contains($texto, 'AVISO Acceso fallido'), 'el nivel y el mensaje');
        Afirma::cierto(str_contains($texto, '"usuario":"dueño"'), 'el acento del contexto, sin escapar');
    },

    'el archivo del registro no lo puede leer cualquiera' => function () use ($enUnaCarpeta): void {
        // Lleva la operación y los intentos de acceso: 0640 el archivo, 0750 la
        // carpeta. En `pruebas/humo.sh` se comprueba además que no la sirva el
        // servidor.
        [$registro, $carpeta, , $borra] = $enUnaCarpeta(false);

        $registro->aviso('algo');
        $archivo = $carpeta . '/' . date('Y-m-d') . '.log';

        $delArchivo = substr(sprintf('%o', fileperms($archivo)), -4);
        $deLaCarpeta = substr(sprintf('%o', fileperms($carpeta)), -4);
        $borra();

        Afirma::igual('0640', $delArchivo, 'los permisos del archivo');
        Afirma::igual('0750', $deLaCarpeta, 'los permisos de la carpeta');
    },

    'los registros viejos se tiran, y sólo los que este archivo escribió' => function () use ($enUnaCarpeta): void {
        // El respaldo conserva catorce copias por esta razón y el registro no la
        // aplicaba: el disco del hospedaje se llena y el respaldo del día que
        // hacía falta es el que no se pudo escribir.
        [$registro, $carpeta, , $borra] = $enUnaCarpeta(false);

        $hace = static fn (int $dias): string => date('Y-m-d', strtotime('-' . $dias . ' days'));

        file_put_contents($carpeta . '/' . $hace(200) . '.log', "viejísimo\n");
        file_put_contents($carpeta . '/' . $hace(91) . '.log', "recién pasado el límite\n");
        file_put_contents($carpeta . '/' . $hace(89) . '.log', "dentro del límite\n");
        // Dos que no son del registro. El segundo importa: se llama de modo que
        // **ordena antes** de la fecha límite, que es lo único que decide si un
        // archivo es viejo. Sin mirar el nombre, ése se borraría.
        file_put_contents($carpeta . '/notas-de-alguien.log', "esto no lo escribió el registro\n");
        file_put_contents($carpeta . '/1-apuntes.log', "ni esto\n");

        // El barrido va con el primer error del día, que es el que sigue.
        $registro->aviso('el primero de hoy');

        $quedan = array_map('basename', glob($carpeta . '/*.log') ?: []);
        sort($quedan);
        $borra();

        Afirma::igual(
            ['1-apuntes.log', $hace(89) . '.log', date('Y-m-d') . '.log', 'notas-de-alguien.log'],
            $quedan,
            'lo que quedó en la carpeta'
        );
    },

    'el barrido es una vez al día, no en cada falla' => function () use ($enUnaCarpeta): void {
        [$registro, $carpeta, , $borra] = $enUnaCarpeta(false);

        $viejo = $carpeta . '/' . date('Y-m-d', strtotime('-100 days')) . '.log';

        $registro->aviso('el primero de hoy');      // aquí barre
        file_put_contents($viejo, "sembrado después\n");
        $registro->aviso('el segundo de hoy');      // aquí ya no

        $sigue = is_file($viejo);
        $borra();

        Afirma::cierto($sigue, 'el barrido se repitió dentro del mismo día');
    },

    'dos líneas seguidas no se pisan' => function () use ($enUnaCarpeta): void {
        [$registro, , $lee, $borra] = $enUnaCarpeta(false);

        $registro->aviso('la primera');
        $registro->error('la segunda');
        $texto = $lee();
        $borra();

        Afirma::igual(2, substr_count($texto, "\n"), 'las líneas');
    },
    'si el disco rechaza la escritura, el registro no lanza otra falla' => function () use ($enUnaCarpeta): void {
        [$registro, $carpeta, , $borra] = $enUnaCarpeta(false);

        // El archivo de hoy es una carpeta: `file_put_contents()` falla igual
        // que con el disco lleno o con el archivo desalojado por iCloud.
        $hoy = $carpeta . '/' . date('Y-m-d') . '.log';
        mkdir($hoy);
        $destino = tempnam(sys_get_temp_dir(), 'pb-error-log-');
        $antes = ini_set('error_log', $destino);
        // El manejador del sistema convierte cualquier aviso en excepción.
        set_error_handler(static function (int $nivel, string $mensaje): bool {
            if ((error_reporting() & $nivel) === 0) {
                return false;
            }
            throw new ErrorException($mensaje, 0, $nivel);
        });

        $lanzo = null;
        try {
            $registro->error('la base se cayó');
        } catch (Throwable $e) {
            $lanzo = $e;
        } finally {
            restore_error_handler();
            ini_set('error_log', (string) $antes);
        }

        $alterno = (string) file_get_contents($destino);
        unlink($destino);
        rmdir($hoy);
        $borra();

        Afirma::igual(null, $lanzo, 'la excepción al escribir el registro');
        Afirma::contiene('la base se cayó', $alterno, 'lo que cayó al error_log de PHP');
    },
    'si el disco rechaza la escritura, el registro no lanza otra falla' => function () use ($enUnaCarpeta): void {
        [$registro, $carpeta, , $borra] = $enUnaCarpeta(false);

        // El archivo de hoy es una carpeta: `file_put_contents()` falla igual
        // que con el disco lleno o con el archivo desalojado por iCloud.
        $hoy = $carpeta . '/' . date('Y-m-d') . '.log';
        mkdir($hoy);
        $destino = (string) tempnam(sys_get_temp_dir(), 'pb-error-log-');
        $antes = ini_set('error_log', $destino);
        // Como el manejador del sistema: cualquier aviso se vuelve excepción.
        set_error_handler(static function (int $nivel, string $mensaje): bool {
            if ((error_reporting() & $nivel) === 0) {
                return false;
            }
            throw new ErrorException($mensaje, 0, $nivel);
        });

        $lanzo = null;
        try {
            $registro->error('la base se cayó');
        } catch (Throwable $e) {
            $lanzo = $e;
        } finally {
            restore_error_handler();
            ini_set('error_log', (string) $antes);
        }

        $alterno = (string) file_get_contents($destino);
        unlink($destino);
        rmdir($hoy);
        $borra();

        Afirma::igual(null, $lanzo, 'la excepción al escribir el registro');
        Afirma::contiene('la base se cayó', $alterno, 'lo que cayó al error_log de PHP');
    },
];
