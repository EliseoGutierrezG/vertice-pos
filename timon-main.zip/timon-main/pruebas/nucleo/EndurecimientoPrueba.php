<?php
declare(strict_types=1);

use Modelos\Usuarios;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\Registro;
use Nucleo\Respuesta;
use Nucleo\Seguridad\ClavesComunes;
use Pruebas\Afirma;
use Servicios\RevisionAccesos;
use Servicios\SelloBitacora;

/**
 * Los candados del endurecimiento (docs/seguridad/matriz-controles.md).
 *
 * Un control que no se comprueba es una promesa: aquí cada uno tiene su caso,
 * incluido el que más importa de todos, que alterar la bitácora sí se note.
 */

$raiz = dirname(__DIR__, 2);
$bd = new BaseDatos(Nucleo\Configuracion::baseDatos($raiz));
$llave = random_bytes(32);
$registro = new Registro(sys_get_temp_dir() . '/timon-pruebas', false);
$bitacora = new Bitacora($bd, $registro);

$usuarioPrueba = 'prbsoporte.vencido';
Pruebas\Semilla::borraUsuarios($bd, $usuarioPrueba);

/** Cada caso del sello arranca sin sellos y con renglones propios que luego retira. */
$conSellos = static function (callable $caso) use ($bd, $llave, $bitacora): void {
    $sellosAntes = $bd->filas('SELECT * FROM bitacora_sello ORDER BY id');
    $bd->ejecuta('DELETE FROM bitacora_sello');
    $ultimo = (int) $bd->valor('SELECT COALESCE(MAX(id), 0) FROM bitacora');
    $bitacora->registra('prueba_sello', 'uno', 'cosa', 1, despues: ['n' => 1]);
    $bitacora->registra('prueba_sello', 'dos', 'cosa', 2, despues: ['n' => 2]);

    try {
        $caso(new SelloBitacora($bd, $llave), date('Y-m-d', strtotime('+1 day')));
    } finally {
        $bd->ejecuta('DELETE FROM bitacora_sello');
        $bd->ejecuta('DELETE FROM bitacora WHERE modulo = ? AND id > ?', ['prueba_sello', $ultimo]);
        foreach ($sellosAntes as $s) {
            $bd->ejecuta(
                'INSERT INTO bitacora_sello (id, desde_id, hasta_id, renglones, huella, huella_anterior, sellado_en) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [$s['id'], $s['desde_id'], $s['hasta_id'], $s['renglones'], $s['huella'], $s['huella_anterior'], $s['sellado_en']]
            );
        }
    }
};

return [
    'las contraseñas conocidas se rechazan aunque sean largas' => function (): void {
        foreach (['123456789012', 'password1234', 'contraseña123', 'abcabcabcabc', 'aaaaaaaaaaaa', 'qwertyuiop12'] as $clave) {
            Afirma::cierto(ClavesComunes::es($clave), $clave . ' debería ser común');
        }
        Afirma::cierto(!ClavesComunes::es('mesa-verde-del-patio-9'), 'una frase propia no es común');
    },

    'la contraseña pide doce caracteres y no acepta una conocida' => function (): void {
        Afirma::noNulo(Usuarios::quejaDeClave('corta-11-ca', 'alguien'), 'once caracteres');
        Afirma::noNulo(Usuarios::quejaDeClave('password1234', 'alguien'), 'una conocida');
        Afirma::nulo(Usuarios::quejaDeClave('mesa-verde-del-patio-9', 'alguien'), 'una frase propia');
    },

    'la bitácora oculta secretos y recorta los contactos, a cualquier profundidad' => function (): void {
        $limpio = Bitacora::enmascara([
            'clave_hash' => 'secreto-de-prueba',
            'telefono' => '2220001234',
            'correo' => 'alguien@ejemplo.test',
            'nombre' => 'Se queda',
            'clave' => 'parametro_visible',
            'dentro' => ['token' => 'otro-secreto', 'celular' => '2229998877'],
        ]);

        Afirma::igual('[oculto]', $limpio['clave_hash'], 'el hash');
        Afirma::igual('[oculto]', $limpio['dentro']['token'], 'el token anidado');
        Afirma::cierto(!str_contains((string) $limpio['telefono'], '222000'), 'el teléfono');
        Afirma::cierto(str_ends_with((string) $limpio['dentro']['celular'], '77'), 'los últimos dos del celular');
        Afirma::cierto(!str_contains((string) $limpio['correo'], 'alguien'), 'el correo');
        Afirma::igual('Se queda', $limpio['nombre'], 'lo que no es sensible');
        Afirma::igual('parametro_visible', $limpio['clave'], 'la clave de un parámetro no es una contraseña');
    },

    'un sello recién hecho verifica limpio y no se repite' => function () use ($conSellos): void {
        $conSellos(function (SelloBitacora $sello, string $manana): void {
            Afirma::cierto($sello->sella($manana) >= 2, 'sella los renglones');
            Afirma::igual([], $sello->verifica(), 'los problemas');
            Afirma::igual(0, $sello->sella($manana), 'la segunda pasada');
        });
    },

    'hoy no se sella: el día sigue abierto' => function () use ($conSellos, $bd): void {
        $conSellos(function (SelloBitacora $sello) use ($bd): void {
            $sello->sella(date('Y-m-d'));
            $tope = (int) $bd->valor('SELECT COALESCE(MAX(hasta_id), 0) FROM bitacora_sello');
            $hoy = (int) $bd->valor("SELECT COUNT(*) FROM bitacora WHERE modulo = 'prueba_sello' AND id <= ?", [$tope]);
            Afirma::igual(0, $hoy, 'renglones de hoy sellados');
        });
    },

    'cambiar un renglón sellado se nota' => function () use ($conSellos, $bd): void {
        $conSellos(function (SelloBitacora $sello, string $manana) use ($bd): void {
            $sello->sella($manana);
            $bd->ejecuta("UPDATE bitacora SET accion = 'alterada' WHERE modulo = 'prueba_sello' AND accion = 'uno'");
            Afirma::contiene('Se alteró', implode(' ', $sello->verifica()), 'el aviso');
        });
    },

    'borrar un renglón sellado se nota' => function () use ($conSellos, $bd): void {
        $conSellos(function (SelloBitacora $sello, string $manana) use ($bd): void {
            $sello->sella($manana);
            $bd->ejecuta("DELETE FROM bitacora WHERE modulo = 'prueba_sello' AND accion = 'dos'");
            Afirma::contiene('renglones', implode(' ', $sello->verifica()), 'el aviso');
        });
    },

    'quitar un tramo entero rompe la cadena' => function () use ($conSellos, $bd, $bitacora): void {
        $conSellos(function (SelloBitacora $sello, string $manana) use ($bd, $bitacora): void {
            $sello->sella($manana);
            $bitacora->registra('prueba_sello', 'tres', 'cosa', 3);
            $sello->sella($manana);
            $bitacora->registra('prueba_sello', 'cuatro', 'cosa', 4);
            $sello->sella($manana);
            $segundo = (int) $bd->valor('SELECT id FROM bitacora_sello ORDER BY hasta_id LIMIT 1 OFFSET 1');
            $bd->ejecuta('DELETE FROM bitacora_sello WHERE id = ?', [$segundo]);
            Afirma::cierto($sello->verifica() !== [], 'debe avisar');
        });
    },

    'con otra llave nada cuadra' => function () use ($conSellos, $bd): void {
        $conSellos(function (SelloBitacora $sello, string $manana) use ($bd): void {
            $sello->sella($manana);
            Afirma::cierto((new SelloBitacora($bd, random_bytes(32)))->verifica() !== [], 'debe avisar');
        });
    },

    'una cuenta con el acceso vencido no entra' => function () use ($bd, $usuarioPrueba): void {
        $clave = 'frase-larga-de-soporte-7';
        $id = Pruebas\Semilla::usuario($bd, $usuarioPrueba, 'administrador', $clave);
        $usuarios = new Usuarios($bd);

        try {
            $bd->ejecuta('UPDATE usuario SET acceso_hasta = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id = ?', [$id]);
            Afirma::noNulo($usuarios->autentica($usuarioPrueba, $clave), 'vigente');

            $bd->ejecuta('UPDATE usuario SET acceso_hasta = DATE_SUB(NOW(), INTERVAL 1 MINUTE) WHERE id = ?', [$id]);
            Afirma::nulo($usuarios->autentica($usuarioPrueba, $clave), 'vencida');
        } finally {
            Pruebas\Semilla::borraUsuarios($bd, $usuarioPrueba);
        }
    },

    'la revisión de accesos pide una nota y deja constancia' => function () use ($bd, $bitacora, $usuarioPrueba): void {
        $id = Pruebas\Semilla::usuario($bd, $usuarioPrueba, 'administrador', 'frase-larga-de-soporte-7');
        $servicio = new RevisionAccesos($bd, $bitacora);

        try {
            $reporte = $servicio->reporte();
            Afirma::cierto($reporte['cuentas'] !== [], 'trae cuentas');

            $rechazada = false;
            try {
                $servicio->registra('corta', $id, '127.0.0.1');
            } catch (Nucleo\Errores\ErrorHttp) {
                $rechazada = true;
            }
            Afirma::cierto($rechazada, 'una nota corta se rechaza');

            $servicio->registra('Revisé cuentas y puestos, sin cambios.', $id, '127.0.0.1');
            Afirma::igual(1, (int) $bd->valor('SELECT COUNT(*) FROM revision_acceso WHERE revisado_por = ?', [$id]), 'la revisión');
            Afirma::igual(1, (int) $bd->valor("SELECT COUNT(*) FROM bitacora WHERE accion = 'revisa_accesos' AND id_usuario = ?", [$id]), 'el apunte');
        } finally {
            $bd->ejecuta('DELETE FROM revision_acceso WHERE revisado_por = ?', [$id]);
            Pruebas\Semilla::borraUsuarios($bd, $usuarioPrueba);
        }
    },

    'la política de contenido no permite scripts incrustados' => function (): void {
        $politica = Respuesta::POLITICA_CONTENIDO;

        Afirma::contiene("script-src 'self';", $politica, 'los scripts');
        Afirma::contiene("frame-ancestors 'none'", $politica, 'los marcos');
        Afirma::contiene("object-src 'none'", $politica, 'los objetos');
        Afirma::contiene('geolocation=()', Respuesta::POLITICA_PERMISOS, 'los permisos');
    },

    'solo las pantallas del ticket mandan formularios a WhatsApp' => function () use ($raiz): void {
        Afirma::contiene("form-action 'self';", Respuesta::POLITICA_CONTENIDO, 'el resto del panel');
        $ticket = Respuesta::html('')->conSalidaAWhatsApp()->cabeceras()['Content-Security-Policy'] ?? '';
        Afirma::contiene("form-action 'self' https://wa.me https://api.whatsapp.com;", $ticket, 'el ticket');
        Afirma::contiene("script-src 'self';", $ticket, 'sin aflojar lo demás');

        $usan = [];
        foreach (glob($raiz . '/controladores/Web/*.php') ?: [] as $archivo) {
            if (str_contains((string) file_get_contents($archivo), 'conSalidaAWhatsApp()')) {
                $usan[] = basename($archivo);
            }
        }
        sort($usan);
        // Hoy ninguna: el ticket de la comanda (fase 7) la abre y se anota aquí.
        Afirma::igual([], $usan, 'quién abre la excepción');

        // Cada vista con el botón está detrás de una de esas acciones.
        $vistas = [];
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($raiz . '/vistas', FilesystemIterator::SKIP_DOTS)) as $archivo) {
            if (str_contains((string) file_get_contents($archivo->getPathname()), '/ticket-publico" target="_blank"')) {
                $vistas[] = substr($archivo->getPathname(), strlen($raiz) + 1);
            }
        }
        sort($vistas);
        Afirma::igual([], $vistas, 'las vistas con el botón');
    },

    'ninguna vista trae scripts ni manejadores incrustados' => function () use ($raiz): void {
        $hallados = [];
        $archivos = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($raiz . '/vistas', FilesystemIterator::SKIP_DOTS));
        foreach ($archivos as $archivo) {
            if ($archivo->getExtension() !== 'php') {
                continue;
            }
            $texto = (string) file_get_contents($archivo->getPathname());
            if (preg_match('/<script(?![^>]*\\bsrc=)(?![^>]*type="application\/(?:ld\+)?json")[^>]*>/i', $texto)
                || preg_match('/<[a-z][^>]*\son(?:click|load|change|submit|input|error)=/i', $texto)
            ) {
                $hallados[] = substr($archivo->getPathname(), strlen($raiz) + 1);
            }
        }
        Afirma::igual([], $hallados, 'las vistas con código incrustado');
    },
];
