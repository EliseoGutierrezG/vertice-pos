<?php
declare(strict_types=1);

use Nucleo\Contenedor;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Errores\Errores;
use Nucleo\Middleware\Cadena;
use Nucleo\Middleware\Intermediario;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Pruebas\Afirma;

/**
 * La cadena de intermediarios: orden, corte y paso de argumento.
 *
 * El orden no es un detalle. Identidad tiene que correr antes que permiso,
 * porque no se puede preguntar qué puede hacer alguien de quien todavía no se
 * sabe quién es.
 */

/** Lleva la cuenta de por dónde pasó la petición. */
final class Rastro
{
    /** @var list<string> */
    public static array $pasos = [];

    public static function limpia(): void
    {
        self::$pasos = [];
    }
}

final class IntermediarioQueDejaPasar implements Intermediario
{
    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        Rastro::$pasos[] = 'entra-primero';
        $respuesta = $siguiente($peticion);
        Rastro::$pasos[] = 'sale-primero';

        return $respuesta;
    }
}

final class IntermediarioSegundo implements Intermediario
{
    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        Rastro::$pasos[] = 'entra-segundo';
        $respuesta = $siguiente($peticion);
        Rastro::$pasos[] = 'sale-segundo';

        return $respuesta;
    }
}

final class IntermediarioQueCorta implements Intermediario
{
    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        Rastro::$pasos[] = 'corta';

        throw Errores::prohibido('No pasa');
    }
}

final class IntermediarioConArgumento implements Intermediario
{
    public function __construct(private string $permiso)
    {
    }

    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        Rastro::$pasos[] = 'permiso:' . $this->permiso;

        return $siguiente($peticion);
    }
}

$peticion = function (): Peticion {
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['REQUEST_URI']    = '/lo-que-sea';
    $_SERVER['REMOTE_ADDR']    = '127.0.0.1';
    $_GET = [];

    return Peticion::desdeGlobales();
};

$destino = function (Peticion $peticion): Respuesta {
    Rastro::$pasos[] = 'destino';

    return Respuesta::json(['listo' => true]);
};

$contenedor = new Contenedor([]);

return [
    'sin intermediarios, la petición llega al destino' => function () use ($peticion, $destino, $contenedor): void {
        Rastro::limpia();
        $cadena = new Cadena([], $contenedor);

        $respuesta = $cadena->ejecutar($peticion(), $destino);

        Afirma::igual(['destino'], Rastro::$pasos, 'el rastro');
        Afirma::igual(200, $respuesta->estado(), 'el estado');
    },

    'el primero declarado es el primero en correr' => function () use ($peticion, $destino, $contenedor): void {
        Rastro::limpia();
        $cadena = new Cadena(
            [IntermediarioQueDejaPasar::class, IntermediarioSegundo::class],
            $contenedor
        );

        $cadena->ejecutar($peticion(), $destino);

        Afirma::igual(
            ['entra-primero', 'entra-segundo', 'destino', 'sale-segundo', 'sale-primero'],
            Rastro::$pasos,
            'el rastro'
        );
    },

    'un intermediario que corta impide que el destino corra' => function () use ($peticion, $destino, $contenedor): void {
        Rastro::limpia();
        $cadena = new Cadena(
            [IntermediarioQueCorta::class, IntermediarioSegundo::class],
            $contenedor
        );

        $error = Afirma::lanza(ErrorHttp::class, fn () => $cadena->ejecutar($peticion(), $destino));

        Afirma::igual(403, $error->getCode(), 'el código');
        Afirma::igual(['corta'], Rastro::$pasos, 'el rastro: nada corrió después');
    },

    'el argumento después de los dos puntos llega al intermediario' => function () use ($peticion, $destino, $contenedor): void {
        Rastro::limpia();
        $cadena = new Cadena([IntermediarioConArgumento::class . ':pedidos_ver'], $contenedor);

        $cadena->ejecutar($peticion(), $destino);

        Afirma::igual(['permiso:pedidos_ver', 'destino'], Rastro::$pasos, 'el rastro');
    },
];
