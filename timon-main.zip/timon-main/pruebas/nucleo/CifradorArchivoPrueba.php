<?php
declare(strict_types=1);

use Nucleo\Seguridad\CifradorArchivo;
use Pruebas\Afirma;

$carpeta = sys_get_temp_dir() . '/app-cifrado-' . bin2hex(random_bytes(4));
mkdir($carpeta, 0700, true);
register_shutdown_function(static function () use ($carpeta): void {
    foreach (glob($carpeta . '/*') ?: [] as $archivo) {
        @unlink($archivo);
    }
    @rmdir($carpeta);
});
$cifrador = new CifradorArchivo(CifradorArchivo::generaLlave());
$escribe = static function (string $nombre, string $contenido) use ($carpeta): string {
    $ruta = $carpeta . '/' . $nombre;
    file_put_contents($ruta, $contenido);
    return $ruta;
};

return [
    'un respaldo de varios bloques vuelve idéntico y sin texto en claro' => function () use ($cifrador, $escribe, $carpeta): void {
        // Más de dos bloques de 64 KB, y que no caiga justo en el borde.
        $claro = str_repeat("INSERT INTO pedido VALUES ('Cliente secreto');\n", 4000);
        $origen = $escribe('a.sql', $claro);
        $cifrado = $carpeta . '/a.sql.sgr';
        $cifrador->cifra($origen, $cifrado);
        Afirma::falso(str_contains((string) file_get_contents($cifrado), 'Cliente secreto'));
        Afirma::cierto(str_starts_with((string) file_get_contents($cifrado), CifradorArchivo::FIRMA));
        $huella = $cifrador->descifra($cifrado, $carpeta . '/a.vuelta.sql');
        Afirma::igual(hash('sha256', $claro), $huella);
        Afirma::igual($claro, (string) file_get_contents($carpeta . '/a.vuelta.sql'));
    },
    'un archivo que mide exactamente un bloque o nada también vuelve' => function () use ($cifrador, $escribe, $carpeta): void {
        foreach (['b' => str_repeat('x', 65536), 'c' => ''] as $nombre => $claro) {
            $origen = $escribe($nombre . '.sql', $claro);
            $cifrador->cifra($origen, $carpeta . '/' . $nombre . '.sgr');
            Afirma::igual(hash('sha256', $claro), $cifrador->descifra($carpeta . '/' . $nombre . '.sgr'), $nombre);
        }
    },
    'un byte alterado se detecta' => function () use ($cifrador, $escribe, $carpeta): void {
        $origen = $escribe('d.sql', str_repeat('respaldo ', 20000));
        $cifrador->cifra($origen, $carpeta . '/d.sgr');
        $bytes = (string) file_get_contents($carpeta . '/d.sgr');
        $posicion = intdiv(strlen($bytes), 2);
        $bytes[$posicion] = chr(ord($bytes[$posicion]) ^ 1);
        file_put_contents($carpeta . '/d.sgr', $bytes);
        Afirma::lanza(\RuntimeException::class, fn () => $cifrador->descifra($carpeta . '/d.sgr'));
    },
    'una copia truncada no pasa por buena' => function () use ($cifrador, $escribe, $carpeta): void {
        $origen = $escribe('e.sql', str_repeat('respaldo ', 30000));
        $cifrador->cifra($origen, $carpeta . '/e.sgr');
        $bytes = (string) file_get_contents($carpeta . '/e.sgr');
        // Se corta justo donde empieza el último bloque: lo que queda está
        // bien formado, pero le falta la marca final.
        $primero = strlen(CifradorArchivo::FIRMA) + 24;
        $largo = unpack('N', substr($bytes, $primero, 4))[1];
        file_put_contents($carpeta . '/e.sgr', substr($bytes, 0, $primero + 4 + $largo));
        $x = Afirma::lanza(\RuntimeException::class, fn () => $cifrador->descifra($carpeta . '/e.sgr'));
        Afirma::cierto(str_contains($x->getMessage(), 'incompleto'), $x->getMessage());
    },
    'otra llave no abre la copia y no deja salida a medias' => function () use ($cifrador, $escribe, $carpeta): void {
        $origen = $escribe('f.sql', 'contenido');
        $cifrador->cifra($origen, $carpeta . '/f.sgr');
        $otro = new CifradorArchivo(CifradorArchivo::generaLlave());
        Afirma::lanza(\RuntimeException::class, fn () => $otro->descifra($carpeta . '/f.sgr', $carpeta . '/f.vuelta'));
        Afirma::falso(file_exists($carpeta . '/f.vuelta'));
        Afirma::igual([], glob($carpeta . '/f.vuelta.tmp-*') ?: []);
    },
    'no sobrescribe una copia que ya existe' => function () use ($cifrador, $escribe, $carpeta): void {
        $origen = $escribe('g.sql', 'uno');
        $cifrador->cifra($origen, $carpeta . '/g.sgr');
        $antes = (string) file_get_contents($carpeta . '/g.sgr');
        Afirma::lanza(\RuntimeException::class, fn () => $cifrador->cifra($origen, $carpeta . '/g.sgr'));
        Afirma::lanza(\RuntimeException::class, fn () => $cifrador->descifra($carpeta . '/g.sgr', $origen));
        Afirma::igual('uno', (string) file_get_contents($origen));
        Afirma::igual($antes, (string) file_get_contents($carpeta . '/g.sgr'));
    },
    'una llave que no mide 32 bytes se rechaza' => function (): void {
        Afirma::lanza(\RuntimeException::class, fn () => new CifradorArchivo(base64_encode('corta')));
    },
];
