<?php
declare(strict_types=1);

use Nucleo\BaseDatos;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Errores\Errores;
use Pruebas\Afirma;

/**
 * La capa de base de datos contra MariaDB de verdad.
 *
 * No hay simulacro: una capa de base de datos que sólo se prueba contra un
 * doble no prueba lo que importa —que el motor acepte lo que se le manda—.
 * Todo lo que estas pruebas escriben, lo borran.
 */

/** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
$config = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd     = new BaseDatos($config);

/**
 * Una tabla propia para no ensuciar las del negocio.
 *
 * ⚠️ Y se tira al terminar el proceso, no sólo en la última prueba de aquí. El
 * corredor hace `require` de **todos** los archivos antes de aplicar el filtro,
 * así que `php pruebas/correr.php router` creaba esta tabla y **no corría la
 * prueba que la tira**: quedaba en la base hasta la siguiente corrida completa.
 * Medido, y con consecuencia: el diagnóstico contaba 46 tablas contra las 45 del
 * esquema, y una tabla de basura **tapa una tabla que falte**, que es justo lo
 * que esa comprobación existe para ver.
 */
register_shutdown_function(static function () use ($bd): void {
    $bd->ejecuta('DROP TABLE IF EXISTS prueba_andamiaje');
});

$bd->ejecuta('DROP TABLE IF EXISTS prueba_andamiaje');
$bd->ejecuta(
    'CREATE TABLE prueba_andamiaje (
        id      INT UNSIGNED NOT NULL AUTO_INCREMENT,
        nombre  VARCHAR(60)   NOT NULL,
        importe DECIMAL(12,4) NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_prueba_nombre (nombre)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
);

return [
    'una consulta preparada devuelve lo que se le pide' => function () use ($bd): void {
        Afirma::igual(1, (int) $bd->valor('SELECT 1'), 'el valor');
    },

    'los parámetros viajan atados, no pegados a la cadena' => function () use ($bd): void {
        // Si esto se concatenara, la comilla rompería la consulta.
        $nombre = "Cerveza 'clara'";
        $bd->ejecuta('DELETE FROM prueba_andamiaje');
        $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', [$nombre]);

        Afirma::igual(
            $nombre,
            $bd->valor('SELECT nombre FROM prueba_andamiaje WHERE nombre = ?', [$nombre]),
            'el nombre'
        );
    },

    'un intento de inyección se guarda como texto, no se ejecuta' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');
        $veneno = "x'; DROP TABLE prueba_andamiaje; --";
        $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', [$veneno]);

        Afirma::igual(1, (int) $bd->valor('SELECT COUNT(*) FROM prueba_andamiaje'), 'las filas');
        Afirma::igual($veneno, $bd->valor('SELECT nombre FROM prueba_andamiaje'), 'el texto guardado');
    },

    'los enteros, decimales y nulos se atan con su tipo' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');
        $bd->inserta('INSERT INTO prueba_andamiaje (nombre, importe) VALUES (?, ?)', ['con importe', 12.3456]);
        $bd->inserta('INSERT INTO prueba_andamiaje (nombre, importe) VALUES (?, ?)', ['sin importe', null]);

        Afirma::igual('12.3456', $bd->valor('SELECT importe FROM prueba_andamiaje WHERE nombre = ?', ['con importe']), 'el decimal');
        Afirma::nulo($bd->valor('SELECT importe FROM prueba_andamiaje WHERE nombre = ?', ['sin importe']), 'el nulo');
    },

    'inserta devuelve el identificador recién creado' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');
        $id = $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['con id']);

        Afirma::cierto($id > 0, 'el id es positivo');
        Afirma::igual('con id', $bd->valor('SELECT nombre FROM prueba_andamiaje WHERE id = ?', [$id]), 'la fila');
    },

    'fila devuelve null cuando no hay nada' => function () use ($bd): void {
        Afirma::nulo($bd->fila('SELECT * FROM prueba_andamiaje WHERE id = ?', [999999]), 'la fila');
    },

    'una transacción que termina bien deja el cambio' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');

        $bd->transaccion(function (BaseDatos $bd): void {
            $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['queda']);
        });

        Afirma::igual(1, (int) $bd->valor('SELECT COUNT(*) FROM prueba_andamiaje'), 'las filas');
    },

    'una transacción que falla deja la base intacta' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');

        Afirma::lanza(RuntimeException::class, function () use ($bd): void {
            $bd->transaccion(function (BaseDatos $bd): void {
                $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['primera']);
                $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['segunda']);

                throw new RuntimeException('algo salió mal a media transacción');
            });
        });

        Afirma::igual(
            0,
            (int) $bd->valor('SELECT COUNT(*) FROM prueba_andamiaje'),
            'las filas después de deshacer'
        );
    },

    'la excepción sigue su camino después de deshacer' => function () use ($bd): void {
        $error = Afirma::lanza(RuntimeException::class, function () use ($bd): void {
            $bd->transaccion(function (): void {
                throw new RuntimeException('el mensaje original');
            });
        });

        Afirma::igual('el mensaje original', $error->getMessage(), 'el mensaje');
    },

    'una transacción anidada que falla no arrastra a la de fuera' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');

        $bd->transaccion(function (BaseDatos $bd): void {
            $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['de fuera']);

            try {
                $bd->transaccion(function (BaseDatos $bd): void {
                    $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['de dentro']);
                    throw new RuntimeException('falla la de dentro');
                });
            } catch (RuntimeException $e) {
                // Se atiende aquí: la de fuera decide seguir.
            }
        });

        $nombres = array_column($bd->filas('SELECT nombre FROM prueba_andamiaje ORDER BY id'), 'nombre');
        Afirma::igual(['de fuera'], $nombres, 'lo que quedó');
    },

    'si el punto de retorno ya no existe, la falla original es la que sale' => function () use ($bd): void {
        // ⚠️ El caso de verdad es un **interbloqueo** dentro de una transacción
        // anidada: MariaDB deshace la transacción entera al devolverlo, así que
        // el punto de retorno desaparece y el `ROLLBACK TO SAVEPOINT` falla.
        // Aquí el punto se suelta a mano, que es lo mismo desde adentro.
        //
        // Medido antes del arreglo: la falla del punto de retorno **reemplazaba**
        // a la original, y en lugar de «otra operación tocaba lo mismo, vuelve a
        // intentar» —un 409 con instrucción— salía «SAVEPOINT nivel_1 does not
        // exist», que no es `ErrorHttp` y por lo tanto sale por 500. El usuario
        // recibe «algo salió mal» por algo que se arregla volviendo a intentar, y
        // el registro de errores se queda con el mensaje que no explica nada.
        $salio = null;

        try {
            $bd->transaccion(fn (BaseDatos $bd) => $bd->transaccion(function (BaseDatos $bd): void {
                $bd->ejecuta('RELEASE SAVEPOINT nivel_1');

                throw Errores::conflicto('Otra operación tocaba lo mismo al mismo tiempo. Vuelve a intentar.');
            }));
        } catch (Throwable $e) {
            $salio = $e;
        }

        Afirma::cierto($salio instanceof ErrorHttp, 'salió ' . ($salio === null ? 'nada' : get_class($salio)));
        Afirma::contiene('Vuelve a intentar', $salio?->getMessage() ?? '', 'el mensaje que sí explica');
        Afirma::falso($bd->enTransaccion(), 'y la bandera quedó limpia');
    },

    'si lo de la llave ya está, no se vuelve a guardar' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');
        $id = $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['con llave']);

        $seLlamo = false;

        $resultado = $bd->guardaUnaSolaVez(
            fn (): ?int => $id,
            function () use (&$seLlamo): int {
                $seLlamo = true;

                return 0;
            }
        );

        Afirma::igual($id, $resultado, 'lo que devolvió');
        Afirma::falso($seLlamo, 'se volvió a guardar');
    },

    'si dos llegan a la vez, al segundo se le devuelve lo que guardó el primero' => function () use ($bd): void {
        // El caso que la comprobación previa no puede cubrir. Se imita desde
        // adentro: la primera vez que se pregunta, no está —como le pasó al que
        // llegó un instante antes de que el otro confirmara—, y al guardar, la
        // llave única contesta que ya estaba.
        //
        // Medido antes: al segundo le salía un 409, y un 409 es lo único que la
        // app llama «rechazo», así que marcaba la operación atorada y detenía la
        // cola. `pruebas/concurrencia.sh` lo comprueba con dos procesos.
        $bd->ejecuta('DELETE FROM prueba_andamiaje');
        $delOtro = $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['los dos a la vez']);

        $veces = 0;

        $resultado = $bd->guardaUnaSolaVez(
            function () use ($bd, &$veces): ?int {
                $veces++;

                if ($veces === 1) {
                    return null;   // todavía no lo veía
                }

                $id = $bd->valor('SELECT id FROM prueba_andamiaje WHERE nombre = ?', ['los dos a la vez']);

                return $id === null ? null : (int) $id;
            },
            fn (): int => $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['los dos a la vez'])
        );

        Afirma::igual($delOtro, $resultado, 'el identificador que se devolvió');
        Afirma::igual(2, $veces, 'las veces que se preguntó');
        Afirma::igual(1, (int) $bd->valor('SELECT COUNT(*) FROM prueba_andamiaje'), 'las filas');
    },

    'un conflicto que no es el de la llave sale como vino' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');

        $error = Afirma::lanza(ErrorHttp::class, fn () => $bd->guardaUnaSolaVez(
            fn (): ?int => null,
            function (): int {
                throw Errores::conflicto('Ese cliente no existe o está dado de baja');
            }
        ));

        Afirma::contiene('dado de baja', $error->getMessage(), 'el mensaje original');
        Afirma::igual(0, (int) $bd->valor('SELECT COUNT(*) FROM prueba_andamiaje'), 'y no quedó nada escrito');
    },

    'sin llave que buscar, es una transacción y nada más' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');

        Afirma::lanza(ErrorHttp::class, fn () => $bd->guardaUnaSolaVez(null, function () use ($bd): int {
            $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['sin llave']);

            throw Errores::conflicto('algo salió mal después de escribir');
        }));

        Afirma::igual(0, (int) $bd->valor('SELECT COUNT(*) FROM prueba_andamiaje'), 'se deshizo lo escrito');
    },

    'después de una transacción, la bandera vuelve a su sitio' => function () use ($bd): void {
        Afirma::falso($bd->enTransaccion(), 'antes');

        $bd->transaccion(function (BaseDatos $bd): void {
            Afirma::cierto($bd->enTransaccion(), 'durante');
        });

        Afirma::falso($bd->enTransaccion(), 'después');
    },

    'un duplicado es conflicto del usuario, no falla del servidor' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');
        $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['único']);

        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['único'])
        );

        Afirma::igual(409, $error->getCode(), 'el código');
    },

    'lo que el motor rechaza no sale con el SQL a cuestas' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');
        $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['único']);

        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['único'])
        );

        Afirma::falso(str_contains($error->getMessage(), 'INSERT'), 'se filtró el SQL');
        Afirma::falso(str_contains($error->getMessage(), 'prueba_andamiaje'), 'se filtró la tabla');
    },

    'el modo estricto rechaza lo que no cabe en la columna' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');

        Afirma::lanza(
            Throwable::class,
            fn () => $bd->inserta(
                'INSERT INTO prueba_andamiaje (nombre) VALUES (?)',
                [str_repeat('x', 200)]
            ),
            'un texto de 200 en una columna de 60'
        );
    },

    'los acentos van y vuelven enteros' => function () use ($bd): void {
        $bd->ejecuta('DELETE FROM prueba_andamiaje');
        $bd->inserta('INSERT INTO prueba_andamiaje (nombre) VALUES (?)', ['Dueño, sidra y ñandú']);

        Afirma::igual(
            'Dueño, sidra y ñandú',
            $bd->valor('SELECT nombre FROM prueba_andamiaje'),
            'el texto'
        );
    },

    'se limpia lo que la prueba creó' => function () use ($bd): void {
        $bd->ejecuta('DROP TABLE IF EXISTS prueba_andamiaje');

        Afirma::igual(
            0,
            (int) $bd->valor(
                "SELECT COUNT(*) FROM information_schema.tables
                 WHERE table_schema = DATABASE() AND table_name = 'prueba_andamiaje'"
            ),
            'la tabla de prueba'
        );
    },
];
