<?php
declare(strict_types=1);

use Nucleo\Errores\Errores;
use Nucleo\ManejadorErrores;
use Nucleo\Peticion;
use Nucleo\Registro;
use Nucleo\Respuesta;
use Pruebas\Afirma;

/**
 * El sobre de la respuesta y la traducción de un problema a HTTP.
 *
 * Aquí se comprueba la promesa que la app va a dar por buena: el sobre no
 * cambia nunca, y un error del usuario jamás llega como 500.
 */

$peticion = function (bool $json): Peticion {
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['REQUEST_URI']    = $json ? '/api/v1/cosa' : '/cosa';
    $_SERVER['REMOTE_ADDR']    = '127.0.0.1';
    $_GET = [];
    unset($_SERVER['HTTP_ACCEPT']);

    return Peticion::desdeGlobales();
};

$carpeta = sys_get_temp_dir() . '/timon-pruebas';
$manejador = new ManejadorErrores(new Registro($carpeta, false), false);

return [
    'el éxito viaja como ok verdadero con sus datos' => function (): void {
        $cuerpo = json_decode(Respuesta::json(['id' => 7])->cuerpo(), true);

        Afirma::igual(['ok' => true, 'datos' => ['id' => 7]], $cuerpo, 'el sobre');
    },

    'el error viaja como ok falso con clave y mensaje' => function (): void {
        $cuerpo = json_decode(
            Respuesta::jsonError(404, 'no_encontrado', 'No existe')->cuerpo(),
            true
        );

        Afirma::igual(false, $cuerpo['ok'], 'ok');
        Afirma::igual('no_encontrado', $cuerpo['error']['clave'], 'la clave');
        Afirma::igual('No existe', $cuerpo['error']['mensaje'], 'el mensaje');
    },

    'los acentos no se escapan' => function (): void {
        Afirma::contiene('ñ', Respuesta::json(['nombre' => 'Dueño'])->cuerpo(), 'el cuerpo');
    },

    'un decimal con ceros conserva su forma' => function (): void {
        Afirma::contiene('25.0', Respuesta::json(['precio' => 25.0])->cuerpo(), 'el cuerpo');
    },

    'una versión ya guardada responde 304 sin cuerpo y con ETag' => function (): void {
        $respuesta = Respuesta::noModificada('"abc123"');

        Afirma::igual(304, $respuesta->estado(), 'el estado');
        Afirma::igual('', $respuesta->cuerpo(), 'no transfiere JSON');
        Afirma::igual('"abc123"', $respuesta->cabeceras()['ETag'] ?? null, 'el ETag');
        // Antes decía «private, no-cache»: iOS guardaba el catálogo y, ante
        // este 304, entregaba su copia vieja como respuesta nueva (bitácora 107).
        Afirma::igual('no-store', $respuesta->cabeceras()['Cache-Control'] ?? null, 'no se guarda');
    },

    'lo que contesta la API no se guarda en ninguna caché' => function (): void {
        Afirma::igual('no-store', Respuesta::json(['id' => 7])->cabeceras()['Cache-Control'] ?? null, 'el éxito');
        Afirma::igual('no-store', Respuesta::jsonError(404, 'no_encontrado', 'No existe')->cabeceras()['Cache-Control'] ?? null, 'el error');
    },

    'cada error con nombre lleva su código honesto' => function (): void {
        $esperados = [
            400 => Errores::peticionInvalida(),
            401 => Errores::noAutenticado(),
            403 => Errores::prohibido(),
            404 => Errores::noEncontrado(),
            405 => Errores::metodoNoPermitido(),
            409 => Errores::conflicto(),
            419 => Errores::marcaInvalida(),
            422 => Errores::datosInvalidos(['nombre' => 'Es obligatorio']),
            429 => Errores::demasiadosIntentos(60),
        ];

        foreach ($esperados as $codigo => $error) {
            Afirma::igual($codigo, $error->estado(), 'el código de ' . $error->clave());
        }
    },

    'un error del usuario nunca sale como 500' => function () use ($manejador, $peticion): void {
        foreach ([400, 401, 403, 404, 405, 409, 419, 422, 429] as $codigo) {
            $error     = new Nucleo\Errores\ErrorHttp($codigo, 'Da igual el mensaje');
            $respuesta = $manejador->aRespuesta($error, $peticion(true));

            Afirma::igual($codigo, $respuesta->estado(), 'el estado');
            Afirma::falso($respuesta->estado() === 500, 'salió como 500');
        }
    },

    'el 422 dice qué campo está mal' => function () use ($manejador, $peticion): void {
        $error     = Errores::datosInvalidos(['cantidad' => 'Debe ser mayor que cero']);
        $respuesta = $manejador->aRespuesta($error, $peticion(true));
        $cuerpo    = json_decode($respuesta->cuerpo(), true);

        Afirma::igual(422, $respuesta->estado(), 'el estado');
        Afirma::igual('Debe ser mayor que cero', $cuerpo['error']['campos']['cantidad'], 'el campo');
    },

    'el límite de acceso lleva clave uniforme y Retry-After' => function () use ($manejador, $peticion): void {
        $respuesta = $manejador->aRespuesta(Errores::demasiadosIntentos(37), $peticion(true));
        $cuerpo = json_decode($respuesta->cuerpo(), true);

        Afirma::igual(429, $respuesta->estado(), 'el estado');
        Afirma::igual('demasiados_intentos', $cuerpo['error']['clave'], 'la clave');
        Afirma::igual('37', $respuesta->cabeceras()['Retry-After'] ?? null, 'Retry-After');
    },

    'una excepción cualquiera sale como 500 sin contar nada' => function () use ($manejador, $peticion): void {
        $respuesta = $manejador->aRespuesta(
            new RuntimeException('SELECT clave_hash FROM usuario WHERE id = 1'),
            $peticion(true)
        );
        $cuerpo = $respuesta->cuerpo();

        Afirma::igual(500, $respuesta->estado(), 'el estado');
        Afirma::falso(str_contains($cuerpo, 'SELECT'), 'se filtró el SQL');
        Afirma::falso(str_contains($cuerpo, 'clave_hash'), 'se filtró un nombre de columna');
        Afirma::falso(str_contains($cuerpo, '.php'), 'se filtró una ruta de archivo');
    },

    'una excepción en el navegador tampoco enseña la traza' => function () use ($manejador, $peticion): void {
        $respuesta = $manejador->aRespuesta(new RuntimeException('cosa interna'), $peticion(false));
        $cuerpo    = $respuesta->cuerpo();

        Afirma::igual(500, $respuesta->estado(), 'el estado');
        Afirma::contiene('<!doctype html>', $cuerpo, 'es una página');
        Afirma::falso(str_contains($cuerpo, 'cosa interna'), 'se filtró el mensaje interno');
        Afirma::falso(str_contains($cuerpo, '#0 '), 'se filtró la traza');
    },

    'la ruta de la API responde en JSON aunque nadie pida JSON' => function () use ($manejador, $peticion): void {
        $respuesta = $manejador->aRespuesta(Errores::noEncontrado(), $peticion(true));

        Afirma::igual(
            'application/json; charset=utf-8',
            $respuesta->cabeceras()['Content-Type'],
            'el tipo de contenido'
        );
    },

    'el 404 del navegador es nuestra página, no la del servidor' => function () use ($manejador, $peticion): void {
        $respuesta = $manejador->aRespuesta(Errores::noEncontrado(), $peticion(false));

        Afirma::igual(404, $respuesta->estado(), 'el estado');
        Afirma::contiene('El Timón', $respuesta->cuerpo(), 'la página');
        Afirma::falso(str_contains($respuesta->cuerpo(), 'Apache'), 'se filtró el servidor');
    },

    'el mensaje del error se escapa antes de pintarse' => function () use ($manejador, $peticion): void {
        $respuesta = $manejador->aRespuesta(
            Errores::noEncontrado('<script>alert(1)</script>'),
            $peticion(false)
        );

        Afirma::falso(str_contains($respuesta->cuerpo(), '<script>alert'), 'se coló el guion');
        Afirma::contiene('&lt;script&gt;', $respuesta->cuerpo(), 'quedó escapado');
    },

    'un archivo en flujo se escribe por partes y en orden al enviarse' => function (): void {
        $respuesta = Respuesta::flujo(static function (callable $emite): void {
            $emite('uno,');
            $emite('dos');
        }, 'text/csv; charset=utf-8')->conCabecera('Content-Disposition', 'attachment; filename="x.csv"');

        Afirma::cierto($respuesta->esFlujo(), 'conserva el flujo al agregar cabeceras');
        Afirma::igual('', $respuesta->cuerpo(), 'no junta el cuerpo en memoria');
        Afirma::falso(isset($respuesta->cabeceras()['Content-Length']), 'no anuncia un largo que no conoce');
        ob_start();
        $respuesta->enviar();
        Afirma::igual('uno,dos', (string) ob_get_clean(), 'lo emitido');
    },
];
