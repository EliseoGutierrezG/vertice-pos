<?php
declare(strict_types=1);

use Nucleo\Csrf;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Middleware\ExigeMarca;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use Pruebas\Afirma;

/**
 * La marca contra peticiones forjadas desde otro sitio.
 *
 * GET no la pide —por definición no cambia nada—. Todo lo demás sí, y sin
 * lista de rutas exentas: una lista de excepciones es exactamente por donde
 * se cuela el descuido.
 */

$sesion = new Sesion(soloHttps: false);
$csrf   = new Csrf($sesion);

/** @param array<string,mixed> $cuerpo */
$peticion = function (string $metodo, array $cuerpo = [], ?string $cabecera = null): Peticion {
    $_SERVER['REQUEST_METHOD'] = $metodo;
    $_SERVER['REQUEST_URI']    = '/usuarios';
    $_SERVER['REMOTE_ADDR']    = '127.0.0.1';
    $_GET  = [];
    $_POST = $cuerpo;
    unset($_SERVER['CONTENT_TYPE'], $_SERVER['HTTP_X_MARCA']);

    if ($cabecera !== null) {
        $_SERVER['HTTP_X_MARCA'] = $cabecera;
    }

    return Peticion::desdeGlobales();
};

$sigue = static fn (Peticion $p): Respuesta => Respuesta::json(['llegó' => true]);

return [
    'la marca se genera una vez y se conserva' => function () use ($csrf): void {
        $primera = $csrf->marca();
        $segunda = $csrf->marca();

        Afirma::igual($primera, $segunda, 'la marca');
        Afirma::igual(64, strlen($primera), 'la longitud en caracteres');
    },

    'el campo oculto lleva la marca escapada' => function () use ($csrf): void {
        Afirma::contiene('name="_marca"', $csrf->campo(), 'el campo');
        Afirma::contiene($csrf->marca(), $csrf->campo(), 'el valor');
    },

    'la marca correcta pasa' => function () use ($csrf): void {
        $csrf->valida($csrf->marca());
        Afirma::cierto(true, 'no lanzó');
    },

    'una marca equivocada da 419' => function () use ($csrf): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $csrf->valida(str_repeat('a', 64)));

        Afirma::igual(419, $error->getCode(), 'el código');
    },

    'una marca ausente da 419' => function () use ($csrf): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $csrf->valida(null));

        Afirma::igual(419, $error->getCode(), 'el código');
    },

    'una marca vacía da 419' => function () use ($csrf): void {
        $error = Afirma::lanza(ErrorHttp::class, fn () => $csrf->valida(''));

        Afirma::igual(419, $error->getCode(), 'el código');
    },

    'un GET no pide marca' => function () use ($csrf, $peticion, $sigue): void {
        $respuesta = (new ExigeMarca($csrf))->maneja($peticion('GET'), $sigue);

        Afirma::igual(200, $respuesta->estado(), 'el estado');
    },

    'un POST sin marca se rechaza con 419' => function () use ($csrf, $peticion, $sigue): void {
        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => (new ExigeMarca($csrf))->maneja($peticion('POST'), $sigue)
        );

        Afirma::igual(419, $error->getCode(), 'el código');
    },

    'un POST con la marca en el formulario pasa' => function () use ($csrf, $peticion, $sigue): void {
        $respuesta = (new ExigeMarca($csrf))->maneja(
            $peticion('POST', ['_marca' => $csrf->marca()]),
            $sigue
        );

        Afirma::igual(200, $respuesta->estado(), 'el estado');
    },

    'un POST con la marca en la cabecera también pasa' => function () use ($csrf, $peticion, $sigue): void {
        $respuesta = (new ExigeMarca($csrf))->maneja(
            $peticion('POST', [], $csrf->marca()),
            $sigue
        );

        Afirma::igual(200, $respuesta->estado(), 'el estado');
    },

    'DELETE tampoco se libra de la marca' => function () use ($csrf, $peticion, $sigue): void {
        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => (new ExigeMarca($csrf))->maneja($peticion('DELETE'), $sigue)
        );

        Afirma::igual(419, $error->getCode(), 'el código');
    },
];
