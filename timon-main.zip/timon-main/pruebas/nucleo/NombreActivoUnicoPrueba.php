<?php
declare(strict_types=1);

use Nucleo\BaseDatos;
use Nucleo\Errores\ErrorHttp;
use Pruebas\Afirma;

/**
 * Un solo nombre y una sola clave activos por sucursal (esquema/002).
 *
 * La base rechaza dos activas con el mismo nombre aunque la escritura no pase
 * por el servicio, y deja que una inactiva repita el nombre de otra.
 */

$config = Nucleo\Configuracion::baseDatos(dirname(__DIR__, 2));
$bd     = new BaseDatos($config);

$nombre = 'Prueba nombre activo ' . bin2hex(random_bytes(3));
$limpia = function () use ($bd, $nombre): void {
    $bd->ejecuta('DELETE FROM sucursal WHERE nombre = ?', [$nombre]);
};

return [
    'dos sucursales activas con el mismo nombre chocan en la base' => function () use ($bd, $nombre, $limpia): void {
        try {
            $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', [$nombre]);
            $error = Afirma::lanza(ErrorHttp::class, fn () => $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', [mb_strtoupper($nombre)]));
            Afirma::igual(409, $error->getCode(), 'sin importar mayúsculas, es conflicto');
        } finally {
            $limpia();
        }
    },

    'una sucursal inactiva sí repite el nombre de una activa' => function () use ($bd, $nombre, $limpia): void {
        try {
            $bd->inserta('INSERT INTO sucursal (nombre, id_estatus) VALUES (?, 3)', [$nombre]);
            $bd->inserta('INSERT INTO sucursal (nombre, id_estatus) VALUES (?, 3)', [$nombre]);
            $bd->inserta('INSERT INTO sucursal (nombre) VALUES (?)', [$nombre]);
            Afirma::igual(3, (int) $bd->valor('SELECT COUNT(*) FROM sucursal WHERE nombre = ?', [$nombre]));
            $error = Afirma::lanza(ErrorHttp::class, fn () => $bd->ejecuta('UPDATE sucursal SET id_estatus = 4 WHERE nombre = ? AND id_estatus = 3 LIMIT 1', [$nombre]));
            Afirma::igual(409, $error->getCode(), 'reactivar una repetida también choca');
        } finally {
            $limpia();
        }
    },

    'dos sucursales activas con la misma clave chocan en la base' => function () use ($bd, $nombre, $limpia): void {
        $clave = strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        try {
            $bd->inserta('INSERT INTO sucursal (nombre, clave) VALUES (?, ?)', [$nombre, $clave]);
            $error = Afirma::lanza(ErrorHttp::class, fn () => $bd->inserta('INSERT INTO sucursal (nombre, clave) VALUES (?, ?)', [$nombre . ' 2', $clave]));
            Afirma::igual(409, $error->getCode(), 'es conflicto');
        } finally {
            $bd->ejecuta('DELETE FROM sucursal WHERE nombre LIKE ?', [$nombre . '%']);
        }
    },
];
