<?php
declare(strict_types=1);

use Nucleo\MigracionesEsquema;
use Pruebas\Afirma;

$raiz = dirname(__DIR__, 2);

return [
    'el inventario de migraciones es continuo y empieza en el consolidado' => function () use ($raiz): void {
        $inventario = MigracionesEsquema::inventario($raiz . '/esquema');
        $ultima = (int) array_key_last($inventario);
        Afirma::cierto($ultima >= 6, 'llega al menos al 006');
        Afirma::igual(range(1, $ultima), array_keys($inventario), 'sin huecos');
        Afirma::igual('001_catalogos.sql', $inventario[1]['nombre']);
        Afirma::igual('006_datos_base.sql', $inventario[6]['nombre']);
        Afirma::igual(64, strlen($inventario[6]['sha256']));
    },
    'una migración aplicada que cambia de huella detiene el avance' => function (): void {
        $inventario = [
            1 => ['numero' => 1, 'nombre' => '001_uno.sql', 'ruta' => '/tmp/001_uno.sql', 'sha256' => str_repeat('a', 64)],
            2 => ['numero' => 2, 'nombre' => '002_dos.sql', 'ruta' => '/tmp/002_dos.sql', 'sha256' => str_repeat('b', 64)],
        ];
        $estado = MigracionesEsquema::compara($inventario, [[
            'numero' => 1,
            'nombre' => '001_uno.sql',
            'sha256' => str_repeat('c', 64),
        ]]);
        Afirma::igual(1, count($estado['errores']));
        Afirma::igual([2], array_column($estado['pendientes'], 'numero'));
    },
    'una migración registrada sin archivo también es corrupción' => function (): void {
        $inventario = [
            1 => ['numero' => 1, 'nombre' => '001_uno.sql', 'ruta' => '/tmp/001_uno.sql', 'sha256' => str_repeat('a', 64)],
        ];
        $estado = MigracionesEsquema::compara($inventario, [[
            'numero' => 2,
            'nombre' => '002_perdida.sql',
            'sha256' => str_repeat('b', 64),
        ]]);
        Afirma::igual(1, count($estado['errores']));
        Afirma::igual([1], array_column($estado['pendientes'], 'numero'));
    },
    'una secuencia de archivos con un hueco se rechaza' => function (): void {
        $directorio = sys_get_temp_dir() . '/migraciones-hueco-' . bin2hex(random_bytes(4));
        mkdir($directorio, 0700, true);
        file_put_contents($directorio . '/001_uno.sql', 'SELECT 1;');
        file_put_contents($directorio . '/003_tres.sql', 'SELECT 3;');
        try {
            $error = Afirma::lanza(RuntimeException::class, fn () => MigracionesEsquema::inventario($directorio));
            Afirma::contiene('se esperaba 002', $error->getMessage());
        } finally {
            unlink($directorio . '/001_uno.sql');
            unlink($directorio . '/003_tres.sql');
            rmdir($directorio);
        }
    },
];
