<?php
declare(strict_types=1);

use Nucleo\Errores\ErrorHttp;
use Nucleo\Peticion;
use Nucleo\Router;
use Pruebas\Afirma;

/**
 * El router: parámetros, verbos y los dos códigos que se confunden
 * todo el tiempo, 404 y 405.
 */

/** Arma una petición como si hubiera entrado por el servidor. */
$peticion = function (string $metodo, string $ruta): Peticion {
    $_SERVER['REQUEST_METHOD'] = $metodo;
    $_SERVER['REQUEST_URI']    = $ruta;
    $_SERVER['REMOTE_ADDR']    = '127.0.0.1';
    $_GET = [];
    $_POST = [];

    return Peticion::desdeGlobales();
};

return [
    'una ruta sin parámetros resuelve al destino declarado' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/pedidos', ['Controlador', 'lista']);

        [$ruta, $parametros] = $r->resuelve($peticion('GET', '/pedidos'));

        Afirma::igual(['Controlador', 'lista'], $ruta->destino(), 'el destino');
        Afirma::igual([], $parametros, 'los parámetros');
    },

    'una ruta con parámetro entrega su valor' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/pedidos/{id}', ['Controlador', 'ver']);

        [, $parametros] = $r->resuelve($peticion('GET', '/pedidos/482'));

        Afirma::igual(['id' => '482'], $parametros, 'los parámetros');
    },

    'el parámetro llega a la petición y se puede leer por nombre' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/pedidos/{id}', ['Controlador', 'ver']);

        $entrante = $peticion('GET', '/pedidos/482');
        [, $parametros] = $r->resuelve($entrante);

        Afirma::igual('482', $entrante->conParametros($parametros)->parametro('id'), 'el id');
    },

    'varios parámetros en una misma ruta se separan bien' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/hojas/{fecha}/pedidos/{id}', ['Controlador', 'ver']);

        [, $parametros] = $r->resuelve($peticion('GET', '/hojas/2026-09-23/pedidos/7'));

        Afirma::igual(['fecha' => '2026-09-23', 'id' => '7'], $parametros, 'los parámetros');
    },

    'un parámetro con forma sólo acepta lo que dice su forma' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/pedidos/{id:\d+}', ['Controlador', 'ver']);

        [, $parametros] = $r->resuelve($peticion('GET', '/pedidos/482'));
        Afirma::igual(['id' => '482'], $parametros, 'con dígitos');

        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => $r->resuelve($peticion('GET', '/pedidos/abc')),
            'con letras'
        );
        Afirma::igual(404, $error->getCode(), 'el código');
    },

    'un parámetro no se come la barra siguiente' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/clientes/{id}', ['Controlador', 'ver']);

        $error = Afirma::lanza(
            ErrorHttp::class,
            fn () => $r->resuelve($peticion('GET', '/clientes/7/pedidos'))
        );
        Afirma::igual(404, $error->getCode(), 'el código');
    },

    'una ruta que no existe es 404' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/pedidos', ['Controlador', 'lista']);

        $error = Afirma::lanza(ErrorHttp::class, fn () => $r->resuelve($peticion('GET', '/inventado')));

        Afirma::igual(404, $error->getCode(), 'el código');
    },

    'la ruta correcta con el verbo equivocado es 405, no 404' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/pedidos', ['Controlador', 'lista']);

        $error = Afirma::lanza(ErrorHttp::class, fn () => $r->resuelve($peticion('POST', '/pedidos')));

        Afirma::igual(405, $error->getCode(), 'el código');
        Afirma::contiene('GET', $error->getMessage(), 'el mensaje dice qué verbo acepta');
    },

    'la misma ruta con dos verbos lleva a destinos distintos' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/pedidos', ['Controlador', 'lista']);
        $r->post('/pedidos', ['Controlador', 'crea']);

        [$conGet]  = $r->resuelve($peticion('GET', '/pedidos'));
        [$conPost] = $r->resuelve($peticion('POST', '/pedidos'));

        Afirma::igual('lista', $conGet->destino()[1], 'el GET');
        Afirma::igual('crea', $conPost->destino()[1], 'el POST');
    },

    'un grupo pone su prefijo y sus intermediarios en cada ruta' => function () use ($peticion): void {
        $r = new Router();
        $r->grupo('/api/v1', ['token', 'dispositivo'], function (Router $r): void {
            $r->get('/pedidos', ['Controlador', 'lista'])->protege('permiso:pedidos_ver');
        });

        [$ruta] = $r->resuelve($peticion('GET', '/api/v1/pedidos'));

        Afirma::igual('/api/v1/pedidos', $ruta->patron(), 'el patrón');
        Afirma::igual(
            ['token', 'dispositivo', 'permiso:pedidos_ver'],
            $ruta->intermediarios(),
            'los intermediarios, en orden'
        );
    },

    'lo que el grupo protege no se filtra a las rutas de fuera' => function () use ($peticion): void {
        $r = new Router();
        $r->grupo('/api/v1', ['token'], function (Router $r): void {
            $r->get('/pedidos', ['Controlador', 'lista']);
        });
        $r->get('/', ['Controlador', 'inicio']);

        [$fuera] = $r->resuelve($peticion('GET', '/'));

        Afirma::igual([], $fuera->intermediarios(), 'los intermediarios de la raíz');
    },

    'la barra final sobrante no cambia la ruta' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/pedidos', ['Controlador', 'lista']);

        [$ruta] = $r->resuelve($peticion('GET', '/pedidos/'));

        Afirma::igual('/pedidos', $ruta->patron(), 'el patrón');
    },

    'la cadena de consulta no forma parte de la ruta' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/pedidos', ['Controlador', 'lista']);

        [$ruta] = $r->resuelve($peticion('GET', '/pedidos?desde=2026-09-01'));

        Afirma::igual('/pedidos', $ruta->patron(), 'el patrón');
    },

    'un punto en el patrón no equivale a cualquier carácter' => function () use ($peticion): void {
        $r = new Router();
        $r->get('/archivo.json', ['Controlador', 'ver']);

        $error = Afirma::lanza(ErrorHttp::class, fn () => $r->resuelve($peticion('GET', '/archivoXjson')));
        Afirma::igual(404, $error->getCode(), 'el código');
    },
];
