<?php
declare(strict_types=1);

use Nucleo\Exporta\Pdf;
use Nucleo\Exporta\Tabla;
use Pruebas\Afirma;

/**
 * El PDF de reportes con la línea D24 (2026-11-10): banda del primario,
 * nombre de la instalación y neutros del panel. Los flujos van sin comprimir,
 * así que lo que se dibuja se puede buscar en el archivo.
 */
$tabla = static fn (int $filas = 3): Tabla => new Tabla(
    titulo: 'Ventas del día',
    encabezados: ['Cliente', 'Importe'],
    filas: array_map(static fn (int $i): array => ["Cliente {$i}", number_format($i * 10.5, 2)], range(1, $filas)),
    pie: ['Total', '63.00'],
    subtitulo: 'Del 10/11/2026 al 10/11/2026'
);

return [
    'sin marca propia sale con la banda marina y el nombre de la marca' => function () use ($tabla): void {
        Pdf::marca('Base', '#172D4D');
        $pdf = Pdf::de($tabla());
        Afirma::cierto(str_starts_with($pdf, '%PDF-'), 'abre como PDF');
        Afirma::contiene('0.090 0.176 0.302 rg', $pdf, 'la banda es marina');
        Afirma::contiene('(Base) Tj', $pdf, 'el nombre a la derecha del título');
        Afirma::contiene('(Base · ', str_replace("\xB7", '·', $pdf), 'y en el pie');
        Afirma::contiene('0.980 0.973 0.953 rg', $pdf, 'encabezado de tabla con el neutro del panel');
        Afirma::contiene('0.890 0.867 0.816 RG', $pdf, 'filetes con el borde del panel');
    },

    'una marca propia cambia el color de la banda y el nombre' => function () use ($tabla): void {
        Pdf::marca('Ejemplo', '#14532D');
        $pdf = Pdf::de($tabla());
        Afirma::contiene('0.078 0.325 0.176 rg', $pdf);
        Afirma::contiene('(Ejemplo) Tj', $pdf);
        Pdf::marca('Base', '#172D4D');
    },

    'un color o un nombre raros no entran al archivo' => function () use ($tabla): void {
        Pdf::marca('Base', '#172D4D');
        Pdf::marca(str_repeat('x', 61), 'red) Tj (inyectado');
        $pdf = Pdf::de($tabla());
        Afirma::cierto(!str_contains($pdf, 'inyectado'), 'el color inválido se ignora');
        Afirma::contiene('(Base) Tj', $pdf, 'el nombre largo se ignora');
        Afirma::contiene('0.090 0.176 0.302 rg', $pdf);
    },

    'la banda se repite en cada página' => function () use ($tabla): void {
        Pdf::marca('Base', '#172D4D');
        $pdf = Pdf::de($tabla(140));
        $paginas = substr_count($pdf, '/Type /Page ');
        Afirma::cierto($paginas >= 2, 'el reporte largo ocupa varias páginas');
        Afirma::igual($paginas, substr_count($pdf, '0.090 0.176 0.302 rg'));
    },
];
