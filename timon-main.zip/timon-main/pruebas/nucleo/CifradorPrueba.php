<?php
declare(strict_types=1);

use Nucleo\Seguridad\Cifrador;
use Pruebas\Afirma;

$cifrador = new Cifrador(base64_encode(str_repeat('k', 32)));

return [
    'AES-GCM recupera el secreto sin guardarlo en claro' => function () use ($cifrador): void {
        $sobre = $cifrador->cifra('SECRETO-TOTP-123');
        Afirma::falso(str_contains($sobre, 'SECRETO-TOTP-123'));
        Afirma::igual('SECRETO-TOTP-123', $cifrador->descifra($sobre));
    },
    'la etiqueta GCM detecta cualquier alteración' => function () use ($cifrador): void {
        $sobre = $cifrador->cifra('secreto');
        $partes = explode('.', $sobre);
        $partes[2][0] = $partes[2][0] === 'A' ? 'B' : 'A';
        $alterado = implode('.', $partes);
        Afirma::lanza(\RuntimeException::class, fn () => $cifrador->descifra($alterado));
    },
];
