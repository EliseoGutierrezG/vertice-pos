<?php
declare(strict_types=1);

use Nucleo\Exporta\Csv;
use Nucleo\Exporta\Tabla;
use Pruebas\Afirma;

/**
 * El CSV que el dueño abre de doble clic.
 *
 * Lo que se sostiene aquí no es el formato, es que **el reporte diga lo que la
 * pantalla dijo**. Un exportador que se come un nombre o convierte un importe
 * en texto entrega un reporte que no cuadra con la pantalla de la que salió, y
 * eso no se nota leyendo el código: se nota en Excel.
 */

$una = static fn (array $filas): string => Csv::de(new Tabla(
    titulo: 'Prueba',
    encabezados: ['Cliente', 'Importe'],
    filas: $filas
));

return [
    'una celda con coma viaja entera, entrecomillada' => function () use ($una): void {
        // Sin esto Excel parte «1,234.50» en dos columnas y el reporte se corre.
        Afirma::contiene('"1,234.50"', $una([['Tienda', '1,234.50']]), 'el importe con miles');
    },

    'las comillas se duplican' => function () use ($una): void {
        Afirma::contiene('"Tienda ""La Esquina"""', $una([['Tienda "La Esquina"', '1.00']]));
    },

    'lo que Excel leería como fórmula deja de parecerlo' => function () use ($una): void {
        // ⚠️ Medido con el exportador tal como estaba: un cliente llamado
        // «- sin ruta -» salía como #NAME? y uno llamado «=1+1» salía como 2.
        // El nombre desaparecía del reporte sin que nada avisara.
        foreach (['=1+1', '- sin ruta -', '@casa del norte', '+Sucursal centro'] as $nombre) {
            Afirma::contiene("'" . $nombre, $una([[$nombre, '1.00']]), 'el nombre «' . $nombre . '»');
        }
    },

    'pero un importe negativo sigue siendo un número' => function () use ($una): void {
        // El caso que hace que la regla no pueda ser «todo lo que empiece con
        // menos»: el reporte de movimientos escribe las mermas con signo, y un
        // número entrecomillado como texto ya no suma en Excel.
        $csv = $una([['Merma', '-12.000'], ['Ajuste', '-1,234.50'], ['Baja', '-0.5%']]);

        Afirma::contiene('Merma,-12.000', $csv, 'la merma');
        Afirma::contiene('Ajuste,"-1,234.50"', $csv, 'el ajuste con miles');
        Afirma::contiene('Baja,-0.5%', $csv, 'el porcentaje');
        Afirma::falso(str_contains($csv, "'-"), 'algún número quedó convertido en texto');
    },

    'el BOM va al principio, o los acentos se ven mal' => function () use ($una): void {
        Afirma::cierto(
            str_starts_with($una([['Jalapeño', '1.00']]), "\xEF\xBB\xBF"),
            'falta el BOM: Excel leería «JalapeÃ±o»'
        );
    },

    'y los renglones terminan como el formato pide' => function () use ($una): void {
        Afirma::contiene("\r\n", $una([['Tienda', '1.00']]), 'el fin de línea de Windows');
    },
];
