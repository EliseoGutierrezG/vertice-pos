#!/usr/bin/env bash
# Ensayo de la auditoría de cierre sobre un paquete extraído y la base aislada.
# Todo lo que escribe vive en un temporal; la base sólo se lee.

set -u

RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
PHP=/opt/homebrew/opt/php@8.3/bin/php
export PATH="$(dirname "$PHP"):/opt/homebrew/opt/mysql-client/bin:$PATH"
export APP_ENTORNO=pruebas
. "$RAIZ/pruebas/exige-entorno.sh"

TEMPORAL=$(mktemp -d)
trap 'rm -rf "$TEMPORAL"' EXIT

bash "$RAIZ/guiones/prepara-despliegue-subdominio.sh" "$TEMPORAL/salida" > /dev/null 2>&1 || {
  echo "No se pudo armar el paquete temporal." >&2
  exit 1
}
mkdir -p "$TEMPORAL/host"
tar -xzf "$TEMPORAL/salida/app-subdominio-candidato.tar.gz" -C "$TEMPORAL/host"
PRIVADO="$TEMPORAL/host/.app"

for tipo in app bd seguridad respaldo alertas; do
  cp "$RAIZ/config/$tipo.pruebas.php" "$PRIVADO/config/$tipo.pruebas.php"
  chmod 600 "$PRIVADO/config/$tipo.pruebas.php"
done

# El verificador se ejecuta después del retiro de transportes. En este ensayo
# se quitan únicamente los archivos recién extraídos dentro del temporal.
rm -f \
  "$PRIVADO/instalacion/app-esquema.sql" \
  "$PRIVADO/instalacion/app-esquema.sql.sha256" \
  "$PRIVADO/instalacion/app-esquema.sql.json"

"$PHP" "$PRIVADO/guiones/tarea.php" respaldo --cifrar --cuantos=1 > /dev/null 2>&1 || {
  echo "No se pudo crear el respaldo temporal del ensayo." >&2
  exit 1
}
"$PHP" "$PRIVADO/guiones/tarea.php" mantenimiento --ensayo > /dev/null 2>&1 || {
  echo "No se pudo ejecutar el mantenimiento en ensayo." >&2
  exit 1
}

"$PHP" "$PRIVADO/guiones/verifica-cierre-host.php" --perfil=pruebas --max-horas=2
