#!/usr/bin/env bash
# Prueba de humo contra el servidor de verdad.
#
#   pruebas/humo.sh                              contra el entorno local
#   pruebas/humo.sh https://timon.example ID 36   contra producción (fase 21)
#
# Las pruebas del corredor de PHP comprueban las piezas por dentro. Esto
# comprueba lo que sale por el cable: los códigos, el sobre y que nada de
# fuera de publico/ sea alcanzable.

set -u
BASE="${1:-http://127.0.0.1:8081}"
ESPERA_LIBERACION="${2:-}"
ESPERA_ESQUEMA="${3:-}"

if [ "$#" -eq 2 ] || [ "$#" -gt 3 ]; then
  echo "Uso: $0 [BASE [LIBERACION ESQUEMA]]" >&2
  exit 2
fi
if [ -n "$ESPERA_LIBERACION" ]; then
  if ! [[ "$ESPERA_LIBERACION" =~ ^[A-Za-z0-9._:-]{3,100}$ ]]; then
    echo "El identificador de liberación esperado no tiene un formato válido." >&2
    exit 2
  fi
  if ! [[ "$ESPERA_ESQUEMA" =~ ^[0-9]+$ ]] || [ "$ESPERA_ESQUEMA" -lt 1 ]; then
    echo "La versión de esquema esperada debe ser un entero positivo." >&2
    exit 2
  fi
  case "$BASE" in
    https://*) ;;
    http://127.0.0.1:*|http://localhost:*) ;;
    *) echo "La comprobación con huella sólo acepta HTTPS o el servidor local." >&2; exit 2 ;;
  esac
  case "$BASE:$ESPERA_LIBERACION" in
    http://127.0.0.1:*:sin-identificar|http://localhost:*:sin-identificar) ;;
    *:sin-identificar) echo "Producción no puede cerrarse como sin-identificar." >&2; exit 2 ;;
  esac
fi

verde=$'\033[32m'; rojo=$'\033[31m'; gris=$'\033[90m'; nada=$'\033[0m'
pasadas=0; fallas=0

# codigo METODO RUTA ESPERADO
codigo() {
  local obtenido
  obtenido=$(curl -s -m 10 -o /dev/null -w "%{http_code}" -X "$1" "$BASE$2")
  if [ "$obtenido" = "$3" ]; then
    printf "  %s✓%s %-6s %-32s %s\n" "$verde" "$nada" "$1" "$2" "$3"
    pasadas=$((pasadas + 1))
  else
    printf "  %s✗%s %-6s %-32s esperaba %s, llegó %s\n" "$rojo" "$nada" "$1" "$2" "$3" "$obtenido"
    fallas=$((fallas + 1))
  fi
}

# codigo_privado RUTA — un servidor puede negar antes de PHP (403) o dejar que
# el enrutador oculte la ruta (404); cualquiera protege, 200 no.
codigo_privado() {
  local obtenido
  obtenido=$(curl -s -m 10 -o /dev/null -w "%{http_code}" "$BASE$1")
  case "$obtenido" in
    403|404)
      printf "  %s✓%s %-39s %s\n" "$verde" "$nada" "$1" "$obtenido"
      pasadas=$((pasadas + 1))
      ;;
    *)
      printf "  %s✗%s %-39s esperaba 403/404, llegó %s\n" "$rojo" "$nada" "$1" "$obtenido"
      fallas=$((fallas + 1))
      ;;
  esac
}

# contiene RUTA TEXTO descripción
contiene() {
  local cuerpo
  cuerpo=$(curl -s -m 10 "$BASE$1")
  if printf '%s' "$cuerpo" | grep -q -- "$2"; then
    printf "  %s✓%s %s\n" "$verde" "$nada" "$3"
    pasadas=$((pasadas + 1))
  else
    printf "  %s✗%s %s\n" "$rojo" "$nada" "$3"
    fallas=$((fallas + 1))
  fi
}

# cabecera RUTA NOMBRE VALOR descripción — lo que el servidor promete en el sobre
cabecera() {
  local valor
  valor=$(curl -s -m 10 -D - -o /dev/null "$BASE$1" | grep -i "^$2:" | tr -d '\r' | cut -d' ' -f2-)
  if printf '%s' "$valor" | grep -qi -- "$3"; then
    printf "  %s✓%s %s\n" "$verde" "$nada" "$4"
    pasadas=$((pasadas + 1))
  else
    printf "  %s✗%s %s — %s dijo «%s»\n" "$rojo" "$nada" "$4" "$2" "$valor"
    fallas=$((fallas + 1))
  fi
}

# sin_cabecera RUTA NOMBRE descripción — lo que el servidor NO debe contar
sin_cabecera() {
  local valor
  valor=$(curl -s -m 10 -D - -o /dev/null "$BASE$1" | grep -ci "^$2:")
  if [ "$valor" = "0" ]; then
    printf "  %s✓%s %s\n" "$verde" "$nada" "$3"
    pasadas=$((pasadas + 1))
  else
    printf "  %s✗%s %s\n" "$rojo" "$nada" "$3"
    fallas=$((fallas + 1))
  fi
}

# no_contiene RUTA TEXTO descripción
no_contiene() {
  local cuerpo
  cuerpo=$(curl -s -m 10 "$BASE$1")
  if printf '%s' "$cuerpo" | grep -q -- "$2"; then
    printf "  %s✗%s %s\n" "$rojo" "$nada" "$3"
    fallas=$((fallas + 1))
  else
    printf "  %s✓%s %s\n" "$verde" "$nada" "$3"
    pasadas=$((pasadas + 1))
  fi
}

# igual VALOR ESPERADO DESCRIPCIÓN — para los campos públicos del latido.
igual() {
  if [ "$1" = "$2" ]; then
    printf "  %s✓%s %s\n" "$verde" "$nada" "$3"
    pasadas=$((pasadas + 1))
  else
    printf "  %s✗%s %s — esperaba «%s», llegó «%s»\n" \
      "$rojo" "$nada" "$3" "$2" "$1"
    fallas=$((fallas + 1))
  fi
}

echo "${gris}Contra ${BASE}${nada}"

echo "${gris}rutas que existen${nada}"
codigo GET  /entrar                  200
codigo GET  /api/v1/salud            200

echo "${gris}la raíz${nada}"
# Con `sitio/` (el subdominio, 2026-11-08 C1) la raíz es la landing estática;
# sin ella —en local— manda al panel. Las dos son válidas; lo que no vale es
# que la raíz enseñe el panel o un error.
RAIZ_CODIGO=$(curl -s -m 10 -o /dev/null -w '%{http_code}' "$BASE/")
if [ "$RAIZ_CODIGO" = "200" ]; then
  contiene / 'Mariscos frescos, servicio de puerto' 'la raíz es la landing'
  no_contiene / 'Entrar al sistema' 'la landing no anuncia la entrada del panel'
  no_contiene / 'csrf-token' 'y no es una pantalla del panel'
  cabecera / 'Content-Security-Policy' "script-src 'self'" 'la landing solo ejecuta guiones propios'
  cabecera / 'X-Frame-Options' 'DENY' 'ni se deja meter en un marco'
  contiene / 'id="carta-portada"' 'la landing trae el menú completo'
  codigo GET /api/v1/menu-publico/NOEXISTE 404
  # Staging bloquea el sitio entero; producción aparta el panel. Ambas reglas
  # impiden rastrear el panel. La comprobación específica de staging exige /.
  contiene /robots.txt '^Disallow:[[:space:]]*/\(panel\)\{0,1\}[[:space:]]*$' 'robots.txt aparta el panel o todo el sitio de los buscadores'
  contiene /sitemap.xml '<urlset' 'el mapa del sitio responde'
  contiene / 'application/ld+json' 'la landing trae datos estructurados'
else
  igual "$RAIZ_CODIGO" 302 'sin landing, la raíz manda al panel'
fi

echo "${gris}sin sesión no se pasa${nada}"
codigo GET  /panel                   302
codigo GET  /bitacora                302
codigo GET  /sistema/diagnostico     302
codigo GET  /api/v1/yo               401
codigo GET  /api/v1/estado           401

echo "${gris}códigos honestos${nada}"
codigo GET  /no-existe               404
codigo GET  /api/v1/no-existe        404
# Una ruta que existe y está protegida: sin sesión manda a entrar.
codigo GET  /personal/1              302
codigo POST /api/v1/salud            405
codigo PUT  /entrar                  405

echo "${gris}nada fuera de publico/ es alcanzable${nada}"
codigo GET  /config/bd.php                     404
codigo GET  /config/app.php                    404
codigo GET  /nucleo/BaseDatos.php              404
codigo GET  /rutas/api.php                     404
codigo_privado /esquema/001_catalogos.sql
codigo GET  /almacenamiento/registros          404
codigo GET  /almacenamiento/respaldos          404
codigo GET  /CLAUDE.md                         404
codigo GET  /pruebas/correr.php                404
# Las plantillas de configuración no llevan valores de verdad, pero sí dicen la
# forma exacta de lo que el sistema lee. No hay razón para regálarsela a nadie.
codigo GET  /config/bd.php.ejemplo             404
codigo GET  /config/app.php.ejemplo            404

# En el paquete para hosting de raíz única, todo lo privado vive dentro de
# `.app/`. Estas rutas también tienen que quedar negadas por el servidor,
# antes de que PHP o el enrutador alcancen a verlas.
codigo_privado /.app/config/bd.php
codigo_privado /.app/nucleo/BaseDatos.php
codigo_privado /.app/esquema/001_catalogos.sql
codigo_privado /.app/almacenamiento/respaldos/
# `.gz` no está negado por extensión: esta petición prueba que la regla del
# árbol privado cubre también un archivo completo, no sólo el directorio.
codigo_privado /.app/almacenamiento/respaldos/no-debe-ser-publico.sql.gz

# Y un respaldo de verdad, por su nombre completo: es el archivo más delicado
# del proyecto —lleva la operación entera, con nombres, domicilios y teléfonos—
# y `.gz` no está en la lista de extensiones negadas del .htaccess, así que lo
# único que lo protege es vivir fuera de publico/.
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
ULTIMO=$(ls -1t "$RAIZ/almacenamiento/respaldos"/*.sql.gz 2>/dev/null | head -1)
if [ -n "$ULTIMO" ]; then
  codigo_privado "/almacenamiento/respaldos/$(basename "$ULTIMO")"
else
  printf "  %s·%s no hay ningún respaldo guardado que pedirle al servidor\n" "$gris" "$nada"
fi

echo "${gris}el sobre de la respuesta${nada}"
contiene    /api/v1/salud       '"ok":true'            'el éxito trae ok verdadero'
contiene    /api/v1/no-existe   '"ok":false'           'el error trae ok falso'
contiene    /api/v1/no-existe   '"clave":"no_encontrado"' 'el error trae su clave'

# La ruta de salud es la evidencia pública de que el código y el esquema que se
# prepararon son los que realmente quedaron sirviendo. Se lee una sola vez para
# comparar campos del mismo latido y no mezclar una actualización concurrente.
SALUD=$(curl -sS -m 10 "$BASE/api/v1/salud" 2>/dev/null || true)
BASE_SALUD=$(printf '%s' "$SALUD" | sed -nE 's/.*"base"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/p')
igual "$BASE_SALUD" viva 'la API confirma que su base está viva'
if [ -n "$ESPERA_LIBERACION" ]; then
  LIBERACION_SALUD=$(printf '%s' "$SALUD" | sed -nE 's/.*"liberacion"[[:space:]]*:[[:space:]]*"([^"]*)".*/\1/p')
  ESQUEMA_SALUD=$(printf '%s' "$SALUD" | sed -nE 's/.*"esquema"[[:space:]]*:[[:space:]]*([0-9]+).*/\1/p')
  igual "$LIBERACION_SALUD" "$ESPERA_LIBERACION" \
    'la API sirve la liberación que se subió'
  igual "$ESQUEMA_SALUD" "$ESPERA_ESQUEMA" \
    'y la base llegó al esquema esperado'
fi

echo "${gris}nada se filtra${nada}"
no_contiene /no-existe          'Apache'               'el 404 es nuestro, no el del servidor'
no_contiene /no-existe          '\.php'                'el 404 no enseña rutas de archivo'
no_contiene /api/v1/no-existe   'Nucleo\\'             'el error no enseña clases internas'

# --- El sobre de la respuesta, que es lo que mira un navegador ----------------
# Esto vale igual en local y en Hostinger, y es lo que hay que volver a correr
# contra el dominio de verdad en la fase 21: las cabeceras las pone la aplicación,
# no el hospedaje, así que si aquí están, allá también tienen que estar.

echo "${gris}las cabeceras que protegen al navegador${nada}"
cabecera /entrar 'X-Content-Type-Options' 'nosniff' \
  'se le prohíbe al navegador adivinar el tipo de archivo'
cabecera /entrar 'Content-Security-Policy' "default-src 'self'" \
  "la política de contenido va en la respuesta"
cabecera /entrar 'Permissions-Policy' 'camera=()' \
  "los permisos del navegador van apagados"
cabecera /entrar 'Cross-Origin-Opener-Policy' 'same-origin' \
  "el origen va aislado"
cabecera /entrar 'X-Frame-Options' 'DENY' \
  'y meter el sistema dentro de un marco ajeno'
cabecera /entrar 'Referrer-Policy' 'same-origin' \
  'la dirección de la pantalla no se le cuenta a otros sitios'
cabecera /entrar 'Cache-Control' 'no-store' \
  'y una pantalla con sesión no se queda guardada'

echo "${gris}y lo que el servidor NO debe contar${nada}"
sin_cabecera /entrar 'X-Powered-By' 'no anuncia la versión de PHP'
sin_cabecera /api/v1/salud 'X-Powered-By' 'ni en la API'

echo "${gris}la cookie de sesión${nada}"
GALLETA=$(curl -s -m 10 -D - -o /dev/null "$BASE/entrar" | grep -i '^set-cookie:' | tr -d '\r')
for QUE in HttpOnly SameSite Path; do
  if printf '%s' "$GALLETA" | grep -qi -- "$QUE"; then
    printf "  %s✓%s la cookie lleva %s\n" "$verde" "$nada" "$QUE"; pasadas=$((pasadas + 1))
  else
    printf "  %s✗%s la cookie lleva %s\n" "$rojo" "$nada" "$QUE"; fallas=$((fallas + 1))
  fi
done

# `Secure` sólo tiene sentido sobre HTTPS, y sobre HTTPS es obligatoria: sin ella
# la cookie de sesión viaja en claro la primera vez que alguien teclee http://.
case "$BASE" in
  https://*)
    if printf '%s' "$GALLETA" | grep -qi 'Secure'; then
      printf "  %s✓%s y sobre HTTPS lleva Secure\n" "$verde" "$nada"; pasadas=$((pasadas + 1))
    else
      printf "  %s✗%s y sobre HTTPS lleva Secure\n" "$rojo" "$nada"; fallas=$((fallas + 1))
    fi

    # Paso 20.4: quien llegue por http tiene que acabar en https.
    DESTINO=$(curl -s -m 10 -o /dev/null -w '%{redirect_url}' "$(printf '%s' "$BASE" | sed 's|^https://|http://|')/entrar")
    case "$DESTINO" in
      https://*) printf "  %s✓%s y quien llega por http acaba en https\n" "$verde" "$nada"; pasadas=$((pasadas + 1)) ;;
      *)         printf "  %s✗%s y quien llega por http acaba en https — fue a «%s»\n" "$rojo" "$nada" "$DESTINO"; fallas=$((fallas + 1)) ;;
    esac
    ;;
  *)
    printf "  %s·%s Secure se comprueba cuando la dirección sea https (paso 20.4)\n" "$gris" "$nada"
    ;;
esac

# --- El salto a https, comprobado sin tener todavía el dominio ----------------
#
# La regla vive en `publico/.htaccess` y decide por el **nombre del host**, así
# que se puede comprobar aquí mismo: basta pedirle al servidor local que se
# crea `elsistema.mx`. No prueba el certificado de Hostinger —eso es del paso
# 20.4 de verdad—, pero sí prueba lo único que está en nuestras manos: que la
# regla distinga producción de desarrollo y no arme un ciclo.

# salto HOST RUTA CABECERAS_EXTRA DESTINO_ESPERADO descripción
# DESTINO_ESPERADO vacío significa «no debe redirigir».
salto() {
  local obtenido
  obtenido=$(curl -s -m 10 -o /dev/null -w '%{redirect_url}' \
    -H "Host: $1" ${3:+-H "$3"} "$ORIGEN$2")
  if [ "$obtenido" = "$4" ]; then
    printf "  %s✓%s %s\n" "$verde" "$nada" "$5"
    pasadas=$((pasadas + 1))
  else
    printf "  %s✗%s %s — esperaba «%s», fue a «%s»\n" "$rojo" "$nada" "$5" "$4" "$obtenido"
    fallas=$((fallas + 1))
  fi
}

case "$BASE" in
  http://*)
    echo "${gris}la regla que manda todo a https (fase 21)${nada}"

    # Contra la IP y el puerto, para que el Host sea lo único que cambia.
    PUERTO=$(printf '%s' "$BASE" | sed -n 's|^http://[^:/]*:\([0-9]*\).*|\1|p')
    ORIGEN="http://127.0.0.1${PUERTO:+:$PUERTO}"

    salto 'elsistema.mx' /entrar '' 'https://elsistema.mx/entrar' \
      'un dominio de verdad por http acaba en https, en la misma pantalla'
    salto 'elsistema.mx' /recursos/estilo.css '' 'https://elsistema.mx/recursos/estilo.css' \
      'y también los recursos, porque la regla va antes que las demás'

    # Detrás del proxy de Hostinger la petición llega como http aunque el
    # navegador la hiciera cifrada. Si esto redirigiera, el sitio entero
    # quedaría en un ciclo infinito.
    salto 'elsistema.mx' /entrar 'X-Forwarded-Proto: https' '' \
      'si el TLS lo terminó el proxy, no vuelve a redirigir'

    # Y lo que hay que no romper: el sitio de desarrollo no tiene certificado.
    salto 'timon.test' /entrar '' '' \
      'el sitio de desarrollo por nombre no salta'
    salto "127.0.0.1${PUERTO:+:$PUERTO}" /entrar '' '' \
      'ni por dirección IP'
    salto '10.0.2.2:8081' /api/v1/entrar '' '' \
      'ni desde el emulador de Android, que ve a esta máquina como 10.0.2.2'

    # ⚠️ `HTTP_HOST` trae el puerto: un patrón anclado en `\.test$` no le atina
    # y la primera versión de la regla mandaba el desarrollo a un https
    # inexistente. Esta comprobación es la que lo encontró.
    salto 'timon.test:9999' /entrar '' '' \
      'aunque el puerto sea otro'

    sin_cabecera /entrar 'Strict-Transport-Security' \
      'y por http no se anuncia HSTS, que es una trampa con memoria'

    # ⚠️ Pero sí tiene que anunciarse cuando la petición **venía** cifrada y el
    # TLS lo terminó el hospedaje. Es la falla más callada de las dos: una
    # cabecera que falta no rompe ninguna pantalla, así que sin esta
    # comprobación HSTS podría no enviarse nunca en producción y nadie lo sabría.
    HSTS=$(curl -s -m 10 -D - -o /dev/null \
      -H 'Host: elsistema.mx' -H 'X-Forwarded-Proto: https' "$ORIGEN/entrar" \
      | grep -ci '^strict-transport-security:')
    if [ "$HSTS" != "0" ]; then
      printf "  %s✓%s pero sí cuando el TLS lo terminó el hospedaje\n" "$verde" "$nada"
      pasadas=$((pasadas + 1))
    else
      printf "  %s✗%s pero sí cuando el TLS lo terminó el hospedaje\n" "$rojo" "$nada"
      fallas=$((fallas + 1))
    fi
    ;;
esac

echo
if [ "$fallas" -eq 0 ]; then
  echo "${verde}${pasadas} comprobaciones, todas pasan.${nada}"
  exit 0
fi
echo "${rojo}${fallas} de $((pasadas + fallas)) fallan.${nada}"
exit 1
