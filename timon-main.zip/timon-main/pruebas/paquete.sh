#!/usr/bin/env bash
# El paquete que sube al hospedaje (fase 29).
#
#   pruebas/paquete.sh
#
# Arma los dos paquetes —el de raíz propia y el de subdominio— en una carpeta
# temporal y mira dentro: que lleve lo que el cron y la copia cifrada necesitan,
# que **no** lleve una sola llave ni credencial de esta máquina, que el
# identificador de liberación sea el mismo en la configuración y en
# `LIBERACION.json`, que el manifiesto cuadre archivo por archivo y que lo
# realmente empacado conserve sintaxis, integridad y una estructura regular.
#
# No toca la base ni `entregables/`: todo se arma y se tira en un temporal.

set -u
PHP=/opt/homebrew/opt/php@8.3/bin/php
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="$(dirname "$PHP"):$PATH"

verde=$'\033[32m'; rojo=$'\033[31m'; gris=$'\033[90m'; nada=$'\033[0m'
pasadas=0; fallas=0

ok()    { printf "  %s✓%s %s\n" "$verde" "$nada" "$1"; pasadas=$((pasadas + 1)); }
mal()   { printf "  %s✗%s %s\n" "$rojo" "$nada" "$1"; fallas=$((fallas + 1)); }
juzga() { if [ "$2" = "$3" ]; then ok "$1"; else mal "$1 — esperaba $3, llegó $2"; fi; }
hay()   { if [ -e "$2" ]; then ok "$1"; else mal "$1 — falta ${2#$TEMPORAL/}"; fi; }
nohay() { if [ -e "$2" ]; then mal "$1 — sobra ${2#$TEMPORAL/}"; else ok "$1"; fi; }

TEMPORAL=$(mktemp -d)
trap 'rm -rf "$TEMPORAL"' EXIT

# Las llaves y credenciales que existen en esta máquina y nunca deben viajar.
SECRETOS="app.php bd.php bd.pruebas.php seguridad.php seguridad.pruebas.php respaldo.php respaldo.pruebas.php alertas.php alertas.pruebas.php marca-visual.php marca-visual.pruebas.php"

revisa() {
  # `base` es desde donde el empaquetador escribió el manifiesto.
  local nombre="$1" base="$2" privado="$3"
  printf "\n%s%s%s\n" "$gris" "$nombre" "$nada"

  for guion in tarea.php respaldo.php restaura.php descifra-respaldo.php genera-llave-respaldo.php mantenimiento.php parametro.php verifica-cierre-host.php verifica-host.php; do
    hay "lleva guiones/$guion" "$privado/guiones/$guion"
  done
  hay "lleva la plantilla de la llave de respaldo" "$privado/config/respaldo.php.ejemplo"
  hay "lleva la plantilla de alertas" "$privado/config/alertas.php.ejemplo"
  hay "lleva la plantilla de marca (D24)" "$privado/config/marca-visual.php.ejemplo"
  hay "trae almacenamiento/marca para el logotipo" "$privado/almacenamiento/marca"
  local recursos="$base/recursos"
  [ -d "$recursos" ] || recursos="$base/publico/recursos"
  for pieza in logo-horizontal.svg logo-monocromo.svg simbolo.svg; do
    hay "lleva la pieza D25 $pieza" "$recursos/$pieza"
  done
  juzga "y las letras locales del panel con su licencia" \
    "$(find "$base" -path '*recursos/fuentes/*' \( -name 'plus-jakarta-sans.woff2' -o -name 'OFL-PlusJakartaSans.txt' \) | wc -l | tr -d ' ')" 2
  for carpeta in tareas alertas respaldos/cifrados; do
    hay "trae almacenamiento/$carpeta" "$privado/almacenamiento/$carpeta"
  done

  local sobra=0
  for secreto in $SECRETOS; do
    [ -e "$privado/config/$secreto" ] && sobra=$((sobra + 1))
  done
  juzga "no lleva ninguna llave ni credencial de esta máquina" "$sobra" 0
  juzga "ni respaldos, alertas o estados de aquí" \
    "$(find "$privado/almacenamiento" -type f ! -name .gitkeep | wc -l | tr -d ' ')" 0
  nohay "ni las credenciales de la demostración" "$privado/almacenamiento/credenciales-demo.txt"
  nohay "ni pruebas" "$privado/pruebas"
  nohay "ni la app" "$privado/movil"
  juzga "ni dependencias de Node" \
    "$(find "$base" -type d -name node_modules | wc -l | tr -d ' ')" 0
  juzga "ni metadatos de Git" \
    "$(find "$base" -type d -name .git | wc -l | tr -d ' ')" 0

  local enlaces
  enlaces=$(find "$base" -type l | wc -l | tr -d ' ')
  juzga "no lleva enlaces simbólicos que puedan escapar del paquete" "$enlaces" 0

  local php_total=0 php_rotos=0 archivo_php
  while IFS= read -r -d '' archivo_php; do
    php_total=$((php_total + 1))
    "$PHP" -l "$archivo_php" > /dev/null 2>&1 || php_rotos=$((php_rotos + 1))
  done < <(find "$privado" -type f -name '*.php' -print0)
  if [ "$php_total" -gt 0 ] && [ "$php_rotos" -eq 0 ]; then
    ok "todo el PHP empacado conserva sintaxis válida ($php_total archivos)"
  else
    mal "el PHP empacado tiene $php_rotos archivos rotos de $php_total"
  fi

  "$PHP" "$privado/guiones/verifica-host.php" > /dev/null 2>&1
  juzga "el diagnóstico previo corre desde el paquete extraído" "$?" 0

  ( cd "$privado/instalacion" && shasum -a 256 -c app-esquema.sql.sha256 > /dev/null 2>&1 )
  juzga "el SQL interno conserva la huella publicada" "$?" 0

  local id_php id_json esquema descriptor_igual
  id_php=$("$PHP" -r 'echo (require $argv[1])["id"];' "$privado/config/liberacion.php")
  id_json=$("$PHP" -r 'echo json_decode(file_get_contents($argv[1]), true)["id"];' "$privado/instalacion/LIBERACION.json")
  juzga "el id de liberación es el mismo en la configuración y en LIBERACION.json" "$id_php" "$id_json"
  descriptor_igual=$("$PHP" -r '$php = require $argv[1]; $json = json_decode(file_get_contents($argv[2]), true); echo $php === $json ? "1" : "0";' \
    "$privado/config/liberacion.php" "$privado/instalacion/LIBERACION.json")
  juzga "el descriptor completo coincide entre PHP y JSON" "$descriptor_igual" 1
  esquema=$("$PHP" -r 'echo json_decode(file_get_contents($argv[1]), true)["esquema"];' "$privado/instalacion/LIBERACION.json")
  juzga "y declara el esquema del último guion" "$esquema" "$ULTIMO"

  ( cd "$base" && shasum -a 256 -c "$privado/instalacion/MANIFIESTO-SHA256.txt" > /dev/null 2>&1 )
  juzga "el manifiesto cuadra con cada archivo" "$?" 0
}

ULTIMO=$(ls "$RAIZ"/esquema/[0-9][0-9][0-9]_*.sql | tail -1 | xargs basename | cut -c1-3 | sed 's/^0*//')

printf "%sArmando los paquetes en un temporal…%s\n" "$gris" "$nada"
bash "$RAIZ/guiones/prepara-despliegue.sh" "$TEMPORAL/salida" > /dev/null 2>&1
juzga "se arma el paquete de raíz propia" "$?" 0
bash "$RAIZ/guiones/prepara-despliegue-subdominio.sh" "$TEMPORAL/salida" > /dev/null 2>&1
juzga "se arma el paquete de subdominio" "$?" 0

( cd "$TEMPORAL/salida" && shasum -a 256 -c app-candidato-productivo.tar.gz.sha256 app-subdominio-candidato.tar.gz.sha256 > /dev/null 2>&1 )
juzga "las huellas de los dos .tar.gz cuadran" "$?" 0

mkdir -p "$TEMPORAL/raiz" "$TEMPORAL/subdominio"
tar -xzf "$TEMPORAL/salida/app-candidato-productivo.tar.gz" -C "$TEMPORAL/raiz"
tar -xzf "$TEMPORAL/salida/app-subdominio-candidato.tar.gz" -C "$TEMPORAL/subdominio"

revisa "Raíz propia" "$TEMPORAL/raiz/app" "$TEMPORAL/raiz/app"
revisa "Subdominio" "$TEMPORAL/subdominio" "$TEMPORAL/subdominio/.app"

FTP="$TEMPORAL/salida/app-subdominio-ftp"
hay "se genera la carpeta descomprimida para FTP individual" "$FTP/index.php"
hay "la carpeta FTP incluye el código privado" "$FTP/.app/publico/index.php"
hay "la carpeta FTP incluye el cerrojo de instalación" "$FTP/app-bloqueo-instalacion.htaccess"
( cd "$FTP" && shasum -a 256 -c .app/instalacion/MANIFIESTO-SHA256.txt > /dev/null 2>&1 )
juzga "la carpeta FTP conserva el manifiesto del candidato" "$?" 0
ID_FTP=$("$PHP" -r 'echo json_decode(file_get_contents($argv[1]), true)["id"];' "$FTP/.app/instalacion/LIBERACION.json")
ID_TAR=$("$PHP" -r 'echo json_decode(file_get_contents($argv[1]), true)["id"];' "$TEMPORAL/subdominio/.app/instalacion/LIBERACION.json")
juzga "la carpeta FTP y el paquete identifican la misma liberación" "$ID_FTP" "$ID_TAR"

hay "la raíz propia conserva su punto de entrada público" "$TEMPORAL/raiz/app/publico/index.php"
hay "la raíz propia conserva su regla pública" "$TEMPORAL/raiz/app/publico/.htaccess"
hay "el subdominio conserva su punto de entrada mínimo" "$TEMPORAL/subdominio/index.php"
hay "el subdominio conserva la regla privada independiente" "$TEMPORAL/subdominio/.app/.htaccess"
hay "el subdominio trae la regla pública lista para activar" "$TEMPORAL/subdominio/.htaccess.app"

if grep -Fq 'RewriteRule ^\.app(?:/|$) - [F,L,NC]' "$TEMPORAL/subdominio/.htaccess.app"; then
  ok "la regla pública niega el árbol .app antes de publicarlo"
else
  mal "la regla pública no niega el árbol .app"
fi

# La landing (fase 11): en `sitio/`, con su CSP, sin lo del repositorio. Hasta
# que exista `landing/`, el subdominio abre directo en el panel.
SITIO="$TEMPORAL/subdominio/sitio"
if [ -d "$RAIZ/landing" ]; then
  hay "el subdominio trae la landing en sitio/" "$SITIO/index.html"
  hay "con su hoja" "$SITIO/estilo.css"
  hay "y su propia regla de cabeceras" "$SITIO/.htaccess"
  nohay "el README de la landing no viaja" "$SITIO/README.md"
  nohay "ni los originales de las fotos" "$SITIO/img/fotografias/originales"
  if grep -Fq "script-src 'self'" "$SITIO/.htaccess"; then ok "la landing usa sus propios guiones"; else mal "la landing no trae su CSP"; fi
  if grep -rFq 'Entrar al sistema' "$SITIO"; then mal "la landing anuncia la entrada del panel"; else ok "la landing no anuncia la entrada del panel"; fi
else
  nohay "sin landing todavía, el subdominio no trae sitio/" "$SITIO"
fi
if [ -f "$RAIZ/app/dist/index.html" ]; then
  hay "el subdominio trae la PWA" "$TEMPORAL/subdominio/app/index.html"
  hay "la PWA trae el manifiesto" "$TEMPORAL/subdominio/app/manifest.webmanifest"
  hay "la PWA trae el trabajador de servicio" "$TEMPORAL/subdominio/app/servicio.js"
  nohay "la PWA no lleva dependencias de Node" "$TEMPORAL/subdominio/app/node_modules"
fi
if grep -Fq 'RewriteRule ^$ sitio/index.html [L]' "$TEMPORAL/subdominio/.htaccess.app"; then
  ok "la regla pública sirve la landing en la raíz cuando exista"
else
  mal "la regla pública no sirve la landing en la raíz"
fi

echo
if [ "$fallas" -eq 0 ]; then
  echo "$verde$pasadas comprobaciones, todas pasan.$nada"
else
  echo "$rojo$fallas de $((pasadas + fallas)) fallan.$nada"
  exit 1
fi
