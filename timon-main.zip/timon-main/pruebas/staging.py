#!/usr/bin/env python3
"""Comprueba el staging publicado sin iniciar sesión ni crear datos.

Uso: python3 pruebas/staging.py https://staging.example PAQUETE.tar.gz
Primero ejecuta la compuerta de publicación; después revisa lo propio del
staging, los menús publicados y los recursos de la PWA contra ese paquete.
"""

import argparse
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as XML
from urllib.error import HTTPError
from urllib.parse import quote, urljoin, urlsplit
from urllib.request import urlopen
from urllib.robotparser import RobotFileParser


def huella_png(contenido):
    """El CDN puede recomprimir PNG: compara dimensiones y píxeles con GD."""
    php = '/opt/homebrew/opt/php@8.3/bin/php'
    resultado = subprocess.run([php, '-r', '''
        $imagen = @imagecreatefromstring(stream_get_contents(STDIN));
        if (!$imagen) exit(1);
        imagepalettetotruecolor($imagen);
        $ancho = imagesx($imagen); $alto = imagesy($imagen);
        $hash = hash_init('sha256');
        hash_update($hash, pack('NN', $ancho, $alto));
        for ($y = 0; $y < $alto; $y++) {
            for ($x = 0; $x < $ancho; $x++) {
                hash_update($hash, pack('N', imagecolorat($imagen, $x, $y)));
            }
        }
        echo hash_final($hash);
    '''], input=contenido, capture_output=True, check=True)
    return resultado.stdout


class RecursosHTML(HTMLParser):
    def __init__(self):
        super().__init__()
        self.guiones = []
        self.manifiesto = None

    def handle_starttag(self, tag, atributos):
        datos = dict(atributos)
        if tag == 'script' and datos.get('src'):
            self.guiones.append(datos['src'])
        if tag == 'link' and datos.get('rel') == 'manifest':
            self.manifiesto = datos.get('href')


def main():
    argumentos = argparse.ArgumentParser(description=__doc__)
    argumentos.add_argument('origen')
    argumentos.add_argument('paquete', type=Path)
    argumentos.add_argument('--landing', default='https://verticesoftware.com.mx')
    args = argumentos.parse_args()
    origen = args.origen.rstrip('/')
    partes = urlsplit(origen)
    if (partes.scheme != 'https' or not partes.netloc or partes.path
            or partes.username or partes.password or partes.query or partes.fragment):
        argumentos.error('El origen debe ser HTTPS, sin ruta ni credenciales.')

    raiz = Path(__file__).resolve().parents[1]
    compuerta = subprocess.run(['bash', str(raiz / 'pruebas/publicacion.sh'), origen, str(args.paquete)])
    if compuerta.returncode:
        return compuerta.returncode

    pasadas, fallas = 0, 0

    def comprueba(condicion, mensaje):
        nonlocal pasadas, fallas
        if condicion:
            pasadas += 1
            print(f'  ✓ {mensaje}', flush=True)
        else:
            fallas += 1
            print(f'  ✗ {mensaje}', flush=True)

    def pide(direccion):
        url = urljoin(origen + '/', direccion)
        try:
            with urlopen(url, timeout=20) as respuesta:
                return respuesta.status, respuesta.headers, respuesta.read()
        except HTTPError as error:
            return error.code, error.headers, error.read()

    def pagina(ruta):
        estado, cabeceras, contenido = pide(ruta)
        comprueba(estado == 200, f'{ruta} responde 200')
        robots = ','.join(cabeceras.get_all('X-Robots-Tag', [])).lower()
        comprueba('noindex' in robots and 'nofollow' in robots, f'{ruta} lleva noindex y nofollow')
        comprueba('text/html' in cabeceras.get('Content-Type', ''), f'{ruta} entrega HTML')
        return contenido

    print('\nComprobaciones propias de staging', flush=True)
    pagina('/')
    pagina('/entrar')
    pagina('/aviso-privacidad')
    html = pagina('/app/')

    estado, _, robots = pide('/robots.txt')
    analizador = RobotFileParser()
    analizador.parse(robots.decode('utf-8').splitlines())
    comprueba(estado == 200 and all(not analizador.can_fetch('*', origen + ruta)
                                  for ruta in ['/', '/entrar', '/app/', '/menu/CEN']),
               'robots.txt impide rastrear todo el staging')

    estado, _, contenido = pide('/api/v1/sucursales-publicas')
    sucursales = json.loads(contenido)
    filas = sucursales.get('datos', [])
    comprueba(estado == 200 and sucursales.get('ok') is True and isinstance(filas, list) and bool(filas),
               'hay sucursales de prueba publicadas')
    for sucursal in filas:
        clave = quote(sucursal['clave'], safe='')
        pagina('/menu/' + clave)
        estado, _, contenido = pide('/api/v1/menu-publico/' + clave)
        menu = json.loads(contenido)
        comprueba(estado == 200 and menu.get('ok') is True and bool(menu.get('datos', {}).get('platillos')),
                   f'el menú de {clave} contiene platillos')

    estado, _, contenido = pide('/sitemap.xml')
    direcciones = [nodo.text or '' for nodo in XML.fromstring(contenido).iter('{http://www.sitemaps.org/schemas/sitemap/0.9}loc')]
    comprueba(estado == 200 and bool(direcciones) and all(
                   urlsplit(direccion).scheme == 'https' and urlsplit(direccion).netloc == partes.netloc
                   for direccion in direcciones),
               'el mapa del sitio apunta a staging')

    recursos = RecursosHTML()
    recursos.feed(html.decode('utf-8'))
    comprueba(bool(recursos.guiones) and recursos.manifiesto is not None,
               'la PWA declara su JavaScript y manifiesto')

    with tarfile.open(args.paquete, 'r:gz') as paquete:
        archivos = {miembro.name.removeprefix('./'): miembro for miembro in paquete.getmembers() if miembro.isfile()}

        def recurso(ruta, tipo):
            url = urljoin(origen + '/app/', ruta)
            if urlsplit(url).netloc != partes.netloc or not urlsplit(url).path.startswith('/app/'):
                comprueba(False, 'el recurso de la PWA pertenece al mismo origen y a /app/')
                return b''
            estado, cabeceras, contenido = pide(url)
            comprueba(estado == 200 and tipo in cabeceras.get('Content-Type', ''),
                       f'{urlsplit(url).path} entrega {tipo}')
            miembro = archivos.get(urlsplit(url).path.lstrip('/'))
            if miembro is None:
                comprueba(False, 'el recurso existe en el candidato')
            else:
                with paquete.extractfile(miembro) as archivo:
                    original = archivo.read()
                    if tipo == 'image/png':
                        comprueba(huella_png(contenido) == huella_png(original),
                                   f'{urlsplit(url).path} conserva dimensiones y píxeles del candidato')
                    else:
                        comprueba(hashlib.sha256(contenido).digest() == hashlib.sha256(original).digest(),
                                   f'{urlsplit(url).path} coincide con el candidato')
            return contenido

        # El índice se sirve como directorio; el candidato lo guarda con nombre.
        miembro = archivos.get('app/index.html')
        if miembro is not None:
            with paquete.extractfile(miembro) as archivo:
                comprueba(html == archivo.read(), 'el índice de la PWA coincide con el candidato')
        else:
            comprueba(False, 'el candidato contiene el índice de la PWA')
        for guion in recursos.guiones:
            recurso(guion, 'javascript')
        if recursos.manifiesto:
            manifiesto = json.loads(recurso(recursos.manifiesto, 'manifest+json'))
            comprueba(manifiesto.get('start_url') == '/app/' and manifiesto.get('scope') == '/app/',
                       'la instalación de la PWA queda dentro de /app/')
            for icono in manifiesto.get('icons', []):
                recurso(icono['src'], 'image/png')
        recurso('/app/servicio.js', 'javascript')
        _, cabeceras, _ = pide('/app/servicio.js')
        comprueba('no-cache' in cabeceras.get('Cache-Control', ''), 'el trabajador de servicio permite buscar actualizaciones')

    for ruta in ['/app-subdominio-candidato.tar.gz', '/app-esquema.sql', '/.app/instalacion/LIBERACION.json']:
        estado, _, _ = pide(ruta)
        comprueba(estado in (403, 404), f'{ruta} permanece privado')

    estado, cabeceras, _ = pide(args.landing)
    csp = ','.join(cabeceras.get_all('Content-Security-Policy', []))
    comprueba(estado == 200 and "default-src 'self'" in csp and "script-src 'self'" in csp,
               'la landing principal conserva su política de contenido')
    print(f'\n{pasadas} comprobaciones de staging aprobadas; {fallas} fallas.', flush=True)
    return 1 if fallas else 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print(f'No se pudo completar la validación: {type(error).__name__}.', file=sys.stderr)
        sys.exit(1)
