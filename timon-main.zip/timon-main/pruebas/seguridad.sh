#!/usr/bin/env bash
# Los candados del endurecimiento, vistos desde fuera (docs/seguridad/).
#
#   pruebas/seguridad.sh http://127.0.0.1:8082
#
# ⚠️ Escribe en la base: pasa por exige-entorno.sh y nunca corre contra producción.
set -u

BASE="${1:-http://127.0.0.1:8081}"
PHP=/opt/homebrew/opt/php@8.3/bin/php
RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
. "$RAIZ/pruebas/exige-entorno.sh"
. "$RAIZ/pruebas/fixtures/entra-segundo-factor.sh"

T=$(mktemp -d)
verde=$'\033[32m'; rojo=$'\033[31m'; gris=$'\033[90m'; nada=$'\033[0m'
pasadas=0; fallas=0
ok() { printf "  %s✓%s %s\n" "$verde" "$nada" "$1"; pasadas=$((pasadas + 1)); }
mal() { printf "  %s✗%s %s\n" "$rojo" "$nada" "$1"; fallas=$((fallas + 1)); }
juzga() { if [ "$2" = "$3" ]; then ok "$1"; else mal "$1 — esperaba $3, llegó $2"; fi; }
dice() { if printf '%s' "$2" | grep -qi -- "$3"; then ok "$1"; else mal "$1"; fi; }
nodice() { if printf '%s' "$2" | grep -qi -- "$3"; then mal "$1"; else ok "$1"; fi; }
fixture() { "$PHP" "$RAIZ/pruebas/fixtures/seguridad.php" "$@"; }
limpia() { fixture limpia; rm -rf "$T"; }
trap limpia EXIT

CLAVE="prueba-$(head -c 12 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9')"
codigo() { curl -s -m 15 -b "$1" -o /dev/null -w '%{http_code}' "$BASE$2"; }
pagina() { curl -s -m 15 -b "$1" "$BASE$2"; }
marca_de() { curl -s -m 15 -c "$1" -b "$1" "$BASE$2" | grep -o 'name="\(_marca\|csrf-token\)" \(value\|content\)="[a-f0-9]*"' | head -1 | sed 's/.*="//;s/"//'; }

echo "${gris}Contra ${BASE}${nada}"
fixture prepara "$CLAVE"

echo "${gris}Cabeceras${nada}"
H=$(curl -s -m 15 -D - -o "$T/entrar.html" "$BASE/entrar")
dice "la política de contenido va en la respuesta" "$H" "content-security-policy: default-src 'self'; script-src 'self';"
dice "no se permite que otro sitio la enmarque" "$H" "frame-ancestors 'none'"
dice "los permisos del navegador van apagados" "$H" 'permissions-policy: camera=()'
dice "el origen va aislado" "$H" 'cross-origin-opener-policy: same-origin'
dice "no se adivina el tipo de contenido" "$H" 'x-content-type-options: nosniff'
nodice "PHP no anuncia su versión" "$H" 'x-powered-by'
dice "la cookie de sesión no la lee JavaScript" "$H" 'set-cookie:.*httponly'
dice "la cookie de sesión no viaja a otros sitios" "$H" 'set-cookie:.*samesite=\(lax\|strict\)'
nodice "el acceso no trae scripts incrustados" "$(sed 's/<script[^>]*src=[^>]*>//g; s/<script[^>]*application\/json[^>]*>//g' "$T/entrar.html")" '<script'

echo "${gris}Revisión de accesos${nada}"
G_ADM="$T/adm"; G_ALM="$T/alm"
entra_web_segura "$BASE" "$PHP" "$RAIZ" humo.seguridad.admin "$CLAVE" "$G_ADM" || mal "entra el administrador"
entra_web_segura "$BASE" "$PHP" "$RAIZ" humo.seguridad.almacen "$CLAVE" "$G_ALM" || mal "entra almacén"
juzga "el administrador abre la revisión de accesos" "$(codigo "$G_ADM" /seguridad/accesos)" 200
juzga "almacén no la abre" "$(codigo "$G_ALM" /seguridad/accesos)" 403
juzga "almacén no se lleva el CSV" "$(codigo "$G_ALM" /seguridad/accesos.csv)" 403
juzga "almacén no se lleva el XLS" "$(codigo "$G_ALM" /seguridad/accesos.xlsx)" 403
dice "la pantalla enseña las combinaciones por vigilar" "$(pagina "$G_ADM" /seguridad/accesos)" 'Separación de funciones'
ACCESOS=$(pagina "$G_ADM" /seguridad/accesos)
dice "la revisión se captura en modal" "$ACCESOS" 'data-bs-target="#modal-revision-accesos"'
dice "el historial se consulta en modal" "$ACCESOS" 'data-bs-target="#modal-historial-accesos"'
dice "la pantalla ofrece XLS" "$ACCESOS" 'href="/seguridad/accesos.xlsx"'
juzga "el administrador descarga XLS" "$(codigo "$G_ADM" /seguridad/accesos.xlsx)" 200
curl -s -m 15 -b "$G_ADM" "$BASE/seguridad/accesos.xlsx" -o "$T/accesos.xlsx"
if unzip -p "$T/accesos.xlsx" xl/worksheets/sheet1.xml 2>/dev/null | grep -q 'humo.seguridad.admin'; then ok "el XLS muestra la cuenta visible"; else mal "el XLS muestra la cuenta visible"; fi
CSV=$(pagina "$G_ADM" /seguridad/accesos.csv)
dice "el CSV lista las cuentas" "$CSV" 'humo.seguridad.admin'
dice "una fórmula en un nombre sale neutralizada" "$CSV" "'=HYPERLINK"
juzga "bajar el CSV queda como lectura en la bitácora" "$(fixture bitacora exporta_accesos | awk '{print ($1 >= 1)}')" 1
M=$(marca_de "$G_ADM" /seguridad/accesos)
juzga "registrar una revisión sin nota se rechaza" "$(curl -s -m 15 -b "$G_ADM" -H 'Accept: application/json' -o /dev/null -w '%{http_code}' --data-urlencode "_marca=$M" --data-urlencode 'nota=' "$BASE/seguridad/accesos/revision")" 422
juzga "registrar una revisión con nota funciona" "$(curl -s -m 15 -b "$G_ADM" -H 'Accept: application/json' -o /dev/null -w '%{http_code}' --data-urlencode "_marca=$M" --data-urlencode 'nota=Revisión de la prueba de humo' "$BASE/seguridad/accesos/revision")" 200
juzga "la revisión queda en la bitácora" "$(fixture bitacora revisa_accesos | awk '{print ($1 >= 1)}')" 1

echo "${gris}Privacidad${nada}"
juzga "el aviso se lee sin entrar al sistema" "$(curl -s -m 15 -o /dev/null -w '%{http_code}' "$BASE/aviso-privacidad")" 200
AVISO=$(curl -s -m 15 "$BASE/aviso-privacidad")
dice "mientras no se apruebe se presenta como borrador" "$AVISO" 'Borrador pendiente de revisión legal'
dice "explica los derechos" "$AVISO" 'rectificación, cancelación'
dice "el acceso declara la autoría" "$(curl -s -m 15 "$BASE/entrar")" '© 2026 Vértice Software'
dice "el acceso enlaza el aviso" "$(curl -s -m 15 "$BASE/entrar")" 'href="/aviso-privacidad"'
juzga "el administrador abre Privacidad" "$(codigo "$G_ADM" /privacidad)" 200
juzga "almacén no la abre" "$(codigo "$G_ALM" /privacidad)" 403
PRIVACIDAD=$(curl -s -m 15 -b "$G_ADM" "$BASE/privacidad")
dice "Privacidad lleva Agregar solicitud" "$PRIVACIDAD" 'data-bs-target="#modal-solicitud"'
dice "y Exportar XLS" "$PRIVACIDAD" 'href="/privacidad.xlsx'
dice "y cuenta sus registros" "$PRIVACIDAD" ' registro'
printf '%s' "$PRIVACIDAD" | grep -q 'data-pb-privacidad=' && mal "ya no anonimiza con un número suelto" || ok "ya no anonimiza con un número suelto"
dice "anonimizar pide escribir la palabra" "$PRIVACIDAD" 'capture ANONIMIZAR'
dice "el XLS de privacidad baja como archivo" "$(curl -s -m 20 -b "$G_ADM" -D - -o /dev/null "$BASE/privacidad.xlsx")" 'privacidad_'
juzga "almacén no lo baja" "$(codigo "$G_ALM" /privacidad.xlsx)" 403
juzga "almacén no se lleva los datos de un titular" "$(codigo "$G_ALM" /privacidad/empleado/1/datos)" 403
juzga "un titular inexistente da 404" "$(codigo "$G_ADM" /privacidad/empleado/999999999/datos)" 404
M=$(marca_de "$G_ADM" /seguridad/accesos)
juzga "anonimizar sin escribir la palabra se rechaza" "$(curl -s -m 15 -b "$G_ADM" -H 'Accept: application/json' -o /dev/null -w '%{http_code}' --data-urlencode "_marca=$M" --data-urlencode 'confirmacion=si' "$BASE/privacidad/empleado/999999999/anonimizar")" 422

echo "${gris}Acceso de soporte${nada}"
SOPORTE="$PHP $RAIZ/guiones/acceso-soporte.php"
E1=$($SOPORTE abre --usuario=humo.soporte --nombre=Humo --apellido=Soporte --horas=8 2>&1)
juzga "sin motivo no se abre" "$?" 2
dice "y dice que falta el motivo" "$E1" 'motivo'
E2=$($SOPORTE abre --usuario=humo.soporte --nombre=Humo --apellido=Soporte --horas=100 --motivo="Revisión de la prueba de humo" 2>&1)
juzga "más de 72 horas no se abre" "$?" 2
dice "y dice el tope" "$E2" 'entre 1 y 72'
E3=$($SOPORTE abre --usuario=humo.soporte --horas=8 --motivo="Revisión de la prueba de humo" 2>&1)
juzga "sin nombre de persona no se crea" "$?" 2
dice "y pide el nombre" "$E3" 'nombre'
SALIDA=$($SOPORTE abre --usuario=humo.soporte --nombre=Humo --apellido=Soporte --horas=8 --motivo="Revisión de la prueba de humo" 2>&1)
juzga "con motivo y caducidad se abre" "$?" 0
dice "avisa hasta cuándo" "$SALIDA" 'abierto hasta'
dice "la contraseña temporal sale una vez" "$SALIDA" 'Contraseña temporal'
juzga "queda activa" "$(fixture estado humo.soporte)" 4
juzga "abrirlo queda en la bitácora" "$(fixture bitacora abre_acceso_soporte | awk '{print ($1 >= 1)}')" 1
$SOPORTE cierra --usuario=humo.soporte >/dev/null 2>&1
juzga "cerrarlo a mano funciona" "$?" 0
juzga "cerrada queda inactiva" "$(fixture estado humo.soporte)" 3
$SOPORTE abre --usuario=humo.soporte --horas=8 --motivo="Revisión de la prueba de humo" >/dev/null 2>&1
juzga "abrir de nuevo la reactiva" "$(fixture estado humo.soporte)" 4
$SOPORTE cierra --usuario=humo.seguridad.admin >/dev/null 2>&1
juzga "una cuenta normal no se cierra por aquí" "$?" 1
fixture vence humo.soporte
"$PHP" "$RAIZ/guiones/mantenimiento.php" >/dev/null 2>"$T/mantto.err"
juzga "el mantenimiento corre con la llave del sello" "$?" 0
juzga "el mantenimiento cierra la que venció" "$(fixture estado humo.soporte)" 3
juzga "y lo apunta en la bitácora" "$(fixture bitacora acceso_vencido | awk '{print ($1 >= 1)}')" 1

echo "${gris}Sello de la bitácora${nada}"
fixture sella >/dev/null
"$PHP" "$RAIZ/guiones/verifica-bitacora.php" >/dev/null 2>&1
juzga "el sello verifica limpio" "$?" 0
fixture altera
"$PHP" "$RAIZ/guiones/verifica-bitacora.php" >/dev/null 2>&1
juzga "alterar un renglón hace fallar la verificación" "$?" 1
fixture restaura
"$PHP" "$RAIZ/guiones/verifica-bitacora.php" >/dev/null 2>&1
juzga "al devolverlo vuelve a cuadrar" "$?" 0

# Envío único (esquema/062): la solicitud de privacidad repetida con el mismo
# envío —un doble clic que el navegador no frenó— queda registrada una vez.
echo "${gris}Envío único en privacidad${nada}"
cuenta_arco() { "$PHP" -r 'require $argv[1]."/nucleo/Autocargador.php";Nucleo\Autocargador::registrar($argv[1]);$b=new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos($argv[1]));echo $b->valor("SELECT COUNT(*) FROM solicitud_arco WHERE solicitante=?",[$argv[2]]);' "$RAIZ" "$1"; }
SOLICITANTE="Solicitante doble envío $(head -c 4 /dev/urandom | xxd -p)"
ENVIO=$(uuidgen | tr 'A-Z' 'a-z')
M=$(marca_de "$G_ADM" /privacidad)
arco() { command curl -s -m 15 -b "$G_ADM" -H 'Accept: application/json' -w '|%{http_code}' --data-urlencode "_marca=$M" --data-urlencode "_envio=$1" --data-urlencode 'tipo=acceso' --data-urlencode 'titular_tipo=otro' --data-urlencode "solicitante=$SOLICITANTE" --data-urlencode 'detalle=Prueba de envío único' --data-urlencode "recibida_en=$(date +%Y-%m-%d)" "$BASE/privacidad/solicitudes"; }
R1=$(arco "$ENVIO"); R2=$(arco "$ENVIO")
juzga "el primer envío registra la solicitud" "${R1##*|}" 200
juzga "el mismo envío otra vez contesta igual" "${R2##*|}|$(printf '%s' "${R2%|*}" | grep -o '"redirige":"[^"]*"')" "200|$(printf '%s' "${R1%|*}" | grep -o '"redirige":"[^"]*"')"
juzga "y queda una sola solicitud" "$(cuenta_arco "$SOLICITANTE")" 1
juzga "sin llave de envío la solicitud no se registra" "$(command curl -s -m 15 -b "$G_ADM" -H 'Accept: application/json' -o /dev/null -w '%{http_code}' --data-urlencode "_marca=$M" --data-urlencode 'tipo=acceso' --data-urlencode 'titular_tipo=otro' --data-urlencode "solicitante=$SOLICITANTE" --data-urlencode 'detalle=Sin llave' --data-urlencode "recibida_en=$(date +%Y-%m-%d)" "$BASE/privacidad/solicitudes")|$(cuenta_arco "$SOLICITANTE")" "422|1"
"$PHP" -r 'require $argv[1]."/nucleo/Autocargador.php";Nucleo\Autocargador::registrar($argv[1]);$b=new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos($argv[1]));$b->ejecuta("DELETE FROM solicitud_arco WHERE solicitante=?",[$argv[2]]);' "$RAIZ" "$SOLICITANTE" 2>/dev/null || true

echo
if [ "$fallas" -eq 0 ]; then
  echo "${verde}${pasadas} comprobaciones, todas pasan.${nada}"
else
  echo "${rojo}${fallas} de $((pasadas + fallas)) fallan.${nada}"
  exit 1
fi
