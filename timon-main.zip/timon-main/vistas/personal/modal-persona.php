<?php
/**
 * El modal de alta y edición de una persona. Lo usan la lista y la ficha.
 *
 * El usuario no se crea aquí: nace después, desde la ficha, con los permisos
 * del puesto que se elija aquí (D12).
 *
 * @var \Nucleo\Csrf $csrf
 * @var array<string,string> $sucursales
 * @var array<string,string> $puestos
 * @var array<string,string> $superiores
 * @var string $volver
 */
?>
<?= pb_modal('modalPersona', 'Nueva persona', '/personal', $csrf->campo(), $volver) ?>
    <?= pb_seccion('bi-person', 'Datos de la persona') ?>
        <div class="form-grid">
            <?= pb_campo('nombre', 'Nombre', ['id' => 'personaNombre', 'requerido' => true, 'largo' => '80', 'autocompletado' => 'off']) ?>
            <?= pb_campo('apellido_paterno', 'Apellido paterno', ['id' => 'personaPaterno', 'requerido' => true, 'largo' => '60', 'autocompletado' => 'off']) ?>
            <?= pb_campo('apellido_materno', 'Apellido materno', ['id' => 'personaMaterno', 'largo' => '60', 'autocompletado' => 'off']) ?>
            <?= pb_campo('fecha_ingreso', 'Ingreso', ['id' => 'personaIngreso', 'tipo' => 'fecha', 'requerido' => true, 'valor' => date('Y-m-d')]) ?>
            <?= pb_campo('telefono', 'Teléfono', ['id' => 'personaTelefono', 'tipo' => 'tel', 'modo' => 'tel', 'largo' => '20', 'autocompletado' => 'off', 'ayuda' => '10 dígitos']) ?>
            <?= pb_campo('correo', 'Correo', ['id' => 'personaCorreo', 'tipo' => 'email', 'largo' => '160', 'autocompletado' => 'off']) ?>
        </div>
    </section>
    <?= pb_seccion('bi-diagram-3', 'Puesto y lugar') ?>
        <div class="form-grid">
            <?= pb_campo('id_puesto', 'Puesto', ['id' => 'personaPuesto', 'tipo' => 'select', 'requerido' => true, 'vacia' => 'Seleccione el puesto', 'opciones' => $puestos]) ?>
            <?= pb_campo('id_sucursal', 'Sucursal', [
                'id' => 'personaSucursal', 'tipo' => 'select', 'vacia' => 'Todas las sucursales', 'opciones' => $sucursales,
                'ayuda' => '«Todas» solo para administradores.',
            ]) ?>
            <?= pb_campo('id_superior', 'Superior', [
                'id' => 'personaSuperior', 'tipo' => 'select', 'vacia' => 'Sin superior', 'opciones' => $superiores,
                'clase' => 'form-grid__full',
            ]) ?>
        </div>
    </section>
<?= pb_modal_fin() ?>
