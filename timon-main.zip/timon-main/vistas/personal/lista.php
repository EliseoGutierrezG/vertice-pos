<?php
/**
 * El personal: quién trabaja, en qué puesto y en qué sucursal, y si ya tiene
 * usuario. Origen: `R/mtto/admin/rh/personal/`.
 *
 * @var callable $e
 * @var \Nucleo\Csrf $csrf
 * @var \Nucleo\Identidad $identidad
 * @var list<array<string,mixed>> $personas
 * @var string $estatus
 * @var int $idSucursal
 * @var int $idPuesto
 * @var array<string,string> $sucursales
 * @var array<string,string> $puestos
 * @var array<string,string> $superiores
 */
$admin = $identidad->puede('personal_admin');

$consulta = array_filter([
    'sucursal'  => $idSucursal > 0 ? $idSucursal : null,
    'puesto'  => $idPuesto > 0 ? $idPuesto : null,
    'estatus' => $estatus !== 'activas' ? $estatus : null,
]);
$volver = '/personal' . ($consulta === [] ? '' : '?' . http_build_query($consulta));

$acceso = static function (array $p): string {
    if ($p['usuario'] === null) {
        return pb_insignia('mudo', 'Sin usuario');
    }
    if ((int) $p['estatus_usuario'] !== 4) {
        return pb_insignia('mal', 'Bloqueado');
    }

    return (int) $p['cambiar_clave'] === 1 ? pb_insignia('avisa', 'Contraseña temporal') : pb_insignia('bien', 'Activo');
};
?>
<?= pb_modulo(
    'bi-people',
    'Personal', 'Personas que usan el panel o la app, con su puesto, sucursal y usuario.',
    ($admin ? pb_agregar('modalPersona') : '') . pb_exportar('/personal.xlsx')
) ?>

<form class="module-filters" method="get" action="/personal">
    <?= pb_campo('sucursal', 'Sucursal', ['tipo' => 'select', 'id' => 'filtroSucursal', 'vacia' => 'Todas las sucursales', 'opciones' => $sucursales, 'valor' => $idSucursal > 0 ? (string) $idSucursal : '']) ?>
    <?= pb_campo('puesto', 'Puesto', ['tipo' => 'select', 'id' => 'filtroPuesto', 'vacia' => 'Todos los puestos', 'opciones' => $puestos, 'valor' => $idPuesto > 0 ? (string) $idPuesto : '']) ?>
    <?= pb_filtro_estatus($estatus, 'filtroEstatus', true) ?>
    <div class="filter-actions">
        <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> Buscar</button>
        <a class="btn btn-outline-secondary" href="/personal"><i class="fa fa-eraser"></i> Limpiar filtro</a>
    </div>
</form>

<?= pb_registros(count($personas)) ?>
<?= pb_tabla('Personal', '', false, 'bi-people') ?>
    <thead>
        <tr>
            <th data-pb-acciones>Acción</th>
            <th data-pb-titulo>Nombre</th>
            <th>Puesto</th>
            <th>Sucursal</th>
            <th>Usuario</th>
            <th data-pb-insignia>Estatus</th>
        </tr>
    </thead>
    <tbody>
    <?php if ($personas === []): ?>
        <?= pb_fila_vacia(6, $consulta === [] ? 'Aún no hay personal' : 'Sin personal con ese filtro') ?>
    <?php endif; ?>
    <?php foreach ($personas as $p): ?>
        <?php
        $activa  = (int) $p['id_estatus'] === 4;
        $nombre  = trim($p['nombre'] . ' ' . $p['apellido_paterno'] . ' ' . ($p['apellido_materno'] ?? ''));
        $id = (int) $p['id'];
        $esYo = $id === $identidad->idPersonal();
        $tieneUsuario = $p['usuario'] !== null;
        $usuarioActivo = $tieneUsuario && (int) $p['estatus_usuario'] === 4;
        $puedeGestionar = $admin && !$esYo;
        ?>
        <tr>
            <?= pb_acciones([
                pb_accion_detalle('modal-detalle-persona', (int) $p['id']),
                $admin && $activa ? pb_accion_modal('modalPersona', 'actualizar', (int) $p['id'], '/personal/' . (int) $p['id'], 'Actualizar persona', [], '/personal-detalle/' . (int) $p['id']) : '',
                $puedeGestionar && $usuarioActivo ? pb_accion_post('/personal/'.$id.'/usuario/clave', 'Restablecer contraseña', 'fa-key', 'Se crea una contraseña temporal y la actual deja de servir.') : '',
                $puedeGestionar && $usuarioActivo ? pb_accion_post('/personal/'.$id.'/usuario/baja', 'Bloquear acceso', 'fa-lock', '¿Bloquear el acceso de «'.$nombre.'»?', $volver, true) : '',
                $puedeGestionar && $tieneUsuario && !$usuarioActivo && $activa ? pb_accion_post('/personal/'.$id.'/usuario/reactiva', 'Desbloquear acceso', 'fa-unlock', 'Recibirá una contraseña temporal nueva.') : '',
                $puedeGestionar ? ($activa
                    ? pb_accion_post('/personal/'.$id.'/baja', 'Dar de baja', 'fa-close', '¿Dar de baja a «'.$nombre.'»? Pierde el acceso.', $volver, true)
                    : pb_accion_post('/personal/'.$id.'/reactiva', 'Reactivar', 'fa-undo', '¿Reactivar a «'.$nombre.'»? Su acceso sigue bloqueado.', $volver)) : '',
            ]) ?>
            <td><a class="fw-semibold" href="/personal/<?= (int) $p['id'] ?>"><?= $e($nombre) ?></a></td>
            <td><?= $e($p['puesto']) ?></td>
            <td><?= $p['sucursal'] !== null ? $e($p['sucursal']) : '<span class="text-secondary">Todas</span>' ?></td>
            <td>
                <?php if ($p['usuario'] !== null): ?><code><?= $e($p['usuario']) ?></code><br><?php endif; ?>
                <?= $acceso($p) ?>
            </td>
            <td><?= pb_estatus($activa, 'Activo', 'Dado de baja') ?></td>

        </tr>
    <?php endforeach; ?>
    </tbody>
<?= pb_tabla_fin() ?>

<?= pb_modulo_fin() ?>

<?= pb_detalle('modal-detalle-persona', 'Persona', '/personal-detalle', 'modal-xl', $mostrarCredencial ? '?credencial=1' : '') ?>
<?php if ($personaSolicitada > 0): ?><noscript><p>Para abrir la ficha sin JavaScript, <a href="/personal/<?= $personaSolicitada ?>?sinjs=1">consulte la persona</a>.</p></noscript><?php endif; ?>

<?php if ($admin): ?>
    <?php require __DIR__ . '/modal-persona.php'; ?>
<?php endif; ?>
