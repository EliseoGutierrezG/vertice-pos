<?php
/**
 * La ficha de una persona: sus datos, su acceso y sus equipos.
 *
 * El acceso va en dos pasos, como en `R/mtto/admin/rh/personal/`: la persona
 * ya existe, y aquí se le crea el usuario. La contraseña que sale es temporal,
 * se muestra **una vez** —viene de la sesión y ya se borró de ahí— y obliga a
 * cambiarla al entrar.
 *
 * @var callable $e
 * @var \Nucleo\Csrf $csrf
 * @var \Nucleo\Identidad $identidad
 * @var array<string,mixed> $persona
 * @var array{usuario:string,clave:string}|null $temporal
 * @var string $sugerencia
 * @var list<array<string,mixed>> $telefonos
 * @var array<string,string> $sucursales
 * @var array<string,string> $puestos
 * @var array<string,string> $superiores
 */
$admin     = $identidad->puede('personal_admin');
$id        = (int) $persona['id'];
$activa    = (int) $persona['id_estatus'] === 4;
$volver    = '/personal/' . $id;
$nombre    = trim($persona['nombre'] . ' ' . $persona['apellido_paterno'] . ' ' . ($persona['apellido_materno'] ?? ''));
$tieneUsr  = $persona['id_usuario'] !== null;
$usrActivo = $tieneUsr && (int) $persona['estatus_usuario'] === 4;
$esYo      = $id === $identidad->idPersonal();

/** Un formulario de un botón, confirmado con SweetAlert2 y mandado por `fetch`. */
$boton = static function (string $accion, string $texto, string $icono, string $pregunta, string $marca, bool $peligro = false, array $ocultos = []) use ($e): string {
    $html = '<form class="d-inline" method="post" action="' . $e($accion) . '" data-pb-ajax'
        . ' data-confirma="' . $e($pregunta) . '" data-confirma-titulo="' . $e($texto) . '">' . $marca;
    foreach ($ocultos as $n => $v) {
        $html .= '<input type="hidden" name="' . $e($n) . '" value="' . $e($v) . '">';
    }

    return $html . '<button type="submit" class="btn btn-sm ' . ($peligro ? 'btn-outline-danger' : 'btn-outline-secondary') . '">'
        . '<i class="bi ' . $e($icono) . '" aria-hidden="true"></i> ' . $e($texto) . '</button></form>';
};

$vacio = '<span class="text-secondary">—</span>';
?>

<?php if ($temporal !== null): ?>
    <div class="alert alert-warning" role="alert" data-pb-clave-temporal>
        <div class="d-flex gap-2 align-items-start">
            <i class="bi bi-key-fill" aria-hidden="true"></i>
            <div>
                <strong>Contraseña temporal de <code><?= $e($temporal['usuario']) ?></code>:</strong>
                <code class="fs-5 ms-1"><?= $e($temporal['clave']) ?></code>
                <div class="small mt-1">
                    Anótela o entréguela ahora: <strong>no se vuelve a mostrar</strong>.
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-6">
        <?= pb_seccion('bi-info-circle', 'Datos') ?>
            <dl class="detail-list">
                <div class="detail-list__row"><dt>Estatus</dt><dd><?= pb_estatus($activa, 'Activo', 'Dado de baja') ?></dd></div>
                <div class="detail-list__row"><dt>Puesto</dt><dd><?= $e($persona['puesto']) ?></dd></div>
                <div class="detail-list__row"><dt>Sucursal</dt><dd><?= $persona['sucursal'] !== null ? $e($persona['sucursal']) : 'Todas' ?></dd></div>
                <div class="detail-list__row"><dt>Superior</dt><dd><?= $persona['superior'] !== null && $persona['superior'] !== '' ? $e($persona['superior']) : $vacio ?></dd></div>
                <div class="detail-list__row"><dt>Teléfono</dt><dd><?= $persona['telefono'] !== null ? $e($persona['telefono']) : $vacio ?></dd></div>
                <div class="detail-list__row"><dt>Correo</dt><dd><?= $persona['correo'] !== null ? $e($persona['correo']) : $vacio ?></dd></div>
                <div class="detail-list__row"><dt>Ingreso</dt><dd><?= $e(pb_fecha($persona['fecha_ingreso'])) ?></dd></div>
                <?php if ($persona['fecha_baja'] !== null): ?>
                    <div class="detail-list__row"><dt>Baja</dt><dd><?= $e(pb_fecha($persona['fecha_baja'])) ?></dd></div>
                <?php endif; ?>
            </dl>
            <?php if ($admin && !$esYo): ?>
                <div class="mt-3"><?= $activa
                    ? $boton('/personal/' . $id . '/baja', 'Dar de baja', 'bi-power',
                        '¿Dar de baja a «' . $nombre . '»? Pierde el acceso.',
                        $csrf->campo(), true, ['volver' => $volver])
                    : $boton('/personal/' . $id . '/reactiva', 'Reactivar', 'bi-arrow-counterclockwise',
                        '¿Reactivar a «' . $nombre . '»? Su acceso sigue bloqueado.',
                        $csrf->campo(), false, ['volver' => $volver]) ?></div>
            <?php endif; ?>
        </section>
    </div>

    <div class="col-lg-6">
        <?= pb_seccion('bi-shield-lock', 'Acceso al sistema') ?>
            <?php if (!$tieneUsr): ?>
                <?php if ($admin && $activa): ?>
                    <form method="post" action="/personal/<?= $id ?>/usuario" data-pb-ajax>
                        <?= $csrf->campo() ?>
                        <div class="alert alert-danger d-none" role="alert" data-pb-error></div>
                        <div class="form-grid">
                            <?= pb_campo('usuario', 'Nombre de usuario', [
                                'id' => 'accesoUsuario', 'requerido' => true, 'largo' => '60', 'valor' => $sugerencia,
                                'autocompletado' => 'off', 'patron' => '[a-z0-9][a-z0-9._\-]{2,59}',
                                'ayuda' => 'Minúsculas sin acento, números, punto o guion.', 'clase' => 'form-grid__full',
                            ]) ?>
                        </div>
                        <div class="d-flex justify-content-end mt-2">
                            <button class="btn btn-primary" type="submit"><i class="bi bi-person-plus"></i> Crear usuario</button>
                        </div>
                    </form>
                <?php else: ?>
                    <p class="text-secondary mb-0">No tiene usuario.</p>
                <?php endif; ?>
            <?php else: ?>
                <dl class="detail-list">
                    <div class="detail-list__row"><dt>Usuario</dt><dd><code><?= $e($persona['usuario']) ?></code></dd></div>
                    <div class="detail-list__row"><dt>Acceso</dt><dd>
                        <?= $usrActivo ? pb_insignia('bien', 'Activo') : pb_insignia('mal', 'Bloqueado') ?>
                        <?php if ($usrActivo && (int) $persona['cambiar_clave'] === 1): ?>
                            <?= pb_insignia('avisa', 'Contraseña temporal') ?>
                        <?php endif; ?>
                    </dd></div>
                    <div class="detail-list__row"><dt>Último acceso</dt><dd><?= $persona['ultimo_acceso'] !== null ? $e(pb_fecha($persona['ultimo_acceso'])) : 'Nunca ha entrado' ?></dd></div>
                    <?php if (in_array((string) $persona['clave_puesto'], ['administrador','supervisor','almacen','compras'], true)): ?>
                    <div class="detail-list__row"><dt>Segundo factor</dt><dd>
                        <?= $persona['totp_confirmado_en'] !== null
                            ? pb_insignia('bien', 'Configurado')
                            : ((int) $persona['totp_iniciado'] === 1 ? pb_insignia('avisa', 'Configuración pendiente') : pb_insignia('mal', 'Sin configurar')) ?>
                    </dd></div>
                    <?php endif; ?>
                </dl>
                <?php if ($admin && !$esYo): ?>
                    <div class="d-flex flex-wrap gap-2 mt-3">
                        <?php if ($usrActivo): ?>
                            <?= $boton('/personal/' . $id . '/usuario/clave', 'Restablecer contraseña', 'bi-key',
                                'Se crea una contraseña temporal y la actual deja de servir.', $csrf->campo()) ?>
                            <?php if ((int) $persona['totp_iniciado'] === 1): ?>
                            <?= $boton('/personal/' . $id . '/usuario/segundo-factor', 'Restablecer segundo factor', 'bi-shield-x',
                                'Tendrá que configurar Authenticator de nuevo.', $csrf->campo(), true) ?>
                            <?php endif; ?>
                            <?= $boton('/personal/' . $id . '/usuario/baja', 'Bloquear acceso', 'bi-lock',
                                'No podrá entrar hasta que se reactive.', $csrf->campo(), true) ?>
                        <?php elseif ($activa): ?>
                            <?= $boton('/personal/' . $id . '/usuario/reactiva', 'Reactivar acceso', 'bi-unlock',
                                'Recibirá una contraseña temporal nueva.', $csrf->campo()) ?>
                        <?php endif; ?>
                    </div>
                <?php elseif ($esYo): ?>
                    <div class="mt-3"><?= pb_boton('/cambiar-clave', 'Cambiar mi contraseña', 'bi-key', 'outline-secondary') ?></div>
                <?php endif; ?>
            <?php endif; ?>
        </section>
    </div>
</div>

<?php require __DIR__ . '/sucursales-adicionales.php'; ?>

<?php if ($tieneUsr): ?>
    <?= pb_seccion('bi-phone', 'Equipos', ((int) $persona['usa_app'] === 1 ? '' : 'Su puesto no usa la app.')) ?>
        <?= pb_tabla('Equipos de ' . $nombre, 'simple', false, 'bi-phone') ?>
            <thead>
                <tr>
                    <th data-pb-titulo>Equipo</th>
                    <th>Último acceso</th>
                    <th data-pb-insignia>Estatus</th>
                    <?php if ($admin): ?><th class="no-orden" data-pb-acciones>Acción</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php if ($telefonos === []): ?>
                <?= pb_fila_vacia($admin ? 4 : 3, 'Aún no hay equipos') ?>
            <?php endif; ?>
            <?php foreach ($telefonos as $t): ?>
                <?php $autorizado = (int) $t['autorizado'] === 1; ?>
                <tr>
                    <td><span class="fw-semibold"><?= $e($t['nombre'] ?? 'Sin nombre') ?></span><br><code class="small"><?= $e(substr((string) $t['identificador'], 0, 12)) ?>…</code></td>
                    <td data-order="<?= $e($t['ultimo_acceso'] ?? '') ?>"><?= $t['ultimo_acceso'] !== null ? $e(pb_fecha($t['ultimo_acceso'])) : $vacio ?></td>
                    <td><?= $autorizado ? pb_insignia('bien', 'Autorizado') : pb_insignia('avisa', 'En espera') ?></td>
                    <?php if ($admin): ?>
                        <td class="table-actions">
                            <?php if ($autorizado): ?>
                                <?= $boton('/dispositivos/' . (int) $t['id'] . '/retira', 'Retirar', 'bi-phone-vibrate', 'El equipo dejará de entrar.', $csrf->campo(), true, ['volver' => $volver]) ?>
                            <?php elseif ((int) $persona['usa_app'] === 1 && $usrActivo): ?>
                                <?= $boton('/dispositivos/' . (int) $t['id'] . '/autoriza', 'Autorizar', 'bi-check2', 'Este equipo podrá operar con la cuenta de ' . $nombre . '.', $csrf->campo(), false, ['volver' => $volver]) ?>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        <?= pb_tabla_fin() ?>
    </section>
<?php endif; ?>

