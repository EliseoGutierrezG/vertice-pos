<?php
$opcionesAlcance = array_diff_key($sucursales, [(int) $persona['id_sucursal'] => true]);
$actuales = array_intersect_key($opcionesAlcance, array_fill_keys($asignadas, true));
?>
<?php if (\Nucleo\Giro::activo('restaurante') && $tieneUsr && $persona['clave_puesto'] !== 'administrador'): ?>
    <?= pb_seccion('bi-buildings', 'Sucursales adicionales') ?>
    <?php if ($admin && $activa && !$esYo && $opcionesAlcance !== []): ?>
        <form class="form-grid" method="post" action="/personal/<?= (int) $id ?>/usuario/sucursales" data-pb-ajax>
            <?= $csrf->campo() ?>
            <div class="alert alert-danger d-none form-grid__full" role="alert" data-pb-error></div>
            <fieldset class="form-grid__full">
                <legend class="h6">Sucursales con acceso</legend>
                <?php foreach ($opcionesAlcance as $idOpcion => $nombreOpcion): ?>
                    <label class="form-check">
                        <input type="checkbox" class="form-check-input" name="sucursales[]" value="<?= (int) $idOpcion ?>"
                            <?= isset($actuales[$idOpcion]) ? 'checked' : '' ?>>
                        <span class="form-check-label"><?= $e($nombreOpcion) ?></span>
                    </label>
                <?php endforeach; ?>
            </fieldset>
            <div class="form-grid__full">
                <button type="submit" class="btn btn-outline-primary">Guardar sucursales</button>
            </div>
        </form>
    <?php else: ?>
        <p><?= $e($actuales === [] ? 'Sin sucursales adicionales' : implode(', ', $actuales)) ?></p>
    <?php endif; ?>
    </section>
<?php endif; ?>
