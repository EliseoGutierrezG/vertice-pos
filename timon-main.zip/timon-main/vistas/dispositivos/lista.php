<?php
/**
 * Equipos. La app los registra al entrar con usuario y contraseña; hasta que
 * se autorizan aquí, solo pueden preguntar si ya los autorizaron. La fila
 * lleva Ver, Autorizar y Revocar acceso; «Enviar notificación» es un modal del
 * encabezado.
 *
 * @var callable $e
 * @var \Nucleo\Csrf $csrf
 * @var \Nucleo\Identidad $identidad
 * @var list<array<string,mixed>> $telefonos
 * @var string $filtro
 */
$admin  = $identidad->puede('personal_admin');
$puedeNotificar = $identidad->puede('notificaciones_envia');
$volver = '/dispositivos' . ($filtro === 'pendientes' ? '' : '?filtro=' . $filtro);
$vacio  = '<span class="text-secondary">—</span>';
$destinos = array_values(array_filter($telefonos, static fn (array $t): bool => (int) $t['autorizado'] === 1 && (int) $t['push_listo'] === 1));

$textoVacio = match ($filtro) {
    'pendientes'  => 'Sin equipos por autorizar',
    'autorizados' => 'Sin equipos autorizados',
    default       => 'Aún no entra ningún equipo',
};
$encabezado = ($puedeNotificar && $destinos !== [] ? pb_agregar('modal-notificacion', 'Enviar notificación', 'Enviar notificación') : '')
    . pb_exportar('/dispositivos.xlsx');

?>
<?= pb_modulo('bi-tablet', $titulo, 'Equipos de la app por persona: autorización y último acceso.', $encabezado) ?>

<?= pb_filtros('/dispositivos') ?>
    <?= pb_campo('filtro', 'Mostrar', [
        'tipo' => 'select', 'id' => 'filtroDispositivos', 'nativo' => true, 'valor' => $filtro,
        'opciones' => ['pendientes' => 'En espera de autorización', 'autorizados' => 'Autorizados', 'todos' => 'Todos'],
        'ayuda' => 'La autorización es por persona y equipo.',
    ]) ?>
<?= pb_filtros_fin('/dispositivos') ?>

<?= pb_registros(count($telefonos)) ?>
<?= pb_tabla($titulo, '', false, 'bi-tablet') ?>
    <thead>
        <tr>
            <th class="no-orden" data-pb-acciones>Acción</th>
            <th data-pb-titulo>Persona</th>
            <th>Puesto</th>
            <th>Sucursal</th>
            <th>Equipo</th>
            <th>Último acceso</th>
            <th data-pb-insignia>Estatus</th>
        </tr>
    </thead>
    <tbody>
    <?php if ($telefonos === []): ?>
        <?= pb_fila_vacia(7, $textoVacio) ?>
    <?php endif; ?>
    <?php foreach ($telefonos as $t): ?>
        <?php
        $id = (int) $t['id'];
        $autorizado = (int) $t['autorizado'] === 1;
        $puedeUsar  = (int) $t['usa_app'] === 1 && (int) $t['estatus_usuario'] === 4;
        ?>
        <tr>
            <?= pb_acciones([
                pb_accion_detalle('modal-detalle-telefono', $id),
                $admin && !$autorizado && $puedeUsar ? pb_accion_post('/dispositivos/' . $id . '/autoriza', 'Autorizar', 'fa-check', '¿Autorizar este equipo de ' . $t['persona'] . '?', $volver) : '',
                $admin && $autorizado ? pb_accion_post('/dispositivos/' . $id . '/retira', 'Revocar acceso', 'fa-ban', '¿Revocar el acceso? El equipo dejará de entrar.', $volver, true) : '',
            ]) ?>
            <td><strong><?= $e($t['persona']) ?></strong><br><code class="small"><?= $e($t['usuario']) ?></code></td>
            <td><?= $e($t['puesto']) ?></td>
            <td><?= $t['sucursal'] !== null ? $e($t['sucursal']) : 'Todas' ?></td>
            <td><?= $e($t['nombre'] ?? 'Sin nombre') ?><br><code class="small"><?= $e(substr((string) $t['identificador'], 0, 12)) ?>…</code></td>
            <td data-order="<?= $e($t['ultimo_acceso'] ?? '') ?>"><?= $t['ultimo_acceso'] !== null ? $e(pb_fecha($t['ultimo_acceso'])) : $vacio ?></td>
            <td>
                <?= $autorizado ? pb_insignia('bien', 'Autorizado') : pb_insignia('avisa', 'En espera') ?>
                <?php if ($autorizado): ?><br><?= (int) $t['push_listo'] === 1 ? pb_insignia('bien', 'Avisos listos') : pb_insignia('mudo', 'Sin avisos') ?><?php endif; ?>
                <?php if (!$puedeUsar): ?><br><span class="small text-secondary"><?= (int) $t['usa_app'] === 1 ? 'Acceso bloqueado' : 'Su puesto no usa la app' ?></span><?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
<?= pb_tabla_fin() ?>
<?= pb_modulo_fin() ?>
<?= pb_detalle('modal-detalle-telefono', 'Equipo', '/dispositivos', 'modal-lg') ?>

<?php if ($puedeNotificar && $destinos !== []): ?>
<?= pb_modal('modal-notificacion', 'Enviar notificación', '/dispositivos/notificacion', $csrf->campo(), '/dispositivos?filtro=autorizados') ?>
<?= pb_seccion('bi-bell', 'Aviso', 'Llega a equipos con avisos listos.') ?><div class="form-grid">
    <?= pb_campo('destino', 'Equipo', ['tipo' => 'select', 'nativo' => true, 'opciones' => array_column($destinos, 'persona', 'id'), 'vacia' => 'Seleccione', 'requerido' => true]) ?>
    <?= pb_campo('titulo', 'Título', ['valor' => 'Aviso', 'requerido' => true, 'largo' => '80']) ?>
    <?= pb_campo('cuerpo', 'Mensaje', ['requerido' => true, 'largo' => '255', 'marcador' => 'Capture el aviso', 'clase' => 'field-span-2']) ?>
</div></section>
<?= pb_modal_fin('Enviar', 'fa-send') ?>
<?php endif; ?>
