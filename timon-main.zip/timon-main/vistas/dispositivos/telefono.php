<?php
/**
 * Ver de un equipo: de quién es, cuándo se autorizó y su último
 * acceso. Autorizar y Revocar acceso son acciones de la fila.
 *
 * @var callable $e @var array<string,mixed> $telefono
 */
$t = $telefono;
$autorizado = (int) $t['autorizado'] === 1;
?>
<?= pb_seccion('bi-tablet', 'Datos') ?>
<dl class="detail-list">
<div class="detail-list__row"><dt>Persona</dt><dd><?= $e($t['persona']) ?> · <code><?= $e($t['usuario']) ?></code></dd></div>
<div class="detail-list__row"><dt>Puesto</dt><dd><?= $e($t['puesto']) ?></dd></div>
<div class="detail-list__row"><dt>Sucursal</dt><dd><?= $t['sucursal'] !== null ? $e($t['sucursal']) : 'Todas' ?></dd></div>
<div class="detail-list__row"><dt>Equipo</dt><dd><?= $e($t['nombre'] ?? 'Sin nombre') ?><?= $t['plataforma'] ? ' · ' . $e($t['plataforma']) : '' ?></dd></div>
<div class="detail-list__row"><dt>Identificador</dt><dd><code><?= $e(substr((string) $t['identificador'], 0, 12)) ?>…</code></dd></div>
<div class="detail-list__row"><dt>Estatus</dt><dd><?= $autorizado ? pb_insignia('bien', 'Autorizado') : pb_insignia('avisa', 'En espera') ?></dd></div>
<div class="detail-list__row"><dt>Autorizado</dt><dd><?= $t['autorizado_en'] !== null ? $e(pb_fecha($t['autorizado_en'])) : '—' ?></dd></div>
<div class="detail-list__row"><dt>Último acceso</dt><dd><?= $t['ultimo_acceso'] !== null ? $e(pb_fecha($t['ultimo_acceso'])) : '—' ?></dd></div>
<div class="detail-list__row"><dt>Avisos</dt><dd><?= (int) $t['push_listo'] === 1 ? 'Listos' : 'Sin avisos' ?></dd></div>
</dl>
<p class="mb-0"><a href="/personal?ver=<?= (int) $t['id_personal'] ?>">Ver a la persona</a></p>
</section>
