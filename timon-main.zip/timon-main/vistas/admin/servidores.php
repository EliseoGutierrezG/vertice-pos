<?php
/**
 * Servidores de sucursal: una fila por sucursal, con dónde opera y cómo va
 * su sincronización con el central.
 *
 * Debajo, las versiones del sistema registradas y a cuál se actualiza cada
 * computadora: se instala sola cuando no hay cuentas ni turno abiertos.
 *
 * @var list<array<string,mixed>> $servidores
 * @var list<array<string,mixed>> $liberaciones
 * @var int $minutos
 */
$libres = [];
foreach ($servidores as $s) {
    if ($s['id'] === null && $s['servidor'] === 'central') {
        $libres[(int) $s['id_sucursal']] = (string) $s['sucursal'];
    }
}
$hora = static fn (?string $momento): string => $momento === null ? 'Nunca' : date('d/m/Y H:i', strtotime($momento));
$locales = [];
foreach ($servidores as $s) {
    if ($s['servidor'] === 'local' && $s['id'] !== null) {
        $locales[(int) $s['id']] = (string) $s['sucursal'];
    }
}
$versiones = ['' => 'Quedarse con la que tiene'];
foreach ($liberaciones as $l) {
    $versiones[(string) $l['id']] = (string) $l['id'];
}
echo pb_modulo('bi-hdd-network', $titulo, 'Sucursales que siguen operando sin internet.',
    $libres !== [] ? pb_agregar('servidorModal', 'Registrar', 'Registrar computadora') : '');
?>
<?= pb_registros(count($servidores)) ?>
<?= pb_tabla('Computadoras de sucursal') ?>
<thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Sucursal</th><th data-pb-insignia>Opera en</th><th>Computadora</th>
    <th>Última subida</th><th>Última bajada</th><th>Por subir</th><th>Versión</th><th>Actualización</th><th data-pb-insignia>Estado</th></tr></thead>
<tbody>
<?php if ($servidores === []): ?><?= pb_fila_vacia(10, 'Aún no hay sucursales activas') ?><?php endif; ?>
<?php foreach ($servidores as $s): ?>
    <?php $local = $s['servidor'] === 'local'; ?>
    <tr>
        <?= pb_acciones($local && $s['id'] !== null ? [
            pb_accion_post('/servidores/' . (int) $s['id'] . '/regresar', 'Regresar al central', 'fa-undo',
                '¿Operar «' . $s['sucursal'] . '» de nuevo en el central? Antes apague su servidor.', '/servidores', true, [], true),
        ] : []) ?>
        <td><?= $e($s['sucursal']) ?></td>
        <td><?= $local ? pb_insignia('info', 'Su computadora') : pb_insignia('mudo', 'Central') ?></td>
        <td><?= $e($s['nombre'] ?? '—') ?></td>
        <td><?= $local ? $e($hora($s['ultima_subida'])) : '—' ?></td>
        <td><?= $local ? $e($hora($s['ultima_bajada'])) : '—' ?></td>
        <td><?= $local ? (int) $s['pendientes'] : '—' ?></td>
        <td><?= $local ? $e($s['version'] !== '' ? $s['version'] : '—') : '—' ?></td>
        <td><?php if (!$local): ?>—
            <?php elseif ($s['liberacion_asignada'] === null || $s['liberacion_asignada'] === $s['version']): ?><?= $e($s['actualizacion'] !== '' ? $s['actualizacion'] : 'Sin cambios pendientes') ?>
            <?php else: ?><?= pb_insignia((int) $s['actualizacion_error'] === 1 ? 'error' : 'info', 'Va a ' . $s['liberacion_asignada']) ?>
                <small><?= $e($s['actualizacion']) ?></small><?php endif; ?></td>
        <td><?php if (!$local): ?>—
            <?php elseif ((string) $s['ultimo_error'] !== ''): ?><?= pb_insignia('error', 'Con error') ?> <small><?= $e($s['ultimo_error']) ?></small>
            <?php elseif ((int) $s['sin_noticias'] === 1): ?><?= pb_insignia('advertencia', 'Sin noticias') ?>
            <?php else: ?><?= pb_insignia('exito', 'Al día') ?><?php endif; ?></td>
    </tr>
<?php endforeach; ?>
</tbody>
<?= pb_tabla_fin() ?>
<?= pb_aviso('info', 'Sin noticias en ' . $minutos . ' minutos. La sucursal sigue operando.') ?>

<?= pb_seccion('bi-box-seam', 'Versiones del sistema', 'Actualización automática con la sucursal cerrada.') ?>
<div class="d-flex gap-2 mb-3">
    <?= pb_agregar('versionModal', 'Subir versión', 'Subir versión') ?>
    <?php if ($locales !== [] && $liberaciones !== []): ?><?= pb_agregar('asignaModal', 'Asignar versión', 'Asignar versión') ?><?php endif; ?>
</div>
<?= pb_tabla('Versiones registradas') ?>
<thead><tr><th data-pb-titulo>Versión</th><th>Esquema</th><th>Peso</th><th>Registrada</th><th>Asignada a</th><th>Instalada en</th><th>Notas</th></tr></thead>
<tbody>
<?php if ($liberaciones === []): ?><?= pb_fila_vacia(7, 'Aún no hay versiones registradas') ?><?php endif; ?>
<?php foreach ($liberaciones as $l): ?>
    <tr>
        <td><?= $e($l['id']) ?></td>
        <td><?= (int) $l['esquema'] ?></td>
        <td><?= $e(number_format((int) $l['peso'] / 1048576, 1) . ' MB') ?></td>
        <td><?= $e($hora($l['creada_en'])) ?></td>
        <td><?= (int) $l['asignada_a'] ?></td>
        <td><?= (int) $l['instalada_en'] ?></td>
        <td><?= $e($l['notas'] !== '' ? $l['notas'] : '—') ?></td>
    </tr>
<?php endforeach; ?>
</tbody>
<?= pb_tabla_fin() ?>
<?= pb_modulo_fin() ?>

<?= pb_modal('versionModal', 'Subir versión', '/servidores/versiones', $csrf->campo(), '', 'modal-lg',
    'Seleccione los dos archivos de la versión.', true) ?>
<div class="form-grid">
    <?= pb_campo('paquete', 'Paquete', ['tipo' => 'file', 'requerido' => true, 'extra' => ['accept' => '.gz,.tar.gz'],
        'ayuda' => 'El archivo .tar.gz.']) ?>
    <?= pb_campo('firma', 'Firma', ['tipo' => 'file', 'requerido' => true, 'extra' => ['accept' => '.json'],
        'ayuda' => 'Firma del mismo paquete.']) ?>
    <?= pb_campo('notas', 'Notas', ['largo' => 300, 'ayuda' => 'Qué cambia, para quien la asigne.']) ?>
</div>
<?= pb_modal_fin() ?>

<?php if ($locales !== [] && $liberaciones !== []): ?>
    <?= pb_modal('asignaModal', 'Asignar versión', '/servidores/version', $csrf->campo(), '', 'modal-lg',
        'Se instala cuando cierran las cuentas y la caja.') ?>
    <div class="form-grid">
        <?= pb_campo('instalacion', 'Sucursal', ['tipo' => 'select', 'nativo' => true, 'opciones' => $locales, 'requerido' => true]) ?>
        <?= pb_campo('liberacion', 'Versión', ['tipo' => 'select', 'nativo' => true, 'opciones' => $versiones,
            'ayuda' => 'Pruebe primero en una sola sucursal.']) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>

<?php if ($libres !== []): ?>
    <?= pb_modal('servidorModal', 'Registrar computadora', '/servidores', $csrf->campo(), '', 'modal-lg',
        'Opera sola desde ahora. Los campos con * son obligatorios.') ?>
    <div class="form-grid">
        <?= pb_campo('sucursal', 'Sucursal', ['tipo' => 'select', 'nativo' => true, 'opciones' => $libres, 'requerido' => true,
            'ayuda' => 'Sin cuentas ni turno abiertos.']) ?>
        <?= pb_campo('nombre', 'Nombre de la computadora', ['largo' => 80, 'requerido' => true, 'ayuda' => 'Por ejemplo, mini PC de caja.']) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>
