<?php
/**
 * Las piezas que se repiten en las pantallas, con el vocabulario de la plantilla base.
 *
 * Cada función devuelve el mismo marcado que la plantilla base escribe a mano en sus
 * vistas —`module-card`, `module-header`, `table-zone`, `form-section`,
 * `form-grid`, `badge rounded-pill`, `alert`— para que ninguna pantalla
 * invente clases propias. Son funciones y no fragmentos con `include` por
 * **el escape**: devuelven HTML ya escapado, así que una vista no puede
 * olvidar `$e()`. Las que reciben HTML ya hecho lo dicen en el nombre del
 * parámetro (`$accionesHtml`, `$accionHtml`) y son las únicas.
 *
 * El catálogo de clases de la plantilla base y qué pieza emite cada una está en
 * design-system/plantilla/MASTER.md.
 *
 * ⚠️ Se carga **una vez** desde la plantilla base. Las guardas
 * `function_exists` están porque `Vista::suelta()` hace `require` y una
 * pantalla pintada dentro de otra volvería a entrar aquí.
 */

if (!function_exists('pb_escapa')) {
    function pb_escapa(mixed $valor): string
    {
        return htmlspecialchars((string) $valor, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('pb_ico')) {
    /**
     * Un icono de Bootstrap Icons (`bi-…`) o de Font Awesome 4 (`fa-…`), las
     * dos familias de la plantilla base. Decorativo: su significado está en el texto
     * de al lado; si no hay texto, el botón lleva `aria-label`.
     */
    function pb_ico(string $nombre, string $clase = ''): string
    {
        $familia = str_starts_with($nombre, 'fa-') ? 'fa ' : 'bi ';
        $nombre  = str_starts_with($nombre, 'fa-') || str_starts_with($nombre, 'bi-') ? $nombre : 'bi-' . $nombre;

        return '<i class="' . pb_escapa(trim($familia . $nombre . ' ' . $clase)) . '" aria-hidden="true"></i>';
    }
}

if (!function_exists('pb_marca_logo')) {
    /**
     * El logotipo de la instalación (D24): el propio si `config/marca-visual.php`
     * trae uno válido, la de El Timón si no. `$variante` elige la pieza de El Timón:
     * `isotipo` (la placa), `simbolo` (en claro, para ir sobre
     * marino), `monocromo` (un solo color: papel térmico) u `horizontal`.
     */
    function pb_marca_logo(?\Servicios\MarcaVisual $marca, string $variante = 'isotipo', string $alt = '', string $clase = ''): string
    {
        $atributos = ($clase !== '' ? ' class="' . pb_escapa($clase) . '"' : '') . ' alt="' . pb_escapa($alt) . '"';

        if ($marca !== null && $marca->logo() !== null) {
            return '<img src="/marca/logo?v=' . pb_escapa($marca->revision()) . '"' . $atributos . ' decoding="async">';
        }

        $archivo = match ($variante) {
            'simbolo'    => 'simbolo.svg',
            'monocromo'  => 'logo-monocromo.svg',
            'horizontal' => 'logo-horizontal.svg',
            default      => 'isotipo.svg',
        };

        return '<img src="/recursos/' . $archivo . '?v=20261114.2"' . $atributos . '>';
    }
}

if (!function_exists('pb_marca_texto')) {
    /** Nombre, nombre corto o lema de la instalación, ya escapado. */
    function pb_marca_texto(?\Servicios\MarcaVisual $marca, string $campo = 'nombre'): string
    {
        $vigente = $marca?->vigente() ?? \Servicios\MarcaVisual::BASE;
        $valor = in_array($campo, ['nombre', 'nombre_corto', 'lema'], true) ? $vigente[$campo] : $vigente['nombre'];

        return pb_escapa($valor);
    }
}

if (!function_exists('pb_tono')) {
    /**
     * Los tonos del sistema en los colores semánticos de Bootstrap que usa
     * la plantilla base. Los nombres viejos —`bien`, `mal`, `si`, `no`— siguen valiendo
     * porque los usan `Sesion::avisa()` y varios controladores.
     *
     * @return array{0:string,1:string} el color de Bootstrap y el icono
     */
    function pb_tono(string $tono): array
    {
        return match ($tono) {
            'bien', 'exito', 'si'   => ['success',   'bi-check-circle'],
            'avisa', 'advertencia'  => ['warning',   'bi-exclamation-triangle'],
            'mal', 'error', 'no'    => ['danger',    'bi-x-circle'],
            'mudo', 'desconexion'   => ['secondary', 'bi-wifi-off'],
            'marca'                 => ['dark',      'bi-star'],
            'info'                  => ['info',      'bi-info-circle'],
            default                 => ['secondary', 'bi-clock'],
        };
    }
}

if (!function_exists('pb_insignia')) {
    /**
     * Un estatus en tabla o tarjeta: `badge rounded-pill status-*`, como
     * `AppDataTables.badge` con las clases de estatus (guía §4.1, O1). Las de
     * `main.css` son `status-active` y `status-inactive`; las demás —advertencia,
     * información, neutro— son globales de `tema.css`.
     */
    function pb_insignia(string $tono, string $texto, ?string $icono = null): string
    {
        [$color] = pb_tono($tono);
        $clase = match ($color) {
            'success' => 'status-active',
            'danger'  => 'status-inactive',
            'warning' => 'status-warning',
            'info'    => 'status-info',
            default   => 'status-neutral',
        };

        return '<span class="badge rounded-pill ' . $clase . '">'
            . ($icono !== null ? pb_ico($icono) . ' ' : '')
            . pb_escapa($texto) . '</span>';
    }
}

if (!function_exists('pb_estatus')) {
    /** Activo o inactivo, con las clases `status-active` / `status-inactive` de la plantilla base. */
    function pb_estatus(bool $activo, string $si = 'Activo', string $no = 'Inactivo'): string
    {
        return '<span class="badge rounded-pill ' . ($activo ? 'status-active' : 'status-inactive') . '">'
            . pb_escapa($activo ? $si : $no) . '</span>';
    }
}

if (!function_exists('pb_aviso')) {
    /**
     * Un aviso: `alert alert-*`. Con `$anuncia` lo marca para que
     * `plantilla.js` además lo diga con SweetAlert2, como la plantilla base anuncia el
     * resultado de una operación. Sin JavaScript el aviso se lee igual.
     *
     * @param array<string,string> $campos errores por campo
     */
    function pb_aviso(string $tono, string $texto, array $campos = [], bool $anuncia = false): string
    {
        // Un aviso sin texto ni quejas era un cuadro con solo el icono (los
        // reportes sin notas, visto el 2026-11-13): no se pinta.
        if (trim($texto) === '' && $campos === []) {
            return '';
        }
        [$color, $icono] = pb_tono($tono);

        $html = '<div class="alert alert-' . $color . ' d-flex gap-2 align-items-start" role="alert"'
            . ($anuncia ? ' data-pb-aviso="' . $color . '"' : '') . '>'
            . pb_ico($icono)
            . '<div><span data-pb-aviso-texto>' . pb_escapa($texto) . '</span>';

        if ($campos !== []) {
            $html .= '<ul class="mb-0 mt-2">';
            foreach ($campos as $queja) {
                $html .= '<li>' . pb_escapa($queja) . '</li>';
            }
            $html .= '</ul>';
        }

        return $html . '</div></div>';
    }
}

if (!function_exists('pb_vacio')) {
    /**
     * El estado vacío fuera de una tabla: `module-state module-state--empty`.
     * Dice qué falta **y la acción que lo resuelve**; `$accionHtml` es el
     * botón ya armado por la vista.
     */
    function pb_vacio(string $titulo, string $texto = '', string $icono = 'bi-inbox', string $accionHtml = ''): string
    {
        return '<div class="module-state module-state--empty flex-column text-center">'
            . pb_ico($icono)
            . '<strong>' . pb_escapa($titulo) . '</strong>'
            . ($texto !== '' ? '<span>' . pb_escapa($texto) . '</span>' : '')
            . $accionHtml
            . '</div>';
    }
}

if (!function_exists('pb_modulo')) {
    /**
     * Abre la pantalla: `module-shell` > `module-card` > `module-header` con
     * `module-heading` (icono, título y subtítulo) y `module-actions`.
     * Se cierra con `pb_modulo_fin()`.
     *
     * Guía de construcción §1: el título es un `h2` —el CSS de RhToroV1 solo da
     * estilo a `.module-heading h2/p`— y **el subtítulo es obligatorio**: una
     * frase de una línea, la de la ficha de la pantalla. Sin él la pantalla no se
     * pinta fuera de producción, para que el olvido se vea al programar.
     *
     * `$accionesHtml`, en este orden: `pb_agregar()` · un verbo que crea
     * (`pb_verbo()`) · `pb_exportar()`. Ninguno lleva a otra pantalla (D7).
     * Lo que antes era un botón para leer algo, como «Ver el aviso» en
     * Privacidad, va como enlace al final del subtítulo: `$enlace` = [ruta, texto].
     *
     * @param array{0:string,1:string}|array{} $enlace
     */
    function pb_modulo(string $icono, string $titulo, string $descripcion = '', string $accionesHtml = '', string $clase = '', array $enlace = []): string
    {
        if (trim($descripcion) === '' && pb_exige_subtitulo()) {
            throw new \RuntimeException('La pantalla «' . $titulo . '» no tiene subtítulo (guía de construcción §1).');
        }

        return '<section class="module-shell' . ($clase !== '' ? ' ' . pb_escapa($clase) : '') . '">'
            . '<div class="module-card">'
            // El título de la pantalla es su h1 (2026-11-09): sin él, un lector de
            // pantalla no encuentra dónde empieza. Se ve igual que el h2 de RH.
            . pb_encabezado($icono, $titulo, $descripcion, $accionesHtml, 1, $enlace);
    }
}

if (!function_exists('pb_exige_subtitulo')) {
    /** Fuera de producción, una pantalla sin subtítulo es un error del programador. */
    function pb_exige_subtitulo(): bool
    {
        return (getenv('APP_ENTORNO') ?: 'desarrollo') !== 'produccion';
    }
}

if (!function_exists('pb_agregar')) {
    /** «Agregar» del encabezado: abre el modal en blanco (guía §2). */
    function pb_agregar(string $modal, string $texto = 'Agregar', string $tituloModal = ''): string
    {
        return '<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#' . pb_escapa($modal) . '"'
            . ' data-pb-modo="agregar"' . ($tituloModal !== '' ? ' data-pb-titulo="' . pb_escapa($tituloModal) . '"' : '') . '>'
            . pb_ico('fa-plus') . ' ' . pb_escapa($texto) . '</button>';
    }
}

if (!function_exists('pb_verbo')) {
    /**
     * Un verbo del encabezado que **crea algo** (Abrir turno, Armar): contorno
     * primario. Abre un modal; nunca lleva a otra pantalla (D7).
     */
    function pb_verbo(string $modal, string $texto, string $icono): string
    {
        return '<button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#' . pb_escapa($modal) . '"'
            . ' data-pb-modo="agregar">' . pb_ico($icono) . ' ' . pb_escapa($texto) . '</button>';
    }
}

if (!function_exists('pb_exportar')) {
    /**
     * «Exportar XLS» del encabezado (guía §7, D4). `$ruta` es la del archivo
     * (`/rutas.xlsx`); se le pegan **los filtros de la consulta que se ve**
     * —la de la URL—, no lo que tenga el formulario en ese momento. `plantilla.js`
     * lo baja por `fetch`: muestra que trabaja y, si el servidor dice que no, lo
     * dice en la misma pantalla en lugar de abrir una pestaña con el error.
     *
     * Solo se pinta si quien mira puede ver la pantalla, que es el permiso de
     * exportar (D21); la vista la llama donde ya tiene ese permiso.
     */
    function pb_exportar(string $ruta, ?array $filtros = null): string
    {
        $consulta = $filtros ?? $_GET;
        unset($consulta['ver'], $consulta['sondeo'], $consulta['pagina'], $consulta['por_pagina'],
            $consulta['cursor'], $consulta['antes'], $consulta['antes_de']);
        $href = $ruta . ($consulta === [] ? '' : '?' . http_build_query($consulta, encoding_type: PHP_QUERY_RFC3986));

        return '<a class="btn btn-outline-success" href="' . pb_escapa($href) . '" data-pb-exporta>'
            . pb_ico('fa-file-excel-o') . ' Exportar XLS</a>';
    }
}

if (!function_exists('pb_filtros')) {
    /**
     * Abre el formulario de filtros (guía §3). Los campos van en el orden fijo:
     * periodo, sucursal, oficina, ruta, catálogos de la pantalla, estatus y buscar.
     * Se cierra con `pb_filtros_fin()`.
     */
    function pb_filtros(string $accion, string $clase = ''): string
    {
        return '<form class="module-filters' . ($clase !== '' ? ' ' . pb_escapa($clase) : '') . '" method="get" action="' . pb_escapa($accion) . '">';
    }
}

if (!function_exists('pb_filtros_fin')) {
    /**
     * «Buscar» y «Limpiar filtro» (R78). Limpiar vuelve a los valores por
     * defecto de la ficha, que son los de la pantalla sin consulta (`$limpiar`).
     */
    /** `$hoy`: el botón «Hoy» junto a «Buscar», como en el Tablero; pone la fecha de hoy en el campo `fecha`. */
    function pb_filtros_fin(string $limpiar, bool $hoy = false): string
    {
        return '<div class="filter-actions">'
            . ($hoy ? '<button class="btn btn-outline-secondary" type="button" data-pb-hoy="' . pb_escapa(date('Y-m-d')) . '">' . pb_ico('bi-calendar-event') . ' Hoy</button>' : '')
            . '<button class="btn btn-primary" type="submit">' . pb_ico('fa-search') . ' Buscar</button>'
            . '<a class="btn btn-outline-secondary" href="' . pb_escapa($limpiar) . '">' . pb_ico('fa-eraser') . ' Limpiar filtro</a>'
            . '</div></form>';
    }
}

if (!function_exists('pb_rango')) {
    function pb_rango(string $desde, string $hasta): string
    {
        if (($desde === '') !== ($hasta === '')) {
            return pb_campo('desde', 'Desde', ['tipo' => 'fecha', 'valor' => $desde])
                . pb_campo('hasta', 'Hasta', ['tipo' => 'fecha', 'valor' => $hasta]);
        }
        return '<div class="field"><label for="periodo-consulta">Periodo</label>'
            . '<input type="text" id="periodo-consulta" class="form-control" data-app-date-range'
            . ' data-date-range-driver="daterangepicker" data-start-name="desde" data-end-name="hasta"'
            . ' placeholder="dd/mm/aaaa - dd/mm/aaaa" autocomplete="off">'
            . '<input type="hidden" name="desde" value="' . pb_escapa($desde) . '">'
            . '<input type="hidden" name="hasta" value="' . pb_escapa($hasta) . '"></div>';
    }
}

if (!function_exists('pb_registros')) {
    /** «N registros» en `module-summary` (guía §4.3, C3). */
    function pb_registros(int $cuantos, string $derechaHtml = ''): string
    {
        return pb_resumen(number_format($cuantos) . ($cuantos === 1 ? ' registro' : ' registros'), $derechaHtml);
    }
}

if (!function_exists('pb_acciones')) {
    /**
     * La celda «Acción», primera columna (guía §4.1): enlaces apilados en el
     * orden Ver · Actualizar · flujo · descargas · cierre. Cada enlace ya decidió
     * si se pinta (permiso y estatus); aquí solo se acomodan.
     *
     * @param list<string> $enlacesHtml
     */
    function pb_acciones(array $enlacesHtml): string
    {
        $enlaces = array_values(array_filter($enlacesHtml, static fn (string $h): bool => $h !== ''));

        // Un `<br>` después de cada enlace, como `AppDataTables.actionLink` de RH.
        return '<td class="table-actions">' . implode('', array_map(static fn (string $h): string => $h . '<br>', $enlaces)) . '</td>';
    }
}

if (!function_exists('pb_accion_modal')) {
    /**
     * Ver o Actualizar un registro en el modal de la pantalla (guía §5.2). Es un
     * enlace a `?ver={id}`, así funciona también abierto en otra pestaña, y abre
     * el modal sin salir del listado. `$modo`: `ver` (solo lectura) o `actualizar`.
     *
     * @param array<string,mixed> $registro los valores de los campos del modal
     */
    function pb_accion_modal(string $modal, string $modo, int|string $id, string $accion, string $titulo, array $registro, string $registroUrl = '', ?string $etiqueta = null): string
    {
        [$texto, $icono] = $modo === 'ver' ? ['Ver', 'fa-newspaper-o'] : ['Actualizar', 'fa-edit'];
        $texto = pb_escapa($etiqueta ?? $texto);
        // Una clave SAT es su propio id y puede empezar en cero (ficha 34).
        $id = pb_escapa((string) $id);

        // Con `$registroUrl` el registro se pide al abrir (un pedido con sus
        // productos no cabe en la fila); `$registro` adelanta lo que ya se sabe.
        return '<a class="label-default action-link" href="?ver=' . $id . '" role="button"'
            . ' data-bs-toggle="modal" data-bs-target="#' . pb_escapa($modal) . '"'
            . ' data-pb-modo="' . pb_escapa($modo) . '" data-pb-id="' . $id . '"'
            . ' data-pb-accion="' . pb_escapa($accion) . '" data-pb-titulo="' . pb_escapa($titulo) . '"'
            . ' data-pb-registro="' . pb_escapa((string) json_encode($registro, JSON_UNESCAPED_UNICODE)) . '"'
            . ($registroUrl !== '' ? ' data-pb-registro-url="' . pb_escapa($registroUrl) . '"' : '')
            . ' title="' . $texto . '">' . pb_ico($icono) . ' ' . $texto . '</a>';
    }
}

if (!function_exists('pb_detalle')) {
    /**
     * El modal de detalle (Fase 4): lo que antes era la página `{raiz}/{id}`.
     * `plantilla.js` pide ese mismo `GET` como JSON (`titulo`, `html`) al abrir;
     * la URL vieja redirige a `?ver={id}` y abre este modal. Es de solo lectura
     * y estático como los demás (M1); sus acciones son las de la fila.
     */
    function pb_detalle(string $id, string $titulo, string $raiz, string $tamano = 'modal-xl', string $consulta = ''): string
    {
        // `$consulta` se pega a `{raiz}/{id}`: una misma ficha con dos modos
        // (Ver y Registrar devolución, ficha 5).
        return '<div class="modal fade" id="' . pb_escapa($id) . '" tabindex="-1" aria-hidden="true"'
            . ' data-bs-backdrop="static" data-bs-keyboard="false" data-pb-detalle-raiz="' . pb_escapa($raiz) . '"'
            . ($consulta !== '' ? ' data-pb-detalle-consulta="' . pb_escapa($consulta) . '"' : '')
            . ' aria-labelledby="' . pb_escapa($id) . '-titulo">'
            . '<div class="modal-dialog ' . pb_escapa($tamano) . ' modal-dialog-scrollable modal-fullscreen-sm-down">'
            . '<div class="modal-content"><div class="modal-header">'
            . '<h5 class="modal-title" id="' . pb_escapa($id) . '-titulo" data-pb-modal-titulo data-pb-titulo-nueva="' . pb_escapa($titulo) . '">' . pb_escapa($titulo) . '</h5>'
            . '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>'
            . '</div><div class="modal-body" data-pb-detalle-cuerpo aria-live="polite"></div></div></div></div>';
    }
}

if (!function_exists('pb_accion_detalle')) {
    /** «Ver» de la fila que abre `pb_detalle` con ese registro. */
    function pb_accion_detalle(string $modal, int $id, string $texto = 'Ver', string $icono = 'fa-newspaper-o'): string
    {
        return '<a class="label-default action-link" href="?ver=' . $id . '" role="button"'
            . ' data-bs-toggle="modal" data-bs-target="#' . pb_escapa($modal) . '"'
            . ' data-pb-modo="ver" data-pb-id="' . $id . '" title="' . pb_escapa($texto) . '">'
            . pb_ico($icono) . ' ' . pb_escapa($texto) . '</a>';
    }
}

if (!function_exists('pb_accion_abre')) {
    /**
     * Una acción de la fila que abre un modal de captura con parte del registro
     * ya puesto (Desarmar con su lote, ficha 23): es un alta, no una edición.
     *
     * @param array<string,mixed> $registro
     */
    function pb_accion_abre(string $modal, string $texto, string $icono, string $titulo, array $registro, string $accion = ''): string
    {
        // Con `$accion` el alta va a otra ruta que la del modal (Agregar casco
        // de un producto, ficha 28).
        return '<a class="label-default action-link" href="#" role="button"'
            . ' data-bs-toggle="modal" data-bs-target="#' . pb_escapa($modal) . '" data-pb-modo="agregar"'
            . ($accion !== '' ? ' data-pb-accion="' . pb_escapa($accion) . '" data-pb-accion-alta' : '')
            . ' data-pb-titulo="' . pb_escapa($titulo) . '"'
            . ' data-pb-registro="' . pb_escapa((string) json_encode($registro, JSON_UNESCAPED_UNICODE)) . '"'
            . ' title="' . pb_escapa($texto) . '">' . pb_ico($icono) . ' ' . pb_escapa($texto) . '</a>';
    }
}

if (!function_exists('pb_accion_post')) {
    /**
     * Una acción de la fila que cambia algo (Dar de baja, Cancelar, Validar):
     * un **enlace**, no un formulario dentro de la fila (O4). `plantilla.js` pide
     * la confirmación con el nombre del registro y lo manda por POST con su
     * marca; si el servidor dice que no, el motivo sale en un aviso.
     */
    /**
     * `$campos` viaja con el envío (la fecha de la vista, un motivo fijo) y
     * `$unaVez` le agrega la llave de una sola vez (H6): la misma en cada
     * reintento del mismo enlace.
     *
     * @param array<string,string> $campos
     */
    function pb_accion_post(string $accion, string $texto, string $icono, string $pregunta, string $volver = '', bool $peligro = false, array $campos = [], bool $unaVez = false): string
    {
        return '<a class="label-default action-link' . ($peligro ? ' text-danger' : '') . '" href="#" role="button"'
            . ' data-pb-post="' . pb_escapa($accion) . '"'
            . ($volver !== '' ? ' data-pb-volver="' . pb_escapa($volver) . '"' : '')
            . ($campos !== [] ? ' data-pb-campos="' . pb_escapa((string) json_encode($campos, JSON_UNESCAPED_UNICODE)) . '"' : '')
            . ($unaVez ? ' data-pb-llave="' . pb_uuid() . '"' : '')
            . ' data-confirma="' . pb_escapa($pregunta) . '" data-confirma-titulo="' . pb_escapa($texto) . '"'
            . ' title="' . pb_escapa($texto) . '">' . pb_ico($icono) . ' ' . pb_escapa($texto) . '</a>';
    }
}

if (!function_exists('pb_dar_baja')) {
    /** Dar de baja o Reactivar un catálogo, al final de la columna Acción (D3). */
    function pb_dar_baja(string $raiz, int|string $id, bool $activo, string $nombre, string $volver = ''): string
    {
        return $activo
            ? pb_accion_post($raiz . '/' . $id . '/baja', 'Dar de baja', 'fa-close', '¿Dar de baja «' . $nombre . '»? Deja de ofrecerse.', $volver, true)
            : pb_accion_post($raiz . '/' . $id . '/reactiva', 'Reactivar', 'fa-undo', '¿Reactivar «' . $nombre . '»?', $volver);
    }
}

if (!function_exists('pb_encabezado')) {
    /** El `module-header`; por omisión es una sección interior (`h2`). */
    function pb_encabezado(
        string $icono,
        string $titulo,
        string $descripcion = '',
        string $accionesHtml = '',
        int $nivel = 2,
        array $enlace = []
    ): string
    {
        $etiqueta = $nivel === 1 ? 'h1' : 'h2';
        $despues = count($enlace) === 2
            ? ' <a href="' . pb_escapa($enlace[0]) . '">' . pb_escapa($enlace[1]) . '</a>'
            : '';

        return '<div class="module-header">'
            . '<div class="module-heading">'
            . '<span class="module-icon">' . pb_ico($icono) . '</span>'
            . '<div><' . $etiqueta . '>' . pb_escapa($titulo) . '</' . $etiqueta . '>'
            . ($descripcion !== '' ? '<p>' . pb_escapa($descripcion) . $despues . '</p>' : '')
            . '</div></div>'
            . ($accionesHtml !== '' ? '<div class="module-actions">' . $accionesHtml . '</div>' : '')
            . '</div>';
    }
}

if (!function_exists('pb_modulo_fin')) {
    function pb_modulo_fin(): string
    {
        return '</div></section>';
    }
}

if (!function_exists('pb_boton')) {
    /**
     * Un enlace con forma de botón de la plantilla base: `btn btn-primary`,
     * `btn-outline-secondary`, `btn-outline-success`…
     */
    function pb_boton(string $href, string $texto, string $icono = '', string $estilo = 'primary', array $extra = []): string
    {
        $atributos = '';
        foreach ($extra as $nombre => $valor) {
            $atributos .= ' ' . pb_escapa($nombre) . '="' . pb_escapa($valor) . '"';
        }

        return '<a class="btn btn-' . pb_escapa($estilo) . '" href="' . pb_escapa($href) . '"' . $atributos . '>'
            . ($icono !== '' ? pb_ico($icono) . ' ' : '') . pb_escapa($texto) . '</a>';
    }
}

if (!function_exists('pb_accion')) {
    /** Una acción de renglón: `label-default action-link`, como `AppDataTables.actionLink`. */
    function pb_accion(string $href, string $texto, string $icono = 'fa-pencil', array $extra = []): string
    {
        $atributos = '';
        foreach ($extra as $nombre => $valor) {
            $atributos .= ' ' . pb_escapa($nombre) . '="' . pb_escapa($valor) . '"';
        }

        return '<a class="label-default action-link" href="' . pb_escapa($href) . '" title="' . pb_escapa($texto) . '"' . $atributos . '>'
            . pb_ico($icono) . ' ' . pb_escapa($texto) . '</a>';
    }
}

if (!function_exists('pb_resumen')) {
    /** La línea `module-summary`: el conteo o el total del listado. */
    function pb_resumen(string $texto, string $derechaHtml = ''): string
    {
        // El espacio separa el conteo de lo de la derecha también para un lector de pantalla.
        return '<div class="module-summary"><span>' . pb_escapa($texto) . '</span>' . ($derechaHtml !== '' ? ' ' . $derechaHtml : '') . '</div>';
    }
}

if (!function_exists('pb_tabla')) {
    /**
     * Abre `table-zone` y la tabla con las clases de la plantilla base. `plantilla.js`
     * le monta DataTables y arma las `record-cards` del teléfono.
     *
     * `$modo`: `''` = listado completo (buscador, 25 por página), `'simple'` =
     * tabla corta de ficha, sin buscador ni paginación.
     */
    function pb_tabla(string $etiqueta, string $modo = '', bool $ancha = false, string $icono = 'bi-inbox'): string
    {
        // `pb-preparando`: hasta que `plantilla.js` la monta se ven sus primeros
        // renglones, no todos, para que no salte al paginarse.
        return '<div class="table-zone pb-preparando' . ($ancha ? ' table-wide' : '') . '">'
            . '<table class="table table-striped table-bordered table-hover dataTable dt-table-hover align-middle mb-0"'
            . ' aria-label="' . pb_escapa($etiqueta) . '"'
            . ' data-pb-tabla="' . pb_escapa($modo) . '"'
            . ' data-pb-vacio-icono="' . pb_escapa($icono) . '">';
    }
}

if (!function_exists('pb_tabla_fin')) {
    function pb_tabla_fin(): string
    {
        // En el teléfono las tarjetas las arma `plantilla.js`; mientras, su esqueleto.
        $tarjeta = '<div class="pb-esqueleto__tarjeta"><span class="pb-esqueleto__barra pb-esqueleto__barra--titulo"></span>'
            . str_repeat('<span class="pb-esqueleto__barra"></span>', 3) . '</div>';

        return '</table></div><div class="record-cards" aria-busy="true"><div class="pb-esqueleto">'
            . '<span class="visually-hidden">Cargando</span>' . str_repeat($tarjeta, 3) . '</div></div>';
    }
}

if (!function_exists('pb_tabla_captura')) {
    /**
     * Una tabla con campos por renglón: una compra, un conteo físico, una
     * entrega. **No lleva DataTables ni tarjetas**, a propósito:
     *
     * - DataTables saca del DOM los renglones de otras páginas y los que no
     *   pasan la búsqueda, y un campo fuera del DOM no se envía: la compra
     *   llegaría sin los productos de la página dos.
     * - Las tarjetas copian el HTML del renglón, y cada campo quedaría dos
     *   veces con el mismo nombre; PHP se queda con el último, el vacío.
     *
     * Va en `table-responsive`, como las tablas sueltas de la plantilla base: en el
     * teléfono se desliza y `main.js` pone el aviso de deslizar.
     */
    function pb_tabla_captura(string $etiqueta): string
    {
        return '<div class="table-responsive">'
            . '<table class="table table-striped table-bordered table-hover align-middle mb-0 pb-captura" aria-label="' . pb_escapa($etiqueta) . '">';
    }
}

if (!function_exists('pb_tabla_captura_fin')) {
    function pb_tabla_captura_fin(): string
    {
        return '</table></div>';
    }
}

if (!function_exists('pb_fila_vacia')) {
    /**
     * El renglón de «no hay nada». Sin JavaScript se lee como renglón; con
     * JavaScript `plantilla.js` lo quita y su texto pasa a ser el `emptyTable`
     * de DataTables y la tarjeta vacía del teléfono.
     */
    function pb_fila_vacia(int $columnas, string $texto): string
    {
        return '<tr data-pb-vacio><td colspan="' . $columnas . '" class="text-center text-secondary py-4">'
            . pb_escapa($texto) . '</td></tr>';
    }
}

if (!function_exists('pb_seccion')) {
    /**
     * Abre una `form-section` con su `form-section-title`, como las secciones
     * de los modales de la plantilla base. Se cierra con `</section>`.
     */
    function pb_seccion(string $icono, string $titulo, string $ayuda = '', string $clase = ''): string
    {
        return '<section class="form-section' . ($clase !== '' ? ' ' . pb_escapa($clase) : '') . '">'
            . '<div class="form-section-title">'
            . '<span>' . pb_ico($icono) . ' ' . pb_escapa($titulo) . '</span>'
            . ($ayuda !== '' ? '<small>' . pb_escapa($ayuda) . '</small>' : '')
            . '</div>';
    }
}

if (!function_exists('pb_campo')) {
    /**
     * Un campo de `form-grid`: etiqueta visible, control, ayuda y el error en
     * `invalid-feedback[data-error-for]`, que es donde `main.js` de la plantilla base
     * pinta los errores de validación.
     *
     * `tipo`: cualquier tipo de `input`, o `select`, `textarea` o `fecha`
     * (Flatpickr por `data-app-date`). Los `select` llevan Select2 salvo
     * `nativo`. `clase` agrega `field-span-2` o `form-grid__full` al contenedor.
     *
     * @param array{tipo?:string,valor?:string,ayuda?:string,error?:string,requerido?:bool,
     *              autofoco?:bool,paso?:string,minimo?:string,maximo?:string,largo?:string,
     *              marcador?:string,modo?:string,autocompletado?:string,patron?:string,
     *              opciones?:array<string,string>,vacia?:string,nativo?:bool,filas?:string,
     *              clase?:string,id?:string,deshabilitado?:bool,extra?:array<string,string>} $opciones
     */
    function pb_campo(string $nombre, string $etiqueta, array $opciones = []): string
    {
        // Los nombres de HTML también valen. Medido: `vehiculos` y
        // `liquidaciones` pasaban `maxlength`, `min` y `step`, que se perdían
        // en silencio, y el efectivo con centavos no se podía guardar.
        foreach (['maxlength' => 'largo', 'min' => 'minimo', 'max' => 'maximo', 'step' => 'paso',
                  'placeholder' => 'marcador', 'inputmode' => 'modo', 'autocomplete' => 'autocompletado',
                  'pattern' => 'patron', 'rows' => 'filas'] as $html => $nuestro) {
            if (isset($opciones[$html]) && !isset($opciones[$nuestro])) {
                $opciones[$nuestro] = (string) $opciones[$html];
            }
        }
        if (($opciones['tipo'] ?? '') === 'numero') {
            $opciones['tipo'] = 'number';
        }

        // El id sale del nombre, y el mismo nombre se repite cuando los
        // filtros y el modal de alta comparten un campo (sucursal, oficina,
        // fecha): con dos ids iguales, la etiqueta del modal enfocaba el
        // filtro. El segundo en la página lleva `-2`, el tercero `-3`.
        static $vistos = [];
        $id = $opciones['id'] ?? ('c-' . preg_replace('/[^a-z0-9_-]/i', '-', $nombre));
        $vistos[$id] = ($vistos[$id] ?? 0) + 1;
        if ($vistos[$id] > 1) {
            $id .= '-' . $vistos[$id];
        }
        $tipo  = $opciones['tipo']  ?? 'text';
        $valor = (string) ($opciones['valor'] ?? '');
        $ayuda = $opciones['ayuda'] ?? '';
        $error = $opciones['error'] ?? '';
        $clave = rtrim($nombre, '[]');

        $describe = [];
        if ($ayuda !== '') { $describe[] = $id . '-ayuda'; }

        $atributos = ' id="' . pb_escapa($id) . '" name="' . pb_escapa($nombre) . '"';
        foreach ([
            'paso'           => 'step',
            'minimo'         => 'min',
            'maximo'         => 'max',
            'largo'          => 'maxlength',
            'marcador'       => 'placeholder',
            'modo'           => 'inputmode',
            'autocompletado' => 'autocomplete',
            'patron'         => 'pattern',
            'filas'          => 'rows',
        ] as $nuestro => $suyo) {
            if (isset($opciones[$nuestro]) && $opciones[$nuestro] !== '') {
                $atributos .= ' ' . $suyo . '="' . pb_escapa($opciones[$nuestro]) . '"';
            }
        }
        foreach ($opciones['extra'] ?? [] as $n => $v) {
            $atributos .= ' ' . pb_escapa($n) . '="' . pb_escapa($v) . '"';
        }
        if (!empty($opciones['requerido']))     { $atributos .= ' required'; }
        if (!empty($opciones['autofoco']))      { $atributos .= ' autofocus'; }
        if (!empty($opciones['deshabilitado'])) { $atributos .= ' disabled'; }
        if ($describe !== [])                   { $atributos .= ' aria-describedby="' . implode(' ', $describe) . '"'; }
        if ($error !== '')                      { $atributos .= ' aria-invalid="true"'; }

        $invalido = $error !== '' ? ' is-invalid' : '';

        if ($tipo === 'select') {
            // La etiqueta va sola en su renglón: la regla de arquitectura que
            // busca SQL armado con variables lee «select» como una consulta.
            $control = '<select class="form-select'
                . $invalido . '"' . $atributos
                . (empty($opciones['nativo']) ? ' data-app-select2' : '') . '>';
            if (isset($opciones['vacia'])) {
                $control .= '<option value="">' . pb_escapa($opciones['vacia']) . '</option>';
            }
            foreach ($opciones['opciones'] ?? [] as $v => $t) {
                $control .= '<option value="' . pb_escapa($v) . '"' . ((string) $v === $valor ? ' selected' : '') . '>'
                    . pb_escapa($t) . '</option>';
            }
            $control .= '</select>';
        } elseif ($tipo === 'textarea') {
            $control = '<textarea class="form-control' . $invalido . '"' . $atributos . '>' . pb_escapa($valor) . '</textarea>';
        } else {
            $esFecha = $tipo === 'fecha';
            $control = '<input class="form-control' . $invalido . '" type="' . ($esFecha ? 'date' : pb_escapa($tipo)) . '"'
                . $atributos . ' value="' . pb_escapa($valor) . '"' . ($esFecha ? ' data-app-date' : '') . '>';
        }

        // R55: dentro de un modal, lo que no es obligatorio lo dice. Los filtros no.
        $opcional = empty($opciones['requerido']) && empty($opciones['deshabilitado'])
            && !in_array($tipo, ['hidden', 'checkbox', 'radio'], true)
            && ($opciones['opcional'] ?? pb_en_modal());

        return '<div' . (!empty($opciones['clase']) ? ' class="' . pb_escapa($opciones['clase']) . '"' : '') . '>'
            . '<label class="form-label" for="' . pb_escapa($id) . '">' . pb_escapa($etiqueta)
            . ($opcional ? ' <span class="text-secondary">(Opcional)</span>' : '')
            . (!empty($opciones['requerido']) ? ' <span class="required-hint" aria-hidden="true">*</span>' : '')
            . '</label>'
            . $control
            . ($ayuda !== '' ? '<div class="form-text" id="' . pb_escapa($id) . '-ayuda">' . pb_escapa($ayuda) . '</div>' : '')
            . '<div class="invalid-feedback" data-error-for="' . pb_escapa($clave) . '"'
            . ($error !== '' ? ' style="display:block"' : '') . '>' . pb_escapa($error) . '</div>'
            . '</div>';
    }
}

if (!function_exists('pb_modal')) {
    /**
     * Abre un modal de alta y edición, como los de la plantilla base: `modal fade` >
     * `modal-dialog` > `modal-content`, con el formulario envolviendo
     * encabezado, cuerpo y pie. Se cierra con `pb_modal_fin()`.
     *
     * El formulario lleva `data-pb-ajax`: `plantilla.js` lo manda por `fetch` y
     * pinta el 422 debajo de cada campo sin cerrar el modal. El mismo modal
     * sirve para dar de alta y para editar: el botón que lo abre
     * (`pb_abre_modal`) le dice a dónde mandar, qué título poner y con qué
     * valores llenarlo. `$accion` y `$titulo` son los del alta.
     *
     * `$marcaHtml` es `$csrf->campo()`; `$volver`, la pantalla a la que se
     * regresa al guardar.
     */
    function pb_modal(
        string $id,
        string $titulo,
        string $accion,
        string $marcaHtml,
        string $volver = '',
        string $tamano = 'modal-lg',
        string $instruccion = 'Capture los datos. Los campos con * son obligatorios.',
        bool $archivos = false
    ): string {
        // Guía §5.1: no se cierra con Escape ni con un clic afuera (M1), lleva su
        // instrucción (M2) y, dentro, cada campo opcional lo dice (R55).
        pb_en_modal(true);

        return '<div class="modal fade" id="' . pb_escapa($id) . '" tabindex="-1" aria-hidden="true" data-pb-formulario'
            . ' data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="' . pb_escapa($id) . '-titulo">'
            . '<div class="modal-dialog ' . pb_escapa($tamano) . ' modal-dialog-scrollable modal-fullscreen-sm-down">'
            . '<div class="modal-content">'
            . '<form method="post" action="' . pb_escapa($accion) . '"' . ($archivos ? ' enctype="multipart/form-data"' : '')
            . ' data-pb-ajax data-pb-accion-nueva="' . pb_escapa($accion) . '">'
            . $marcaHtml
            . ($volver !== '' ? '<input type="hidden" name="volver" value="' . pb_escapa($volver) . '">' : '')
            . '<div class="modal-header">'
            . '<div><h5 class="modal-title" id="' . pb_escapa($id) . '-titulo" data-pb-modal-titulo data-pb-titulo-nueva="' . pb_escapa($titulo) . '">' . pb_escapa($titulo) . '</h5>'
            . ($instruccion !== '' ? '<small class="text-secondary" data-pb-instruccion>' . pb_escapa($instruccion) . '</small>' : '')
            . '</div>'
            . '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>'
            . '</div>'
            . '<div class="modal-body">'
            . '<div class="alert alert-danger d-none" role="alert" data-pb-error></div>';
    }
}

if (!function_exists('pb_modal_ver')) {
    /**
     * Un modal de solo lectura para el «Ver» de la fila (guía §5.2) cuando lo
     * que se muestra ya viaja en `data-pb-registro`: los mismos campos del
     * listado, deshabilitados, sin instrucción ni «(Opcional)» y sin botón de
     * guardar. Se cierra con `pb_modal_fin()`.
     */
    function pb_modal_ver(string $id, string $titulo, string $tamano = 'modal-lg'): string
    {
        $html = pb_modal($id, $titulo, '#', '', '', $tamano, '');
        pb_en_modal(false);

        return str_replace(' data-pb-formulario', ' data-pb-formulario data-pb-solo-ver', $html);
    }
}

if (!function_exists('pb_en_modal')) {
    /** Si lo que se pinta está dentro de un modal: ahí un campo opcional dice «(Opcional)». */
    function pb_en_modal(?bool $dentro = null): bool
    {
        static $estado = false;
        if ($dentro !== null) {
            $estado = $dentro;
        }

        return $estado;
    }
}

if (!function_exists('pb_modal_fin')) {
    /**
     * El pie: un solo botón, sin «Cancelar», porque la X ya cierra (D9). Dice
     * «Guardar» en altas y cambios, o el verbo de la operación.
     */
    function pb_modal_fin(string $boton = 'Guardar', string $icono = 'fa-save'): string
    {
        pb_en_modal(false);

        return '</div>'
            . '<div class="modal-footer">'
            . '<button type="submit" class="btn btn-primary">' . pb_ico($icono) . ' ' . pb_escapa($boton) . '</button>'
            . '</div></form></div></div></div>';
    }
}

if (!function_exists('pb_abre_modal')) {
    /**
     * El botón que abre un `pb_modal`. Sin `$accion` abre el alta; con
     * `$accion`, `$titulo` y `$registro` abre la edición de ese renglón:
     * `plantilla.js` llena cada campo cuyo `name` esté en `$registro`.
     *
     * `$renglon` le da la forma de acción de tabla (`label-default
     * action-link`), que es como se ve en la columna de acciones y en las
     * tarjetas del teléfono.
     *
     * @param array<string,mixed> $registro
     */
    function pb_abre_modal(
        string $modal,
        string $texto,
        string $icono = 'bi-plus-lg',
        ?string $accion = null,
        ?string $titulo = null,
        array $registro = [],
        bool $renglon = false
    ): string {
        $datos = ' data-bs-toggle="modal" data-bs-target="#' . pb_escapa($modal) . '"';

        if ($accion !== null) {
            $datos .= ' data-pb-accion="' . pb_escapa($accion) . '"'
                . ' data-pb-titulo="' . pb_escapa($titulo ?? $texto) . '"'
                . ' data-pb-registro="' . pb_escapa((string) json_encode($registro, JSON_UNESCAPED_UNICODE)) . '"';
        }

        $clase = $renglon ? 'label-default action-link' : 'btn btn-primary';

        return '<button type="button" class="' . $clase . '"' . $datos . ($renglon ? ' title="' . pb_escapa($texto) . '"' : '') . '>'
            . pb_ico($icono) . ' ' . pb_escapa($texto) . '</button>';
    }
}

if (!function_exists('pb_filtro_estatus')) {
    /**
     * El `select` de estatus de las listas de catálogo: activas, inactivas o
     * todas. Los valores no cambian; `$masculino` sólo cambia cómo se leen
     * —«Activos», «Dados de baja»—, que es como se habla del personal.
     */
    function pb_filtro_estatus(string $estatus, string $id = 'filtroEstatus', bool $masculino = false): string
    {
        return pb_campo('estatus', 'Estatus', [
            'tipo'     => 'select',
            'id'       => $id,
            'nativo'   => true,
            'valor'    => $estatus,
            'opciones' => $masculino
                ? ['activas' => 'Activos', 'inactivas' => 'Dados de baja', 'todas' => 'Todos']
                : ['activas' => 'Activas', 'inactivas' => 'Dadas de baja', 'todas' => 'Todas'],
        ]);
    }
}

if (!function_exists('pb_dinero')) {
    /** Pesos con dos decimales y separador de miles: `$1,234.50`. */
    function pb_dinero(mixed $cantidad): string
    {
        $valor = (float) $cantidad;
        return ($valor < 0 ? '−' : '') . '$' . number_format(abs($valor), 2);
    }
}

if (!function_exists('pb_cantidad')) {
    /**
     * Una cantidad como la lee una persona: `102.000` → `102`, `1500.500` →
     * `1,500.5`. La base guarda tres decimales; la pantalla no los necesita
     * cuando son ceros. Sin redondeo: los decimales que hay se quedan.
     */
    function pb_cantidad(mixed $cantidad): string
    {
        $texto = trim((string) $cantidad);
        if (preg_match('/^(-?)(\d+)(?:\.(\d+))?$/', $texto, $m) !== 1) {
            return $texto;
        }
        $decimales = rtrim($m[3] ?? '', '0');
        return $m[1] . number_format((float) $m[2]) . ($decimales !== '' ? '.' . $decimales : '');
    }
}

if (!function_exists('pb_valor_cantidad')) {
    /**
     * Una cantidad para el `value` de un campo numérico: sin ceros de sobra
     * («3», no «3.000», que en México se lee como tres mil) y sin separador
     * de miles, que el campo no acepta.
     */
    function pb_valor_cantidad(mixed $cantidad): string
    {
        $texto = trim((string) $cantidad);
        if (preg_match('/^-?\d+(?:\.\d+)?$/', $texto) !== 1) {
            return $texto;
        }
        return str_contains($texto, '.') ? rtrim(rtrim($texto, '0'), '.') : $texto;
    }
}

if (!function_exists('pb_fecha')) {
    /**
     * Una fecha de la base como se lee en mostrador: `2026-10-07 13:45:12` →
     * `07 oct 2026, 13:45`; `2026-10-07` → `07 oct 2026`. Lo que no es fecha
     * se devuelve tal cual, y vacío queda vacío.
     */
    function pb_fecha(mixed $fecha): string
    {
        $texto = trim((string) $fecha);
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/', $texto, $m) !== 1) {
            return $texto;
        }
        $meses = ['', 'ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
        $dia = $m[3] . ' ' . ($meses[(int) $m[2]] ?? $m[2]) . ' ' . $m[1];
        return isset($m[4]) ? $dia . ', ' . $m[4] . ':' . $m[5] : $dia;
    }
}

if (!function_exists('pb_qr')) {
    /**
     * Un código QR como SVG en línea, dibujado en el servidor con
     * `Dominio\CodigoQr`. Lleva la zona de silencio de cuatro módulos que pide
     * la norma y un solo trazo, así que pesa poco y se imprime nítido.
     */
    function pb_qr(string $texto, string $etiqueta, int $pixeles = 200): string
    {
        $qr = \Dominio\CodigoQr::codifica($texto);
        $n = $qr->tamano();
        $trazo = '';
        for ($fila = 0; $fila < $n; $fila++) {
            for ($columna = 0; $columna < $n; $columna++) {
                if ($qr->oscuro($fila, $columna)) $trazo .= 'M' . ($columna + 4) . ' ' . ($fila + 4) . 'h1v1h-1z';
            }
        }
        $lado = $n + 8;
        return '<svg class="pb-qr" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $lado . ' ' . $lado . '"'
            . ' width="' . $pixeles . '" height="' . $pixeles . '" role="img" aria-label="' . pb_escapa($etiqueta) . '"'
            . ' shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/>'
            . '<path fill="#000" d="' . $trazo . '"/></svg>';
    }
}

if (!function_exists('pb_inicial')) {
    /** La inicial del nombre, para el avatar de la barra superior. */
    function pb_inicial(string $nombre): string
    {
        $limpio = trim($nombre);

        return $limpio === '' ? '?' : mb_strtoupper(mb_substr($limpio, 0, 1, 'UTF-8'), 'UTF-8');
    }
}

if (!function_exists('pb_llave')) {
    /**
     * Campo oculto con una llave de idempotencia (UUID v4) nueva por cada vez
     * que se pinta el formulario. Un doble clic o un reintento tras perder la
     * red mandan la misma llave, y el servidor devuelve lo que ya hizo en vez
     * de repetirlo; recargar la pantalla da una llave nueva.
     */
    function pb_llave(string $nombre = 'llave_idempotencia'): string
    {
        return '<input type="hidden" name="' . pb_escapa($nombre) . '" value="' . pb_uuid() . '">';
    }
}

if (!function_exists('pb_uuid')) {
    /** Un UUID v4 nuevo: la llave de una sola vez de un formulario o un enlace. */
    function pb_uuid(): string
    {
        $b = random_bytes(16);
        $b[6] = chr((ord($b[6]) & 0x0f) | 0x40);
        $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
        $h = bin2hex($b);

        return substr($h, 0, 8) . '-' . substr($h, 8, 4) . '-' . substr($h, 12, 4) . '-' . substr($h, 16, 4) . '-' . substr($h, 20);
    }
}

if (!function_exists('pb_legible')) {
    /**
     * Una clave interna en palabras: `crea_cambio_fisico` → «Crea cambio
     * físico», `api_sincroniza` → «App · sincronización», `id_cliente` →
     * «Cliente». La bitácora guarda claves para poder filtrarlas; en pantalla
     * se leen así. Lo que no es clave (un nombre, un folio, un número) pasa
     * igual.
     */
    function pb_legible(string $clave): string
    {
        if (!preg_match('/^[a-z][a-z0-9]*(_[a-z0-9]+)*$/', $clave)) {
            return $clave;
        }
        static $palabras = [
            'api' => 'App ·', 'sincroniza' => 'envío de la app', 'fisico' => 'físico', 'fisicos' => 'físicos',
            'version' => 'versión', 'devolucion' => 'devolución', 'liquidacion' => 'liquidación',
            'autorizacion' => 'autorización', 'ubicacion' => 'ubicación', 'operacion' => 'operación',
            'sesion' => 'sesión', 'credito' => 'crédito', 'telefono' => 'teléfono', 'presentacion' => 'presentación',
            'codigo' => 'código', 'numero' => 'número', 'parametro' => 'parámetro', 'parametros' => 'parámetros',
            'bitacora' => 'bitácora', 'vehiculo' => 'vehículo', 'vehiculos' => 'vehículos', 'categoria' => 'categoría',
            'transito' => 'tránsito', 'razon' => 'razón', 'dia' => 'día',
            'catalogos' => 'catálogos', 'catalogo' => 'catálogo', 'organizacion' => 'organización',
        ];
        $partes = explode('_', $clave);
        if ($partes[0] === 'id' && count($partes) > 1) {
            array_shift($partes);
        }
        $texto = implode(' ', array_map(static fn (string $p): string => $palabras[$p] ?? $p, $partes));

        return mb_strtoupper(mb_substr($texto, 0, 1)) . mb_substr($texto, 1);
    }
}
