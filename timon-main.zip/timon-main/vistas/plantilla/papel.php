<?php
/**
 * Plantilla de papel: el ticket de 58 mm y las hojas impresas.
 *
 * **No lleva armazón.** Estas tres salidas son papel: no tienen menú, no tienen
 * barra superior y no comparten la hoja del sistema. Su hoja es `impresion.css`
 * y está en milímetros, porque el papel está en milímetros.
 *
 * ⚠️ El formato lo fija la vista con `$ancho`, no esta plantilla: «58», «80» o
 * «76» para los rollos de ticket (`Dominio\AnchoTicket`) y «carta» para las
 * hojas. De ahí salen el `data-ancho` del cuerpo y **la segunda hoja de
 * estilo**, que es la que trae el `@page`: `@page` no acepta selectores, así
 * que el tamaño de página no se puede decidir con una clase.
 *
 * En los tickets, arriba y fuera de la impresión, van los anchos para volver
 * a imprimir en otro rollo: el ancho se elige al imprimir (2026-11-08, C3).
 *
 * @var callable $e
 * @var string $contenido  HTML ya pintado: la salida de impresión interior
 * @var string $titulo
 * @var string $ancho  «58», «80» o «76» para ticket, «carta» para hoja
 */
$titulo ??= 'El Timón';
$ancho  ??= 'carta';
$esTicket = \Dominio\AnchoTicket::esTicket($ancho);
$formato = $esTicket ? 'ticket-' . $ancho : 'hoja';
// El papel queda dicho en el HTML y no solo en la hoja: quien recibe el ticket
// —la impresora, la prueba de humo— sabe su ancho sin cargar el CSS.
$papel   = $esTicket ? $ancho . 'mm' : 'carta';
$enAncho = static function (string $otro): string {
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
    $ruta = (string) parse_url($uri, PHP_URL_PATH);
    parse_str((string) parse_url($uri, PHP_URL_QUERY), $consulta);
    $consulta['ancho'] = $otro;
    return $ruta . '?' . http_build_query($consulta);
};
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $e($titulo) ?> · <?= pb_marca_texto($marcaVisual ?? null, 'nombre_corto') ?></title>
<link rel="icon" href="/recursos/isotipo.svg?v=20261114.2" type="image/svg+xml">
<link rel="stylesheet" href="/recursos/impresion.css?v=20261111.1">
<link rel="stylesheet" href="/recursos/<?= $e($formato) ?>.css?v=20261110.2">
</head>
<?php // Se manda a imprimir solo: quien abre esta pestaña ya decidió imprimir. ?>
<body data-ancho="<?= $e($ancho) ?>" data-papel="<?= $e($papel) ?>">
<?php if ($esTicket): ?>
<nav class="no-imprimir ticket-anchos" aria-label="Ancho del rollo">
  <span>Rollo:</span>
  <?php foreach (\Dominio\AnchoTicket::nombres() as $otro => $nombre): ?>
  <a href="<?= $e($enAncho($otro)) ?>" data-pb-ancho="<?= $e($otro) ?>"<?= $otro === $ancho ? ' aria-current="true"' : '' ?>><?= $e($nombre) ?></a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>
<?= $contenido ?>
<script src="/recursos/envio-unico.js?v=20261108.1"></script>
<script src="/recursos/imprime.js?v=20261108.1"></script>
</body>
</html>
