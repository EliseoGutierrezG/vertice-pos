<?php
/**
 * Plantilla sin armazón: la pantalla de entrada, con la entrada de
 * la plantilla base tal cual —`.login`, `auth-card`, `auth-form` y `auth-hero`—.
 *
 * ⚠️ **Sí pinta avisos, y antes no.** Es la pantalla a la que el sistema manda a
 * alguien cuando tiene algo que explicarle —«se cerró la sesión por estar mucho
 * tiempo sin usarse»—, y el aviso se perdía: ninguna de sus etiquetas lo leía.
 * Peor que perderse: el aviso **no se consume si nadie lo lee**, así que salía
 * después, en el tablero, justo cuando el usuario ya había vuelto a entrar.
 *
 * @var callable $e
 * @var \Nucleo\Sesion $sesion
 * @var string $contenido  HTML ya pintado: es la pantalla de dentro
 * @var string $titulo
 */

$titulo ??= 'El Timón';
$aviso = $sesion->aviso();
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0F1F36">
    <title><?= $e($titulo) ?> · <?= pb_marca_texto($marcaVisual ?? null, 'nombre_corto') ?></title>
    <link rel="icon" href="/recursos/isotipo.svg?v=20261114.2" type="image/svg+xml">
    <?php require __DIR__ . '/estilos.php'; ?>
</head>
<body class="login-page">
<main class="login">
    <section class="auth-card">
        <div class="auth-grid">
            <div class="auth-form">
                <?php if ($aviso !== null): ?>
                    <?= pb_aviso($aviso['tono'], $aviso['texto'], $aviso['campos'] ?? []) ?>
                <?php endif; ?>
                <?= $contenido ?>
            </div>

            <?php /* El lado oscuro es la foto de fondo con un velo de la marca y,
                     abajo, la frase y el lema. En pantalla ancha el logo vive
                     en el formulario. Abajo de 992 px la foto pasa a ser el
                     fondo de toda la pantalla: encima van el logo y el nombre
                     en una tarjeta de vidrio y, debajo, el formulario en una
                     hoja blanca. */ ?>
            <div class="auth-hero">
                <div class="auth-hero__marca">
                    <?= pb_marca_logo($marcaVisual ?? null, 'simbolo', '', 'auth-hero__placa') ?>
                    <div>
                        <p class="auth-hero__antetitulo">Panel de operación</p>
                        <p class="auth-hero__nombre"><?= pb_marca_texto($marcaVisual ?? null) ?></p>
                    </div>
                </div>
                <div class="auth-hero__content">
                    <p class="auth-hero__etiqueta pb-etiqueta-tecnica">Panel de operación</p>
                    <p class="auth-hero__titular">Mesas, cocina y caja de cada sucursal en un lugar.</p>
                    <p><?= pb_marca_texto($marcaVisual ?? null, 'lema') ?></p>
                </div>
            </div>
        </div>
    </section>
</main>
<script src="/recursos/envio-unico.js?v=20261108.1"></script>
<script src="/recursos/entrada.js?v=20261111.1"></script>
</body>
</html>
