<?php
/**
 * Los grupos del menú: ruta, nombre, icono y el permiso —o los permisos, y
 * basta con tener uno— del que cuelga cada entrada. Lo usan la barra lateral
 * (`base.php`) y los accesos del inicio (`tablero/inicio.php`), así que no hay
 * una segunda lista que se pueda desincronizar.
 *
 * El texto de la opción es el `h2` de su pantalla y el título de la pestaña.
 * El permiso de cada opción es el de su `GET`: quien la ve, entra.
 *
 * Cada fase del giro agrega su grupo aquí (Salón, Cocina, Caja, Almacén,
 * Compras, Menú, Reportes), en el orden del día.
 *
 * @return list<array{0:string,1:string,2:list<array{0:string,1:string,2:string,3:string|list<string>}>}>
 */
$restaurante = [
    ['Salón y carta', 'bi-shop', [
        ['/areas', 'Áreas', 'bi-map', 'plano_ver'],
        ['/mesas', 'Mesas', 'bi-grid-3x3-gap', 'plano_ver'],
        ['/mesas/plano', 'Plano del salón', 'bi-diagram-3', 'plano_ver'],
        ['/reservaciones', 'Reservaciones', 'bi-calendar2-check', 'reservaciones_opera'],
        ['/categorias-menu', 'Categorías del menú', 'bi-tags', 'menu_admin'],
        ['/platillos', 'Platillos', 'bi-journal-text', ['menu_admin', 'menu_sucursal']],
        ['/promociones', 'Promociones', 'bi-percent', 'promocion_admin'],
        ['/carta', 'Carta', 'bi-book', ['menu_admin', 'menu_sucursal']],
    ]],
    ['Equipos y ventas', 'bi-pc-display', [
        ['/equipos-comanda', 'Equipos de comanda', 'bi-pc-display', 'equipo_admin'],
        ['/impresoras', 'Impresoras', 'bi-printer', 'plano_admin'],
        ['/gastos', 'Gastos', 'bi-receipt-cutoff', 'gastos_opera'],
        ['/caja/turnos', 'Turnos y cortes', 'bi-cash-stack', 'caja_consulta'],
        ['/reportes', 'Reportes', 'bi-bar-chart', 'reportes_restaurante'],
    ]],
    ['Almacén y compras', 'bi-box-seam', [
        ['/inventario/insumos', 'Insumos', 'bi-basket', 'inventario_opera'],
        ['/inventario/lotes', 'Lotes de insumo', 'bi-boxes', 'inventario_opera'],
        ['/inventario/compras', 'Compras', 'bi-bag-check', 'inventario_opera'],
        ['/inventario/proveedores', 'Proveedores', 'bi-truck', 'inventario_opera'],
        ['/inventario/recetas', 'Recetas', 'bi-card-checklist', 'inventario_opera'],
        ['/inventario/movimientos', 'Kardex de insumos', 'bi-list-check', 'inventario_opera'],
        ['/inventario/faltantes', 'Faltantes', 'bi-exclamation-circle', 'faltantes_atiende'],
    ]],
];

return [
    ...(\Nucleo\Giro::activo('restaurante') ? $restaurante : []),
    ['Negocio y seguridad', 'bi-building-lock', [
        ['/sucursales',        'Sucursales',                'bi-building',         'organizacion_ver'],
        ['/servidores',        'Operación local',           'bi-hdd-network',      'servidor_admin'],
        ['/personal',          'Personal',                  'bi-people',           'personal_ver'],
        ['/dispositivos',      'Equipos del personal',      'bi-tablet',           'personal_ver'],
        ['/avisos',            'Avisos',                    'bi-megaphone',        ['avisos_ver', 'notificaciones_envia']],
        ['/seguridad',         'Verificación en dos pasos', 'bi-shield-lock',      'seguridad_admin'],
        ['/seguridad/accesos', 'Revisión de accesos',       'bi-person-check',     ['accesos_revisa', 'seguridad_admin']],
        ['/bitacora',          'Bitácora',                  'bi-journal-richtext', 'bitacora_ver'],
        ['/privacidad',        'Privacidad',                'bi-person-lock',      'seguridad_admin'],
    ]],
];
