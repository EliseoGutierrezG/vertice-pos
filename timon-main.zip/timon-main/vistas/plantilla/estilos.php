<?php
/**
 * Las hojas del administrativo, en el orden de la plantilla base.
 *
 * Todas son locales (`publico/recursos/vendor/`), con las versiones de la
 * plantilla. `plantilla/main.css` se conserva intacto; `tema.css` va
 * después con el sistema visual y al final `/marca/tema.css` con la paleta vigente.
 *
 * @var \Servicios\MarcaVisual|null $marcaVisual
 */
$v = '/recursos/vendor';
?>
    <link rel="preload" href="/recursos/fuentes/plus-jakarta-sans.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="/recursos/fuentes/sora.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="<?= $v ?>/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= $v ?>/bootstrap-icons/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= $v ?>/plugins/font-icons/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= $v ?>/plugins/select2/select2.min.css">
    <link rel="stylesheet" href="<?= $v ?>/plugins/select2-bootstrap-5-theme/select2-bootstrap-5-theme.min.css">
    <link rel="stylesheet" href="<?= $v ?>/plugins/sweetalerts/sweetalert2.min.css">
    <link rel="stylesheet" href="<?= $v ?>/plugins/flatpickr/flatpickr.css">
    <link rel="stylesheet" href="<?= $v ?>/plugins/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="<?= $v ?>/plugins/table/datatable/datatables.css">
    <link rel="stylesheet" href="<?= $v ?>/plugins/table/datatable/dt-global_style.css">
    <link rel="stylesheet" href="<?= $v ?>/plugins/table/datatable/custom_dt_custom.css">
    <link rel="stylesheet" href="/recursos/plantilla/main.css?v=20261105.1">
    <link rel="stylesheet" href="/recursos/tema.css?v=20261118.1">
<?php if (isset($marcaVisual)): ?>
    <link rel="stylesheet" href="/marca/tema.css?v=<?= $e($marcaVisual->revision()) ?>">
<?php endif; ?>
