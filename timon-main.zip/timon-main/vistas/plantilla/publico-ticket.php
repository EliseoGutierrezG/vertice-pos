<?php
/**
 * Vista pública deliberadamente mínima: sin menús, analítica, guiones ni
 * recursos de terceros. El propio HTTP impide caché, indexación y referer.
 * @var callable $e
 * @var string $contenido HTML ya pintado: el comprobante interior
 * @var string $titulo
 */
$titulo ??= 'Ticket';
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive">
<title><?= $e($titulo) ?> · <?= pb_marca_texto($marcaVisual ?? null, 'nombre_corto') ?></title>
<link rel="icon" href="/recursos/isotipo.svg?v=20261114.2" type="image/svg+xml">
<link rel="stylesheet" href="/recursos/ticket-publico.css?v=20261114.1">
</head>
<body>
<?= $contenido ?>
</body>
</html>
