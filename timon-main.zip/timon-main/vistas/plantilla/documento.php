<?php
/**
 * Plantilla para leer: una página de texto, pública, sin menú ni entrada.
 *
 * @var callable $e
 * @var string $contenido  HTML ya pintado: es la pantalla de dentro
 * @var string $titulo
 */
$titulo ??= 'El Timón';
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0F1F36">
    <title><?= $e($titulo) ?> · <?= pb_marca_texto($marcaVisual ?? null, 'nombre_corto') ?></title>
    <link rel="icon" href="/recursos/isotipo.svg?v=20261114.2" type="image/svg+xml">
    <?php require __DIR__ . '/estilos.php'; ?>
</head>
<body>
<a class="visually-hidden-focusable btn btn-primary position-fixed top-0 start-0 m-2 pb-saltar" href="#contenido">Saltar al contenido</a>
<?= $contenido ?>
</body>
</html>
