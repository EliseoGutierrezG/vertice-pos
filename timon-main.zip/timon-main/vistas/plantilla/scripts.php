<?php
/**
 * Los scripts del administrativo, en el orden de la plantilla base.
 * `servicio.js` ocupa el lugar de su `service.js`; `plantilla.js` va al final,
 * como el script de un módulo.
 */
$v = '/recursos/vendor';
?>
<script src="<?= $v ?>/jquery/jquery-3.7.1.min.js"></script>
<script src="<?= $v ?>/bootstrap/js/bootstrap.bundle.min.js?v=20260929.1"></script>
<script src="<?= $v ?>/plugins/select2/select2.min.js"></script>
<script src="<?= $v ?>/plugins/select2/es.js"></script>
<script src="<?= $v ?>/plugins/sweetalerts/sweetalert2.min.js"></script>
<script src="/recursos/alertas.js?v=20261112.1"></script>
<script src="<?= $v ?>/plugins/flatpickr/flatpickr.js"></script>
<script src="<?= $v ?>/plugins/daterangepicker/moment.min.js"></script>
<script src="<?= $v ?>/plugins/daterangepicker/daterangepicker.min.js"></script>
<script src="<?= $v ?>/plugins/table/datatable/datatables.js"></script>
<script src="/recursos/servicio.js?v=20260926.1"></script>
<script src="/recursos/plantilla/datatables.js?v=20261105.1"></script>
<script src="/recursos/plantilla/main.js?v=20261105.2"></script>
<script src="/recursos/plantilla.js?v=20261118.1"></script>
