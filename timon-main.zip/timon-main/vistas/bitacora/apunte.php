<?php
/**
 * Ver de un apunte de la bitácora (ficha 43): quién, cuándo, desde dónde y
 * el antes y el después completos, campo por campo.
 *
 * @var callable $e @var array<string,mixed> $apunte @var array<string,array<int,string>> $nombres
 */
$a = $apunte;
$canales = ['web' => 'Web', 'api' => 'App', 'tarea' => 'Tarea', 'guion' => 'Guion'];
$lista = static function (?string $json) use ($e, $nombres): string {
    $datos = $json === null || $json === '' ? null : json_decode($json, true);
    if ($datos === null) return '<p class="text-secondary mb-0">—</p>';
    if (!is_array($datos)) return '<p class="mb-0">' . $e((string) $json) . '</p>';
    $html = '<dl class="detail-list">';
    foreach ($datos as $campo => $valor) {
        $valor = is_array($valor) ? (string) json_encode($valor, JSON_UNESCAPED_UNICODE) : ($valor === null ? '—' : (string) $valor);
        $valor = $nombres[preg_replace('/^id_/', '', (string) $campo)][(int) $valor] ?? $valor;
        $html .= '<div class="detail-list__row"><dt>' . $e(pb_legible((string) $campo)) . '</dt><dd class="text-break">' . $e($valor) . '</dd></div>';
    }
    return $html . '</dl>';
};
?>
<div class="row g-3">
<div class="col-12">
<?= pb_seccion('bi-info-circle', 'Datos') ?>
<dl class="detail-list">
<div class="detail-list__row"><dt>Cuándo</dt><dd><?= $e(pb_fecha($a['momento'])) ?> · <?= $e(substr((string) $a['momento'], 11, 8)) ?></dd></div>
<div class="detail-list__row"><dt>Quién</dt><dd><?= $e($a['usuario'] ?? 'el sistema') ?> · <?= $e($canales[$a['canal'] ?? ''] ?? 'Histórico') ?></dd></div>
<div class="detail-list__row"><dt>Qué hizo</dt><dd><?= $e(pb_legible((string) $a['accion'])) ?> · <?= $e(pb_legible((string) $a['modulo'])) ?></dd></div>
<div class="detail-list__row"><dt>Sobre qué</dt><dd><?= $e($a['entidad'] === null ? '—' : pb_legible((string) $a['entidad']) . ($a['id_entidad'] === null ? '' : ' #' . (int) $a['id_entidad'])) ?></dd></div>
<div class="detail-list__row"><dt>Operación</dt><dd><code><?= $e($a['operacion'] ?? 'Histórico') ?></code></dd></div>
<?php if (($a['id_dispositivo'] ?? null) !== null): ?><div class="detail-list__row"><dt>Teléfono</dt><dd>#<?= (int) $a['id_dispositivo'] ?></dd></div><?php endif; ?>
</dl>
</section>
</div>
<div class="col-lg-6"><?= pb_seccion('bi-arrow-left-circle', 'Antes') ?><?= $lista($a['antes']) ?></section></div>
<div class="col-lg-6"><?= pb_seccion('bi-arrow-right-circle', 'Después') ?><?= $lista($a['despues']) ?></section></div>
</div>
