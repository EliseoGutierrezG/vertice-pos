<?php
/**
 * La bitácora. Quién, cuándo, qué había antes y qué quedó.
 *
 * Lo que se enseña de cada apunte son los **dos valores**, no una frase que los
 * resuma: «cambió el precio» obliga a creerle al sistema, «18.50 → 21.00» se
 * lee. Se pintan como pares campo/valor y no como el JSON crudo, porque el JSON
 * crudo es exactamente el dato que nadie revisa. En la tabla se ven tres
 * campos; Ver abre el antes y el después completos (ficha 43). Abre con el mes
 * en curso (D16) y pagina en el servidor, por llave.
 *
 * @var callable $e
 * @var list<array<string,mixed>> $apuntes
 * @var bool $hay_mas
 * @var int $ultimo
 * @var array<string,mixed> $filtros
 * @var list<string> $modulos
 * @var list<string> $acciones
 * @var list<string> $entidades
 * @var list<array<string,mixed>> $quienes
 * @var array<string,array<int,string>> $nombres
 */

$canales = ['web' => 'Web', 'api' => 'App', 'tarea' => 'Tarea', 'guion' => 'Guion'];

/** El JSON de un apunte, en renglones legibles. */
$campos = static function (?string $json) use ($e, $nombres): string {
    if ($json === null || $json === '') {
        return '<span class="text-secondary">—</span>';
    }

    $datos = json_decode($json, true);

    if (!is_array($datos)) {
        return $e($json);
    }

    $renglones = [];

    foreach ($datos as $campo => $valor) {
        if (is_array($valor)) {
            $valor = json_encode($valor, JSON_UNESCAPED_UNICODE);
        }

        $valor = $valor === null ? '—' : (string) $valor;
        $valor = $nombres[preg_replace('/^id_/', '', (string) $campo)][(int) $valor] ?? $valor;
        // Lo guardado sigue íntegro en la base: aquí sólo se escribe para leerse.
        if (preg_match('/^-?\d+\.000$/', $valor) === 1) {
            $valor = pb_valor_cantidad($valor);
        } elseif (preg_match('/^\d{4}-\d{2}-\d{2}/', $valor) === 1) {
            $valor = pb_fecha($valor);
        }
        $renglones[] = '<span class="text-secondary">' . $e(pb_legible((string) $campo)) . '</span> '
            . $e(str_contains($valor, '_') ? pb_legible($valor) : $valor);
    }

    // Un alta trae decenas de campos: se ven tres y el resto se despliega,
    // para que un apunte no ocupe media pantalla.
    $vistos = array_slice($renglones, 0, 3);
    $resto = array_slice($renglones, 3);

    return implode('<br>', $vistos) . ($resto === [] ? ''
        : '<details class="bitacora-mas"><summary>y ' . count($resto) . ' más</summary>' . implode('<br>', $resto) . '</details>');
};

/** Los filtros puestos, para que los enlaces de «más» los conserven. */
$conservados = array_filter([
    'canal'      => (string) $filtros['canal'],
    'modulo'     => (string) $filtros['modulo'],
    'accion'     => (string) $filtros['accion'],
    'id_usuario' => ((int) $filtros['id_usuario']) ?: '',
    'entidad'    => (string) $filtros['entidad'],
    'identificador' => ((int) $filtros['identificador']) ?: '',
    'operacion'  => (string) $filtros['operacion'],
    'desde'      => (string) $filtros['desde'],
    'hasta'      => (string) $filtros['hasta'],
], static fn ($v): bool => $v !== '' && $v !== 0);
// Un periodo vaciado a propósito se conserva vacío: sin él, volvería el mes en curso.
$conservados += ['desde' => '', 'hasta' => ''];
?>
<?= pb_modulo(
    'bi-journal-richtext',
    'Bitácora', 'Quién hizo qué, cuándo y sobre qué registro, con el antes y el después.',
    $identidad->puede('bitacora_exporta') ? pb_exportar('/bitacora.xlsx', $conservados) : '') ?>

<?= pb_filtros('/bitacora') ?>
    <?= pb_rango((string) $filtros['desde'], (string) $filtros['hasta']) ?>
    <?= pb_campo('canal', 'Canal', ['tipo' => 'select', 'id' => 'filtroCanal', 'valor' => (string) $filtros['canal'], 'vacia' => 'Todos los canales', 'opciones' => $canales]) ?>
    <?= pb_campo('modulo', 'Módulo', ['tipo' => 'select', 'id' => 'filtroModulo', 'valor' => (string) $filtros['modulo'], 'vacia' => 'Todos los módulos', 'opciones' => $modulos === [] ? [] : array_combine($modulos, array_map('pb_legible', $modulos))]) ?>
    <?= pb_campo('accion', 'Acción', ['tipo' => 'select', 'id' => 'filtroAccion', 'valor' => (string) $filtros['accion'], 'vacia' => 'Todas las acciones', 'opciones' => $acciones === [] ? [] : array_combine($acciones, array_map('pb_legible', $acciones))]) ?>
    <?= pb_campo('id_usuario', 'Quién', ['tipo' => 'select', 'id' => 'filtroQuien', 'valor' => (int) $filtros['id_usuario'] > 0 ? (string) (int) $filtros['id_usuario'] : '', 'vacia' => 'Cualquiera', 'opciones' => array_column($quienes, 'nombre', 'id')]) ?>
    <?= pb_campo('entidad', 'Tipo de registro', ['tipo' => 'select', 'id' => 'filtroEntidad', 'valor' => (string) $filtros['entidad'], 'vacia' => 'Todos los registros', 'opciones' => $entidades === [] ? [] : array_combine($entidades, array_map('pb_legible', $entidades))]) ?>
    <?= pb_campo('identificador', 'Número de registro', ['tipo' => 'number', 'id' => 'filtroIdentificador', 'valor' => (int) $filtros['identificador'] > 0 ? (string) (int) $filtros['identificador'] : '', 'minimo' => '1', 'paso' => '1']) ?>
    <?= pb_campo('operacion', 'Operación', ['id' => 'filtroOperacion', 'valor' => (string) $filtros['operacion'], 'marcador' => 'Código completo']) ?>
    <?= pb_campo('por_pagina', 'Filas por página', ['tipo' => 'numero', 'min' => 1, 'max' => 100, 'valor' => $tamano]) ?>
<?= pb_filtros_fin('/bitacora') ?>

<?= pb_registros($total, '<span class="text-secondary">' . count($apuntes) . ' en esta página</span>') ?>
<?= pb_tabla('Bitácora', 'simple', true, 'bi-journal-x') ?>
    <thead>
        <tr>
            <th class="no-orden" data-pb-acciones>Acción</th>
            <th>Cuándo</th>
            <th>Quién</th>
            <th data-pb-titulo>Qué hizo</th>
            <th>Sobre qué</th>
            <th>Operación</th>
            <th>Antes</th>
            <th>Después</th>
        </tr>
    </thead>
    <tbody>
    <?php if ($apuntes === []): ?>
        <?= pb_fila_vacia(8, 'Sin apuntes con esos filtros') ?>
    <?php endif; ?>
    <?php foreach ($apuntes as $a): ?>
        <tr>
            <?= pb_acciones([pb_accion_detalle('modal-detalle-apunte', (int) $a['id'])]) ?>
            <td class="text-nowrap" data-order="<?= $e($a['momento']) ?>"><?= $e(pb_fecha($a['momento'])) ?></td>
            <td><?= $e($a['usuario'] ?? 'el sistema') ?><br><span class="small text-secondary"><?= $e($canales[$a['canal'] ?? ''] ?? 'Histórico') ?></span></td>
            <td><span class="fw-semibold"><?= $e(pb_legible((string) $a['accion'])) ?></span><br><span class="small text-secondary"><?= $e(pb_legible((string) $a['modulo'])) ?></span></td>
            <td>
                <?php if ($a['entidad'] === null): ?>
                    <span class="text-secondary">—</span>
                <?php else: ?>
                    <?= $e(pb_legible((string) $a['entidad'])) ?><?= $a['id_entidad'] === null ? '' : ' #' . (int) $a['id_entidad'] ?>
                <?php endif; ?>
            </td>
            <td class="small">
                <?php if (($a['operacion'] ?? null) === null): ?>
                    <span class="text-secondary">Histórico</span>
                <?php else: ?>
                    <span class="font-monospace" title="<?= $e($a['operacion']) ?>"><?= $e(substr((string) $a['operacion'], 0, 8)) ?></span>
                    <?php if (($a['id_dispositivo'] ?? null) !== null): ?><br><span class="text-secondary">Teléfono #<?= (int) $a['id_dispositivo'] ?></span><?php endif; ?>
                <?php endif; ?>
            </td>
            <td class="small bitacora-campos"><?= $campos($a['antes']) ?></td>
            <td class="small bitacora-campos"><?= $campos($a['despues']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
<?= pb_tabla_fin() ?>

<?php if ($hay_mas || $filtros['antes_de'] > 0): ?>
    <?php $conservados['por_pagina'] = $tamano; ?>
    <nav class="d-flex justify-content-center flex-wrap gap-2 mt-3" aria-label="Paginación de la bitácora">
        <?php if ($filtros['antes_de'] > 0): ?>
            <?= pb_boton('/bitacora?' . http_build_query($conservados), 'Registros recientes', 'bi-chevron-double-up', 'outline-secondary') ?>
        <?php endif; ?>
        <?php if ($hay_mas): ?>
            <?= pb_boton('/bitacora?' . http_build_query($conservados + ['antes_de' => $ultimo]), 'Ver lo anterior', 'bi-chevron-double-down', 'outline-secondary') ?>
        <?php endif; ?>
    </nav>
<?php endif; ?>

<?= pb_modulo_fin() ?>
<?= pb_detalle('modal-detalle-apunte', 'Apunte', '/bitacora', 'modal-lg') ?>
