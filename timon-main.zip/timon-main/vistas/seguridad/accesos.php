<?php
/** @var callable $e @var \Nucleo\Csrf $csrf @var \Nucleo\Identidad $identidad @var array $reporte */
$acciones = pb_verbo('modal-revision-accesos', 'Registrar revisión', 'fa-check')
    . pb_verbo('modal-historial-accesos', 'Revisiones anteriores', 'fa-history')
    . pb_exportar('/seguridad/accesos.xlsx');
echo pb_modulo('bi-person-check', 'Revisión de accesos', 'Quién tiene acceso, con qué puesto y hasta cuándo, y sus revisiones.', $acciones);
?>
<?= pb_seccion('bi-exclamation-triangle', 'Separación de funciones', 'Decida si se acepta o se reparte.') ?>
<div class="row g-3">
<?php if ($reporte['conflictos'] === []): ?><div class="col-12"><p class="text-secondary">Ningún puesto junta estos permisos.</p></div><?php endif; ?>
<?php foreach ($reporte['conflictos'] as $c): ?><div class="col-md-6 col-xl-4"><div class="summary-tile"><div><span><?= $e($c['conflicto']) ?></span><div><small><?= $e($c['puesto']) ?></small></div></div><strong><?= (int)$c['personas'] ?></strong></div></div><?php endforeach; ?>
</div></section>
<?= pb_registros(count($reporte['cuentas'])) ?>
<?= pb_tabla('Cuentas') ?><thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Usuario</th><th>Nombre</th><th>Puesto</th><th>Sucursal</th><th data-pb-insignia>Cuenta</th><th>Authenticator</th><th>Acceso hasta</th></tr></thead><tbody>
<?php if ($reporte['cuentas'] === []): ?><?= pb_fila_vacia(8, 'Sin cuentas') ?><?php endif; ?>
<?php foreach ($reporte['cuentas'] as $c):
$id=(int)$c['id_personal']; $activa=(int)$c['id_estatus']===4;
$ver=$identidad->puede('personal_ver') ? pb_accion_detalle('modal-detalle-persona',$id,'Ver persona','fa-user') : '';
$bloquear=$identidad->puede('personal_admin') && $activa && (int)$c['id'] !== $identidad->id()
    ? pb_accion_post('/personal/'.$id.'/usuario/baja','Bloquear acceso','fa-lock','¿Bloquear el acceso de «'.$c['usuario'].'»?','/seguridad/accesos',true) : '';
?><tr><?= pb_acciones([$ver,$bloquear]) ?><td><strong><?= $e($c['usuario']) ?></strong></td><td><?= $e($c['nombre']) ?></td><td><?= $e($c['puesto']) ?></td><td><?= $e($c['sucursal'] ?? 'Todas') ?></td><td><?= $activa ? pb_insignia('bien','Activa') : pb_insignia('mudo','Inactiva') ?></td><td><?= $c['totp_confirmado_en'] === null ? 'No' : 'Sí' ?></td><td><?= $c['acceso_hasta'] === null ? 'Sin caducidad' : $e(pb_fecha($c['acceso_hasta']) . ' · ' . ($c['acceso_motivo'] ?? '')) ?></td></tr><?php endforeach; ?>
</tbody><?= pb_tabla_fin() ?><?= pb_modulo_fin() ?>
<?php if ($identidad->puede('personal_ver')): ?><?= pb_detalle('modal-detalle-persona', 'Persona', '/personal-detalle') ?><?php endif; ?>
<?= pb_modal('modal-revision-accesos','Registrar revisión','/seguridad/accesos/revision',$csrf->campo(),'/seguridad/accesos') ?>
<?= pb_seccion('bi-journal-check','Resultado de la revisión') ?><div class="form-grid"><?= pb_campo('nota','Resultado de la revisión',['requerido'=>true,'largo'=>'500','clase'=>'form-grid__full']) ?></div></section><?= pb_modal_fin() ?>
<?= pb_modal_ver('modal-historial-accesos','Revisiones anteriores','modal-xl') ?>
<?= pb_seccion('bi-clock-history','Revisiones anteriores') ?><?= pb_tabla('Historial de revisiones','simple') ?><thead><tr><th data-pb-titulo>Fecha</th><th>Quién</th><th>Cuentas</th><th>Nota</th></tr></thead><tbody>
<?php if ($reporte['revisiones'] === []): ?><?= pb_fila_vacia(4,'Aún no hay registros') ?><?php endif; ?>
<?php foreach ($reporte['revisiones'] as $r): ?><tr><td data-order="<?= $e($r['revisado_en']) ?>"><?= $e(pb_fecha($r['revisado_en'])) ?></td><td><?= $e($r['usuario']) ?></td><td><?= (int)$r['usuarios'] ?></td><td><?= $e($r['nota']) ?></td></tr><?php endforeach; ?>
</tbody><?= pb_tabla_fin() ?></section><?= pb_modal_fin() ?>
