<?php
/**
 * Verificación en dos pasos (ficha 41). Sin listado: la configuración va en
 * una tarjeta y «Actualizar» abre el modal que la cambia. Cambiarla pide la
 * contraseña propia y, mientras esté encendida, el código de Authenticator:
 * lo comprueba `Servicios\Seguridad`, no esta pantalla. Los cambios se leen
 * en Bitácora, ya filtrada (P10).
 *
 * @var callable $e
 * @var \Nucleo\Csrf $csrf
 * @var array{activo:bool,cobertura:array{total:int,configurados:int},cambios:list<array<string,mixed>>} $estado
 */
$activo = $estado['activo'];
$total = $estado['cobertura']['total'];
$configurados = $estado['cobertura']['configurados'];
$sinAlta = $total - $configurados;
$personas = static fn (int $n): string => $n === 1 ? '1 persona' : $n . ' personas';
$posiciones = [
    'Encendido' => ['Estos puestos piden código del teléfono', 'Usuario, contraseña y código de quien autoriza'],
    'Apagado'   => ['Todos entran con usuario y contraseña', 'Usuario y contraseña de quien autoriza'],
];
$ultimo = $estado['cambios'][0] ?? null;
?>
<?= pb_modulo('bi-shield-lock', 'Verificación en dos pasos', 'Cuándo se pide el código de verificación al entrar y al autorizar.',
    pb_agregar('modal-segundo-factor', 'Actualizar', 'Actualizar verificación')) ?>

<div class="card"><div class="card-body">
<div class="detail-hero">
    <div><span>Segundo factor</span><strong><?= $activo ? pb_insignia('bien', 'Encendido', 'bi-shield-check') : pb_insignia('avisa', 'Apagado', 'bi-shield-exclamation') ?></strong></div>
    <div><span>Con Authenticator</span><strong><?= $e($configurados . ' de ' . $total) ?></strong></div>
</div>
<dl class="detail-list mt-3">
    <div class="detail-list__row"><dt>Al entrar</dt><dd><?= $e($posiciones[$activo ? 'Encendido' : 'Apagado'][0]) ?></dd></div>
    <div class="detail-list__row"><dt>Al autorizar</dt><dd><?= $e($posiciones[$activo ? 'Encendido' : 'Apagado'][1]) ?></dd></div>
    <div class="detail-list__row"><dt>Último cambio</dt><dd><?= $ultimo === null ? 'Sin cambios registrados' : $e(pb_fecha($ultimo['momento']) . ' · ' . ($ultimo['usuario'] ?? 'Sistema')) ?>
        · <a href="/bitacora?modulo=seguridad">Ver en Bitácora</a></dd></div>
</dl>
</div></div>

<?= pb_modulo_fin() ?>

<?= pb_modal('modal-segundo-factor', 'Actualizar verificación', '/seguridad/segundo-factor', $csrf->campo() . '<input type="hidden" name="encender" value="' . ($activo ? '0' : '1') . '">', '/seguridad') ?>
<?= pb_seccion('bi-shield', 'Posición') ?>
<?php foreach ($posiciones as $nombre => [$entrar, $autorizar]): $queda = ($nombre === 'Encendido') !== $activo; ?>
<div class="border rounded p-2 mb-2<?= $queda ? ' bg-body-tertiary' : '' ?>">
    <strong><?= $e($nombre) ?></strong> <?= $queda ? pb_insignia('info', 'Quedará') : pb_insignia('mudo', 'Ahora') ?>
    <dl class="detail-list mb-0 mt-1">
        <div class="detail-list__row"><dt>Al entrar</dt><dd><?= $e($entrar) ?></dd></div>
        <div class="detail-list__row"><dt>Al autorizar</dt><dd><?= $e($autorizar) ?></dd></div>
    </dl>
</div>
<?php endforeach; ?>
</section>
<?php if ($activo): ?>
    <?= pb_seccion('bi-shield-x', 'Apagar código', 'Sin código, basta la contraseña para entrar.', 'form-section--danger') ?>
<?php else: ?>
    <?= pb_seccion('bi-shield-check', 'Encender código', $sinAlta > 0 ? $personas($sinAlta) . ' darán de alta Authenticator.' : 'Se pide desde la siguiente entrada.') ?>
<?php endif; ?>
    <div class="form-grid">
        <?= pb_campo('clave', 'Su contraseña', [
            'id' => 'seguridadClave', 'tipo' => 'password', 'requerido' => true,
            'autocompletado' => 'current-password', 'clase' => 'form-grid__full',
        ]) ?>
        <?php if ($activo): ?>
            <?= pb_campo('codigo', 'Código de Authenticator', [
                'id' => 'seguridadCodigo', 'modo' => 'numeric', 'patron' => '[0-9]{6}', 'largo' => '6',
                'autocompletado' => 'one-time-code', 'requerido' => true, 'clase' => 'form-grid__full',
            ]) ?>
        <?php endif; ?>
    </div>
</section>
<?= pb_modal_fin() ?>
