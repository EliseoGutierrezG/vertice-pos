<?php
/**
 * El tablero de la capa base: las fichas de lo que hay que atender y, para
 * quien no tiene tablero, los accesos a sus pantallas.
 *
 * @var callable $e @var \Nucleo\Identidad $identidad @var list<string> $permisos
 * @var list<array<string,string>> $fichas @var ?array $resumen
 */
echo pb_modulo('bi-speedometer2', 'Tablero', 'Lo que hay que atender hoy en sus sucursales.');
?>
<?php if ($fichas !== []): ?>
<section class="inicio-hoy" aria-labelledby="inicio-hoy-titulo">
<h2 id="inicio-hoy-titulo">Lo de hoy</h2>
<div class="inicio-hoy__rejilla"><?php foreach ($fichas as $f): ?><a class="summary-tile" href="<?= $e($f['ruta']) ?>"><div><span><?= $e($f['titulo']) ?></span><div><small><?= $e($f['pie']) ?></small></div></div><strong><?= $e($f['dato']) ?></strong></a><?php endforeach; ?></div>
<?php if ($resumen !== null): ?><p class="tablero-actualizado"><i class="bi bi-clock"></i> Consultado <time datetime="<?= $e($resumen['actualizado_en']) ?>"><?= $e(pb_fecha($resumen['actualizado_en'])) ?></time>.</p><?php endif; ?>
</section>
<?php endif; ?>

<?php if ($sucursales !== []): ?>
    <?= pb_seccion('bi-shop', 'Operación de hoy') ?>
    <?= pb_filtros('/panel') ?>
    <?= pb_campo('sucursal', 'Sucursal', ['tipo' => 'select', 'opciones' => $sucursales, 'valor' => $sucursal, 'nativo' => true]) ?>
    <?= pb_filtros_fin('/panel') ?>
    <?php if ($operacion !== []): ?>
        <div class="inicio-hoy__rejilla" data-restaurante-vivo="<?= (int) $sucursal ?>">
            <?php foreach (['venta' => 'Venta de hoy', 'cuentas' => 'Cuentas abiertas', 'mesas' => 'Mesas ocupadas',
                'cocina' => 'Platillos en cocina', 'atrasadas' => 'Comandas con 20 min o más', 'impresiones' => 'Impresiones demoradas',
                'reservaciones' => 'Reservaciones por confirmar', 'faltantes' => 'Faltantes pendientes', 'turno' => 'Turno de caja'] as $clave => $nombre): ?>
                <div class="summary-tile"><span><?= $e($nombre) ?></span>
                    <strong data-resumen="<?= $e($clave) ?>"><?= $e(($clave === 'venta' ? '$' : '') . $operacion[$clave]) ?></strong>
                </div>
            <?php endforeach; ?>
        </div>
        <p class="tablero-actualizado">Última consulta <span data-resumen="actualizado"><?= $e($operacion['actualizado']) ?></span></p>
        <script src="/recursos/reporte-vivo.js" defer></script>
    <?php endif; ?>
    </section>
<?php endif; ?>

<?php
// Los accesos salen del mismo menú de la barra lateral, filtrados con puede():
// el inicio de un puesto sin tablero muestra a dónde puede ir, con nombres de
// pantalla y no con las claves internas de los permisos.
$puede = static function (array|string $permiso) use ($identidad): bool {
    foreach ((array) $permiso as $cual) {
        if ($identidad->puede($cual)) {
            return true;
        }
    }
    return false;
};
$accesos = [];
foreach (require __DIR__ . '/../plantilla/menu.php' as [$grupo, , $entradas]) {
    $visibles = array_values(array_filter($entradas, static fn (array $fila): bool => $puede($fila[3])));
    if ($visibles !== []) {
        $accesos[$grupo] = $visibles;
    }
}
?>
<?= pb_seccion('bi-grid', 'Sus pantallas') ?>
<?php if ($accesos === [] && $identidad->usaApp()): ?><?= pb_vacio('Su puesto trabaja en la app', 'Entre desde su equipo asignado', 'bi-tablet') ?>
<?php elseif ($permisos === []): ?><?= pb_vacio('Su cuenta no tiene accesos', 'Avise al administrador', 'bi-person-lock') ?>
<?php elseif ($accesos === []): ?><?= pb_vacio('Su puesto trabaja en la app', '', 'bi-tablet') ?>
<?php else: ?><div class="inicio-accesos"><?php foreach ($accesos as $grupo => $filas): ?><div class="inicio-accesos__grupo"><h3><?= $e($grupo) ?></h3><nav aria-label="<?= $e($grupo) ?>"><?php foreach ($filas as $fila): ?><a class="inicio-acceso" href="<?= $e($fila[0]) ?>"><?= pb_ico($fila[2]) ?><span><?= $e($fila[1]) ?></span></a><?php endforeach; ?></nav></div><?php endforeach; ?></div><?php endif; ?>
</section>
<?= pb_modulo_fin() ?>
