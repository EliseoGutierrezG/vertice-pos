<?php
/**
 * Ver de una solicitud ARCO (ficha 44): lo que se pidió, quién la registró y
 * cómo se atendió.
 *
 * @var callable $e @var array<string,mixed> $solicitud @var array<string,string> $tipos @var array<string,string> $titulares
 */
$s = $solicitud;
?>
<?= pb_seccion('bi-inbox', 'Solicitud') ?>
<dl class="detail-list">
<div class="detail-list__row"><dt>Quién lo pide</dt><dd><?= $e($s['solicitante']) ?></dd></div>
<div class="detail-list__row"><dt>Cómo contestarle</dt><dd><?= $e($s['contacto'] ?? '—') ?></dd></div>
<div class="detail-list__row"><dt>Derecho</dt><dd><?= $e($tipos[$s['tipo']] ?? $s['tipo']) ?></dd></div>
<div class="detail-list__row"><dt>Titular</dt><dd><?= $e(($titulares[$s['titular_tipo']] ?? '') . ($s['id_titular'] === null ? '' : ' ' . $s['id_titular'])) ?></dd></div>
<div class="detail-list__row"><dt>Qué pide</dt><dd class="text-break"><?= $e($s['detalle']) ?></dd></div>
<div class="detail-list__row"><dt>Recibida</dt><dd><?= $e(pb_fecha($s['recibida_en'])) ?> · registró <?= $e($s['registrada_por_usuario']) ?></dd></div>
<div class="detail-list__row"><dt>Vence</dt><dd><?= $e(pb_fecha($s['vence_en'])) ?></dd></div>
<div class="detail-list__row"><dt>Estatus</dt><dd><?= $e(ucfirst((string) $s['estado'])) ?></dd></div>
<?php if ($s['resolucion'] !== null): ?>
<div class="detail-list__row"><dt>Qué se contestó</dt><dd class="text-break"><?= $e($s['resolucion']) ?></dd></div>
<div class="detail-list__row"><dt>Atendió</dt><dd><?= $e($s['atendida_por_usuario'] ?? '—') ?></dd></div>
<?php endif; ?>
</dl>
</section>
