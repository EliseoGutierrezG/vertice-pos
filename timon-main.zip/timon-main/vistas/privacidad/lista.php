<?php
/**
 * Privacidad (ficha 44): solicitudes de derechos ARCO y su atención. Agregar
 * solicitud es un modal del encabezado; la fila lleva Ver, Actualizar (cerrar
 * con lo que se contestó), Descargar datos en las de Acceso y Anonimizar en
 * las de Cancelación u Oposición (P11). Anonimizar sigue pidiendo escribir la
 * palabra: no tiene vuelta atrás.
 *
 * @var callable $e
 * @var \Nucleo\Csrf $csrf
 * @var list<array<string,mixed>> $solicitudes
 * @var array<string,string> $tipos
 * @var array<string,string> $titulares
 */
$hoy = date('Y-m-d');
$abiertas = array_filter($solicitudes, static fn (array $s): bool => $s['estado'] === 'abierta');
$vencidas = array_filter($abiertas, static fn (array $s): bool => $s['vence_en'] < $hoy);
$encabezado = pb_agregar('modal-solicitud', 'Agregar solicitud', 'Agregar solicitud') . pb_exportar('/privacidad.xlsx');
?>
<?= pb_modulo('bi-person-lock', 'Privacidad', 'Solicitudes de derechos ARCO de clientes y empleados, y su atención.', $encabezado, '', ['/aviso-privacidad', 'Ver el aviso de privacidad']) ?>

<div class="detail-hero">
    <div><span>Abiertas</span><strong><?= $e((string) count($abiertas)) ?></strong></div>
    <div><span>Vencidas</span><strong><?= $vencidas === [] ? '0' : pb_insignia('error', (string) count($vencidas)) ?></strong></div>
</div>

<?= pb_registros(count($solicitudes)) ?>
<?= pb_tabla('Solicitudes', '', false, 'bi-inbox') ?>
    <thead><tr><th class="no-orden" data-pb-acciones>Acción</th><th data-pb-titulo>Quién</th><th>Derecho</th><th>Titular</th><th>Recibida</th><th>Vence</th><th data-pb-insignia>Estatus</th><th class="text-wrap">Detalle</th></tr></thead>
    <tbody>
    <?php if ($solicitudes === []): ?>
        <?= pb_fila_vacia(8, 'Aún no hay solicitudes') ?>
    <?php endif; ?>
    <?php foreach ($solicitudes as $s):
        $id = (int) $s['id'];
        $abierta = $s['estado'] === 'abierta';
        $conTitular = $s['titular_tipo'] === 'empleado' && $s['id_titular'] !== null;
        $titular = ($titulares[$s['titular_tipo']] ?? '') . ($s['id_titular'] === null ? '' : ' ' . $s['id_titular']);
        $base = '/privacidad/' . $s['titular_tipo'] . '/' . (int) $s['id_titular'];
    ?>
        <tr>
            <?= pb_acciones([
                pb_accion_detalle('modal-detalle-solicitud', $id),
                $abierta ? pb_accion_modal('modal-cierra-solicitud', 'actualizar', $id, '/privacidad/solicitudes/' . $id . '/cerrar', 'Atender solicitud de ' . $s['solicitante'], []) : '',
                $conTitular && $s['tipo'] === 'acceso' ? pb_accion($base . '/datos', 'Descargar datos', 'fa-download', ['data-pb-sin-espera' => '1']) : '',
                $conTitular && in_array($s['tipo'], ['cancelacion', 'oposicion'], true)
                    ? pb_accion_abre('modal-anonimizar', 'Anonimizar', 'fa-eraser', 'Anonimizar ' . mb_strtolower($titular), ['volver' => '/privacidad'], $base . '/anonimizar') : '',
            ]) ?>
            <td><strong><?= $e($s['solicitante']) ?></strong></td>
            <td><?= $e($tipos[$s['tipo']] ?? $s['tipo']) ?></td>
            <td><?= $e($titular) ?></td>
            <td data-order="<?= $e($s['recibida_en']) ?>"><?= $e(pb_fecha($s['recibida_en'])) ?></td>
            <td data-order="<?= $e($s['vence_en']) ?>"><?= $e(pb_fecha($s['vence_en'])) ?></td>
            <td><?= match ($s['estado']) {
                'abierta' => $s['vence_en'] < $hoy ? pb_insignia('error', 'Vencida') : pb_insignia('advertencia', 'Abierta'),
                'atendida' => pb_insignia('bien', 'Atendida'),
                default => pb_insignia('mudo', 'Rechazada'),
            } ?></td>
            <td class="text-wrap"><?= $e($s['detalle']) ?><?= $s['resolucion'] === null ? '' : '<br><small class="text-secondary">' . $e($s['resolucion']) . '</small>' ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
<?= pb_tabla_fin() ?>
<?= pb_modulo_fin() ?>
<?= pb_detalle('modal-detalle-solicitud', 'Solicitud', '/privacidad/solicitudes', 'modal-lg') ?>

<?= pb_modal('modal-solicitud', 'Agregar solicitud', '/privacidad/solicitudes', $csrf->campo(), '/privacidad') ?>
<?= pb_seccion('bi-inbox', 'Solicitud') ?>
<div class="form-grid">
    <?= pb_campo('tipo', 'Derecho que se pide', ['tipo' => 'select', 'requerido' => true, 'opciones' => $tipos, 'vacia' => 'Seleccione']) ?>
    <?= pb_campo('recibida_en', 'Recibida el', ['tipo' => 'fecha', 'requerido' => true, 'valor' => $hoy]) ?>
    <?= pb_campo('solicitante', 'Quién lo pide', ['requerido' => true, 'largo' => '160']) ?>
    <?= pb_campo('contacto', 'Cómo contestarle', ['largo' => '160']) ?>
    <?= pb_campo('titular_tipo', 'Titular', ['tipo' => 'select', 'requerido' => true, 'opciones' => $titulares, 'vacia' => 'Seleccione']) ?>
    <?= pb_campo('id_titular', 'Número de titular', ['tipo' => 'number', 'minimo' => '1', 'ayuda' => 'Número en la dirección de su ficha.']) ?>
    <?= pb_campo('detalle', 'Qué pide', ['requerido' => true, 'largo' => '500', 'clase' => 'form-grid__full']) ?>
</div>
</section>
<?= pb_modal_fin() ?>

<?= pb_modal('modal-cierra-solicitud', 'Atender solicitud', '/privacidad', $csrf->campo(), '/privacidad') ?>
<?= pb_seccion('bi-check2-square', 'Respuesta') ?>
<div class="form-grid">
    <?= pb_campo('resolucion', 'Qué se contestó', ['requerido' => true, 'largo' => '500', 'clase' => 'form-grid__full']) ?>
    <?= pb_campo('estado', 'Cómo se cierra', ['tipo' => 'select', 'requerido' => true, 'opciones' => ['atendida' => 'Atendida', 'rechazada' => 'Rechazada'], 'vacia' => 'Seleccione', 'nativo' => true]) ?>
</div>
</section>
<?= pb_modal_fin() ?>

<?= pb_modal('modal-anonimizar', 'Anonimizar', '/privacidad', $csrf->campo(), '/privacidad') ?>
<?= pb_seccion('bi-eraser', 'Confirmación', 'No se puede deshacer.', 'form-section--danger') ?>
<div class="form-grid">
    <?= pb_campo('confirmacion', 'Para anonimizar, capture ANONIMIZAR', ['requerido' => true, 'clase' => 'form-grid__full', 'ayuda' => 'Se borran selfies y rastro; las ventas quedan.']) ?>
</div>
</section>
<?= pb_modal_fin('Anonimizar', 'fa-eraser') ?>
