<?php
/**
 * Avisos (C5, 2026-11-08): el historial de avisos a los teléfonos y «Agregar»
 * para mandar uno a una persona, un puesto, una sucursal o a todos.
 * Cada destino dice cuántas personas y teléfonos lo reciben: es la vista
 * previa, sin pedir nada al servidor.
 *
 * @var callable $e @var \Nucleo\Identidad $identidad @var \Nucleo\Csrf $csrf
 * @var array $avisos @var array $destinos @var string $desde @var string $hasta
 */
$puedeEnviar = $identidad->puede('notificaciones_envia');
$consulta = ['desde' => $desde, 'hasta' => $hasta];
$volver = '/avisos?' . http_build_query($consulta);
$plural = static fn (int $n, string $uno, string $varios): string => $n . ' ' . ($n === 1 ? $uno : $varios);
$opciones = [];
foreach ($destinos as $d) {
    $tipo = \Servicios\Notificaciones::DESTINOS[$d['tipo']];
    $opciones[$d['valor']] = ($d['tipo'] === 'todos' ? $tipo : $tipo . ' · ' . $d['texto'])
        . ' (' . $plural($d['personas'], 'persona', 'personas') . ', ' . $plural($d['telefonos'], 'teléfono', 'teléfonos') . ')';
}
echo pb_modulo('bi-megaphone', 'Avisos', 'Avisos del panel a los teléfonos del personal.',
    ($puedeEnviar && $opciones !== [] ? pb_agregar('modal-aviso', 'Agregar', 'Enviar aviso') : '') . pb_exportar('/avisos.xlsx', $consulta));
?>
<?php if ($puedeEnviar && $opciones === []): ?><?= pb_aviso('info', 'Nadie tiene avisos activos todavía.') ?><?php endif; ?>
<?= pb_filtros('/avisos') ?>
<?= pb_rango($desde, $hasta) ?>
<?= pb_filtros_fin('/avisos') ?>
<?= pb_registros(count($avisos)) ?>
<?= pb_tabla('Avisos', '', false, 'bi-megaphone') ?><thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Título</th><th>Enviado</th><th>Destino</th><th class="text-end">Personas</th><th class="text-end">Teléfonos</th><th class="text-end">Recibidos</th><th class="text-end">Fallidos</th><th>Envió</th></tr></thead><tbody>
<?php if ($avisos === []): ?><?= pb_fila_vacia(9, 'Sin avisos en este periodo') ?><?php endif; ?>
<?php foreach ($avisos as $a): ?><tr><?= pb_acciones([pb_accion_detalle('modal-detalle-aviso', (int) $a['id'])]) ?>
<td><strong><?= $e($a['titulo']) ?></strong><div class="small text-secondary"><?= $e(mb_strimwidth((string) $a['cuerpo'], 0, 60, '…')) ?></div></td>
<td data-order="<?= $e($a['creado_en']) ?>"><?= $e(pb_fecha($a['creado_en'])) ?></td>
<td><?= $e(\Controladores\Web\AvisosWeb::destino($a)) ?></td>
<td class="text-end"><?= (int) $a['personas'] ?></td><td class="text-end"><?= (int) $a['telefonos'] ?></td>
<td class="text-end"><?= (int) $a['aceptados'] ?></td>
<td class="text-end"><?php if ((int) $a['fallidos'] > 0): ?><?= pb_insignia('avisa', (string) (int) $a['fallidos']) ?><?php else: ?>0<?php endif; ?></td>
<td><?= $e($a['envio']) ?></td></tr><?php endforeach; ?>
</tbody><?= pb_tabla_fin() ?><?= pb_modulo_fin() ?>
<?= pb_detalle('modal-detalle-aviso', 'Aviso', '/avisos', 'modal-lg') ?>

<?php if ($puedeEnviar && $opciones !== []): ?>
<?= pb_modal('modal-aviso', 'Enviar aviso', '/avisos', $csrf->campo(), $volver) ?>
<?= pb_seccion('bi-people', 'Destinatarios', 'Solo teléfonos autorizados con avisos.') ?><div class="form-grid">
    <?= pb_campo('destino', 'Mandar a', ['tipo' => 'select', 'opciones' => $opciones, 'vacia' => 'Seleccione', 'requerido' => true, 'clase' => 'field-span-2']) ?>
</div></section>
<?= pb_seccion('bi-bell', 'Aviso', '') ?><div class="form-grid">
    <?= pb_campo('titulo', 'Título', ['valor' => 'El Timón', 'requerido' => true, 'largo' => '80']) ?>
    <?= pb_campo('cuerpo', 'Mensaje', ['tipo' => 'textarea', 'filas' => '3', 'requerido' => true, 'largo' => '255', 'clase' => 'field-span-2']) ?>
</div></section>
<?= pb_modal_fin('Enviar', 'fa-send') ?>
<?php endif; ?>
