<?php
/**
 * Un aviso en el modal «Ver» (C5): a quién se mandó y cómo le fue en cada
 * teléfono. El motivo de un fallo es el que dio Expo.
 *
 * @var callable $e @var array $aviso @var string $destino
 */
?>
<div class="detail-hero"><div><span>Destino</span><strong><?= $e($destino) ?></strong></div><div><span>Enviado</span><strong><?= $e(pb_fecha($aviso['creado_en'])) ?></strong></div><div><span>Envió</span><strong><?= $e($aviso['envio']) ?></strong></div><div><span>Recibidos</span><strong><?= (int) $aviso['aceptados'] ?> de <?= (int) $aviso['telefonos'] ?></strong></div></div>
<p class="mb-3"><?= $e($aviso['cuerpo']) ?></p>
<?= pb_tabla('Teléfonos del aviso', 'simple') ?><thead><tr><th data-pb-titulo>Persona</th><th>Teléfono</th><th data-pb-insignia>Resultado</th></tr></thead><tbody>
<?php foreach ($aviso['telefonos_detalle'] as $t): ?><tr><td><strong><?= $e($t['persona']) ?></strong></td><td><?= $e($t['telefono'] ?? 'Sin nombre') ?></td>
<td><?php if ($t['enviado_en'] !== null): ?><?= pb_insignia('bien', 'Recibido') ?><?php else: ?><?= pb_insignia('avisa', 'Falló') ?><div class="small text-secondary"><?= $e($t['error'] ?? 'Sin respuesta') ?></div><?php endif; ?></td></tr><?php endforeach; ?>
</tbody><?= pb_tabla_fin() ?>
