<?php
/**
 * La pestaña que se abrió para recuperar la sesión de otra (homologación §S.6).
 * Lo capturado sigue en la otra pestaña: aquí solo se dice que ya puede volver.
 *
 * @var callable $e
 */
?>
<div class="auth-brand">
    <?= pb_marca_logo($marcaVisual ?? null, 'horizontal', pb_marca_texto($marcaVisual ?? null)) ?>
</div>

<div class="auth-heading">
    <span class="auth-badge">Acceso privado</span>
    <h1>Sesión iniciada</h1>
</div>

<p class="auth-note">Ya puede cerrar esta pestaña y volver a guardar.</p>
<p class="auth-note"><a href="/panel">Ir al tablero</a></p>
