<?php
/**
 * Cambiar la contraseña propia. Si llegó aquí con una temporal, no hay otra
 * pantalla a la que pueda ir hasta cambiarla (`ExigeClaveDefinitiva`).
 *
 * @var callable $e
 * @var \Nucleo\Csrf $csrf
 * @var bool $temporal
 * @var int $minimo
 */
?>
<?= pb_modulo(
    'bi-shield-lock',
    'Cambiar contraseña', 'Cambio de la contraseña con la que entra al sistema.',
    $temporal ? '' : pb_boton('/perfil', 'Mi perfil', 'bi-arrow-left', 'outline-secondary')
) ?>

<?php if ($temporal): ?>
    <?= pb_aviso('advertencia', 'Contraseña temporal: escoja la suya para seguir.') ?>
<?php endif; ?>

<form method="post" action="/cambiar-clave" data-pb-ajax class="mt-3" style="max-width: 36rem">
    <?= $csrf->campo() ?>
    <div class="alert alert-danger d-none" role="alert" data-pb-error></div>
    <?= pb_seccion('bi-key', 'Contraseña') ?>
        <div class="form-grid">
            <?= pb_campo('actual', $temporal ? 'Contraseña temporal' : 'Contraseña actual', [
                'id' => 'claveActual', 'tipo' => 'password', 'requerido' => true, 'autocompletado' => 'current-password',
                'clase' => 'form-grid__full', 'autofoco' => true,
            ]) ?>
            <?= pb_campo('nueva', 'Contraseña nueva', [
                'id' => 'claveNueva', 'tipo' => 'password', 'requerido' => true, 'autocompletado' => 'new-password',
                'clase' => 'form-grid__full',
                'ayuda' => 'Al menos ' . $minimo . ' caracteres, sin su nombre de usuario.',
                'extra' => ['minlength' => (string) $minimo],
            ]) ?>
            <?= pb_campo('confirma', 'Repita la contraseña nueva', [
                'id' => 'claveConfirma', 'tipo' => 'password', 'requerido' => true, 'autocompletado' => 'new-password',
                'clase' => 'form-grid__full',
            ]) ?>
        </div>
    </section>
    <div class="d-flex justify-content-end gap-2 mt-3">
        <button class="btn btn-primary" type="submit"><i class="bi bi-check2"></i> Cambiar contraseña</button>
    </div>
</form>

<?php if ($temporal): ?>
    <form method="post" action="/salir" class="mt-2">
        <?= $csrf->campo() ?>
        <button class="btn btn-link text-secondary px-0" type="submit"><i class="bi bi-box-arrow-right"></i> Salir sin cambiarla</button>
    </form>
<?php endif; ?>

<?= pb_modulo_fin() ?>
