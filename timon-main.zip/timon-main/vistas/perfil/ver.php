<?php
/**
 * El perfil propio, con el perfil de la plantilla base: `perfil-hero` y dos
 * `module-card` con su `detail-list`.
 *
 * @var callable $e
 * @var \Nucleo\Csrf $csrf
 * @var array<string,mixed> $usuario
 * @var list<string> $permisos
 * @var array<string,string> $descripciones
 */
$nombre = trim((string) ($usuario['nombre'] ?? ''));
// En palabras, no con la clave interna; la clave sólo queda si faltara su descripción.
$enPalabras = array_map(static fn (string $p): string => $descripciones[$p] ?? $p, $permisos);
sort($enPalabras, SORT_LOCALE_STRING);
?>
<section class="perfil-shell" data-module="perfil">
    <div class="perfil-hero">
        <div class="perfil-hero__avatar-wrap">
            <span class="perfil-hero__avatar pb-inicial" aria-hidden="true"><?= $e(pb_inicial($nombre)) ?></span>
        </div>
        <div class="perfil-hero__info">
            <span class="perfil-hero__label">Mi perfil</span>
            <h1><?= $e($nombre) ?></h1>
            <p><?= $e((string) ($usuario['usuario'] ?? '')) ?></p>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-12 col-xl-6">
            <div class="module-card h-100">
                <?= pb_encabezado('bi-person-lines-fill', 'Información de la cuenta') ?>
                <dl class="detail-list">
                    <div class="detail-list__row"><dt><i class="bi bi-person"></i> Nombre</dt><dd><?= $e($nombre) ?></dd></div>
                    <div class="detail-list__row"><dt><i class="bi bi-at"></i> Usuario</dt><dd><?= $e((string) ($usuario['usuario'] ?? '')) ?></dd></div>
                    <div class="detail-list__row"><dt><i class="bi bi-person-badge"></i> Puesto</dt><dd><?= $e((string) ($usuario['nombre_puesto'] ?? '')) ?></dd></div>
                    <div class="detail-list__row"><dt><i class="bi bi-building"></i> Sucursal</dt><dd><?= $e((string) ($usuario['sucursal'] ?? 'Todas las sucursales')) ?></dd></div>
                </dl>
            </div>
        </div>
        <div class="col-12 col-xl-6">
            <div class="module-card h-100">
                <?= pb_encabezado('bi-shield-lock', 'Sesión') ?>
                <details class="perfil-permisos mb-3">
                    <summary>Ver lo que puede hacer</summary>
                    <ul class="perfil-permisos__lista">
                        <?php foreach ($enPalabras as $permiso): ?>
                            <li><?= $e($permiso) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </details>
                <div class="d-flex flex-wrap gap-2">
                    <?= pb_boton('/cambiar-clave', 'Cambiar contraseña', 'bi-key', 'outline-secondary') ?>
                    <?php if (\Nucleo\Giro::activo('restaurante') && ($identidad->usaApp() || $identidad->esAdministrador())): ?>
                        <?= pb_agregar('pinComanda', 'Configurar PIN de comanda', 'Configurar PIN de comanda') ?>
                    <?php endif; ?>
                    <form method="post" action="/salir" data-confirma="La sesión actual se cerrará." data-confirma-titulo="¿Cerrar sesión?">
                        <?= $csrf->campo() ?>
                        <button class="btn btn-outline-danger" type="submit"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if (\Nucleo\Giro::activo('restaurante') && ($identidad->usaApp() || $identidad->esAdministrador())): ?>
    <?= pb_modal('pinComanda', 'Configurar PIN de comanda', '/perfil/pin', $csrf->campo(), '/perfil') ?>
    <div class="form-grid">
        <?= pb_campo('clave', 'Contraseña actual', ['tipo' => 'password', 'autocompletado' => 'current-password', 'requerido' => true]) ?>
        <?= pb_campo('pin', 'PIN nuevo', ['tipo' => 'password', 'modo' => 'numeric', 'patron' => '[0-9]{4,6}', 'largo' => 6,
            'autocompletado' => 'new-password', 'requerido' => true]) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>
