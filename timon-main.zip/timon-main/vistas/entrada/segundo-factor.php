<?php /** @var callable $e @var \Nucleo\Csrf $csrf @var string $usuario @var ?string $error */ ?>
<div class="auth-brand"><?= pb_marca_logo($marcaVisual ?? null, 'horizontal', pb_marca_texto($marcaVisual ?? null)) ?></div>
<div class="auth-heading">
    <span class="auth-badge">Segundo factor</span>
    <h1>Verificar acceso</h1>
    <p>Código de 6 dígitos de Authenticator para <strong><?= $e($usuario) ?></strong>.</p>
</div>
<form method="post" action="/segundo-factor" autocomplete="off">
    <?= $csrf->campo() ?>
    <?php if ($error): ?><div class="alert alert-danger" role="alert" tabindex="-1" autofocus><?= $e($error) ?></div><?php endif; ?>
    <div class="auth-field">
        <label for="codigo">Código del teléfono <span aria-hidden="true">*</span></label>
        <input id="codigo" name="codigo" type="text" inputmode="numeric" autocomplete="one-time-code"
            minlength="6" maxlength="6" pattern="[0-9]{6}" required autofocus>
    </div>
    <button class="auth-submit" type="submit">Verificar y entrar</button>
</form>
<?php /* El código de recuperación lleva letras: con `inputmode="numeric"` el
   teléfono no deja escribirlo. Va en su propio formulario, sin JavaScript. */ ?>
<details class="auth-recuperacion">
    <summary>¿No tiene el teléfono? Use un código de recuperación</summary>
    <form method="post" action="/segundo-factor" autocomplete="off">
        <?= $csrf->campo() ?>
        <div class="auth-field">
            <label for="codigo-recuperacion">Código de recuperación <span aria-hidden="true">*</span></label>
            <input id="codigo-recuperacion" name="codigo" type="text" autocapitalize="characters" spellcheck="false"
                minlength="12" maxlength="14" pattern="[A-Za-z0-9\-]{12,14}" placeholder="XXXX-XXXX-XXXX" required>
        </div>
        <button class="auth-submit" type="submit">Entrar</button>
    </form>
</details>
<p class="auth-note">Cada código de recuperación sirve una vez.</p>
