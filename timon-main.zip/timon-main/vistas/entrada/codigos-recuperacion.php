<?php /** @var callable $e @var list<string> $codigos */ ?>
<div class="auth-brand"><?= pb_marca_logo($marcaVisual ?? null, 'horizontal', pb_marca_texto($marcaVisual ?? null)) ?></div>
<div class="auth-heading">
    <span class="auth-badge">Una sola vez</span>
    <h1>Guarde sus códigos</h1>
    <p>Cada código sirve una vez. No volverán a mostrarse.</p>
</div>
<div class="alert alert-warning" role="alert"><strong>No los guarde con su contraseña.</strong></div>
<ul class="list-group mb-3" aria-label="Códigos de recuperación">
<?php foreach ($codigos as $codigo): ?><li class="list-group-item"><code><?= $e($codigo) ?></code></li><?php endforeach; ?>
</ul>
<a class="auth-submit d-block text-center text-decoration-none" href="/panel">Continuar</a>

