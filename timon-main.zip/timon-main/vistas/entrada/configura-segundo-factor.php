<?php /** @var callable $e @var \Nucleo\Csrf $csrf @var array $configuracion @var ?string $error */
// La clave en grupos de cuatro: se copia a mano en el teléfono y una base32 de
// 32 letras seguidas se lee mal. Las dos aplicaciones aceptan los espacios.
$claveLegible = trim(chunk_split((string) $configuracion['secreto'], 4, ' '));
?>
<div class="auth-brand"><?= pb_marca_logo($marcaVisual ?? null, 'horizontal', pb_marca_texto($marcaVisual ?? null)) ?></div>
<div class="auth-heading">
    <span class="auth-badge">Protección obligatoria</span>
    <h1>Active el segundo factor</h1>
    <p>Pide código del teléfono al entrar.</p>
</div>
<ol class="auth-pasos">
    <li>En el teléfono abra <strong>Google Authenticator</strong> o <strong>Microsoft Authenticator</strong> y toque agregar una cuenta.</li>
    <li>Escanee este código con la app.</li>
    <li>Capture el código de 6 dígitos.</li>
</ol>
<figure class="auth-qr">
    <?= pb_qr((string) $configuracion['uri'], 'Código QR para agregar la cuenta ' . (string) $configuracion['usuario'] . ' al autenticador') ?>
    <figcaption>No comparta este código.</figcaption>
</figure>
<details class="auth-recuperacion auth-sin-camara">
    <summary>¿No puede escanear? Capture la clave a mano</summary>
    <div class="auth-clave" role="group" aria-label="Datos para el autenticador">
        <span>Cuenta</span><strong><?= $e($configuracion['usuario']) ?></strong>
        <span>Clave</span><code><?= $e($claveLegible) ?></code>
        <span>Tipo</span><small>6 dígitos · cambia cada 30 segundos</small>
    </div>
    <p>Si está entrando desde el mismo teléfono, <a href="<?= $e($configuracion['uri']) ?>">ábrala directo en la aplicación</a>.</p>
</details>
<form method="post" action="/segundo-factor/configurar" autocomplete="off">
    <?= $csrf->campo() ?>
    <?php if ($error): ?><div class="alert alert-danger" role="alert" tabindex="-1" autofocus><?= $e($error) ?></div><?php endif; ?>
    <div class="auth-field">
        <label for="codigo">Código del teléfono <span aria-hidden="true">*</span></label>
        <input id="codigo" name="codigo" type="text" inputmode="numeric" autocomplete="one-time-code"
            minlength="6" maxlength="6" pattern="[0-9]{6}" required autofocus>
    </div>
    <button class="auth-submit" type="submit">Activar y continuar</button>
</form>
