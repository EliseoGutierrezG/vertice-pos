<?php
/**
 * El modal de alta y de Actualizar de una sucursal.
 *
 * La clave es la abreviatura que sale en tickets y folios (CEN, NTE…).
 *
 * @var \Nucleo\Csrf $csrf
 * @var array<string,string> $estados
 * @var string $volver
 */
?>
<?= pb_modal('modalSucursal', 'Agregar sucursal', '/sucursales', $csrf->campo(), $volver) ?>
    <?= pb_seccion('bi-building', 'Datos de la sucursal') ?>
        <div class="form-grid">
            <?= pb_campo('nombre', 'Nombre', ['id' => 'sucursalNombre', 'requerido' => true, 'largo' => '80', 'clase' => 'field-span-2', 'marcador' => 'Centro']) ?>
            <?= pb_campo('clave', 'Clave pública', ['id' => 'sucursalClave', 'largo' => '8', 'marcador' => 'CEN',
                'requerido' => \Nucleo\Giro::activo('restaurante'), 'ayuda' => 'Identifica la sucursal en menús y tickets.']) ?>
            <?= pb_campo('telefono', 'Teléfono', ['id' => 'sucursalTelefono', 'tipo' => 'tel', 'modo' => 'tel', 'largo' => '20', 'autocompletado' => 'off', 'ayuda' => '10 dígitos']) ?>
        </div>
    </section>
    <?= pb_seccion('bi-geo-alt', 'Dirección') ?>
        <div class="form-grid">
            <?= pb_campo('calle', 'Calle', ['id' => 'sucursalCalle', 'largo' => '120', 'clase' => 'field-span-2']) ?>
            <?= pb_campo('numero', 'Número', ['id' => 'sucursalNumero', 'largo' => '20']) ?>
            <?= pb_campo('colonia', 'Colonia', ['id' => 'sucursalColonia', 'largo' => '80']) ?>
            <?= pb_campo('cp', 'Código postal', ['id' => 'sucursalCp', 'modo' => 'numeric', 'largo' => '5', 'patron' => '\d{5}']) ?>
            <?= pb_campo('id_estado', 'Estado', ['id' => 'sucursalEstado', 'tipo' => 'select', 'vacia' => 'Sin estado', 'opciones' => $estados]) ?>
        </div>
    </section>
<?= pb_modal_fin() ?>
