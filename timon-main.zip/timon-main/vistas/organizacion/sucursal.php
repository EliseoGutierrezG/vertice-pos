<?php
/**
 * Ficha de la sucursal dentro del modal Ver. Actualizar y Dar de baja son
 * acciones de la fila. Las fases del giro agregan aquí sus secciones (áreas y
 * mesas, equipos, impresoras).
 *
 * @var callable $e
 * @var array<string,mixed> $sucursal
 */
$activa = (int) $sucursal['id_estatus'] === 4;

$calle     = trim(($sucursal['calle'] ?? '') . ' ' . ($sucursal['numero'] ?? ''));
$direccion = implode(', ', array_filter([$calle, $sucursal['colonia'] ?? null, $sucursal['cp'] ?? null, $sucursal['estado'] ?? null]));
?>
<?= pb_seccion('bi-info-circle', 'Datos') ?>
    <dl class="detail-list">
        <div class="detail-list__row">
            <dt>Estatus</dt>
            <dd><?= pb_estatus($activa, 'Activa', 'Dada de baja') ?></dd>
        </div>
        <div class="detail-list__row">
            <dt>Clave pública</dt>
            <dd><?= $sucursal['clave'] !== null ? '<code>' . $e($sucursal['clave']) . '</code>' : '<span class="text-secondary">Sin clave</span>' ?></dd>
        </div>
        <div class="detail-list__row">
            <dt>Dirección</dt>
            <dd><?= $direccion !== '' ? $e($direccion) : '<span class="text-secondary">Sin dirección</span>' ?></dd>
        </div>
        <div class="detail-list__row">
            <dt>Teléfono</dt>
            <dd><?= $sucursal['telefono'] !== null ? $e($sucursal['telefono']) : '<span class="text-secondary">Sin teléfono</span>' ?></dd>
        </div>
        <?php if (\Nucleo\Giro::activo('restaurante')): ?>
            <div class="detail-list__row">
                <dt>Horario de respaldo</dt><dd><?= $e($sucursal['horario_publico'] ?: 'Sin capturar') ?></dd>
            </div>
            <div class="detail-list__row">
                <dt>WhatsApp público</dt><dd><?= $e($sucursal['whatsapp_publico'] ?: 'Sin WhatsApp') ?></dd>
            </div>
        <?php endif; ?>
        <div class="detail-list__row">
            <dt>Personal activo</dt>
            <dd><?= (int) $sucursal['personas'] ?></dd>
        </div>
        <div class="detail-list__row">
            <dt>Dada de alta</dt>
            <dd><?= $e(pb_fecha(substr((string) $sucursal['creado_en'], 0, 10))) ?></dd>
        </div>
    </dl>
</section>

<?php if ($horarios !== []): ?>
    <?= pb_seccion('bi-clock', 'Horario semanal') ?>
    <dl class="detail-list">
        <?php $porDia = array_column($horarios, null, 'dia'); ?>
        <?php foreach (\Servicios\HorariosRestaurante::DIAS as $dia => $nombre): ?>
            <div class="detail-list__row">
                <dt><?= $e($nombre) ?></dt>
                <dd><?= $e(isset($porDia[$dia]) ? $porDia[$dia]['abre'] . '–' . $porDia[$dia]['cierra'] : 'Cerrado') ?></dd>
            </div>
        <?php endforeach; ?>
    </dl>
    </section>
<?php endif; ?>

<?php if ($arranque !== []): ?>
    <?php
    $idSucursal = (int) $sucursal['id'];
    $pasos = [
        ['Clave pública', $sucursal['clave'] !== null, '/sucursales', 'organizacion_admin'],
        ['Horario público', $horarios !== [] || $sucursal['horario_publico'] !== '', '/sucursales', 'organizacion_admin'],
        ['Áreas', (int) $arranque['areas'], '/areas', 'plano_ver'],
        ['Mesas', (int) $arranque['mesas'], '/mesas', 'plano_ver'],
        ['Platillos con precio', (int) $arranque['platillos'], '/platillos', 'menu_sucursal'],
        ['Impresoras activas', (int) $arranque['impresoras'], '/impresoras', 'plano_admin'],
        ['Personal con PIN', (int) $arranque['operadores'], '/personal', 'personal_ver'],
        ['Equipos autorizados', (int) $arranque['equipos'], '/equipos-comanda', 'equipo_admin'],
    ];
    ?>
    <?= pb_seccion('bi-list-check', 'Lista de arranque') ?>
    <dl class="detail-list">
        <?php foreach ($pasos as [$nombre, $listo, $ruta, $permiso]): ?>
            <?php $destino = $ruta === '/sucursales' ? $ruta . '?ver=' . $idSucursal : $ruta . '?sucursal=' . $idSucursal; ?>
            <div class="detail-list__row">
                <dt><?php if ($identidad->puede($permiso)): ?><a href="<?= $e($destino) ?>"><?= $e($nombre) ?></a>
                    <?php else: ?><?= $e($nombre) ?><?php endif; ?></dt>
                <dd><?= pb_insignia($listo ? 'bien' : 'advertencia', $listo ? (is_int($listo) ? (string) $listo : 'Listo') : 'Pendiente') ?></dd>
            </div>
        <?php endforeach; ?>
    </dl>
    </section>
<?php endif; ?>
