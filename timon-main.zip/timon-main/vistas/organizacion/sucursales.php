<?php
/**
 * Las sucursales del negocio.
 *
 * Una `module-card` de la plantilla base: encabezado con «Nueva sucursal», filtro de
 * estatus, resumen, tabla y el modal de alta y edición.
 *
 * @var callable $e
 * @var \Nucleo\Csrf $csrf
 * @var \Nucleo\Identidad $identidad
 * @var list<array<string,mixed>> $sucursales
 * @var string $estatus
 * @var array<string,string> $estados
 */
$admin  = $identidad->puede('organizacion_admin');
$volver = '/sucursales' . ($estatus === 'activas' ? '' : '?estatus=' . $estatus);

$direccion = static function (array $b): string {
    $calle = trim(($b['calle'] ?? '') . ' ' . ($b['numero'] ?? ''));

    return implode(', ', array_filter([$calle, $b['colonia'] ?? null, $b['estado'] ?? null]));
};
?>
<?= pb_modulo(
    'bi-building',
    'Sucursales', 'Sucursales del negocio, con su clave para tickets y su dirección.',
    ($admin ? pb_agregar('modalSucursal', 'Agregar', 'Agregar sucursal') : '')
        . pb_exportar('/sucursales.xlsx', $estatus === 'activas' ? [] : ['estatus' => $estatus])
) ?>

<?= pb_filtros('/sucursales') ?>
    <?= pb_filtro_estatus($estatus) ?>
<?= pb_filtros_fin('/sucursales') ?>

<?= pb_registros(count($sucursales)) ?>
<?= pb_tabla('Sucursales', '', false, 'bi-building') ?>
    <thead>
        <tr>
            <th class="no-orden" data-pb-acciones>Acción</th>
            <th>Clave</th>
            <th data-pb-titulo>Sucursal</th>
            <th>Dirección</th>
            <th>Teléfono</th>
            <th class="text-end">Personal activo</th>
            <th data-pb-insignia>Estatus</th>
        </tr>
    </thead>
    <tbody>
    <?php if ($sucursales === []): ?>
        <?= pb_fila_vacia(7, $estatus === 'activas' ? 'Aún no hay sucursales' : 'Sin sucursales con ese estatus') ?>
    <?php endif; ?>
    <?php foreach ($sucursales as $b): ?>
        <?php
        $activa   = (int) $b['id_estatus'] === 4;
        $id       = (int) $b['id'];
        $registro = ['clave' => $b['clave'], 'nombre' => $b['nombre'], 'calle' => $b['calle'], 'numero' => $b['numero'], 'colonia' => $b['colonia'], 'cp' => $b['cp'], 'id_estado' => $b['id_estado'], 'telefono' => $b['telefono']];
        ?>
        <tr>
            <?= pb_acciones([
                pb_accion_detalle('modal-detalle-sucursal', $id),
                $admin ? pb_accion_modal('modalSucursal', 'actualizar', $id, '/sucursales/' . $id, 'Actualizar sucursal', $registro) : '',
                $admin && $activa && \Nucleo\Giro::activo('restaurante')
                    ? pb_accion_modal('horarioPublico', 'actualizar', $id, '/sucursales/datos-publicos', 'Datos públicos',
                        ['sucursal' => $id, 'volver' => $volver], '/sucursales/' . $id, 'Datos públicos') : '',
                $admin ? pb_dar_baja('/sucursales', $id, $activa, (string) $b['nombre'], $volver) : '',
            ]) ?>
            <td><?= $b['clave'] !== null ? '<code>' . $e($b['clave']) . '</code>' : '<span class="text-secondary">—</span>' ?></td>
            <td class="fw-semibold"><?= $e($b['nombre']) ?></td>
            <td><?= $direccion($b) !== '' ? $e($direccion($b)) : '<span class="text-secondary">Sin dirección</span>' ?></td>
            <td><?= $e($b['telefono'] ?? '') ?></td>
            <td class="text-end"><?= (int) $b['personas'] ?></td>
            <td><?= pb_estatus($activa, 'Activa', 'Dada de baja') ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
<?= pb_tabla_fin() ?>

<?= pb_modulo_fin() ?>

<?= pb_detalle('modal-detalle-sucursal', 'Sucursal', '/sucursales') ?>
<?php if ($admin): ?>
    <?php require __DIR__ . '/modal-sucursal.php'; ?>
    <?php if (\Nucleo\Giro::activo('restaurante')): ?>
        <?= pb_modal('horarioPublico', 'Datos públicos', '/sucursales/datos-publicos', $csrf->campo()) ?>
        <input type="hidden" name="sucursal">
        <input type="hidden" name="volver" value="<?= $e($volver) ?>">
        <div class="form-grid">
            <?= pb_campo('horario', 'Horario de respaldo', ['largo' => 160, 'clase' => 'field-span-2']) ?>
            <?= pb_campo('whatsapp', 'WhatsApp con código de país', ['largo' => 15, 'patron' => '\d{10,15}', 'modo' => 'tel']) ?>
            <?= pb_campo('latitud', 'Latitud', ['tipo' => 'numero', 'min' => -90, 'max' => 90, 'step' => '0.0000001']) ?>
            <?= pb_campo('longitud', 'Longitud', ['tipo' => 'numero', 'min' => -180, 'max' => 180, 'step' => '0.0000001']) ?>
        </div>
        <?= pb_seccion('bi-clock', 'Horario semanal', 'Días cerrados con horas vacías.') ?>
        <div class="form-grid">
            <?php foreach (\Servicios\HorariosRestaurante::DIAS as $dia => $nombre): ?>
                <?= pb_campo('abre[' . $dia . ']', $nombre . ' · Apertura', ['tipo' => 'time', 'opcional' => false]) ?>
                <?= pb_campo('cierra[' . $dia . ']', $nombre . ' · Cierre', ['tipo' => 'time', 'opcional' => false]) ?>
            <?php endforeach; ?>
        </div>
        </section>
        <?= pb_modal_fin() ?>
    <?php endif; ?>
<?php endif; ?>
