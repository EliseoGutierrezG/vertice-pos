<?php
use Servicios\PlanoRestaurante;

$ruta = '/mesas';
$puedeEditar = $sucursal > 0 && $identidad->puede('plano_admin');
$nombresAreas = array_column($areas ?? [], 'nombre', 'id');
$estados = PlanoRestaurante::ESTADOS + ['ocupada' => 'Ocupada', 'cuenta_pedida' => 'Cuenta pedida', 'reservada' => 'Reservada'];
echo pb_modulo('bi-grid-3x3-gap', $titulo, 'Mesas, capacidad y ubicación por área.',
    $puedeEditar && $nombresAreas !== [] ? pb_agregar('mesaModal', 'Agregar', 'Agregar mesa') : '');
require __DIR__ . '/filtro.php';
?>
<?php if ($sucursal > 0): ?>
    <?= pb_registros(count($mesas)) ?>
    <?= pb_tabla('Mesas') ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Mesa</th><th>Área</th><th>Capacidad</th><th data-pb-insignia>Estado</th></tr></thead>
    <tbody>
    <?php if ($mesas === []): ?><?= pb_fila_vacia(5, $nombresAreas === [] ? 'Agregue un área para registrar mesas' : 'Aún no hay mesas') ?><?php endif; ?>
    <?php foreach ($mesas as $m): ?>
        <tr>
            <?= pb_acciones(array_filter([
                pb_accion_detalle('verMesa', (int) $m['id']),
                $puedeEditar && $m['id_cuenta'] === null ? pb_accion_modal('mesaModal', 'actualizar', (int) $m['id'],
                    $ruta . '/' . $m['id'], 'Actualizar mesa', [], $ruta . '/' . $m['id'] . '?sucursal=' . $sucursal) : '',
                $claveSucursal !== '' ? '<a class="action-link" href="/mesas/' . $e($m['id']) . '/qr?sucursal=' . $sucursal . '">Imprimir QR</a>' : '',
                $puedeEditar && $m['id_cuenta'] === null && $m['estado'] !== 'reservada'
                    ? pb_accion_post($ruta . '/' . $m['id'] . '/baja', 'Dar de baja', 'fa-close', '¿Dar de baja la mesa?',
                        peligro: true, campos: ['sucursal' => $sucursal], unaVez: true) : '',
            ])) ?>
            <td><?= $e($m['numero']) ?></td><td><?= $e($nombresAreas[$m['id_area']]) ?></td>
            <td><?= $e($m['capacidad']) ?></td>
            <td><?= pb_insignia(match ($m['estado']) {
                'libre' => 'bien', 'bloqueada' => 'error', 'ocupada', 'cuenta_pedida' => 'info', default => 'advertencia',
            }, $estados[$m['estado']] ?? $m['estado']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>

<?php if ($sucursal > 0): ?>
    <?= pb_detalle('verMesa', 'Mesa', $ruta, 'modal-lg', '?sucursal=' . $sucursal) ?>
<?php endif; ?>

<?php if ($puedeEditar && $nombresAreas !== []): ?>
    <?= pb_modal('mesaModal', 'Agregar mesa', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('numero', 'Número de mesa', ['requerido' => true, 'largo' => 20]) ?>
        <?= pb_campo('id_area', 'Área', ['tipo' => 'select', 'opciones' => $nombresAreas, 'requerido' => true, 'nativo' => true]) ?>
        <?= pb_campo('capacidad', 'Capacidad', ['tipo' => 'numero', 'min' => 1, 'max' => 255, 'requerido' => true]) ?>
        <?= pb_campo('forma', 'Forma', ['tipo' => 'select', 'opciones' => PlanoRestaurante::FORMAS, 'requerido' => true, 'nativo' => true]) ?>
        <?= pb_campo('x', 'Posición horizontal (%)', ['tipo' => 'numero', 'min' => 0, 'max' => 100, 'valor' => 50, 'requerido' => true]) ?>
        <?= pb_campo('y', 'Posición vertical (%)', ['tipo' => 'numero', 'min' => 0, 'max' => 100, 'valor' => 50, 'requerido' => true]) ?>
        <?= pb_campo('estado', 'Estado', ['tipo' => 'select', 'opciones' => PlanoRestaurante::ESTADOS, 'requerido' => true, 'nativo' => true]) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>
