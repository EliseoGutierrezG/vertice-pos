<?php
/**
 * La carta impresa de la sucursal, armada con Categorías, Platillos y
 * Promociones. La vista previa es la hoja misma en un marco; `carta-vista.js`
 * pregunta cada pocos segundos si algo cambió y la recarga.
 *
 * @var array<string,string> $textos
 * @var string $huella
 * @var bool $puedeEditar
 */
$ruta = '/carta';
$hoja = '/carta/hoja?' . http_build_query(['sucursal' => $sucursal]);
echo pb_modulo('bi-book', $titulo, 'Se arma sola con las categorías, los platillos y las promociones.',
    $sucursal > 0
        ? pb_boton($hoja . '&imprimir=1', 'Imprimir la carta', 'bi-printer', 'primary',
            ['target' => '_blank', 'rel' => 'noopener', 'data-carta-imprimir' => ''])
            . ($puedeEditar ? pb_verbo('textosCartaModal', 'Textos del pie', 'bi-pencil-square') : '')
        : '');
require __DIR__ . '/filtro.php';
?>
<?php if ($sucursal > 0): ?>
<div class="carta-pantalla" data-carta-vista
     data-hoja="<?= $e($hoja) ?>"
     data-huella-url="<?= $e('/carta/huella?' . http_build_query(['sucursal' => $sucursal])) ?>"
     data-huella="<?= $e($huella) ?>">
    <aside class="carta-opciones" aria-label="Opciones de la carta">
        <?= pb_seccion('bi-sliders', 'Opciones') ?>
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" role="switch" id="carta-promociones" data-carta-opcion="promociones" checked>
                <label class="form-check-label" for="carta-promociones">Incluir promociones</label>
            </div>
            <?= pb_campo('tamano', 'Tamaño de letra', ['tipo' => 'select', 'nativo' => true, 'id' => 'carta-tamano',
                'opciones' => ['normal' => 'Normal', 'compacta' => 'Compacto'], 'valor' => 'normal',
                'extra' => ['data-carta-opcion' => 'tamano']]) ?>
        </section>
        <?= pb_seccion('bi-info-circle', 'Cómo se arma') ?>
            <ul class="carta-ayuda">
                <li>El orden sale de <a href="/categorias-menu?sucursal=<?= $sucursal ?>">Categorías</a> y del campo Orden de cada <a href="/platillos?sucursal=<?= $sucursal ?>">platillo</a>.</li>
                <li>Las preparaciones son los modificadores del platillo.</li>
                <li>Las <a href="/promociones?sucursal=<?= $sucursal ?>">promociones</a> vigentes o programadas salen con su horario.</li>
                <li>Los teléfonos y la dirección vienen de la sucursal.</li>
            </ul>
        </section>
        <p class="carta-estado" data-carta-estado role="status" aria-live="polite">Vista previa al día.</p>
    </aside>
    <div class="carta-previa" data-carta-previa>
        <iframe src="<?= $e($hoja) ?>" title="Vista previa de la carta" data-carta-marco tabindex="-1"></iframe>
    </div>
</div>
<?php endif; ?>
<?= pb_modulo_fin() ?>
<?php if ($sucursal > 0 && $puedeEditar): ?>
    <?= pb_modal('textosCartaModal', 'Textos del pie', $ruta . '/textos', $csrf->campo(), $ruta . '?sucursal=' . $sucursal) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?php foreach (\Servicios\CartaImpresa::TEXTOS as $clave => $nombre): ?>
            <?= pb_campo($clave, $nombre, $clave === 'carta_fundacion'
                ? ['valor' => $textos[$clave], 'largo' => 4, 'modo' => 'numeric', 'patron' => '(19|20)[0-9]{2}', 'marcador' => '2020']
                : ['tipo' => in_array($clave, ['carta_advertencia', 'carta_pagos'], true) ? 'textarea' : 'text', 'valor' => $textos[$clave],
                    'largo' => 255, 'clase' => in_array($clave, ['carta_advertencia', 'carta_pagos'], true) ? 'field-span-2' : '']) ?>
        <?php endforeach; ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>
<?php if ($sucursal > 0): ?>
    <script src="/recursos/carta-vista.js?v=20261118.2" defer></script>
<?php endif; ?>
