<?php
$ruta = '/inventario/' . $tipo;
[$icono, $subtitulo, $modal, $alta, $columnas] = match ($tipo) {
    'insumos' => ['bi-basket','Existencias y unidades de medida.','invInsumo','Agregar insumo',
        ['nombre'=>'Insumo','unidad'=>'Unidad','saldo'=>'Existencia','vencido'=>'Vencido']],
    'lotes' => ['bi-boxes','Caducidad, costo y saldo por lote.','invInicial','Existencia inicial',
        ['id'=>'Lote','nombre'=>'Insumo','saldo'=>'Saldo','vence'=>'Caducidad','costo'=>'Costo']],
    'compras' => ['bi-bag-check','Órdenes y recepciones de insumos.','invCompra','Agregar compra',
        ['referencia'=>'Referencia','proveedor'=>'Proveedor','creada_en'=>'Fecha','estado'=>'Estado']],
    'proveedores' => ['bi-truck','Proveedores de insumos de la sucursal.','invProveedor','Agregar proveedor',
        ['nombre'=>'Proveedor','contacto'=>'Contacto']],
    'recetas' => ['bi-card-checklist','Consumo de insumos por platillo.','invReceta','Agregar insumo a receta',
        ['platillo'=>'Platillo','insumo'=>'Insumo','cantidad'=>'Cantidad']],
    'movimientos' => ['bi-list-check','Entradas, consumos, mermas y conteos.','','',
        ['id_lote'=>'Lote','nombre'=>'Insumo','tipo'=>'Movimiento','cantidad'=>'Cantidad','motivo'=>'Motivo','creado_en'=>'Fecha']],
};
$registros = $$tipo ?? [];
$catalogoEditable = in_array($tipo, ['insumos','proveedores'], true);
$accionesFila = $catalogoEditable || in_array($tipo, ['lotes','compras','recetas'], true);
$tituloMovil = match ($tipo) {
    'compras' => 'referencia', 'recetas' => 'platillo', default => 'nombre',
};
$estados = \Servicios\HistoriasRestaurante::ESTADOS_COMPRA + \Servicios\HistoriasRestaurante::MOVIMIENTOS;
$vende = ($tipo !== 'compras' || (!empty($proveedores) && !empty($insumos)))
    && ($tipo !== 'recetas' || (!empty($platillos) && !empty($insumos)));
$acciones = $sucursal > 0 && $modal !== '' && $vende && ($tipo !== 'lotes' || $insumos !== [])
    ? pb_agregar($modal, $tipo === 'lotes' ? 'Existencia inicial' : 'Agregar', $alta) : '';
if (isset($pagina)) {
    $acciones .= pb_exportar($ruta . '/exportar', $filtros);
} elseif ($catalogoEditable && $sucursal > 0) {
    $acciones .= pb_exportar($ruta . '/exportar', array_filter(['sucursal' => $sucursal, 'buscar' => $buscar ?? '']));
}
echo pb_modulo($icono, $titulo, $subtitulo, $acciones);
require __DIR__ . (isset($pagina) ? '/filtro-historial.php' : '/filtro.php');
?>
<?php if ($sucursal > 0): ?>
    <?php if (!$vende): ?><p>Registre los catálogos necesarios para continuar.</p><?php endif; ?>
    <?= pb_registros($pagina['total'] ?? count($registros)) ?>
    <?= pb_tabla($titulo, isset($pagina) ? 'simple' : '') ?>
    <thead><tr>
        <?php if ($accionesFila): ?><th data-pb-acciones>Acción</th><?php endif; ?>
        <?php foreach ($columnas as $campo => $columna): ?>
            <th<?= $campo === $tituloMovil ? ' data-pb-titulo' : '' ?><?= $campo === 'estado' ? ' data-pb-insignia' : '' ?>><?= $e($columna) ?></th>
        <?php endforeach; ?>
    </tr></thead>
    <tbody>
    <?php if ($registros === []): ?><?= pb_fila_vacia(count($columnas) + ($accionesFila ? 1 : 0), 'Sin registros en esta sucursal') ?><?php endif; ?>
    <?php foreach ($registros as $r): ?>
        <tr>
            <?php if ($tipo === 'lotes'): ?>
                <?= pb_acciones([
                    pb_accion_modal('invMerma', 'actualizar', (int) $r['id'], '/inventario/merma', 'Registrar merma', ['id_lote' => $r['id']], etiqueta: 'Merma'),
                    pb_accion_modal('invConteo', 'actualizar', (int) $r['id'], '/inventario/conteo', 'Registrar conteo', ['id_lote' => $r['id']], etiqueta: 'Conteo'),
                ]) ?>
            <?php elseif ($tipo === 'compras'): ?>
                <?php $pendiente = in_array($r['estado'], ['ordenada', 'parcial'], true); ?>
                <?= pb_acciones([
                    pb_accion_detalle('verCompra', (int) $r['id']),
                    $pendiente ? pb_accion_detalle('invRecibe', (int) $r['id'], 'Recibir', 'fa-check') : '',
                    $pendiente ? pb_accion_modal('invCancela', 'actualizar', (int) $r['id'], '/inventario/cancelar-compra',
                        'Cancelar compra', ['id_compra' => $r['id']], etiqueta: 'Cancelar') : '',
                ]) ?>
            <?php elseif ($tipo === 'recetas'): ?>
                <?php $clave = ['sucursal' => $sucursal, 'id_platillo' => $r['id_platillo'], 'id_insumo' => $r['id_insumo']]; ?>
                <?= pb_acciones([
                    pb_accion_modal('invReceta', 'actualizar', (int) $r['id_insumo'], '/inventario/receta', 'Actualizar cantidad',
                        $clave + ['cantidad' => $r['cantidad']]),
                    pb_accion_post('/inventario/receta', 'Quitar', 'fa-close', '¿Quitar ' . $r['insumo'] . ' de la receta de ' . $r['platillo'] . '?',
                        peligro: true, campos: $clave + ['cantidad' => 0], unaVez: true),
                ]) ?>
            <?php elseif ($catalogoEditable): ?>
                <?php $destino = $ruta . '/' . $r['id']; ?>
                <?= pb_acciones([
                    pb_accion_detalle('verCatalogo', (int) $r['id']),
                    pb_accion_modal($modal, 'actualizar', (int) $r['id'], $destino, 'Actualizar', [], $destino . '?sucursal=' . $sucursal),
                    pb_accion_post($destino . '/baja', 'Dar de baja', 'fa-close', '¿Dar de baja este registro?',
                        peligro: true, campos: ['sucursal' => $sucursal], unaVez: true),
                ]) ?>
            <?php endif; ?>
            <?php foreach ($columnas as $campo => $nombre): ?>
                <?php if ($campo === 'estado'): ?>
                    <td><?= pb_insignia(match ($r['estado']) {
                        'recibida' => 'exito', 'cancelada' => 'error', default => 'advertencia',
                    }, $estados[$r['estado']] ?? $r['estado']) ?></td>
                <?php else: ?>
                    <?php $valor = $r[$campo] ?? null; ?>
                    <td><?= match (true) {
                        $valor === null || $valor === '' => '—',
                        $campo === 'tipo' => $e($estados[$valor] ?? $valor),
                        in_array($campo, ['creada_en', 'creado_en', 'vence'], true) => $e(pb_fecha($valor)),
                        $campo === 'costo' => pb_dinero($valor),
                        default => $e($valor),
                    } ?></td>
                <?php endif; ?>
            <?php endforeach; ?>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
    <?php if (isset($pagina)) require __DIR__ . '/paginacion.php'; ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>

<?php if ($sucursal > 0 && $catalogoEditable): ?>
    <?= pb_detalle('verCatalogo', $tipo === 'insumos' ? 'Insumo' : 'Proveedor', $ruta, 'modal-lg', '?sucursal=' . $sucursal) ?>
<?php endif; ?>

<?php if ($sucursal > 0 && $tipo === 'compras'): ?>
    <?= pb_detalle('verCompra', 'Compra', $ruta, 'modal-xl', '?sucursal=' . $sucursal) ?>
    <?= pb_detalle('invRecibe', 'Recibir compra', $ruta, 'modal-lg', '/recibir?sucursal=' . $sucursal) ?>
    <?= pb_modal('invCancela', 'Cancelar compra', '/inventario/cancelar-compra', $csrf->campo(), '', 'modal-sm', '') ?>
    <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>"><input type="hidden" name="id_compra">
    <p>Lo recibido sigue en inventario.</p>
    <?= pb_modal_fin('Cancelar compra', 'fa-ban') ?>
<?php endif; ?>

<?php if ($sucursal > 0 && $tipo === 'insumos'): ?>
    <?= pb_modal('invInsumo', 'Agregar insumo', '/inventario/insumo', $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('nombre', 'Nombre', ['requerido' => true, 'largo' => 100]) ?>
        <?= pb_campo('unidad', 'Unidad', ['requerido' => true, 'largo' => 20, 'ayuda' => 'Por ejemplo, kg o piezas.']) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>

<?php if ($sucursal > 0 && $tipo === 'proveedores'): ?>
    <?= pb_modal('invProveedor', 'Agregar proveedor', '/inventario/proveedor', $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('nombre', 'Nombre', ['requerido' => true, 'largo' => 100]) ?>
        <?= pb_campo('contacto', 'Contacto', ['largo' => 100]) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>

<?php if ($sucursal > 0 && $tipo === 'recetas' && $vende): ?>
    <?= pb_modal('invReceta', 'Agregar insumo a receta', '/inventario/receta', $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('id_platillo', 'Platillo', ['tipo' => 'select', 'opciones' => array_column($platillos, 'nombre', 'id'), 'nativo' => true, 'requerido' => true]) ?>
        <?= pb_campo('id_insumo', 'Insumo', ['tipo' => 'select', 'opciones' => array_column($insumos, 'nombre', 'id'), 'nativo' => true, 'requerido' => true]) ?>
        <?= pb_campo('cantidad', 'Cantidad por porción', ['tipo' => 'numero', 'min' => 0, 'step' => '.001', 'requerido' => true,
            'ayuda' => 'Use cero para quitar el insumo.']) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>

<?php if ($sucursal > 0 && $tipo === 'compras' && $vende): ?>
    <?= pb_modal('invCompra', 'Agregar compra', '/inventario/compra', $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('id_proveedor', 'Proveedor', ['tipo' => 'select', 'opciones' => array_column($proveedores, 'nombre', 'id'), 'nativo' => true, 'requerido' => true]) ?>
        <?= pb_campo('referencia', 'Referencia', ['largo' => 80, 'requerido' => true]) ?>
    </div>
    <div class="d-grid gap-2 mt-3" data-compra-lineas></div>
    <button type="button" class="btn btn-outline-primary mt-3" data-compra-agrega>Agregar renglón</button>
    <template data-compra-linea>
        <fieldset class="border rounded p-3 min-w-0">
            <legend class="h6" data-compra-leyenda>Renglón</legend>
            <div class="form-grid">
                <?= pb_campo('id_insumo', 'Insumo', ['tipo' => 'select', 'opciones' => array_column($insumos, 'nombre', 'id'),
                    'nativo' => true, 'requerido' => true, 'vacia' => 'Seleccione']) ?>
                <?= pb_campo('cantidad', 'Cantidad', ['tipo' => 'numero', 'min' => '.001', 'step' => '.001', 'requerido' => true]) ?>
                <?= pb_campo('costo', 'Costo unitario', ['tipo' => 'numero', 'min' => 0, 'step' => '.01', 'requerido' => true]) ?>
                <?= pb_campo('vence', 'Caducidad', ['tipo' => 'fecha']) ?>
            </div>
            <button type="button" class="btn btn-outline-secondary btn-sm mt-2" data-compra-quita>Quitar renglón</button>
        </fieldset>
    </template>
    <?= pb_modal_fin() ?>
    <script src="/recursos/compra-captura.js" defer></script>
<?php endif; ?>

<?php if ($sucursal > 0 && $tipo === 'lotes'): ?>
    <?php if ($insumos !== []): ?>
        <?= pb_modal('invInicial', 'Existencia inicial', '/inventario/existencia-inicial', $csrf->campo()) ?>
        <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>">
        <div class="form-grid">
            <?= pb_campo('id_insumo', 'Insumo', ['tipo' => 'select', 'opciones' => array_column($insumos, 'nombre', 'id'),
                'nativo' => true, 'requerido' => true, 'vacia' => 'Seleccione']) ?>
            <?= pb_campo('cantidad', 'Cantidad', ['tipo' => 'numero', 'min' => '.001', 'step' => '.001', 'requerido' => true]) ?>
            <?= pb_campo('costo', 'Costo unitario', ['tipo' => 'numero', 'min' => 0, 'step' => '.01', 'requerido' => true]) ?>
            <?= pb_campo('vence', 'Caducidad', ['tipo' => 'fecha']) ?>
        </div>
        <?= pb_modal_fin('Registrar entrada') ?>
    <?php endif; ?>
    <?php foreach (['merma' => 'Registrar merma', 'conteo' => 'Registrar conteo'] as $operacion => $encabezado): ?>
        <?= pb_modal('inv' . ucfirst($operacion), $encabezado, '/inventario/' . $operacion, $csrf->campo()) ?>
        <input type="hidden" name="sucursal" value="<?= $sucursal ?>"><input type="hidden" name="id_lote">
        <div class="form-grid">
            <?= pb_campo('cantidad', $operacion === 'merma' ? 'Cantidad que se retira' : 'Existencia contada',
                ['tipo' => 'numero', 'min' => $operacion === 'merma' ? '.001' : '0', 'step' => '.001', 'requerido' => true]) ?>
            <?= pb_campo('motivo', 'Motivo', ['largo' => 160, 'requerido' => true]) ?>
        </div>
        <?= pb_modal_fin() ?>
    <?php endforeach; ?>
<?php endif; ?>
