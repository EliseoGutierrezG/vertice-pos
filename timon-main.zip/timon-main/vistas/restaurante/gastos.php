<?php
$ruta = '/gastos';
$tipo = 'gastos';
$puedeCaja = $identidad->puede('comanda_cobra');
$volver = $ruta . (isset($pagina) ? '?' . http_build_query($filtros + ['pagina' => $pagina['pagina'], 'por_pagina' => $pagina['tamano']]) : '');
echo pb_modulo('bi-receipt-cutoff', $titulo, 'Gastos y salidas de caja de la sucursal.',
    isset($pagina) ? pb_agregar('gastoModal', 'Agregar', 'Agregar gasto') . pb_exportar('/gastos.xlsx', $filtros) : '');
require __DIR__ . (isset($pagina) ? '/filtro-historial.php' : '/filtro.php');
?>
<?php if ($sucursal > 0): ?>
    <?= pb_registros($pagina['total']) ?>
    <?= pb_tabla('Gastos', 'simple') ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Concepto</th><th>Proveedor</th><th>Importe</th><th>Comprobante</th>
        <th>Pagado en caja</th><th>Fecha</th><th data-pb-insignia>Estado</th></tr></thead>
    <tbody>
    <?php if ($gastos === []): ?><?= pb_fila_vacia(8, 'Sin gastos registrados') ?><?php endif; ?>
    <?php foreach ($gastos as $g): ?>
        <?php $vigente = $g['cancelado_en'] === null;
        $modifica = $vigente && ($g['id_asiento'] === null || $puedeCaja);
        $destino = $ruta . '/' . $g['id'];
        $detalle = $destino . '?sucursal=' . $sucursal; ?>
        <tr>
            <?= pb_acciones([
                pb_accion_detalle('verGasto', (int) $g['id']),
                $modifica ? pb_accion_modal('gastoModal', 'actualizar', (int) $g['id'], $destino, 'Actualizar gasto', [], $detalle) : '',
                $modifica ? pb_accion_modal('cancelaGasto', 'actualizar', (int) $g['id'], $destino . '/cancelar',
                    'Cancelar gasto', [], $detalle, 'Cancelar') : '',
            ]) ?>
            <td><?= $e($g['concepto']) ?></td><td><?= $e($g['proveedor'] ?? 'Sin proveedor') ?></td><td><?= $e(pb_dinero($g['importe'])) ?></td>
            <td><?= $e($g['comprobante']) ?></td><td><?= $g['id_asiento'] === null ? 'No' : 'Sí' ?></td><td><?= $e(pb_fecha($g['creado_en'])) ?></td>
            <td><?= pb_insignia($vigente ? 'bien' : 'mudo', $vigente ? 'Vigente' : 'Cancelado') ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
    <?php require __DIR__ . '/paginacion.php'; ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>

<?php if ($sucursal > 0): ?>
    <?= pb_detalle('verGasto', 'Gasto', $ruta, 'modal-lg', '?sucursal=' . $sucursal) ?>
    <?= pb_modal('gastoModal', 'Agregar gasto', $ruta, $csrf->campo(), $volver) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <input type="hidden" name="version">
    <div class="form-grid">
        <?= pb_campo('concepto', 'Concepto', ['largo' => 120, 'requerido' => true]) ?>
        <?= pb_campo('importe', 'Importe', ['tipo' => 'numero', 'min' => '.01', 'step' => '.01', 'requerido' => true]) ?>
        <?= pb_campo('id_proveedor', 'Proveedor', ['tipo' => 'select', 'opciones' => array_column($proveedores, 'nombre', 'id'),
            'vacia' => 'Sin proveedor', 'nativo' => true]) ?>
        <?= pb_campo('comprobante', 'Referencia del comprobante', ['largo' => 200]) ?>
        <?php if ($puedeCaja): ?>
            <?= pb_campo('caja', 'Pagar desde caja', ['tipo' => 'select', 'opciones' => [0 => 'No', 1 => 'Sí'], 'nativo' => true, 'requerido' => true]) ?>
        <?php endif; ?>
    </div>
    <?= pb_modal_fin() ?>
    <?= pb_modal('cancelaGasto', 'Cancelar gasto', $ruta, $csrf->campo(), $volver, 'modal-sm', '') ?>
    <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>"><input type="hidden" name="version">
    <?= pb_campo('motivo', 'Motivo', ['largo' => 160, 'requerido' => true]) ?>
    <?= pb_modal_fin('Cancelar gasto', 'fa-ban') ?>
<?php endif; ?>
