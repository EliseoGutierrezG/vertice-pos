<?php
/**
 * La carta impresa: portada y hoja de platillos con el diseño de la carta del
 * restaurante. Se arma con `CartaImpresa::arma()`; nada de lo que dice está
 * escrito aquí salvo los títulos de las secciones fijas.
 *
 * Es una página suelta: la pantalla Carta la muestra en un marco y «Imprimir
 * o guardar PDF» la abre con `imprimir=1`.
 *
 * @var callable $e
 * @var array $carta
 * @var bool $compacta
 * @var bool $imprimir
 */
$textos = $carta['textos'];
$s = $carta['sucursal'];
$marca = pb_marca_texto($marcaVisual ?? null, 'nombre_corto');
$mayuscula = static fn (string $t): string => mb_strtoupper(mb_substr($t, 0, 1)) . mb_substr($t, 1);
$sello = preg_split('/\s+/u', trim($textos['carta_sello']), 2) ?: [];
$telefono = static function (?string $numero): string {
    $d = preg_replace('/\D/', '', (string) $numero);
    if (strlen($d) === 12 && str_starts_with($d, '52')) {
        $d = substr($d, 2);
    }
    return strlen($d) === 10 ? substr($d, 0, 3) . ' ' . substr($d, 3, 3) . ' ' . substr($d, 6) : $d;
};
$pesos = static fn (string $precio): string => '$' . (str_ends_with($precio, '.00') ? substr($precio, 0, -3) : $precio);
$iconos = ['Facebook' => 'bi-facebook', 'Instagram' => 'bi-instagram', 'TikTok' => 'bi-tiktok'];
$whatsapp = $telefono($s['whatsapp_publico'] ?? '');
$fijo = $telefono($s['telefono'] ?? '');
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Carta · <?= $e($s['nombre']) ?></title>
<link rel="icon" href="/recursos/isotipo.svg?v=20261114.2" type="image/svg+xml">
<link rel="stylesheet" href="/recursos/vendor/bootstrap-icons/bootstrap-icons.css">
<link rel="stylesheet" href="/recursos/carta/carta.css?v=20261118.1">
</head>
<body class="carta<?= $compacta ? ' carta--compacta' : '' ?>"<?= $imprimir ? ' data-imprimir' : '' ?>>

<section class="hoja hoja-portada" aria-label="Portada">
  <h1 class="visualmente-oculto"><?= $marca ?>. Restaurante. Menú</h1>
</section>

<section class="hoja hoja-menu" aria-label="Menú">
  <img class="adorno adorno-brujula" src="/recursos/carta/brujula.webp" alt="">
  <header class="menu-encabezado">
    <div class="menu-marca">
      <p class="menu-nombre"><?= $marca ?>.</p>
      <p class="menu-giro">Restaurante</p>
      <?php if ($textos['carta_fundacion'] !== ''): ?><p class="menu-fundacion">Est. <?= $e($textos['carta_fundacion']) ?></p><?php endif; ?>
    </div>
    <?php if ($sello !== []): ?>
    <div class="menu-sello">
      <p><span><?= $e($mayuscula($sello[0])) ?></span><?php if (isset($sello[1])): ?><span><?= $e($mayuscula($sello[1])) ?></span><?php endif; ?></p>
      <small><?= $marca ?></small>
    </div>
    <?php endif; ?>
  </header>

  <div class="menu-columnas">
    <?php if ($carta['categorias'] === []): ?>
      <p class="menu-vacio">Aún no hay platillos con precio en esta sucursal.</p>
    <?php endif; ?>
    <?php foreach ($carta['categorias'] as $c): ?>
    <section class="categoria">
      <h2><?= $e($c['nombre']) ?></h2>
      <?php if ($c['leyenda'] !== ''): ?><p class="leyenda"><?= $e($c['leyenda']) ?></p><?php endif; ?>
      <ul>
        <?php foreach ($c['platillos'] as $pl): $promo = $pl['promocion']; ?>
        <li class="platillo<?= $promo ? ' platillo--promocion' : '' ?>">
          <span class="platillo-nombre"><?= $e($pl['nombre']) ?><?php if ($pl['porcion'] !== ''): ?> <span class="porcion">(<?= $e($pl['porcion']) ?>)</span><?php endif; ?><?php if ($pl['especialidad']): ?> <span class="estrella" title="Especialidad de la casa">★</span><?php endif; ?></span>
          <span class="platillo-precio">
            <?php if ($promo && $promo['precio_promocion'] !== null): ?>
              <s><?= $e($pesos($pl['precio'])) ?></s> <?= $e($pesos($promo['precio_promocion'])) ?>
            <?php else: ?>
              <?= $e($pesos($pl['precio'])) ?>
            <?php endif; ?>
          </span>
          <?php if ($promo): ?><span class="platillo-promo"><?= $e($promo['etiqueta']) ?> · <?= $e($promo['horario']) ?></span><?php endif; ?>
          <?php if ($pl['preparaciones'] !== ''): ?><span class="preparaciones"><?= $e($pl['preparaciones']) ?></span><?php endif; ?>
        </li>
        <?php endforeach; ?>
      </ul>
    </section>
    <?php endforeach; ?>

    <?php if ($carta['promociones'] !== []): ?>
    <section class="categoria promociones">
      <h2>Promociones</h2>
      <ul>
        <?php foreach ($carta['promociones'] as $p): ?>
        <li>
          <span class="promo-etiqueta"><?= $e($p['etiqueta']) ?></span>
          <span class="promo-nombre"><?= $e($p['nombre']) ?></span>
          <span class="promo-detalle"><?= $e($p['horario']) ?><?php if ($p['hasta']): ?>, hasta el <?= $e(pb_fecha($p['hasta'])) ?><?php endif; ?>.
            <?= $e(implode(', ', $p['platillos'])) ?>.</span>
        </li>
        <?php endforeach; ?>
      </ul>
    </section>
    <?php endif; ?>
  </div>

  <footer class="menu-pie">
    <div class="pie-contacto">
      <?php foreach ($carta['redes'] as $r): ?>
        <p><i class="bi <?= $e($iconos[$r['nombre']] ?? 'bi-link-45deg') ?>" aria-hidden="true"></i><span class="visualmente-oculto"><?= $e($r['nombre']) ?>:</span> <?= $e($r['usuario'] ?: $r['url']) ?></p>
      <?php endforeach; ?>
      <?php if ($whatsapp !== '' || $fijo !== ''): ?>
      <p class="pie-telefonos">
        <?php if ($whatsapp !== ''): ?><span><i class="bi bi-whatsapp" aria-hidden="true"></i><span class="visualmente-oculto">WhatsApp:</span> <?= $e($whatsapp) ?></span><?php endif; ?>
        <?php if ($fijo !== '' && $fijo !== $whatsapp): ?><span><i class="bi bi-telephone-fill" aria-hidden="true"></i><span class="visualmente-oculto">Teléfono:</span> <?= $e($fijo) ?></span><?php endif; ?>
      </p>
      <?php endif; ?>
      <?php if ($carta['direccion'] !== ''): ?><p class="pie-direccion"><i class="bi bi-geo-alt-fill" aria-hidden="true"></i> <?= $e($carta['direccion']) ?></p><?php endif; ?>
    </div>
    <div class="pie-lema">
      <img src="/recursos/carta/timon.webp" alt="">
      <?php if ($textos['carta_lema'] !== ''): ?><p><?= $e($textos['carta_lema']) ?></p><?php endif; ?>
    </div>
    <div class="pie-avisos">
      <?php if ($textos['carta_advertencia'] !== ''): ?><p><?= $e($textos['carta_advertencia']) ?></p><?php endif; ?>
      <?php if ($textos['carta_pagos'] !== ''): ?><p><?= $e($textos['carta_pagos']) ?></p><?php endif; ?>
    </div>
  </footer>
  <img class="adorno adorno-plato" src="/recursos/carta/plato.webp" alt="">
  <img class="adorno adorno-camaron" src="/recursos/carta/camaron.webp" alt="">
  <img class="adorno adorno-pulpo" src="/recursos/carta/pulpo.webp" alt="">
</section>

<script src="/recursos/carta/carta.js?v=20261118.1"></script>
</body>
</html>
