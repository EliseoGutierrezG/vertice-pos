<?php
use Servicios\MenuRestaurante;
$ruta = '/impresoras';
$destinos = MenuRestaurante::AREAS + ['caja' => 'Caja'];
echo pb_modulo('bi-printer', $titulo, 'Impresoras térmicas y áreas que atienden.',
    $sucursal > 0 ? pb_agregar('impresoraModal', 'Agregar', 'Agregar impresora') : '');
require __DIR__ . '/filtro.php';
?>
<?php if ($sucursal > 0): ?>
    <?= pb_registros(count($impresoras)) ?>
    <?= pb_tabla('Impresoras') ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Equipo</th><th>Área</th><th>Red</th><th>Rollo</th><th data-pb-insignia>Estado</th></tr></thead>
    <tbody>
    <?php if ($impresoras === []): ?><?= pb_fila_vacia(6, 'Aún no hay impresoras configuradas') ?><?php endif; ?>
    <?php foreach ($impresoras as $i): ?>
        <tr>
            <?= pb_acciones([
                pb_accion_detalle('verImpresora', (int) $i['id']),
                pb_accion_modal('impresoraModal', 'actualizar', (int) $i['id'], $ruta . '/' . $i['id'],
                    'Actualizar impresora', [], $ruta . '/' . $i['id'] . '?sucursal=' . $sucursal),
            ]) ?>
            <td><?= $e($i['nombre']) ?></td><td><?= $e($destinos[$i['destino']]) ?></td><td><?= $e($i['ip']) ?>:<?= $e($i['puerto']) ?></td>
            <td><?= $e($i['ancho']) ?> mm</td><td><?= pb_estatus((int) $i['activa'] === 1, 'Activa', 'Inactiva') ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>

<?php if ($sucursal > 0): ?>
    <?= pb_detalle('verImpresora', 'Impresora', $ruta, 'modal-lg', '?sucursal=' . $sucursal) ?>
    <?= pb_modal('impresoraModal', 'Agregar impresora', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('nombre', 'Nombre', ['largo' => 80, 'requerido' => true]) ?>
        <?= pb_campo('destino', 'Área', ['tipo' => 'select', 'nativo' => true, 'opciones' => $destinos, 'requerido' => true,
            'ayuda' => 'El área se define al agregar.', 'extra' => ['data-pb-solo-alta' => '']]) ?>
        <?= pb_campo('ip', 'Dirección IP privada', ['largo' => 15, 'requerido' => true]) ?>
        <?= pb_campo('puerto', 'Puerto', ['tipo' => 'numero', 'valor' => 9100, 'min' => 1, 'max' => 65535, 'requerido' => true]) ?>
        <?= pb_campo('ancho', 'Rollo', ['tipo' => 'select', 'opciones' => [80 => '80 mm', 58 => '58 mm'], 'nativo' => true, 'requerido' => true]) ?>
        <?= pb_campo('activa', 'Estado', ['tipo' => 'select', 'opciones' => [1 => 'Activa', 0 => 'Inactiva'], 'nativo' => true, 'requerido' => true]) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>
