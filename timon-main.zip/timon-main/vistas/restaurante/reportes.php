<?php
use Servicios\ReportesRestaurante;
$ruta = '/reportes';
$filtros = $sucursal > 0 ? compact('sucursal', 'tipo', 'desde', 'hasta') : [];
$consulta = '?' . http_build_query($filtros, encoding_type: PHP_QUERY_RFC3986);
$acciones = $sucursal > 0 ? pb_boton($ruta . '/exportar/csv' . $consulta, 'CSV', 'bi-download', 'outline-primary')
    . pb_boton($ruta . '/exportar/pdf' . $consulta, 'PDF', 'bi-file-earmark-pdf', 'outline-primary')
    . pb_exportar($ruta . '/exportar/xlsx', $filtros) : '';
echo pb_modulo('bi-bar-chart', $titulo, 'Ventas, cocina e inventario por sucursal.', $acciones);
?>
<?php if ($sucursal > 0): ?>
    <?= pb_filtros($ruta) ?>
    <?= pb_rango($desde, $hasta) ?>
    <?= pb_campo('sucursal', 'Sucursal', ['tipo' => 'select', 'opciones' => $opciones, 'valor' => $sucursal, 'nativo' => true]) ?>
    <?= pb_campo('tipo', 'Reporte', ['tipo' => 'select', 'opciones' => ReportesRestaurante::TIPOS, 'valor' => $tipo, 'nativo' => true]) ?>
    <?= pb_filtros_fin($ruta) ?>
    <?= pb_registros(count($tabla->filas)) ?>
    <?= pb_tabla($tabla->titulo) ?>
    <thead><tr><?php foreach ($tabla->encabezados as $n => $nombre): ?><th<?= $n === 0 ? ' data-pb-titulo' : '' ?>><?= $e($nombre) ?></th><?php endforeach; ?></tr></thead>
    <tbody>
    <?php if ($tabla->filas === []): ?><?= pb_fila_vacia(count($tabla->encabezados), 'Sin datos en este periodo') ?><?php endif; ?>
    <?php foreach ($tabla->filas as $fila): ?>
        <tr><?php foreach ($fila as $celda): ?><td><?= $e($celda) ?></td><?php endforeach; ?></tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php else: ?>
    <?= pb_vacio('Aún no hay sucursales disponibles', '', 'bi-building') ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>
