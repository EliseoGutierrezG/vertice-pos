<?php
use Servicios\Reservaciones;

$ruta = '/reservaciones';
$volver = $ruta . '?' . http_build_query(['sucursal' => $sucursal, 'desde' => $desde, 'hasta' => $hasta, 'estado' => $estadoFiltro]);
echo pb_modulo('bi-calendar2-check', $titulo, 'Agenda y asignación de mesas por sucursal.',
    $sucursal > 0 ? pb_agregar('reservaManual', 'Agregar', 'Reservación por teléfono') : '');
?>
<?php if ($sucursal > 0): ?>
    <?= pb_filtros($ruta) ?>
    <?= pb_rango($desde, $hasta) ?>
    <?= pb_campo('sucursal', 'Sucursal', ['tipo' => 'select', 'opciones' => $opciones, 'valor' => $sucursal, 'nativo' => true]) ?>
    <?= pb_campo('estado', 'Estado', ['tipo' => 'select', 'opciones' => Reservaciones::ESTADOS, 'valor' => $estadoFiltro, 'vacia' => 'Todos', 'nativo' => true]) ?>
    <?= pb_filtros_fin($ruta) ?>
    <?= pb_registros(count($reservaciones)) ?>
    <?php if (count($reservaciones) === 200): ?>
        <?= pb_aviso('info', 'Acote el periodo. Se muestran hasta 200 reservaciones.') ?>
    <?php endif; ?>
    <?= pb_tabla('Reservaciones') ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Cliente</th><th>Folio</th><th>Teléfono</th><th>Fecha</th><th>Personas</th><th>Mesa</th><th data-pb-insignia>Estado</th></tr></thead>
    <tbody>
    <?php if ($reservaciones === []): ?><?= pb_fila_vacia(8, 'Sin reservaciones en la agenda') ?><?php endif; ?>
    <?php foreach ($reservaciones as $r): ?>
        <tr>
            <?= pb_acciones([
                pb_accion_detalle('verReserva', (int) $r['id']),
                in_array($r['estado'], ['solicitada','confirmada'], true) && $mesas !== []
                    ? pb_accion_modal('reservaMesa', 'actualizar', (int) $r['id'], $ruta . '/' . $r['id'], 'Confirmar mesa',
                        [], $ruta . '/' . $r['id'] . '?sucursal=' . $sucursal, 'Asignar mesa') : '',
                $r['estado'] === 'confirmada' ? pb_accion_modal('reservaAtiende', 'actualizar', (int) $r['id'],
                    $ruta . '/' . $r['id'], 'Marcar atendida', [], etiqueta: 'Marcar atendida') : '',
                $r['estado'] === 'confirmada' && $r['desde'] <= date('Y-m-d H:i:s')
                    ? pb_accion_modal('reservaAusente', 'actualizar', (int) $r['id'],
                        $ruta . '/' . $r['id'], 'No se presentó', [], etiqueta: 'No se presentó') : '',
                in_array($r['estado'], ['solicitada','confirmada'], true) ? pb_accion_modal('reservaCancela', 'actualizar',
                    (int) $r['id'], $ruta . '/' . $r['id'], 'Cancelar reservación', [], etiqueta: 'Cancelar') : '',
            ]) ?>
            <td><?= $e($r['cliente']) ?></td><td><?= $e($r['folio'] ?? '—') ?></td><td><?= $e($r['telefono']) ?></td><td><?= $e(pb_fecha($r['desde'])) ?></td>
            <td><?= $e($r['personas']) ?></td><td><?= $e($r['mesa'] ?? 'Sin asignar') ?></td>
            <td><?= pb_insignia(match ($r['estado']) {
                'solicitada' => 'advertencia', 'confirmada' => 'info', 'atendida' => 'bien', 'ausente' => 'error', default => 'mudo',
            }, Reservaciones::ESTADOS[$r['estado']]) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php else: ?>
    <?= pb_vacio('Aún no hay sucursales disponibles', 'Agregue una sucursal desde el panel.', 'bi-building') ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>

<?php if ($sucursal > 0): ?>
    <?= pb_detalle('verReserva', 'Reservación', $ruta, 'modal-lg', '?sucursal=' . $sucursal) ?>
    <?= pb_modal('reservaManual', 'Reservación por teléfono', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('cliente', 'Nombre', ['largo' => 100, 'requerido' => true]) ?>
        <?= pb_campo('telefono', 'Teléfono', ['tipo' => 'tel', 'largo' => 25, 'requerido' => true]) ?>
        <?= pb_campo('desde', 'Fecha y hora', ['tipo' => 'datetime-local', 'min' => date('Y-m-d\TH:i'), 'requerido' => true]) ?>
        <?= pb_campo('personas', 'Personas', ['tipo' => 'numero', 'min' => 1, 'max' => 255, 'requerido' => true]) ?>
        <?= pb_campo('nota', 'Nota', ['tipo' => 'textarea', 'largo' => 240, 'clase' => 'field-span-2']) ?>
    </div>
    <?= pb_modal_fin('Registrar') ?>

    <?= pb_modal('reservaMesa', 'Confirmar mesa', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>"><input type="hidden" name="estado" value="confirmada">
    <input type="hidden" name="volver" value="<?= $e($volver) ?>">
    <?= pb_campo('id_mesa', 'Mesa', ['tipo' => 'select', 'nativo' => true, 'requerido' => true,
        'opciones' => array_column($mesas, 'numero', 'id')]) ?>
    <?= pb_modal_fin('Confirmar', 'fa-check') ?>

    <?= pb_modal('reservaAusente', 'No se presentó', $ruta, $csrf->campo(), '', 'modal-sm', '') ?>
    <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>"><input type="hidden" name="estado" value="ausente">
    <input type="hidden" name="volver" value="<?= $e($volver) ?>">
    <p>Confirme que la persona no llegó.</p>
    <?= pb_modal_fin('Confirmar', 'fa-check') ?>

    <?= pb_modal('reservaAtiende', 'Marcar atendida', $ruta, $csrf->campo(), '', 'modal-sm', '') ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>"><input type="hidden" name="estado" value="atendida">
    <input type="hidden" name="volver" value="<?= $e($volver) ?>">
    <p>Confirme la llegada para que el mesero pueda abrir la mesa.</p>
    <?= pb_modal_fin('Confirmar', 'fa-check') ?>

    <?= pb_modal('reservaCancela', 'Cancelar reservación', $ruta, $csrf->campo(), '', 'modal-sm', '') ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>"><input type="hidden" name="estado" value="cancelada">
    <input type="hidden" name="volver" value="<?= $e($volver) ?>">
    <p>Confirme la cancelación de esta reservación.</p>
    <?= pb_modal_fin('Cancelar reservación', 'fa-ban') ?>
<?php endif; ?>
