<?php
use Servicios\EquiposRestaurante;

$ruta = '/equipos-comanda';
echo pb_modulo('bi-pc-display', $titulo, 'Equipos vinculados a la sucursal y su modo de operación.',
    $sucursal > 0 ? pb_agregar('equipoAutoriza', 'Autorizar equipo', 'Autorizar equipo') : '');
require __DIR__ . '/filtro.php';
?>
<?php if ($sucursal > 0): ?>
    <?= pb_registros(count($equipos) + count($pendientes)) ?>
    <?= pb_tabla('Equipos de comanda') ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Equipo</th><th>Modo</th><th>Plataforma</th><th data-pb-insignia>Estado</th></tr></thead>
    <tbody>
    <?php if ($equipos === [] && $pendientes === []): ?><?= pb_fila_vacia(5, 'Aún no hay equipos asignados') ?><?php endif; ?>
    <?php foreach ($pendientes as $equipo): ?>
        <tr>
            <?= pb_acciones([pb_accion_modal('equipoPendiente', 'actualizar', (int) $equipo['id'], $ruta . '/' . $equipo['id'] . '/autorizar',
                'Autorizar equipo', [], etiqueta: 'Autorizar')]) ?>
            <td><?= $e($equipo['nombre']) ?></td><td>Sin asignar</td><td><?= $e($equipo['plataforma']) ?></td>
            <td><?= pb_insignia('advertencia', 'Pendiente') ?></td>
        </tr>
    <?php endforeach; ?>
    <?php foreach ($equipos as $equipo): ?>
        <tr>
            <?= pb_acciones((int) $equipo['autorizado'] ? [
                pb_accion_modal('editaEquipo', 'actualizar', (int) $equipo['id'], $ruta . '/' . $equipo['id'], 'Actualizar equipo', $equipo),
                pb_accion_modal('equipoRetira', 'retirar', (int) $equipo['id'], $ruta . '/' . $equipo['id'] . '/retirar',
                    'Retirar equipo', [], etiqueta: 'Retirar'),
            ] : []) ?>
            <td><?= $e($equipo['nombre']) ?></td><td><?= $e(EquiposRestaurante::TIPOS[$equipo['tipo']]) ?></td>
            <td><?= $e($equipo['plataforma']) ?></td><td><?= pb_estatus((int) $equipo['autorizado'] === 1, 'Autorizado', 'Retirado') ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>

<?php if ($sucursal > 0): ?>
    <?= pb_modal('equipoAutoriza', 'Autorizar equipo', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('codigo', 'Código del equipo', ['patron' => '[0-9a-fA-F]{10}', 'largo' => 10, 'requerido' => true]) ?>
        <?= pb_campo('tipo', 'Modo', ['tipo' => 'select', 'opciones' => EquiposRestaurante::TIPOS, 'nativo' => true, 'requerido' => true]) ?>
    </div>
    <?= pb_modal_fin('Autorizar', 'fa-check') ?>

    <?= pb_modal('equipoPendiente', 'Autorizar equipo', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>">
    <?= pb_campo('tipo', 'Modo', ['tipo' => 'select', 'opciones' => EquiposRestaurante::TIPOS, 'nativo' => true, 'requerido' => true]) ?>
    <?= pb_modal_fin('Autorizar', 'fa-check') ?>

    <?= pb_modal('editaEquipo', 'Actualizar equipo', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>">
    <?= pb_campo('nombre', 'Nombre', ['largo' => 80, 'requerido' => true]) ?>
    <?= pb_campo('tipo', 'Modo', ['tipo' => 'select', 'opciones' => EquiposRestaurante::TIPOS, 'nativo' => true, 'requerido' => true]) ?>
    <?= pb_modal_fin() ?>

    <?= pb_modal('equipoRetira', 'Retirar equipo', $ruta, $csrf->campo(), '', 'modal-sm', '') ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <p>El equipo perderá el acceso a la comanda de esta sucursal.</p>
    <?= pb_modal_fin('Retirar', 'fa-ban') ?>
<?php endif; ?>
