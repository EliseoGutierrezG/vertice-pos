<?php
use Servicios\PlanoRestaurante;

$ruta = '/mesas/plano';
$puedeEditar = $sucursal > 0 && $identidad->puede('plano_admin');
$nombresAreas = array_column($areas ?? [], 'nombre', 'id');
$estados = PlanoRestaurante::ESTADOS + ['ocupada' => 'Ocupada', 'cuenta_pedida' => 'Cuenta pedida', 'reservada' => 'Reservada'];
echo pb_modulo('bi-diagram-3', $titulo, 'Ubicación de las mesas por área de la sucursal.');
require __DIR__ . '/filtro.php';
?>
<?php if ($sucursal > 0): ?>
    <?php if ($mesas !== []): ?>
        <?= pb_seccion('bi-map', 'Plano del salón', $puedeEditar ? 'Arrastre la mesa o muévala con las flechas.' : '') ?>
        <div role="status" data-plano-estado></div>
        <?php foreach ($nombresAreas as $area => $nombre): ?>
            <figure class="plano-figura">
                <figcaption><?= $e($nombre) ?></figcaption>
                <div class="plano-editor" data-sucursal="<?= $sucursal ?>" data-marca="<?= $e($csrf->marca()) ?>">
                <?php foreach ($mesas as $m): if ($m['id_area'] !== $area) continue; ?>
                    <button type="button" class="plano-mesa <?= $e($m['forma']) ?>" data-mesa="<?= (int) $m['id'] ?>"
                        data-x="<?= (int) $m['x'] ?>" data-y="<?= (int) $m['y'] ?>" <?= $puedeEditar ? '' : 'disabled' ?>
                        aria-label="Mesa <?= $e($m['numero']) ?>, <?= $e($estados[$m['estado']]) ?>">
                        <strong><?= $e($m['numero']) ?></strong><small><?= $e($estados[$m['estado']]) ?></small>
                    </button>
                <?php endforeach; ?>
                </div>
            </figure>
        <?php endforeach; ?>
        </section>
        <script src="/recursos/plano-editor.js" defer></script>
    <?php else: ?>
        <?= pb_aviso('info', 'Agregue mesas para ver su ubicación en el plano.') ?>
    <?php endif; ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>
