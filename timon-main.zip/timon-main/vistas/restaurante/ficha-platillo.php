<?php
use Servicios\MenuRestaurante;

$campos = ['Categoría' => $platillo['categoria'], 'Porción' => $platillo['porcion'] ?: 'Sin porción',
    'Orden en la carta' => $platillo['orden'], 'Preparación' => MenuRestaurante::AREAS[$platillo['preparacion']],
    'Descripción' => $platillo['descripcion'] ?: 'Sin descripción',
    'Especialidad de la casa' => (int) $platillo['especialidad'] === 1 ? 'Sí' : 'No',
    'Precio' => $platillo['precio'] === null ? 'Sin precio' : pb_dinero($platillo['precio']),
    'Promoción ahora' => empty($platillo['promocion']) ? 'Ninguna'
        : $platillo['promocion']['etiqueta'] . ' · ' . $platillo['promocion']['nombre']];
require __DIR__ . '/ficha.php';
$admin = $identidad->puede('menu_admin');
?>
<?php if (!empty($platillo['foto'])): ?>
    <img class="img-fluid rounded" width="320" src="<?= $e($platillo['foto']) ?>" alt="<?= $e($platillo['nombre']) ?>">
<?php endif; ?>
<?= pb_seccion('bi-list-check', 'Modificadores') ?>
    <?php if ($admin): ?>
        <?= pb_accion_modal('modificadorModal', 'modificador', (int) $platillo['id'], '/modificadores', 'Agregar modificador',
            ['id_platillo' => $platillo['id']], etiqueta: 'Agregar modificador') ?>
    <?php endif; ?>
    <?= pb_tabla('Modificadores', 'simple') ?>
    <thead><tr><?php if ($admin): ?><th data-pb-acciones>Acción</th><?php endif; ?>
        <th data-pb-titulo>Nombre</th><th>Suplemento</th><th data-pb-insignia>Estado</th></tr></thead>
    <tbody>
    <?php if ($platillo['modificadores'] === []): ?><?= pb_fila_vacia($admin ? 4 : 3, 'Sin modificadores') ?><?php endif; ?>
    <?php foreach ($platillo['modificadores'] as $m): ?>
        <tr>
            <?php if ($admin): ?>
                <?= pb_acciones([pb_accion_modal('modificadorModal', 'modificador', (int) $m['id'], '/modificadores/' . $m['id'],
                    'Actualizar modificador', $m)]) ?>
            <?php endif; ?>
            <td><?= $e($m['nombre']) ?></td>
            <td><?= $e(pb_dinero($m['suplemento'])) ?></td>
            <td><?= pb_estatus((int) $m['activo'] === 1, 'Activo', 'Inactivo') ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
</section>
