<?php
$filtros = compact('sucursal', 'desde', 'hasta');
echo pb_modulo('bi-cash-stack', $titulo, 'Aperturas y cortes de caja por sucursal.',
    $sucursal > 0 ? pb_exportar($ruta . '/exportar', $filtros) : '');
?>
<?php if ($opciones === []): ?>
    <?= pb_vacio('Aún no hay sucursales disponibles', '', 'bi-building') ?>
<?php else: ?>
    <?= pb_filtros($ruta) ?>
    <?= pb_rango($desde, $hasta) ?>
    <?= pb_campo('sucursal', 'Sucursal', ['tipo' => 'select', 'opciones' => $opciones, 'valor' => $sucursal, 'nativo' => true]) ?>
    <?= pb_filtros_fin($ruta) ?>
    <?= pb_registros(count($turnos)) ?>
    <?= pb_tabla($titulo, 'simple', true, 'bi-cash-stack') ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Apertura</th><th>Cajero</th><th data-pb-insignia>Estado</th>
        <th>Cierre</th><th>Fondo</th><th>Esperado</th><th>Contado</th><th>Diferencia</th></tr></thead>
    <tbody>
        <?php if ($turnos === []): ?><?= pb_fila_vacia(9, 'Sin turnos en el periodo') ?><?php endif; ?>
        <?php foreach ($turnos as $t): ?>
            <tr>
                <?= pb_acciones([pb_accion_detalle('verTurno', (int) $t['id'])]) ?>
                <td><?= $e(pb_fecha($t['abierto_en'])) ?></td><td><?= $e($t['cajero']) ?></td>
                <td><?= pb_insignia($t['cerrado_en'] === null ? 'bien' : 'mudo', $t['cerrado_en'] === null ? 'Abierto' : 'Cerrado') ?></td>
                <td><?= $e($t['cerrado_en'] === null ? '—' : pb_fecha($t['cerrado_en'])) ?></td>
                <?php foreach (['fondo', 'efectivo_esperado', 'efectivo_declarado', 'diferencia'] as $campo): ?>
                    <td><?= $e($t[$campo] === null ? '—' : pb_dinero($t[$campo])) ?></td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>
<?php if ($sucursal > 0): ?>
    <?= pb_detalle('verTurno', 'Turno', $ruta, 'modal-xl', '?sucursal=' . $sucursal) ?>
<?php endif; ?>
