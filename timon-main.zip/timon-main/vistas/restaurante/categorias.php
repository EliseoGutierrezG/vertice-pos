<?php
$ruta = '/categorias-menu';
echo pb_modulo('bi-tags', $titulo, 'Categorías que agrupan los platillos.',
    $sucursal > 0 ? pb_agregar('categoriaModal', 'Agregar', 'Agregar categoría')
        . pb_boton('/carta?sucursal=' . $sucursal, 'Ver carta', 'bi-book', 'outline-primary') : '');
require __DIR__ . '/filtro.php';
?>
<?php if ($sucursal > 0): ?>
    <?= pb_registros(count($categorias)) ?>
    <?= pb_tabla('Categorías del menú') ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Categoría</th><th>Leyenda en la carta</th><th>Orden</th></tr></thead>
    <tbody>
    <?php if ($categorias === []): ?><?= pb_fila_vacia(4, 'Aún no hay categorías') ?><?php endif; ?>
    <?php foreach ($categorias as $c): ?>
        <tr><?= pb_acciones([
            pb_accion_detalle('verCategoria', (int) $c['id']),
            pb_accion_modal('categoriaModal', 'actualizar', (int) $c['id'], $ruta . '/' . $c['id'],
                'Actualizar categoría', [], $ruta . '/' . $c['id'] . '?sucursal=' . $sucursal),
            pb_accion_post($ruta . '/' . $c['id'] . '/baja', 'Dar de baja', 'fa-close', '¿Dar de baja la categoría?',
                peligro: true, campos: ['sucursal' => $sucursal], unaVez: true),
        ]) ?>
            <td><?= $e($c['nombre']) ?></td><td><?= $e($c['descripcion'] ?: '—') ?></td><td><?= $e($c['orden']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>
<?php if ($sucursal > 0): ?>
    <?= pb_detalle('verCategoria', 'Categoría', $ruta, 'modal-lg', '?sucursal=' . $sucursal) ?>
    <?= pb_modal('categoriaModal', 'Agregar categoría', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('nombre', 'Nombre', ['requerido' => true, 'largo' => 80]) ?>
        <?= pb_campo('orden', 'Orden', ['tipo' => 'numero', 'min' => 0, 'max' => 65535, 'valor' => 0, 'requerido' => true]) ?>
        <?= pb_campo('descripcion', 'Leyenda en la carta', ['tipo' => 'textarea', 'largo' => 300, 'clase' => 'field-span-2',
            'ayuda' => 'Sale en cursiva bajo el título.']) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>
