<main class="ticket">
    <header class="ticket-header">
        <?= pb_marca_logo($marcaVisual ?? null, 'monocromo', 'El Timón', 'ticket-logo') ?>
        <h1>Ticket <?= $e($ticket['folio']) ?></h1>
        <p><?= $e($ticket['sucursal']) ?> · <?= $e(pb_fecha($ticket['pagado_en'])) ?></p>
        <p><?= $e($ticket['origen']) ?> · Atendió <?= $e($ticket['mesero']) ?></p>
    </header>
    <table class="ticket-tabla">
        <thead><tr><th>Platillo</th><th>Importe</th></tr></thead>
        <tbody><?php foreach ($ticket['items'] as $item): ?>
            <tr><td><?= $e($item['cantidad']) ?> × <?= $e($item['platillo']) ?></td><td>$<?= $e($item['importe']) ?></td></tr>
            <?php if ((float) $item['descuento'] > 0): ?>
                <tr class="ticket-promocion"><td><?= $e($item['promocion']) ?></td><td>−$<?= $e($item['descuento']) ?></td></tr>
            <?php endif; ?>
        <?php endforeach; ?></tbody>
    </table>
    <dl>
        <?php if ($ticket['ajuste_reparto'] !== '0.00'): ?>
            <dt>Platillos</dt><dd>$<?= $e($ticket['platillos_total']) ?></dd>
            <dt>Ajuste por reparto</dt><dd>$<?= $e($ticket['ajuste_reparto']) ?></dd>
        <?php endif; ?>
        <dt>Consumo</dt><dd>$<?= $e($ticket['consumo']) ?></dd>
        <?php if ((float) $ticket['descuento'] > 0): ?><dt>Descuento</dt><dd>−$<?= $e($ticket['descuento']) ?></dd><?php endif; ?>
        <dt>Propina</dt><dd>$<?= $e($ticket['propina']) ?></dd>
        <dt><strong>Total</strong></dt><dd><strong>$<?= $e($ticket['pagado']) ?></strong></dd>
        <?php foreach ($ticket['formas'] as $forma): ?>
            <dt><?= $e(ucfirst($forma['medio'])) ?></dt><dd>$<?= $e($forma['importe']) ?></dd>
            <?php if ($forma['recibido'] !== null): ?>
                <dt>Recibido</dt><dd>$<?= $e($forma['recibido']) ?></dd>
                <dt>Cambio</dt><dd>$<?= $e($forma['cambio']) ?></dd>
            <?php endif; ?>
        <?php endforeach; ?>
    </dl>
    <p>Consulte el ticket con este código.</p>
    <?= pb_qr($enlace, 'Ticket en línea', 144) ?>
</main>
