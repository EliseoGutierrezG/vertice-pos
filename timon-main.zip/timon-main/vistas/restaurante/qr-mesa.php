<main class="ticket">
    <?= pb_marca_logo($marcaVisual ?? null, 'monocromo', 'El Timón', 'ticket-logo') ?>
    <h1>Menú de la mesa <?= $e($mesa['numero']) ?></h1>
    <p><?= $e($sucursal['nombre']) ?></p>
    <?= pb_qr($enlace, 'Menú de la sucursal', 168) ?>
    <p><a href="<?= $e($enlace) ?>"><?= $e($enlace) ?></a></p>
</main>
