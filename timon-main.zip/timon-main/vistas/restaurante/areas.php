<?php
$ruta = '/areas';
$puedeEditar = $sucursal > 0 && $identidad->puede('plano_admin');
echo pb_modulo('bi-map', $titulo, 'Áreas que organizan el plano de la sucursal.',
    $puedeEditar ? pb_agregar('areaModal', 'Agregar', 'Agregar área') : '');
require __DIR__ . '/filtro.php';
?>
<?php if ($sucursal > 0): ?>
    <?= pb_registros(count($areas)) ?>
    <?= pb_tabla('Áreas') ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Área</th><th>Mesas</th></tr></thead>
    <tbody>
    <?php if ($areas === []): ?><?= pb_fila_vacia(3, 'Aún no hay áreas') ?><?php endif; ?>
    <?php foreach ($areas as $area): ?>
        <tr>
            <?= pb_acciones([
                pb_accion_detalle('verArea', (int) $area['id']),
                $puedeEditar ? pb_accion_modal('areaModal', 'actualizar', (int) $area['id'], $ruta . '/' . $area['id'],
                    'Actualizar área', [], $ruta . '/' . $area['id'] . '?sucursal=' . $sucursal) : '',
                $puedeEditar && (int) $area['mesas'] === 0
                    ? pb_accion_post($ruta . '/' . $area['id'] . '/baja', 'Dar de baja', 'fa-close', '¿Dar de baja el área?',
                        peligro: true, campos: ['sucursal' => $sucursal], unaVez: true) : '',
            ]) ?>
            <td><?= $e($area['nombre']) ?></td>
            <td><?= (int) $area['mesas'] ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>

<?php if ($sucursal > 0): ?>
    <?= pb_detalle('verArea', 'Área', $ruta, 'modal-lg', '?sucursal=' . $sucursal) ?>
<?php endif; ?>

<?php if ($puedeEditar): ?>
    <?= pb_modal('areaModal', 'Agregar área', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <?= pb_campo('nombre', 'Nombre', ['requerido' => true, 'largo' => 80]) ?>
    <?= pb_modal_fin() ?>
<?php endif; ?>
