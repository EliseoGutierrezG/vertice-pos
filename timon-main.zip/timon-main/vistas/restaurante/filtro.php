<?php if ($opciones === []): ?>
    <?= pb_vacio('Aún no hay sucursales disponibles', 'Agregue una sucursal desde el panel.', 'bi-building') ?>
<?php else: ?>
    <?= pb_filtros($ruta) ?>
    <?= pb_campo('sucursal', 'Sucursal', ['tipo' => 'select', 'opciones' => $opciones, 'valor' => $sucursal, 'nativo' => true]) ?>
    <?php if (isset($buscar)): ?><?= pb_campo('buscar', ($tipo ?? '') === 'insumos' ? 'Insumo' : 'Nombre', ['valor' => $buscar, 'largo' => 120]) ?><?php endif; ?>
    <?php if (isset($platilloFiltro)): ?><?= pb_campo('platillo', 'Platillo', ['tipo' => 'select', 'nativo' => true, 'valor' => $platilloFiltro,
        'opciones' => [0 => 'Todos'] + array_column($platillos ?? [], 'nombre', 'id')]) ?><?php endif; ?>
    <?php if (isset($estadoFiltro)): ?><?= pb_campo('estado', 'Estado', ['tipo' => 'select', 'nativo' => true, 'valor' => $estadoFiltro,
        'opciones' => ['' => 'Todos'] + \Servicios\Promociones::ESTADOS]) ?><?php endif; ?>
    <?= pb_filtros_fin($ruta) ?>
<?php endif; ?>
