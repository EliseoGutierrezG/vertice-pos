<?php
$p = $pagina['pagina'];
$paginas = $pagina['paginas'];
$enlace = static fn (int $numero): string => $ruta . '?' . http_build_query(
    $filtros + ['por_pagina' => $pagina['tamano'], 'pagina' => $numero], encoding_type: PHP_QUERY_RFC3986
);
?>
<nav class="d-flex align-items-center justify-content-between flex-wrap gap-2 py-3" aria-label="Paginación">
    <span>Página <?= (int) $p ?> de <?= (int) $paginas ?> · <?= count($pagina['filas']) ?> en esta página</span>
    <div class="d-flex flex-wrap gap-2">
        <?php if ($p > 1): ?><a class="btn btn-outline-secondary" rel="prev" href="<?= $e($enlace($p - 1)) ?>">Anterior</a><?php endif; ?>
        <?php if ($p < $paginas): ?><a class="btn btn-outline-secondary" rel="next" href="<?= $e($enlace($p + 1)) ?>">Siguiente</a><?php endif; ?>
    </div>
</nav>
