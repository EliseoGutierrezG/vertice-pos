<form method="post" action="/inventario/recibir" data-pb-ajax>
    <?= $csrf->campo() ?>
    <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>">
    <input type="hidden" name="id_compra" value="<?= (int) $compra['id'] ?>">
    <div class="alert alert-danger d-none" role="alert" data-pb-error></div>
    <div class="form-grid">
        <?php foreach ($compra['lineas'] as $l): ?>
            <?php if ((float) $l['pendiente'] > 0): ?>
                <?= pb_campo('recibidas[' . $l['id'] . ']', $l['insumo'], ['tipo' => 'numero', 'min' => 0, 'max' => $l['pendiente'],
                    'step' => '.001', 'valor' => $l['pendiente'], 'ayuda' => 'Pendiente: ' . $l['pendiente']]) ?>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
    <button type="submit" class="btn btn-primary mt-3">Registrar recepción</button>
</form>
