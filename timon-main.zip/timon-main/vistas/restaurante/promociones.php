<?php
use Dominio\Promocion;
use Servicios\Promociones;

$ruta = '/promociones';
$porCategoria = [];
foreach ($platillos ?? [] as $pl) {
    if ((int) $pl['activo'] === 1) {
        $porCategoria[$pl['categoria']][] = $pl;
    }
}
$tonos = ['vigente' => 'bien', 'programada' => 'info', 'pausada' => 'mudo', 'vencida' => 'avisa'];
echo pb_modulo('bi-percent', $titulo, 'Descuentos por platillo que se aplican solos al capturar.',
    $sucursal > 0 && $porCategoria !== [] ? pb_agregar('promocionModal', 'Agregar', 'Agregar promoción') : '');
require __DIR__ . '/filtro.php';
?>
<?php if ($sucursal > 0): ?>
    <?= pb_registros(count($promociones)) ?>
    <?= pb_tabla('Promociones') ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Promoción</th><th>Rebaja</th><th>Platillos</th>
        <th>Cuándo</th><th>Vigencia</th><th data-pb-insignia>Estado</th></tr></thead>
    <tbody>
    <?php if ($promociones === []): ?><?= pb_fila_vacia(7, 'Aún no hay promociones') ?><?php endif; ?>
    <?php foreach ($promociones as $pr): ?>
        <?php $detalle = $ruta . '/' . $pr['id'] . '?sucursal=' . $sucursal; ?>
        <tr>
            <?= pb_acciones(array_filter([
                pb_accion_detalle('verPromocion', (int) $pr['id']),
                pb_accion_modal('promocionModal', 'actualizar', (int) $pr['id'], $ruta . '/' . $pr['id'],
                    'Actualizar promoción', [], $detalle),
                (int) $pr['activa'] === 1
                    ? pb_accion_post($ruta . '/' . $pr['id'] . '/pausar', 'Pausar', 'fa-pause', '¿Pausar la promoción?',
                        campos: ['sucursal' => $sucursal], unaVez: true)
                    : pb_accion_post($ruta . '/' . $pr['id'] . '/reanudar', 'Reanudar', 'fa-play', '¿Reanudar la promoción?',
                        campos: ['sucursal' => $sucursal], unaVez: true),
                pb_accion_post($ruta . '/' . $pr['id'] . '/baja', 'Dar de baja', 'fa-close', '¿Dar de baja la promoción?',
                    peligro: true, campos: ['sucursal' => $sucursal], unaVez: true),
            ])) ?>
            <td><?= $e($pr['nombre']) ?></td>
            <td><?= pb_insignia('marca', $pr['etiqueta']) ?></td>
            <td><?= $e($pr['platillos'] ?? '') ?></td>
            <td><?= $e($pr['horario']) ?></td>
            <td><?= $e(pb_fecha($pr['desde'])) ?><?= $pr['hasta'] === null ? ' en adelante' : ' al ' . $e(pb_fecha($pr['hasta'])) ?></td>
            <td><?= pb_insignia($tonos[$pr['estado']], Promociones::ESTADOS[$pr['estado']]) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>

<?php if ($sucursal > 0): ?>
    <?= pb_detalle('verPromocion', 'Promoción', $ruta, 'modal-lg', '?sucursal=' . $sucursal) ?>
<?php endif; ?>

<?php if ($sucursal > 0 && $porCategoria !== []): ?>
    <?= pb_modal('promocionModal', 'Agregar promoción', $ruta, $csrf->campo(),
        instruccion: 'Se aplica sola al capturar. Los campos con * son obligatorios.') ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('nombre', 'Nombre', ['requerido' => true, 'largo' => 80, 'clase' => 'field-span-2',
            'marcador' => 'Martes de aguachile']) ?>
        <?= pb_campo('tipo', 'Tipo', ['tipo' => 'select', 'opciones' => Promocion::TIPOS, 'nativo' => true, 'requerido' => true,
            'valor' => 'porcentaje']) ?>
        <div data-pb-segun="tipo" data-pb-segun-valor="porcentaje">
            <?= pb_campo('porcentaje', 'Porcentaje de descuento', ['tipo' => 'numero', 'min' => 1, 'max' => 90, 'requerido' => true,
                'ayuda' => 'De 1 a 90 %. Incluye los suplementos.']) ?>
        </div>
        <div data-pb-segun="tipo" data-pb-segun-valor="precio">
            <?= pb_campo('precio_especial', 'Precio especial', ['tipo' => 'numero', 'min' => '0.01', 'step' => '.01', 'requerido' => true,
                'ayuda' => 'Debe ser menor que el precio de lista.']) ?>
        </div>
        <div data-pb-segun="tipo" data-pb-segun-valor="nxm" class="form-grid">
            <?= pb_campo('lleva', 'Lleva', ['tipo' => 'numero', 'min' => 2, 'max' => 10, 'valor' => 2, 'requerido' => true]) ?>
            <?= pb_campo('paga', 'Paga', ['tipo' => 'numero', 'min' => 1, 'max' => 9, 'valor' => 1, 'requerido' => true,
                'ayuda' => 'Sale gratis la pieza más barata.']) ?>
        </div>
        <?= pb_campo('desde', 'Desde', ['tipo' => 'fecha', 'valor' => date('Y-m-d'), 'requerido' => true]) ?>
        <?= pb_campo('hasta', 'Hasta', ['tipo' => 'fecha', 'ayuda' => 'Vacío: sin fecha final.']) ?>
        <?= pb_campo('hora_inicio', 'Hora de inicio', ['tipo' => 'time', 'ayuda' => 'Vacío: todo el día.']) ?>
        <?= pb_campo('hora_fin', 'Hora final', ['tipo' => 'time']) ?>
        <fieldset class="form-grid__full">
            <legend class="form-label">Días <span class="required-hint" aria-hidden="true">*</span></legend>
            <div class="d-flex flex-wrap gap-3">
                <?php foreach (Promocion::DIAS as $n => $dia): ?>
                    <label class="form-check"><input type="checkbox" class="form-check-input" name="dias[]" value="<?= $n ?>" checked>
                        <span class="form-check-label"><?= $e($dia) ?></span></label>
                <?php endforeach; ?>
            </div>
            <div class="invalid-feedback" data-error-for="dias"></div>
        </fieldset>
        <fieldset class="form-grid__full">
            <legend class="form-label">Sucursales <span class="required-hint" aria-hidden="true">*</span></legend>
            <div class="d-flex flex-wrap gap-3">
                <?php foreach ($opciones as $idSucursal => $nombreSucursal): ?>
                    <label class="form-check"><input type="checkbox" class="form-check-input" name="sucursales[]" value="<?= (int) $idSucursal ?>"
                        <?= (int) $idSucursal === $sucursal ? 'checked' : '' ?>>
                        <span class="form-check-label"><?= $e($nombreSucursal) ?></span></label>
                <?php endforeach; ?>
            </div>
            <div class="invalid-feedback" data-error-for="sucursales"></div>
        </fieldset>
        <fieldset class="form-grid__full promo-platillos">
            <legend class="form-label">Platillos <span class="required-hint" aria-hidden="true">*</span></legend>
            <?php foreach (array_values(array_keys($porCategoria)) as $n => $categoria): ?>
                <div class="promo-platillos__grupo">
                    <label class="form-check fw-semibold"><input type="checkbox" class="form-check-input" data-pb-marca-grupo="cat-<?= $n ?>">
                        <span class="form-check-label"><?= $e($categoria) ?> · toda la categoría</span></label>
                    <div class="d-flex flex-wrap gap-3 ps-4">
                        <?php foreach ($porCategoria[$categoria] as $pl): ?>
                            <label class="form-check"><input type="checkbox" class="form-check-input" name="platillos[]" value="<?= (int) $pl['id'] ?>"
                                data-pb-grupo="cat-<?= $n ?>">
                                <span class="form-check-label"><?= $e($pl['nombre']) ?><?= $pl['precio'] === null ? '' : ' · ' . $e(pb_dinero($pl['precio'])) ?></span></label>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            <div class="invalid-feedback" data-error-for="platillos"></div>
        </fieldset>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>
