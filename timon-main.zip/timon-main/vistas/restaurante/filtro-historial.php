<?php
use Servicios\HistoriasRestaurante;

$estadosFiltro = match ($tipo) {
    'compras' => HistoriasRestaurante::ESTADOS_COMPRA, 'movimientos' => HistoriasRestaurante::MOVIMIENTOS,
    'gastos' => HistoriasRestaurante::ESTADOS_GASTO, default => [],
};
$catalogoFiltro = array_column($tipo === 'movimientos' ? $insumos : $proveedores, 'nombre', 'id');
?>
<?= pb_filtros($ruta) ?>
    <?= pb_rango($filtros['desde'], $filtros['hasta']) ?>
    <?= pb_campo('sucursal', 'Sucursal', ['tipo' => 'select', 'opciones' => $opciones, 'valor' => $sucursal, 'nativo' => true]) ?>
    <?= pb_campo('catalogo', $tipo === 'movimientos' ? 'Insumo' : 'Proveedor', ['tipo' => 'select',
        'opciones' => [0 => 'Todos'] + $catalogoFiltro, 'valor' => $filtros['catalogo'], 'nativo' => true]) ?>
    <?php if ($estadosFiltro !== []): ?>
        <?= pb_campo('estado', $tipo === 'movimientos' ? 'Movimiento' : 'Estado', ['tipo' => 'select', 'opciones' => $estadosFiltro,
            'valor' => $filtros['estado'], 'vacia' => 'Todos', 'nativo' => true]) ?>
    <?php endif; ?>
    <?= pb_campo('buscar', 'Texto', ['valor' => $filtros['buscar'], 'largo' => 120]) ?>
    <?= pb_campo('por_pagina', 'Filas por página', ['tipo' => 'numero', 'min' => 1, 'max' => 100, 'valor' => $pagina['tamano']]) ?>
<?= pb_filtros_fin($ruta) ?>
