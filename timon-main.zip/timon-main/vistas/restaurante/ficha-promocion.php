<?php
use Dominio\Promocion;
use Servicios\Promociones;

$campos = [
    'Tipo' => Promocion::TIPOS[$promo['tipo']], 'Rebaja' => $promo['etiqueta'], 'Cuándo' => $promo['horario'],
    'Desde' => pb_fecha($promo['desde']), 'Hasta' => $promo['hasta'] === null ? 'Sin fecha final' : pb_fecha($promo['hasta']),
    'Sucursales' => implode(', ', $promo['nombres_sucursales']), 'Estado' => Promociones::ESTADOS[$promo['estado']],
];
require __DIR__ . '/ficha.php';
?>
<?= pb_seccion('bi-journal-text', 'Platillos') ?>
    <?= pb_tabla('Platillos de la promoción', 'simple') ?>
    <thead><tr><th data-pb-titulo>Platillo</th><th>Categoría</th></tr></thead>
    <tbody>
    <?php foreach ($promo['platillos'] as $pl): ?>
        <tr><td><?= $e($pl['nombre']) ?></td><td><?= $e($pl['categoria']) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
</section>
