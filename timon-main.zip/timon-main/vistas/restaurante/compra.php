<?php
$campos = ['Proveedor' => $compra['proveedor'], 'Fecha' => pb_fecha($compra['creada_en']),
    'Estado' => \Servicios\HistoriasRestaurante::ESTADOS_COMPRA[$compra['estado']]];
require __DIR__ . '/ficha.php';
?>
<?= pb_seccion('bi-list-check', 'Renglones') ?>
<?= pb_tabla('Renglones de compra', 'simple') ?>
<thead><tr><th data-pb-titulo>Insumo</th><th>Pedido</th><th>Recibido</th><th>Pendiente</th><th>Costo</th><th>Caducidad</th></tr></thead>
<tbody>
    <?php if ($compra['lineas'] === []): ?><?= pb_fila_vacia(6, 'Sin renglones') ?><?php endif; ?>
    <?php foreach ($compra['lineas'] as $l): ?>
        <tr>
            <td><?= $e($l['insumo']) ?></td><td><?= $e($l['cantidad']) ?></td><td><?= $e($l['recibido']) ?></td><td><?= $e($l['pendiente']) ?></td>
            <td><?= $e(pb_dinero($l['costo'])) ?></td><td><?= $e($l['vence'] === null ? '—' : pb_fecha($l['vence'])) ?></td>
        </tr>
    <?php endforeach; ?>
</tbody>
<?= pb_tabla_fin() ?>
</section>
