<?php
// El menú QR de una sucursal: lo que el comensal ve al escanear el código de
// su mesa. Lleva el estilo de la carta impresa (marino, dorado y Playfair) en
// una sola columna, sin JavaScript: el índice de categorías son anclas y la
// mesa llega en `?mesa=`. Las promociones vigentes salen arriba y en cada
// platillo, con el precio tachado.
$categorias = [];
$promociones = [];
foreach ($platillos as $p) {
    $categorias[$p['categoria']] ??= ['leyenda' => (string) ($p['descripcion_categoria'] ?? ''), 'platillos' => []];
    $categorias[$p['categoria']]['platillos'][] = $p;
    if (($p['promocion'] ?? null) !== null) {
        $id = $p['promocion']['id'];
        $promociones[$id] ??= $p['promocion'] + ['incluidos' => []];
        $promociones[$id]['incluidos'][] = $p['nombre'];
    }
}
$ancla = static fn (int $i): string => 'categoria-' . ($i + 1);
?>
<!doctype html>
<html lang="es-MX">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#0B1930">
    <meta name="description" content="Menú de El Timón <?= $e($sucursal['nombre']) ?>: precios y platillos disponibles hoy.">
    <title>Menú · El Timón <?= $e($sucursal['nombre']) ?></title>
    <link rel="icon" href="/recursos/isotipo.svg" type="image/svg+xml">
    <link rel="stylesheet" href="/recursos/marca.css">
    <link rel="stylesheet" href="/recursos/sitio/estilo.css?v=20261118.1">
</head>
<body class="portada carta-qr">
<a href="#contenido" class="salto">Ir al menú</a>
<header class="qr-cabecera">
    <div class="envoltura qr-cabecera-interior">
        <a class="barra-marca" href="/" aria-label="El Timón, inicio">
            <svg class="barra-simbolo" viewBox="0 0 100 94" aria-hidden="true"><circle cx="50" cy="46" r="27"/><path d="M50 8v76M12 46h76M23 19l54 54M23 73l54-54"/><circle class="centro" cx="50" cy="46" r="8"/><path class="ola-logo" d="M7 66c13-9 24-9 38 0s25 9 37 1l11-5"/></svg>
            <span><strong>El Timón</strong><small><?= $e($sucursal['nombre']) ?></small></span>
        </a>
        <?php if ($mesa !== null): ?><p class="qr-mesa">Mesa <?= $e($mesa) ?></p><?php endif; ?>
    </div>
    <?php if (count($categorias) > 1): ?>
        <nav class="qr-indice" aria-label="Categorías del menú">
            <div class="envoltura qr-indice-interior">
                <?php if ($promociones !== []): ?><a href="#promociones">Promociones</a><?php endif; ?>
                <?php foreach (array_keys($categorias) as $i => $nombre): ?>
                    <a href="#<?= $e($ancla($i)) ?>"><?= $e($nombre) ?></a>
                <?php endforeach; ?>
            </div>
        </nav>
    <?php endif; ?>
</header>

<main id="contenido" class="envoltura qr-carta">
    <div class="qr-titulo">
        <img class="qr-brujula" src="/recursos/carta/brujula.webp" alt="" width="240" height="190">
        <p class="qr-nombre">El Timón.</p>
        <p class="qr-giro">Restaurante · <?= $e($sucursal['nombre']) ?></p>
        <img class="qr-timon" src="/recursos/carta/timon.webp" alt="" width="122" height="108">
        <h1>Menú</h1>
        <p class="entrada">Precios en pesos mexicanos. Pida a su mesero lo que guste.</p>
    </div>

    <?php if ($platillos === []): ?>
        <p class="qr-vacio">Esta sucursal aún no publica su menú.</p>
    <?php endif; ?>

    <?php if ($promociones !== []): ?>
        <section class="qr-promociones" id="promociones" aria-labelledby="promociones-titulo">
            <h2 id="promociones-titulo">Promociones de hoy</h2>
            <ul>
                <?php foreach ($promociones as $promo): ?>
                    <li>
                        <span class="qr-promo-etiqueta"><?= $e($promo['etiqueta']) ?></span>
                        <strong><?= $e($promo['nombre']) ?></strong>
                        <small><?= $e($promo['horario']) ?>. <?= $e(implode(', ', $promo['incluidos'])) ?>.</small>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endif; ?>

    <?php foreach (array_values($categorias) as $i => $categoria): $lista = $categoria['platillos']; ?>
        <section class="qr-seccion" id="<?= $e($ancla($i)) ?>" aria-labelledby="<?= $e($ancla($i)) ?>-titulo">
            <h2 id="<?= $e($ancla($i)) ?>-titulo"><?= $e($lista[0]['categoria']) ?></h2>
            <?php if (trim($categoria['leyenda']) !== ''): ?><p class="qr-leyenda"><?= $e($categoria['leyenda']) ?></p><?php endif; ?>
            <ul class="qr-lista">
                <?php foreach ($lista as $p): ?>
                    <?php
                    $agotado = (bool) (int) $p['agotado'];
                    $promo = $p['promocion'] ?? null;
                    $preparaciones = \Servicios\CartaImpresa::preparaciones($p['modificadores'] ?? []);
                    ?>
                    <li class="qr-platillo<?= $agotado ? ' esta-agotado' : '' ?><?= $promo ? ' tiene-promocion' : '' ?>">
                        <?php if ($p['foto'] !== null && $p['foto'] !== ''): ?>
                            <img src="<?= $e($p['foto']) ?>" alt="" width="160" height="160" loading="lazy" decoding="async">
                        <?php endif; ?>
                        <div class="qr-platillo-texto">
                            <h3><?= $e($p['nombre']) ?><?php if (($p['porcion'] ?? '') !== ''): ?> <span class="qr-porcion">(<?= $e($p['porcion']) ?>)</span><?php endif; ?></h3>
                            <?php if (trim((string) $p['descripcion']) !== ''): ?><p><?= $e($p['descripcion']) ?></p><?php endif; ?>
                            <?php if ($preparaciones !== ''): ?><p class="qr-preparaciones"><?= $e($preparaciones) ?></p><?php endif; ?>
                            <?php if ($agotado): ?>
                                <span class="qr-marca qr-agotado">Agotado hoy</span>
                            <?php elseif ($promo): ?>
                                <span class="qr-marca qr-marca-promo"><?= $e($promo['etiqueta']) ?> · <?= $e($promo['horario']) ?></span>
                            <?php elseif ((int) ($p['especialidad'] ?? 0) === 1): ?>
                                <span class="qr-marca">De la casa</span>
                            <?php endif; ?>
                        </div>
                        <strong class="qr-precio">
                            <?php if ($promo && $promo['precio_promocion'] !== null && !$agotado): ?>
                                <s><?= pb_dinero($p['precio']) ?></s><?= pb_dinero($promo['precio_promocion']) ?>
                            <?php else: ?>
                                <?= pb_dinero($p['precio']) ?>
                            <?php endif; ?>
                        </strong>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endforeach; ?>
</main>

<footer class="qr-pie">
    <div class="envoltura qr-pie-interior">
        <a class="boton boton-salsa" href="/#reservar">Reservar mesa</a>
        <a href="/">Conozca El Timón</a>
        <a href="/aviso-privacidad">Aviso de privacidad</a>
    </div>
</footer>
</body>
</html>
