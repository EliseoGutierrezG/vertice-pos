<?php
$ruta = '/inventario/faltantes';
echo pb_modulo('bi-exclamation-circle', $titulo, 'Insumos que faltaron al cobrar.');
?>
<?php if ($sucursal > 0): ?>
    <?= pb_filtros($ruta) ?>
    <?= pb_campo('sucursal', 'Sucursal', ['tipo' => 'select', 'opciones' => $opciones, 'valor' => $sucursal, 'nativo' => true]) ?>
    <?= pb_campo('estado', 'Estado', ['tipo' => 'select', 'opciones' => ['pendientes' => 'Pendientes', 'atendidos' => 'Atendidos', 'todos' => 'Todos'],
        'valor' => $estado, 'nativo' => true]) ?>
    <?= pb_filtros_fin($ruta) ?>
    <?= pb_registros(count($faltantes)) ?>
    <?= pb_tabla($titulo) ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Insumo</th><th>Cantidad</th><th>Ticket</th>
        <th>Registrado</th><th data-pb-insignia>Estado</th><th>Atendió</th><th>Nota</th></tr></thead>
    <tbody>
    <?php if ($faltantes === []): ?><?= pb_fila_vacia(8, 'Sin faltantes con este filtro') ?><?php endif; ?>
    <?php foreach ($faltantes as $f): ?>
        <tr>
            <?= pb_acciones([$f['atendido_en'] === null ? pb_accion_modal('atenderFaltante', 'actualizar', (int) $f['id'],
                $ruta . '/' . $f['id'] . '/atender', 'Atender faltante', [], etiqueta: 'Atender') : '']) ?>
            <td><?= $e($f['insumo']) ?></td><td><?= $e($f['cantidad'] . ' ' . $f['unidad']) ?></td>
            <td><?= $e($f['folio'] ?? '#' . $f['id_cuenta']) ?></td>
            <td><?= $e(pb_fecha($f['creado_en'])) ?></td>
            <td><?= pb_insignia($f['atendido_en'] === null ? 'advertencia' : 'bien', $f['atendido_en'] === null ? 'Pendiente' : 'Atendido') ?></td>
            <td><?= $e($f['atendio'] ?? '—') ?></td><td><?= $e($f['nota'] ?? '—') ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php else: ?>
    <?= pb_vacio('Aún no hay sucursales disponibles', '', 'bi-building') ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>

<?php if ($sucursal > 0): ?>
    <?= pb_modal('atenderFaltante', 'Atender faltante', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>">
    <?= pb_campo('nota', 'Nota', ['tipo' => 'textarea', 'largo' => 160, 'ayuda' => 'Indique cómo se atendió el faltante.']) ?>
    <?= pb_modal_fin('Marcar atendido', 'fa-check') ?>
<?php endif; ?>
