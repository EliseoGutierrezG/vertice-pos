<?php
use Servicios\MenuRestaurante;

$ruta = '/platillos';
$admin = $sucursal > 0 && $identidad->puede('menu_admin');
$editaSucursal = $sucursal > 0 && $identidad->puede('menu_sucursal');
$categoriasMenu = array_column($categorias ?? [], 'nombre', 'id');
$desdeSucursales = array_diff_key($opciones, [$sucursal => true]);
$acciones = $admin && $categoriasMenu !== [] ? pb_agregar('platilloModal', 'Agregar', 'Agregar platillo') : '';
if ($sucursal > 0) {
    $acciones .= pb_boton('/carta?sucursal=' . $sucursal, 'Ver carta', 'bi-book', 'outline-primary');
}
if ($editaSucursal && $platillos !== []) {
    $acciones .= pb_verbo('preciosModal', 'Precios en lote', 'bi-currency-dollar');
    if ($desdeSucursales !== []) {
        $acciones .= pb_verbo('copiaPrecios', 'Copiar precios', 'bi-copy');
    }
}
echo pb_modulo('bi-journal-text', $titulo, 'Carta, precios y disponibilidad por sucursal.', $acciones);
require __DIR__ . '/filtro.php';
?>
<?php if ($sucursal > 0): ?>
    <?= pb_registros(count($platillos)) ?>
    <?= pb_tabla('Platillos') ?>
    <thead><tr><th data-pb-acciones>Acción</th><th data-pb-titulo>Platillo</th><th>Categoría</th><th>Preparación</th><th>Precio</th><th data-pb-insignia>Disponibilidad</th></tr></thead>
    <tbody>
    <?php if ($platillos === []): ?><?= pb_fila_vacia(6, 'Aún no hay platillos') ?><?php endif; ?>
    <?php foreach ($platillos as $d): ?>
        <tr>
            <?php $detalle = $ruta . '/' . $d['id'] . '?sucursal=' . $sucursal; ?>
            <?= pb_acciones(array_filter([
                pb_accion_detalle('verPlatillo', (int) $d['id']),
                $admin ? pb_accion_modal('platilloModal', 'actualizar', (int) $d['id'],
                    $ruta . '/' . $d['id'], 'Actualizar platillo', [], $detalle) : '',
                $editaSucursal ? pb_accion_modal('precioModal', 'precio', (int) $d['id'], $ruta . '/' . $d['id'] . '/disponibilidad',
                    'Precio y disponibilidad', [], $detalle, 'Precio y disponibilidad') : '',
            ])) ?>
            <td><?= $e($d['nombre']) ?><?= $d['porcion'] === '' ? '' : ' <span class="text-secondary">(' . $e($d['porcion']) . ')</span>' ?>
                <?php if ((int) $d['especialidad'] === 1): ?><br><?= pb_insignia('info', 'Especialidad') ?><?php endif; ?>
                <?php if (!empty($d['promocion'])): ?><br><?= pb_insignia('marca', 'En promoción · ' . $d['promocion']['etiqueta']) ?><?php endif; ?></td>
            <td><?= $e($d['categoria']) ?></td><td><?= $e(MenuRestaurante::AREAS[$d['preparacion']]) ?></td>
            <td><?= $d['precio'] === null ? 'Sin precio' : $e(pb_dinero($d['precio'])) ?></td>
            <td><?= match (true) {
                !(int) $d['activo'] => pb_insignia('mudo', 'Inactivo'),
                $d['precio'] === null => pb_insignia('mudo', 'Sin publicar'),
                (int) $d['agotado'] === 1 => pb_insignia('advertencia', 'Agotado'),
                default => pb_insignia('bien', 'Disponible'),
            } ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
<?php endif; ?>
<?= pb_modulo_fin() ?>

<?php if ($sucursal > 0): ?>
    <?= pb_detalle('verPlatillo', 'Platillo', $ruta, 'modal-lg', '?sucursal=' . $sucursal) ?>
<?php endif; ?>

<?php if ($admin && $categoriasMenu !== []): ?>
    <?= pb_modal('platilloModal', 'Agregar platillo', $ruta, $csrf->campo(), archivos: true) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <input type="hidden" name="foto">
    <div class="form-grid">
        <?= pb_campo('nombre', 'Nombre', ['requerido' => true, 'largo' => 100, 'clase' => 'field-span-2']) ?>
        <?= pb_campo('id_categoria', 'Categoría', ['tipo' => 'select', 'opciones' => $categoriasMenu, 'nativo' => true, 'requerido' => true]) ?>
        <?= pb_campo('preparacion', 'Preparación', ['tipo' => 'select', 'opciones' => MenuRestaurante::AREAS, 'nativo' => true, 'requerido' => true]) ?>
        <?= pb_campo('porcion', 'Porción', ['largo' => 40, 'marcador' => '3 pzas', 'ayuda' => 'Sale junto al nombre en la carta.']) ?>
        <?= pb_campo('orden', 'Orden en la carta', ['tipo' => 'numero', 'min' => 0, 'max' => 65535, 'valor' => 0,
            'ayuda' => 'Menor sale primero dentro de su categoría.']) ?>
        <?= pb_campo('descripcion', 'Descripción', ['tipo' => 'textarea', 'largo' => 400, 'clase' => 'field-span-2']) ?>
        <?= pb_campo('imagen', 'Foto', ['tipo' => 'file', 'ayuda' => 'JPG, PNG o WebP. Hasta 5 MB.',
            'clase' => 'field-span-2', 'extra' => ['accept' => 'image/jpeg,image/png,image/webp', 'data-pb-vista-previa' => '#vista-foto-platillo']]) ?>
        <div class="image-upload-preview field-span-2"><img id="vista-foto-platillo" alt="Vista previa de la foto" hidden width="240"></div>
        <?= pb_campo('especialidad', 'Especialidad de la casa', ['tipo' => 'select', 'opciones' => [0 => 'No', 1 => 'Sí'],
            'valor' => 0, 'nativo' => true, 'requerido' => true]) ?>
        <?= pb_campo('activo', 'Estado', ['tipo' => 'select', 'opciones' => [1 => 'Activo', 0 => 'Inactivo'], 'nativo' => true, 'requerido' => true]) ?>
    </div>
    <?= pb_modal_fin() ?>

    <?= pb_modal('modificadorModal', 'Agregar modificador', '/modificadores', $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <input type="hidden" name="id_platillo">
    <div class="form-grid">
        <?= pb_campo('nombre', 'Nombre', ['requerido' => true, 'largo' => 80]) ?>
        <?= pb_campo('suplemento', 'Suplemento', ['tipo' => 'numero', 'min' => 0, 'step' => '.01', 'valor' => '0.00', 'requerido' => true]) ?>
        <?= pb_campo('activo', 'Estado', ['tipo' => 'select', 'opciones' => [1 => 'Activo', 0 => 'Inactivo'], 'nativo' => true, 'requerido' => true]) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>

<?php if ($editaSucursal): ?>
    <?php if ($platillos !== []): ?>
        <?= pb_modal('preciosModal', 'Precios en lote', $ruta . '/precios', $csrf->campo(), instruccion: 'Capture los precios que quiera cambiar.') ?>
        <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>">
        <div class="form-grid">
            <?php foreach ($platillos as $d): ?>
                <?= pb_campo('precios[' . $d['id'] . ']', $d['nombre'], ['tipo' => 'numero', 'min' => 0, 'max' => '99999999.99',
                    'step' => '.01', 'marcador' => $d['precio'] ?? 'Sin precio', 'opcional' => false]) ?>
            <?php endforeach; ?>
        </div>
        <?= pb_modal_fin() ?>
    <?php endif; ?>
    <?php if ($platillos !== [] && $desdeSucursales !== []): ?>
        <?= pb_modal('copiaPrecios', 'Copiar precios', $ruta . '/precios', $csrf->campo(), instruccion: 'Reemplaza los precios de esta sucursal.') ?>
        <input type="hidden" name="sucursal" value="<?= (int) $sucursal ?>">
        <?= pb_campo('origen', 'Tomar precios de', ['tipo' => 'select', 'opciones' => $desdeSucursales, 'vacia' => 'Seleccione',
            'nativo' => true, 'requerido' => true]) ?>
        <?= pb_modal_fin('Copiar precios', 'fa-copy') ?>
    <?php endif; ?>

    <?= pb_modal('precioModal', 'Precio y disponibilidad', $ruta, $csrf->campo()) ?>
    <input type="hidden" name="sucursal" value="<?= $sucursal ?>">
    <div class="form-grid">
        <?= pb_campo('precio', 'Precio', ['tipo' => 'numero', 'min' => 0, 'max' => '99999999.99', 'step' => '.01', 'requerido' => true]) ?>
        <?= pb_campo('agotado', 'Disponibilidad', ['tipo' => 'select', 'opciones' => [0 => 'Disponible', 1 => 'Agotado'], 'nativo' => true, 'requerido' => true]) ?>
    </div>
    <?= pb_modal_fin() ?>
<?php endif; ?>
