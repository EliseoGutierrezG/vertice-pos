<?php
$campos = [
    'Cajero' => $turno['cajero'], 'Apertura' => pb_fecha($turno['abierto_en']),
    'Cierre' => $turno['cerrado_en'] === null ? 'Abierto' : pb_fecha($turno['cerrado_en']),
    'Fondo' => pb_dinero($resumen['fondo']), 'Venta' => pb_dinero($resumen['venta']),
    'Descuentos' => pb_dinero($resumen['descuentos']), 'Promociones' => pb_dinero($resumen['promociones']),
    'Propinas' => pb_dinero($resumen['propinas']),
    'Efectivo esperado' => pb_dinero($turno['efectivo_esperado'] ?? $resumen['esperado']),
    'Efectivo contado' => $turno['efectivo_declarado'] === null ? '—' : pb_dinero($turno['efectivo_declarado']),
    'Diferencia' => $turno['diferencia'] === null ? '—' : pb_dinero($turno['diferencia']),
];
require __DIR__ . '/ficha.php';
?>
<?= pb_seccion('bi-credit-card', 'Formas de pago') ?>
    <dl class="detail-list">
        <?php foreach (['efectivo' => 'Efectivo', 'tarjeta' => 'Tarjeta', 'transferencia' => 'Transferencia'] as $medio => $texto): ?>
            <div class="detail-list__row"><dt><?= $e($texto) ?></dt><dd><?= $e(pb_dinero($resumen['formas'][$medio])) ?></dd></div>
        <?php endforeach; ?>
    </dl>
</section>
<?= pb_seccion('bi-arrow-left-right', 'Movimientos de caja') ?>
    <?= pb_tabla('Movimientos de caja', 'simple') ?>
    <thead><tr><th>Fecha</th><th data-pb-titulo>Concepto</th><th>Importe</th><th>Operador</th></tr></thead>
    <tbody>
        <?php if ($movimientos === []): ?><?= pb_fila_vacia(4, 'Sin movimientos') ?><?php endif; ?>
        <?php foreach ($movimientos as $m): ?>
            <tr><td><?= $e(pb_fecha($m['creado_en'])) ?></td><td><?= $e($m['concepto']) ?></td>
                <td><?= $e(pb_dinero($m['importe'])) ?></td><td><?= $e($m['quien']) ?></td></tr>
        <?php endforeach; ?>
    </tbody>
    <?= pb_tabla_fin() ?>
</section>
