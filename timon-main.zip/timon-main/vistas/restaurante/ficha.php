<?= pb_seccion('bi-info-circle', 'Datos') ?>
    <dl class="detail-list">
        <?php foreach ($campos as $nombre => $valor): ?>
            <div class="detail-list__row">
                <dt><?= $e($nombre) ?></dt>
                <dd><?= $e($valor ?? '—') ?></dd>
            </div>
        <?php endforeach; ?>
    </dl>
</section>
