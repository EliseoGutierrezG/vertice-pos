# El Timón — sistema visual

> La [identidad vigente](../../marca/marca.md) es la «1A»: Timón y ola con la paleta Peltre, aprobada el 14 de noviembre de 2026. Sus colores salen de `marca/tokens.json` y `guiones/genera-marca.mjs` los lleva al panel (`servicios/MarcaBase.php` → `/marca/tema.css`), al sitio (`publico/recursos/marca.css`) y a la app (`app/src/nucleo/marca.ts`).

> El panel usa [la hoja estructural](../../publico/recursos/plantilla/main.css), [la adaptación del panel](../../publico/recursos/tema.css) y la paleta de la instalación en `/marca/tema.css`, que se carga al final. Las pantallas se arman según la [homologación](../../docs/homologacion-timon.md) y la [guía de pantallas](../../docs/guia-pantallas.md); este documento describe el aspecto, no el alcance.

## 0. La dirección

La plantilla base (fuera del proyecto, solo lectura) aporta un armazón sólido:
componentes, tablas, formularios y avisos. **Se reutiliza sin modificar
`main.css`, pero la jerarquía y los flujos se adaptan a la tarea.** El Timón
conserva sus clases, suma accesibilidad y usa esta identidad:

- Cobalto `#1C3F94` para acciones, fondo `#F5F7F8`, tinta de calamar `#0D1B3E`, rojo salsa `#C8372D` para errores, amarillo limón `#E9C24A` para avisos y verde limón `#A6C83C` solo en la ola sobre oscuro.
- En el plano se distingue libre, ocupada, cuenta pedida, por limpiar, reservada y bloqueada con texto visible. En teléfono pasa a lista.
- Cocina y caja muestran avisos de impresión con texto y el acceso al listado de trabajos.

`tema.css` conserva la forma y la letra de D24 (2026-11-09) y unos neutros de
respaldo; los colores de marca de cada instalación siempre llegan después, desde
`/marca/tema.css`. Por eso un valor escrito en `tema.css` no es la marca: la
marca es `tokens.json`.

## 0.1 Los valores

| Qué | Valor |
|---|---|
| Títulos y cifras del panel | Sora 600–700 (`--pb-fuente-titulos`) |
| Interfaz | Plus Jakarta Sans 400–700 (`--pb-fuente-interfaz`) |
| Folios y etiquetas técnicas | JetBrains Mono 400–500 (`--pb-fuente-mono`, clase `.pb-etiqueta-tecnica`) |
| Titulares del sitio | Playfair Display en la portada y los títulos de sección; Sora en el resto |
| Radios | 12 controles (`--pb-radio-chico`), 18 tarjetas (`--pb-radio`), 28 Entrar (`--pb-radio-grande`) |
| Sombras | Solo menús, modales y la portada |
| Contadores | `metric-card` y `summary-tile` planos; etiqueta en monoespaciada, cifra en Sora con cifras tabulares |
| Movimiento | 180 ms en controles; nada con `prefers-reduced-motion` |
| Armazón | Barra lateral plana en tinta; la sección activa lleva fondo tenue y orilla de 3 px |
| Superficies de Bootstrap | `--bs-body-bg` es blanco (tablas, tarjetas, ventanas y campos); el lienzo sale de `--app-bg` en `body` |
| Tablas | Superficie blanca, cebra al 2.5 % y paso del ratón al 4.5 % |
| Tablero | Indicadores del día de la sucursal (ventas, cuentas abiertas, comandas atrasadas, impresiones, reservaciones, faltantes y turno), con alcance y hora visibles |
| Sitio | `publico/recursos/sitio/estilo.css` y `landing.js`, con los tokens de `marca.css`; fuentes locales |
| App de comanda | `app/src/nucleo/marca.ts` y `tintes` en `ui.tsx`; tipografía del sistema para conservar las métricas nativas |
| Papel | Tickets monocromos con la versión negra del logotipo; el QR de mesa con la leyenda de la sucursal |

Las fuentes son locales (`publico/recursos/fuentes/`, OFL) y se precargan en
`vistas/plantilla/estilos.php`. Ninguna petición sale a Google Fonts.

## 1. Color

### 1.1 Los tokens

`tema.css` empieza por redefinir las variables de `main.css` (`--app-primary`,
`--app-bg`, `--app-text`, `--app-accent`…) y `/marca/tema.css` las reemplaza con
los valores de `tokens.json`. Se declaran además los dos tokens que `main.css`
usa y nunca define: `--app-shadow-sm` y `--app-radius-lg`.

### 1.2 Los azules que la plantilla base deja escritos a mano

Además de las variables, `tema.css` corrige lo que sale en azul aunque
no pase por ellas:

- las variables de Bootstrap `--bs-primary*`, `--bs-link*` y
  `--bs-focus-ring-color`, y `.btn-primary`, `.text-primary`, `.bg-primary`,
  `.btn-link`, `.nav-link`, `.form-check-input:checked` y el foco de
  `.form-control` y `.form-select`;
- el brillo radial azul de `.app-shell` y `.login`, que pasa al primario;
- `.summary-tile--info`, `.chart-card`, `.module-icon`, `.module-chip` y
  `.perfil-hero`;
- DataTables (`dt-global_style`): el azul `#4361ee` de la paginación y el tinte
  `rgba(234, 241, 255)` de la cabecera;
- Select2, Flatpickr y los diálogos de SweetAlert2 (§4.1);
- `code`, que Bootstrap pinta en rosa.

### 1.3 Contraste

`node guiones/genera-marca.mjs --verifica` comprueba que los archivos generados
están al día y que los pares de `tokens.json` alcanzan AA. `MarcaVisual` repite
la revisión con la marca propia de una instalación. El verde limón y el
amarillo limón nunca van como texto sobre claro.

Bootstrap y DataTables dejan cuatro colores por debajo de 4.5 sobre la
superficie apagada de los filtros. `tema.css` los oscurece desde la
auditoría del 2026-10-06 (bitácora 95):

| Qué | Antes | Ahora |
|---|---|---|
| `.btn-outline-secondary` («Limpiar», «Hoy», «Cancelar») | 4.48 | `#4b5563` · 7.2 |
| `.btn-outline-success` y `-danger` (CSV, PDF, «Retirar») | 4.33 | `#146c43` · 6.9 / `#b02a37` · 6.4 |
| El asterisco `.required-hint` | 4.33 | `#b02a37` · 6.4 |
| «Mostrar:» e información de DataTables | 3.24 | `--app-muted` · 4.55 |

`text-bg-info` usa el tenue `--pb-tenue` con el texto de la tinta: lo informativo no tiene color propio.

## 2. Las librerías

Todas en local, en `publico/recursos/vendor/`, copiadas de
la plantilla original con **las mismas versiones y archivos**. Nada se
carga de un CDN. Se enlazan desde [`estilos.php`](../../vistas/plantilla/estilos.php) y
[`scripts.php`](../../vistas/plantilla/scripts.php):

| Librería | Versión | Para qué |
|---|---|---|
| Bootstrap (CSS y `bootstrap.bundle`) | 5.3.8 | Rejilla, formularios, colapsables, menú de usuario |
| Bootstrap Icons | la de la plantilla base | Los iconos del menú y de los módulos (`bi-*`) |
| Font Awesome | 4.6 | Los iconos de acción que la plantilla base usa (`fa-search`, `fa-pencil`, `fa-file-excel-o`) |
| jQuery | 3.6.0 | Lo pide DataTables, Select2 y `main.js` |
| DataTables (bs4) + `dt-global_style` + `custom_dt_custom` | 1.10 | Listados: búsqueda, orden, paginación |
| Select2 + tema bs5 + `es.js` | la de la plantilla base | Selects con búsqueda (`data-app-select2`) |
| SweetAlert2 | la de la plantilla base, con [`alertas.js`](../../publico/recursos/alertas.js) encima | Confirmaciones y avisos (`window.alerts`), con la disposición y el movimiento de §4.1 |
| Flatpickr | la de la plantilla base | Fechas (`data-app-date`) |

El sitio público no carga ninguna: su CSP es `default-src 'self'` y no hay mapa incrustado.

## 3. El JavaScript

| Archivo | Qué es |
|---|---|
| [`plantilla/main.js`](../../publico/recursos/plantilla/main.js) | El de la plantilla base con dos llaves propias de `localStorage` y el resumen accesible de errores de validación: recibe foco y enlaza cada mensaje con su campo |
| [`plantilla/datatables.js`](../../publico/recursos/plantilla/datatables.js) | El de la plantilla base, sin cambios: `AppDataTables` |
| [`servicio.js`](../../publico/recursos/servicio.js) | `window.service` mínimo: lo que `main.js` y `datatables.js` consultan. Solo la salida pasa por él (POST a `/salir` con la marca CSRF) |
| [`plantilla.js`](../../publico/recursos/plantilla.js) | Lo propio: monta DataTables sobre `table[data-pb-tabla]`, arma las `record-cards`, abre Ver y Actualizar con la ficha del servidor, confirma `form[data-confirma]` con SweetAlert2, anuncia los avisos, pliega los filtros en el teléfono y previsualiza la foto del platillo |
| [`sitio/landing.js`](../../publico/recursos/sitio/landing.js) | El sitio: sucursales, «Abierto ahora», menú, especialidades, reservación y JSON-LD, desde las dos API públicas |

La plantilla base pide sus renglones por AJAX. Aquí **las pantallas llegan pintadas del
servidor**: funcionan sin JavaScript, las pruebas de humo las leen tal cual, y
`plantilla.js` solo les monta encima los mismos componentes.

## 4. Las piezas

[`vistas/partes/piezas.php`](../../vistas/partes/piezas.php) emite el marcado de
la plantilla base. Todas escapan cada dato; sus parámetros `...Html` reciben la salida
de otra pieza, nunca un dato.

| Pieza | Emite |
|---|---|
| `pb_modulo` / `pb_modulo_fin` | `module-shell` > `module-card` con su `module-header` |
| `pb_encabezado` | `module-header`: `module-icon`, `h2`, descripción y `module-actions` |
| `pb_boton` / `pb_accion` / `pb_agregar` | `a.btn.btn-*` / `a.label-default.action-link` / el botón primario del alta |
| `pb_exportar` | «Exportar XLS» en contorno, con los filtros normalizados del listado |
| `pb_filtros` / `pb_filtros_fin` / `pb_rango` | `module-filters`, «Buscar» y «Limpiar filtro»; el rango de fechas con atajos |
| `pb_resumen` / `pb_registros` | `module-summary`: el conteo filtrado y la página |
| `pb_tabla` / `pb_tabla_fin` | `table-zone` > `table.table…dataTable`, y su `record-cards` |
| `pb_acciones`, `pb_detalle` / `pb_accion_detalle`, `pb_accion_modal`, `pb_accion_post`, `pb_dar_baja` | La columna Acción: Ver, Actualizar, transiciones confirmadas y baja |
| `pb_tabla_captura` / `pb_tabla_captura_fin` | `table-responsive` sin DataTables, para tablas con campos por renglón |
| `pb_fila_vacia` | El renglón vacío, que pasa a ser el `emptyTable` y la tarjeta vacía |
| `pb_modal` / `pb_abre_modal` / `pb_modal_fin` | El modal de alta y edición de la plantilla base |
| `pb_seccion` | `form-section` con su `form-section-title` |
| `pb_campo` | `form-label` + `form-control` / `form-select` + `invalid-feedback[data-error-for]`. Sus opciones son `largo`, `minimo`, `maximo`, `paso`, `marcador`, `modo`, `autocompletado`, `patron` y `filas`; también acepta el nombre de HTML (`step`, `min`, `maxlength`…). El id sale del nombre y es **único en la página**: el segundo `id_sucursal` (filtros y modal) lleva `-2` |
| `pb_insignia` / `pb_estatus` | `badge rounded-pill text-bg-*` / `status-active`, `status-inactive` |
| `pb_aviso` | `alert alert-*`, que además se anuncia con SweetAlert2: el **éxito** en el diálogo «Operación correcta», que espera a «Aceptar», y la franja se esconde; el error y la advertencia también en un diálogo |
| `pb_cantidad` | Una cantidad como la lee una persona: `102.000` → `102`, `1500.500` → `1,500.5`. Sin redondeo. **No** va dentro de `value`, `min` o `max` de un campo numérico: la coma lo rompe |
| `pb_fecha` | `2026-10-07 13:45:12` → `07 oct 2026, 13:45`; `2026-10-07` → `07 oct 2026`. Tampoco va en el `value` de un campo de fecha |
| `pb_dinero` | `$1,234.50`. Ningún importe se pinta con `$` pegado a mano |
| `pb_qr` | Un código QR como SVG en línea, dibujado en el servidor por `Dominio\CodigoQr`, con su zona de silencio y `role="img"` con nombre. Sin librerías ni servicios externos: lo usan el segundo factor y el QR de mesa |
| `pb_llave` | El campo oculto con la llave de envío único (`#[Accion(unaVez: true)]`) |
| `pb_vacio` | `module-state module-state--empty` |
| `pb_ico` | `<i class="bi bi-…">` o `<i class="fa fa-…">` |

### 4.1 Diálogos (D25.2)

SweetAlert2 no se usa con su aspecto de fábrica. [`alertas.js`](../../publico/recursos/alertas.js)
se carga justo después de la librería y cambia `window.Swal` por una subclase de
un `mixin`. Por eso `window.alerts` (de `plantilla/main.js`, que no se toca) y
`plantilla.js` siguen llamando igual. El aspecto vive en el bloque «Diálogos
(D25.2)» de `tema.css`.

| Pieza | Cómo es |
|---|---|
| Disposición | Alineada a la izquierda: la insignia del icono junto al título, el texto debajo y los botones a la derecha. Blanca, con orilla `--app-border`, radio `--pb-radio` y sombra `--app-shadow`, de `min(30rem, 100vw − 2rem)` de ancho |
| Insignia | 44 px y radio de 12, con fondo tenue y glifo de Bootstrap Icons. Éxito: verde `#146C43` sobre `#E7F3EC`, con la palomita en SVG que se dibuja una vez. Error y peligro: `#B02A37` sobre `#FBE9EB`. Aviso: el par de estatus de advertencia. Info y pregunta: el par de estatus info. Todos de 5.5:1 o más |
| Título y texto | Sora 1.125 rem 600; texto en `--app-muted`, 0.95 rem e interlineado 1.5. Las cifras de `strong` son tabulares |
| Botones | Los de Bootstrap de la casa (`btn-primary`, `btn-outline-secondary`, `btn-danger`), de 44 px de alto como mínimo y con el anillo de foco. A 575 px o menos se apilan a lo ancho, con la acción principal arriba |
| Fondo | Tinta al 45 % con `blur(2px)`, en lugar del negro al 40 % |
| Movimiento | Entra en 220 ms (sube 8 px, escala 0.97 → 1, desacelerando) y sale en 140 ms (acelerando); el fondo, en 200 y 140 ms. Con «reducir movimiento», solo opacidad en 120 ms y la palomita ya dibujada |
| Carga | `alerts.loading`: la rueda marina a la izquierda del texto, sin insignia, y «Cancelar» con contorno |

`fire()` acepta además `tono: 'peligro'`: el icono de alerta octagonal y el
botón rojo.

**Confirmaciones (`form[data-confirma]`).** El botón de confirmar repite el
verbo del que se pulsó («Dar de baja», «Registrar entrada»), no «Confirmar».
`data-confirma-accion` lo da a mano. Van en **peligro** si el formulario trae
`data-confirma-tono="peligro"`, si el botón es `btn-danger`, `btn-outline-danger`
o `text-danger` (las bajas de `pb_dar_baja`), o si está dentro de
`form-section--danger`. Si el verbo empieza con «Cancelar», el botón de salida
dice «Volver». El foco abre en el de salida (`focusCancel`).

### 4.2 Movimiento (D25.3)

Un solo lenguaje de movimiento para el panel y el sitio. La intensidad es
**sobria operativa**: nada en bucle salvo lo que está trabajando.

| Token | Valor | Uso |
|---|---|---|
| Entrada | 220 ms, `cubic-bezier(.2,.8,.2,1)` (`--pb-curva-entra`; `CURVA_ENTRA` en la app) | Aparecer, abrir |
| Salida | 140 ms, `cubic-bezier(.4,0,1,1)` | Cerrar, quitar |
| Revelado | 260 ms: sube 6 px desde `blur(4px)` (la app no desenfoca); 40 ms entre hermanos, tope en el octavo | Tarjetas y renglones al cargar |
| Pulsación | Escala 0.97 en 90 ms y regreso con resorte (`damping` 18, `stiffness` 320); 0.98 en tarjetas y renglones | Botones y tocables |
| Cifras | 600 ms desacelerando, del valor anterior al nuevo; la primera vez desde 0 | Indicadores del Tablero, «N por subir» |
| Movimiento reducido | Panel y landing: quieto (la regla general de `tema.css` y la de `estilo.css`). App: fundido de 120 ms y las cifras saltan al valor final | Siempre |

**Panel** (bloque «Movimiento (D25.3)» de `tema.css`):

- revelan `.module-card`, `.summary-tile`, `.metric-card`, `.inicio-acceso`,
  `.form-section` y las tarjetas de `.record-cards`. `plantilla.js` pone `--pb-i`
  en el orden de la página y, 1.2 s después de cargar, la clase `pb-revelado`
  en `<html>`: lo que entra después (el Tablero que se actualiza solo, otra
  página de una tabla) ya no se revela;
- ⚠️ las animaciones van con `backwards`, nunca `both` ni `forwards`: un
  `transform` o `filter` que se queda puesto encierra a los modales que viven
  dentro de una `module-card`;
- `a.summary-tile` e `.inicio-acceso` suben 2 px con sombra al pasar el ratón
  y ceden a 0.98 al pulsar; `.btn` cede a 0.97;
- los modales de Bootstrap entran con la curva de los diálogos (8 px y 0.97)
  sobre el mismo fondo de tinta al 45 % con desenfoque; los submenús se
  despliegan en 220 ms y la orilla de la sección activa se dibuja al cargar;
- **cifras:** `window.pbCifras` hace rodar el `strong` de `.summary-tile` y
  `.metric-card` cuando entra en pantalla. El valor real queda en un `<data>`
  `visually-hidden` y lo que rueda va en otro con `aria-hidden`; son `<data>`
  y no `<span>` porque la plantilla da a todo `span` de la tarjeta el aspecto
  de la etiqueta. `tablero.js` lee las cifras antes de reemplazar el bloque y
  las hace rodar del valor anterior al nuevo.

**Sitio**: `landing.js` pone la clase `con-movimiento` en `<html>` y un
`IntersectionObserver` revela las secciones al entrar en pantalla. Sin
JavaScript, o con movimiento reducido, todo está visible y quieto. El carrusel
de especialidades se mueve con flechas y desplazamiento nativo; las flechas se
ocultan cuando todo cabe.

**App de comanda**: transiciones cortas de React Native; ningún bucle salvo el
indicador de lo que está cargando o imprimiendo.

## 5. Las pantallas

Cada pantalla es **una sola `module-card`**, en el orden de la plantilla base:

1. `module-header` con icono, título, descripción y acciones.
2. `module-filters`: los campos como hijos directos de la rejilla y
   `filter-actions` con «Consultar» y «Limpiar» (y «Hoy» cuando hay fecha,
   con `pb_filtros_fin($limpiar, true)`). Desde 768 px, `filter-actions` toma
   las dos últimas columnas de su renglón, en fila y a la derecha. Bajo 768 px, con tres campos
   o más, `plantilla.js` los pliega tras una barra que dice qué está aplicado
   («Fecha: 06/10/2026 · Sucursal: Centro») y un botón «Filtros (2)» con
   `aria-expanded`; con un error se quedan abiertos. `data-pb-plegable="0"`
   en el formulario lo evita.
3. `module-summary`: el conteo y, si aplica, el total.
4. `table-zone` con DataTables, y `record-cards` debajo de 768 px. El primer
   encabezado lleva `data-pb-titulo`; el estado, `data-pb-insignia`, y la
   columna Acción, `data-pb-acciones`. Vacía, la
   tabla muestra lo mismo que la tarjeta vacía del teléfono: icono, título y
   explicación (`data-pb-vacio-icono` y `data-pb-vacio-texto`).
5. El alta y la edición en un **modal** de la plantilla base (`pb_modal`), con
   `form-section` y `form-grid` adentro. El mismo modal sirve para las dos: el
   botón que lo abre (`pb_abre_modal`) le dice a dónde mandar y con qué llenarlo.
   Se manda por `fetch` (`form[data-pb-ajax]` en `plantilla.js`): un 422 pinta
   cada queja bajo su campo sin cerrar el modal. Sin JavaScript, el POST de
   siempre con su redirección. Ver usa `pb_detalle` / `pb_accion_detalle` y
   Actualizar `pb_accion_modal` con la URL del registro: los dos piden la ficha
   actual al servidor. Una transición confirmada usa `pb_accion_post`.

Reglas que se cumplen en todas:

- **Una acción principal responde qué sigue.** Las acciones secundarias no
  compiten por color ni posición; lo destructivo queda separado y confirmado.
- **Un 422 se entiende y se recorre.** El formulario crea un resumen con
  `role="alert"`, recibe foco, enlaza cada mensaje con su control y conserva el
  error junto al campo mediante `aria-describedby`.
- **Todo objetivo interactivo mide al menos 24 px en escritorio y 44 px hasta
  480 px.** El anillo de foco se ve también en los controles nativos de fecha,
  cuyo foco interno se detecta con `:focus-within`.
- **Las tablas y sus tarjetas conservan la misma información y acciones.** El
  barrido a 375, 768, 1024 y 1440 px vigila que no haya desbordamiento de página.

- **Tablas de captura sin DataTables.** DataTables saca del DOM los renglones
  que no están en la página visible, y las tarjetas duplican los campos: una
  compra llegaría incompleta. Los renglones de una compra y los precios en lote
  usan `pb_tabla_captura`.
- Las acciones de renglón miden al menos 24 px de alto con ratón y 44 px en
  pantalla táctil (`pointer: coarse`).
- Los números van en `text-end`.
- El tablero y los índices usan `metric-card`; los cortes usan `summary-tile`.
- Las fichas usan `detail-list`.
- **Una cantidad pasa por `pb_cantidad`, una fecha por `pb_fecha` y un importe
  por `pb_dinero`** (bitácora 96). En un listado, la celda con fecha lleva
  `data-order` con el valor crudo: DataTables ordenaría «07 oct» como texto.
- **Las tablas `simple` son fichas cortas**: sin flechas de orden y sin el
  mínimo de 680 px de los listados. `pb_tabla(..., true)` («ancha», 820 px) sólo
  para tablas con muchas columnas, como el resultado del conteo.
- **El lenguaje es del mostrador y del almacén, no del sistema.** Nada de
  FIFO, FEFO, UMV, TOTP, HMAC, «versionada», «inmutable» o «ciego» en avisos y
  descripciones de pantallas operativas: «sale primero el lote más antiguo»,
  «en sucursal (unidades)», «el código de su teléfono», «ya no se puede
  cambiar». La web habla de usted; la app de comanda, también (ver la [guía de textos](../../docs/textos/guia-de-textos.md)).
- Lo destructivo va en `form-section--danger` y se confirma con SweetAlert2
  (`data-confirma`), en el tono de peligro de §4.1. Apagar el segundo factor en «Seguridad» es así, aunque ya
  pida contraseña y código.
- La caja de error de un formulario (`[data-pb-error]`) lleva `scroll-margin-top`:
  `plantilla.js` la desplaza a la vista y, sin el margen, la barra fija le tapaba
  el primer renglón en el teléfono (bitácora 98).
- Platillos usa `table-avatar` para la miniatura del listado e
  `image-upload-preview` con `file-upload` para la foto; la vista previa sale de
  `data-pb-vista-previa`.
- Los formularios largos ocupan todo el alto en teléfono, con cabecera y pie
  fijos dentro del modal; el contenido central es el único que desplaza.

## 6. El armazón

El de la plantilla base, en [`base.php`](../../vistas/plantilla/base.php):
`app-shell`, `app-sidebar` con `app-brand` (el símbolo) y `app-menu`
(`app-menu__link`, `app-menu__toggle` y sus colapsables), `app-topbar` con el
antetítulo `MÓDULO · SUCURSAL` y `app-user-menu`, `app-main` y `app-footer`. Un
enlace «Saltar al contenido» va primero.

Los grupos del [menú](../../vistas/plantilla/menu.php) siguen el trabajo del
restaurante: **Tablero**, **Salón y carta**, **Equipos y ventas**, **Almacén y
compras** y **Negocio y seguridad**. La misma lista alimenta los accesos del
Tablero. Cada entrada aparece solo si el perfil tiene su permiso.

La entrada ([`limpia.php`](../../vistas/plantilla/limpia.php) y
[`entrada/formulario.php`](../../vistas/entrada/formulario.php)) es el login de
la plantilla base con la fotografía de El Timón: `.login` > `.auth-card` con
`auth-form` y `auth-hero`. La página de error de `Nucleo\ManejadorErrores` usa
las mismas hojas.

## 7. Fuera del armazón

El ticket de 58 mm y las hojas impresas (`plantilla/papel.php`,
`impresion.css`, `ticket.css`, `hoja.css`) no usan la plantilla base ni color: una
impresora térmica no imprime grises. Sus medidas se tomaron contra la impresora
y no cambian.

## 8. La app de comanda

Expo universal: nativa en Android e iPad y PWA en las PC con Windows. El
puesto del equipo decide qué abre: **Salón** (mesero), **Caja**, **Cocina** o
barra, e **Impresor**.

| Ancho | Disposición |
|---|---|
| Teléfono, menos de 740 | Una columna: mesas, cuenta y carta apiladas |
| Tableta, 740–1199 | `DosPaneles`: cuenta a la izquierda; carta, cobro o separar a la derecha |
| Escritorio, 1200 o más | Lo mismo, con la caja y el mostrador a dos paneles |

Los anchos viven en `app/src/nucleo/disposicion.ts` (`TABLETA`, `ESCRITORIO`).

Piezas de [`ui.tsx`](../../app/src/componentes/ui.tsx): `Boton`, `Campo`,
`Aviso`, `Insignia` (tonos `neutro`, `primario`, `exito`, `aviso`, `riesgo`),
`Pestanas`, `Contador`, `Dialogo`, `Cargando`, `Tostada` y `DosPaneles`.

Reglas de la app:

- **44 pt** de área pulsable y 8 de separación entre dos objetivos; respuesta
  visual inmediata al pulsar.
- Los estados de mesa y de comanda llevan **texto**, no solo color. El
  semáforo de cocina cambia a los 10 y a los 20 minutos.
- La conexión y lo pendiente por enviar se ven siempre. «Sin conexión» y
  «falla del servicio» son avisos distintos y se limpian solos.
- La cola de envío nunca regenera la llave: un rechazo marca solo ese renglón.
- «Cobrar» siempre está activo y, si aún no se puede, dice por qué.
- Ningún color escrito a mano fuera de `marca.ts` y `tintes`.

## 9. Lista de comprobación antes de entregar

Panel:

- [ ] Sin desplazamiento horizontal de página en 1440, 768 y 375 px
- [ ] Barra lateral, cajón y `is-active` correctos en los tres anchos
- [ ] Recorrido completo con `Tab`, con «Saltar al contenido» primero
- [ ] Los colores salen de `/marca/tema.css`; ningún azul de la plantilla base a la vista
- [ ] Anillo de foco visible en todo control, también sobre la tinta
- [ ] Contraste AA medido, no estimado (`genera-marca.mjs --verifica` y el navegador)
- [ ] Zoom al 200 % sin pérdida de contenido
- [ ] `prefers-reduced-motion` respetado
- [ ] Tabla y tarjeta con la **misma** información y las **mismas** acciones
- [ ] Listado, conteo y XLS con el mismo conjunto de filtros
- [ ] Ninguna tabla con campos por renglón monta DataTables
- [ ] Ningún id repetido en la página (filtros y modal comparten nombres)
- [ ] Filtros plegados a 375 px, con lo aplicado a la vista
- [ ] Ninguna cantidad con `.000`, ninguna fecha `AAAA-MM-DD HH:MM:SS` y ningún `$` pegado a mano
- [ ] Un éxito se anuncia una vez, en el diálogo «Operación correcta»
- [ ] Una confirmación dice el verbo del botón pulsado, y lo destructivo va en rojo (§4.1)
- [ ] Un QR nuevo se comprueba leyéndolo, no mirándolo
- [ ] Al subir `tema.css`, `plantilla.js`, `estilo.css` o `landing.js`, su `?v=` cambia

Sitio:

- [ ] Con y sin sucursales publicadas: nada inventado, los huecos lo dicen
- [ ] Barra fija en el celular; «Abierto ahora» según el horario del día
- [ ] Menú QR con la mesa solo si es de esa sucursal

App:

- [ ] Sin emoji como icono
- [ ] 44 pt, respuesta al pulsar y `accessibilityLabel` en todo lo pulsable
- [ ] Teléfono, tableta y PC con su disposición; áreas seguras arriba y abajo
- [ ] Estado sin conexión con icono y palabra
- [ ] Teclado correcto por campo
