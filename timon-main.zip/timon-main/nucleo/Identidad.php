<?php
declare(strict_types=1);

namespace Nucleo;

use Nucleo\Errores\Errores;

/**
 * Quién está pidiendo esto, qué puede hacer y **dónde**.
 *
 * El usuario siempre es una persona del personal con un puesto: los permisos
 * son los de su puesto, y el alcance —qué sucursales— es su sucursal base más
 * las que tenga asignadas en `usuario_sucursal`. El administrador ve todas.
 *
 * Los permisos y las sucursales se traen **una vez** al establecer la
 * identidad y se guardan para toda la petición. Preguntar "¿puede?" veinte
 * veces no cuesta veinte consultas.
 *
 * El backend es la autoridad. Que la pantalla esconda un botón no protege
 * nada: la comprobación vive aquí y corre siempre, venga de donde venga.
 * `ExigePermiso` contesta **qué** puede hacer; si puede hacerlo **en esa
 * sucursal** lo preguntan los servicios con `exigeSucursal()`, porque solo
 * ellos saben sobre qué registro se actúa.
 */
final class Identidad
{
    public const ADMINISTRADOR = 'administrador';

    /** Quienes mueven dinero, inventario o accesos: más candados en la entrada y en la sesión. */
    public const PUESTOS_SENSIBLES = ['administrador', 'gerente', 'cajero', 'almacen'];

    /** @var array<string,mixed>|null */
    private ?array $usuario = null;
    /** @var array<string,true> */
    private array $permisos = [];
    /** @var list<int> */
    private array $sucursales = [];

    public function __construct(private BaseDatos $bd)
    {
    }

    /** Carga al usuario, sus permisos y su alcance. Tres consultas, y ya. */
    public function establece(int $idUsuario): void
    {
        // La sucursal viaja en la MISMA consulta: la barra superior la pinta en
        // cada pantalla. `LEFT JOIN` porque el rótulo no puede decidir si
        // alguien entra; la persona y el puesto, sí.
        $usuario = $this->bd->fila(
            "SELECT u.id, u.usuario, u.cambiar_clave, u.sesion_version, u.totp_confirmado_en,
                    p.id AS id_personal,
                    TRIM(CONCAT(p.nombre, ' ', p.apellido_paterno, ' ', COALESCE(p.apellido_materno, ''))) AS nombre,
                    p.id_sucursal, b.nombre AS sucursal,
                    pu.id AS id_puesto, pu.clave AS puesto, pu.nombre AS nombre_puesto, pu.usa_app
             FROM usuario u
             JOIN personal p  ON p.id = u.id_personal AND p.id_estatus = 4
             JOIN puesto pu   ON pu.id = p.id_puesto AND pu.id_estatus = 4
             LEFT JOIN sucursal b ON b.id = p.id_sucursal
             WHERE u.id = ? AND u.id_estatus = 4
               AND (u.acceso_hasta IS NULL OR u.acceso_hasta > NOW())",
            [$idUsuario]
        );

        if ($usuario === null) {
            // Existía al entrar y ya no: la sesión no puede seguir valiendo.
            throw Errores::noAutenticado('Cuenta inactiva');
        }

        $this->usuario = $usuario;

        $this->permisos = [];
        foreach ($this->bd->filas(
            'SELECT pe.clave
             FROM puesto_permiso pp
             JOIN permiso pe ON pe.id = pp.id_permiso
             WHERE pp.id_puesto = ?',
            [(int) $usuario['id_puesto']]
        ) as $fila) {
            $this->permisos[(string) $fila['clave']] = true;
        }

        $sucursales = array_map(
            static fn (array $f): int => (int) $f['id_sucursal'],
            $this->bd->filas('SELECT id_sucursal FROM usuario_sucursal WHERE id_usuario = ?', [$idUsuario])
        );
        if ($usuario['id_sucursal'] !== null) {
            array_unshift($sucursales, (int) $usuario['id_sucursal']);
        }
        $this->sucursales = array_values(array_unique($sucursales));
    }

    public function hay(): bool
    {
        return $this->usuario !== null;
    }

    /** @return array<string,mixed> */
    public function usuario(): array
    {
        if ($this->usuario === null) {
            throw Errores::noAutenticado();
        }

        return $this->usuario;
    }

    public function id(): int
    {
        return (int) $this->usuario()['id'];
    }

    /** La persona del personal detrás del usuario (D12: siempre hay una). */
    public function idPersonal(): int
    {
        return (int) $this->usuario()['id_personal'];
    }

    /** Si entró con una contraseña temporal que todavía no cambia. */
    public function debeCambiarClave(): bool
    {
        return (int) $this->usuario()['cambiar_clave'] === 1;
    }

    public function sesionVersion(): int
    {
        return (int) $this->usuario()['sesion_version'];
    }

    public function nombre(): string
    {
        return (string) $this->usuario()['nombre'];
    }

    public function puesto(): string
    {
        return (string) $this->usuario()['puesto'];
    }

    public function esPuestoSensible(): bool
    {
        return in_array($this->puesto(), self::PUESTOS_SENSIBLES, true);
    }

    /** Su puesto trabaja en la app de comanda (mesero, cocina, caja…). */
    public function usaApp(): bool
    {
        return (int) ($this->usuario()['usa_app'] ?? 0) === 1;
    }

    public function esAdministrador(): bool
    {
        return $this->puesto() === self::ADMINISTRADOR;
    }

    /** La sucursal de la persona. `null` solo para quien ve todas. */
    public function idSucursal(): ?int
    {
        $sucursal = $this->usuario()['id_sucursal'];

        return $sucursal === null ? null : (int) $sucursal;
    }

    /** @return list<int> Sucursales que alcanza. Vacía para el administrador, que ve todas. */
    public function sucursales(): array
    {
        return $this->esAdministrador() ? [] : $this->sucursales;
    }

    public function alcanzaSucursal(int $idSucursal): bool
    {
        return $this->esAdministrador() || in_array($idSucursal, $this->sucursales, true);
    }

    public function exigeSucursal(int $idSucursal): void
    {
        if (!$this->alcanzaSucursal($idSucursal)) {
            throw Errores::prohibido('Esa sucursal no es de su alcance');
        }
    }

    public function puede(string $permiso): bool
    {
        return isset($this->permisos[$permiso]);
    }

    /** @return list<string> */
    public function permisos(): array
    {
        return array_keys($this->permisos);
    }

    public function exige(string $permiso): void
    {
        if (!$this->hay()) {
            throw Errores::noAutenticado();
        }

        if (!$this->puede($permiso)) {
            throw Errores::prohibido('Sin acceso. Avise al administrador.', $permiso);
        }
    }

    public function olvida(): void
    {
        $this->usuario = null;
        $this->permisos = [];
        $this->sucursales = [];
    }
}
