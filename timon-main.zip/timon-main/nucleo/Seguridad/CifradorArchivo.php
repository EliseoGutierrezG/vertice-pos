<?php
declare(strict_types=1);

namespace Nucleo\Seguridad;

use RuntimeException;

/**
 * Cifra un archivo completo para que pueda salir del hospedaje (fase 29).
 *
 * El respaldo lleva la operación entera del negocio. La copia que se guarda
 * fuera del hosting —en la computadora del dueño o en otra nube— tiene que
 * viajar cifrada: si esa copia se pierde, lo que se pierde es ruido.
 *
 * - **XChaCha20-Poly1305 en flujo** (`sodium_crypto_secretstream`), por bloques
 *   de 64 KB: un respaldo de cientos de megas no se carga entero en memoria del
 *   hospedaje compartido.
 * - **Cada bloque va autenticado** y el último lleva la marca final: un archivo
 *   alterado, truncado o cifrado con otra llave no se descifra a medias, falla.
 * - La llave (32 bytes en Base64) vive fuera de la base y fuera de `publico/`,
 *   en `config/respaldo.php`. Sin ella el archivo no sirve: el dueño guarda una
 *   copia de la llave aparte del hospedaje.
 *
 * Formato: `BASE-RESPALDO-1\n`, la cabecera del flujo (24 bytes) y después cada
 * bloque como longitud de 4 bytes (big endian) seguida del bloque cifrado.
 */
final class CifradorArchivo
{
    public const FIRMA = "BASE-RESPALDO-1\n";
    private const BLOQUE = 65536;

    private string $llave;

    public function __construct(string $llaveBase64)
    {
        $llave = base64_decode($llaveBase64, true);
        if (!is_string($llave) || strlen($llave) !== SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_KEYBYTES) {
            throw new RuntimeException('La llave de respaldo debe ser Base64 de 32 bytes');
        }
        $this->llave = $llave;
    }

    public static function generaLlave(): string
    {
        return base64_encode(sodium_crypto_secretstream_xchacha20poly1305_keygen());
    }

    /** Cifra `$origen` en `$destino` (que no debe existir). */
    public function cifra(string $origen, string $destino): void
    {
        if (file_exists($destino)) {
            throw new RuntimeException('Ya existe ' . basename($destino) . '; no se sobrescribe');
        }
        $entrada = self::abre($origen, 'rb');
        $temporal = $destino . '.tmp-' . bin2hex(random_bytes(4));
        $salida = self::abre($temporal, 'xb');
        $estado = '';

        try {
            [$estado, $cabecera] = sodium_crypto_secretstream_xchacha20poly1305_init_push($this->llave);
            self::escribe($salida, self::FIRMA . $cabecera);

            // Se lee un bloque adelantado para saber cuál es el último y marcarlo.
            $actual = self::lee($entrada);
            do {
                $siguiente = $actual === '' ? '' : self::lee($entrada);
                $marca = $siguiente === ''
                    ? SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL
                    : SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_MESSAGE;
                $cifrado = sodium_crypto_secretstream_xchacha20poly1305_push($estado, $actual, '', $marca);
                self::escribe($salida, pack('N', strlen($cifrado)) . $cifrado);
                $actual = $siguiente;
            } while ($marca !== SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL);

            fclose($salida);
            fclose($entrada);
            if (!rename($temporal, $destino)) {
                throw new RuntimeException('No se pudo dejar el archivo cifrado en su lugar');
            }
            @chmod($destino, 0640);
        } catch (\Throwable $e) {
            if (is_resource($salida)) fclose($salida);
            if (is_resource($entrada)) fclose($entrada);
            @unlink($temporal);
            throw $e;
        } finally {
            sodium_memzero($estado);
        }
    }

    /**
     * Descifra `$origen`. Con `$destino` null sólo comprueba que el archivo
     * esté completo e íntegro. Devuelve el SHA-256 del contenido en claro.
     */
    public function descifra(string $origen, ?string $destino = null): string
    {
        if ($destino !== null && file_exists($destino)) {
            throw new RuntimeException('Ya existe ' . basename($destino) . '; no se sobrescribe');
        }
        $entrada = self::abre($origen, 'rb');
        $temporal = $destino === null ? null : $destino . '.tmp-' . bin2hex(random_bytes(4));
        $salida = $temporal === null ? null : self::abre($temporal, 'xb');
        $huella = hash_init('sha256');

        try {
            $inicio = fread($entrada, strlen(self::FIRMA) + SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_HEADERBYTES);
            if (!is_string($inicio) || !str_starts_with($inicio, self::FIRMA)
                || strlen($inicio) !== strlen(self::FIRMA) + SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_HEADERBYTES) {
                throw new RuntimeException('El archivo no es un respaldo cifrado de El Timón');
            }
            $estado = sodium_crypto_secretstream_xchacha20poly1305_init_pull(substr($inicio, strlen(self::FIRMA)), $this->llave);

            $final = false;
            while (!$final) {
                $largo = fread($entrada, 4);
                if (!is_string($largo) || strlen($largo) !== 4) {
                    throw new RuntimeException('El respaldo cifrado está incompleto');
                }
                $tamano = unpack('N', $largo)[1];
                $maximo = self::BLOQUE + SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_ABYTES;
                if ($tamano < SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_ABYTES || $tamano > $maximo) {
                    throw new RuntimeException('El respaldo cifrado está dañado');
                }
                $bloque = self::leeExacto($entrada, $tamano);
                $resultado = sodium_crypto_secretstream_xchacha20poly1305_pull($estado, $bloque);
                if ($resultado === false) {
                    throw new RuntimeException('El respaldo cifrado fue alterado o la llave no corresponde');
                }
                [$claro, $marca] = $resultado;
                hash_update($huella, $claro);
                if ($salida !== null) {
                    self::escribe($salida, $claro);
                }
                $final = $marca === SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL;
            }
            if (fread($entrada, 1) !== '') {
                throw new RuntimeException('El respaldo cifrado trae datos después del final');
            }

            fclose($entrada);
            if ($salida !== null && $temporal !== null && $destino !== null) {
                fclose($salida);
                if (!rename($temporal, $destino)) {
                    throw new RuntimeException('No se pudo dejar el respaldo descifrado en su lugar');
                }
                @chmod($destino, 0640);
            }
            return hash_final($huella);
        } catch (\Throwable $e) {
            if (is_resource($entrada)) fclose($entrada);
            if (is_resource($salida)) fclose($salida);
            if ($temporal !== null) @unlink($temporal);
            throw $e;
        }
    }

    /** @return resource */
    private static function abre(string $ruta, string $modo)
    {
        $manejador = @fopen($ruta, $modo);
        if ($manejador === false) {
            throw new RuntimeException('No se pudo abrir ' . basename($ruta));
        }
        return $manejador;
    }

    /** @param resource $manejador */
    private static function lee($manejador): string
    {
        $bloque = '';
        while (strlen($bloque) < self::BLOQUE && !feof($manejador)) {
            $parte = fread($manejador, self::BLOQUE - strlen($bloque));
            if ($parte === false) {
                throw new RuntimeException('No se pudo leer el respaldo');
            }
            $bloque .= $parte;
        }
        return $bloque;
    }

    /** @param resource $manejador */
    private static function leeExacto($manejador, int $tamano): string
    {
        $bloque = '';
        while (strlen($bloque) < $tamano) {
            $parte = fread($manejador, $tamano - strlen($bloque));
            if ($parte === false || $parte === '') {
                throw new RuntimeException('El respaldo cifrado está incompleto');
            }
            $bloque .= $parte;
        }
        return $bloque;
    }

    /** @param resource $manejador */
    private static function escribe($manejador, string $texto): void
    {
        $escritos = fwrite($manejador, $texto);
        if ($escritos === false || $escritos < strlen($texto)) {
            throw new RuntimeException('Se escribió a medias: el archivo no sirve');
        }
    }
}
