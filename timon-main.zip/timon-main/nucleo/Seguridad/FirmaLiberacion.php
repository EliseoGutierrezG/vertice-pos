<?php
declare(strict_types=1);

namespace Nucleo\Seguridad;

use RuntimeException;

/**
 * La firma de los paquetes que actualizan las computadoras de sucursal.
 *
 * Ed25519 (`sodium_crypto_sign`) sobre el id, el esquema y el sha256 del
 * paquete: quien cambie un byte del paquete o le ponga otro nombre rompe la
 * firma. La llave privada vive solo en la máquina que arma los paquetes
 * (`guiones/genera-llave-firma.php`); la pública viaja con el código en
 * `config/firma-liberaciones.pub`. Así, ni quien entre al hospedaje del
 * central puede mandar código a una sucursal.
 *
 * La computadora comprueba con la llave del código que **ya tiene**, no con la
 * del paquete nuevo: cambiar de llave es mandar una versión firmada con la
 * anterior que ya traiga la nueva.
 */
final class FirmaLiberacion
{
    public const ARCHIVO = 'config/firma-liberaciones.pub';
    private const PREFIJO = "timon-liberacion-1\n";

    /** @return array{publica:string,privada:string} Las dos en Base64. */
    public static function generaPar(): array
    {
        $par = sodium_crypto_sign_keypair();

        return [
            'publica' => base64_encode(sodium_crypto_sign_publickey($par)),
            'privada' => base64_encode(sodium_crypto_sign_secretkey($par)),
        ];
    }

    /** La llave pública del código instalado, o null si todavía no se generó. */
    public static function publicaDe(string $raiz): ?string
    {
        $ruta = rtrim($raiz, '/') . '/' . self::ARCHIVO;
        if (!is_file($ruta)) {
            return null;
        }
        $llave = trim((string) file_get_contents($ruta));
        $bytes = base64_decode($llave, true);
        if (!is_string($bytes) || strlen($bytes) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
            throw new RuntimeException(self::ARCHIVO . ' no es una llave pública Ed25519 en Base64');
        }

        return $llave;
    }

    /**
     * El descriptor que acompaña al paquete, ya firmado.
     *
     * @return array{id:string,esquema:int,sha256:string,peso:int,firma:string}
     */
    public static function firma(string $id, int $esquema, string $paquete, string $privadaBase64): array
    {
        $privada = base64_decode($privadaBase64, true);
        if (!is_string($privada) || strlen($privada) !== SODIUM_CRYPTO_SIGN_SECRETKEYBYTES) {
            throw new RuntimeException('La llave privada de firma no es válida');
        }
        $sha = hash_file('sha256', $paquete);
        if ($sha === false) {
            throw new RuntimeException('No se pudo leer el paquete');
        }
        $descriptor = ['id' => $id, 'esquema' => $esquema, 'sha256' => $sha, 'peso' => (int) filesize($paquete)];
        self::exigeForma($descriptor + ['firma' => str_repeat('A', 86) . '==']);

        return $descriptor + ['firma' => base64_encode(sodium_crypto_sign_detached(self::mensaje($descriptor), $privada))];
    }

    /**
     * ¿El descriptor está firmado por esa llave? No mira el paquete: para eso
     * está `verificaPaquete`.
     *
     * @param array<string,mixed> $descriptor
     */
    public static function verifica(array $descriptor, string $publicaBase64): bool
    {
        try {
            self::exigeForma($descriptor);
        } catch (RuntimeException) {
            return false;
        }
        $publica = base64_decode($publicaBase64, true);
        $firma = base64_decode((string) $descriptor['firma'], true);
        if (!is_string($publica) || strlen($publica) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES
            || !is_string($firma) || strlen($firma) !== SODIUM_CRYPTO_SIGN_BYTES) {
            return false;
        }

        return sodium_crypto_sign_verify_detached($firma, self::mensaje($descriptor), $publica);
    }

    /**
     * El paquete en disco es el del descriptor (peso y sha256) y la firma es
     * buena. Lanza con el motivo; un paquete que no pasa no se instala.
     *
     * @param array<string,mixed> $descriptor
     */
    public static function verificaPaquete(array $descriptor, string $paquete, string $publicaBase64): void
    {
        if (!self::verifica($descriptor, $publicaBase64)) {
            throw new RuntimeException('La firma del paquete no es válida');
        }
        if (!is_file($paquete) || filesize($paquete) !== (int) $descriptor['peso']) {
            throw new RuntimeException('El paquete no tiene el tamaño firmado');
        }
        if (!hash_equals((string) $descriptor['sha256'], (string) hash_file('sha256', $paquete))) {
            throw new RuntimeException('El paquete no es el que se firmó');
        }
    }

    /** @param array<string,mixed> $descriptor */
    public static function exigeForma(array $descriptor): void
    {
        if (preg_match('/^[A-Za-z0-9._:-]{3,100}$/D', (string) ($descriptor['id'] ?? '')) !== 1
            || !is_int($descriptor['esquema'] ?? null) || $descriptor['esquema'] < 1
            || preg_match('/^[a-f0-9]{64}$/D', (string) ($descriptor['sha256'] ?? '')) !== 1
            || !is_int($descriptor['peso'] ?? null) || $descriptor['peso'] < 1
            || preg_match('#^[A-Za-z0-9+/]{86}==$#D', (string) ($descriptor['firma'] ?? '')) !== 1) {
            throw new RuntimeException('El descriptor del paquete no es válido');
        }
    }

    /** @param array<string,mixed> $descriptor */
    private static function mensaje(array $descriptor): string
    {
        return self::PREFIJO . $descriptor['id'] . "\n" . $descriptor['esquema'] . "\n" . $descriptor['sha256'] . "\n" . $descriptor['peso'] . "\n";
    }
}
