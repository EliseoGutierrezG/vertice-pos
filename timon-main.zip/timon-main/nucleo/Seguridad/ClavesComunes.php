<?php
declare(strict_types=1);

namespace Nucleo\Seguridad;

/**
 * Las contraseñas que el largo no detiene.
 *
 * Doce caracteres no bastan si son `123456789012`. La lista es local a propósito:
 * consultar un servicio externo mandaría fuera algo derivado de la contraseña.
 * Sólo trae lo que pasa el largo mínimo, porque lo demás ya se rechaza por corto,
 * y se le suman los patrones que ninguna lista alcanza a enumerar.
 *
 * No se fuerzan mayúsculas ni símbolos: empujan a `Timon2026!`, que es peor que
 * una frase larga.
 */
final class ClavesComunes
{
    /** Ya en minúsculas y sin acentos, que es como se comparan. */
    private const LISTA = [
        'contrasena123', 'contrasena1234', 'contrasenas123', 'micontrasena', 'micontrasena1',
        'password1234', 'password12345', 'password123456', 'passwordpassword', 'adminadmin12',
        'administrador', 'administrador1', 'administrador123', 'administrator', 'administrator1',
        'qwertyuiop12', 'qwertyuiop123', 'qwertyuiopas', 'asdfghjklzxc', 'zxcvbnmasdfg',
        'iloveyou1234', 'teamo1234567', 'teamomucho12', 'bienvenido12', 'bienvenido123',
        'bienvenidos1', 'bienvenidos12', 'bienvenidos123', 'distribuidora', 'distribuidora1',
        'eltimon12345', 'eltimon123456', 'timontimon12', 'timon1234567', 'timon12345678',
        'cambiame1234', 'cambiarclave', 'cambiarclave1', 'temporal1234', 'temporal12345',
        'mexico123456', 'mexico1234567', 'puebla123456', 'puebla1234567',
    ];

    public static function es(string $clave): bool
    {
        $limpia = self::normaliza($clave);

        return in_array($limpia, self::LISTA, true)
            || self::soloSeRepite($limpia)
            || self::esSecuencia($limpia);
    }

    private static function normaliza(string $clave): string
    {
        return strtr(mb_strtolower(trim($clave)), [
            'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n',
        ]);
    }

    /** `aaaaaaaaaaaa`, `abcabcabcabc`, `timon2026timon2026`: un trozo corto una y otra vez. */
    private static function soloSeRepite(string $clave): bool
    {
        return preg_match('/^(.{1,6})\1+$/su', $clave) === 1;
    }

    /** `123456789012`, `987654321098` o una hilera entera del teclado. */
    private static function esSecuencia(string $clave): bool
    {
        foreach (['1234567890', 'abcdefghijklmnopqrstuvwxyz', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm'] as $serie) {
            $vuelta = str_repeat($serie, 3);
            if (str_contains($vuelta, $clave) || str_contains(strrev($vuelta), $clave)) {
                return true;
            }
        }

        return false;
    }
}
