<?php
declare(strict_types=1);

namespace Nucleo\Seguridad;

use RuntimeException;

/** Sobre AES-256-GCM versionado. La llave se recibe desde configuración externa a la BD. */
final class Cifrador
{
    private string $llave;

    public function __construct(string $llaveBase64)
    {
        $llave = base64_decode($llaveBase64, true);
        if (!is_string($llave) || strlen($llave) !== 32) {
            throw new RuntimeException('La llave de segundo factor debe ser Base64 de 32 bytes');
        }
        $this->llave = $llave;
    }

    public function cifra(string $claro): string
    {
        $nonce = random_bytes(12);
        $etiqueta = '';
        $cifrado = openssl_encrypt($claro, 'aes-256-gcm', $this->llave, OPENSSL_RAW_DATA, $nonce, $etiqueta);
        if (!is_string($cifrado) || strlen($etiqueta) !== 16) {
            throw new RuntimeException('No fue posible cifrar el secreto de segundo factor');
        }

        return 'v1.' . self::b64($nonce) . '.' . self::b64($etiqueta) . '.' . self::b64($cifrado);
    }

    public function descifra(string $sobre): string
    {
        $partes = explode('.', $sobre);
        if (count($partes) !== 4 || $partes[0] !== 'v1') {
            throw new RuntimeException('El secreto de segundo factor tiene un formato desconocido');
        }
        [$version, $nonce64, $etiqueta64, $cifrado64] = $partes;
        unset($version);
        $nonce = self::desb64($nonce64);
        $etiqueta = self::desb64($etiqueta64);
        $cifrado = self::desb64($cifrado64);
        if (strlen($nonce) !== 12 || strlen($etiqueta) !== 16) {
            throw new RuntimeException('El secreto de segundo factor está dañado');
        }
        $claro = openssl_decrypt($cifrado, 'aes-256-gcm', $this->llave, OPENSSL_RAW_DATA, $nonce, $etiqueta);
        if (!is_string($claro)) {
            throw new RuntimeException('El secreto de segundo factor no se pudo autenticar');
        }
        return $claro;
    }

    private static function b64(string $valor): string
    {
        return rtrim(strtr(base64_encode($valor), '+/', '-_'), '=');
    }

    private static function desb64(string $valor): string
    {
        $relleno = (4 - strlen($valor) % 4) % 4;
        $resultado = base64_decode(strtr($valor . str_repeat('=', $relleno), '-_', '+/'), true);
        if (!is_string($resultado)) {
            throw new RuntimeException('El secreto de segundo factor está dañado');
        }
        return $resultado;
    }
}

