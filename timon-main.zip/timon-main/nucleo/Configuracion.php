<?php
declare(strict_types=1);

namespace Nucleo;

use RuntimeException;

/**
 * Selecciona la configuración del proceso sin depender del directorio actual.
 *
 * Apache/FPM y la línea de comandos controlan el entorno mediante
 * `APP_ENTORNO`. El entorno de pruebas usa archivos separados para que
 * una corrida destructiva no pueda heredar por accidente la base cotidiana.
 */
final class Configuracion
{
    private const ENTORNOS = ['local', 'pruebas', 'produccion'];

    /** @return array<string,mixed> */
    public static function aplicacion(string $raiz): array
    {
        $config = self::lee($raiz, 'app');
        $entornoDeclarado = (string) ($config['entorno'] ?? '');

        if (!in_array($entornoDeclarado, self::ENTORNOS, true)) {
            throw new RuntimeException('La configuración declara un entorno no permitido');
        }

        $controlado = self::entornoControlado();
        if ($controlado !== null && $controlado !== $entornoDeclarado) {
            throw new RuntimeException('APP_ENTORNO no coincide con la configuración cargada');
        }

        return $config;
    }

    /**
     * La conexión, más el reparto de ids de la instalación cuando hay
     * `config/instalacion.php`: con servidores de sucursal, cada instalación
     * genera ids que no chocan con los de las demás.
     *
     * @return array{host:string,base:string,usuario:string,clave:string,puerto:int,desplazamiento?:int}
     */
    public static function baseDatos(string $raiz): array
    {
        /** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
        $config = self::lee($raiz, 'bd');
        $instalacion = self::instalacion($raiz);
        if ($instalacion !== null) {
            $config['desplazamiento'] = $instalacion['desplazamiento'];
        }

        return $config;
    }

    /** Las instalaciones reparten ids de 100 en 100; cada una con su desplazamiento. */
    public const INCREMENTO_IDS = 100;

    /**
     * Qué es esta instalación: el central (desplazamiento 1) o el servidor de
     * una sucursal. `null` si no hay `config/instalacion.php`: una instalación
     * sola, sin servidores de sucursal.
     *
     * @return array{tipo:'central'|'sucursal',desplazamiento:int,id_sucursal:?int,url_central:?string,secreto:?string}|null
     */
    public static function instalacion(string $raiz): ?array
    {
        $sufijo = self::entornoControlado() === 'pruebas' ? '.pruebas' : '';
        $ruta = rtrim($raiz, '/') . '/config/instalacion' . $sufijo . '.php';
        if (!is_file($ruta)) {
            return null;
        }

        $datos = require $ruta;
        $tipo = is_array($datos) ? ($datos['tipo'] ?? null) : null;
        if ($tipo === 'central') {
            return ['tipo' => 'central', 'desplazamiento' => 1, 'id_sucursal' => null, 'url_central' => null, 'secreto' => null];
        }
        if ($tipo !== 'sucursal') {
            throw new RuntimeException('config/instalacion.php debe declarar tipo central o sucursal');
        }

        $desplazamiento = $datos['desplazamiento'] ?? null;
        $sucursal = $datos['id_sucursal'] ?? null;
        $url = (string) ($datos['url_central'] ?? '');
        $secreto = (string) ($datos['secreto'] ?? '');
        if (!is_int($desplazamiento) || $desplazamiento < 2 || $desplazamiento >= self::INCREMENTO_IDS) {
            throw new RuntimeException('El desplazamiento del servidor de sucursal va de 2 a 99');
        }
        if (!is_int($sucursal) || $sucursal < 1) {
            throw new RuntimeException('Falta la sucursal del servidor en config/instalacion.php');
        }
        if (preg_match('#^https?://[^\s/]+$#D', $url) !== 1 || strlen($secreto) < 40) {
            throw new RuntimeException('Faltan la dirección del central o el secreto en config/instalacion.php');
        }

        return ['tipo' => 'sucursal', 'desplazamiento' => $desplazamiento, 'id_sucursal' => $sucursal,
            'url_central' => $url, 'secreto' => $secreto, 'salud_ca' => (string) ($datos['salud_ca'] ?? '')];
    }

    /** @return array{llave_totp:string} */
    public static function seguridad(string $raiz): array
    {
        /** @var array{llave_totp:string} $config */
        $config = self::lee($raiz, 'seguridad');
        if (!isset($config['llave_totp']) || !is_string($config['llave_totp'])) {
            throw new RuntimeException('Falta la llave de segundo factor');
        }

        return $config;
    }

    /**
     * La llave que sella la bitácora. Vive fuera de la base a propósito: quien
     * alcance a alterar un renglón no debe poder rehacer su sello.
     */
    public static function llaveSello(string $raiz): string
    {
        $config = self::lee($raiz, 'seguridad');
        $llave = $config['llave_sello'] ?? null;
        if (!is_string($llave) || strlen((string) base64_decode($llave, true)) !== 32) {
            throw new RuntimeException('Falta la llave de sello de la bitácora en config/seguridad.php');
        }

        return (string) base64_decode($llave, true);
    }

    /**
     * La llave que cifra la copia del respaldo que sale del hospedaje.
     * Vive en `config/respaldo.php`, aparte de la de segundo factor: se le
     * entrega al dueño para guardarla fuera del hosting, y esa copia no debe
     * abrir nada más.
     */
    public static function llaveRespaldo(string $raiz): string
    {
        $config = self::lee($raiz, 'respaldo');
        if (!isset($config['llave']) || !is_string($config['llave'])) {
            throw new RuntimeException('Falta la llave de respaldo');
        }

        return $config['llave'];
    }

    /**
     * A quién y cómo avisar cuando una tarea programada falla.
     *
     * @return array{correo:string,remitente:string,transporte:string,espacio_minimo_mb:int,registros_maximo_mb:int}
     */
    public static function alertas(string $raiz): array
    {
        $config = self::lee($raiz, 'alertas');
        $transporte = (string) ($config['transporte'] ?? 'mail');
        if (!in_array($transporte, ['mail', 'archivo'], true)) {
            throw new RuntimeException('El transporte de alertas debe ser mail o archivo');
        }

        return [
            'correo' => trim((string) ($config['correo'] ?? '')),
            'remitente' => trim((string) ($config['remitente'] ?? '')),
            'transporte' => $transporte,
            'espacio_minimo_mb' => max(1, (int) ($config['espacio_minimo_mb'] ?? 1024)),
            'registros_maximo_mb' => max(1, (int) ($config['registros_maximo_mb'] ?? 200)),
        ];
    }

    public static function entorno(string $raiz): string
    {
        return (string) self::aplicacion($raiz)['entorno'];
    }

    /** @return array{id:string,creada_en:?string,fuente_sha256:?string,esquema:int} */
    public static function liberacion(string $raiz): array
    {
        $ruta = rtrim($raiz, '/') . '/config/liberacion.php';
        if (!is_file($ruta)) {
            return ['id' => 'sin-identificar', 'creada_en' => null, 'fuente_sha256' => null, 'esquema' => 0];
        }

        $datos = require $ruta;
        if (!is_array($datos)
            || preg_match('/^[A-Za-z0-9._:-]{3,100}$/', (string) ($datos['id'] ?? '')) !== 1
            || !is_int($datos['esquema'] ?? null)) {
            throw new RuntimeException('El descriptor de liberación no es válido');
        }

        return [
            'id' => (string) $datos['id'],
            'creada_en' => isset($datos['creada_en']) ? (string) $datos['creada_en'] : null,
            'fuente_sha256' => isset($datos['fuente_sha256']) ? (string) $datos['fuente_sha256'] : null,
            'esquema' => (int) $datos['esquema'],
        ];
    }

    private static function entornoControlado(): ?string
    {
        $valor = trim((string) (getenv('APP_ENTORNO') ?: ($_SERVER['APP_ENTORNO'] ?? '')));

        if ($valor === '') {
            return null;
        }
        if (!in_array($valor, self::ENTORNOS, true)) {
            throw new RuntimeException('APP_ENTORNO no es local, pruebas o produccion');
        }

        return $valor;
    }

    /** @return array<string,mixed> */
    private static function lee(string $raiz, string $tipo): array
    {
        $entorno = self::entornoControlado();
        $sufijo = $entorno === 'pruebas' ? '.pruebas' : '';
        $ruta = rtrim($raiz, '/') . '/config/' . $tipo . $sufijo . '.php';

        if (!is_file($ruta)) {
            throw new RuntimeException('Falta el archivo de configuración para el entorno solicitado');
        }

        $config = require $ruta;
        if (!is_array($config)) {
            throw new RuntimeException('El archivo de configuración no devuelve un arreglo');
        }

        return $config;
    }
}
