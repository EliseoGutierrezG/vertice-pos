<?php
declare(strict_types=1);

namespace Nucleo;

use Nucleo\Errores\Errores;

/**
 * La petición que entró, ya leída y limpia.
 *
 * Nadie más toca $_GET, $_POST, $_FILES, $_SERVER ni php://input. Se leen aquí una vez
 * y se entregan por métodos con tipo. Así el origen de cada dato es rastreable
 * y no hay superglobales repartidas por todo el código.
 */
final class Peticion
{
    /** @var array<string,mixed>|null Se lee la primera vez que se pide. */
    private ?array $cuerpo = null;

    /** @var array{0:class-string,1:string}|null Controlador y método que atienden. */
    private ?array $destino = null;

    /** @var array<string,mixed>|null Token y dispositivo, cuando entra por la API. */
    private ?array $acceso = null;

    /** @param array<string,mixed> $consulta
     *  @param array<string,string> $cabeceras */
    private function __construct(
        private string $metodo,
        private string $ruta,
        private array $consulta,
        private array $cabeceras,
        private string $ip,
        /** @var array<string,string> Parámetros de la ruta: /pedidos/{id} */
        private array $parametros = [],
        /** @var array<string,mixed> Los archivos subidos, tal como los deja PHP */
        private array $archivos = []
    ) {
    }

    public static function desdeGlobales(): self
    {
        $metodo = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

        // Sólo la ruta: sin cadena de consulta y sin barra final sobrante.
        $ruta = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
        $ruta = '/' . trim(rawurldecode($ruta), '/');

        $cabeceras = [];
        foreach ($_SERVER as $llave => $valor) {
            if (str_starts_with((string) $llave, 'HTTP_')) {
                $nombre = strtolower(str_replace('_', '-', substr((string) $llave, 5)));
                $cabeceras[$nombre] = (string) $valor;
            }
        }
        if (isset($_SERVER['CONTENT_TYPE'])) {
            $cabeceras['content-type'] = (string) $_SERVER['CONTENT_TYPE'];
        }
        if (isset($_SERVER['CONTENT_LENGTH'])) {
            $cabeceras['content-length'] = (string) $_SERVER['CONTENT_LENGTH'];
        }

        return new self(
            $metodo,
            $ruta,
            $_GET,
            $cabeceras,
            (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
            [],
            $_FILES,
        );
    }

    /**
     * El cuerpo, leído la PRIMERA vez que alguien lo pide.
     *
     * Perezoso a propósito: un JSON roto es un 400, y ese 400 tiene que poder
     * construirse sin que la propia construcción de la petición reviente. Si
     * se leyera en el constructor, el manejador de errores no tendría petición
     * con la que trabajar.
     *
     * @return array<string,mixed>
     */
    private function leerCuerpo(): array
    {
        $tipo = strtolower($this->cabeceras['content-type'] ?? '');

        if (str_contains($tipo, 'application/json')) {
            $crudo = (string) file_get_contents('php://input');
            if ($crudo === '') {
                return [];
            }
            $datos = json_decode($crudo, true);
            if (!is_array($datos)) {
                // JSON ilegible es culpa de quien llama: 400, no 500.
                throw Errores::peticionInvalida('Datos ilegibles. Intente de nuevo');
            }
            return $datos;
        }

        return $_POST;
    }

    public function metodo(): string
    {
        return $this->metodo;
    }

    public function ruta(): string
    {
        return $this->ruta;
    }

    public function ip(): string
    {
        return $this->ip;
    }

    public function cabecera(string $nombre, ?string $porOmision = null): ?string
    {
        return $this->cabeceras[strtolower($nombre)] ?? $porOmision;
    }

    /** Lo que sacó el router de la ruta: /pedidos/{id} → ['id' => '7'] */
    public function parametro(string $nombre, ?string $porOmision = null): ?string
    {
        return $this->parametros[$nombre] ?? $porOmision;
    }

    /** @return array<string,string> */
    public function parametros(): array
    {
        return $this->parametros;
    }

    /** @param array<string,string> $parametros */
    public function conParametros(array $parametros): self
    {
        $copia = clone $this;
        $copia->parametros = $parametros;
        return $copia;
    }

    /**
     * A dónde va esta petición. Lo pone el router, y lo lee el intermediario
     * de permiso para preguntarle por reflexión qué exige la acción.
     *
     * @param array{0:class-string,1:string} $destino
     */
    public function conDestino(array $destino): self
    {
        $copia = clone $this;
        $copia->destino = $destino;
        return $copia;
    }

    /** @return array{0:class-string,1:string}|null */
    public function destino(): ?array
    {
        return $this->destino;
    }

    /**
     * El token y el dispositivo resueltos, cuando la petición viene de la app.
     *
     * @param array<string,mixed> $acceso
     */
    public function conAcceso(array $acceso): self
    {
        $copia = clone $this;
        $copia->acceso = $acceso;
        return $copia;
    }

    /** @return array<string,mixed>|null */
    public function acceso(): ?array
    {
        return $this->acceso;
    }

    public function consulta(string $nombre, mixed $porOmision = null): mixed
    {
        return $this->consulta[$nombre] ?? $porOmision;
    }

    /**
     * Toda la cadena de consulta.
     *
     * La usan las pantallas que tienen que volver a armar su propia URL —un
     * reporte con filtros que se exporta sin perderlos—. Existe para que un
     * controlador no tenga que leer `$_GET`: la petición ya la trae, y lo que
     * la petición trae es lo que las pruebas pueden fingir.
     *
     * @return array<string,mixed>
     */
    public function consultas(): array
    {
        return $this->consulta;
    }

    public function dato(string $nombre, mixed $porOmision = null): mixed
    {
        return $this->datos()[$nombre] ?? $porOmision;
    }

    /** @return array<string,mixed> */
    public function datos(): array
    {
        return $this->cuerpo ??= $this->leerCuerpo();
    }

    /**
     * Un archivo subido en el campo `$nombre`, o null si no vino.
     *
     * Sólo un archivo por campo: un `name="foto[]"` con varios se trata como
     * ausente, porque ninguna pantalla los pide y aceptarlos a medias es peor.
     * `ruta` es el temporal de PHP; quien lo use tiene que comprobar con
     * `is_uploaded_file()` que de verdad llegó por la subida.
     *
     * @return array{ruta:string,error:int,peso:int,nombre:string}|null
     */
    public function archivo(string $nombre): ?array
    {
        $archivo = $this->archivos[$nombre] ?? null;
        if (!is_array($archivo) || !is_string($archivo['tmp_name'] ?? null)) {
            return null;
        }

        return [
            'ruta'   => $archivo['tmp_name'],
            'error'  => (int) ($archivo['error'] ?? UPLOAD_ERR_NO_FILE),
            'peso'   => (int) ($archivo['size'] ?? 0),
            'nombre' => (string) ($archivo['name'] ?? ''),
        ];
    }

    /** ¿Quien llama espera JSON? Decide cómo se le presenta un error. */
    public function esperaJson(): bool
    {
        $acepta = strtolower($this->cabecera('accept', '') ?? '');
        $conQue = strtolower($this->cabecera('x-requested-with', '') ?? '');

        return str_contains($acepta, 'application/json')
            || $conQue === 'xmlhttprequest'
            || str_starts_with($this->ruta, '/api/');
    }
}
