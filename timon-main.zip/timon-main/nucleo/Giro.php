<?php
declare(strict_types=1);

namespace Nucleo;

final class Giro
{
    public static function activo(string $modulo): bool
    {
        return (self::configuracion()[$modulo] ?? false) === true;
    }

    public static function redes(): array
    {
        $dominios = [
            'Instagram' => 'instagram.com',
            'Facebook' => 'facebook.com',
            'TikTok' => 'tiktok.com',
        ];
        $enlaces = [];
        foreach ($dominios as $nombre => $dominio) {
            $url = self::configuracion()['redes'][$nombre] ?? '';
            if (!is_string($url) || filter_var($url, FILTER_VALIDATE_URL) === false) {
                continue;
            }
            $partes = parse_url($url);
            if (($partes['scheme'] ?? '') === 'https'
                && in_array(strtolower($partes['host'] ?? ''), [$dominio, 'www.' . $dominio], true)
                && !isset($partes['user']) && !isset($partes['port'])) {
                $enlaces[] = ['nombre' => $nombre, 'url' => $url];
            }
        }
        return $enlaces;
    }

    private static function configuracion(): array
    {
        static $config;
        return $config ??= require dirname(__DIR__) . '/config/giro.php';
    }
}
