<?php
declare(strict_types=1);

namespace Nucleo;

/**
 * Qué es esta instalación: el central, el servidor de una sucursal o una
 * instalación sola (sin `config/instalacion.php`).
 *
 * El servidor de sucursal opera su sucursal sin internet y se sincroniza con
 * el central (`servicios/Replica.php`, `docs/servidor-sucursal.md`).
 */
final class Instalacion
{
    /** @param array{tipo:'central'|'sucursal',desplazamiento:int,id_sucursal:?int,url_central:?string,secreto:?string}|null $datos */
    public function __construct(private ?array $datos)
    {
    }

    public static function de(string $raiz): self
    {
        return new self(Configuracion::instalacion($raiz));
    }

    public function esSucursal(): bool
    {
        return ($this->datos['tipo'] ?? null) === 'sucursal';
    }

    public function esCentral(): bool
    {
        return ($this->datos['tipo'] ?? null) === 'central';
    }

    /** La sucursal que opera este servidor; null fuera de un servidor de sucursal. */
    public function idSucursal(): ?int
    {
        return $this->esSucursal() ? (int) $this->datos['id_sucursal'] : null;
    }

    public function urlCentral(): string
    {
        return (string) ($this->datos['url_central'] ?? '');
    }

    public function secreto(): string
    {
        return (string) ($this->datos['secreto'] ?? '');
    }

    public function desplazamiento(): ?int
    {
        return $this->datos === null ? null : (int) $this->datos['desplazamiento'];
    }
}
