<?php
declare(strict_types=1);

namespace Nucleo;

use Nucleo\Seguridad\Cifrador;
use Servicios\FotosCarta;
use Servicios\MarcaVisual;
use Servicios\SegundoFactor;
use Throwable;

/**
 * El arranque: arma las piezas, resuelve la ruta, corre la cadena y responde.
 *
 * Todo pasa por aquí. No hay un segundo camino de entrada, ni un archivo
 * suelto que se pueda pedir por URL: publico/ sólo tiene index.php y recursos
 * estáticos.
 */
final class Aplicacion
{
    private Contenedor $contenedor;
    private Router $router;
    private ManejadorErrores $manejador;

    public function __construct(private string $raiz)
    {
        /** @var array<string,mixed> $config */
        $config = Configuracion::aplicacion($this->raiz);
        $config['liberacion'] = Configuracion::liberacion($this->raiz)['id'];

        Reloj::fijaLaZonaConNombre((string) $config['zona_horaria']);

        // En produccion nada se imprime; en local tampoco: todo va al registro.
        ini_set('display_errors', '0');
        error_reporting(E_ALL);

        $this->contenedor = new Contenedor($config);

        $registro = new Registro(
            (string) $config['registros'],
            (bool) $config['depurar']
        );
        $this->contenedor->comparte(Registro::class, $registro);

        $this->manejador = new ManejadorErrores($registro, (bool) $config['depurar']);
        $this->manejador->registrar();
        $this->contenedor->comparte(ManejadorErrores::class, $this->manejador);

        // La conexión se abre sólo si alguien la pide.
        $this->contenedor->receta(BaseDatos::class, function () use ($config): BaseDatos {
            /** @var array{host:string,base:string,usuario:string,clave:string,puerto:int} $bd */
            $bd = Configuracion::baseDatos($this->raiz);
            return new BaseDatos($bd);
        });

        // Central, servidor de sucursal o instalación sola.
        $this->contenedor->receta(Instalacion::class, fn (): Instalacion => Instalacion::de($this->raiz));
        // Los paquetes que el central reparte a las computadoras de sucursal,
        // y la llave pública con que se comprueba su firma.
        $this->contenedor->receta(\Servicios\Liberaciones::class, fn (Contenedor $c): \Servicios\Liberaciones => new \Servicios\Liberaciones(
            $c->obtiene(BaseDatos::class),
            $c->obtiene(\Nucleo\Bitacora::class),
            $c->obtiene(Identidad::class),
            $this->raiz . '/almacenamiento/liberaciones' . ($config['entorno'] === 'pruebas' ? '-pruebas' : ''),
            \Nucleo\Seguridad\FirmaLiberacion::publicaDe($this->raiz)
        ));

        // La llave que cifra los secretos TOTP vive en un archivo distinto de
        // la conexión. La base por sí sola nunca basta para obtenerlos.
        $this->contenedor->receta(Cifrador::class, function (): Cifrador {
            return new Cifrador((string) Configuracion::seguridad($this->raiz)['llave_totp']);
        });

        // La cookie de sesión sólo viaja por HTTPS cuando hay HTTPS, y el
        // archivo de la sesión vive en una carpeta propia (ver `Sesion`).
        $this->contenedor->receta(Sesion::class, fn (): Sesion => new Sesion(
            $config['entorno'] === 'produccion',
            $this->raiz . '/almacenamiento/sesiones' . ($config['entorno'] === 'pruebas' ? '-pruebas' : '')
        ));

        // La marca visual de la instalación : la base sin
        // archivo, o la de `config/marca-visual.php` si es válida.
        $this->contenedor->receta(MarcaVisual::class, fn (): MarcaVisual => MarcaVisual::deInstalacion(
            $this->raiz,
            (string) $config['entorno']
        ));
        $this->contenedor->receta(FotosCarta::class,
            fn (): FotosCarta => new FotosCarta(self::carpetaImagenes($this->raiz, $config)));
        // Los PDF de reportes toman su nombre y su primario, y sólo la
        // consultan cuando de verdad se arma un PDF.
        \Nucleo\Exporta\Pdf::marcaDesde(function (): array {
            $vigente = $this->contenedor->obtiene(MarcaVisual::class)->vigente();
            return [$vigente['nombre_corto'], $vigente['colores']['primario']];
        });

        // Las plantillas reciben la identidad y la marca. Son los mismos
        // objetos que usa el resto: lo que la pantalla esconde y lo que el
        // backend rechaza salen de la misma fuente, así no discrepan.
        $this->contenedor->receta(Vista::class, function (Contenedor $c) use ($config): Vista {
            return new Vista($this->raiz . '/vistas', [
                'identidad' => $c->obtiene(Identidad::class),
                'csrf'      => $c->obtiene(Csrf::class),
                'sesion'    => $c->obtiene(Sesion::class),
                'app'       => $config,
                // Nombre, colores y logotipo con que se pinta la instalación.
                'marcaVisual' => $c->obtiene(MarcaVisual::class),
                // Si las autorizaciones piden el código de Authenticator
                // (parámetro `segundo_factor_web`). Es una función para que sólo
                // la consulte la pantalla que la usa.
                'segundoFactorActivo' => static fn (): bool => $c->obtiene(SegundoFactor::class)->activo(),
                // Segundos que le quedan a la sesión, para el aviso de `plantilla.js`.
                'vidaSesion' => static fn (): ?int => $c->obtiene(VidaSesion::class)->restante(),
            ]);
        });

        $this->router = new Router();
        $this->contenedor->comparte(Router::class, $this->router);

        // Dos árboles, cada uno con sus protecciones.
        (require $this->raiz . '/rutas/web.php')($this->router);
        (require $this->raiz . '/rutas/api.php')($this->router);
    }

    /**
     * Dónde van las fotos: la clave `imagenes` de la configuración o, si no la
     * hay, `almacenamiento/`. Pública porque la demostración tiene que borrar
     * y cargar en la misma carpeta que después sirve la aplicación.
     *
     * @param array<string, mixed> $config
     */
    public static function carpetaImagenes(string $raiz, array $config): string
    {
        if (isset($config['imagenes']) && $config['imagenes'] !== '') {
            return rtrim((string) $config['imagenes'], '/');
        }

        $entorno = (string) ($config['entorno'] ?? '');

        return $raiz . '/almacenamiento/imagenes' . ($entorno === 'pruebas' ? '-pruebas' : '') . '/productos';
    }

    public function corre(): void
    {
        $peticion = null;
        $operacion = null;

        try {
            $peticion = Peticion::desdeGlobales();
            // Salud debe seguir disponible para comprobar la versión mientras
            // el actualizador tiene el candado exclusivo. El resto termina
            // antes de respaldar y migrar, o recibe un error reintentable.
            if ($peticion->ruta() !== '/api/v1/salud') {
                $operacion = CerrojoActualizacion::lectura($this->raiz);
            }

            [$ruta, $parametros] = $this->router->resuelve($peticion);
            $peticion            = $peticion->conParametros($parametros)->conDestino($ruta->destino());
            /** @var ContextoAuditoria $auditoria */
            $auditoria = $this->contenedor->obtiene(ContextoAuditoria::class);
            $auditoria->iniciaPeticion($peticion, $ruta);

            $cadena = new Middleware\Cadena($ruta->intermediarios(), $this->contenedor);

            $respuesta = $cadena->ejecutar($peticion, function (Peticion $peticion) use ($ruta): Respuesta {
                [$clase, $metodo] = $ruta->destino();
                $controlador      = $this->contenedor->obtiene($clase);

                return $controlador->{$metodo}($peticion);
            });
        } catch (Throwable $e) {
            $peticion ??= Peticion::desdeGlobales();
            $respuesta = $this->manejador->aRespuesta($e, $peticion);
        }

        try {
            $respuesta->enviar();
        } finally {
            CerrojoActualizacion::libera($operacion);
        }
    }

    public function contenedor(): Contenedor
    {
        return $this->contenedor;
    }
}
