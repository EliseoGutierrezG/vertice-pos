<?php
declare(strict_types=1);

namespace Nucleo;

use DateTimeZone;
use RuntimeException;

/**
 * El reloj del negocio.
 *
 * En este sistema «hoy» se pregunta en dos idiomas: PHP lo contesta con
 * `date('Y-m-d')` —el precio vigente, la hoja del día, los filtros de los
 * reportes— y MariaDB con `CURDATE()` o `NOW()` —el catálogo, los parámetros
 * vigentes, el `creado_en` de cada movimiento—. **Si los dos relojes no están
 * en la misma zona, el sistema tiene dos días distintos al mismo tiempo**, y
 * eso se nota justo donde más duele: de las 18:00 en adelante el catálogo
 * mostraría el precio de mañana y la venta cobraría el de hoy.
 *
 * Aquí hay un solo lugar que fija la zona, y `BaseDatos` le pregunta a PHP en
 * qué desplazamiento está para ponerle el mismo al motor. Así los dos relojes
 * no *pueden* discrepar: o los dos están bien, o los dos están igual de mal, y
 * lo segundo lo caza la regla de arquitectura que exige que todo punto de
 * entrada pase por aquí.
 *
 * ⚠️ En el hospedaje compartido la zona del motor viene en `SYSTEM`, que suele
 * ser UTC: seis horas adelante. Por eso no se confía en la del servidor.
 */
final class Reloj
{
    /**
     * Pone a PHP en la zona del negocio, la que dice `config/app.php`.
     *
     * Todo punto de entrada —el navegador y cada guion de la línea de
     * comandos— tiene que llamarla antes de leer una fecha o de abrir la base.
     * En la línea de comandos PHP no hereda la zona de nadie: si no se fija,
     * corre en UTC.
     */
    public static function fijaLaZona(string $raiz): void
    {
        /** @var array<string,mixed> $config */
        $config = Configuracion::aplicacion($raiz);

        self::fijaLaZonaConNombre((string) $config['zona_horaria']);
    }

    /** La misma cosa cuando la zona ya se leyó de la configuración. */
    public static function fijaLaZonaConNombre(string $zona): void
    {
        // `date_default_timezone_set()` emite un aviso antes de devolver false.
        // La configuración inválida es un error controlado del sistema, no
        // ruido inesperado en la salida de las pruebas o del cron.
        if (!in_array($zona, DateTimeZone::listIdentifiers(), true)) {
            throw new RuntimeException('La zona horaria configurada no existe: ' . $zona);
        }

        date_default_timezone_set($zona);
    }

    /**
     * El desplazamiento de PHP en este momento, como lo entiende MariaDB.
     *
     * Se manda el desplazamiento («-06:00») y no el nombre de la zona porque
     * `SET time_zone = 'America/Mexico_City'` necesita las tablas de zonas de
     * MySQL, y en un hospedaje compartido casi siempre están vacías: la
     * sentencia falla y la sesión se queda en la zona del servidor sin que
     * nadie se entere. El desplazamiento siempre funciona.
     *
     * Se recalcula en cada conexión a propósito: si algún día vuelve el horario
     * de verano —México lo tuvo hasta 2022—, el desplazamiento cambia dos veces
     * al año y esto lo sigue sin que haya que tocar nada.
     */
    public static function desplazamiento(): string
    {
        $desplazamiento = date('P');

        // `date('P')` sólo puede devolver «±HH:MM», pero se comprueba igual:
        // es lo único que se pega dentro de una sentencia en `BaseDatos`.
        if (preg_match('/^[+-]\d{2}:\d{2}$/', $desplazamiento) !== 1) {
            throw new RuntimeException('El desplazamiento horario no tiene la forma esperada');
        }

        return $desplazamiento;
    }
}
