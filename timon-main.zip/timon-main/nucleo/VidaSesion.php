<?php
declare(strict_types=1);

namespace Nucleo;

use Modelos\Parametros;
use Nucleo\Middleware\ExigeSesion;

/**
 * Cuánto le queda a la sesión del panel, con las mismas reglas que la cierra.
 *
 * `ExigeSesion` decide si la sesión sigue; esta clase dice **cuándo** dejará de
 * seguir, para que la pantalla avise antes (homologación §S, D19). Lee los tres
 * parámetros que lee el intermediario y los mismos sellos de la sesión, así que
 * el aviso y el cierre no pueden discrepar:
 *
 *  - `horas_sesion_maxima`, contado desde que entró (`ExigeSesion::ENTRADA`);
 *  - `minutos_sesion_inactiva`, contado desde el último uso;
 *  - `minutos_sesion_inactiva_sensible`, igual, solo en los puestos sensibles.
 *
 * Gana el que vence primero. Un cero en un parámetro lo apaga, como allá.
 */
final class VidaSesion
{
    public function __construct(
        private Sesion $sesion,
        private Identidad $identidad,
        private Parametros $parametros
    ) {
    }

    /** Segundos que le quedan; `null` si ningún tope aplica. */
    public function restante(): ?int
    {
        if (!$this->identidad->hay()) {
            return null;
        }

        $ahora   = time();
        $topes   = [];
        $entro   = $this->sesion->saca(ExigeSesion::ENTRADA);
        $ultimo  = $this->sesion->saca(ExigeSesion::SELLO);

        $horas = $this->parametros->entero('horas_sesion_maxima', 12);
        if ($horas > 0 && is_int($entro)) {
            $topes[] = $entro + $horas * 3600 - $ahora;
        }

        $minutos = $this->parametros->entero('minutos_sesion_inactiva', 120);
        if ($minutos > 0 && is_int($ultimo)) {
            $topes[] = $ultimo + $minutos * 60 - $ahora;
        }

        if ($this->identidad->esPuestoSensible()) {
            $sensible = $this->parametros->entero('minutos_sesion_inactiva_sensible', 30);
            if ($sensible > 0 && is_int($ultimo)) {
                $topes[] = $ultimo + $sensible * 60 - $ahora;
            }
        }

        return $topes === [] ? null : max(0, min($topes));
    }
}
