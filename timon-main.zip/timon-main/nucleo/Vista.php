<?php
declare(strict_types=1);

namespace Nucleo;

use RuntimeException;

/**
 * Plantillas en PHP, sin motor de plantillas.
 *
 * Una regla, y es la que importa: **todo se escapa al salir**. La función
 * `$e()` está disponible en cada plantilla y no hay forma de imprimir sin
 * ella salvo escribiéndolo a propósito, que entonces se ve en la revisión.
 */
final class Vista
{
    public function __construct(
        private string $carpeta,
        /** @var array<string,mixed> Lo que toda plantilla recibe: usuario, etc. */
        private array $comunes = []
    ) {
    }

    /** @param array<string,mixed> $datos */
    public function comparte(string $llave, mixed $valor): void
    {
        $this->comunes[$llave] = $valor;
    }

    /**
     * Pinta una plantilla dentro de la plantilla base.
     *
     * @param array<string,mixed> $datos
     */
    public function pinta(string $plantilla, array $datos = [], string $base = 'plantilla/base'): string
    {
        $contenido = $this->suelta($plantilla, $datos);

        return $this->suelta($base, [...$datos, 'contenido' => $contenido]);
    }

    /**
     * Pinta una plantilla sola, sin base. Para fragmentos y correos.
     *
     * @param array<string,mixed> $datos
     */
    public function suelta(string $plantilla, array $datos = []): string
    {
        $archivo = $this->carpeta . '/' . $plantilla . '.php';

        if (!is_file($archivo)) {
            throw new RuntimeException('No existe la plantilla ' . $plantilla);
        }

        // Las piezas del sistema visual —`pb_ico`, `pb_aviso`, `pb_insignia`—
        // se cargan aquí y no desde la plantilla base.
        //
        // ⚠️ **La base se pinta al final, no al principio.** `pinta()` primero
        // suelta la pantalla de dentro y luego la mete en la base, así que una
        // vista que llamara a `pb_ico()` reventaba con «Call to undefined
        // function»: la base todavía no había corrido. Medido en `/entrar`,
        // que dio 500 en cuanto su formulario estrenó un icono.
        $piezas = $this->carpeta . '/partes/piezas.php';

        if (is_file($piezas)) {
            require_once $piezas;
        }

        $e = static fn (mixed $valor): string => htmlspecialchars(
            (string) $valor,
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );

        extract([...$this->comunes, ...$datos], EXTR_SKIP);

        ob_start();

        try {
            require $archivo;
        } catch (\Throwable $e) {
            // Si la plantilla revienta a media página, lo escrito hasta ahí
            // se tira. Sin esto, PHP acaba vaciando el buffer al terminar y
            // el navegador recibe media pantalla pegada a la de error.
            ob_end_clean();
            throw $e;
        }

        return (string) ob_get_clean();
    }
}
