<?php
declare(strict_types=1);

namespace Nucleo;

/**
 * Quién miró o se llevó datos personales.
 *
 * La bitácora de siempre cuenta cambios. Una selfie abierta o un reporte exportado
 * no cambian nada, y son justo lo que se pregunta tras una fuga: quién tuvo eso a
 * la vista. Van con el módulo `lectura`, y no bloquean: si el apunte falla, se
 * registra el error y la pantalla sigue, porque leer no debe tumbar la operación.
 */
final class AuditoriaLectura
{
    public function __construct(
        private Bitacora $bitacora,
        private Identidad $identidad,
        private Sesion $sesion,
        private Registro $registro
    ) {
    }

    /** @param array<string,mixed> $detalle */
    public function anota(string $accion, string $entidad, ?int $id, array $detalle, string $ip): void
    {
        try {
            $this->bitacora->registra(
                'lectura',
                $accion,
                $entidad,
                $id,
                despues: $detalle === [] ? null : $detalle,
                idUsuario: $this->identidad->hay() ? $this->identidad->id() : null,
                ip: $ip
            );
        } catch (\Throwable $e) {
            $this->registro->error('No se pudo apuntar una lectura sensible', ['accion' => $accion], $e);
        }
    }

    /**
     * Para lo que se vuelve a leer solo, como el Tablero cada 45 segundos: un apunte
     * por recarga ahogaría la bitácora y no diría nada más que el primero.
     */
    public function unaVezAlDia(string $accion, string $entidad, string $ip): void
    {
        $llave = 'lectura_' . $accion;
        if ($this->sesion->saca($llave) === date('Y-m-d')) {
            return;
        }

        $this->sesion->pon($llave, date('Y-m-d'));
        $this->anota($accion, $entidad, null, [], $ip);
    }
}
