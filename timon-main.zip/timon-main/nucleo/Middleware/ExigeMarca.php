<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Nucleo\Csrf;
use Nucleo\Errores\Errores;
use Nucleo\Peticion;
use Nucleo\Respuesta;

/**
 * Exige la marca CSRF en todo lo que cambia algo.
 *
 * GET, HEAD y OPTIONS no la piden: por definición no cambian nada. Todo lo
 * demás sí, sin excepciones y sin lista de rutas exentas —una lista de
 * excepciones es exactamente por donde se cuela el descuido—.
 *
 * La marca se acepta en el campo `_marca` o en la cabecera `X-Marca`, que es
 * lo que usa el JavaScript de las pantallas.
 */
final class ExigeMarca implements Intermediario
{
    private const SIN_EFECTO = ['GET', 'HEAD', 'OPTIONS'];

    public function __construct(private Csrf $csrf)
    {
    }

    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        if (in_array($peticion->metodo(), self::SIN_EFECTO, true)) {
            return $siguiente($peticion);
        }

        // Si el cuerpo pasa de `post_max_size`, PHP lo tira entero —campos,
        // archivos y la marca con ellos— sin avisar. Sin esto, quien sube una
        // foto demasiado grande leería «la sesión expiró», que no es cierto y
        // no le dice qué hacer.
        $limite = self::bytes((string) ini_get('post_max_size'));
        $largo  = (int) $peticion->cabecera('content-length', '0');
        if ($limite > 0 && $largo > $limite) {
            throw Errores::datosInvalidos(
                ['imagen' => 'El archivo pesa demasiado'],
                'El archivo pesa demasiado'
            );
        }

        $recibida = $peticion->cabecera('x-marca');
        if ($recibida === null) {
            $delCuerpo = $peticion->dato('_marca');
            $recibida  = is_string($delCuerpo) ? $delCuerpo : null;
        }

        $this->csrf->valida($recibida);

        return $siguiente($peticion);
    }

    /** «12M» → 12 582 912. PHP escribe sus límites así. */
    private static function bytes(string $valor): int
    {
        $valor = trim($valor);
        if ($valor === '') {
            return 0;
        }

        return (int) $valor * match (strtoupper(substr($valor, -1))) {
            'G' => 1024 ** 3,
            'M' => 1024 ** 2,
            'K' => 1024,
            default => 1,
        };
    }
}
