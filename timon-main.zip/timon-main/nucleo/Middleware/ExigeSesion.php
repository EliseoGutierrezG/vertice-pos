<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Modelos\Parametros;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;

/**
 * Exige sesión iniciada y con uso reciente, y carga la identidad.
 *
 * Corre antes que cualquier comprobación de permiso: no se puede preguntar
 * qué puede hacer alguien de quien todavía no se sabe quién es.
 *
 * ⚠️ **La sesión no se cerraba nunca.** Medido envejeciendo el archivo de
 * sesión y volviendo a pedir una pantalla protegida: quieta treinta días,
 * seguía contestando 200. `session.gc_maxlifetime` es un barrido de basura que
 * corre una de cada mil veces, no una caducidad, y usarlo como si lo fuera deja
 * la sesión del mostrador abierta de un turno al siguiente: quien se siente
 * delante vende con el nombre del anterior, y la bitácora lo firma así.
 *
 * El tope lo dice el parámetro `minutos_sesion_inactiva`, porque es decisión del
 * negocio. El sello se guarda con `time()`, que no depende de zona: comparar dos
 * instantes absolutos no tiene por qué pasar por el reloj del negocio.
 *
 * Sobre ese tope hay dos más (esquema 053): `horas_sesion_maxima` cierra la sesión
 * aunque se use sin parar, para que un identificador robado no valga para siempre,
 * y `minutos_sesion_inactiva_sensible` acorta la espera de los puestos que mueven
 * dinero, inventario o accesos.
 *
 * ⚠️ El Tablero se recarga solo. Sin `sondeo=1` en esa recarga, una pantalla olvidada
 * mantendría viva la sesión para siempre y el tope de inactividad no valdría de nada.
 */
final class ExigeSesion implements Intermediario
{
    /** El último uso. Lo lee también `Nucleo\VidaSesion` para avisar antes de vencer. */
    public const SELLO = 'ultimo_uso';

    /** Consultar cuánto queda no es usar la sesión: si lo fuera, el aviso la mantendría viva. */
    private const SIN_USO = ['/sesion/estado'];

    /** Cuándo entró. Lo pone `Controladores\Web\Entrada` y no se renueva con el uso. */
    public const ENTRADA = 'entro_en';

    public function __construct(
        private Sesion $sesion,
        private Identidad $identidad,
        private Parametros $parametros
    ) {
    }

    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        $idUsuario = $this->sesion->saca('id_usuario');

        if (!is_int($idUsuario)) {
            return $this->afuera($peticion);
        }

        if ($this->llevaMuchoQuieta()) {
            // Se vacía de verdad, no sólo se redirige: una sesión que sigue
            // en el disco revive con el siguiente clic. Y se vacía en vez de
            // cerrarse porque hay que poder explicarle al usuario qué pasó —sin
            // el aviso, llega a la entrada sin una palabra y cree que el sistema
            // se cayó—. El identificador viejo se destruye de todos modos.
            $this->sesion->vacia();
            $this->sesion->avisa('Sesión vencida. Entre de nuevo.', 'mal');

            return $this->afuera($peticion);
        }

        if ($this->rebasoElTope()) {
            $horas = $this->parametros->entero('horas_sesion_maxima', 12);
            $this->sesion->vacia();
            $this->sesion->avisa('La sesión se cierra tras ' . $horas . ' horas. Entre de nuevo.', 'mal');

            return $this->afuera($peticion);
        }

        $ultimoUso = $this->sesion->saca(self::SELLO);
        $cuentaComoUso = $peticion->consulta('sondeo', '') !== '1' && !in_array($peticion->ruta(), self::SIN_USO, true);
        if ($cuentaComoUso || !is_int($ultimoUso)) {
            $this->sesion->pon(self::SELLO, time());
        }

        // Si la cuenta se desactivó a media sesión, `establece` lanza 401. ⚠️ Sin
        // vaciar la sesión, esa computadora quedaba atorada: la entrada ve un
        // `id_usuario` y manda al tablero, el tablero lo rechaza, y nadie más
        // podía entrar en ella hasta que venciera la sesión (bitácora 97).
        try {
            $this->identidad->establece($idUsuario);
        } catch (ErrorHttp $error) {
            if ($error->estado() !== 401) throw $error;
            $this->sesion->vacia();
            $this->sesion->avisa('Cuenta inactiva. Avise al administrador.', 'mal');
            return $this->afuera($peticion);
        }

        if ($this->identidad->esPuestoSensible() && $this->quietaParaSuPuesto($ultimoUso)) {
            $this->sesion->vacia();
            $this->identidad->olvida();
            $this->sesion->avisa('Sesión vencida. Entre de nuevo.', 'mal');

            return $this->afuera($peticion);
        }

        $versionSesion = $this->sesion->saca('sesion_version');
        if (!is_int($versionSesion)) {
            // Sesiones emitidas antes de la migración se adoptan una sola vez.
            $this->sesion->pon('sesion_version', $this->identidad->sesionVersion());
        } elseif ($versionSesion !== $this->identidad->sesionVersion()) {
            $this->sesion->vacia();
            $this->identidad->olvida();
            $this->sesion->avisa('Sesión cerrada. Entre de nuevo.', 'mal');
            return $this->afuera($peticion);
        }

        return $siguiente($peticion);
    }

    private function llevaMuchoQuieta(): bool
    {
        $minutos = $this->parametros->entero('minutos_sesion_inactiva', 120);

        // Un cero la deja abierta, y es decisión del dueño dicha a propósito.
        if ($minutos <= 0) {
            return false;
        }

        $ultimo = $this->sesion->saca(self::SELLO);

        // Una sesión de antes de que esto existiera no tiene sello. Se le pone
        // uno y se le deja pasar: echar a todo el mundo al desplegar sería un
        // susto sin motivo, y a los dos minutos ya está bajo la regla.
        if (!is_int($ultimo)) {
            return false;
        }

        return time() - $ultimo > $minutos * 60;
    }

    /** Una sesión de antes de este tope se adopta una vez, igual que el sello de uso. */
    private function rebasoElTope(): bool
    {
        $horas = $this->parametros->entero('horas_sesion_maxima', 12);
        $entro = $this->sesion->saca(self::ENTRADA);

        if (!is_int($entro)) {
            $this->sesion->pon(self::ENTRADA, time());
            return false;
        }

        return $horas > 0 && time() - $entro > $horas * 3600;
    }

    private function quietaParaSuPuesto(mixed $ultimoUso): bool
    {
        $minutos = $this->parametros->entero('minutos_sesion_inactiva_sensible', 30);

        return $minutos > 0 && is_int($ultimoUso) && time() - $ultimoUso > $minutos * 60;
    }

    /**
     * Al navegador, a la entrada, con la pantalla de vuelta; a quien pide JSON,
     * un 401 que sabe leer. ⚠️ Antes el AJAX recibía la redirección, la leía como
     * HTML y la pantalla decía «No se pudo guardar» sin explicar que la sesión
     * había terminado (homologación §S).
     */
    private function afuera(Peticion $peticion): Respuesta
    {
        if ($peticion->esperaJson()) {
            throw Errores::noAutenticado('Su sesión terminó.');
        }

        // Solo se vuelve a una pantalla: la ruta de un POST no se puede abrir.
        $vuelta = $peticion->metodo() === 'GET'
            ? \Controladores\Web\Entrada::vueltaValida($peticion->ruta() . $this->consultaSinSondeo($peticion))
            : null;

        return Respuesta::redireccion('/entrar' . ($vuelta !== null && !in_array($vuelta, ['/', '/panel'], true) ? '?vuelta=' . rawurlencode($vuelta) : ''));
    }

    /** La consulta de la pantalla, sin `sondeo`: al volver, la pantalla sí cuenta como uso. */
    private function consultaSinSondeo(Peticion $peticion): string
    {
        $consulta = $peticion->consultas();
        unset($consulta['sondeo']);

        return $consulta === [] ? '' : '?' . http_build_query($consulta);
    }
}
