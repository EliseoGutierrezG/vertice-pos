<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Nucleo\Peticion;
use Nucleo\Respuesta;

/**
 * Un eslabón de la cadena.
 *
 * Cada intermediario recibe la petición y la continuación. Puede:
 *  - dejar pasar:        return $siguiente($peticion);
 *  - cortar con error:   throw Errores::prohibido();
 *  - cortar con respuesta: return Respuesta::redireccion('/entrar');
 *
 * La cadena se declara por ruta, no por controlador. Quitar un permiso en la
 * base bloquea la acción sin tocar código: eso lo hace el intermediario de
 * permiso, que consulta la base, no una lista escrita a mano.
 */
interface Intermediario
{
    public function maneja(Peticion $peticion, callable $siguiente): Respuesta;
}
