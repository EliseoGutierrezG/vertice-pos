<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Nucleo\Atributos\Accion;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use ReflectionMethod;

/**
 * Lee por reflexión qué permiso exige la acción, y lo comprueba.
 *
 * El permiso no se escribe en la ruta: se declara junto al método que lo
 * necesita, con `#[Accion('pedidos_ver')]`. Así no hay dos sitios que puedan
 * discrepar.
 *
 * **Una acción sin atributo se rechaza.** Falla cerrado a propósito: olvidar
 * declarar el permiso no puede significar "entonces cualquiera puede".
 *
 * Quitar el permiso de un perfil en la base bloquea la acción sin tocar
 * código, porque lo que se compara viene de la consulta de Identidad.
 */
final class ExigePermiso implements Intermediario
{
    public function __construct(private Identidad $identidad)
    {
    }

    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        $destino = $peticion->destino();

        if ($destino === null) {
            throw Errores::prohibido('La ruta no declara a dónde va');
        }

        [$clase, $metodo] = $destino;

        if (!method_exists($clase, $metodo)) {
            throw Errores::noEncontrado();
        }

        $atributos = (new ReflectionMethod($clase, $metodo))->getAttributes(Accion::class);

        if ($atributos === []) {
            // No es 403: es un descuido nuestro, y tiene que doler.
            throw Errores::prohibido(
                'La acción no declara permiso. Falta el atributo #[Accion] en '
                . $clase . '::' . $metodo
            );
        }

        /** @var Accion $accion */
        $accion = $atributos[0]->newInstance();

        if ($accion->publica) {
            return $siguiente($peticion);
        }

        $permisos = array_values(array_filter(
            array_map('trim', explode(',', $accion->permiso)),
            static fn (string $permiso): bool => $permiso !== ''
        ));

        if ($permisos === []) {
            throw Errores::prohibido(
                'El atributo #[Accion] no dice qué permiso exige en '
                . $clase . '::' . $metodo
            );
        }

        if (!$this->identidad->hay()) {
            throw Errores::noAutenticado();
        }

        foreach ($permisos as $permiso) {
            if ($this->identidad->puede($permiso)) {
                return $siguiente($peticion);
            }
        }

        throw Errores::prohibido('Su puesto no tiene acceso. Consulte al administrador.', implode(' o ', $permisos));
    }
}
