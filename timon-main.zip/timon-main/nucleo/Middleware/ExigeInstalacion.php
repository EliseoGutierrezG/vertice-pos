<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Nucleo\Errores\Errores;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Servicios\Instalaciones;

/**
 * La puerta de la réplica: solo pasa un servidor de sucursal registrado, con
 * su secreto en `X-Instalacion`. No hay usuario: lo que escribe la réplica
 * queda en la bitácora a nombre de la instalación.
 */
final class ExigeInstalacion implements Intermediario
{
    public function __construct(private Instalaciones $instalaciones)
    {
    }

    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        $secreto = (string) ($peticion->cabecera('x-instalacion', '') ?? '');
        $instalacion = preg_match('/^[a-f0-9]{64}$/D', $secreto) === 1 ? $this->instalaciones->autentica($secreto) : null;
        if ($instalacion === null) {
            throw Errores::noAutenticado('Computadora de sucursal no registrada');
        }

        return $siguiente($peticion->conAcceso(['instalacion' => $instalacion]));
    }
}
