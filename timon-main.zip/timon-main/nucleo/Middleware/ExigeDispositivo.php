<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Nucleo\Errores\Errores;
use Nucleo\Peticion;
use Nucleo\Respuesta;

/**
 * Exige que el teléfono esté autorizado desde la web.
 *
 * Va DESPUÉS de ExigeToken, que es quien resuelve de qué dispositivo se
 * trata. Un teléfono recién registrado tiene token pero no autorización: la
 * app puede entrar, ver que está en espera y decirlo, pero no operar.
 *
 * Es 403 y no 401: quién es, ya se sabe. Lo que falta es el permiso, y
 * volver a pedir la contraseña no lo arreglaría.
 */
final class ExigeDispositivo implements Intermediario
{
    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        $acceso = $peticion->acceso();

        if ($acceso === null) {
            throw Errores::noAutenticado('Entre de nuevo');
        }

        if ((int) $acceso['autorizado'] !== 1) {
            throw Errores::prohibido(
                'Equipo sin autorizar. Avise a la gerencia de su sucursal.'
            );
        }

        return $siguiente($peticion);
    }
}
