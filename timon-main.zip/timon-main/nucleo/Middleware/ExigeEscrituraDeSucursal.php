<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Nucleo\Errores\Errores;
use Nucleo\Instalacion;
use Nucleo\Peticion;
use Nucleo\Respuesta;

/**
 * En el servidor de sucursal, el panel solo escribe la operación de la
 * sucursal: entrar, equipos, reservaciones, inventario y gastos. El resto
 * (menú, precios, personal, plano, contraseñas…) es del central y llega por
 * la réplica; si se cambiara aquí, la siguiente bajada lo pisaría.
 *
 * Falla cerrado: una ruta nueva que escribe queda bloqueada en la sucursal
 * hasta que se agregue a esta lista.
 */
final class ExigeEscrituraDeSucursal implements Intermediario
{
    private const SIN_EFECTO = ['GET', 'HEAD', 'OPTIONS'];

    /** Lo que sí se escribe en el servidor de sucursal. */
    public const PERMITIDAS = [
        '#^/(entrar|salir|segundo-factor|sesion/renovar)$#D',
        '#^/equipos-comanda(/\d+(/(autorizar|retirar))?)?$#D',
        '#^/reservaciones(/\d+)?$#D',
        '#^/inventario/#',
        '#^/gastos(/\d+(/cancelar)?)?$#D',
    ];

    public function __construct(private Instalacion $instalacion)
    {
    }

    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        if (!$this->instalacion->esSucursal() || in_array($peticion->metodo(), self::SIN_EFECTO, true)) {
            return $siguiente($peticion);
        }
        foreach (self::PERMITIDAS as $patron) {
            if (preg_match($patron, $peticion->ruta()) === 1) {
                return $siguiente($peticion);
            }
        }

        throw Errores::conflicto('Esto se cambia en el panel central.');
    }
}
