<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Nucleo\Atributos\Accion;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use ReflectionMethod;

/**
 * Quien entró con una contraseña temporal la cambia antes de hacer nada más.
 *
 * La temporal la vio alguien más —quien dio de alta al usuario o restableció
 * su contraseña—, así que mientras no se cambie la cuenta no es sólo de su
 * dueño. Va detrás de `ExigeSesion`, que carga la identidad, y deja pasar
 * únicamente las acciones marcadas `#[Accion(conClaveTemporal: true)]`:
 * cambiar la contraseña y salir.
 *
 * Al navegador lo manda a `/cambiar-clave`; a quien pide JSON le contesta un
 * 403 con la clave `clave_temporal`, que es lo que un modal sabe mostrar.
 */
final class ExigeClaveDefinitiva implements Intermediario
{
    public const PANTALLA = '/cambiar-clave';

    public function __construct(private Identidad $identidad)
    {
    }

    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        if (!$this->identidad->hay() || !$this->identidad->debeCambiarClave() || $this->dejaPasar($peticion)) {
            return $siguiente($peticion);
        }

        if ($peticion->esperaJson()) {
            throw new ErrorHttp(403, 'Su contraseña es temporal: cámbiela antes de seguir.', 'clave_temporal');
        }

        return Respuesta::redireccion(self::PANTALLA);
    }

    private function dejaPasar(Peticion $peticion): bool
    {
        $destino = $peticion->destino();

        if ($destino === null || !method_exists($destino[0], $destino[1])) {
            // Que lo rechace quien sabe hacerlo: `ExigePermiso`.
            return true;
        }

        foreach ((new ReflectionMethod($destino[0], $destino[1]))->getAttributes(Accion::class) as $atributo) {
            if ($atributo->newInstance()->conClaveTemporal) {
                return true;
            }
        }

        return false;
    }
}
