<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Nucleo\Atributos\Accion;
use Nucleo\BaseDatos;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Nucleo\Sesion;
use ReflectionMethod;
use Throwable;

/**
 * Un envío del panel se hace una sola vez (`esquema/062`).
 *
 * El navegador manda en cada POST la llave `_envio` (o la cabecera `X-Envio`):
 * un UUID por cada intención de guardar. Si el proceso tarda y llega el mismo
 * envío otra vez —un doble clic que el navegador no alcanzó a frenar, un
 * reintento, «Atrás» y Guardar—, se contesta lo mismo que la primera vez y el
 * trabajo **no se vuelve a hacer**.
 *
 * El orden importa:
 *
 *  1. Si la llave ya está «hecha», se repite la respuesta: el mismo destino y
 *     el mismo aviso. De otro usuario o de otra ruta, 409.
 *  2. Si es nueva, se **aparta** («en_curso») antes de hacer nada, en su propio
 *     `INSERT` fuera de toda transacción. Dos envíos simultáneos chocan en la
 *     llave primaria y solo uno pasa. No se envuelve el trabajo en una
 *     transacción a propósito: hay acciones que llaman afuera (el push a Expo)
 *     o guardan archivos, y retener la base mientras tanto estorba a todos.
 *  3. Si el trabajo sale bien (2xx o 3xx) se marca «hecho» con el destino y el
 *     aviso. Un error 4xx libera la llave para corregir; ante un fallo inesperado
 *     o un 5xx se conserva, pues pudo haber efectos ya realizados.
 *  4. Si la llave sigue «en_curso», el primero no ha terminado: 409, espere.
 *
 * **No se guarda el cuerpo**, solo el código, el destino y el aviso: aquí no
 * queda ninguna contraseña temporal. La ficha la sigue leyendo de la sesión,
 * una sola vez, como siempre.
 *
 * La llave es **obligatoria** donde repetir hace daño, `#[Accion(..., unaVez:
 * true)]`; en lo demás se respeta si llega. Solo va en el grupo web con sesión:
 * la app tiene su propia llave (`operacion_sincronizada`) y no cambia.
 */
final class ExigeEnvioUnico implements Intermediario
{
    private const SIN_EFECTO = ['GET', 'HEAD', 'OPTIONS'];
    private const FORMA = '/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/';

    public function __construct(
        private BaseDatos $bd,
        private Identidad $identidad,
        private Sesion $sesion
    ) {
    }

    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        if (in_array($peticion->metodo(), self::SIN_EFECTO, true) || !$this->identidad->hay()) {
            return $siguiente($peticion);
        }

        $llave = self::llave($peticion);

        if ($llave === '') {
            if ($this->exige($peticion)) {
                throw Errores::datosInvalidos([], 'Recargue la página antes de continuar');
            }

            return $siguiente($peticion);
        }

        if (preg_match(self::FORMA, $llave) !== 1) {
            throw Errores::datosInvalidos([], 'Recargue la página antes de continuar');
        }

        $ruta      = mb_substr($peticion->metodo() . ' ' . $peticion->ruta(), 0, 190);
        $idUsuario = $this->identidad->id();

        $previa = $this->busca($llave);
        if ($previa !== null) {
            return $this->repite($peticion, $previa, $ruta, $idUsuario);
        }

        try {
            $this->bd->ejecuta(
                'INSERT INTO envio_panel (llave, id_usuario, ruta) VALUES (?, ?, ?)',
                [$llave, $idUsuario, $ruta]
            );
        } catch (ErrorHttp $e) {
            // Otro envío con la misma llave la apartó un instante antes.
            $previa = $e->estado() === 409 ? $this->busca($llave) : null;
            if ($previa === null) {
                throw $e;
            }

            return $this->repite($peticion, $previa, $ruta, $idUsuario);
        }

        try {
            $respuesta = $siguiente($peticion);
        } catch (Throwable $e) {
            // Solo los errores de cliente permiten corregir y reintentar. Un
            // fallo inesperado puede ocurrir después de un efecto irreversible.
            if ($e instanceof ErrorHttp && $e->estado() >= 400 && $e->estado() < 500) {
                $this->suelta($llave);
            }
            throw $e;
        }

        if ($respuesta->estado() >= 400) {
            if ($respuesta->estado() < 500) {
                $this->suelta($llave);
            }
            return $respuesta;
        }

        $aviso = self::avisoPendiente();
        $this->bd->ejecuta(
            'UPDATE envio_panel SET estado = \'hecho\', codigo_http = ?, redirige = ?, aviso = ?, tono = ?, terminada_en = NOW() WHERE llave = ?',
            [
                $respuesta->estado(),
                self::destino($respuesta),
                $aviso === null ? null : mb_substr($aviso['texto'], 0, 255),
                $aviso === null ? null : mb_substr($aviso['tono'], 0, 12),
                $llave,
            ]
        );

        return $respuesta;
    }

    /** La llave del envío, del campo o de la cabecera, en minúsculas. */
    public static function llave(Peticion $peticion): string
    {
        $llave = $peticion->cabecera('x-envio');
        if ($llave === null) {
            $delCuerpo = $peticion->dato('_envio');
            $llave     = is_string($delCuerpo) ? $delCuerpo : '';
        }

        return strtolower(trim($llave));
    }

    private function exige(Peticion $peticion): bool
    {
        $destino = $peticion->destino();
        if ($destino === null || !method_exists($destino[0], $destino[1])) {
            return false;
        }

        $atributos = (new ReflectionMethod($destino[0], $destino[1]))->getAttributes(Accion::class);

        return $atributos !== [] && $atributos[0]->newInstance()->unaVez;
    }

    /** @return array<string,mixed>|null */
    private function busca(string $llave): ?array
    {
        return $this->bd->fila(
            'SELECT id_usuario, ruta, estado, redirige, aviso, tono FROM envio_panel WHERE llave = ?',
            [$llave]
        );
    }

    /** @param array<string,mixed> $previa */
    private function repite(Peticion $peticion, array $previa, string $ruta, int $idUsuario): Respuesta
    {
        // Una llave es de quien la mandó y para lo que la mandó.
        if ((int) $previa['id_usuario'] !== $idUsuario || (string) $previa['ruta'] !== $ruta) {
            throw Errores::conflicto('Recargue la página antes de continuar');
        }

        if ($previa['estado'] !== 'hecho') {
            throw Errores::ocupado('Envío sin confirmar. Espere y revise antes de guardar.');
        }

        $destino = $previa['redirige'];
        if (!is_string($destino) || $destino === '') {
            throw Errores::conflicto('Ya se guardó. Recargue la pantalla');
        }

        if (is_string($previa['aviso']) && $previa['aviso'] !== '') {
            $this->sesion->avisa($previa['aviso'], is_string($previa['tono']) && $previa['tono'] !== '' ? $previa['tono'] : 'bien');
        }

        return $peticion->esperaJson()
            ? Respuesta::json(['redirige' => $destino])
            : Respuesta::redireccion($destino);
    }

    private function suelta(string $llave): void
    {
        try {
            $this->bd->ejecuta('DELETE FROM envio_panel WHERE llave = ? AND estado = \'en_curso\'', [$llave]);
        } catch (Throwable) {
            // Si ni esto se puede, la llave queda apartada: un reintento con
            // ella recibe «espere» y uno con la página recargada pasa. Nunca
            // se hace dos veces, que es lo que importa.
        }
    }

    /** A dónde se mandó a la persona: `Location` o el `redirige` del JSON. */
    private static function destino(Respuesta $respuesta): ?string
    {
        foreach ($respuesta->cabeceras() as $nombre => $valor) {
            if (strcasecmp($nombre, 'Location') === 0) {
                return self::cabe($valor);
            }
        }

        if ($respuesta->esFlujo()) {
            return null;
        }

        $json = json_decode($respuesta->cuerpo(), true);
        $destino = is_array($json) && is_array($json['datos'] ?? null) ? ($json['datos']['redirige'] ?? null) : null;

        return is_string($destino) && $destino !== '' ? self::cabe($destino) : null;
    }

    /**
     * Un destino recortado mandaría a un enlace roto (un WhatsApp con el
     * mensaje a medias): si no cabe completo, no se guarda y la repetición
     * contesta «Ya se guardó» sin redirigir.
     */
    private static function cabe(string $destino): ?string
    {
        return mb_strlen($destino) <= 255 ? $destino : null;
    }

    /**
     * El aviso que dejó la acción, sin consumirlo: lo pinta la pantalla
     * siguiente. Se lee directo para no abrir otra sesión después de «Salir».
     *
     * @return array{texto:string,tono:string}|null
     */
    private static function avisoPendiente(): ?array
    {
        $aviso = isset($_SESSION) && is_array($_SESSION) ? ($_SESSION['aviso'] ?? null) : null;

        return is_array($aviso) && is_string($aviso['texto'] ?? null)
            ? ['texto' => $aviso['texto'], 'tono' => is_string($aviso['tono'] ?? null) ? $aviso['tono'] : 'bien']
            : null;
    }
}
