<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Nucleo\Errores\Errores;
use Nucleo\Peticion;
use Nucleo\Respuesta;
use Servicios\EquiposRestaurante;

final class ExigeEquipo implements Intermediario
{
    public function __construct(private EquiposRestaurante $equipos)
    {
    }

    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        if (!preg_match('/^Bearer ([a-f0-9]{64})$/iD', $peticion->cabecera('authorization', '') ?? '', $partes)) {
            throw Errores::noAutenticado('Entre con el PIN del equipo');
        }
        $acceso = $this->equipos->resuelve($partes[1], $peticion->metodo() !== 'GET');
        return $siguiente($peticion->conAcceso($acceso + ['token_equipo' => $partes[1]]));
    }
}
