<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Modelos\Tokens;
use Nucleo\ContextoAuditoria;
use Nucleo\Errores\Errores;
use Nucleo\Identidad;
use Nucleo\Peticion;
use Nucleo\Respuesta;

/**
 * Exige un token válido en la cabecera `Authorization: Bearer ...`.
 *
 * Carga la identidad igual que lo hace la sesión en la web, para que de aquí
 * en adelante los permisos se comprueben exactamente con el mismo código. Es
 * el punto: dos puertas de entrada, una sola autoridad.
 */
final class ExigeToken implements Intermediario
{
    public function __construct(
        private Tokens $tokens,
        private Identidad $identidad,
        private ContextoAuditoria $auditoria
    ) {
    }

    public function maneja(Peticion $peticion, callable $siguiente): Respuesta
    {
        $cabecera = $peticion->cabecera('authorization', '') ?? '';

        if (!preg_match('/^Bearer\s+(\S+)$/i', $cabecera, $coincidencia)) {
            throw Errores::noAutenticado('Entre de nuevo');
        }

        $acceso = $this->tokens->resuelve($coincidencia[1]);

        if ($acceso === null) {
            throw Errores::noAutenticado('Sesión vencida. Entre de nuevo');
        }

        $this->identidad->establece((int) $acceso['id_usuario']);
        $this->auditoria->dispositivo((int) $acceso['id_dispositivo']);

        return $siguiente($peticion->conAcceso($acceso));
    }
}
