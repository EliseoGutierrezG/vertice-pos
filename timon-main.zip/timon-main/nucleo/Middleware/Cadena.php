<?php
declare(strict_types=1);

namespace Nucleo\Middleware;

use Nucleo\Contenedor;
use Nucleo\Peticion;
use Nucleo\Respuesta;

/**
 * Arma la cadena de intermediarios alrededor del destino final.
 *
 * Se recorre la lista al revés para que el PRIMERO declarado sea el primero
 * en ejecutarse. El orden importa: identidad antes que permiso, porque no se
 * puede preguntar qué puede hacer alguien de quien todavía no se sabe quién es.
 */
final class Cadena
{
    /** @param list<string> $intermediarios */
    public function __construct(
        private array $intermediarios,
        private Contenedor $contenedor
    ) {
    }

    public function ejecutar(Peticion $peticion, callable $destino): Respuesta
    {
        $siguiente = $destino;

        foreach (array_reverse($this->intermediarios) as $nombre) {
            $anterior = $siguiente;
            $siguiente = function (Peticion $peticion) use ($nombre, $anterior): Respuesta {
                [$clase, $argumento] = array_pad(explode(':', $nombre, 2), 2, null);
                /** @var Intermediario $instancia */
                $instancia = $this->contenedor->intermediario((string) $clase, $argumento);
                return $instancia->maneja($peticion, $anterior);
            };
        }

        return $siguiente($peticion);
    }
}
