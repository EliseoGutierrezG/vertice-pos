<?php
declare(strict_types=1);

namespace Nucleo;

use Nucleo\Middleware\Intermediario;
use ReflectionClass;
use ReflectionNamedType;
use RuntimeException;

/**
 * Quien arma las piezas. Un contenedor pequeño, a propósito.
 *
 * Guarda lo compartido (base de datos, registro, bitácora, configuración) y
 * construye controladores e intermediarios mirando lo que piden en su
 * constructor. No hay archivo de definiciones que mantener: si un controlador
 * pide BaseDatos, la recibe.
 *
 * La conexión se abre la PRIMERA vez que alguien la pide, no al arrancar: una
 * ruta que no toca la base no paga el costo de conectarse.
 */
final class Contenedor
{
    /** @var array<string,object> */
    private array $compartidos = [];
    /** @var array<string,callable> */
    private array $recetas = [];

    /** @param array<string,mixed> $config */
    public function __construct(private array $config)
    {
        // Se comparte a sí mismo. Sin esto, una clase que pida el contenedor
        // hace que el contenedor intente construir OTRO contenedor, y el
        // segundo no tiene con qué. Lo piden los pocos casos que necesitan
        // resolver algo tarde: el latido de la API, que debe responder aunque
        // la base esté caída, no puede recibir la conexión ya abierta.
        $this->compartidos[self::class] = $this;
    }

    /** Registra cómo construir algo, sin construirlo todavía. */
    public function receta(string $clase, callable $como): void
    {
        $this->recetas[$clase] = $como;
    }

    public function comparte(string $clase, object $instancia): void
    {
        $this->compartidos[$clase] = $instancia;
    }

    public function config(string $llave, mixed $porOmision = null): mixed
    {
        return $this->config[$llave] ?? $porOmision;
    }

    public function obtiene(string $clase): object
    {
        if (isset($this->compartidos[$clase])) {
            return $this->compartidos[$clase];
        }

        if (isset($this->recetas[$clase])) {
            $this->compartidos[$clase] = ($this->recetas[$clase])($this);
            return $this->compartidos[$clase];
        }

        // Lo construido se guarda. Sin esto, cada inyección recibiría su
        // propio ejemplar: el intermediario cargaría la identidad en uno y el
        // controlador recibiría otro vacío. Una petición, un ejemplar de cada
        // servicio.
        $this->compartidos[$clase] = $this->construye($clase);

        return $this->compartidos[$clase];
    }

    /**
     * Un intermediario, con su argumento opcional: 'permiso:pedidos_ver'.
     *
     * No se guarda: el mismo intermediario puede aparecer dos veces en una
     * misma cadena con argumentos distintos.
     */
    public function intermediario(string $clase, ?string $argumento): Intermediario
    {
        $instancia = $this->construye($clase, $argumento === null ? [] : [$argumento]);

        if (!$instancia instanceof Intermediario) {
            throw new RuntimeException($clase . ' no es un intermediario');
        }

        return $instancia;
    }

    /** @param list<mixed> $extras Argumentos que van al final del constructor. */
    public function construye(string $clase, array $extras = []): object
    {
        if (!class_exists($clase)) {
            throw new RuntimeException('No existe la clase ' . $clase);
        }

        $reflexion   = new ReflectionClass($clase);
        $constructor = $reflexion->getConstructor();

        if ($constructor === null) {
            return $reflexion->newInstance();
        }

        $argumentos = [];
        foreach ($constructor->getParameters() as $parametro) {
            $tipo = $parametro->getType();

            if ($tipo instanceof ReflectionNamedType && !$tipo->isBuiltin()) {
                $argumentos[] = $this->obtiene($tipo->getName());
                continue;
            }

            if ($extras !== []) {
                $argumentos[] = array_shift($extras);
                continue;
            }

            if ($parametro->isDefaultValueAvailable()) {
                $argumentos[] = $parametro->getDefaultValue();
                continue;
            }

            throw new RuntimeException(
                'No se puede construir ' . $clase . ': falta el argumento $' . $parametro->getName()
            );
        }

        return $reflexion->newInstanceArgs($argumentos);
    }
}
