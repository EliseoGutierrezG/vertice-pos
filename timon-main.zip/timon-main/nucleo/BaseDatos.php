<?php
declare(strict_types=1);

namespace Nucleo;

use mysqli;
use mysqli_sql_exception;
use mysqli_stmt;
use Nucleo\Errores\ErrorHttp;
use Nucleo\Errores\Errores;
use Throwable;

/**
 * La capa de base de datos. `mysqli`, siempre preparado, siempre con tipos.
 *
 * Reglas que esta clase impone y no se pueden esquivar:
 *  - No existe un método que reciba SQL ya interpolado con valores. `escapa()`
 *    devuelve un valor escapado para escribirlo en un archivo, y una regla de
 *    arquitectura falla si aparece fuera del guion de respaldo.
 *  - Los errores del motor llegan como excepción, no como `false` silencioso.
 *  - Una transacción que falla deja la base como estaba.
 *
 * Es la respuesta directa a lo que se documentó de la referencia, donde las
 * consultas se armaban concatenando variables dentro de la cadena SQL.
 */
final class BaseDatos
{
    private mysqli $conexion;
    private int $profundidadDeTransaccion = 0;

    /** @param array{host:string,base:string,usuario:string,clave:string,puerto:int} $config */
    public function __construct(private array $config)
    {
        // Que el motor hable: excepción en lugar de un false que nadie mira.
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        try {
            $this->conexion = new mysqli(
                $config['host'],
                $config['usuario'],
                $config['clave'],
                $config['base'],
                $config['puerto']
            );
        } catch (mysqli_sql_exception $e) {
            // El mensaje del motor puede llevar el usuario: no se propaga.
            throw new \RuntimeException('No se pudo conectar a la base de datos', 0, $e);
        }

        $this->conexion->set_charset('utf8mb4');
        // Fechas y horas del negocio, no las del servidor, y **las mismas que
        // las de PHP**: aquí se le pone al motor el desplazamiento en el que
        // está PHP, para que `CURDATE()` y `date('Y-m-d')` no puedan contestar
        // días distintos. La razón de mandar el desplazamiento y no el nombre
        // de la zona está en `Reloj::desplazamiento()`.
        $desplazamiento = Reloj::desplazamiento();

        try {
            $this->conexion->query("SET time_zone = '" . $desplazamiento . "'");
        } catch (mysqli_sql_exception $e) {
            // Medido en MariaDB 10.11: sólo acepta de «-12:59» a «+13:00». Ninguna
            // zona de México se acerca, pero si alguien configura una que sí, más
            // vale decir qué hay que cambiar que dejar salir el error del motor.
            throw new \RuntimeException(
                'El motor no acepta el desplazamiento ' . $desplazamiento . ' de la zona '
                . date_default_timezone_get() . ' (config/app.php, zona_horaria)',
                0,
                $e
            );
        }

        // Que el motor rechace lo que está mal en lugar de acomodarlo.
        $this->conexion->query(
            "SET sql_mode = 'STRICT_ALL_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'"
        );

        // Con servidores de sucursal, cada instalación genera ids distintos:
        // de 100 en 100, a partir de su desplazamiento. Así una fila conserva
        // su id en el central y en la sucursal (ver Configuracion::instalacion).
        if (isset($config['desplazamiento'])) {
            $sentencia = $this->conexion->prepare('SET SESSION auto_increment_increment = ?, auto_increment_offset = ?');
            $incremento = Configuracion::INCREMENTO_IDS;
            $desplazamiento = (int) $config['desplazamiento'];
            $sentencia->bind_param('ii', $incremento, $desplazamiento);
            $sentencia->execute();
            $sentencia->close();
        }
    }

    /** El desplazamiento de ids de esta conexión, o null si es una instalación sola. */
    public function desplazamiento(): ?int
    {
        return isset($this->config['desplazamiento']) ? (int) $this->config['desplazamiento'] : null;
    }

    /**
     * Todas las filas.
     *
     * @param list<mixed> $parametros
     * @return list<array<string,mixed>>
     */
    public function filas(string $sql, array $parametros = []): array
    {
        $sentencia = $this->prepara($sql, $parametros);
        $resultado = $sentencia->get_result();
        $filas     = $resultado === false ? [] : $resultado->fetch_all(MYSQLI_ASSOC);
        $sentencia->close();

        return $filas;
    }

    /**
     * La primera fila, o null.
     *
     * @param list<mixed> $parametros
     * @return array<string,mixed>|null
     */
    public function fila(string $sql, array $parametros = []): ?array
    {
        $filas = $this->filas($sql, $parametros);

        return $filas[0] ?? null;
    }

    /**
     * Las filas de una en una, sin armar el arreglo con todas.
     *
     * `filas()` sirve para lo que cabe en una pantalla, que es casi todo. Esto
     * es para lo que no cabe: recorrer `movimiento` entero para respaldarlo.
     *
     * **Con precisión, porque la diferencia importa**: el juego de resultados sí
     * viaja completo del motor al cliente —así funciona `mysqlnd`—, lo que no se
     * arma es el arreglo de PHP con dos millones de arreglos asociativos dentro,
     * que es donde está la mayor parte del gasto. Si algún día tampoco alcanza
     * con eso, el paso siguiente es leer por trozos con `LIMIT`, no cambiar esto.
     *
     * @param list<mixed> $parametros
     * @return \Generator<int, array<string,mixed>>
     */
    public function porRenglon(string $sql, array $parametros = []): \Generator
    {
        $sentencia = $this->prepara($sql, $parametros);
        $resultado = $sentencia->get_result();

        if ($resultado !== false) {
            while (($fila = $resultado->fetch_assoc()) !== null) {
                yield $fila;
            }
        }

        $sentencia->close();
    }

    /**
     * Escapa un valor **para escribirlo en un archivo**, nunca para una consulta.
     *
     * Existe por el respaldo, que tiene que producir un `.sql` de texto: ahí no
     * hay consulta preparada donde poner un parámetro, porque lo que se genera
     * *es* el SQL. Fuera de ahí no tiene ningún uso legítimo, y hay una regla
     * de arquitectura que falla si aparece en otro archivo.
     */
    public function escapa(string $valor): string
    {
        return $this->conexion->real_escape_string($valor);
    }

    /**
     * El primer valor de la primera fila, o null. Para COUNT y semejantes.
     *
     * @param list<mixed> $parametros
     */
    public function valor(string $sql, array $parametros = []): mixed
    {
        $fila = $this->fila($sql, $parametros);
        if ($fila === null) {
            return null;
        }

        return array_values($fila)[0] ?? null;
    }

    /**
     * INSERT, UPDATE o DELETE. Devuelve cuántas filas cambiaron.
     *
     * @param list<mixed> $parametros
     */
    public function ejecuta(string $sql, array $parametros = []): int
    {
        $sentencia = $this->prepara($sql, $parametros);
        $afectadas = $sentencia->affected_rows;
        $sentencia->close();

        return $afectadas;
    }

    /**
     * INSERT que devuelve el id recién creado.
     *
     * @param list<mixed> $parametros
     */
    public function inserta(string $sql, array $parametros = []): int
    {
        $sentencia = $this->prepara($sql, $parametros);
        $id        = (int) $this->conexion->insert_id;
        $sentencia->close();

        return $id;
    }

    /**
     * Guarda una sola vez, aunque lleguen dos a la vez.
     *
     * Es el contrato de la llave de idempotencia: «mandar lo mismo dos veces
     * devuelve lo mismo y no mueve nada dos veces» (arquitectura §11.1). `$busca`
     * dice qué hay guardado con esa llave, o `null`; `$guarda` hace el trabajo.
     * Sin llave —`$busca` en `null`— esto es una transacción y nada más.
     *
     * ⚠️ **Mirar antes no alcanza.** Si los dos envíos llegan al mismo instante,
     * los dos ven que no está y los dos siguen. La llave única de la tabla deja
     * pasar a uno —eso está bien: el trabajo no se hace dos veces— y al otro le
     * devuelve un **409**. Y un 409 es lo único que la app llama «rechazo»:
     * marca la operación **atorada** y detiene la cola, que es exactamente lo
     * que la llave venía a evitar. Medido con dos procesos de verdad en
     * `pruebas/concurrencia.sh`: un pedido, una salida, la mercancía salió una
     * vez, y a uno de los dos se le contestó conflicto.
     *
     * Cuando el motor devuelve el duplicado, el renglón del otro **ya está
     * confirmado** —el `INSERT` se quedó esperando a que su transacción
     * cerrara—, así que preguntar otra vez da la respuesta que había que dar
     * desde el principio. Si con esa llave no hay nada, el conflicto era otro y
     * sale como vino.
     *
     * @template T
     * @param (callable():?T)|null $busca
     * @param callable():T $guarda
     * @return T
     */
    public function guardaUnaSolaVez(?callable $busca, callable $guarda): mixed
    {
        if ($busca !== null) {
            $yaEsta = $busca();

            if ($yaEsta !== null) {
                return $yaEsta;
            }
        }

        try {
            return $this->transaccion($guarda);
        } catch (ErrorHttp $e) {
            if ($busca === null || $e->estado() !== 409) {
                throw $e;
            }

            $yaEsta = $busca();

            if ($yaEsta === null) {
                throw $e;
            }

            return $yaEsta;
        }
    }

    /**
     * Ejecuta el trabajo dentro de una transacción.
     *
     * Si el trabajo lanza cualquier excepción, se deshace todo y la excepción
     * sigue su camino. No hay forma de quedarse a medias: o cuadra o no pasó.
     *
     * Admite anidarse con puntos de retorno, para que un servicio pueda usar
     * a otro sin saber si ya venía dentro de una transacción.
     */
    public function transaccion(callable $trabajo): mixed
    {
        if ($this->profundidadDeTransaccion === 0) {
            $this->conexion->begin_transaction();
        } else {
            $this->conexion->savepoint('nivel_' . $this->profundidadDeTransaccion);
        }

        $this->profundidadDeTransaccion++;

        try {
            $resultado = $trabajo($this);
        } catch (Throwable $e) {
            $this->profundidadDeTransaccion--;
            if ($this->profundidadDeTransaccion === 0) {
                $this->conexion->rollback();
            } else {
                // Ojo: mysqli::rollback() con nombre NO deshace hasta un punto
                // de retorno, manda otra cosa. La sentencia va explícita.
                //
                // ⚠️ Y va envuelta, porque puede fallar por una razón legítima:
                // si el choque fue un **interbloqueo**, MariaDB ya deshizo la
                // transacción entera y el punto de retorno dejó de existir.
                // Medido: la falla del punto de retorno **reemplazaba** a la
                // original, así que en lugar de «otra operación tocaba lo mismo,
                // vuelve a intentar» —un 409 con instrucción— salía
                // «SAVEPOINT nivel_1 does not exist», que no es un `ErrorHttp` y
                // por lo tanto sale por 500, y el registro de errores se queda
                // con el mensaje que no explica nada. Lo que hay que conservar
                // es la falla original: es la única que dice qué pasó.
                try {
                    $this->conexion->query(
                        'ROLLBACK TO SAVEPOINT nivel_' . $this->profundidadDeTransaccion
                    );
                } catch (Throwable) {
                    // El nivel de arriba deshará lo que quede. Aquí no hay nada
                    // que decir que valga más que `$e`.
                }
            }
            throw $e;
        }

        $this->profundidadDeTransaccion--;
        if ($this->profundidadDeTransaccion === 0) {
            $this->conexion->commit();
        } else {
            $this->conexion->release_savepoint('nivel_' . $this->profundidadDeTransaccion);
        }

        return $resultado;
    }

    public function enTransaccion(): bool
    {
        return $this->profundidadDeTransaccion > 0;
    }

    /**
     * Abre otra conexión con la misma configuración.
     *
     * Se reserva para registros de seguridad que deben sobrevivir al retroceso
     * de una operación de negocio rechazada (por ejemplo, un intento de
     * autorización inválido dentro de la edición transaccional de un pedido).
     */
    public function independiente(): self
    {
        return new self($this->config);
    }

    /** @param list<mixed> $parametros */
    private function prepara(string $sql, array $parametros): mysqli_stmt
    {
        try {
            $sentencia = $this->conexion->prepare($sql);

            if ($parametros !== []) {
                $sentencia->bind_param($this->tipos($parametros), ...$parametros);
            }

            $sentencia->execute();

            return $sentencia;
        } catch (mysqli_sql_exception $e) {
            throw $this->traduce($e);
        }
    }

    /**
     * Los tipos para bind_param, deducidos del valor de PHP.
     *
     * @param list<mixed> $parametros
     */
    private function tipos(array $parametros): string
    {
        $tipos = '';
        foreach ($parametros as $valor) {
            $tipos .= match (true) {
                is_int($valor)   => 'i',
                is_float($valor) => 'd',
                is_bool($valor)  => 'i',
                default          => 's',   // null incluido: viaja como NULL
            };
        }

        return $tipos;
    }

    /**
     * Traduce lo que el motor rechaza por el estado de los datos.
     *
     * Un duplicado o una llave foránea rota son conflictos con la realidad,
     * no fallas del servidor: 409, no 500. Lo demás sí es falla nuestra y se
     * deja pasar tal cual para que quede en el registro con su traza.
     */
    private function traduce(mysqli_sql_exception $e): Throwable
    {
        return match ($e->getCode()) {
            1062    => Errores::conflicto('Ya existe un registro con esos datos'),
            1451    => Errores::conflicto('No se puede borrar: está en uso'),
            1452    => Errores::conflicto('Ese registro ya no existe'),
            // Dos operaciones se estorbaron. No es una falla del servidor: es el
            // estado actual diciendo que no, y volver a intentar suele bastar.
            // MariaDB ya deshizo la transacción entera al devolver esto.
            1213    => Errores::ocupado('Otra operación está en curso. Intente de nuevo.'),
            1205    => Errores::ocupado('Otra operación está en curso. Intente de nuevo.'),
            default => $e,
        };
    }
}
