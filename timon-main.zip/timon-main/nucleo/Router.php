<?php
declare(strict_types=1);

namespace Nucleo;

use Nucleo\Errores\Errores;

/**
 * La tabla de rutas.
 *
 * Esto es lo que le faltaba a la plantilla base: allí la URL llevaba el controlador y
 * la acción como parámetros (?controlador=x&accion=y). Aquí la URL es limpia
 * y la correspondencia está declarada en un solo archivo por árbol.
 *
 * Dos árboles, con protecciones distintas:
 *   rutas/web.php  → sesión y marca CSRF
 *   rutas/api.php  → token y dispositivo autorizado
 */
final class Router
{
    /** @var list<Ruta> */
    private array $rutas = [];

    private string $prefijo = '';
    /** @var list<string> */
    private array $intermediariosDelGrupo = [];

    /** @param array{0:class-string,1:string} $destino */
    public function get(string $patron, array $destino): Ruta
    {
        return $this->agrega('GET', $patron, $destino);
    }

    /** @param array{0:class-string,1:string} $destino */
    public function post(string $patron, array $destino): Ruta
    {
        return $this->agrega('POST', $patron, $destino);
    }

    /** @param array{0:class-string,1:string} $destino */
    public function put(string $patron, array $destino): Ruta
    {
        return $this->agrega('PUT', $patron, $destino);
    }

    /** @param array{0:class-string,1:string} $destino */
    public function patch(string $patron, array $destino): Ruta
    {
        return $this->agrega('PATCH', $patron, $destino);
    }

    /** @param array{0:class-string,1:string} $destino */
    public function delete(string $patron, array $destino): Ruta
    {
        return $this->agrega('DELETE', $patron, $destino);
    }

    /**
     * Un grupo con prefijo e intermediarios comunes.
     *
     * $r->grupo('/api/v1', ['token', 'dispositivo'], function (Router $r) { ... });
     *
     * @param list<string> $intermediarios
     */
    public function grupo(string $prefijo, array $intermediarios, callable $definicion): void
    {
        $prefijoAnterior       = $this->prefijo;
        $intermediariosAnterior = $this->intermediariosDelGrupo;

        $this->prefijo                = $prefijoAnterior . $prefijo;
        $this->intermediariosDelGrupo = [...$intermediariosAnterior, ...$intermediarios];

        $definicion($this);

        $this->prefijo                = $prefijoAnterior;
        $this->intermediariosDelGrupo = $intermediariosAnterior;
    }

    /** @param array{0:class-string,1:string} $destino */
    private function agrega(string $metodo, string $patron, array $destino): Ruta
    {
        $completo = $this->prefijo . $patron;
        $completo = '/' . trim($completo, '/');
        if ($completo === '/') {
            $completo = '/';
        }

        $ruta = new Ruta($metodo, $completo, $destino);
        if ($this->intermediariosDelGrupo !== []) {
            $ruta->protege($this->intermediariosDelGrupo);
        }

        $this->rutas[] = $ruta;

        return $ruta;
    }

    /**
     * Encuentra la ruta que atiende esta petición.
     *
     * Si el camino existe pero con otro verbo, es 405 con la cabecera Allow,
     * no 404. Decirle "no existe" a quien mandó POST a una ruta que sólo
     * atiende GET es mentirle.
     *
     * @return array{0:Ruta,1:array<string,string>}
     */
    public function resuelve(Peticion $peticion): array
    {
        $verbosDelCamino = [];

        foreach ($this->rutas as $ruta) {
            $parametros = $ruta->coincide($peticion->ruta());
            if ($parametros === null) {
                continue;
            }

            if ($ruta->metodo() === $peticion->metodo()) {
                return [$ruta, $parametros];
            }

            $verbosDelCamino[] = $ruta->metodo();
        }

        if ($verbosDelCamino !== []) {
            throw Errores::metodoNoPermitido(
                'La ruta existe, pero no atiende ' . $peticion->metodo()
                . '. Acepta: ' . implode(', ', array_unique($verbosDelCamino))
            );
        }

        throw Errores::noEncontrado('La ruta ' . $peticion->ruta() . ' no existe');
    }

    /** @return list<Ruta> */
    public function rutas(): array
    {
        return $this->rutas;
    }
}
