<?php
declare(strict_types=1);

namespace Nucleo;

/**
 * La bitácora del negocio: quién, cuándo, qué había antes y qué quedó.
 *
 * No es el registro de errores. Aquí van los cambios que alguien hizo sobre
 * los datos, que es lo que se pidió en la respuesta 9.3 del cuestionario:
 * poder responder "¿quién movió esto?" sin adivinar.
 *
 * Comparte la conexión con quien la llama, así que **va dentro de su misma
 * transacción**: si el cambio se deshace, el apunte se deshace con él. Es lo
 * que se quiere —que la bitácora no afirme cambios que nunca ocurrieron—,
 * pero tiene su contraparte: los intentos rechazados no se ven aquí. Ésos
 * quedan en el registro de archivo, que sí es independiente.
 */
final class Bitacora
{
    /**
     * Lo que nunca se copia a la bitácora, aunque un servicio lo pase.
     * ⚠️ `clave` a secas no va aquí: en parámetros es el nombre del parámetro y
     * `Servicios\Seguridad` lo busca dentro de `despues`.
     */
    private const SECRETOS = [
        'clave_hash', 'contrasena', 'password', 'clave_nueva', 'clave_actual', 'token', 'token_hash', 'secreto',
        'totp_secreto', 'totp_cifrado', 'llave', 'llave_idempotencia', 'foto', 'selfie',
    ];

    /** Sirve saber que cambió y cuál era, no tener el dato completo a la vista. */
    private const CONTACTO = ['telefono', 'telefono2', 'celular', 'whatsapp', 'correo', 'email', 'curp', 'rfc', 'nss'];

    public function __construct(
        private BaseDatos $bd,
        private Registro $registro,
        private ?ContextoAuditoria $contexto = null
    ) {
    }

    /**
     * @param array<string,mixed>|null $antes
     * @param array<string,mixed>|null $despues
     */
    public function registra(
        string $modulo,
        string $accion,
        ?string $entidad = null,
        ?int $idEntidad = null,
        ?array $antes = null,
        ?array $despues = null,
        ?int $idUsuario = null,
        ?string $ip = null
    ): void {
        try {
            $contexto = ($this->contexto ?? new ContextoAuditoria())->datos();
            $this->bd->ejecuta(
                'INSERT INTO bitacora
                    (id_usuario, modulo, accion, entidad, id_entidad, antes, despues, ip,
                     canal, operacion, ruta, accion_ruta, id_dispositivo, correlacion_hash)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    $idUsuario,
                    $modulo,
                    $accion,
                    $entidad,
                    $idEntidad,
                    $antes   === null ? null : json_encode(self::enmascara($antes), JSON_UNESCAPED_UNICODE),
                    $despues === null ? null : json_encode(self::enmascara($despues), JSON_UNESCAPED_UNICODE),
                    $ip,
                    $contexto['canal'],
                    $contexto['operacion'],
                    $contexto['ruta'],
                    $contexto['accion_ruta'],
                    $contexto['id_dispositivo'],
                    $contexto['correlacion_hash'],
                ]
            );
        } catch (\Throwable $e) {
            // Sin bitácora no hay operación auditable. Se registra sin repetir
            // argumentos del negocio ni secretos y se conserva la excepción
            // original para que la transacción completa se revierta.
            $this->registro->error('No se pudo escribir en la bitácora', [], $e);
            throw $e;
        }
    }

    /**
     * Incorpora un apunte que ya se escribió en un servidor de sucursal. Entra
     * con un id nuevo de aquí (el sello encadena por id) y conserva su origen,
     * que impide incorporarlo dos veces. Las columnas ya vienen revisadas.
     *
     * @param array<string,mixed> $apunte sin `id`, con su `momento` original
     * @return int 1 si entró, 0 si ya estaba
     */
    public function incorporaDeSucursal(int $instalacion, int $origen, array $apunte): int
    {
        if ($this->bd->valor('SELECT id FROM bitacora WHERE origen_instalacion = ? AND origen_id = ?', [$instalacion, $origen]) !== null) {
            return 0;
        }
        unset($apunte['id'], $apunte['origen_instalacion'], $apunte['origen_id']);
        $apunte['origen_instalacion'] = $instalacion;
        $apunte['origen_id'] = $origen;
        $this->bd->ejecuta('INSERT INTO bitacora (' . implode(', ', array_keys($apunte)) . ') VALUES ('
            . implode(', ', array_fill(0, count($apunte), '?')) . ')', array_values($apunte));

        return 1;
    }

    /**
     * Quita secretos y recorta datos de contacto, a cualquier profundidad.
     *
     * @param array<array-key,mixed> $datos
     * @return array<array-key,mixed>
     */
    public static function enmascara(array $datos): array
    {
        foreach ($datos as $llave => $valor) {
            $nombre = is_string($llave) ? strtolower($llave) : '';

            if (is_array($valor)) {
                $datos[$llave] = self::enmascara($valor);
            } elseif ($valor === null || $valor === '') {
                continue;
            } elseif (in_array($nombre, self::SECRETOS, true)) {
                $datos[$llave] = '[oculto]';
            } elseif (in_array($nombre, self::CONTACTO, true) && is_scalar($valor)) {
                $datos[$llave] = self::recorta((string) $valor);
            }
        }

        return $datos;
    }

    /** `••••••••34` o `a•••@dominio.mx`. */
    private static function recorta(string $valor): string
    {
        $arroba = mb_strpos($valor, '@');
        if ($arroba !== false && $arroba > 0) {
            return mb_substr($valor, 0, 1) . '•••' . mb_substr($valor, $arroba);
        }

        $largo = mb_strlen($valor);

        return $largo <= 2 ? '••' : str_repeat('•', $largo - 2) . mb_substr($valor, -2);
    }
}
