<?php
declare(strict_types=1);

namespace Nucleo;

/**
 * Metadatos comunes a todos los apuntes producidos por una petición o tarea.
 *
 * No contiene datos del negocio ni secretos. La llave de idempotencia se
 * conserva sólo como SHA-256 para poder correlacionar reintentos sin exponerla.
 */
final class ContextoAuditoria
{
    private string $canal = 'guion';
    private string $operacion;
    private ?string $ruta = null;
    private ?string $accion = null;
    private ?int $idDispositivo = null;
    private ?string $correlacionHash = null;

    public function __construct()
    {
        $this->operacion = LlaveOperacion::nueva();
    }

    public function iniciaPeticion(Peticion $peticion, Ruta $ruta): void
    {
        $this->canal = str_starts_with($peticion->ruta(), '/api/') ? 'api' : 'web';
        $this->operacion = LlaveOperacion::nueva();
        $this->ruta = $ruta->patron();
        $this->accion = $ruta->nombre();

        $llave = trim((string) ($peticion->cabecera('idempotency-key', '') ?? ''));
        if ($llave === '' && $this->canal === 'api') {
            $llave = trim((string) $peticion->dato('llave_idempotencia', ''));
        }
        $this->correlacionHash = $llave === '' ? null : hash('sha256', $llave);
    }

    public function comoTarea(?string $accion = null): self
    {
        $this->canal = 'tarea';
        $this->accion = $accion;
        return $this;
    }

    public function comoGuion(?string $accion = null): self
    {
        $this->canal = 'guion';
        $this->accion = $accion;
        return $this;
    }

    public function dispositivo(?int $id): void
    {
        $this->idDispositivo = $id !== null && $id > 0 ? $id : null;
    }

    public function correlacion(string $llave): void
    {
        $llave = trim($llave);
        $this->correlacionHash = $llave === '' ? null : hash('sha256', $llave);
    }

    /** @return array{canal:string,operacion:string,ruta:?string,accion_ruta:?string,id_dispositivo:?int,correlacion_hash:?string} */
    public function datos(): array
    {
        return [
            'canal' => $this->canal,
            'operacion' => $this->operacion,
            'ruta' => $this->ruta,
            'accion_ruta' => $this->accion,
            'id_dispositivo' => $this->idDispositivo,
            'correlacion_hash' => $this->correlacionHash,
        ];
    }
}
