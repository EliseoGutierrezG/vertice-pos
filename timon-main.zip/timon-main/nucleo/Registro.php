<?php
declare(strict_types=1);

namespace Nucleo;

use Throwable;

/**
 * El registro de errores, en archivo y fuera de publico/.
 *
 * Lo que aquí se escribe es para nosotros: puede llevar traza. Lo que sale
 * por HTTP es para el cliente: nunca la lleva. Esa frontera es el punto.
 */
final class Registro
{
    /**
     * Cuánto se guarda. Noventa días cubren «esto empezó a pasar el mes pasado»,
     * que es la pregunta que se le hace al registro, sin llenar el disco.
     */
    private const DIAS_QUE_SE_GUARDAN = 90;

    public function __construct(
        private string $carpeta,
        private bool $conTraza
    ) {
        if (!is_dir($this->carpeta)) {
            mkdir($this->carpeta, 0750, true);
        }
    }

    /** @param array<string,mixed> $contexto */
    public function error(string $mensaje, array $contexto = [], ?Throwable $e = null): void
    {
        $linea = sprintf(
            "[%s] ERROR %s%s",
            date('Y-m-d H:i:s'),
            $mensaje,
            $contexto === [] ? '' : ' ' . json_encode($contexto, JSON_UNESCAPED_UNICODE)
        );

        if ($e !== null) {
            $linea .= sprintf(
                "\n    %s: %s en %s:%d",
                $e::class,
                $e->getMessage(),
                $e->getFile(),
                $e->getLine()
            );
            if ($this->conTraza) {
                $linea .= "\n" . $this->traza($e);
            }
        }

        $this->escribe($linea);
    }

    /** @param array<string,mixed> $contexto */
    public function aviso(string $mensaje, array $contexto = []): void
    {
        $this->escribe(sprintf(
            "[%s] AVISO %s%s",
            date('Y-m-d H:i:s'),
            $mensaje,
            $contexto === [] ? '' : ' ' . json_encode($contexto, JSON_UNESCAPED_UNICODE)
        ));
    }

    /**
     * La traza: por dónde pasó, **no con qué**.
     *
     * ⚠️ `getTraceAsString()` escribe los argumentos de cada llamada, y los de
     * texto con sus primeros quince caracteres. Medido: una contraseña de
     * diecisiete caracteres quedaba en el registro como
     * `claveCorrecta(Array, 'Timon2026segu...')`, y una de seis **entera**.
     * Por ahí pasan los tres secretos que tiene el sistema —la contraseña, el
     * token de la API y el identificador del teléfono, que es el segundo factor
     * y no se enseña en ninguna pantalla—, y el registro se guarda para siempre.
     *
     * Con `depurar` en `false` no se escribía traza y en producción no había
     * fuga; pero lo primero que alguien hace cuando algo falla en producción es
     * encender `depurar`, y entonces la tendría sin saberlo.
     *
     * No depende de `zend.exception_ignore_args`, que viene apagado en unas
     * instalaciones y encendido en otras: aquí los argumentos no se escriben
     * nunca. Lo que sirve para depurar —el archivo, la línea y a quién se
     * llamó— se conserva entero.
     */
    private function traza(Throwable $e): string
    {
        $marcos = $e->getTrace();
        $lineas = [];

        foreach ($marcos as $i => $marco) {
            $donde = isset($marco['file'])
                ? $marco['file'] . '(' . ($marco['line'] ?? 0) . ')'
                : '[interno]';

            $lineas[] = sprintf(
                '#%d %s: %s%s%s()',
                $i,
                $donde,
                (string) ($marco['class'] ?? ''),
                (string) ($marco['type'] ?? ''),
                (string) ($marco['function'] ?? '')
            );
        }

        $lineas[] = '#' . count($marcos) . ' {main}';

        return implode("\n", $lineas);
    }

    private function escribe(string $linea): void
    {
        $archivo = $this->carpeta . '/' . date('Y-m-d') . '.log';

        // El primer error del día es el único momento en que hay que barrer, y
        // sale gratis: si el archivo de hoy todavía no existe, el día cambió.
        $primeroDelDia = !is_file($archivo);

        // ⚠️ Escribir el registro no puede tumbar la respuesta. Si el disco
        // rechaza la escritura —lleno, sin permiso, o el archivo desalojado por
        // iCloud en la máquina de desarrollo (errno 11)—, el manejador de
        // errores convertía el aviso en otra excepción *mientras atendía la
        // primera* y la persona recibía una página en blanco. Se cae a
        // `error_log()`, que va al registro del propio PHP.
        if (@file_put_contents($archivo, $linea . "\n", FILE_APPEND | LOCK_EX) === false) {
            error_log($linea);

            return;
        }
        @chmod($archivo, 0640);

        if ($primeroDelDia) {
            $this->tiraLosViejos();
        }
    }

    /**
     * Se tiran los registros de hace más de `DIAS_QUE_SE_GUARDAN`.
     *
     * El respaldo conserva catorce copias por una razón que aquí valía igual y
     * no estaba aplicada: **conservar todo llena el disco del hospedaje, y
     * entonces el respaldo del día que hacía falta es el que no se pudo
     * escribir.** El registro no se barría nunca. Dos días de pruebas dejaron
     * 400 KB; un defecto ruidoso sin atender deja mucho más.
     *
     * Barre por el nombre, que este archivo escribe y nadie más, y **nunca
     * levanta una excepción**: esto corre a la vuelta de registrar una falla, y
     * perder esa falla por no haber podido borrar un archivo viejo sería peor
     * que el archivo viejo.
     */
    private function tiraLosViejos(): void
    {
        $limite = date('Y-m-d', strtotime('-' . self::DIAS_QUE_SE_GUARDAN . ' days'));

        foreach (glob($this->carpeta . '/*.log') ?: [] as $archivo) {
            $nombre = basename($archivo, '.log');

            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $nombre) !== 1) {
                continue;
            }

            if ($nombre < $limite) {
                @unlink($archivo);
            }
        }
    }
}
