<?php
declare(strict_types=1);

namespace Nucleo;

/**
 * La sesión del navegador.
 *
 * Cookie sólo por HTTP (nada de JavaScript leyéndola), con `SameSite=Lax` y,
 * en produccion, sólo por HTTPS. El identificador se renueva al entrar: si
 * alguien plantó un identificador antes del acceso, el que queda es otro. Y no
 * se adopta un identificador que este servidor no emitió.
 *
 * Lo que aquí **no** vive es cuánto puede estar quieta: eso lo decide el negocio
 * y lo aplica `Nucleo\Middleware\ExigeSesion`, con su parámetro.
 *
 * Lo que sí vive aquí es que el archivo de la sesión dure lo suficiente para
 * que ese parámetro se cumpla. ⚠️ PHP trae `session.gc_maxlifetime` en 1440
 * **segundos**, y su barrido borra cualquier sesión quieta más de 24 minutos:
 * medido, el tope de 120 minutos no se cumplía. Con `$carpeta` las sesiones
 * van a una carpeta propia, fuera de `publico/`, que el barrido de otros sitios
 * del mismo hospedaje no toca, y el archivo dura `DIAS_EN_DISCO`. Un tope del
 * negocio más largo que eso no tiene efecto.
 */
final class Sesion
{
    public const DIAS_EN_DISCO = 7;

    private bool $iniciada = false;

    public function __construct(private bool $soloHttps, private ?string $carpeta = null)
    {
    }

    public function inicia(): void
    {
        if ($this->iniciada || session_status() === PHP_SESSION_ACTIVE) {
            $this->iniciada = true;
            return;
        }

        // En la línea de comandos no hay navegador ni cookie que valga:
        // `$_SESSION` se comporta como un arreglo cualquiera y ya. Sin esto,
        // los guiones y las pruebas avisan de cabeceras ya enviadas por algo
        // que no les incumbe.
        if (PHP_SAPI === 'cli') {
            $_SESSION ??= [];
            $this->iniciada = true;
            return;
        }

        // ⚠️ `session.use_strict_mode` viene apagado en este PHP, y medido contra
        // el sistema corriendo: mandando `sesion=` con un identificador que el
        // servidor nunca emitió, el servidor **no devuelve Set-Cookie**, o sea
        // que lo adopta. Se pone aquí y no en el `php.ini` porque el `php.ini`
        // del hospedaje es de otro: lo que no está en el código no se despliega.
        ini_set('session.use_strict_mode', '1');

        if ($this->carpeta !== null) {
            if (!is_dir($this->carpeta) && !@mkdir($this->carpeta, 0700, true) && !is_dir($this->carpeta)) {
                throw new \RuntimeException('No se pudo crear la carpeta de sesiones: ' . $this->carpeta);
            }
            ini_set('session.save_path', $this->carpeta);
            ini_set('session.gc_maxlifetime', (string) (self::DIAS_EN_DISCO * 86400));
        }

        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'httponly' => true,
            'secure'   => $this->soloHttps,
            'samesite' => 'Lax',
        ]);
        session_name('sesion');
        session_start();

        $this->iniciada = true;
    }

    public function pon(string $llave, mixed $valor): void
    {
        $this->inicia();
        $_SESSION[$llave] = $valor;
    }

    public function saca(string $llave, mixed $porOmision = null): mixed
    {
        $this->inicia();

        return $_SESSION[$llave] ?? $porOmision;
    }

    public function quita(string $llave): void
    {
        $this->inicia();
        unset($_SESSION[$llave]);
    }

    public function tiene(string $llave): bool
    {
        $this->inicia();

        return isset($_SESSION[$llave]);
    }

    /** Se llama al entrar: el identificador de antes deja de valer. */
    public function renueva(): void
    {
        $this->inicia();

        if (PHP_SAPI !== 'cli') {
            session_regenerate_id(true);
        }
    }

    /**
     * Vacía la sesión y le da un identificador nuevo, sin cerrarla.
     *
     * Es lo que hace falta cuando el sistema la cierra por su cuenta y tiene
     * algo que explicar: `cierra()` destruye el almacén y el aviso se guardaría
     * donde nadie va a leerlo —medido: el usuario llegaba a la pantalla de
     * entrada sin una palabra, creyendo que el sistema se cayó—. Aquí el
     * identificador viejo se destruye igual, así que con él no se revive.
     */
    public function vacia(): void
    {
        $this->inicia();
        $_SESSION = [];

        if (PHP_SAPI !== 'cli') {
            session_regenerate_id(true);
        }
    }

    public function cierra(): void
    {
        $this->inicia();
        $_SESSION = [];

        if (PHP_SAPI === 'cli') {
            $this->iniciada = false;
            return;
        }

        if (ini_get('session.use_cookies')) {
            $parametros = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires'  => time() - 42000,
                'path'     => $parametros['path'],
                'httponly' => true,
                'secure'   => $this->soloHttps,
                'samesite' => 'Lax',
            ]);
        }

        session_destroy();
        $this->iniciada = false;
    }

    /** Un mensaje que sobrevive a una redirección y se consume al leerse. */
    public function avisa(string $texto, string $tono = 'bien'): void
    {
        $this->pon('aviso', ['texto' => $texto, 'tono' => $tono]);
    }

    /** @return array{texto:string,tono:string}|null */
    public function aviso(): ?array
    {
        /** @var array{texto:string,tono:string}|null $aviso */
        $aviso = $this->saca('aviso');
        $this->quita('aviso');

        return $aviso;
    }
}
