<?php
declare(strict_types=1);

namespace Nucleo;

use Nucleo\Errores\Errores;

/**
 * La marca contra peticiones forjadas desde otro sitio.
 *
 * Una sola marca por sesión, no una por formulario: con varias pestañas
 * abiertas —que es como se trabaja en mostrador— una marca por formulario
 * invalida la pestaña de al lado y el usuario pierde lo capturado.
 *
 * La comparación es en tiempo constante. Comparar con `===` filtra, por el
 * tiempo que tarda, cuántos caracteres acertó quien prueba.
 */
final class Csrf
{
    private const LLAVE = 'csrf';

    public function __construct(private Sesion $sesion)
    {
    }

    public function marca(): string
    {
        $marca = $this->sesion->saca(self::LLAVE);

        if (!is_string($marca) || $marca === '') {
            $marca = bin2hex(random_bytes(32));
            $this->sesion->pon(self::LLAVE, $marca);
        }

        return $marca;
    }

    public function valida(?string $recibida): void
    {
        $guardada = $this->sesion->saca(self::LLAVE);

        if (!is_string($guardada) || $guardada === '' || $recibida === null || $recibida === '') {
            throw Errores::marcaInvalida();
        }

        if (!hash_equals($guardada, $recibida)) {
            throw Errores::marcaInvalida();
        }
    }

    /** El campo oculto, listo para pegarlo en un formulario. */
    public function campo(): string
    {
        return '<input type="hidden" name="_marca" value="'
            . htmlspecialchars($this->marca(), ENT_QUOTES, 'UTF-8') . '">';
    }
}
