<?php
declare(strict_types=1);

namespace Nucleo;

/**
 * Carga de clases por espacio de nombres, sin Composer.
 *
 * Hostinger compartido no siempre deja correr Composer con comodidad, y el
 * proyecto no tiene dependencias externas: no hace falta. La correspondencia
 * es directa: Nucleo\Middleware\Cadena → nucleo/Middleware/Cadena.php
 */
final class Autocargador
{
    /** @param array<string,string> $mapa Prefijo de espacio de nombres → carpeta */
    public function __construct(private array $mapa)
    {
    }

    public static function registrar(string $raiz): void
    {
        $cargador = new self([
            'Nucleo\\'        => $raiz . '/nucleo',
            'Controladores\\' => $raiz . '/controladores',
            'Modelos\\'       => $raiz . '/modelos',
            'Servicios\\'     => $raiz . '/servicios',
            'Dominio\\'       => $raiz . '/dominio',
        ]);

        spl_autoload_register([$cargador, 'carga']);
    }

    public function carga(string $clase): void
    {
        foreach ($this->mapa as $prefijo => $carpeta) {
            if (!str_starts_with($clase, $prefijo)) {
                continue;
            }

            $relativa = substr($clase, strlen($prefijo));
            $archivo  = $carpeta . '/' . str_replace('\\', '/', $relativa) . '.php';

            if (is_file($archivo)) {
                require_once $archivo;
            }

            return;
        }
    }
}
