<?php
declare(strict_types=1);

namespace Nucleo\Exporta;

/**
 * «Exportar XLS»: un XLSX de verdad, sin dependencias (homologación D18 y D20).
 *
 * Un XLSX es un zip con media docena de XML. Se escribe aquí, como el PDF de
 * `Pdf`, por la regla del proyecto de no cargar librerías y porque así no
 * depende de que el hospedaje tenga `ext-zip`: el zip también se arma a mano
 * (`Zip`), y solo pide `zlib`, que PHP trae siempre.
 *
 * Lo que compra frente al CSV, y por lo que la guía lo pide (§7):
 *
 *  - **Los números son números.** Un importe se suma en Excel sin «convertir a
 *    número»; lleva dos decimales y separador de miles.
 *  - **Las fechas son fechas**, en `dd/mm/aaaa` o `dd/mm/aaaa hh:mm`.
 *  - **Una clave con ceros a la izquierda sigue siendo texto**: «00123» no pasa
 *    a 123.
 *  - **Los acentos se ven** sin depender de cómo adivine Excel la codificación.
 *  - ⚠️ **Ningún texto se evalúa como fórmula.** Toda celda de texto va como
 *    `inlineStr`, que Excel nunca calcula: un cliente llamado «=1+1» sale como
 *    «=1+1». En el CSV hubo que ponerle un apóstrofo delante.
 *
 * El encabezado lleva el estilo estándar (negritas y fondo), queda fijo al
 * desplazarse y con autofiltro. Una hoja, una fila por registro.
 */
final class Xlsx
{
    public const TEXTO     = 'texto';
    public const CLAVE     = 'clave';     // texto que no se toca: folios, claves con ceros
    public const ENTERO    = 'entero';
    public const DECIMAL   = 'decimal';   // cantidades con decimales
    public const IMPORTE   = 'importe';   // dinero: 2 decimales
    public const FECHA     = 'fecha';     // `Y-m-d`
    public const FECHAHORA = 'fechahora'; // `Y-m-d H:i[:s]`

    /** Índice de estilo de cada tipo en `styles.xml`. */
    private const ESTILO = [
        'encabezado'    => 1,
        self::TEXTO     => 0,
        self::CLAVE     => 2,
        self::ENTERO    => 3,
        self::DECIMAL   => 4,
        self::IMPORTE   => 5,
        self::FECHA     => 6,
        self::FECHAHORA => 7,
    ];

    /**
     * @param list<array{titulo:string,tipo?:string}> $columnas
     * @param iterable<list<mixed>>                   $filas los valores crudos, en el orden de las columnas
     * @param list<mixed>                             $pie   un renglón de totales, solo si la pantalla lo muestra
     */
    public static function de(string $hoja, array $columnas, iterable $filas, array $pie = []): string
    {
        $tipos  = array_map(static fn (array $c): string => $c['tipo'] ?? self::TEXTO, $columnas);
        $anchos = array_map(static fn (array $c): int => max(8, mb_strlen($c['titulo']) + 2), $columnas);
        $xmlFilas = [];

        $celdas = '';
        foreach ($columnas as $i => $columna) {
            $celdas .= self::celdaTexto(self::ref($i, 1), $columna['titulo'], self::ESTILO['encabezado']);
        }
        $xmlFilas[] = '<row r="1">' . $celdas . '</row>';

        $numero = 1;
        foreach ($filas as $fila) {
            $numero++;
            $xmlFilas[] = self::renglon($numero, array_values($fila), $tipos, $anchos);
        }

        if ($pie !== []) {
            $numero++;
            $xmlFilas[] = self::renglon($numero, array_values($pie), $tipos, $anchos);
        }

        $ultima = self::ref(max(0, count($columnas) - 1), max(1, $numero));
        $cols = '';
        foreach ($anchos as $i => $ancho) {
            $cols .= '<col min="' . ($i + 1) . '" max="' . ($i + 1) . '" width="' . min(60, $ancho) . '" customWidth="1"/>';
        }

        $hojaXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<dimension ref="A1:' . $ultima . '"/>'
            . '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
            . '<sheetFormatPr defaultRowHeight="15"/>'
            . ($cols !== '' ? '<cols>' . $cols . '</cols>' : '')
            . '<sheetData>' . implode('', $xmlFilas) . '</sheetData>'
            . ($columnas !== [] ? '<autoFilter ref="A1:' . self::ref(count($columnas) - 1, max(1, $numero)) . '"/>' : '')
            . '</worksheet>';

        $zip = new Zip();
        $zip->agrega('[Content_Types].xml', self::tipos());
        $zip->agrega('_rels/.rels', self::relaciones());
        $zip->agrega('docProps/app.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>El Timón</Application></Properties>');
        $zip->agrega('xl/workbook.xml', self::libro($hoja));
        $zip->agrega('xl/_rels/workbook.xml.rels', self::relacionesLibro());
        $zip->agrega('xl/styles.xml', self::estilos());
        $zip->agrega('xl/worksheets/sheet1.xml', $hojaXml);

        return $zip->contenido();
    }

    /**
     * El nombre del archivo: la pantalla y la fecha o el periodo (guía §7.7),
     * por ejemplo `kardex_2026-11-01_2026-11-30.xlsx`.
     */
    public static function archivo(string $pantalla, string ...$fechas): string
    {
        // Sin `iconv`: su transliteración cambia según el sistema (en macOS «á» sale «'a»).
        $limpio = strtr(mb_strtolower($pantalla), ['á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n']);
        $limpio = trim((string) preg_replace('/[^a-z0-9]+/', '_', $limpio), '_') ?: 'exportacion';
        $fechas = array_values(array_filter($fechas, static fn (string $f): bool => preg_match('/^\d{4}-\d{2}-\d{2}$/', $f) === 1));

        return $limpio . '_' . ($fechas === [] ? date('Y-m-d') : implode('_', $fechas)) . '.xlsx';
    }

    /**
     * @param list<mixed>  $valores
     * @param list<string> $tipos
     * @param list<int>    $anchos
     */
    private static function renglon(int $numero, array $valores, array $tipos, array &$anchos): string
    {
        $celdas = '';
        foreach ($tipos as $i => $tipo) {
            $valor = $valores[$i] ?? null;
            $ref   = self::ref($i, $numero);

            if ($valor === null || $valor === '') {
                continue;
            }

            $texto = is_scalar($valor) ? (string) $valor : '';
            $anchos[$i] = max($anchos[$i], min(60, mb_strlen($texto) + 2));

            $celdas .= match ($tipo) {
                self::ENTERO, self::DECIMAL, self::IMPORTE => is_numeric($valor)
                    ? '<c r="' . $ref . '" s="' . self::ESTILO[$tipo] . '"><v>' . self::numero($valor) . '</v></c>'
                    : self::celdaTexto($ref, $texto, 0),
                self::FECHA, self::FECHAHORA => ($serial = self::serial($texto)) !== null
                    ? '<c r="' . $ref . '" s="' . self::ESTILO[$tipo] . '"><v>' . $serial . '</v></c>'
                    : self::celdaTexto($ref, $texto, 0),
                self::CLAVE => self::celdaTexto($ref, $texto, self::ESTILO[self::CLAVE]),
                default     => self::celdaTexto($ref, $texto, 0),
            };
        }

        return '<row r="' . $numero . '">' . $celdas . '</row>';
    }

    private static function celdaTexto(string $ref, string $texto, int $estilo): string
    {
        // Lo que XML no admite (controles de C0) se quita; lo demás se escapa.
        $limpio = (string) preg_replace('/[^\x{9}\x{A}\x{D}\x{20}-\x{D7FF}\x{E000}-\x{FFFD}]/u', '', $texto);

        return '<c r="' . $ref . '" t="inlineStr"' . ($estilo > 0 ? ' s="' . $estilo . '"' : '') . '>'
            . '<is><t xml:space="preserve">' . htmlspecialchars($limpio, ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</t></is></c>';
    }

    private static function numero(mixed $valor): string
    {
        $n = (float) $valor;

        return is_int($valor) || (is_string($valor) && preg_match('/^-?\d+$/', $valor) === 1)
            ? (string) (int) $valor
            : rtrim(rtrim(sprintf('%.6F', $n), '0'), '.');
    }

    /** Días desde el 30/12/1899, que es como Excel guarda una fecha. Sin zona: es la fecha tal cual. */
    private static function serial(string $texto): ?string
    {
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?$/', $texto, $m) !== 1) {
            return null;
        }

        $dias = gregoriantojd((int) $m[2], (int) $m[3], (int) $m[1]) - gregoriantojd(12, 30, 1899);
        $segundos = isset($m[4]) ? ((int) $m[4]) * 3600 + ((int) $m[5]) * 60 + (int) ($m[6] ?? 0) : 0;

        return $segundos === 0
            ? (string) $dias
            : rtrim(rtrim(sprintf('%.8F', $dias + $segundos / 86400), '0'), '.');
    }

    private static function ref(int $columna, int $fila): string
    {
        $letras = '';
        $n = $columna + 1;
        while ($n > 0) {
            $resto  = ($n - 1) % 26;
            $letras = chr(65 + $resto) . $letras;
            $n      = intdiv($n - 1, 26);
        }

        return $letras . $fila;
    }

    private static function tipos(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            . '</Types>';
    }

    private static function relaciones(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
            . '</Relationships>';
    }

    private static function libro(string $hoja): string
    {
        // Excel no admite en el nombre de una hoja : \ / ? * [ ] ni más de 31 caracteres.
        $nombre = mb_substr(trim((string) preg_replace('/[:\\\\\/?*\[\]]/', ' ', $hoja)) ?: 'Hoja1', 0, 31);

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="' . htmlspecialchars($nombre, ENT_XML1 | ENT_QUOTES, 'UTF-8') . '" sheetId="1" r:id="rId1"/></sheets>'
            . '</workbook>';
    }

    private static function relacionesLibro(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            . '</Relationships>';
    }

    /** 0 normal · 1 encabezado · 2 texto · 3 entero · 4 decimal · 5 importe · 6 fecha · 7 fecha y hora. */
    private static function estilos(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<numFmts count="4">'
            . '<numFmt numFmtId="164" formatCode="#,##0.00"/>'
            . '<numFmt numFmtId="165" formatCode="dd/mm/yyyy"/>'
            . '<numFmt numFmtId="166" formatCode="dd/mm/yyyy hh:mm"/>'
            . '<numFmt numFmtId="167" formatCode="#,##0.####"/>'
            . '</numFmts>'
            . '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts>'
            . '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FF1C1917"/><bgColor indexed="64"/></patternFill></fill></fills>'
            . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="8">'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            . '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>'
            . '<xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '<xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '<xf numFmtId="167" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '<xf numFmtId="166" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }
}
