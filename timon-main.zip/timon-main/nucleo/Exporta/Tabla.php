<?php
declare(strict_types=1);

namespace Nucleo\Exporta;

/**
 * Una tabla de reporte, sin saber cómo se va a ver.
 *
 * Existe para que **la pantalla, el Excel y el PDF salgan del mismo sitio**
 * (paso 16.5). La forma habitual de que un reporte exportado no cuadre con el
 * de pantalla es que sean dos consultas distintas escritas en dos momentos
 * distintos; aquí el controlador arma la tabla una vez y elige el formato al
 * final. Si los números difieren, difieren en los tres.
 *
 * Todo entra ya formateado, en texto: lo que decide cómo se ve un importe es
 * la pantalla, no el exportador.
 */
final class Tabla
{
    /**
     * @param list<string>       $encabezados
     * @param list<list<string>> $filas
     * @param list<string>       $pie      Renglón de totales, opcional.
     * @param list<string>       $notas    Lo que hay que leer para entender la tabla.
     */
    public function __construct(
        public readonly string $titulo,
        public readonly array $encabezados,
        public readonly array $filas,
        public readonly array $pie = [],
        public readonly string $subtitulo = '',
        public readonly array $notas = []
    ) {
    }

    /** Un nombre de archivo decente a partir del título. */
    public function archivo(string $extension): string
    {
        $limpio = iconv('UTF-8', 'ASCII//TRANSLIT', $this->titulo) ?: 'reporte';
        $limpio = strtolower((string) preg_replace('/[^A-Za-z0-9]+/', '-', $limpio));

        return trim($limpio, '-') . '-' . date('Y-m-d') . '.' . $extension;
    }

    /**
     * ¿Esta columna es de números? Se decide por el contenido, no por el nombre.
     *
     * Sirve para alinear a la derecha, que es lo que hace que una columna de
     * importes se pueda comparar de un vistazo.
     */
    public function esNumerica(int $columna): bool
    {
        $vistos = 0;

        foreach ($this->filas as $fila) {
            $celda = trim($fila[$columna] ?? '');

            if ($celda === '' || $celda === '—') {
                continue;
            }

            if (preg_match('/^-?\$?[\d,]+(\.\d+)?%?$/', $celda) !== 1) {
                return false;
            }

            $vistos++;
        }

        return $vistos > 0;
    }
}
