<?php
declare(strict_types=1);

namespace Nucleo\Exporta;

/**
 * Un zip mínimo, escrito a mano, para el XLSX (homologación D20).
 *
 * No usa `ZipArchive` a propósito: es `ext-zip`, que el hospedaje puede no
 * tener (reconocimiento H3) y que `guiones/verifica-host.php` no revisa. Esto
 * solo pide `zlib` (`gzdeflate`, `crc32`), que viene con PHP.
 *
 * Lo justo del formato (APPNOTE de PKWARE): por cada archivo, su encabezado
 * local y sus datos comprimidos con *deflate*; al final, el directorio central
 * y su cierre. Sin cifrado, sin zip64: un XLSX de un listado no llega a 4 GB.
 */
final class Zip
{
    /** @var list<array{nombre:string,crc:int,comprimido:int,original:int,desde:int}> */
    private array $entradas = [];

    private string $datos = '';

    public function agrega(string $nombre, string $contenido): void
    {
        $comprimido = gzdeflate($contenido, 6);
        if ($comprimido === false) {
            throw new \RuntimeException('No se pudo comprimir ' . $nombre);
        }

        [$hora, $fecha] = self::fechaDos();
        $crc   = crc32($contenido);
        $desde = strlen($this->datos);

        $this->datos .= pack('VvvvvvVVVvv', 0x04034b50, 20, 0x0800, 8, $hora, $fecha, $crc, strlen($comprimido), strlen($contenido), strlen($nombre), 0)
            . $nombre
            . $comprimido;

        $this->entradas[] = [
            'nombre'     => $nombre,
            'crc'        => $crc,
            'comprimido' => strlen($comprimido),
            'original'   => strlen($contenido),
            'desde'      => $desde,
        ];
    }

    public function contenido(): string
    {
        [$hora, $fecha] = self::fechaDos();
        $central = '';

        foreach ($this->entradas as $e) {
            $central .= pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0x0800, 8, $hora, $fecha, $e['crc'], $e['comprimido'], $e['original'], strlen($e['nombre']), 0, 0, 0, 0, 0, $e['desde'])
                . $e['nombre'];
        }

        return $this->datos
            . $central
            . pack('VvvvvVVv', 0x06054b50, 0, 0, count($this->entradas), count($this->entradas), strlen($central), strlen($this->datos), 0);
    }

    /** @return array{0:int,1:int} la hora y la fecha en el formato de MS-DOS */
    private static function fechaDos(): array
    {
        $t = getdate();

        return [
            ($t['hours'] << 11) | ($t['minutes'] << 5) | intdiv($t['seconds'], 2),
            (max(0, $t['year'] - 1980) << 9) | ($t['mon'] << 5) | $t['mday'],
        ];
    }
}
