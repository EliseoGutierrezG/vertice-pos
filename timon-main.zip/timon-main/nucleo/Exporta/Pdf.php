<?php
declare(strict_types=1);

namespace Nucleo\Exporta;

/**
 * La tabla, en un PDF que abre en cualquier lado.
 *
 * **Escrito a mano y a propósito.** Un PDF de una tabla es un archivo de texto
 * con una lista de objetos y una tabla de posiciones al final; no necesita una
 * biblioteca de 300 archivos con su propio ciclo de actualizaciones. Lo que sí
 * necesita es cuidado en tres cosas, que son las que hacen que un PDF casero
 * no abra:
 *
 *  - **Las posiciones del `xref` son bytes, no caracteres.** Se miden sobre el
 *    archivo ya armado.
 *  - **El texto va en Windows-1252**, que es lo que entiende `WinAnsiEncoding`.
 *    Un acento en UTF-8 metido tal cual sale como dos letras raras.
 *  - **`(`, `)` y `\` se escapan**, o el lector pierde el hilo a media cadena.
 *
 * Usa las tipografías **base de PDF** (Helvetica), que no se incrustan porque
 * todo lector las tiene. Por eso el archivo pesa kilobytes y no megas.
 *
 * D24 (2026-11-10): una banda con el primario de la marca arriba de cada
 * página, el nombre de la instalación a la derecha del título y en el pie, y
 * el encabezado de la tabla y los filetes con los neutros del panel. La letra
 * sigue siendo Helvetica: Sora y Plus Jakarta Sans pedirían incrustarlas.
 * La marca la da `Aplicacion` con `Pdf::marcaDesde()` y se consulta al armar
 * el primer PDF; sin eso es El Timón.
 */
final class Pdf
{
    /** A4 en puntos. Un punto es 1/72 de pulgada. */
    private const ANCHO_A4 = 595.28;
    private const ALTO_A4  = 841.89;
    private const MARGEN   = 36.0;

    private const ALTO_RENGLON = 14.0;
    private const TAM_TITULO   = 14.0;
    private const TAM_CUERPO   = 8.5;
    private const TAM_PIE      = 7.5;

    /**
     * Ancho de cada carácter en Helvetica, por mil. Es la tabla del propio
     * formato: sin ella no se puede alinear a la derecha ni saber si un texto
     * cabe en su columna.
     *
     * @var array<string,int>
     */
    private const ANCHOS = [
        ' ' => 278, '!' => 278, '"' => 355, '#' => 556, '$' => 556, '%' => 889, '&' => 667, "'" => 191,
        '(' => 333, ')' => 333, '*' => 389, '+' => 584, ',' => 278, '-' => 333, '.' => 278, '/' => 278,
        '0' => 556, '1' => 556, '2' => 556, '3' => 556, '4' => 556, '5' => 556, '6' => 556, '7' => 556,
        '8' => 556, '9' => 556, ':' => 278, ';' => 278, '<' => 584, '=' => 584, '>' => 584, '?' => 556,
        '@' => 1015,
        'A' => 667, 'B' => 667, 'C' => 722, 'D' => 722, 'E' => 667, 'F' => 611, 'G' => 778, 'H' => 722,
        'I' => 278, 'J' => 500, 'K' => 667, 'L' => 556, 'M' => 833, 'N' => 722, 'O' => 778, 'P' => 667,
        'Q' => 778, 'R' => 722, 'S' => 667, 'T' => 611, 'U' => 722, 'V' => 667, 'W' => 944, 'X' => 667,
        'Y' => 667, 'Z' => 611,
        '[' => 278, '\\' => 278, ']' => 278, '^' => 469, '_' => 556, '`' => 333,
        'a' => 556, 'b' => 556, 'c' => 500, 'd' => 556, 'e' => 556, 'f' => 278, 'g' => 556, 'h' => 556,
        'i' => 222, 'j' => 222, 'k' => 500, 'l' => 222, 'm' => 833, 'n' => 556, 'o' => 556, 'p' => 556,
        'q' => 556, 'r' => 333, 's' => 500, 't' => 278, 'u' => 556, 'v' => 500, 'w' => 722, 'x' => 500,
        'y' => 500, 'z' => 500, '{' => 334, '|' => 260, '}' => 334, '~' => 584,
    ];

    /** Neutros del panel, en RGB de 0 a 1: encabezado de tabla y filetes. */
    private const FONDO_ENCABEZADO = [0.980, 0.973, 0.953]; // #FAF8F3
    private const FILETE           = [0.890, 0.867, 0.816]; // #E3DDD0

    private static string $nombreMarca = 'El Timón';
    /** @var array{float,float,float} */
    private static array $primario = [0.090, 0.176, 0.302]; // marino #172D4D

    /**
     * La marca con que salen los PDF de esta instalación. El color llega ya
     * validado por `MarcaVisual`; aquí sólo se acepta `#RRGGBB` y lo demás se
     * ignora, porque va escrito dentro del archivo.
     */
    public static function marca(string $nombre, string $primario): void
    {
        $nombre = trim($nombre);
        if ($nombre !== '' && mb_strlen($nombre) <= 60) {
            self::$nombreMarca = $nombre;
        }
        if (preg_match('/^#([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})$/', $primario, $m) === 1) {
            self::$primario = [hexdec($m[1]) / 255, hexdec($m[2]) / 255, hexdec($m[3]) / 255];
        }
    }

    /** @var (\Closure(): array{string,string})|null */
    private static ?\Closure $resolutor = null;

    /**
     * De dónde sale la marca, para no consultarla en cada petición: se pide
     * la primera vez que se arma un PDF. Si falla, el PDF sale como El Timón.
     *
     * @param callable(): array{string,string} $resolutor nombre corto y primario
     */
    public static function marcaDesde(callable $resolutor): void
    {
        self::$resolutor = \Closure::fromCallable($resolutor);
    }

    /** @var list<string> Los objetos del archivo, en orden. */
    private array $objetos = [];

    private float $ancho;
    private float $alto;

    public function __construct(private bool $horizontal = false)
    {
        $this->ancho = $horizontal ? self::ALTO_A4 : self::ANCHO_A4;
        $this->alto  = $horizontal ? self::ANCHO_A4 : self::ALTO_A4;
    }

    /** La tabla completa, paginada, como bytes de un PDF. */
    public static function de(Tabla $tabla, bool $horizontal = false): string
    {
        return (new self($horizontal))->arma($tabla);
    }

    private function arma(Tabla $tabla): string
    {
        if (self::$resolutor !== null) {
            $resolutor = self::$resolutor;
            self::$resolutor = null;
            try {
                [$nombre, $primario] = $resolutor();
                self::marca((string) $nombre, (string) $primario);
            } catch (\Throwable) {
                // Sin marca legible el reporte sale igual, con la de El Timón.
            }
        }

        $anchos   = $this->anchosDeColumna($tabla);
        $derecha  = array_map(fn (int $i): bool => $tabla->esNumerica($i), array_keys($tabla->encabezados));
        $paginas  = $this->pagina($tabla, $anchos, $derecha);
        $cuantas  = count($paginas);
        $flujos   = [];

        foreach ($paginas as $numero => $contenido) {
            $flujos[] = $contenido . $this->pieDePagina($numero + 1, $cuantas);
        }

        return $this->archivo($flujos);
    }

    /**
     * Reparte el ancho útil entre las columnas.
     *
     * Cada una pide lo que mide su contenido más largo; si entre todas se pasan,
     * se encogen a proporción. Una columna nunca baja de 40 puntos: por debajo
     * de eso no cabe ni un número de tres cifras, y una columna ilegible no
     * ahorra nada.
     *
     * @return list<float>
     */
    private function anchosDeColumna(Tabla $tabla): array
    {
        $util   = $this->ancho - 2 * self::MARGEN;
        $piden  = [];

        foreach ($tabla->encabezados as $i => $encabezado) {
            $mayor = $this->mide($encabezado, self::TAM_CUERPO) * 1.08;

            foreach ($tabla->filas as $fila) {
                $mayor = max($mayor, $this->mide($fila[$i] ?? '', self::TAM_CUERPO));
            }

            if (isset($tabla->pie[$i])) {
                $mayor = max($mayor, $this->mide($tabla->pie[$i], self::TAM_CUERPO) * 1.08);
            }

            $piden[] = max(40.0, $mayor + 8.0);
        }

        $suma = array_sum($piden);

        if ($suma > $util) {
            $factor = $util / $suma;
            $piden  = array_map(static fn (float $a): float => max(28.0, $a * $factor), $piden);
        }

        return $piden;
    }

    /**
     * Pinta la tabla y la corta en páginas.
     *
     * @param list<float> $anchos
     * @param list<bool>  $derecha
     * @return list<string>
     */
    private function pagina(Tabla $tabla, array $anchos, array $derecha): array
    {
        $paginas = [];
        $flujo   = '';
        $y       = 0.0;
        $abajo   = self::MARGEN + 24.0;
        $primera = true;

        // El título y la fila de encabezados se repiten en cada página: una hoja
        // suelta de un reporte de ocho páginas tiene que decir de qué es y qué
        // significa cada columna. El subtítulo —el periodo y los filtros— va
        // sólo en la primera, que es la que nadie separa del resto.
        $encabeza = function () use (&$flujo, &$y, &$primera, $tabla, $anchos): void {
            $y = $this->alto - self::MARGEN;

            // La banda de la marca: 4 puntos de primario sobre el ancho útil.
            [$r, $g, $b] = self::$primario;
            $flujo .= sprintf(
                "%.3f %.3f %.3f rg %.2f %.2f %.2f %.2f re f\n0 g\n",
                $r, $g, $b,
                self::MARGEN - 2, $y + 6, $this->ancho - 2 * self::MARGEN + 4, 4.0
            );

            $flujo .= $this->texto($tabla->titulo, self::MARGEN, $y - self::TAM_TITULO, self::TAM_TITULO, true);
            $marca  = self::$nombreMarca;
            $flujo .= $this->texto(
                $marca,
                $this->ancho - self::MARGEN - $this->mide($marca, self::TAM_PIE),
                $y - self::TAM_TITULO,
                self::TAM_PIE,
                true,
                0.35
            );
            $y -= self::TAM_TITULO + 6;

            if ($primera && $tabla->subtitulo !== '') {
                $flujo .= $this->texto($tabla->subtitulo, self::MARGEN, $y - self::TAM_PIE, self::TAM_PIE, false, 0.35);
                $y -= self::TAM_PIE + 8;
            }

            $primera = false;

            $flujo .= $this->renglon($tabla->encabezados, $anchos, $y, true, array_fill(0, count($anchos), false));
            $y     -= self::ALTO_RENGLON;
        };

        $encabeza();

        foreach ($tabla->filas as $fila) {
            if ($y - self::ALTO_RENGLON < $abajo) {
                $paginas[] = $flujo;
                $flujo     = '';
                $encabeza();
            }

            $flujo .= $this->renglon($fila, $anchos, $y, false, $derecha);
            $y     -= self::ALTO_RENGLON;
        }

        if ($tabla->pie !== []) {
            if ($y - self::ALTO_RENGLON < $abajo) {
                $paginas[] = $flujo;
                $flujo     = '';
                $encabeza();
            }

            $flujo .= $this->renglon($tabla->pie, $anchos, $y, true, $derecha);
            $y     -= self::ALTO_RENGLON;
        }

        foreach ($tabla->notas as $nota) {
            if ($y - 12 < $abajo) {
                $paginas[] = $flujo;
                $flujo     = '';
                $encabeza();
            }

            $y     -= 10;
            $flujo .= $this->texto($nota, self::MARGEN, $y, self::TAM_PIE, false, 0.35);
            $y     -= 4;
        }

        $paginas[] = $flujo;

        return $paginas;
    }

    /**
     * Un renglón de la tabla, con su raya y su fondo si es de encabezado.
     *
     * @param list<string> $celdas
     * @param list<float>  $anchos
     * @param list<bool>   $derecha
     */
    private function renglon(array $celdas, array $anchos, float $y, bool $fuerte, array $derecha): string
    {
        $flujo = '';
        $base  = $y - self::ALTO_RENGLON + 4.0;

        if ($fuerte) {
            [$r, $g, $b] = self::FONDO_ENCABEZADO;
            $flujo .= sprintf(
                "%.3f %.3f %.3f rg %.2f %.2f %.2f %.2f re f\n0 g\n",
                $r, $g, $b,
                self::MARGEN - 2,
                $y - self::ALTO_RENGLON + 1,
                array_sum($anchos) + 4,
                self::ALTO_RENGLON
            );
        }

        $x = self::MARGEN;

        foreach ($anchos as $i => $ancho) {
            $celda = $this->recorta($celdas[$i] ?? '', $ancho - 8.0, self::TAM_CUERPO);
            $donde = ($derecha[$i] ?? false)
                ? $x + $ancho - 4.0 - $this->mide($celda, self::TAM_CUERPO)
                : $x + 2.0;

            $flujo .= $this->texto($celda, $donde, $base, self::TAM_CUERPO, $fuerte);
            $x     += $ancho;
        }

        [$r, $g, $b] = self::FILETE;
        $flujo .= sprintf(
            "%.3f %.3f %.3f RG 0.4 w %.2f %.2f m %.2f %.2f l S\n",
            $r, $g, $b,
            self::MARGEN - 2,
            $y - self::ALTO_RENGLON + 1,
            self::MARGEN - 2 + array_sum($anchos) + 4,
            $y - self::ALTO_RENGLON + 1
        );

        return $flujo;
    }

    private function pieDePagina(int $numero, int $de): string
    {
        $texto = sprintf('%s · %s · página %d de %d', self::$nombreMarca, date('Y-m-d H:i'), $numero, $de);

        return $this->texto($texto, self::MARGEN, self::MARGEN, self::TAM_PIE, false, 0.45);
    }

    private function texto(string $texto, float $x, float $y, float $tam, bool $fuerte = false, float $gris = 0.0): string
    {
        if (trim($texto) === '') {
            return '';
        }

        return sprintf(
            "BT %.3f g /%s %.2f Tf %.2f %.2f Td (%s) Tj ET\n0 g\n",
            $gris,
            $fuerte ? 'F2' : 'F1',
            $tam,
            $x,
            $y,
            $this->escapa($texto)
        );
    }

    /** Cuánto mide un texto, en puntos, a ese tamaño. */
    private function mide(string $texto, float $tam): float
    {
        $mil = 0;

        foreach (str_split($this->aWindows($texto)) as $letra) {
            $mil += self::ANCHOS[$letra] ?? 556;
        }

        return $mil * $tam / 1000;
    }

    /** Corta con puntos suspensivos lo que no cabe. Mejor cortado que encimado. */
    private function recorta(string $texto, float $cabe, float $tam): string
    {
        if ($this->mide($texto, $tam) <= $cabe) {
            return $texto;
        }

        $corte = $texto;

        while ($corte !== '' && $this->mide($corte . '...', $tam) > $cabe) {
            $corte = mb_substr($corte, 0, mb_strlen($corte) - 1);
        }

        return $corte . '...';
    }

    /** UTF-8 a Windows-1252, que es lo que dice el `/Encoding` de las tipografías. */
    private function aWindows(string $texto): string
    {
        $convertido = @mb_convert_encoding($texto, 'Windows-1252', 'UTF-8');

        return $convertido === false ? $texto : $convertido;
    }

    private function escapa(string $texto): string
    {
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $this->aWindows($texto));
    }

    /**
     * Arma el archivo: objetos, tabla de posiciones y cola.
     *
     * @param list<string> $flujos Un contenido por página.
     */
    private function archivo(array $flujos): string
    {
        $cuantas  = count($flujos);
        $primeraP = 5; // 1 catálogo, 2 páginas, 3 y 4 tipografías.
        $hijos    = [];

        for ($i = 0; $i < $cuantas; $i++) {
            $hijos[] = ($primeraP + $i * 2) . ' 0 R';
        }

        $this->objetos = [];
        $this->objeto('<< /Type /Catalog /Pages 2 0 R >>');
        $this->objeto('<< /Type /Pages /Kids [' . implode(' ', $hijos) . '] /Count ' . $cuantas . ' >>');
        $this->objeto('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
        $this->objeto('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');

        foreach ($flujos as $i => $flujo) {
            $this->objeto(sprintf(
                '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2f %.2f] '
                . '/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>',
                $this->ancho,
                $this->alto,
                $primeraP + $i * 2 + 1
            ));
            $this->objeto('<< /Length ' . strlen($flujo) . " >>\nstream\n" . $flujo . 'endstream');
        }

        $salida  = "%PDF-1.4\n";
        // Un comentario con bytes altos: le dice a quien mueva el archivo que es
        // binario y que no lo toque convirtiendo finales de línea.
        $salida .= "%\xE2\xE3\xCF\xD3\n";
        $posiciones = [];

        foreach ($this->objetos as $i => $cuerpo) {
            $posiciones[] = strlen($salida);
            $salida .= ($i + 1) . " 0 obj\n" . $cuerpo . "\nendobj\n";
        }

        $inicioXref = strlen($salida);
        $total      = count($this->objetos) + 1;

        $salida .= "xref\n0 " . $total . "\n";
        $salida .= "0000000000 65535 f \n";

        foreach ($posiciones as $posicion) {
            $salida .= sprintf("%010d 00000 n \n", $posicion);
        }

        $salida .= "trailer\n<< /Size " . $total . " /Root 1 0 R >>\n";
        $salida .= "startxref\n" . $inicioXref . "\n%%EOF\n";

        return $salida;
    }

    private function objeto(string $cuerpo): void
    {
        $this->objetos[] = $cuerpo;
    }
}
