<?php
declare(strict_types=1);

namespace Nucleo\Exporta;

/**
 * La tabla, en un archivo que Excel abre de doble clic.
 *
 * **Es CSV, y se dice que es CSV.** No es un `.xlsx`: un xlsx es un zip con
 * media docena de XML dentro, y para lo que aquí se necesita —una tabla que
 * alguien va a pegar en su propia hoja— no compra nada y sí trae una
 * dependencia que hay que mantener viva. Lo que sí se cuida es que abra
 * bien, que es lo que la gente quiere decir cuando dice "en Excel":
 *
 *  - **BOM al principio**. Sin él, Excel lee el archivo como si fuera Windows-1252
 *    y "Jalapeño" aparece como "JalapeÃ±o". Es *el* motivo por el que los
 *    exportadores caseros se ven mal.
 *  - **Fin de línea de Windows** (CRLF), que es lo que el formato pide.
 *  - Las comillas se duplican y cualquier celda con coma, comillas o salto de
 *    línea va entrecomillada.
 *  - ⚠️ **Una celda que empiece como una fórmula deja de parecerlo.** Excel
 *    evalúa lo que empieza con `=`, `+`, `@` o `-`: un cliente llamado
 *    «- sin ruta -» salía como `#NAME?`, uno llamado «=1+1» salía como `2`, y el
 *    nombre desaparecía del reporte. Medido con el exportador tal como estaba.
 *    Se les pone un apóstrofo delante, que Excel usa justo para eso y no enseña.
 */
final class Csv
{
    /** El BOM de UTF-8. Tres bytes que deciden si los acentos se ven. */
    private const BOM = "\xEF\xBB\xBF";

    public static function de(Tabla $tabla): string
    {
        $lineas = [];

        if ($tabla->titulo !== '') {
            $lineas[] = self::renglon([$tabla->titulo]);
        }

        if ($tabla->subtitulo !== '') {
            $lineas[] = self::renglon([$tabla->subtitulo]);
        }

        if ($tabla->titulo !== '' || $tabla->subtitulo !== '') {
            $lineas[] = '';
        }

        $lineas[] = self::renglon($tabla->encabezados);

        foreach ($tabla->filas as $fila) {
            $lineas[] = self::renglon($fila);
        }

        if ($tabla->pie !== []) {
            $lineas[] = self::renglon($tabla->pie);
        }

        foreach ($tabla->notas as $nota) {
            $lineas[] = '';
            $lineas[] = self::renglon([$nota]);
        }

        return self::BOM . implode("\r\n", $lineas) . "\r\n";
    }

    /**
     * El mismo formato, escrito por partes: para un detalle que no debe
     * juntarse entero en memoria. Junta unos 64 KB antes de emitir, para no
     * mandar un paquete por renglón.
     *
     * @param list<string> $encabezados
     * @param iterable<list<string>> $filas
     * @param callable(string):void $emite
     */
    public static function enFlujo(string $titulo, string $subtitulo, array $encabezados, iterable $filas, callable $emite): void
    {
        $parte = self::BOM;
        if ($titulo !== '') {
            $parte .= self::renglon([$titulo]) . "\r\n";
        }
        if ($subtitulo !== '') {
            $parte .= self::renglon([$subtitulo]) . "\r\n";
        }
        if ($titulo !== '' || $subtitulo !== '') {
            $parte .= "\r\n";
        }
        $parte .= self::renglon($encabezados) . "\r\n";

        foreach ($filas as $fila) {
            $parte .= self::renglon(array_map('strval', $fila)) . "\r\n";
            if (strlen($parte) >= 65536) {
                $emite($parte);
                $parte = '';
            }
        }

        if ($parte !== '') {
            $emite($parte);
        }
    }

    /** @param list<string> $celdas */
    private static function renglon(array $celdas): string
    {
        return implode(',', array_map(self::celda(...), $celdas));
    }

    private static function celda(string $valor): string
    {
        if (self::pareceFormula($valor)) {
            $valor = "'" . $valor;
        }

        // Los importes salen de la pantalla con separador de miles: "1,234.50".
        // Si eso viaja tal cual, Excel lo parte en dos columnas. Se entrecomilla
        // como cualquier otra celda con coma, y así llega entero.
        if (preg_match('/[",\r\n]/', $valor) === 1) {
            return '"' . str_replace('"', '""', $valor) . '"';
        }

        return $valor;
    }

    /**
     * Si Excel va a tratar esta celda como una fórmula en lugar de como texto.
     *
     * El caso delicado es el **menos**, porque un importe negativo empieza con
     * menos y tiene que seguir siendo un número que sume: el reporte de
     * movimientos escribe `-12.000` y el de ventas `-1,234.50`. Por eso el menos
     * sólo se neutraliza cuando lo que sigue **no** es un número; los demás
     * signos no tienen ese problema, porque ningún reporte escribe un `+`
     * delante de un número.
     */
    private static function pareceFormula(string $valor): bool
    {
        if ($valor === '') {
            return false;
        }

        if (str_starts_with($valor, '-')) {
            return preg_match('/^-[\d,]+(\.\d+)?%?$/', $valor) !== 1;
        }

        return in_array($valor[0], ['=', '+', '@', "\t", "\r"], true);
    }
}
