<?php
declare(strict_types=1);

namespace Nucleo\Errores;

use RuntimeException;

/**
 * Error que SÍ tiene que llegar al cliente, con su código honesto.
 *
 * La regla del proyecto: un error del usuario nunca es un 500. Si el código
 * de estado que se va a devolver está en esta jerarquía, es porque se decidió
 * a propósito. Todo lo demás —lo que nadie previó— sí es un 500, y ése se
 * registra con su traza pero se responde sin detalle.
 */
class ErrorHttp extends RuntimeException
{
    /** @var array<string,string> */
    private array $campos;
    private string $clave;
    /** @var array<string,string> */
    private array $cabeceras;
    /** Lo que sirve al administrador en el registro y no se le enseña a la persona. */
    private ?string $detalle = null;
    private ?array $estadoActual = null;

    /**
     * @param array<string,string> $campos Errores por campo, para el 422.
     */
    public function __construct(
        int $estado,
        string $mensaje,
        string $clave = 'error',
        array $campos = [],
        array $cabeceras = []
    ) {
        parent::__construct($mensaje, $estado);
        $this->clave  = $clave;
        $this->campos = $campos;
        $this->cabeceras = $cabeceras;
    }

    public function estado(): int
    {
        return $this->getCode();
    }

    public function clave(): string
    {
        return $this->clave;
    }

    /** @return array<string,string> */
    public function campos(): array
    {
        return $this->campos;
    }

    /** @return array<string,string> */
    public function cabeceras(): array
    {
        return $this->cabeceras;
    }

    public function conDetalle(?string $detalle): static
    {
        $this->detalle = $detalle;
        return $this;
    }

    public function detalle(): ?string
    {
        return $this->detalle;
    }

    public function conEstadoActual(array $estado): static
    {
        $this->estadoActual = $estado;
        return $this;
    }

    public function estadoActual(): ?array
    {
        return $this->estadoActual;
    }
}
