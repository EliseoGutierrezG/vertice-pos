<?php
declare(strict_types=1);

namespace Nucleo\Errores;

/**
 * Los errores con nombre. Se usan así:
 *
 *     throw Errores::noEncontrado('El pedido no existe');
 *
 * Tener un solo lugar donde se deciden los códigos evita que cada controlador
 * invente el suyo. En el sistema de referencia un error del usuario podía salir como página en
 * blanco, como aviso o como 500, según quién escribiera el archivo.
 */
final class Errores
{
    /** 400 · La petición está mal formada (JSON ilegible, por ejemplo). */
    public static function peticionInvalida(string $mensaje = 'Datos ilegibles. Intente de nuevo'): ErrorHttp
    {
        return new ErrorHttp(400, $mensaje, 'peticion_invalida');
    }

    /** 401 · No hay identidad: no inició sesión o el token no sirve. */
    public static function noAutenticado(string $mensaje = 'Entre al sistema'): ErrorHttp
    {
        return new ErrorHttp(401, $mensaje, 'no_autenticado');
    }

    /** 403 · Hay identidad, pero no tiene el permiso. */
    public static function prohibido(string $mensaje = 'No tiene permiso para esta acción', ?string $permisoFaltante = null): ErrorHttp
    {
        return (new ErrorHttp(403, $mensaje, 'prohibido'))->conDetalle($permisoFaltante);
    }

    /** 404 · La ruta o el recurso no existe. */
    public static function noEncontrado(string $mensaje = 'No se encontró lo solicitado'): ErrorHttp
    {
        return new ErrorHttp(404, $mensaje, 'no_encontrado');
    }

    /** 405 · La ruta existe, pero no con ese verbo. */
    public static function metodoNoPermitido(string $mensaje = 'Acción no disponible'): ErrorHttp
    {
        return new ErrorHttp(405, $mensaje, 'metodo_no_permitido');
    }

    /** 409 · Choque con el estado actual: ya existe, ya se cerró, ya se surtió. */
    public static function conflicto(string $mensaje = 'Ya cambió. Recargue la pantalla'): ErrorHttp
    {
        return new ErrorHttp(409, $mensaje, 'conflicto');
    }

    /**
     * 409 · Otra operación tenía ocupado lo mismo. No es un «no»: volver a
     * intentar basta, y la app lo reintenta sola en vez de atorar la cola.
     */
    public static function ocupado(string $mensaje = 'Otra operación está en curso. Intente de nuevo.'): ErrorHttp
    {
        return new ErrorHttp(409, $mensaje, 'ocupado');
    }

    /** 419 · Falta la marca CSRF o ya venció la sesión. */
    public static function marcaInvalida(string $mensaje = 'Sesión vencida. Recargue la pantalla'): ErrorHttp
    {
        return new ErrorHttp(419, $mensaje, 'marca_invalida');
    }

    /**
     * 422 · Se entendió la petición, pero los datos no pasan las reglas.
     *
     * @param array<string,string> $campos
     */
    public static function datosInvalidos(array $campos, string $mensaje = 'Hay datos que corregir'): ErrorHttp
    {
        return new ErrorHttp(422, $mensaje, 'datos_invalidos', $campos);
    }

    /** 429 · El límite persistente de acceso sigue bloqueado. */
    public static function demasiadosIntentos(int $reintentarEn): ErrorHttp
    {
        $segundos = max(1, $reintentarEn);
        return new ErrorHttp(
            429,
            'Demasiados intentos. Espere un momento',
            'demasiados_intentos',
            [],
            ['Retry-After' => (string) $segundos]
        );
    }
}
