<?php
declare(strict_types=1);

namespace Nucleo;

use Closure;

/**
 * La respuesta, con un sobre siempre igual.
 *
 * Éxito:
 *   { "ok": true,  "datos": ... }
 * Error:
 *   { "ok": false, "error": { "clave": "...", "mensaje": "...", "campos": {...} } }
 *
 * Que el sobre no cambie es lo que permite que la app tenga UN solo lugar
 * donde interpreta respuestas. En el sistema de referencia cada pantalla devolvía lo suyo:
 * a veces JSON, a veces HTML, a veces la palabra "ok" suelta.
 */
final class Respuesta
{
    /**
     * Lo que el navegador puede cargar en cualquier pantalla de este sistema.
     *
     * - **Sin scripts incrustados:** un XSS que logre colar una etiqueta no corre.
     *   Por eso los scripts de las vistas viven en archivos.
     * - `style-src` conserva `'unsafe-inline'`: 9 vistas y las librerías usan el
     *   atributo `style`. Es una excepción conocida y de menor riesgo.
     * - `img-src` nombra los mosaicos del mapa; `connect-src` no, porque las
     *   direcciones se geocodifican desde el servidor.
     */
    public const POLITICA_CONTENIDO = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
        . "img-src 'self' data: blob: https://tile.openstreetmap.org; font-src 'self' data:; connect-src 'self'; "
        . "object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'";

    /** La web no usa cámara, micrófono ni ubicación: los usa la app, que no pasa por aquí. */
    public const POLITICA_PERMISOS = 'camera=(), microphone=(), geolocation=(), payment=(), usb=()';

    /**
     * Lo que contesta la API no se guarda en ninguna caché: trae sesiones,
     * clientes y precios. En iOS la copia del sistema quedaba en disco sin
     * cifrar y, ante un 304 del catálogo, se entregaba como si fuera la
     * respuesta nueva (bitácora 107).
     */
    private const CABECERAS_JSON = [
        'Content-Type'  => 'application/json; charset=utf-8',
        'Cache-Control' => 'no-store',
    ];

    private ?Closure $flujo = null;

    /** @param array<string,string> $cabeceras */
    private function __construct(
        private int $estado,
        private string $cuerpo,
        private array $cabeceras = []
    ) {
    }

    public static function json(mixed $datos = null, int $estado = 200): self
    {
        return new self(
            $estado,
            self::codificar(['ok' => true, 'datos' => $datos]),
            self::CABECERAS_JSON
        );
    }

    /** @param array<string,string> $campos */
    public static function jsonError(
        int $estado,
        string $clave,
        string $mensaje,
        array $campos = [],
        ?array $estadoActual = null
    ): self {
        $error = ['clave' => $clave, 'mensaje' => $mensaje];
        if ($campos !== []) {
            $error['campos'] = $campos;
        }
        if ($estadoActual !== null) {
            $error['estado_actual'] = $estadoActual;
        }

        return new self(
            $estado,
            self::codificar(['ok' => false, 'error' => $error]),
            self::CABECERAS_JSON
        );
    }

    public static function html(string $html, int $estado = 200): self
    {
        return new self($estado, $html, ['Content-Type' => 'text/html; charset=utf-8']);
    }

    public static function texto(string $texto, int $estado = 200): self
    {
        return new self($estado, $texto, ['Content-Type' => 'text/plain; charset=utf-8']);
    }

    /**
     * Bytes tal cual —una foto—, con su tipo y cuánto se puede guardar en
     * caché. Nada se adivina: el tipo lo dice quien responde.
     */
    public static function archivo(string $contenido, string $tipo, int $cacheSegundos = 0): self
    {
        return new self(200, $contenido, [
            'Content-Type'   => $tipo,
            'Content-Length' => (string) strlen($contenido),
            'Cache-Control'  => $cacheSegundos > 0
                ? 'public, max-age=' . $cacheSegundos . ', immutable'
                : 'no-store',
        ]);
    }

    /**
     * Un archivo que se escribe por partes mientras se lee de la base.
     *
     * Para lo que no cabe —o no debe caber— en memoria, como el CSV del
     * detalle de ventas de un año. `$escribe` recibe una función que emite
     * cada parte; el `echo` sigue estando sólo aquí, en `enviar()`. Sin
     * `Content-Length`, porque no se sabe hasta el final.
     *
     * @param callable(callable(string):void):void $escribe
     */
    public static function flujo(callable $escribe, string $tipo): self
    {
        $respuesta = new self(200, '', [
            'Content-Type'      => $tipo,
            'Cache-Control'     => 'no-store',
            'X-Accel-Buffering' => 'no',
        ]);
        $respuesta->flujo = Closure::fromCallable($escribe);
        return $respuesta;
    }

    /**
     * Un archivo grande del disco, por bloques y reanudable: con `Range:
     * bytes=N-` responde 206 desde el byte N. Lo usa la computadora de
     * sucursal para bajar su paquete con internet que se corta.
     */
    public static function archivoEnDisco(string $ruta, string $tipo, ?string $rango = null): self
    {
        $peso = (int) filesize($ruta);
        $desde = 0;
        $parcial = false;
        if ($rango !== null && preg_match('/^bytes=(\d+)-$/D', trim($rango), $m) === 1) {
            $parcial = true;
            $desde = (int) $m[1];
            if ($desde >= $peso) {
                return new self(416, '', ['Content-Range' => 'bytes */' . $peso, 'Cache-Control' => 'no-store']);
            }
        }
        $cabeceras = [
            'Content-Type'   => $tipo,
            'Content-Length' => (string) ($peso - $desde),
            'Accept-Ranges'  => 'bytes',
            'Cache-Control'  => 'no-store',
        ];
        if ($parcial) {
            $cabeceras['Content-Range'] = 'bytes ' . $desde . '-' . ($peso - 1) . '/' . $peso;
        }
        $respuesta = new self($parcial ? 206 : 200, '', $cabeceras);
        $respuesta->flujo = static function (callable $emite) use ($ruta, $desde): void {
            $archivo = fopen($ruta, 'rb');
            if ($archivo === false) {
                return;
            }
            fseek($archivo, $desde);
            while (!feof($archivo)) {
                $parte = fread($archivo, 262144);
                if ($parte === false || $parte === '') {
                    break;
                }
                $emite($parte);
            }
            fclose($archivo);
        };

        return $respuesta;
    }

    public function esFlujo(): bool
    {
        return $this->flujo !== null;
    }

    public static function redireccion(string $destino, int $estado = 302): self
    {
        return new self($estado, '', ['Location' => $destino]);
    }

    public static function sinContenido(): self
    {
        return new self(204, '');
    }

    /** Respuesta condicional HTTP: el cliente ya tiene exactamente esta versión. */
    public static function noModificada(string $etag): self
    {
        return new self(304, '', [
            'ETag'          => $etag,
            'Cache-Control' => 'no-store',
        ]);
    }

    private static function codificar(mixed $valor): string
    {
        return (string) json_encode(
            $valor,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION
        );
    }

    /**
     * Para las dos pantallas del ticket. «Compartir por WhatsApp» manda un
     * formulario y el servidor contesta 303 a `wa.me`, que a su vez salta a
     * `api.whatsapp.com`. El navegador revisa `form-action` en cada salto,
     * así que con solo `'self'` bloqueaba el envío y la pestaña quedaba en
     * blanco (bitácora 122). Solo estas dos pantallas abren la excepción.
     */
    public function conSalidaAWhatsApp(): self
    {
        return $this->conCabecera('Content-Security-Policy', str_replace(
            "form-action 'self'",
            "form-action 'self' https://wa.me https://api.whatsapp.com",
            self::POLITICA_CONTENIDO
        ));
    }

    /**
     * Para la hoja de la carta, que la pantalla Carta muestra dentro de un
     * marco como vista previa. Solo el mismo sitio puede enmarcarla; otro
     * sitio sigue sin poder hacerlo.
     */
    public function conMarcoPropio(): self
    {
        return $this->conCabecera('X-Frame-Options', 'SAMEORIGIN')->conCabecera('Content-Security-Policy', str_replace(
            "frame-ancestors 'none'",
            "frame-ancestors 'self'",
            self::POLITICA_CONTENIDO
        ));
    }

    public function conCabecera(string $nombre, string $valor): self
    {
        $copia = clone $this;
        $copia->cabeceras[$nombre] = $valor;
        return $copia;
    }

    public function estado(): int
    {
        return $this->estado;
    }

    public function cuerpo(): string
    {
        return $this->cuerpo;
    }

    /** @return array<string,string> */
    public function cabeceras(): array
    {
        return $this->cabeceras;
    }

    /** Escribe la respuesta. Es el único lugar del proyecto que hace echo. */
    public function enviar(): void
    {
        if (!headers_sent()) {
            // PHP anuncia su versión por omisión. No hace falta decirle a
            // nadie qué versión corre aquí.
            header_remove('X-Powered-By');

            http_response_code($this->estado);
            foreach ($this->cabeceras as $nombre => $valor) {
                header($nombre . ': ' . $valor);
            }
            // Nada de adivinar el tipo de contenido por el navegador. Una
            // respuesta puede endurecer una política (el ticket público usa
            // `no-referrer`), pero nunca se la pisamos con el valor general.
            foreach ([
                'X-Content-Type-Options' => 'nosniff',
                'X-Frame-Options' => 'DENY',
                'Referrer-Policy' => 'same-origin',
                'Content-Security-Policy' => self::POLITICA_CONTENIDO,
                'Permissions-Policy' => self::POLITICA_PERMISOS,
                'Cross-Origin-Opener-Policy' => 'same-origin',
                'Cross-Origin-Resource-Policy' => 'same-origin',
            ] as $nombre => $valor) {
                if (!$this->tieneCabecera($nombre)) {
                    header($nombre . ': ' . $valor);
                }
            }
        }

        if ($this->flujo !== null) {
            ($this->flujo)(static function (string $parte): void {
                echo $parte;
                flush();
            });
            return;
        }

        if ($this->cuerpo !== '') {
            echo $this->cuerpo;
        }
    }

    private function tieneCabecera(string $nombre): bool
    {
        foreach (array_keys($this->cabeceras) as $actual) {
            if (strcasecmp($actual, $nombre) === 0) {
                return true;
            }
        }

        return false;
    }
}
