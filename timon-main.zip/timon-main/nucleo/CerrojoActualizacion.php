<?php
declare(strict_types=1);

namespace Nucleo;

use Nucleo\Errores\Errores;
use RuntimeException;

/** Coordina peticiones, réplica y actualización entre procesos del mismo servidor. */
final class CerrojoActualizacion
{
    /** @return resource|null Fuera de una instalación por versiones no necesita candado. */
    public static function lectura(string $raiz)
    {
        $real = realpath($raiz) ?: $raiz;
        if (basename(dirname($real)) !== 'liberaciones') {
            return null;
        }
        $archivo = fopen(dirname($real, 2) . '/compartido/operacion.candado', 'c');
        if ($archivo === false) {
            throw new RuntimeException('No se pudo abrir el candado de operación');
        }
        if (!flock($archivo, LOCK_SH | LOCK_NB)) {
            fclose($archivo);
            throw Errores::ocupado('Actualización en curso. Intente de nuevo en un momento.');
        }
        // Una petición iniciada con el código anterior no escribe después del cambio.
        if (realpath(dirname($real, 2) . '/actual') !== $real) {
            self::libera($archivo);
            throw Errores::ocupado('El sistema se actualizó. Intente de nuevo.');
        }
        return $archivo;
    }

    /** @param resource|null $archivo */
    public static function libera($archivo): void
    {
        if (is_resource($archivo)) {
            flock($archivo, LOCK_UN);
            fclose($archivo);
        }
    }
}
