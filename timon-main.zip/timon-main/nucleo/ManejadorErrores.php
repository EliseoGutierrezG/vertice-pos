<?php
declare(strict_types=1);

namespace Nucleo;

use ErrorException;
use Nucleo\Errores\ErrorHttp;
use Throwable;

/**
 * Un solo lugar donde un problema se convierte en respuesta.
 *
 * Tres reglas:
 *  1. Lo previsto (ErrorHttp) sale con su código honesto y su mensaje, que
 *     está escrito para que lo lea una persona.
 *  2. Lo imprevisto sale como 500 SIN detalle, y se registra CON detalle.
 *  3. Nunca sale una traza, ni una ruta del servidor, ni SQL. Ni en local:
 *     lo que no se puede filtrar en produccion no se practica en local.
 */
final class ManejadorErrores
{
    public function __construct(
        private Registro $registro,
        private bool $depurar
    ) {
    }

    /** Avisos y advertencias de PHP pasan a ser excepciones: nada silencioso. */
    public function registrar(): void
    {
        set_error_handler(static function (int $nivel, string $mensaje, string $archivo, int $linea): bool {
            if ((error_reporting() & $nivel) === 0) {
                return false;
            }
            throw new ErrorException($mensaje, 0, $nivel, $archivo, $linea);
        });
    }

    public function aRespuesta(Throwable $e, Peticion $peticion): Respuesta
    {
        if ($e instanceof ErrorHttp) {
            // 401 y 403 se registran porque dicen algo sobre quién intenta qué.
            if (in_array($e->estado(), [401, 403, 419, 429], true)) {
                // La clave del permiso se queda aquí: a quien la lee en pantalla no le dice nada.
                $this->registro->aviso('Acceso rechazado', array_filter([
                    'estado' => $e->estado(),
                    'ruta'   => $peticion->metodo() . ' ' . $peticion->ruta(),
                    'ip_hash' => \Modelos\IntentosAcceso::hashDireccion($peticion->ip()),
                    'permiso' => $e->detalle(),
                ], static fn (mixed $valor): bool => $valor !== null));
            }

            $respuesta = $this->presenta(
                $peticion,
                $e->estado(),
                $e->clave(),
                $e->getMessage(),
                $e->campos(),
                $e->estadoActual()
            );

            foreach ($e->cabeceras() as $nombre => $valor) {
                $respuesta = $respuesta->conCabecera($nombre, $valor);
            }

            return $respuesta;
        }

        // Esto sí es culpa nuestra: queda completo en el registro.
        $this->registro->error('Falla no prevista', [
            'ruta' => $peticion->metodo() . ' ' . $peticion->ruta(),
            'ip'   => $peticion->ip(),
        ], $e);

        return $this->presenta(
            $peticion,
            500,
            'error_interno',
            'Algo salió mal. Intente de nuevo.',
            []
        );
    }

    /** @param array<string,string> $campos */
    private function presenta(
        Peticion $peticion,
        int $estado,
        string $clave,
        string $mensaje,
        array $campos,
        ?array $estadoActual = null
    ): Respuesta {
        if ($peticion->esperaJson()) {
            return Respuesta::jsonError($estado, $clave, $mensaje, $campos, $estadoActual);
        }

        return Respuesta::html($this->pagina($estado, $mensaje, $campos), $estado);
    }

    /**
     * Página mínima para el navegador. Sin traza y sin rutas del servidor.
     *
     * ⚠️ **Los mensajes por campo no llegaban.** `presenta()` se los daba al JSON
     * y a esta página no: la app sabía qué corregir y la persona no. Medido con
     * la misma petición, un día 31 de febrero en la fecha de un precio:
     *
     *     al navegador   «Hay datos que corregir»
     *     a la app       {"campos":{"desde":"Esa fecha no existe en el calendario"}}
     *
     * Son **43 mensajes** en el sistema, varios escritos a propósito en sesiones
     * anteriores justo para que la persona supiera qué arreglar —«El tope es
     * $100,000.00 por unidad», «Escribe un número con punto decimal, por ejemplo
     * 25.50»—, y en la web no se veía ninguno. Quien captura leía «hay datos que
     * corregir» y un enlace al inicio que le pierde lo escrito.
     *
     * @param array<string,string> $campos
     */
    private function pagina(int $estado, string $mensaje, array $campos = []): string
    {
        $titulo = match ($estado) {
            401     => 'Entre al sistema',
            403     => 'Sin permiso',
            404     => 'Aquí no hay nada',
            405     => 'Acción no disponible',
            419     => 'Sesión vencida. Entre de nuevo',
            422     => 'Datos por corregir',
            429     => 'Demasiados intentos. Espere un momento',
            default => 'Algo salió mal',
        };

        $e = static fn (string $t): string => htmlspecialchars($t, ENT_QUOTES, 'UTF-8');

        // El nombre del campo se enseña tal como lo escribió quien lanzó el
        // error, sin traducirlo: es el nombre del control del formulario, y con
        // él se encuentra. Inventar aquí una tabla de nombres bonitos sería otra
        // copia de algo que ya vive en la plantilla.
        $detalle = '';

        foreach ($campos as $campo => $queja) {
            $detalle .= '<li><b>' . $e((string) $campo) . '</b> · ' . $e($queja) . '</li>';
        }

        if ($detalle !== '') {
            $detalle = '<ul class="list-unstyled text-start small mb-0">' . $detalle . '</ul>';
        }

        $icono = match ($estado) {
            401, 419 => 'bi-person-lock',
            403      => 'bi-shield-lock',
            404      => 'bi-signpost-split',
            422      => 'bi-pencil-square',
            429      => 'bi-hourglass-split',
            default  => 'bi-exclamation-octagon',
        };

        // La misma cara que el resto del administrativo: las hojas de la plantilla base
        // y la capa de color de El Timón, servidas en local. Si alguna no
        // carga, la página sigue legible: sólo trae texto y un enlace.
        return <<<HTML
        <!doctype html>
        <html lang="es">
        <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#0F1F36">
        <title>{$estado} · {$e($titulo)} · El Timón</title>
        <link rel="stylesheet" href="/recursos/vendor/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="/recursos/vendor/bootstrap-icons/bootstrap-icons.css">
        <link rel="stylesheet" href="/recursos/plantilla/main.css?v=20261008.1">
        <link rel="stylesheet" href="/recursos/tema.css?v=20261118.1">
        </head>
        <body>
          <main class="login">
            <section class="module-card w-100" style="max-width: 32rem">
              <div class="module-state module-state--empty flex-column text-center">
                <span class="module-icon pb-error__sello"><i class="bi {$icono}" aria-hidden="true"></i></span>
                <span class="pb-etiqueta-tecnica">Error {$estado}</span>
                <h1 class="h5 mb-0 text-body">{$e($titulo)}</h1>
                <span>{$e($mensaje)}</span>
                {$detalle}
              </div>
              <div class="text-center mt-3">
                <a class="btn btn-primary" href="/panel"><i class="bi bi-house" aria-hidden="true"></i> Volver al inicio</a>
              </div>
            </section>
          </main>
        </body>
        </html>
        HTML;
    }
}
