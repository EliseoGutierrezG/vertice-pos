<?php
declare(strict_types=1);

namespace Nucleo;

use RuntimeException;

/**
 * Corre una tarea del cron, revisa el hospedaje y decide si hay que avisar
 * (fase 29).
 *
 * Además del código de salida de la tarea revisa lo que hace fallar a la
 * siguiente sin que nadie lo note: el disco libre y el tamaño de los registros.
 * El resultado queda en `almacenamiento/tareas/<tarea>.json`, que dice cuándo
 * fue la última corrida buena.
 */
final class TareaProgramada
{
    private const LINEAS_EN_AVISO = 40;

    /** @param array{espacio_minimo_mb:int,registros_maximo_mb:int} $umbrales */
    public function __construct(
        private string $raiz,
        private string $registros,
        private array $umbrales
    ) {
    }

    /**
     * @param list<string> $comando
     * @return array{codigo:int,salida:string,inicio:string,fin:string,segundos:float}
     */
    public function corre(array $comando): array
    {
        $inicio = date('c');
        $arranque = microtime(true);
        $proceso = proc_open($comando, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['redirect', 1]], $tubos, $this->raiz);
        if (!is_resource($proceso)) {
            throw new RuntimeException('No se pudo arrancar la tarea');
        }
        fclose($tubos[0]);
        $salida = (string) stream_get_contents($tubos[1]);
        fclose($tubos[1]);
        $codigo = proc_close($proceso);

        return [
            'codigo' => $codigo,
            'salida' => $salida,
            'inicio' => $inicio,
            'fin' => date('c'),
            'segundos' => round(microtime(true) - $arranque, 1),
        ];
    }

    /**
     * Lo que merece aviso aunque la tarea haya salido bien.
     *
     * @return list<string>
     */
    public function revisaHospedaje(?float $libreBytes = null): array
    {
        $avisos = [];
        $libre = $libreBytes ?? @disk_free_space($this->raiz);
        if ($libre === false) {
            $avisos[] = 'No se pudo medir el espacio libre del hospedaje';
        } elseif ($libre < $this->umbrales['espacio_minimo_mb'] * 1048576) {
            $avisos[] = sprintf(
                'Quedan %.0f MB libres; el mínimo configurado es %d MB',
                $libre / 1048576,
                $this->umbrales['espacio_minimo_mb']
            );
        }

        $registros = self::tamano($this->registros);
        if ($registros > $this->umbrales['registros_maximo_mb'] * 1048576) {
            $avisos[] = sprintf(
                'Los registros ocupan %.0f MB; el máximo configurado es %d MB',
                $registros / 1048576,
                $this->umbrales['registros_maximo_mb']
            );
        }

        return $avisos;
    }

    /**
     * @param array{codigo:int,salida:string,inicio:string,fin:string,segundos:float} $resultado
     * @param list<string> $avisos
     */
    public static function cuerpo(string $tarea, array $resultado, array $avisos): string
    {
        $lineas = preg_split('/\R/', rtrim($resultado['salida'])) ?: [];
        $cola = array_slice($lineas, -self::LINEAS_EN_AVISO);

        return implode("\n", array_merge([
            'Tarea: ' . $tarea,
            'Equipo: ' . (gethostname() ?: 'desconocido'),
            'Inicio: ' . $resultado['inicio'],
            'Fin: ' . $resultado['fin'] . ' (' . $resultado['segundos'] . ' s)',
            'Código de salida: ' . $resultado['codigo'],
            '',
            $avisos === [] ? 'Sin avisos del hospedaje.' : 'Avisos:',
        ], array_map(static fn (string $a): string => '- ' . $a, $avisos), [
            '',
            'Últimas líneas de la tarea:',
        ], $cola));
    }

    /**
     * @param array{codigo:int,salida:string,inicio:string,fin:string,segundos:float} $resultado
     * @param list<string> $avisos
     */
    public function guardaEstado(string $tarea, array $resultado, array $avisos): void
    {
        $carpeta = $this->raiz . '/almacenamiento/tareas';
        if (!is_dir($carpeta) && !mkdir($carpeta, 0750, true) && !is_dir($carpeta)) {
            throw new RuntimeException('No se pudo crear la carpeta de tareas');
        }
        $ruta = $carpeta . '/' . $tarea . '.json';
        $anterior = is_file($ruta) ? json_decode((string) file_get_contents($ruta), true) : null;
        $estado = [
            'tarea' => $tarea,
            'inicio' => $resultado['inicio'],
            'fin' => $resultado['fin'],
            'codigo' => $resultado['codigo'],
            'avisos' => $avisos,
            // La última corrida buena sobrevive a las fallidas: es lo que se
            // pregunta el día que algo salió mal.
            'ultima_buena' => $resultado['codigo'] === 0
                ? $resultado['fin']
                : (is_array($anterior) ? ($anterior['ultima_buena'] ?? null) : null),
        ];
        $temporal = $ruta . '.tmp-' . bin2hex(random_bytes(3));
        if (file_put_contents($temporal, json_encode($estado, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n") === false
            || !rename($temporal, $ruta)) {
            @unlink($temporal);
            throw new RuntimeException('No se pudo guardar el estado de la tarea');
        }
    }

    private static function tamano(string $carpeta): int
    {
        if (!is_dir($carpeta)) {
            return 0;
        }
        $total = 0;
        $iterador = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($carpeta, \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterador as $archivo) {
            if ($archivo->isFile()) {
                $total += $archivo->getSize();
            }
        }
        return $total;
    }
}
