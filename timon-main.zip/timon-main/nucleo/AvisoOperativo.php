<?php
declare(strict_types=1);

namespace Nucleo;

use RuntimeException;

/**
 * El aviso que llega a una persona cuando una tarea programada falla (fase 29).
 *
 * Un cron que falla en silencio es peor que no tener cron: todos creen que hay
 * respaldo. El transporte `mail` usa la función del hospedaje; `archivo` deja
 * el aviso en `almacenamiento/alertas/` y es el de local y pruebas. Si `mail`
 * no puede entregar, el aviso también queda en archivo y la tarea termina con
 * error para que el propio cron lo reporte.
 */
final class AvisoOperativo
{
    /** @param array{correo:string,remitente:string,transporte:string} $config */
    public function __construct(private array $config, private string $carpeta)
    {
    }

    /** Devuelve dónde quedó el aviso: `mail` o la ruta del archivo. */
    public function envia(string $asunto, string $cuerpo): string
    {
        // Un salto de línea en el asunto abre la puerta a inyectar cabeceras.
        $asunto = trim(preg_replace('/[\r\n]+/', ' ', $asunto) ?? '');
        $correo = $this->config['correo'];
        $remitente = $this->config['remitente'];

        if ($this->config['transporte'] === 'archivo') {
            return $this->guarda($correo, $asunto, $cuerpo);
        }

        if (filter_var($correo, FILTER_VALIDATE_EMAIL) === false || filter_var($remitente, FILTER_VALIDATE_EMAIL) === false) {
            $this->guarda($correo, $asunto, $cuerpo);
            throw new RuntimeException('El correo o el remitente de alertas no son válidos');
        }

        $cabeceras = [
            'From' => 'El Timón <' . $remitente . '>',
            'MIME-Version' => '1.0',
            'Content-Type' => 'text/plain; charset=UTF-8',
            'Content-Transfer-Encoding' => '8bit',
        ];
        $enviado = mail($correo, '=?UTF-8?B?' . base64_encode($asunto) . '?=', $cuerpo, $cabeceras);
        if (!$enviado) {
            $this->guarda($correo, $asunto, $cuerpo);
            throw new RuntimeException('El hospedaje no aceptó el correo de alerta');
        }

        return 'mail';
    }

    private function guarda(string $correo, string $asunto, string $cuerpo): string
    {
        if (!is_dir($this->carpeta) && !mkdir($this->carpeta, 0750, true) && !is_dir($this->carpeta)) {
            throw new RuntimeException('No se pudo crear la carpeta de alertas');
        }
        $ruta = $this->carpeta . '/' . date('Y-m-d-His') . '-' . bin2hex(random_bytes(3)) . '.txt';
        $texto = 'Para: ' . $correo . "\nAsunto: " . $asunto . "\n\n" . $cuerpo . "\n";
        if (file_put_contents($ruta, $texto, LOCK_EX) === false) {
            throw new RuntimeException('No se pudo guardar el aviso');
        }
        @chmod($ruta, 0640);

        return $ruta;
    }
}
