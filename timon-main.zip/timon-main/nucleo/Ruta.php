<?php
declare(strict_types=1);

namespace Nucleo;

/**
 * Una ruta de la tabla: verbo, patrón, a dónde va y por qué filtros pasa.
 *
 * El patrón admite parámetros con nombre y, si hace falta, con forma:
 *   /pedidos/{id}          cualquier cosa que no sea una barra
 *   /pedidos/{id:\d+}      sólo dígitos
 *
 * Los intermediarios se declaran AQUÍ, no dentro del controlador. Leer
 * rutas/web.php y rutas/api.php debe bastar para saber qué protege a qué.
 */
final class Ruta
{
    /** @var list<string> */
    private array $intermediarios = [];
    private string $nombre = '';
    private string $patronRegex;
    /** @var list<string> */
    private array $nombresParametros = [];

    /** @param array{0:class-string,1:string} $destino */
    public function __construct(
        private string $metodo,
        private string $patron,
        private array $destino
    ) {
        $this->patronRegex = $this->compilar($patron);
    }

    /**
     * Convierte el patrón en expresión regular.
     *
     * Se citan SÓLO los tramos literales. Citar el patrón entero y después
     * deshacer las llaves no sirve: `preg_quote` también escapa la barra
     * invertida, y `{id:\d+}` quedaba pidiendo una "d" literal.
     */
    private function compilar(string $patron): string
    {
        $nombres = [];
        $regex   = '';
        $desde   = 0;

        preg_match_all(
            '/\{([a-zA-Z_][a-zA-Z0-9_]*)(?::([^{}]+))?\}/',
            $patron,
            $coincidencias,
            PREG_OFFSET_CAPTURE | PREG_SET_ORDER
        );

        foreach ($coincidencias as $coincidencia) {
            [$completa, $inicio] = $coincidencia[0];

            // El tramo literal que va antes del parámetro.
            $regex .= preg_quote(substr($patron, $desde, $inicio - $desde), '#');

            $nombre    = $coincidencia[1][0];
            $tieneForma = isset($coincidencia[2]) && $coincidencia[2][1] !== -1;
            $forma     = $tieneForma ? $coincidencia[2][0] : '[^/]+';

            $nombres[] = $nombre;
            $regex    .= '(?P<' . $nombre . '>' . $forma . ')';

            $desde = $inicio + strlen($completa);
        }

        // Y lo que quede después del último parámetro.
        $regex .= preg_quote(substr($patron, $desde), '#');

        $this->nombresParametros = $nombres;

        return '#^' . $regex . '$#u';
    }

    /** @param string|list<string> $intermediarios */
    public function protege(string|array $intermediarios): self
    {
        foreach ((array) $intermediarios as $uno) {
            $this->intermediarios[] = $uno;
        }
        return $this;
    }

    public function llamada(string $nombre): self
    {
        $this->nombre = $nombre;
        return $this;
    }

    /**
     * ¿Esta ruta atiende esta URL? Devuelve los parámetros, o null.
     *
     * @return array<string,string>|null
     */
    public function coincide(string $ruta): ?array
    {
        if (preg_match($this->patronRegex, $ruta, $coincidencias) !== 1) {
            return null;
        }

        $parametros = [];
        foreach ($this->nombresParametros as $nombre) {
            $parametros[$nombre] = $coincidencias[$nombre];
        }

        return $parametros;
    }

    public function metodo(): string
    {
        return $this->metodo;
    }

    public function patron(): string
    {
        return $this->patron;
    }

    public function nombre(): string
    {
        return $this->nombre !== '' ? $this->nombre : $this->metodo . ' ' . $this->patron;
    }

    /** @return array{0:class-string,1:string} */
    public function destino(): array
    {
        return $this->destino;
    }

    /** @return list<string> */
    public function intermediarios(): array
    {
        return $this->intermediarios;
    }
}
