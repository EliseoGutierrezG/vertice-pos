<?php
declare(strict_types=1);

namespace Nucleo;

use RuntimeException;

/** Impide que un guion destructivo apunte fuera del entorno de pruebas. */
final class CerrojoPruebas
{
    public static function exige(string $raiz, ?string $destinoHttp = null): void
    {
        $app = Configuracion::aplicacion($raiz);
        $bd = Configuracion::baseDatos($raiz);

        if (!in_array((string) $app['entorno'], ['local', 'pruebas'], true)) {
            throw new RuntimeException('La operación destructiva sólo se permite en local o pruebas');
        }

        if (preg_match('/(?:_pruebas|_test)$/', (string) $bd['base']) !== 1) {
            throw new RuntimeException('La base destructiva debe terminar en _pruebas o _test');
        }

        if ($destinoHttp === null) {
            return;
        }

        $host = strtolower((string) parse_url($destinoHttp, PHP_URL_HOST));
        if ($host === '' || ($host !== 'localhost' && $host !== '127.0.0.1' && !str_ends_with($host, '.test'))) {
            throw new RuntimeException('El destino HTTP de pruebas debe ser localhost, 127.0.0.1 o un dominio .test');
        }
    }
}
