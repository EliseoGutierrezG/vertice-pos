<?php
declare(strict_types=1);

namespace Nucleo\Atributos;

use Attribute;

/**
 * Marca a qué módulo del negocio pertenece un controlador.
 *
 *     #[Modulo('pedidos')]
 *     final class Pedidos extends Controlador { ... }
 *
 * Se usa para el menú, para la bitácora y como prefijo natural de los
 * permisos de sus acciones.
 */
#[Attribute(Attribute::TARGET_CLASS)]
final class Modulo
{
    public function __construct(
        public readonly string $clave,
        public readonly string $nombre = ''
    ) {
    }
}
