<?php
declare(strict_types=1);

namespace Nucleo\Atributos;

use Attribute;

/**
 * Declara qué permiso exige una acción, y si es pública.
 *
 *     #[Accion('pedidos_ver')]           exige ese permiso
 *     #[Accion('compras_ordenes,entradas_registra')]
 *                                        acepta cualquiera de los dos
 *     #[Accion(publica: true)]           no exige ninguno, a propósito
 *     #[Accion(publica: true, conClaveTemporal: true)]
 *                                        y además se deja usar a quien entró
 *                                        con una contraseña temporal: cambiarla
 *                                        y salir. Todo lo demás lo manda a
 *                                        cambiarla (`ExigeClaveDefinitiva`).
 *     #[Accion('pedidos_captura', unaVez: true)]
 *                                        y además exige la llave de envío
 *                                        (`_envio`): sin ella se rechaza, y
 *                                        repetida se contesta lo mismo sin
 *                                        volver a hacerlo (`ExigeEnvioUnico`).
 *
 * Una acción **sin** este atributo se rechaza. Es deliberado: olvidar
 * declarar el permiso no puede traducirse en "entonces cualquiera puede".
 * El descuido tiene que fallar cerrado, no abierto.
 */
#[Attribute(Attribute::TARGET_METHOD)]
final class Accion
{
    public function __construct(
        public readonly string $permiso = '',
        public readonly bool $publica = false,
        public readonly bool $conClaveTemporal = false,
        public readonly bool $unaVez = false
    ) {
    }
}
