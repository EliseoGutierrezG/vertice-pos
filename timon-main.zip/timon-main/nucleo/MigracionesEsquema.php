<?php
declare(strict_types=1);

namespace Nucleo;

use RuntimeException;

/** Inventario inmutable y comparación del esquema incremental. */
final class MigracionesEsquema
{
    /** @return array<int,array{numero:int,nombre:string,ruta:string,sha256:string}> */
    public static function inventario(string $directorio): array
    {
        $archivos = glob(rtrim($directorio, '/') . '/[0-9][0-9][0-9]_*.sql') ?: [];
        sort($archivos, SORT_STRING);

        if ($archivos === []) {
            throw new RuntimeException('No hay guiones numerados de esquema');
        }

        $inventario = [];
        $esperado = 1;
        foreach ($archivos as $ruta) {
            $nombre = basename($ruta);
            if (!preg_match('/^(\d{3})_[a-z0-9_-]+\.sql$/i', $nombre, $coincidencia)) {
                throw new RuntimeException("Nombre de migración no válido: {$nombre}");
            }
            $numero = (int) $coincidencia[1];
            if ($numero !== $esperado) {
                throw new RuntimeException(sprintf(
                    'La secuencia no es continua: se esperaba %03d y apareció %s',
                    $esperado,
                    $nombre
                ));
            }
            $sha256 = hash_file('sha256', $ruta);
            if ($sha256 === false) {
                throw new RuntimeException("No se pudo calcular la huella de {$nombre}");
            }
            $inventario[$numero] = compact('numero', 'nombre', 'ruta', 'sha256');
            $esperado++;
        }

        return $inventario;
    }

    /**
     * @param array<int,array{numero:int,nombre:string,ruta:string,sha256:string}> $inventario
     * @param list<array{numero:int|string,nombre:string,sha256:string}> $aplicadas
     * @return array{pendientes:list<array{numero:int,nombre:string,ruta:string,sha256:string}>,errores:list<string>}
     */
    public static function compara(array $inventario, array $aplicadas): array
    {
        $registradas = [];
        $errores = [];

        foreach ($aplicadas as $fila) {
            $numero = (int) $fila['numero'];
            $registradas[$numero] = true;
            if (!isset($inventario[$numero])) {
                $errores[] = sprintf('La base registra la migración %03d, pero el archivo no existe', $numero);
                continue;
            }
            $archivo = $inventario[$numero];
            if (!hash_equals($archivo['sha256'], (string) $fila['sha256'])) {
                $errores[] = sprintf('La huella de %s cambió después de aplicarse', $archivo['nombre']);
            }
            if ($archivo['nombre'] !== (string) $fila['nombre']) {
                $errores[] = sprintf('La migración %03d cambió de nombre', $numero);
            }
        }

        $pendientes = [];
        foreach ($inventario as $numero => $archivo) {
            if (!isset($registradas[$numero])) {
                $pendientes[] = $archivo;
            }
        }

        return compact('pendientes', 'errores');
    }

    /**
     * Las tablas que dejan los guiones, leídas de sus `CREATE TABLE` y
     * `DROP TABLE` en orden. Leer nombres es más burdo que interpretar el DDL y
     * es justo lo que hace falta para saber si una base tiene lo que el código
     * espera. Una tabla de trabajo que el mismo guion crea y borra (los mapas
     * de la 046) no cuenta, ni una que un guion posterior retire.
     *
     * @param list<string> $rutas Los guiones, en el orden en que se aplican.
     * @return list<string>
     */
    public static function tablasDeclaradas(array $rutas): array
    {
        $tablas = [];
        foreach ($rutas as $ruta) {
            preg_match_all(
                '/^\s*(CREATE|DROP) TABLE(?:\s+IF (?:NOT )?EXISTS)?\s+`?([a-z_0-9]+)`?/mi',
                (string) file_get_contents($ruta),
                $sentencias,
                PREG_SET_ORDER
            );
            foreach ($sentencias as [, $verbo, $tabla]) {
                if (strtoupper($verbo) === 'CREATE') {
                    $tablas[strtolower($tabla)] = true;
                } else {
                    unset($tablas[strtolower($tabla)]);
                }
            }
        }
        return array_keys($tablas);
    }
}
