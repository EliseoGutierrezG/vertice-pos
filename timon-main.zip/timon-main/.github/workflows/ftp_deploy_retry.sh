#!/bin/bash
# ftp_deploy_retry.sh – Ejecuta ftp_deploy_node.js y reintenta si la conexión falla.
#
# Solo reintenta errores de red (conexión cortada, tiempo agotado…). Un usuario
# o contraseña incorrectos se detienen al primer intento.
set +e

max_attempts="${FTP_MAX_ATTEMPTS:-10}"
attempt=1
dir="$(dirname "$0")"

while [ "$attempt" -le "$max_attempts" ]; do
  echo "Intento $attempt/$max_attempts: sincronizando archivos por FTP…"
  output=$(node "$dir/ftp_deploy_node.js" 2>&1)
  exit_code=$?
  echo "$output"

  if [ $exit_code -eq 0 ]; then
    echo "Sincronización completada en el intento $attempt."
    exit 0
  fi

  if grep -qiE "ECONNRESET|ETIMEDOUT|ECONNREFUSED|EPIPE|EHOSTUNREACH|timeout|socket hang up|^421|^425|^426| 421 | 425 | 426 " <<< "$output"; then
    bash "$dir/send_slack_message.sh" \
      "Error de conexión FTP para $SERVICE_NAME (intento $attempt/$max_attempts). Se reintentará." \
      "warning" \
      "*Error de conexión FTP para $SERVICE_NAME (intento $attempt/$max_attempts): reintentando.*" \
      "${SLACK_WEBHOOK_URL:-}"
  else
    echo "::error::Error que no es de conexión (revisa usuario, contraseña, carpeta o protocolo). No se reintenta."
    exit $exit_code
  fi

  attempt=$((attempt + 1))
  sleep 5
done

echo "::error::Se alcanzó el máximo de intentos ($max_attempts) sin lograr la sincronización."
exit 1
