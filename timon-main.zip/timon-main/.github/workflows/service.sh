#!/bin/bash
# service.sh – Configuración del servicio.
#
# Es el ÚNICO archivo de la plantilla que se edita en cada proyecto. Los flujos
# lo ejecutan al inicio y dejan cada valor disponible como variable de entorno
# para el resto de los pasos.

SERVICE_NAME="timon"                  # Nombre del servicio. Ej.: vertice-landing
SERVICE_TYPE="backend"                # "frontend" o "backend" (solo cambia el color en Slack)
FRAMEWORK="php"                       # react, astro, vue, expo, laravel, php…
PROJECT_SRC="."                       # Carpeta del código (donde están package.json o composer.json)
BUILD_DIR="./entregables/despliegue/app-subdominio-ftp"  # Carpeta que se sube al servidor
NODE_VERSION="24"                     # Vacío si el proyecto no usa Node
PHP_VERSION="8.3"                     # Ej.: 8.3 si el proyecto usa Composer; vacío si no
CHECK_COMMAND='find . -name "*.php" -not -path "./node_modules/*" -not -path "./app/*" -not -path "./entregables/*" -not -path "./tmp/*" -not -path "./output/*" -print0 | xargs -0 -n1 -P4 php -l > /dev/null'  # Se corre antes del build. Ej.: "npm run lint"
FTP_SERVER_DIR="./"                   # Carpeta remota, relativa a donde entra la cuenta FTP
FTP_PROTOCOL="ftps"                   # "ftps" (cifrado) o "ftp"
FTP_EXCLUDE="app-bloqueo-instalacion.htaccess .app/config/giro.php .app/instalacion/app-esquema.sql .app/instalacion/app-esquema.sql.sha256 .app/instalacion/app-esquema.sql.json"  # Patrones que NO se suben, separados por espacio. Ej.: ".env storage/logs/**"
DEV_SERVICE_URL="https://staging-timon.verticesoftware.com.mx"  # URL de staging.     Ej.: https://staging.midominio.com
PROD_SERVICE_URL="https://timon.verticesoftware.com.mx"  # URL de producción.  Ej.: https://midominio.com


# ── No hace falta editar de aquí para abajo ──────────────────────────────────
for key in SERVICE_NAME SERVICE_TYPE FRAMEWORK PROJECT_SRC BUILD_DIR NODE_VERSION PHP_VERSION CHECK_COMMAND FTP_SERVER_DIR FTP_PROTOCOL FTP_EXCLUDE DEV_SERVICE_URL PROD_SERVICE_URL; do
  export "${key?}"
  # Dentro de GitHub Actions, los pasos siguientes también las ven.
  if [ -n "${GITHUB_ENV:-}" ]; then
    echo "$key=${!key}" >> "$GITHUB_ENV"
  fi
done

# Salidas del paso, para la URL del entorno que se muestra en GitHub.
if [ -n "${GITHUB_OUTPUT:-}" ]; then
  echo "dev_url=$DEV_SERVICE_URL" >> "$GITHUB_OUTPUT"
  echo "prod_url=$PROD_SERVICE_URL" >> "$GITHUB_OUTPUT"
fi

if [ -z "$SERVICE_NAME" ] || [ -z "$BUILD_DIR" ]; then
  echo "::error::Completa SERVICE_NAME y BUILD_DIR en .github/workflows/service.sh"
  exit 1
fi
