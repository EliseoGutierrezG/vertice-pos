#!/bin/bash
# smoke_check.sh – Comprueba que el sitio publicado responde y sirve el build nuevo.
#
# Uso: smoke_check.sh <url>
#
# Si BUILD_DIR/index.html enlaza archivos con huella (assets/inicio-AbC123.js,
# _astro/…), espera a que la página publicada enlace el mismo archivo. Si no,
# solo comprueba que la URL responda 2xx/3xx.
set -uo pipefail

URL="${1:-}"
if [ -z "$URL" ]; then
  echo "Sin URL del servicio en service.sh: se omite la comprobación."
  exit 0
fi

cd "$(dirname "$0")/../.."
INDEX="${BUILD_DIR:-}/index.html"
esperado=""
if [ -f "$INDEX" ]; then
  esperado=$(grep -oE '(src|href)="/?[^"]+\.(js|css)"' "$INDEX" | head -1 | sed -E 's/^(src|href)="\/?//; s/"$//')
fi

for intento in 1 2 3 4 5 6; do
  html=$(curl -fsSL -H "Cache-Control: no-cache" "${URL%/}/?v=${GITHUB_SHA:-local}" 2>/dev/null)
  estado=$?
  if [ $estado -eq 0 ]; then
    if [ -z "$esperado" ]; then
      echo "El sitio responde: $URL"; exit 0
    fi
    if grep -qF "$esperado" <<< "$html"; then
      curl -fsS -o /dev/null "${URL%/}/$esperado" || { echo "::error::La página enlaza $esperado pero el archivo no se descarga"; exit 1; }
      echo "Publicado y sirviendo la versión nueva ($esperado): $URL"; exit 0
    fi
    echo "Aún no se ve la versión nueva (se espera $esperado); reintento…"
  else
    echo "El sitio no responde todavía ($URL); reintento…"
  fi
  sleep 10
done

echo "::error::$URL no sirve la versión que se subió. Si el archivo sí está en el servidor, purga la caché del CDN y vuelve a correr el flujo."
exit 1
