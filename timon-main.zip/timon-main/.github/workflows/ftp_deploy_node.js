// ftp_deploy_node.js – Sincroniza BUILD_DIR con el servidor por FTP/FTPS.
//
// Usa @samkirkland/ftp-deploy, que guarda en el servidor un registro de lo que
// subió (.ftp-deploy-sync-state.json). Así cada despliegue:
//   1. sube solo los archivos nuevos o modificados,
//   2. y AL FINAL borra los que ya no existen en el build.
// Nunca toca archivos que no subió él (por ejemplo .well-known/ o lo que se
// haya puesto a mano), ni los que coinciden con FTP_EXCLUDE.
const path = require("path");
const { deploy, excludeDefaults } = require("@samkirkland/ftp-deploy");

function requerida(nombre) {
  const valor = process.env[nombre];
  if (!valor) {
    console.error(`Falta la variable ${nombre}. Revisa los secretos del entorno en GitHub.`);
    process.exit(2);
  }
  return valor;
}

const raiz = path.resolve(__dirname, "../..");
const carpetaLocal = path.resolve(raiz, process.env.BUILD_DIR || "./desarrollo") + path.sep;
let carpetaRemota = process.env.FTP_SERVER_DIR || "./";
if (!carpetaRemota.endsWith("/")) carpetaRemota += "/";

const extra = (process.env.FTP_EXCLUDE || "").split(/\s+/).filter(Boolean);

const opciones = {
  server: requerida("FTP_SERVER"),
  username: requerida("FTP_USERNAME"),
  password: requerida("FTP_PASSWORD"),
  port: Number(process.env.FTP_PORT || 21),
  protocol: process.env.FTP_PROTOCOL || "ftps",
  // "loose": cifra igual, pero acepta certificados cuyo nombre no coincide con
  // el host (lo normal en hosting compartido cuando se conecta por IP).
  security: process.env.FTP_SECURITY || "loose",
  "local-dir": carpetaLocal,
  "server-dir": carpetaRemota,
  exclude: [...excludeDefaults, ...extra],
  "log-level": process.env.FTP_LOG_LEVEL || "standard",
  "dry-run": process.env.FTP_DRY_RUN === "true",
  timeout: 60000,
};

console.log(`Subiendo ${carpetaLocal} → ${opciones.protocol}://${opciones.server}:${opciones.port}/${carpetaRemota}`);

deploy(opciones)
  .then(() => {
    console.log("Sincronización terminada.");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Error en la sincronización:", error && error.message ? error.message : error);
    process.exit(1);
  });
