#!/bin/bash
# build_project.sh – Instala dependencias, revisa y construye el proyecto.
#
# Variables que usa:
#   DEPLOY_ENV   staging | production (decide qué sección de ENV_CONFIG se usa)
#   ENV_CONFIG   variable de repositorio opcional con este formato:
#                  # STAGING
#                  VITE_API_URL=https://api.staging.midominio.com
#                  # PRODUCTION
#                  VITE_API_URL=https://api.midominio.com
#   y las de service.sh (PROJECT_SRC, BUILD_DIR, CHECK_COMMAND…).
set -euo pipefail
export SHELL=/bin/bash

cd "$(dirname "$0")/../.."   # raíz del repositorio

# Fuera de GitHub Actions (pruebas locales) se carga la configuración aquí.
if [ -z "${SERVICE_NAME:-}" ]; then
  source .github/workflows/service.sh
fi

DEPLOY_ENV="${DEPLOY_ENV:-production}"
SRC="${PROJECT_SRC:-.}"

echo "=== $SERVICE_NAME · entorno: $DEPLOY_ENV ==="
echo "Código: $SRC · Build: $BUILD_DIR · Framework: ${FRAMEWORK:-sin especificar}"

# 1. Variables de entorno del build (solo se muestran los NOMBRES, nunca los valores)
if [ -n "${ENV_CONFIG:-}" ]; then
  seccion_buscada="# $(echo "$DEPLOY_ENV" | tr '[:lower:]' '[:upper:]')"
  seccion=""
  archivo_env="$SRC/.env.production.local"
  : > "$archivo_env"
  while IFS= read -r linea || [ -n "$linea" ]; do
    linea="${linea%$'\r'}"
    limpia="$(echo "$linea" | sed -E 's/^[[:space:]]+|[[:space:]]+$//g')"
    case "$limpia" in
      "# STAGING" | "# PRODUCTION") seccion="$limpia"; continue ;;
    esac
    if [ "$seccion" = "$seccion_buscada" ] && [[ "$limpia" =~ ^[A-Za-z_][A-Za-z0-9_]*= ]]; then
      echo "$limpia" >> "$archivo_env"
      export "${limpia?}"
      echo "  · ${limpia%%=*}"
    fi
  done <<< "$ENV_CONFIG"
  echo "Variables de $seccion_buscada escritas en $archivo_env"
fi

# 2. Dependencias
if [ -f "$SRC/composer.json" ]; then
  echo "=== composer install ==="
  (cd "$SRC" && composer install --no-dev --prefer-dist --optimize-autoloader --no-interaction --no-progress)
fi

if [ -f "$SRC/package.json" ]; then
  if [ -f "$SRC/pnpm-lock.yaml" ]; then
    command -v pnpm >/dev/null || npm install -g pnpm
    echo "=== pnpm install ==="
    (cd "$SRC" && pnpm install --frozen-lockfile)
    gestor="pnpm"
  elif [ -f "$SRC/package-lock.json" ]; then
    echo "=== npm ci ==="
    (cd "$SRC" && npm ci)
    gestor="npm"
  else
    echo "=== npm install (sin package-lock.json) ==="
    (cd "$SRC" && npm install)
    gestor="npm"
  fi
fi

# 3. Revisión previa (lint, pruebas…)
if [ -n "${CHECK_COMMAND:-}" ]; then
  echo "=== Revisión: $CHECK_COMMAND ==="
  (cd "$SRC" && bash -c "$CHECK_COMMAND")
fi

# 4. Build (solo si el package.json tiene script "build")
if [ -f "$SRC/package.json" ] && node -e "process.exit(require(require('path').resolve(process.argv[1], 'package.json')).scripts?.build ? 0 : 1)" "$SRC"; then
  echo "=== $gestor run build ==="
  (cd "$SRC" && "$gestor" run build)
else
  echo "Sin script de build: se sube $BUILD_DIR tal cual."
fi

# 5. Lo que se va a subir debe existir y no estar vacío
if [ ! -d "$BUILD_DIR" ] || [ -z "$(ls -A "$BUILD_DIR")" ]; then
  echo "::error::La carpeta $BUILD_DIR no existe o está vacía después del build"
  exit 1
fi
echo "Build listo: $(find "$BUILD_DIR" -type f | wc -l | tr -d ' ') archivos en $BUILD_DIR"
