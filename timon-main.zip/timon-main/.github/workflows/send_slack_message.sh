#!/bin/bash
# send_slack_message.sh
#
# Uso:
#   ./send_slack_message.sh "<fallback>" "<color>" "<texto>" "<webhook_url>"
#
# Si el proyecto no tiene Slack (webhook vacío), no hace nada y no falla.

if [ "$#" -ne 4 ]; then
  echo "Uso: $0 <fallback> <color> <texto> <webhook_url>"
  exit 1
fi

FALLBACK="$1"
COLOR="$2"
TEXT="$3"
WEBHOOK_URL="$4"

if [ -z "$WEBHOOK_URL" ]; then
  echo "Slack: sin SLACK_WEBHOOK_URL, se omite el aviso → $FALLBACK"
  exit 0
fi

# jq arma el JSON escapando comillas y saltos de línea del mensaje.
PAYLOAD=$(jq -n --arg f "$FALLBACK" --arg c "$COLOR" --arg t "$TEXT" \
  '{attachments: [{fallback: $f, color: $c, text: $t, mrkdwn_in: ["text"]}]}')

# Un aviso que no llega no debe tumbar el despliegue.
curl -sS -X POST -H 'Content-type: application/json' --data "$PAYLOAD" "$WEBHOOK_URL" || true
echo
