<?php
declare(strict_types=1);

/**
 * Lo que corre el cron del hospedaje (fase 29).
 *
 *   php guiones/tarea.php respaldo --cifrar
 *   php guiones/tarea.php mantenimiento
 *   php guiones/tarea.php prueba-aviso
 *
 * Corre el guion de la tarea, deja su estado en `almacenamiento/tareas/` y
 * avisa por correo (config/alertas.php) si la tarea falla o si el hospedaje se
 * está quedando sin espacio o con registros enormes. Sólo acepta las tareas de
 * la lista: el cron no es una puerta para correr cualquier archivo.
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

const TAREAS = ['respaldo' => 'respaldo.php', 'mantenimiento' => 'mantenimiento.php'];

$tarea = $argv[1] ?? '';
if (!isset(TAREAS[$tarea]) && $tarea !== 'prueba-aviso') {
    fwrite(STDERR, "Uso: tarea.php (respaldo|mantenimiento) [opciones] | prueba-aviso\n");
    exit(2);
}

try {
    $alertas = Nucleo\Configuracion::alertas($raiz);
    $registros = (string) Nucleo\Configuracion::aplicacion($raiz)['registros'];
} catch (Throwable $e) {
    // Sin a quién avisar, la tarea no corre: correr a ciegas es lo que se evita.
    fwrite(STDERR, 'Falta la configuración de alertas: ' . $e->getMessage() . "\n");
    exit(1);
}

$tareas = new Nucleo\TareaProgramada($raiz, $registros, $alertas);
$aviso = new Nucleo\AvisoOperativo($alertas, $raiz . '/almacenamiento/alertas');

if ($tarea === 'prueba-aviso') {
    if (count($argv) !== 2) {
        fwrite(STDERR, "prueba-aviso no recibe opciones.\n");
        exit(2);
    }
    try {
        $destino = $aviso->envia(
            'El Timón: aviso de prueba',
            "Éste es un aviso solicitado desde la consola. No falló ninguna tarea.\n"
        );
        fwrite(STDOUT, 'Aviso de prueba enviado por ' . ($destino === 'mail' ? 'correo' : 'archivo') . ".\n");
        exit(0);
    } catch (Throwable $e) {
        fwrite(STDERR, 'No se pudo enviar el aviso de prueba: ' . $e->getMessage() . "\n");
        exit(1);
    }
}

// PB_TAREA_GUION sólo existe para que las pruebas simulen una tarea que falla.
$guion = $raiz . '/guiones/' . TAREAS[$tarea];
if (Nucleo\Configuracion::entorno($raiz) !== 'produccion' && getenv('APP_ENTORNO') === 'pruebas'
    && is_string(getenv('PB_TAREA_GUION')) && getenv('PB_TAREA_GUION') !== '') {
    $guion = (string) getenv('PB_TAREA_GUION');
}

$resultado = $tareas->corre(array_merge([PHP_BINARY, $guion], array_slice($argv, 2)));
fwrite(STDOUT, $resultado['salida']);

$avisos = $tareas->revisaHospedaje();
$tareas->guardaEstado($tarea, $resultado, $avisos);

$codigo = $resultado['codigo'];
if ($codigo !== 0 || $avisos !== []) {
    $asunto = $codigo !== 0
        ? 'El Timón: falló la tarea «' . $tarea . '»'
        : 'El Timón: la tarea «' . $tarea . '» terminó con avisos del hospedaje';
    try {
        $destino = $aviso->envia($asunto, Nucleo\TareaProgramada::cuerpo($tarea, $resultado, $avisos));
        fwrite(STDOUT, 'Aviso enviado por ' . ($destino === 'mail' ? 'correo' : 'archivo') . ".\n");
    } catch (Throwable $e) {
        fwrite(STDERR, 'No se pudo enviar el aviso: ' . $e->getMessage() . "\n");
        exit($codigo !== 0 ? $codigo : 1);
    }
}

exit($codigo);
