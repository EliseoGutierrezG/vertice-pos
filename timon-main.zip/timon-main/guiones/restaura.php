<?php
declare(strict_types=1);

/**
 * Restaura un respaldo (paso 20.5).
 *
 *   php guiones/restaura.php almacenamiento/respaldos/timon-2026-09-24-0302.sql.gz --base=test_timon
 *   php guiones/restaura.php <archivo> --acepto        (encima de la base configurada)
 *   php guiones/restaura.php <archivo> --credenciales=/ruta/bd-desechable.php
 *
 * `--credenciales` apunta a un archivo con la misma forma que `config/bd.php`
 * (host, puerto, base, usuario, clave). En un hospedaje compartido cada base
 * tiene su propio usuario, y la base desechable donde se prueba la
 * restauración no es la excepción.
 *
 * **Un respaldo que nunca se restauró no es un respaldo, es un archivo.** Este
 * guion existe para que restaurar sea algo que ya se hizo, no algo que se va a
 * intentar por primera vez el día del problema. `pruebas/respaldo.sh` lo corre
 * contra una base aparte y compara tabla por tabla.
 *
 * **El cerrojo está del lado de restaurar, no de respaldar.** Respaldar no
 * destruye nada; restaurar borra todas las tablas del destino antes de
 * escribirlas. Por eso, encima de la base que está en `config/bd.php`, exige
 * `--acepto` escrito a mano.
 */

$raiz = dirname(__DIR__);

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);

// En la línea de comandos PHP corre en UTC si nadie le dice otra cosa, y el
// cron del hospedaje es línea de comandos. Sin esto, este guion y la
// aplicación web tendrían horas distintas —seis, aquí— para el mismo
// instante. La regla está en `pruebas/ArquitecturaPrueba.php`.
Nucleo\Reloj::fijaLaZona($raiz);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

$banderas = array_slice($argv, 1);
$archivos = array_values(array_filter($banderas, static fn (string $b): bool => !str_starts_with($b, '--')));

if ($archivos === []) {
    fwrite(STDERR, "Uso: php guiones/restaura.php <archivo.sql[.gz]> [--base=otra] [--credenciales=RUTA] [--acepto]\n");
    exit(1);
}

$archivo = $archivos[0];

if (!is_file($archivo)) {
    fwrite(STDERR, "No existe el archivo: $archivo\n");
    exit(1);
}

$configuracion = Nucleo\Configuracion::baseDatos($raiz);
$acceso        = $configuracion;

foreach ($banderas as $bandera) {
    if (str_starts_with($bandera, '--credenciales=')) {
        $ruta  = substr($bandera, 15);
        $otras = is_file($ruta) ? require $ruta : null;
        if (!is_array($otras) || array_diff(['host', 'base', 'usuario', 'clave'], array_keys($otras)) !== []) {
            fwrite(STDERR, "El archivo de credenciales debe devolver host, base, usuario y clave.\n");
            exit(1);
        }
        $acceso = $otras + ['puerto' => 3306];
    }
}

$destino = (string) $acceso['base'];

foreach ($banderas as $bandera) {
    if (str_starts_with($bandera, '--base=')) {
        $destino = substr($bandera, 7);
    }
}

if (preg_match('/^[A-Za-z0-9_]+$/', $destino) !== 1) {
    fwrite(STDERR, "Ese nombre de base no es válido.\n");
    exit(1);
}

// Otras credenciales no vuelven inofensiva a la base configurada. No se
// compara el servidor: «localhost» y «127.0.0.1» son el mismo, y adivinarlo mal
// costaría la base de trabajo. Mismo nombre, mismo cerrojo.
if ($destino === (string) $configuracion['base'] && !in_array('--acepto', $banderas, true)) {
    echo "Esto BORRARÍA las tablas de «{$destino}», que es la base configurada.\n";
    fwrite(STDERR, "Si de verdad es lo que quieres, agrega --acepto.\n");
    exit(1);
}

// Se conecta **sin** base para poder crearla si hace falta; en un hospedaje
// compartido la base normalmente se crea desde el panel y esto no tiene permiso,
// así que si no existe se dice con claridad en lugar de fallar con el error del
// motor a media restauración.
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$conexion = new mysqli(
    (string) $acceso['host'],
    (string) $acceso['usuario'],
    (string) $acceso['clave'],
    '',
    (int) $acceso['puerto']
);
$conexion->set_charset('utf8mb4');

// Preparada, como todo lo demás en el proyecto. El nombre ya venía validado
// contra `/^[A-Za-z0-9_]+$/`, pero «ya lo validé antes» es exactamente la frase
// que precede a los agujeros: si el valor puede ir por parámetro, va por
// parámetro. El nombre de la base del CREATE de más abajo no puede —ahí no
// admite parámetro—, y por eso ese sí se apoya en la validación.
$sentencia = $conexion->prepare(
    'SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name = ?'
);
$sentencia->bind_param('s', $destino);
$sentencia->execute();
$resultado = $sentencia->get_result();
$hay       = $resultado === false ? 0 : (int) ($resultado->fetch_array()[0] ?? 0);
$sentencia->close();

if ($hay === 0) {
    try {
        $conexion->query('CREATE DATABASE `' . $destino . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        echo "  Se creó la base «{$destino}».\n";
    } catch (mysqli_sql_exception $e) {
        fwrite(STDERR, "La base «{$destino}» no existe y este usuario no puede crearla. Créala en el panel del hospedaje.\n");
        exit(1);
    }
}

$conexion->select_db($destino);

$arranque   = microtime(true);
$manejador  = str_ends_with($archivo, '.gz') ? gzopen($archivo, 'rb') : fopen($archivo, 'rb');
$sentencias = 0;
$linea      = 0;

if ($manejador === false) {
    fwrite(STDERR, "No se pudo abrir $archivo\n");
    exit(1);
}

echo "  Restaurando $archivo en «{$destino}»…\n";

// Una sentencia por renglón: es como escribe el respaldo, y hace que partir el
// archivo sea leer una línea en vez de interpretar SQL a mano. Los valores no
// traen saltos de línea de verdad —salen escapados como «\n»—, así que no hay
// forma de partir una sentencia por la mitad.
while (($texto = str_ends_with($archivo, '.gz') ? gzgets($manejador) : fgets($manejador)) !== false) {
    $linea++;
    $texto = trim($texto);

    if ($texto === '' || str_starts_with($texto, '--')) {
        continue;
    }

    try {
        $conexion->query(rtrim($texto, ';'));
        $sentencias++;
    } catch (mysqli_sql_exception $e) {
        fwrite(STDERR, sprintf("\n  Falló en la línea %d: %s\n", $linea, $e->getMessage()));
        exit(1);
    }
}

str_ends_with($archivo, '.gz') ? gzclose($manejador) : fclose($manejador);

$tablas = $conexion->query('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE()');

printf(
    "  Listo: %d sentencias, %d tablas, %.1f segundos.\n",
    $sentencias,
    $tablas === false ? 0 : (int) ($tablas->fetch_array()[0] ?? 0),
    microtime(true) - $arranque
);
