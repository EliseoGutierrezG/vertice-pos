#!/usr/bin/env bash
# Lista compartida por los paquetes de Hostinger y de sucursal. Solo código:
# la configuración concreta, dependencias y datos nunca se copian aquí.
DIRECTORIOS_CODIGO=(controladores dominio modelos nucleo servicios vistas rutas publico)
GUIONES_DESPLIEGUE=(
  acceso-soporte.php verifica-bitacora.php crear-usuario.php descifra-respaldo.php
  genera-clave-seguridad.php genera-llave-respaldo.php mantenimiento.php
  migraciones.php parametro.php respaldo.php restaura.php tarea.php
  verifica-cierre-host.php verifica-host.php registra-liberacion.php
  actualiza.php sincroniza.php disparadores-replica.php genera-sql-despliegue.php
)

metadatos_app() {
  php -r '$v=json_decode(file_get_contents($argv[1]),true)["expo"]["version"];
    file_put_contents($argv[2],"<?php\nreturn ".var_export(["version"=>$v,"minima"=>"1.0.0"],true).";\n");' \
    "$1/app/app.json" "$2/config/app-movil.php"
  if [ -f "$1/config/firma-liberaciones.pub" ]; then
    cp "$1/config/firma-liberaciones.pub" "$2/config/"
  fi
}
