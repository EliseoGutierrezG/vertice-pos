<?php
declare(strict_types=1);

/**
 * Firma un paquete de versión para las computadoras de sucursal. Lo llama
 * `guiones/prepara-liberacion-sucursal.sh`; deja junto al paquete su
 * `.firma.json`, que es lo que se sube al central con él.
 *
 *   php guiones/firma-paquete.php PAQUETE.tar.gz ID ESQUEMA [--privada=RUTA]
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZonaConNombre('America/Mexico_City');

use Nucleo\Seguridad\FirmaLiberacion;

if (PHP_SAPI !== 'cli' || $argc < 4) {
    fwrite(STDERR, "Uso: firma-paquete.php PAQUETE.tar.gz ID ESQUEMA [--privada=RUTA]\n");
    exit(2);
}
[, $paquete, $id, $esquema] = $argv;
$privada = (string) (getenv('HOME') ?: '') . '/.timon/firma-liberaciones.llave';
foreach (array_slice($argv, 4) as $argumento) {
    if (str_starts_with($argumento, '--privada=')) {
        $privada = substr($argumento, strlen('--privada='));
    }
}
if (!is_file($privada)) {
    fwrite(STDERR, "No está la llave privada en {$privada}: genérela con guiones/genera-llave-firma.php.\n");
    exit(1);
}
$descriptor = FirmaLiberacion::firma($id, (int) $esquema, $paquete, trim((string) file_get_contents($privada)));
$publica = FirmaLiberacion::publicaDe($raiz);
if ($publica === null || !FirmaLiberacion::verifica($descriptor, $publica)) {
    fwrite(STDERR, "La llave privada no corresponde a config/firma-liberaciones.pub.\n");
    exit(1);
}
$destino = preg_replace('/\.tar\.gz$/', '', $paquete) . '.firma.json';
file_put_contents($destino, json_encode($descriptor, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n", LOCK_EX);
fwrite(STDOUT, $destino . "\n");
