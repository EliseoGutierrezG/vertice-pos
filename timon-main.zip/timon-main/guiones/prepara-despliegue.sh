#!/usr/bin/env bash

set -euo pipefail

RAIZ_PROYECTO="$(cd "$(dirname "$0")/.." && pwd)"
. "$RAIZ_PROYECTO/guiones/archivos-despliegue.sh"
DIRECTORIO_SALIDA="${1:-$RAIZ_PROYECTO/entregables/despliegue}"
NOMBRE_PAQUETE="app-candidato-productivo"
ARCHIVO_SQL="$DIRECTORIO_SALIDA/app-esquema.sql"
ARCHIVO_PAQUETE="$DIRECTORIO_SALIDA/$NOMBRE_PAQUETE.tar.gz"
ESCENA_TEMPORAL="$(mktemp -d "${TMPDIR:-/tmp}/app-despliegue.XXXXXX")"

limpia() {
  rm -rf "$ESCENA_TEMPORAL"
}
trap limpia EXIT

mkdir -p "$DIRECTORIO_SALIDA"
php "$RAIZ_PROYECTO/guiones/genera-sql-despliegue.php" "$ARCHIVO_SQL"

DESTINO="$ESCENA_TEMPORAL/app"
mkdir -p "$DESTINO/config" "$DESTINO/guiones" "$DESTINO/instalacion"

for directorio in "${DIRECTORIOS_CODIGO[@]}"; do
  cp -R "$RAIZ_PROYECTO/$directorio" "$DESTINO/"
done

mkdir -p "$DESTINO/esquema"
for esquema in "$RAIZ_PROYECTO"/esquema/[0-9][0-9][0-9]_*.sql; do
  cp "$esquema" "$DESTINO/esquema/"
done

cp "$RAIZ_PROYECTO/config/giro.php" "$DESTINO/config/"
cp "$RAIZ_PROYECTO/config/app.php.ejemplo" "$DESTINO/config/"
cp "$RAIZ_PROYECTO/config/bd.php.ejemplo" "$DESTINO/config/"
cp "$RAIZ_PROYECTO/config/seguridad.php.ejemplo" "$DESTINO/config/"
cp "$RAIZ_PROYECTO/config/respaldo.php.ejemplo" "$DESTINO/config/"
cp "$RAIZ_PROYECTO/config/alertas.php.ejemplo" "$DESTINO/config/"
# La plantilla de marca (D24); la marca real de una instalación nunca viaja.
cp "$RAIZ_PROYECTO/config/marca-visual.php.ejemplo" "$DESTINO/config/"

metadatos_app "$RAIZ_PROYECTO" "$DESTINO"
for guion in "${GUIONES_DESPLIEGUE[@]}"; do
  cp "$RAIZ_PROYECTO/guiones/$guion" "$DESTINO/guiones/"
done

mkdir -p \
  "$DESTINO/almacenamiento/registros" \
  "$DESTINO/almacenamiento/respaldos/cifrados" \
  "$DESTINO/almacenamiento/tareas" \
  "$DESTINO/almacenamiento/sesiones" \
  "$DESTINO/almacenamiento/alertas" \
  "$DESTINO/almacenamiento/imagenes/productos" \
  "$DESTINO/almacenamiento/marca"
touch \
  "$DESTINO/almacenamiento/registros/.gitkeep" \
  "$DESTINO/almacenamiento/respaldos/.gitkeep" \
  "$DESTINO/almacenamiento/respaldos/cifrados/.gitkeep" \
  "$DESTINO/almacenamiento/tareas/.gitkeep" \
  "$DESTINO/almacenamiento/sesiones/.gitkeep" \
  "$DESTINO/almacenamiento/alertas/.gitkeep" \
  "$DESTINO/almacenamiento/imagenes/productos/.gitkeep" \
  "$DESTINO/almacenamiento/marca/.gitkeep"

cp "$ARCHIVO_SQL" "$DESTINO/instalacion/"
cp "$ARCHIVO_SQL.sha256" "$DESTINO/instalacion/"
cp "$ARCHIVO_SQL.json" "$DESTINO/instalacion/"
cp "$RAIZ_PROYECTO/entregables/despliegue/INSTRUCCIONES-HOST.md" "$DESTINO/instalacion/"
php "$RAIZ_PROYECTO/guiones/genera-liberacion.php" "$DESTINO" "$DESTINO/config" "$DESTINO/instalacion"

(
  cd "$DESTINO"
  find . -type f ! -path './instalacion/MANIFIESTO-SHA256.txt' -print0 \
    | LC_ALL=C sort -z \
    | xargs -0 shasum -a 256 > instalacion/MANIFIESTO-SHA256.txt
)

rm -f "$ARCHIVO_PAQUETE" "$ARCHIVO_PAQUETE.sha256"
# Sin los metadatos extendidos de macOS (avisos LIBARCHIVE.xattr en Linux).
COPYFILE_DISABLE=1 tar --no-xattrs -C "$ESCENA_TEMPORAL" -czf "$ARCHIVO_PAQUETE" app
(
  cd "$DIRECTORIO_SALIDA"
  shasum -a 256 "$(basename "$ARCHIVO_PAQUETE")" > "$(basename "$ARCHIVO_PAQUETE").sha256"
)

printf 'Paquete generado: %s\n' "$ARCHIVO_PAQUETE"
printf 'Integridad: %s\n' "$ARCHIVO_PAQUETE.sha256"
printf 'Contenido: '
tar -tzf "$ARCHIVO_PAQUETE" | wc -l | tr -d ' '
printf ' archivos y directorios\n'
