<?php
declare(strict_types=1);

/**
 * Deja la base configurada con el esquema v2, vacía (fase 1 del plan v2).
 *
 *   APP_ENTORNO=pruebas php guiones/aplica-esquema.php --acepto=timon_pruebas
 *   php guiones/aplica-esquema.php --acepto=timon
 *   APP_ENTORNO=pruebas php guiones/aplica-esquema.php --acepto=timon_pruebas --hasta=021
 *
 * **Borra todas las tablas de la base** y aplica los guiones de `esquema/` en
 * orden. Por eso el cerrojo pide escribir el nombre de la base que se va a
 * borrar: un `--acepto` a secas se copia de la historia de la terminal sin
 * leerlo, y el nombre obliga a mirar contra qué se está corriendo.
 *
 * ⚠️ **Nunca en producción.** El esquema de un servidor con datos se cambia
 * con un guion nuevo, no borrando la base. El entorno `produccion` se rechaza
 * aunque se escriba el nombre.
 *
 * No siembra usuarios: el administrador se crea después con
 * `guiones/crear-usuario.php`, que pide la contraseña sin mostrarla.
 */

$raiz = dirname(__DIR__);

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);

// La regla de pruebas/ArquitecturaPrueba.php: todo punto de entrada fija el
// reloj del negocio.
Nucleo\Reloj::fijaLaZona($raiz);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

$entorno = Nucleo\Configuracion::entorno($raiz);
$config  = Nucleo\Configuracion::baseDatos($raiz);
$base    = (string) $config['base'];

if ($entorno === 'produccion') {
    fwrite(STDERR, "En producción el esquema se cambia con un guion nuevo, nunca borrando la base.\n");
    exit(1);
}

$acepto = '';
$hasta = null;
foreach (array_slice($argv, 1) as $bandera) {
    if (str_starts_with($bandera, '--acepto=')) {
        $acepto = substr($bandera, 9);
    } elseif (str_starts_with($bandera, '--hasta=')) {
        $valor = substr($bandera, 8);
        if (preg_match('/^\d{3}$/D', $valor) !== 1 || (int) $valor < 1) {
            fwrite(STDERR, "--hasta exige exactamente tres dígitos, por ejemplo --hasta=021\n");
            exit(2);
        }
        $hasta = (int) $valor;
    } else {
        fwrite(STDERR, "Argumento no reconocido: {$bandera}\n");
        exit(2);
    }
}

if ($acepto !== $base) {
    echo "Esto BORRA todas las tablas de «{$base}» (entorno {$entorno}) y aplica el esquema v2 vacío.\n";
    fwrite(STDERR, "Si es lo que quieres, agrega --acepto={$base}\n");
    exit(1);
}

$guiones = glob($raiz . '/esquema/*.sql') ?: [];
sort($guiones, SORT_STRING);
if ($hasta !== null) {
    $guiones = array_values(array_filter(
        $guiones,
        static fn (string $ruta): bool => (int) substr(basename($ruta), 0, 3) <= $hasta
    ));
}

if ($guiones === []) {
    fwrite(STDERR, "No hay guiones en esquema/.\n");
    exit(1);
}

$declaradas = array_fill_keys(Nucleo\MigracionesEsquema::tablasDeclaradas($guiones), true);

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conexion = new mysqli(
    (string) $config['host'],
    (string) $config['usuario'],
    (string) $config['clave'],
    $base,
    (int) $config['puerto']
);
$conexion->set_charset('utf8mb4');

// Se tira lo que haya, sea del esquema que sea. Las vistas también, por si un
// arreglo a mano dejó alguna.
$conexion->query('SET FOREIGN_KEY_CHECKS = 0');
$existentes = $conexion->query(
    "SELECT table_name AS t, table_type AS tipo FROM information_schema.tables WHERE table_schema = DATABASE()"
)->fetch_all(MYSQLI_ASSOC);

foreach ($existentes as $fila) {
    $nombre = (string) $fila['t'];
    if (preg_match('/^[A-Za-z0-9_]+$/', $nombre) !== 1) {
        throw new RuntimeException('Nombre de tabla inesperado en la base');
    }
    // El nombre sale de information_schema y se validó arriba: un DROP no
    // acepta el nombre como parámetro.
    $conexion->query(($fila['tipo'] === 'VIEW' ? 'DROP VIEW `' : 'DROP TABLE `') . $nombre . '`');
}
$conexion->query('SET FOREIGN_KEY_CHECKS = 1');
echo '  se tiraron ' . count($existentes) . " tablas\n";

foreach ($guiones as $guion) {
    $conexion->multi_query((string) file_get_contents($guion));
    do {
        if ($resultado = $conexion->store_result()) {
            $resultado->free();
        }
    } while ($conexion->more_results() && $conexion->next_result());

    echo '  aplicado ' . basename($guion) . "\n";
}

// Desde 022, una instalación limpia también deja el mismo libro que una base
// actualizada de forma incremental. El hash lo calcula PHP después de ejecutar
// el archivo: intentar escribir dentro de 022 su propia huella sería circular.
$tieneLibro = (int) $conexion->query(
    "SELECT COUNT(*) FROM information_schema.tables
     WHERE table_schema = DATABASE() AND table_name = 'migracion_esquema'"
)->fetch_row()[0] === 1;
if ($tieneLibro) {
    $registra = $conexion->prepare(
        'INSERT IGNORE INTO migracion_esquema(numero,nombre,sha256) VALUES(?,?,?)'
    );
    foreach (Nucleo\MigracionesEsquema::inventario($raiz . '/esquema') as $archivo) {
        // Con --hasta sólo se anota lo aplicado: si no, `migraciones.php`
        // creería al día una base a la que le faltan guiones.
        if ($hasta !== null && $archivo['numero'] > $hasta) {
            continue;
        }
        $numero = $archivo['numero'];
        $nombre = $archivo['nombre'];
        $sha256 = $archivo['sha256'];
        $registra->bind_param('iss', $numero, $nombre, $sha256);
        $registra->execute();
    }
    $registra->close();
}

$enLaBase = [];
foreach ($conexion->query(
    "SELECT table_name AS t FROM information_schema.tables WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'"
)->fetch_all(MYSQLI_ASSOC) as $fila) {
    $enLaBase[strtolower((string) $fila['t'])] = true;
}
$conexion->close();

$faltan = array_diff(array_keys($declaradas), array_keys($enLaBase));
$sobran = array_diff(array_keys($enLaBase), array_keys($declaradas));

if ($faltan !== [] || $sobran !== []) {
    fwrite(STDERR, 'El esquema quedó distinto de lo declarado. Faltan: ' . implode(', ', $faltan)
        . '. Sobran: ' . implode(', ', $sobran) . "\n");
    exit(1);
}

echo "Listo: «{$base}» tiene las " . count($declaradas) . " tablas del esquema v2"
    . ($hasta === null ? '' : ' hasta ' . sprintf('%03d', $hasta)) . " y ningún usuario.\n";
echo "Sigue: php guiones/crear-usuario.php para dar de alta al administrador.\n";
