import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';

const dist = new URL('../app/dist/', import.meta.url);
const index = new URL('index.html', dist);
const servicio = new URL('servicio.js', dist);
const original = readFileSync(index, 'utf8');
const marca = JSON.parse(readFileSync(new URL('manifest.webmanifest', dist), 'utf8'));
const manifiesto = `<link rel="manifest" href="/app/manifest.webmanifest" />
    <meta name="theme-color" content="${marca.theme_color}" />
    <link rel="apple-touch-icon" href="/app/icono-192.png" />`;
const html = original.replace(/<html\b[^>]*>/, '<html lang="es-MX">')
    .replace('</head>', `${manifiesto}\n</head>`);
const version = createHash('sha256').update(html).digest('hex').slice(0, 16);
writeFileSync(index, html);
writeFileSync(servicio, readFileSync(servicio, 'utf8').replace('timon-app-v1', 'timon-app-' + version));
