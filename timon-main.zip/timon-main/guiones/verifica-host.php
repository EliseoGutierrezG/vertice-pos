#!/usr/bin/env php
<?php

declare(strict_types=1);

/** Diagnóstico de sólo lectura para ejecutar por SSH antes de configurar El Timón. */

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este diagnóstico sólo se ejecuta desde consola.\n");
    exit(2);
}

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
// El diagnóstico debe poder correr antes de crear config/app.php.
Nucleo\Reloj::fijaLaZonaConNombre('America/Mexico_City');

$fallas = 0;
$avisos = 0;

comprueba(
    version_compare(PHP_VERSION, '8.2.0', '>='),
    "PHP " . PHP_VERSION . ' (mínimo 8.2)',
    true
);

foreach (['mysqli', 'mbstring', 'gd', 'curl', 'json', 'openssl', 'fileinfo', 'sodium', 'zlib'] as $extension) {
    comprueba(extension_loaded($extension), "extensión {$extension}", true);
}

comprueba(extension_loaded('exif'), 'extensión exif para orientar fotografías', false);

// La marca visual (2026-11-09, D24): sin `config/marca-visual.php` la instalación
// es El Timón. Un archivo presente pero inválido detiene aquí, con su motivo, en vez
// de descubrirse con la pantalla en los colores de la casa.
try {
    $entornoMarca = (string) (getenv('APP_ENTORNO') ?: 'produccion');
    $archivoMarca = 'config/marca-visual' . ($entornoMarca === 'pruebas' ? '.pruebas' : '') . '.php';
    $marcaVisual = Servicios\MarcaVisual::deInstalacion($raiz, $entornoMarca);
    $marcaVisual->valida();
    comprueba(true, 'marca visual: ' . $marcaVisual->vigente()['nombre'] . ($marcaVisual->personalizada() ? " ({$archivoMarca})" : ' (la de la casa)'), true);
} catch (InvalidArgumentException $e) {
    comprueba(false, $e->getMessage(), true);
}
comprueba((bool) ini_get('date.timezone'), 'date.timezone configurada en PHP', false);

echo PHP_EOL;
echo 'SAPI: ' . PHP_SAPI . PHP_EOL;
echo 'Sistema: ' . PHP_OS_FAMILY . ' ' . php_uname('r') . PHP_EOL;
echo 'memory_limit: ' . ini_get('memory_limit') . PHP_EOL;
echo 'upload_max_filesize: ' . ini_get('upload_max_filesize') . PHP_EOL;
echo 'post_max_size: ' . ini_get('post_max_size') . PHP_EOL;
echo 'max_execution_time: ' . ini_get('max_execution_time') . PHP_EOL;

if ($fallas > 0) {
    fwrite(STDERR, "\nHost NO apto: {$fallas} requisito(s) obligatorio(s) faltante(s).\n");
    exit(1);
}

echo "\nHost apto para continuar" . ($avisos > 0 ? " con {$avisos} aviso(s)." : '.') . PHP_EOL;

function comprueba(bool $condicion, string $descripcion, bool $obligatorio): void
{
    global $fallas, $avisos;
    if ($condicion) {
        echo "[OK] {$descripcion}\n";
        return;
    }

    if ($obligatorio) {
        $fallas++;
        echo "[FALTA] {$descripcion}\n";
        return;
    }

    $avisos++;
    echo "[AVISO] {$descripcion}\n";
}
