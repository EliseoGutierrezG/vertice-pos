<?php
declare(strict_types=1);

/**
 * Datos de demostración de El Timón: dos sucursales con tres semanas de
 * operación hasta el «ahora» de la simulación.
 *
 * Trae el menú con precios por sucursal, el plano, el personal con usuario y
 * PIN, impresoras, equipos, reservaciones, cuentas de mesa, para llevar y a
 * domicilio con sus rondas y tiempos de cocina, cobros, turnos y cortes de
 * caja, gastos, compras, recetas, consumo por PEPS, mermas y conteos. El día
 * en curso queda a medias: cuentas abiertas, cocina trabajando y turno abierto.
 *
 * Escribir el SQL para importarlo en otra base (staging, con phpMyAdmin o mysql):
 *
 *   /opt/homebrew/opt/php@8.3/bin/php guiones/demo.php --sql=entregables/demostracion/timon-demostracion.sql
 *
 * Cargarlo directo en la base configurada (pruebas, con APP_ENTORNO=pruebas):
 *
 *   /opt/homebrew/opt/php@8.3/bin/php guiones/demo.php --carga --acepto=timon
 *
 * Las dos opciones pueden ir juntas. La base debe tener el esquema completo,
 * **ninguna sucursal** ni operación, y sólo el administrador en el personal:
 * la demostración no se mezcla con datos de verdad. Nunca en producción.
 *
 * Opciones:
 *   --hasta="AAAA-MM-DD HH:MM"  El «ahora» de la simulación; por omisión, ahora. Generar
 *                               el SQL el mismo día en que se importa, para que «hoy» sea hoy.
 *   --semilla=N                 Con la misma semilla y la misma hora salen los mismos movimientos.
 *
 * La contraseña y el PIN de los usuarios de demostración se generan en cada
 * corrida y se guardan en `almacenamiento/credenciales-demostracion.txt`
 * (fuera de Git, permisos 0600). No se imprimen.
 */

$raiz = dirname(__DIR__);

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

require __DIR__ . '/demo/catalogo.php';
require __DIR__ . '/demo/opera.php';

$salida = null;
$carga = false;
$acepto = '';
$ahora = new DateTimeImmutable('now');
$semilla = 20261116;

foreach (array_slice($argv, 1) as $opcion) {
    if ($opcion === '--carga') {
        $carga = true;
    } elseif (str_starts_with($opcion, '--sql=')) {
        $salida = substr($opcion, 6);
    } elseif (str_starts_with($opcion, '--acepto=')) {
        $acepto = substr($opcion, 9);
    } elseif (str_starts_with($opcion, '--hasta=')) {
        $hasta = DateTimeImmutable::createFromFormat('!Y-m-d H:i', substr($opcion, 8));
        if ($hasta === false) {
            fwrite(STDERR, "--hasta va como \"AAAA-MM-DD HH:MM\".\n");
            exit(1);
        }
        $ahora = $hasta;
    } elseif (str_starts_with($opcion, '--semilla=') && ctype_digit(substr($opcion, 10))) {
        $semilla = (int) substr($opcion, 10);
    } else {
        fwrite(STDERR, "Opción desconocida: {$opcion}\n");
        exit(1);
    }
}

if ($salida === null && !$carga) {
    fwrite(STDERR, "Indique --sql=archivo.sql, --carga --acepto=<base> o las dos.\n");
    exit(1);
}

$bd = null;
if ($carga) {
    $config = Nucleo\Configuracion::baseDatos($raiz);
    if ($acepto !== (string) $config['base']) {
        fwrite(STDERR, "La demostración se carga en «{$config['base']}». Agregue --acepto={$config['base']}\n");
        exit(1);
    }
    $bd = new Nucleo\BaseDatos($config);
    $problema = DemoSql::verificaBase($bd, DEMO_PUESTOS, DEMO_PRIMER_ID);
    if ($problema !== null) {
        fwrite(STDERR, "No se cargó nada. {$problema}.\n");
        exit(1);
    }
}

// Las credenciales no salen de la semilla: cada corrida trae las suyas.
$alfabeto = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
$clave = '';
for ($i = 0; $i < 16; $i++) {
    $clave .= $alfabeto[random_int(0, strlen($alfabeto) - 1)];
}
$credenciales = ['clave' => $clave, 'pin' => (string) random_int(100000, 999999)];

$inicio = microtime(true);
$sql = new DemoSql();
$azar = new DemoAzar($semilla);
$catalogo = demo_catalogo($sql, $azar, $ahora, $credenciales);
$resumen = demo_opera($sql, $azar, $catalogo, $ahora);
$conteos = $sql->conteos();

if ($salida !== null) {
    $ruta = str_starts_with($salida, '/') ? $salida : getcwd() . '/' . $salida;
    if (!is_dir(dirname($ruta)) && !mkdir(dirname($ruta), 0700, true)) {
        fwrite(STDERR, "No se pudo crear la carpeta de {$ruta}\n");
        exit(1);
    }
    $archivo = fopen($ruta, 'wb');
    if ($archivo === false) {
        fwrite(STDERR, "No se pudo escribir {$ruta}\n");
        exit(1);
    }
    fwrite($archivo, "-- El Timón · datos de demostración (dos sucursales, tres semanas de operación)\n"
        . '-- Simulado hasta ' . $ahora->format('Y-m-d H:i') . ' · semilla ' . $semilla . ' · ' . array_sum($conteos) . " renglones\n"
        . "-- Requiere el esquema 001 a 013 y una base sin sucursales ni operación. Todo va en una\n"
        . "-- transacción: si algo choca, no queda nada a medias. Nunca en producción.\n"
        . "-- Contraseña y PIN de los usuarios: almacenamiento/credenciales-demostracion.txt de quien lo generó.\n\n"
        . "SET NAMES utf8mb4;\nSTART TRANSACTION;\n\n");
    foreach ($sql->sentencias() as $sentencia) {
        fwrite($archivo, $sentencia . ";\n\n");
    }
    fwrite($archivo, "-- Sin segundo factor: basta la contraseña. Se vuelve a encender en «Seguridad».\n");
    foreach (demo_sin_segundo_factor($ahora->format('Y-m-d')) as $sentencia) {
        fwrite($archivo, $sentencia . ";\n\n");
    }
    fwrite($archivo, "COMMIT;\n");
    fclose($archivo);
    chmod($ruta, 0600);
}

if ($bd !== null) {
    $app = Nucleo\Configuracion::aplicacion($raiz);
    $bitacora = new Nucleo\Bitacora(
        $bd,
        new Nucleo\Registro((string) $app['registros'], (bool) $app['depurar']),
        (new Nucleo\ContextoAuditoria())->comoGuion('demo')
    );
    $bd->transaccion(static function (Nucleo\BaseDatos $bd) use ($sql, $bitacora, $conteos, $ahora, $semilla): void {
        foreach ($sql->sentencias() as $sentencia) {
            $bd->ejecuta($sentencia);
        }
        $bitacora->registra('sistema', 'demostracion_cargada', despues: [
            'hasta' => $ahora->format('Y-m-d H:i'), 'semilla' => $semilla, 'renglones' => $conteos,
        ]);
        // Sin segundo factor, como en el SQL para phpMyAdmin.
        $desde = $ahora->format('Y-m-d');
        $antes = (new Modelos\Parametros($bd))->cambia(DEMO_SEGUNDO_FACTOR, '0', $desde);
        $bitacora->registra('parametros', 'cambia', 'parametro', null,
            ['clave' => DEMO_SEGUNDO_FACTOR, 'valor' => $antes],
            ['clave' => DEMO_SEGUNDO_FACTOR, 'valor' => '0', 'desde' => $desde]);
    });
}

$lineas = ["Usuarios de demostración de El Timón (" . $ahora->format('Y-m-d H:i') . ")",
    'Contraseña de todos: ' . $credenciales['clave'], 'PIN de todos en la app: ' . $credenciales['pin'], ''];
foreach ($catalogo['personal'] as $p) {
    $lineas[] = sprintf('%-20s %-10s %s · %s', $p['usuario'], $p['puesto'], $p['nombre'], $catalogo['sucursales'][$p['sucursal']]['nombre']);
}
$credencialesRuta = $raiz . '/almacenamiento/credenciales-demostracion.txt';
file_put_contents($credencialesRuta, implode("\n", $lineas) . "\n");
chmod($credencialesRuta, 0600);

printf("Demostración hasta %s, semilla %d (%.1f s)\n", $ahora->format('Y-m-d H:i'), $semilla, microtime(true) - $inicio);
foreach ($catalogo['sucursales'] as $id => $s) {
    printf("  %-18s %5d cuentas cobradas · $%s de venta\n", $s['nombre'], $resumen['cuentas'][$id] ?? 0,
        number_format(($resumen['ventas'][$id] ?? 0) / 100, 2));
}
printf("  Cuentas abiertas ahora: %d\n", $resumen['abiertas']);
foreach ($conteos as $tabla => $n) {
    printf("  %-22s %7d\n", $tabla, $n);
}
echo $salida !== null ? "SQL: {$salida}\n" : '';
echo $bd !== null ? "Cargado en la base {$acepto}.\n" : '';
echo "Credenciales: almacenamiento/credenciales-demostracion.txt\n";
exit(0);
