<?php
declare(strict_types=1);

/**
 * Crea `config/respaldo.php` con una llave nueva para cifrar los respaldos que
 * salen del hospedaje (fase 29). No imprime la llave: el dueño copia el archivo
 * a su gestor de contraseñas, y nunca se pega en un documento ni en un chat.
 *
 *   php guiones/genera-llave-respaldo.php            (producción o local)
 *   php guiones/genera-llave-respaldo.php --pruebas  (config/respaldo.pruebas.php)
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

$pruebas = in_array('--pruebas', $argv, true);
$destino = $raiz . '/config/respaldo' . ($pruebas ? '.pruebas' : '') . '.php';

// Sobrescribir la llave dejaría inservibles todos los respaldos cifrados que ya
// salieron del hospedaje.
if (is_file($destino)) {
    fwrite(STDERR, "Ya existe {$destino}; no se sobrescribió.\n");
    exit(2);
}

$contenido = "<?php\ndeclare(strict_types=1);\n\nreturn [\n    'llave' => '"
    . Nucleo\Seguridad\CifradorArchivo::generaLlave() . "',\n];\n";
$temporal = $destino . '.tmp-' . bin2hex(random_bytes(4));
if (file_put_contents($temporal, $contenido, LOCK_EX) === false || !chmod($temporal, 0600) || !rename($temporal, $destino)) {
    @unlink($temporal);
    fwrite(STDERR, "No se pudo crear {$destino}.\n");
    exit(1);
}

fwrite(STDOUT, "Llave creada con permisos 0600: {$destino}\n");
fwrite(STDOUT, "Guarde una copia de ese archivo fuera del hospedaje.\n");
