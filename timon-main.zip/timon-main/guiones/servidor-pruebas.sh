#!/usr/bin/env bash
# Servidor local aislado cuando macOS no deja a Apache leer ~/Downloads.
# Se mantiene en primer plano para que Ctrl-C lo detenga de forma limpia.

set -euo pipefail

RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
PHP83="/opt/homebrew/opt/php@8.3/bin/php"
DIRECCION="${PB_SERVIDOR:-127.0.0.1:8081}"

if [ ! -x "$PHP83" ]; then
  echo "No se encontró PHP 8.3 en $PHP83" >&2
  exit 1
fi

export APP_ENTORNO=pruebas

exec "$PHP83" \
  -d upload_max_filesize=10M \
  -d post_max_size=12M \
  -S "$DIRECCION" \
  -t "$RAIZ/publico" \
  "$RAIZ/pruebas/servidor-local.php"
