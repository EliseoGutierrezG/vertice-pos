#!/usr/bin/env php
<?php
declare(strict_types=1);

/**
 * Auditoría de sólo lectura del cierre operativo del hospedaje.
 *
 *   php guiones/verifica-cierre-host.php --perfil=demo
 *   php guiones/verifica-cierre-host.php --perfil=produccion
 *
 * No crea archivos, no inicia sesión y no cambia la base. Revisa lo que puede
 * probarse desde SSH: configuración, liberación, migraciones y tablas, últimas
 * tareas y la integridad de la copia cifrada más reciente. El correo recibido,
 * la copia externa y el horario configurado en hPanel siguen siendo evidencia
 * humana y se recuerdan al final.
 */

use Nucleo\Configuracion;
use Nucleo\MigracionesEsquema;
use Nucleo\Reloj;
use Nucleo\Seguridad\CifradorArchivo;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(2);
}

$perfil = '';
$maxHoras = 36;
foreach (array_slice($argv, 1) as $argumento) {
    if (str_starts_with($argumento, '--perfil=')) {
        $perfil = substr($argumento, strlen('--perfil='));
        continue;
    }
    if (str_starts_with($argumento, '--max-horas=')) {
        $valor = substr($argumento, strlen('--max-horas='));
        if (preg_match('/^[0-9]{1,3}$/', $valor) !== 1 || (int) $valor < 1) {
            fwrite(STDERR, "--max-horas debe ser un entero entre 1 y 999.\n");
            exit(2);
        }
        $maxHoras = (int) $valor;
        continue;
    }
    fwrite(STDERR, "Argumento no reconocido.\n");
    exit(2);
}

$perfiles = ['demo', 'produccion'];
if (getenv('APP_ENTORNO') === 'pruebas') {
    $perfiles[] = 'pruebas';
}
if (!in_array($perfil, $perfiles, true)) {
    fwrite(STDERR, "Indica --perfil=demo o --perfil=produccion.\n");
    exit(2);
}

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Reloj::fijaLaZona($raiz);

$verde = "\033[32m";
$rojo = "\033[31m";
$gris = "\033[90m";
$nada = "\033[0m";
$pasadas = 0;
$fallas = 0;

/** @param callable():bool $revision */
$comprueba = static function (string $descripcion, callable $revision) use (
    &$pasadas,
    &$fallas,
    $verde,
    $rojo,
    $nada
): bool {
    try {
        $correcto = $revision();
    } catch (Throwable) {
        $correcto = false;
    }
    if ($correcto) {
        echo "  {$verde}✓{$nada} {$descripcion}\n";
        $pasadas++;
        return true;
    }
    echo "  {$rojo}✗{$nada} {$descripcion}\n";
    $fallas++;
    return false;
};

echo "{$gris}Configuración privada{$nada}\n";
$sufijo = $perfil === 'pruebas' ? '.pruebas' : '';
$privados = [
    "config/app{$sufijo}.php",
    "config/bd{$sufijo}.php",
    "config/seguridad{$sufijo}.php",
    "config/respaldo{$sufijo}.php",
    "config/alertas{$sufijo}.php",
];
$comprueba('los cinco archivos privados existen y no dan permisos a grupo u otros', static function () use ($raiz, $privados): bool {
    foreach ($privados as $relativa) {
        $ruta = $raiz . '/' . $relativa;
        $modo = @fileperms($ruta);
        if (!is_file($ruta) || $modo === false || (($modo & 0777) & 0077) !== 0) {
            return false;
        }
    }
    return true;
});

$app = null;
$comprueba('la configuración de la aplicación carga sin revelar sus valores', static function () use ($raiz, &$app): bool {
    $app = Configuracion::aplicacion($raiz);
    return true;
});
$comprueba('el ambiente y la depuración son seguros para el hospedaje', static function () use (&$app, $perfil): bool {
    if (!is_array($app)) {
        return false;
    }
    if ($perfil === 'pruebas') {
        return ($app['entorno'] ?? null) === 'pruebas';
    }
    return ($app['entorno'] ?? null) === 'produccion' && ($app['depurar'] ?? null) === false;
});
$comprueba('la URL pública es absoluta y corresponde al ambiente', static function () use (&$app, $perfil): bool {
    $url = is_array($app) ? (string) ($app['url_publica'] ?? '') : '';
    if ($perfil === 'pruebas') {
        return str_starts_with($url, 'http://127.0.0.1:') || str_starts_with($url, 'http://localhost:');
    }
    $host = (string) parse_url($url, PHP_URL_HOST);
    return str_starts_with($url, 'https://')
        && $host !== ''
        && !str_contains($host, 'example')
        && !in_array($host, ['localhost', '127.0.0.1'], true)
        && !str_ends_with($url, '/');
});

$comprueba('la llave de segundo factor tiene 32 bytes', static function () use ($raiz): bool {
    $llave = Configuracion::seguridad($raiz)['llave_totp'];
    $binaria = base64_decode($llave, true);
    return is_string($binaria) && strlen($binaria) === 32;
});

$cifrador = null;
$comprueba('la llave de respaldo abre el cifrador sin mostrarla', static function () use ($raiz, &$cifrador): bool {
    $cifrador = new CifradorArchivo(Configuracion::llaveRespaldo($raiz));
    return true;
});

$alertas = null;
$comprueba('la configuración de alertas carga y tiene direcciones válidas', static function () use ($raiz, &$alertas): bool {
    $alertas = Configuracion::alertas($raiz);
    foreach (['correo', 'remitente'] as $campo) {
        $valor = (string) ($alertas[$campo] ?? '');
        if (filter_var($valor, FILTER_VALIDATE_EMAIL) === false || str_contains($valor, '.example')) {
            return false;
        }
    }
    return true;
});
$comprueba('el transporte de alertas corresponde al ambiente', static function () use (&$alertas, $perfil): bool {
    if (!is_array($alertas)) {
        return false;
    }
    return ($alertas['transporte'] ?? null) === ($perfil === 'pruebas' ? 'archivo' : 'mail');
});

echo "{$gris}Liberación y base{$nada}\n";
$liberacion = null;
$comprueba('el descriptor privado identifica una liberación real', static function () use ($raiz, &$liberacion, $perfil): bool {
    $liberacion = Configuracion::liberacion($raiz);
    return $perfil === 'pruebas'
        ? (int) ($liberacion['esquema'] ?? 0) > 0
        : ($liberacion['id'] ?? 'sin-identificar') !== 'sin-identificar'
            && (int) ($liberacion['esquema'] ?? 0) > 0;
});
$comprueba('LIBERACION.json coincide exactamente con la configuración', static function () use ($raiz, &$liberacion): bool {
    $ruta = $raiz . '/instalacion/LIBERACION.json';
    $json = is_file($ruta) ? json_decode((string) file_get_contents($ruta), true) : null;
    return is_array($liberacion) && is_array($json) && $liberacion === $json;
});

$inventario = null;
$comprueba('los guiones de esquema forman una secuencia íntegra', static function () use ($raiz, &$inventario): bool {
    $inventario = MigracionesEsquema::inventario($raiz . '/esquema');
    return $inventario !== [];
});
$comprueba('la liberación declara el último guion del paquete', static function () use (&$inventario, &$liberacion): bool {
    if (!is_array($inventario) || $inventario === [] || !is_array($liberacion)) {
        return false;
    }
    return (int) $liberacion['esquema'] === (int) array_key_last($inventario);
});

$conexion = null;
$comprueba('la base responde con las credenciales privadas', static function () use ($raiz, &$conexion): bool {
    $config = Configuracion::baseDatos($raiz);
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $conexion = new mysqli(
        (string) $config['host'],
        (string) $config['usuario'],
        (string) $config['clave'],
        (string) $config['base'],
        (int) $config['puerto']
    );
    $conexion->set_charset('utf8mb4');
    return (int) $conexion->query('SELECT 1')->fetch_row()[0] === 1;
});
$comprueba('todas las migraciones tienen nombre y huella intactos', static function () use (&$conexion, &$inventario): bool {
    if (!$conexion instanceof mysqli || !is_array($inventario)) {
        return false;
    }
    $aplicadas = $conexion->query(
        'SELECT numero,nombre,sha256 FROM migracion_esquema ORDER BY numero'
    )->fetch_all(MYSQLI_ASSOC);
    $estado = MigracionesEsquema::compara($inventario, $aplicadas);
    return $estado['errores'] === [] && $estado['pendientes'] === [];
});
$comprueba('la base contiene exactamente las tablas declaradas por el esquema', static function () use ($raiz, &$conexion): bool {
    if (!$conexion instanceof mysqli) {
        return false;
    }
    // Las tablas de trabajo que un guion crea y borra no cuentan.
    $esperadas = array_fill_keys(
        MigracionesEsquema::tablasDeclaradas(glob($raiz . '/esquema/[0-9][0-9][0-9]_*.sql') ?: []),
        true
    );
    $actuales = [];
    foreach ($conexion->query(
        "SELECT table_name FROM information_schema.tables
         WHERE table_schema=DATABASE() AND table_type='BASE TABLE'"
    )->fetch_all(MYSQLI_NUM) as $fila) {
        $actuales[(string) $fila[0]] = true;
    }
    ksort($esperadas);
    ksort($actuales);
    return $esperadas !== [] && array_keys($esperadas) === array_keys($actuales);
});

echo "{$gris}Almacenamiento y cron{$nada}\n";
$carpetas = [
    'almacenamiento',
    'almacenamiento/registros',
    'almacenamiento/respaldos',
    'almacenamiento/respaldos/cifrados',
    'almacenamiento/tareas',
    'almacenamiento/sesiones',
    'almacenamiento/alertas',
    'almacenamiento/imagenes/productos',
];
$comprueba('las carpetas persistentes existen y PHP puede escribirlas', static function () use ($raiz, $carpetas): bool {
    foreach ($carpetas as $relativa) {
        $ruta = $raiz . '/' . $relativa;
        if (!is_dir($ruta) || !is_writable($ruta)) {
            return false;
        }
    }
    return true;
});

$ahora = time();
$estadoReciente = static function (string $tarea) use ($raiz, $ahora, $maxHoras): bool {
    $ruta = $raiz . '/almacenamiento/tareas/' . $tarea . '.json';
    $estado = is_file($ruta) ? json_decode((string) file_get_contents($ruta), true) : null;
    if (!is_array($estado)
        || ($estado['tarea'] ?? null) !== $tarea
        || (int) ($estado['codigo'] ?? -1) !== 0
        || ($estado['avisos'] ?? null) !== []) {
        return false;
    }
    $marca = strtotime((string) ($estado['ultima_buena'] ?? ''));
    return $marca !== false && $marca <= $ahora + 300 && $marca >= $ahora - ($maxHoras * 3600);
};
$comprueba("el último respaldo terminó bien hace menos de {$maxHoras} horas", static fn (): bool => $estadoReciente('respaldo'));
$comprueba("el último mantenimiento terminó bien hace menos de {$maxHoras} horas", static fn (): bool => $estadoReciente('mantenimiento'));

$ultimoCifrado = null;
$comprueba('existe una copia cifrada reciente y no está vacía', static function () use ($raiz, $ahora, $maxHoras, &$ultimoCifrado): bool {
    $archivos = glob($raiz . '/almacenamiento/respaldos/cifrados/*.sgr') ?: [];
    usort($archivos, static fn (string $a, string $b): int => filemtime($b) <=> filemtime($a));
    $ultimoCifrado = $archivos[0] ?? null;
    if (!is_string($ultimoCifrado)) {
        return false;
    }
    $marca = filemtime($ultimoCifrado);
    return is_int($marca)
        && $marca >= $ahora - ($maxHoras * 3600)
        && filesize($ultimoCifrado) > strlen(CifradorArchivo::FIRMA) + 32;
});
$comprueba('la copia cifrada más reciente se autentica completa con su llave', static function () use (&$cifrador, &$ultimoCifrado): bool {
    if (!$cifrador instanceof CifradorArchivo || !is_string($ultimoCifrado)) {
        return false;
    }
    $huella = $cifrador->descifra($ultimoCifrado);
    return preg_match('/^[0-9a-f]{64}$/', $huella) === 1;
});

echo "{$gris}Retiro de transportes{$nada}\n";
$comprueba('no quedó la configuración temporal de la base desechable', static fn (): bool => !is_file($raiz . '/config/bd-desechable.php'));
$comprueba('el SQL y sus transportes ya no están en instalacion/', static function () use ($raiz, $perfil): bool {
    if ($perfil === 'pruebas') {
        return true;
    }
    return (glob($raiz . '/instalacion/app-esquema.sql*') ?: []) === [];
});
$comprueba('el subdominio no conserva paquetes ni cierres temporales públicos', static function () use ($raiz, $perfil): bool {
    if ($perfil === 'pruebas' || basename($raiz) !== '.app') {
        return true;
    }
    $publica = dirname($raiz);
    foreach (['app-*.tar.gz', 'app-*.tar.gz.sha256', 'app-bloqueo-instalacion.htaccess', '.htaccess-instalacion'] as $patron) {
        if ((glob($publica . '/' . $patron) ?: []) !== []) {
            return false;
        }
    }
    return true;
});

if ($conexion instanceof mysqli) {
    $conexion->close();
}

echo "\n{$gris}Evidencia que esta orden no puede fabricar{$nada}\n";
echo "  · confirmar en hPanel que las dos expresiones de cron están activas;\n";
echo "  · confirmar que el responsable recibió el aviso de prueba;\n";
echo "  · verificar fuera del hosting la copia .sgr y la llave resguardada.\n\n";

if ($fallas === 0) {
    echo "{$verde}{$pasadas} comprobaciones locales del host, todas pasan.{$nada}\n";
    exit(0);
}
echo "{$rojo}{$fallas} de " . ($pasadas + $fallas) . " comprobaciones fallan.{$nada}\n";
exit(1);
