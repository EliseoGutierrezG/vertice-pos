<?php
declare(strict_types=1);

/**
 * Consulta y cambia los parámetros del negocio desde la línea de comandos.
 *
 *   php guiones/parametro.php                                  los vigentes
 *   php guiones/parametro.php --clave=segundo_factor_web       el vigente y su historia
 *   php guiones/parametro.php --clave=segundo_factor_web --valor=0 [--desde=AAAA-MM-DD]
 *
 * La v2 no tiene pantalla de parámetros —el segundo factor sí tiene la suya,
 * «Seguridad»—, y cambiar uno a mano en phpMyAdmin pisa la historia: `parametro` guarda cada valor con su
 * vigencia, y lo viejo sigue explicando lo viejo. Aquí se cambia como lo hace
 * `Modelos\Parametros::cambia()`: se cierra el renglón vigente el día anterior
 * y se agrega el nuevo. Queda en la bitácora general.
 *
 * Reglas:
 *   - sólo claves que ya existen en el catálogo: una mal escrita no crea nada;
 *   - `--desde` es hoy o después, nunca antes: no se reescribe el pasado;
 *   - dos cambios el mismo día corrigen el renglón de ese día (la llave es
 *     clave + fecha), y la bitácora guarda los dos;
 *   - si ya hay un cambio programado para después, se rechaza: primero hay que
 *     decidir qué pasa con ese.
 *
 * El valor nuevo vale para la siguiente petición. Las sesiones ya abiertas no
 * se cierran: apagar el segundo factor no saca a nadie, y encenderlo se nota en
 * la siguiente entrada.
 */

$raiz = dirname(__DIR__);

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

use Modelos\Parametros;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\ContextoAuditoria;
use Nucleo\Registro;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

/** Valores que una clave admite, cuando no basta con «número si era número». */
const VALORES_ADMITIDOS = [
    'segundo_factor_web' => ['0', '1'],
];

$opciones = [];
foreach (array_slice($argv, 1) as $bandera) {
    if (preg_match('/^--(clave|valor|desde)=(.*)$/sD', $bandera, $m) !== 1) {
        fwrite(STDERR, "No reconozco «{$bandera}». Use --clave=, --valor= y --desde=.\n");
        exit(1);
    }
    $opciones[$m[1]] = trim($m[2]);
}

$bd = new BaseDatos(Nucleo\Configuracion::baseDatos($raiz));

$vigente = static fn (string $clave): ?array => $bd->fila(
    'SELECT clave, valor, descripcion, vigente_desde FROM parametro
     WHERE clave = ? AND vigente_desde <= CURDATE() AND (vigente_hasta IS NULL OR vigente_hasta >= CURDATE())
     ORDER BY vigente_desde DESC LIMIT 1',
    [$clave]
);

// --- sin clave: la lista ------------------------------------------------------
if (!isset($opciones['clave'])) {
    if (isset($opciones['valor']) || isset($opciones['desde'])) {
        fwrite(STDERR, "Falta --clave.\n");
        exit(1);
    }
    foreach ($bd->filas(
        'SELECT clave, valor, vigente_desde FROM parametro
         WHERE vigente_desde <= CURDATE() AND (vigente_hasta IS NULL OR vigente_hasta >= CURDATE())
         ORDER BY clave'
    ) as $fila) {
        printf("  %-34s %-12s desde %s\n", $fila['clave'], $fila['valor'], $fila['vigente_desde']);
    }
    exit(0);
}

$clave = $opciones['clave'];
if ((int) $bd->valor('SELECT COUNT(*) FROM parametro WHERE clave = ?', [$clave]) === 0) {
    fwrite(STDERR, "No existe el parámetro «{$clave}». Corra el guion sin argumentos para ver los que hay.\n");
    exit(1);
}

// --- sin valor: el vigente y su historia -------------------------------------
if (!isset($opciones['valor'])) {
    foreach ($bd->filas(
        'SELECT valor, vigente_desde, vigente_hasta, descripcion FROM parametro WHERE clave = ? ORDER BY vigente_desde',
        [$clave]
    ) as $fila) {
        printf(
            "  %s → %s  %s\n",
            $fila['vigente_desde'],
            $fila['vigente_hasta'] ?? 'hoy',
            $fila['valor']
        );
    }
    $actual = $vigente($clave);
    printf("\n%s\n", $actual['descripcion'] ?? '');
    exit(0);
}

// --- cambio --------------------------------------------------------------------
$valor = $opciones['valor'];
$hoy   = date('Y-m-d');
$desde = $opciones['desde'] ?? $hoy;

$fecha = DateTimeImmutable::createFromFormat('!Y-m-d', $desde);
if ($fecha === false || $fecha->format('Y-m-d') !== $desde) {
    fwrite(STDERR, "--desde debe ser una fecha AAAA-MM-DD.\n");
    exit(1);
}
if ($desde < $hoy) {
    fwrite(STDERR, "--desde no puede ser anterior a hoy: el pasado se explica con el valor que tenía.\n");
    exit(1);
}

$actual = $vigente($clave);
if (isset(VALORES_ADMITIDOS[$clave]) && !in_array($valor, VALORES_ADMITIDOS[$clave], true)) {
    fwrite(STDERR, "«{$clave}» sólo admite " . implode(' o ', VALORES_ADMITIDOS[$clave]) . ".\n");
    exit(1);
}
if ($actual !== null && is_numeric((string) $actual['valor']) && !is_numeric($valor)) {
    fwrite(STDERR, "«{$clave}» es un número y «{$valor}» no lo es.\n");
    exit(1);
}

$posterior = $bd->valor('SELECT MIN(vigente_desde) FROM parametro WHERE clave = ? AND vigente_desde > ?', [$clave, $desde]);
if ($posterior !== null) {
    fwrite(STDERR, "«{$clave}» ya tiene un cambio programado para el {$posterior}. Decida primero qué pasa con ese.\n");
    exit(1);
}

$app      = Nucleo\Configuracion::aplicacion($raiz);
$bitacora = new Bitacora(
    $bd,
    new Registro((string) $app['registros'], (bool) $app['depurar']),
    (new ContextoAuditoria())->comoGuion('cambia_parametro')
);

$antes = $bd->fila('SELECT valor, descripcion, vigente_desde FROM parametro WHERE clave = ? AND vigente_hasta IS NULL', [$clave]);
if ($antes !== null && (string) $antes['valor'] === $valor) {
    printf("«%s» ya vale %s. No se cambió nada.\n", $clave, $valor);
    exit(0);
}

// El cambio y su apunte van juntos: sin bitácora no hay cambio.
$bd->transaccion(static function () use ($bd, $bitacora, $clave, $valor, $desde, $antes): void {
    (new Parametros($bd))->cambia($clave, $valor, $desde);
    $bitacora->registra(
        'parametros', 'cambia', 'parametro', null,
        ['clave' => $clave, 'valor' => $antes['valor'] ?? null],
        ['clave' => $clave, 'valor' => $valor, 'desde' => $desde]
    );
});

printf("«%s» vale %s desde el %s (antes: %s).\n", $clave, $valor, $desde, $antes['valor'] ?? '—');

if ($clave === 'segundo_factor_web') {
    echo $valor === '0'
        ? "⚠️  Sin segundo factor, una contraseña robada basta para entrar como administrador o supervisor\n"
          . "    y para autorizar retiros de caja, devoluciones y descuentos. Las altas de Authenticator\n"
          . "    se conservan: al volver a 1, cada quien usa el código que ya tenía.\n"
        : "El código de Authenticator se vuelve a pedir en la siguiente entrada y en cada autorización.\n";
}
