<?php
declare(strict_types=1);

/**
 * Crea al primer administrador desde la línea de comandos.
 *
 *   /opt/homebrew/opt/php@8.3/bin/php guiones/crear-usuario.php
 *
 * Existe para el PRIMER usuario: sin él no hay con qué entrar, y la pantalla
 * de alta exige estar dentro. De ahí en adelante el personal y sus usuarios se
 * crean desde la web (fase 3), que además deja rastro en la bitácora.
 *
 * En la v2 no hay usuario sin personal (D12): el guion da de alta a la persona
 * con el puesto de administrador y después su usuario, en una transacción.
 *
 * La contraseña se teclea aquí y no se ve al escribirla: no viaja por
 * argumentos —que quedan en el historial del shell y en la lista de
 * procesos— ni se imprime nunca.
 */

$raiz = dirname(__DIR__);

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);

// En la línea de comandos PHP corre en UTC si nadie le dice otra cosa, y el
// cron del hospedaje es línea de comandos. Sin esto, este guion y la
// aplicación web tendrían horas distintas —seis, aquí— para el mismo
// instante. La regla está en `pruebas/ArquitecturaPrueba.php`.
Nucleo\Reloj::fijaLaZona($raiz);

use Modelos\Usuarios;
use Nucleo\BaseDatos;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

/** Pregunta y devuelve la respuesta. */
function pregunta(string $texto, bool $oculta = false): string
{
    echo $texto;

    // Por una tubería (`read -s` del shell, ver abajo) no hay nada que ocultar.
    if ($oculta && !stream_isatty(STDIN)) {
        $respuesta = trim((string) fgets(STDIN));
        echo "\n";

        return $respuesta;
    }

    if ($oculta) {
        // Hostinger deshabilita `shell_exec`. Sin él no hay forma de apagar el
        // eco: antes el guion moría aquí sin decir nada y lo que se tecleaba
        // después lo recibía el shell, que lo mostraba y lo dejaba en el
        // historial. Se detiene antes de leer y explica cómo darla oculta.
        if (!function_exists('shell_exec')) {
            fwrite(STDERR, "\n\nEste servidor no deja ocultar lo que se teclea, así que no se pide aquí.\n"
                . "Dé la contraseña con `read -s`, que no la muestra ni la guarda en el historial:\n\n"
                . "  read -rsp 'Contraseña: ' C; echo; read -rsp 'Repítala: ' C2; echo\n"
                . "  printf '%s\\n' 'NOMBRE' 'PATERNO' 'MATERNO' 'USUARIO' \"\$C\" \"\$C2\" | php " . $GLOBALS['argv'][0] . "; unset C C2\n\n");
            exit(1);
        }
        // Sin eco: lo tecleado no aparece en pantalla ni queda en el buffer.
        shell_exec('stty -echo');
        $respuesta = trim((string) fgets(STDIN));
        shell_exec('stty echo');
        echo "\n";

        return $respuesta;
    }

    return trim((string) fgets(STDIN));
}

$config   = Nucleo\Configuracion::baseDatos($raiz);
$bd       = new BaseDatos($config);
$usuarios = new Usuarios($bd);

echo "\nEl Timón · alta de usuario\n";
echo "────────────────────────────\n\n";

$puesto = (int) $bd->valor("SELECT id FROM puesto WHERE clave = 'administrador' AND id_estatus = 4");
if ($puesto === 0) {
    fwrite(STDERR, "No está el puesto de administrador. Aplique el esquema primero (guiones/aplica-esquema.php).\n");
    exit(1);
}

$nombre   = pregunta('Nombre(s): ');
$paterno  = pregunta('Apellido paterno: ');
$materno  = pregunta('Apellido materno (opcional): ');
$usuario  = pregunta('Usuario (para entrar): ');

if ($nombre === '' || $paterno === '' || $usuario === '') {
    fwrite(STDERR, "Hacen falta nombre, apellido paterno y usuario.\n");
    exit(1);
}

if ($usuarios->porUsuario($usuario) !== null) {
    fwrite(STDERR, "Ya existe un usuario con ese nombre de acceso.\n");
    exit(1);
}

$clave = pregunta('Contraseña (no se verá): ', oculta: true);
// La misma regla que la pantalla de cambio de contraseña.
if (($queja = Usuarios::quejaDeClave($clave, $usuario)) !== null) {
    fwrite(STDERR, 'La contraseña no sirve: ' . $queja . ".\n");
    exit(1);
}

$otraVez = pregunta('Repita la contraseña: ', oculta: true);
if (!hash_equals($clave, $otraVez)) {
    fwrite(STDERR, "Las dos contraseñas no coinciden.\n");
    exit(1);
}

$id = $bd->transaccion(function (BaseDatos $bd) use ($usuarios, $puesto, $nombre, $paterno, $materno, $usuario, $clave): int {
    // Sin sucursal: el administrador ve todas.
    $idPersonal = $bd->inserta(
        'INSERT INTO personal (nombre, apellido_paterno, apellido_materno, id_puesto, id_sucursal, fecha_ingreso)
         VALUES (?, ?, ?, ?, NULL, CURDATE())',
        [$nombre, $paterno, $materno === '' ? null : $materno, $puesto]
    );

    // La eligió quien la teclea: no nace temporal.
    return $usuarios->crea($idPersonal, $usuario, $clave, temporal: false);
});

// La contraseña no se repite aquí ni en ningún registro.
printf("\n✅ Administrador «%s» creado con el número %d.\n", $usuario, $id);
printf("   Entre en /entrar del sitio de este entorno.\n\n");
