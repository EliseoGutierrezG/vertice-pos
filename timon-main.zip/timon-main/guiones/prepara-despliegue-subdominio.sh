#!/usr/bin/env bash

set -euo pipefail

RAIZ_PROYECTO="$(cd "$(dirname "$0")/.." && pwd)"
. "$RAIZ_PROYECTO/guiones/archivos-despliegue.sh"
DIRECTORIO_SALIDA="${1:-$RAIZ_PROYECTO/entregables/despliegue}"
NOMBRE_PAQUETE="app-subdominio-candidato"
ARCHIVO_SQL="$DIRECTORIO_SALIDA/app-esquema.sql"
ARCHIVO_PAQUETE="$DIRECTORIO_SALIDA/$NOMBRE_PAQUETE.tar.gz"
ARCHIVO_BLOQUEO="$DIRECTORIO_SALIDA/app-bloqueo-instalacion.htaccess"
CARPETA_FTP="$DIRECTORIO_SALIDA/app-subdominio-ftp"
CARPETA_FTP_TEMP="$DIRECTORIO_SALIDA/.app-subdominio-ftp.$$"
ESCENA_TEMPORAL="$(mktemp -d "${TMPDIR:-/tmp}/app-subdominio.XXXXXX")"

limpia() {
  rm -rf "$ESCENA_TEMPORAL"
}
trap limpia EXIT

mkdir -p "$DIRECTORIO_SALIDA"
php "$RAIZ_PROYECTO/guiones/genera-sql-despliegue.php" "$ARCHIVO_SQL"

DESTINO="$ESCENA_TEMPORAL/timon"
PRIVADO="$DESTINO/.app"
mkdir -p "$DESTINO" "$PRIVADO/config" "$PRIVADO/guiones" \
  "$PRIVADO/publico" "$PRIVADO/instalacion" "$PRIVADO/esquema"

for directorio in "${DIRECTORIOS_CODIGO[@]}"; do
  [ "$directorio" = publico ] && continue
  cp -R "$RAIZ_PROYECTO/$directorio" "$PRIVADO/"
done

for esquema in "$RAIZ_PROYECTO"/esquema/[0-9][0-9][0-9]_*.sql; do
  cp "$esquema" "$PRIVADO/esquema/"
done

cp "$RAIZ_PROYECTO/config/giro.php" "$PRIVADO/config/"
cp "$RAIZ_PROYECTO/config/app.php.ejemplo" "$PRIVADO/config/"
cp "$RAIZ_PROYECTO/config/bd.php.ejemplo" "$PRIVADO/config/"
cp "$RAIZ_PROYECTO/config/seguridad.php.ejemplo" "$PRIVADO/config/"
cp "$RAIZ_PROYECTO/config/respaldo.php.ejemplo" "$PRIVADO/config/"
cp "$RAIZ_PROYECTO/config/alertas.php.ejemplo" "$PRIVADO/config/"
# La plantilla de marca (D24). La marca real de una instalación
# (`config/marca-visual.php`) es de esa instalación y nunca viaja.
cp "$RAIZ_PROYECTO/config/marca-visual.php.ejemplo" "$PRIVADO/config/"
cp "$RAIZ_PROYECTO/publico/index.php" "$PRIVADO/publico/"

metadatos_app "$RAIZ_PROYECTO" "$PRIVADO"
for guion in "${GUIONES_DESPLIEGUE[@]}"; do
  cp "$RAIZ_PROYECTO/guiones/$guion" "$PRIVADO/guiones/"
done

mkdir -p \
  "$PRIVADO/almacenamiento/registros" \
  "$PRIVADO/almacenamiento/respaldos/cifrados" \
  "$PRIVADO/almacenamiento/tareas" \
  "$PRIVADO/almacenamiento/sesiones" \
  "$PRIVADO/almacenamiento/alertas" \
  "$PRIVADO/almacenamiento/imagenes/productos" \
  "$PRIVADO/almacenamiento/marca"
touch \
  "$PRIVADO/almacenamiento/registros/.gitkeep" \
  "$PRIVADO/almacenamiento/respaldos/.gitkeep" \
  "$PRIVADO/almacenamiento/respaldos/cifrados/.gitkeep" \
  "$PRIVADO/almacenamiento/tareas/.gitkeep" \
  "$PRIVADO/almacenamiento/sesiones/.gitkeep" \
  "$PRIVADO/almacenamiento/alertas/.gitkeep" \
  "$PRIVADO/almacenamiento/imagenes/productos/.gitkeep" \
  "$PRIVADO/almacenamiento/marca/.gitkeep"

cp "$RAIZ_PROYECTO/despliegue/subdominio/index.php" "$DESTINO/index.php"
cp "$RAIZ_PROYECTO/despliegue/subdominio/privado.htaccess" "$PRIVADO/.htaccess"
cp "$RAIZ_PROYECTO/publico/.user.ini" "$DESTINO/.user.ini"
cp -R "$RAIZ_PROYECTO/publico/recursos" "$DESTINO/"

# La landing pública (fase 11) va en `sitio/`, con su propio `.htaccess` (CSP
# sin guiones). Lo que es del repositorio —el README y los originales de las
# fotos— no viaja. Mientras no exista, la raíz abre directo en el panel.
if php -r '$g = require $argv[1]; exit(($g["restaurante"] && $g["sitio_publico"]) ? 0 : 1);' "$RAIZ_PROYECTO/config/giro.php" && [ -d "$RAIZ_PROYECTO/landing" ]; then
  mkdir -p "$DESTINO/sitio/img"
  cp "$RAIZ_PROYECTO/landing/index.html" "$RAIZ_PROYECTO/landing/estilo.css" \
    "$RAIZ_PROYECTO/landing/.htaccess" "$DESTINO/sitio/"
  # Buscadores y redes piden direcciones absolutas en `canonical`, Open Graph y
  # JSON-LD. Con URL_PUBLICA=https://dominio se completan; sin ella quedan
  # relativas, que también funcionan en el navegador.
  if [ -n "${URL_PUBLICA:-}" ]; then
    URL_PUBLICA="${URL_PUBLICA%/}" perl -pi -e 's#(rel="canonical" href=")/#$1$ENV{URL_PUBLICA}/#; s#(property="og:(?:url|image)" content=")/#$1$ENV{URL_PUBLICA}/#; s#("(?:image|url|hasMenu)": ")/#$1$ENV{URL_PUBLICA}/#' "$DESTINO/sitio/index.html"
  fi
  [ -d "$RAIZ_PROYECTO/landing/img" ] && cp -R "$RAIZ_PROYECTO/landing/img/." "$DESTINO/sitio/img/"
  rm -rf "$DESTINO/sitio/img/fotografias/originales"
  # Las fuentes locales viajan con su licencia OFL.
  [ -d "$RAIZ_PROYECTO/landing/fuentes" ] && cp -R "$RAIZ_PROYECTO/landing/fuentes" "$DESTINO/sitio/"
fi

if php -r '$g = require $argv[1]; exit($g["restaurante"] ? 0 : 1);' "$RAIZ_PROYECTO/config/giro.php" && [ -f "$RAIZ_PROYECTO/app/dist/index.html" ]; then
  mkdir -p "$DESTINO/app"
  cp -R "$RAIZ_PROYECTO/app/dist/." "$DESTINO/app/"
  cat > "$DESTINO/app/.htaccess" <<'APACHE'
Options -Indexes
DirectoryIndex index.html
<IfModule mod_mime.c>
    AddType application/manifest+json .webmanifest
</IfModule>
<IfModule mod_headers.c>
    <Files "servicio.js">
        Header always set Cache-Control "no-cache"
    </Files>
    Header always set Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; worker-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
</IfModule>
APACHE
fi

# Reutiliza la regla pública canónica y agrega el cerrojo antes de la regla que
# permite servir archivos existentes. El resultado se activa al final con un
# rename atómico a `.htaccess`.
awk '
  { print }
  !insertado && /^[[:space:]]*RewriteEngine On[[:space:]]*$/ {
    print ""
    print "    # Hosting de raíz única: el código y los artefactos nunca son públicos."
    print "    RewriteRule ^\\.app(?:/|$) - [F,L,NC]"
    print "    RewriteRule ^app-.*\\.(?:tar\\.gz|sha256|htaccess)$ - [F,L,NC]"
    insertado = 1
  }
  END { if (!insertado) exit 42 }
' "$RAIZ_PROYECTO/publico/.htaccess" > "$DESTINO/.htaccess.app"

cat >> "$DESTINO/.htaccess.app" <<'EOF'

# Defensa adicional si alguna regla de reescritura deja de estar disponible.
<FilesMatch "^app-.*\.(tar\.gz|sha256|htaccess)$">
    Require all denied
</FilesMatch>
EOF

cp "$ARCHIVO_SQL" "$PRIVADO/instalacion/"
cp "$ARCHIVO_SQL.sha256" "$PRIVADO/instalacion/"
cp "$ARCHIVO_SQL.json" "$PRIVADO/instalacion/"
cp "$RAIZ_PROYECTO/entregables/despliegue/INSTRUCCIONES-SUBDOMINIO.md" "$PRIVADO/instalacion/"
# Los metadatos de carpeta de macOS (`.DS_Store`) no viajan: delatan nombres de
# archivos y no sirven en el servidor.
find "$DESTINO" -name '.DS_Store' -type f -delete
php "$RAIZ_PROYECTO/guiones/genera-liberacion.php" "$DESTINO" "$PRIVADO/config" "$PRIVADO/instalacion"

(
  cd "$DESTINO"
  find . -type f ! -path './.app/instalacion/MANIFIESTO-SHA256.txt' -print0 \
    | LC_ALL=C sort -z \
    | xargs -0 shasum -a 256 > .app/instalacion/MANIFIESTO-SHA256.txt
)

rm -f "$ARCHIVO_PAQUETE" "$ARCHIVO_PAQUETE.sha256"
# Sin los metadatos extendidos de macOS: en Linux `tar` los anuncia como
# avisos LIBARCHIVE.xattr al extraer (bitácora 104).
COPYFILE_DISABLE=1 tar --no-xattrs -C "$DESTINO" -czf "$ARCHIVO_PAQUETE" .
(
  cd "$DIRECTORIO_SALIDA"
  shasum -a 256 "$(basename "$ARCHIVO_PAQUETE")" > "$(basename "$ARCHIVO_PAQUETE").sha256"
)

cp "$RAIZ_PROYECTO/despliegue/subdominio/bloqueo-instalacion.htaccess" "$ARCHIVO_BLOQUEO"

# La carpeta es el entregable principal para quien sube archivo por archivo en
# FTP. Se arma completa a un lado y sólo entonces reemplaza la copia anterior,
# para que una interrupción nunca deje un árbol a medias.
rm -rf "$CARPETA_FTP_TEMP"
cp -R "$DESTINO" "$CARPETA_FTP_TEMP"
cp "$ARCHIVO_BLOQUEO" "$CARPETA_FTP_TEMP/app-bloqueo-instalacion.htaccess"
rm -rf "$CARPETA_FTP"
mv "$CARPETA_FTP_TEMP" "$CARPETA_FTP"

printf 'Carpeta para FTP individual: %s\n' "$CARPETA_FTP"
printf 'Paquete para subdominio generado: %s\n' "$ARCHIVO_PAQUETE"
printf 'Integridad: %s\n' "$ARCHIVO_PAQUETE.sha256"
printf 'Bloqueo temporal: %s\n' "$ARCHIVO_BLOQUEO"
printf 'Contenido: '
tar -tzf "$ARCHIVO_PAQUETE" | wc -l | tr -d ' '
printf ' archivos y directorios\n'
