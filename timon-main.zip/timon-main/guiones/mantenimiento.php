<?php
declare(strict_types=1);

/**
 * La limpieza de lo que se acumula en la base.
 *
 *   /opt/homebrew/opt/php@8.3/bin/php guiones/mantenimiento.php
 *   php guiones/mantenimiento.php --ensayo        dice qué borraría, sin borrar
 *   php guiones/mantenimiento.php --tanda=20000   borra de 20 mil en 20 mil
 *
 * Va con el respaldo, en el mismo cron y **después** de él: si algo de esto
 * borrara más de lo que debe, la copia de esta mañana ya está escrita.
 *
 * Qué se tira: los tokens muertos (treinta días después de expirar o de
 * revocarse), los intentos de acceso vencidos y los envíos del panel ya
 * contestados. También anonimiza al ex personal pasado el plazo de
 * `dias_anonimizar_ex_personal` y bloquea los accesos temporales vencidos.
 *
 * Qué **no** se tira, a propósito: `operacion_sincronizada` (borrar una llave
 * es abrirle la puerta a que una subida vieja se aplique de nuevo) y la
 * `bitacora`, que es el rastro de quién hizo qué.
 *
 * Cada fase del giro agrega aquí su propia limpieza (por ejemplo, el cierre
 * mensual del kardex cuando llegue el inventario).
 *
 * Se borra **en tandas y sin transacción larga**. La primera corrida contra una
 * base con años encima podría tener que tirar cientos de miles de renglones, y
 * un solo DELETE de ese tamaño tiene al resto esperando.
 */

$raiz = dirname(__DIR__);

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);

// En la línea de comandos PHP corre en UTC si nadie le dice otra cosa, y el
// cron del hospedaje es línea de comandos. El corte por antigüedad lo calcula
// el motor, pero lo que este guion imprime lleva la hora del negocio.
Nucleo\Reloj::fijaLaZona($raiz);

use Modelos\Parametros;
use Modelos\IntentosAcceso;
use Modelos\Tokens;
use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\ContextoAuditoria;
use Nucleo\Registro;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

$banderas = array_slice($argv, 1);
$ensayo   = in_array('--ensayo', $banderas, true);
$tanda    = 5000;

foreach ($banderas as $bandera) {
    if (str_starts_with($bandera, '--tanda=')) {
        $tanda = max(100, (int) substr($bandera, 8));
    }
}

$bd         = new BaseDatos(Nucleo\Configuracion::baseDatos($raiz));
$parametros = new Parametros($bd);
$app        = Nucleo\Configuracion::aplicacion($raiz);
$contexto   = (new ContextoAuditoria())->comoTarea('mantenimiento_diario');
$bitacora   = new Bitacora(
    $bd,
    new Registro((string) $app['registros'], (bool) $app['depurar']),
    $contexto
);

$arranque = microtime(true);
printf("Mantenimiento · %s\n", date('Y-m-d H:i'));

/**
 * Borra en tandas hasta que no quede nada que borrar.
 *
 * Sin transacción que abarque todo: cada tanda se confirma sola, así que una
 * interrupción deja el trabajo a medias pero nunca inconsistente —lo que se
 * borra son renglones que ya nadie mira—.
 */
$borraEnTandas = static function (string $sql, array $valores, int $tanda) use ($bd): int {
    $total = 0;

    do {
        $idos   = $bd->ejecuta($sql . ' LIMIT ' . $tanda, $valores);
        $total += $idos;
    } while ($idos === $tanda);

    return $total;
};

/**
 * Cada purga que borra algo deja un apunte con cuánto borró y con qué criterio (fase 33). La
 * bitácora falla en cerrado: si no se puede escribir, la tarea termina con
 * error y el cron avisa.
 */
$apuntaPurga = static function (string $tabla, int $borrados, array $criterio) use ($bitacora): void {
    if ($borrados === 0) return;
    $bitacora->registra('mantenimiento', 'purga', $tabla, null, null, ['borrados' => $borrados] + $criterio);
};

// --- ex empleados ----------------------------------------------------------
// El parámetro nace en 0 (055): anonimizar no tiene vuelta atrás, y el plazo lo
// decide el negocio. Una falla no detiene el resto de la limpieza.
$diasEx = $parametros->entero('dias_anonimizar_ex_personal', 0);
if ($diasEx < 1) {
    echo "  ex empleados:      dias_anonimizar_ex_personal vale $diasEx, no se anonimiza nadie\n";
} else {
    $corteEx = date('Y-m-d', strtotime('-' . $diasEx . ' day'));
    $idsEx = $bd->filas(
        'SELECT id FROM personal WHERE id_estatus <> 4 AND anonimizado_en IS NULL AND fecha_baja IS NOT NULL AND fecha_baja < ? LIMIT ' . $tanda,
        [$corteEx]
    );
    if ($ensayo) {
        printf("  ex empleados:      %s de baja antes de %s (no se anonimizan, es un ensayo)\n", number_format(count($idsEx)), $corteEx);
    } else {
        $derechos = new Servicios\DerechosTitular(
            $bd,
            $bitacora,
            $parametros
        );
        foreach ($idsEx as $ex) {
            $derechos->anonimizaEmpleado((int) $ex['id'], null, null);
        }
        printf("  ex empleados:      %s anonimizados\n", number_format(count($idsEx)));
    }
}

// --- los tokens que ya no abren nada ---------------------------------------
if ($ensayo) {
    $muertos = (int) $bd->valor(
        'SELECT COUNT(*) FROM token_acceso
         WHERE expira_en < DATE_SUB(NOW(), INTERVAL 30 DAY)
            OR revocado_en < DATE_SUB(NOW(), INTERVAL 30 DAY)'
    );
    printf("  token_acceso:      %s muertos hace más de 30 días (no se borran, es un ensayo)\n", number_format($muertos));
} else {
    $idos = (new Tokens($bd))->purga();
    $apuntaPurga('token_acceso', $idos, ['muertos_hace_dias' => 30]);
    printf("  token_acceso:      %s muertos hace más de 30 días, borrados\n", number_format($idos));
}

// --- contadores de acceso vencidos -----------------------------------------
if ($ensayo) {
    $viejos = (int) $bd->valor(
        'SELECT COUNT(*) FROM intento_acceso WHERE actualizado_en < DATE_SUB(NOW(), INTERVAL 30 DAY)'
    );
    printf("  intento_acceso:    %s vencidos (no se borran, es un ensayo)\n", number_format($viejos));
} else {
    $idos = (new IntentosAcceso($bd))->purga();
    $apuntaPurga('intento_acceso', $idos, ['vencidos_hace_dias' => 30]);
    printf("  intento_acceso:    %s vencidos, borrados\n", number_format($idos));
}

// --- llaves de envío del panel ----------------------------------------------
// `envio_panel` (062): conservar también las reservas inciertas durante 30 días.
if ($ensayo) {
    $viejas = (int) $bd->valor(
        "SELECT COUNT(*) FROM envio_panel
         WHERE creada_en < DATE_SUB(NOW(), INTERVAL 30 DAY)"
    );
    printf("  envio_panel:       %s vencidas (no se borran, es un ensayo)\n", number_format($viejas));
} else {
    $idos = $borraEnTandas(
        "DELETE FROM envio_panel
         WHERE creada_en < DATE_SUB(NOW(), INTERVAL 30 DAY)",
        [],
        $tanda
    );
    $apuntaPurga('envio_panel', $idos, ['vencidas_hace_dias' => 30]);
    printf("  envio_panel:       %s vencidas, borradas\n", number_format($idos));
}

// --- el sello de la bitácora -----------------------------------------------
// Primero se verifica lo ya sellado y después se sella lo nuevo: sellar encima de
// una alteración la haría pasar por buena. Una falla hace que esta tarea salga con
// error, y `guiones/tarea.php` manda el aviso operativo.
$fallaSeguridad = [];
if (Nucleo\Instalacion::de($raiz)->esSucursal()) {
    // Aquí la bitácora solo espera a subir: el central la renumera y la sella.
    printf("  bitácora:          no se sella en la sucursal; la sella el central\n");
} else try {
    $sello = new Servicios\SelloBitacora($bd, Nucleo\Configuracion::llaveSello($raiz));
    $alteraciones = $sello->verifica();
    if ($alteraciones !== []) {
        $fallaSeguridad = $alteraciones;
        printf("  bitácora:          ⚠️ no cuadra con sus sellos; no se sella\n");
    } elseif ($ensayo) {
        printf("  bitácora:          íntegra (no se sella, es un ensayo)\n");
    } else {
        printf("  bitácora:          íntegra; %s renglones sellados\n", number_format($sello->sella()));
    }
} catch (RuntimeException $e) {
    $fallaSeguridad[] = $e->getMessage();
    printf("  bitácora:          ⚠️ sin sello: %s\n", $e->getMessage());
}

// --- accesos de soporte vencidos ---------------------------------------------
// La entrada ya los rechaza; esto además les revoca el token y los deja inactivos.
if ($ensayo) {
    printf("  accesos vencidos:  %s (no se cierran, es un ensayo)\n", number_format((int) $bd->valor(
        'SELECT COUNT(*) FROM usuario WHERE acceso_hasta <= NOW() AND id_estatus = 4'
    )));
} else {
    $vencidos = $bd->filas('SELECT id, usuario FROM usuario WHERE acceso_hasta <= NOW() AND id_estatus = 4');
    foreach ($vencidos as $cuenta) {
        $bd->transaccion(static function (BaseDatos $bd) use ($cuenta, $bitacora): void {
            $id = (int) $cuenta['id'];
            $bd->ejecuta('UPDATE usuario SET id_estatus = 3, sesion_version = sesion_version + 1 WHERE id = ?', [$id]);
            $bd->ejecuta('UPDATE token_acceso SET revocado_en = NOW() WHERE id_usuario = ? AND revocado_en IS NULL', [$id]);
            $bitacora->registra('seguridad', 'acceso_vencido', 'usuario', $id, despues: ['usuario' => $cuenta['usuario']]);
        });
    }
    printf("  accesos vencidos:  %s cerrados\n", number_format(count($vencidos)));
}

// --- intentos de acceso fuera de lo normal -----------------------------------
$tope = $parametros->entero('alerta_bloqueos_dia', 20);
$bloqueos = (int) $bd->valor(
    'SELECT COUNT(*) FROM intento_acceso WHERE bloqueado_hasta IS NOT NULL AND actualizado_en >= DATE_SUB(NOW(), INTERVAL 1 DAY)'
);
printf("  bloqueos de acceso: %s en 24 horas\n", number_format($bloqueos));
if ($tope > 0 && $bloqueos >= $tope) {
    $fallaSeguridad[] = "Hubo $bloqueos bloqueos de acceso en 24 horas (el aviso salta en $tope): revise si es un ataque.";
}

printf("Listo en %.1f s.\n", microtime(true) - $arranque);

if ($fallaSeguridad !== []) {
    fwrite(STDERR, "Revisión de seguridad:\n  - " . implode("\n  - ", $fallaSeguridad) . "\n");
    exit(1);
}

