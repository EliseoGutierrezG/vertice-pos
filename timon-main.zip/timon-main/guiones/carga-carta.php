<?php
declare(strict_types=1);

/**
 * Carga la carta de El Timón (la del PDF del dueño, en
 * `pruebas/fixtures/carta-el-timon.php`) en una sucursal.
 *
 *   /opt/homebrew/opt/php@8.3/bin/php guiones/carga-carta.php --sucursal=CEN
 *   /opt/homebrew/opt/php@8.3/bin/php guiones/carga-carta.php --sucursal=CEN --aplicar
 *
 * Sin `--aplicar` solo dice lo que haría. Con `--aplicar` lo hace en una
 * transacción y deja un apunte en la bitácora.
 *
 * **Solo agrega lo que falta y nunca borra ni cambia precios:**
 * - Una categoría que ya existe (mismo nombre) se queda como está; si no
 *   tenía leyenda, recibe la del PDF.
 * - Un platillo se busca por nombre dentro de su categoría. Si existe y no
 *   tenía porción, recibe la del PDF.
 * - El precio de la sucursal se agrega solo si el platillo no tenía uno.
 * - Las preparaciones se agregan solo si faltan.
 *
 * En staging o producción se corre solo cuando el dueño lo pida.
 */

$raiz = dirname(__DIR__);

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

use Nucleo\BaseDatos;
use Nucleo\Bitacora;
use Nucleo\ContextoAuditoria;
use Nucleo\Registro;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion solo corre en la línea de comandos.\n");
    exit(1);
}

$clave = null;
$aplicar = false;
foreach (array_slice($argv, 1) as $bandera) {
    if (preg_match('/^--sucursal=([A-Za-z0-9]+)$/D', $bandera, $m) === 1) {
        $clave = $m[1];
    } elseif ($bandera === '--aplicar') {
        $aplicar = true;
    } else {
        fwrite(STDERR, "No reconozco «{$bandera}». Use --sucursal=<clave> y, para escribir, --aplicar.\n");
        exit(1);
    }
}
if ($clave === null) {
    fwrite(STDERR, "Falta --sucursal=<clave>.\n");
    exit(1);
}

$bd = new BaseDatos(Nucleo\Configuracion::baseDatos($raiz));
$sucursal = $bd->fila('SELECT id, nombre FROM sucursal WHERE clave = ?', [$clave]);
if ($sucursal === null) {
    fwrite(STDERR, "No existe la sucursal con clave «{$clave}».\n");
    exit(1);
}
$idSucursal = (int) $sucursal['id'];
$carta = require $raiz . '/pruebas/fixtures/carta-el-timon.php';

/** Lo que se hizo (o se haría), para el resumen y la bitácora. */
$cuenta = ['categorias' => 0, 'leyendas' => 0, 'platillos' => 0, 'porciones' => 0, 'precios' => 0, 'preparaciones' => 0, 'ya_tenian_precio' => 0];

$carga = static function () use ($bd, $carta, $idSucursal, $aplicar, &$cuenta): void {
    foreach ($carta as [$categoria, $orden, $leyenda, $platillos]) {
        $fila = $bd->fila('SELECT id, descripcion FROM categoria_menu WHERE nombre = ?', [$categoria]);
        if ($fila === null) {
            $cuenta['categorias']++;
            $idCategoria = $aplicar
                ? $bd->inserta('INSERT INTO categoria_menu (nombre, orden, descripcion) VALUES (?, ?, ?)', [$categoria, $orden, $leyenda])
                : 0;
        } else {
            $idCategoria = (int) $fila['id'];
            if ($fila['descripcion'] === '' && $leyenda !== '') {
                $cuenta['leyendas']++;
                if ($aplicar) {
                    $bd->ejecuta('UPDATE categoria_menu SET descripcion = ? WHERE id = ?', [$leyenda, $idCategoria]);
                }
            }
        }

        foreach ($platillos as $posicion => [$nombre, $porcion, $precio, $area, $preparaciones]) {
            $platillo = $idCategoria === 0 ? null
                : $bd->fila('SELECT id, porcion FROM platillo WHERE id_categoria = ? AND nombre = ?', [$idCategoria, $nombre]);
            if ($platillo === null) {
                $cuenta['platillos']++;
                $idPlatillo = $aplicar
                    ? $bd->inserta('INSERT INTO platillo (id_categoria, nombre, porcion, orden, preparacion) VALUES (?, ?, ?, ?, ?)',
                        [$idCategoria, $nombre, $porcion, ($posicion + 1) * 10, $area])
                    : 0;
            } else {
                $idPlatillo = (int) $platillo['id'];
                if ($platillo['porcion'] === '' && $porcion !== '') {
                    $cuenta['porciones']++;
                    if ($aplicar) {
                        $bd->ejecuta('UPDATE platillo SET porcion = ? WHERE id = ?', [$porcion, $idPlatillo]);
                    }
                }
            }

            $tienePrecio = $idPlatillo > 0
                && $bd->valor('SELECT 1 FROM platillo_sucursal WHERE id_platillo = ? AND id_sucursal = ?', [$idPlatillo, $idSucursal]) !== null;
            if ($tienePrecio) {
                $cuenta['ya_tenian_precio']++;
            } else {
                $cuenta['precios']++;
                if ($aplicar) {
                    $bd->ejecuta('INSERT INTO platillo_sucursal (id_sucursal, id_platillo, precio) VALUES (?, ?, ?)', [$idSucursal, $idPlatillo, $precio]);
                }
            }

            foreach ($preparaciones as $preparacion) {
                [$modificador, $suplemento] = is_array($preparacion) ? $preparacion : [$preparacion, '0'];
                $existe = $idPlatillo > 0
                    && $bd->valor('SELECT 1 FROM modificador_platillo WHERE id_platillo = ? AND nombre = ?', [$idPlatillo, $modificador]) !== null;
                if (!$existe) {
                    $cuenta['preparaciones']++;
                    if ($aplicar) {
                        $bd->ejecuta('INSERT INTO modificador_platillo (id_platillo, nombre, suplemento) VALUES (?, ?, ?)', [$idPlatillo, $modificador, $suplemento]);
                    }
                }
            }
        }
    }
};

if (!$aplicar) {
    $carga();
    printf("Sucursal %s. Sin --aplicar no se escribió nada. Esto se agregaría:\n", $sucursal['nombre']);
} else {
    $app = Nucleo\Configuracion::aplicacion($raiz);
    $bitacora = new Bitacora($bd, new Registro((string) $app['registros'], (bool) $app['depurar']),
        (new ContextoAuditoria())->comoGuion('carga_carta'));
    $bd->transaccion(static function () use ($carga, $bitacora, $idSucursal, &$cuenta): void {
        $carga();
        $bitacora->registra('restaurante', 'carga_carta', 'sucursal', $idSucursal, despues: $cuenta);
    });
    printf("Sucursal %s. Se agregó:\n", $sucursal['nombre']);
}
printf("  categorías nuevas: %d · leyendas: %d\n  platillos nuevos: %d · porciones: %d\n  precios: %d (ya tenían precio: %d)\n  preparaciones: %d\n",
    $cuenta['categorias'], $cuenta['leyendas'], $cuenta['platillos'], $cuenta['porciones'],
    $cuenta['precios'], $cuenta['ya_tenian_precio'], $cuenta['preparaciones']);
