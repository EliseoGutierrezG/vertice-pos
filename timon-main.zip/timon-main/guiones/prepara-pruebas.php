<?php
declare(strict_types=1);

/**
 * Crea desde cero la base y el usuario exclusivos del entorno de pruebas.
 *
 * Ejecutar en una Terminal para que sudo solicite ahí la contraseña del
 * equipo, sin guardarla ni pasarla a la aplicación:
 *
 *   /opt/homebrew/opt/php@8.3/bin/php guiones/prepara-pruebas.php
 *
 * La contraseña de MariaDB generada para la aplicación tampoco se imprime:
 * sólo se envía al socket administrativo y se guarda en config/bd.pruebas.php,
 * archivo ignorado por Git y con permisos 0600.
 */

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

$raiz = dirname(__DIR__);
$php = '/opt/homebrew/opt/php@8.3/bin/php';
$mariadb = '/opt/homebrew/opt/mariadb@10.11/bin/mariadb';

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZonaConNombre('America/Mexico_City');

foreach ([$php, $mariadb] as $programa) {
    if (!is_file($programa) || !is_executable($programa)) {
        fwrite(STDERR, "Falta una herramienta local requerida: {$programa}\n");
        exit(1);
    }
}

echo "Se reemplazará únicamente la base local «timon_pruebas».\n";
echo "La base cotidiana «timon» no se modifica. Escribe CREAR para continuar: ";
if (trim((string) fgets(STDIN)) !== 'CREAR') {
    fwrite(STDERR, "No se hizo nada.\n");
    exit(1);
}

echo "Validando privilegios administrativos; sudo puede pedir la contraseña del equipo…\n";
passthru('/usr/bin/sudo -v', $sudo);
if ($sudo !== 0) {
    fwrite(STDERR, "No se obtuvieron privilegios; no se hizo ningún cambio.\n");
    exit(1);
}

$clave = bin2hex(random_bytes(32));
$sqlAdmin = <<<SQL
DROP DATABASE IF EXISTS `timon_pruebas`;
CREATE DATABASE `timon_pruebas` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'timon_pruebas'@'localhost' IDENTIFIED BY '{$clave}';
ALTER USER 'timon_pruebas'@'localhost' IDENTIFIED BY '{$clave}';
GRANT ALL PRIVILEGES ON `timon_pruebas`.* TO 'timon_pruebas'@'localhost';
GRANT ALL PRIVILEGES ON `timon_restauracion_pruebas`.* TO 'timon_pruebas'@'localhost';
FLUSH PRIVILEGES;
SQL;

$tuberias = [];
$proceso = proc_open(
    ['/usr/bin/sudo', $mariadb, '--protocol=socket', '--default-character-set=utf8mb4'],
    [0 => ['pipe', 'r'], 1 => STDOUT, 2 => STDERR],
    $tuberias
);
if (!is_resource($proceso)) {
    fwrite(STDERR, "No se pudo iniciar el cliente administrativo de MariaDB.\n");
    exit(1);
}
fwrite($tuberias[0], $sqlAdmin);
fclose($tuberias[0]);
if (proc_close($proceso) !== 0) {
    fwrite(STDERR, "MariaDB rechazó la preparación; no se escribieron configuraciones.\n");
    exit(1);
}

$app = <<<'PHP'
<?php
return [
    'nombre'       => 'El Timón - Pruebas',
    'entorno'      => 'pruebas',
    'depurar'      => true,
    'zona_horaria' => 'America/Mexico_City',
    'registros'    => __DIR__ . '/../almacenamiento/registros',
];
PHP;
$bd = "<?php\nreturn [\n"
    . "    'host'    => '127.0.0.1',\n"
    . "    'base'    => 'timon_pruebas',\n"
    . "    'usuario' => 'timon_pruebas',\n"
    . "    'clave'   => " . var_export($clave, true) . ",\n"
    . "    'puerto'  => 3306,\n"
    . "];\n";

escribePrivado($raiz . '/config/app.pruebas.php', $app . "\n");
escribePrivado($raiz . '/config/bd.pruebas.php', $bd);

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conexion = new mysqli('127.0.0.1', 'timon_pruebas', $clave, 'timon_pruebas', 3306);
$conexion->set_charset('utf8mb4');

$guiones = glob($raiz . '/esquema/*.sql') ?: [];
sort($guiones, SORT_STRING);

foreach ($guiones as $guion) {
    $sql = file_get_contents($guion);
    if ($sql === false) {
        throw new RuntimeException('No se pudo leer ' . basename($guion));
    }

    $conexion->multi_query($sql);
    do {
        if ($resultado = $conexion->store_result()) {
            $resultado->free();
        }
    } while ($conexion->more_results() && $conexion->next_result());

    echo '  aplicado ' . basename($guion) . "\n";
}

$declaradas = Nucleo\MigracionesEsquema::tablasDeclaradas($guiones);

$tablas = (int) $conexion->query(
    "SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema = DATABASE()"
)->fetch_assoc()['n'];
$puesto = (int) $conexion->query(
    "SELECT COUNT(*) AS n FROM puesto WHERE clave = 'administrador'"
)->fetch_assoc()['n'];
$conexion->close();

if ($tablas !== count($declaradas) || $puesto !== 1) {
    fwrite(STDERR, "El esquema quedó incompleto: {$tablas} tablas de " . count($declaradas) . ", puesto administrador={$puesto}.\n");
    exit(1);
}

echo "Listo: timon_pruebas tiene {$tablas} tablas y configuración privada separada.\n";
echo "Sigue: APP_ENTORNO=pruebas php guiones/crear-usuario.php\n";

function escribePrivado(string $ruta, string $contenido): void
{
    $temporal = $ruta . '.tmp-' . bin2hex(random_bytes(6));
    if (file_put_contents($temporal, $contenido, LOCK_EX) === false) {
        throw new RuntimeException('No se pudo escribir ' . basename($ruta));
    }
    chmod($temporal, 0600);
    if (!rename($temporal, $ruta)) {
        @unlink($temporal);
        throw new RuntimeException('No se pudo publicar ' . basename($ruta));
    }
}
