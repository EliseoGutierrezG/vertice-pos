#!/usr/bin/env php
<?php

declare(strict_types=1);

/**
 * Consolida los guiones inmutables de esquema en un único archivo importable.
 *
 * No se conecta a ninguna base ni ejecuta SQL. El resultado es apropiado sólo
 * para una base vacía; una base con datos requiere una migración incremental.
 */

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo se ejecuta desde consola.\n");
    exit(2);
}

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZonaConNombre('America/Mexico_City');

$salida = $argv[1] ?? $raiz . '/entregables/despliegue/app-esquema.sql';
$directorioEsquema = $raiz . '/esquema';
$archivos = glob($directorioEsquema . '/[0-9][0-9][0-9]_*.sql') ?: [];
sort($archivos, SORT_STRING);

if ($archivos === []) {
    fwrite(STDERR, "No se encontraron guiones numerados en {$directorioEsquema}.\n");
    exit(1);
}

$partes = [];
$tablas = [];
$fuentes = [];
$migraciones = [];
$esperado = 1;

foreach ($archivos as $archivo) {
    $nombre = basename($archivo);
    if (!preg_match('/^(\d{3})_[a-z0-9_-]+\.sql$/i', $nombre, $coincidencia)) {
        fwrite(STDERR, "Nombre de guion no válido: {$nombre}\n");
        exit(1);
    }

    $numero = (int) $coincidencia[1];
    if ($numero !== $esperado) {
        fwrite(STDERR, sprintf(
            "La secuencia del esquema no es continua: se esperaba %03d y apareció %s.\n",
            $esperado,
            $nombre
        ));
        exit(1);
    }
    $esperado++;

    $sql = file_get_contents($archivo);
    if ($sql === false) {
        fwrite(STDERR, "No se pudo leer {$archivo}.\n");
        exit(1);
    }

    // La única excepción al DROP TABLE: las tablas de trabajo `appNNN_*` que
    // el propio guion NNN crea y borra (046 en adelante). Ni cuentan como
    // tablas del esquema ni dejan pasar un DROP de cualquier otra.
    $trabajo = sprintf('app%03d_', $numero);
    $sinTrabajo = preg_replace('/\bDROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?`?' . $trabajo . '[a-z0-9_]+`?\s*;/i', '', $sql);
    if (preg_match('/\b(?:DROP\s+(?:DATABASE|TABLE)|CREATE\s+DATABASE|USE\s+[`a-z0-9_])/i', (string) $sinTrabajo)) {
        fwrite(STDERR, "{$nombre} contiene una orden destructiva o selecciona una base explícita.\n");
        exit(1);
    }
    if (preg_match('/\b(?:DEFINER|GRANT|CREATE\s+(?:PROCEDURE|TRIGGER|FUNCTION|EVENT))\b/i', $sql)) {
        fwrite(STDERR, "{$nombre} contiene una orden que requiere privilegios especiales en hosting compartido.\n");
        exit(1);
    }

    preg_match_all(
        '/\bCREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:`([^`]+)`|([a-z0-9_]+))/i',
        $sql,
        $coincidencias,
        PREG_SET_ORDER
    );
    foreach ($coincidencias as $tablaEncontrada) {
        $tabla = $tablaEncontrada[1] !== '' ? $tablaEncontrada[1] : $tablaEncontrada[2];
        $clave = strtolower($tabla);
        if (str_starts_with($clave, $trabajo)) {
            if (!preg_match('/\bDROP\s+TABLE\s+`?' . $clave . '`?\s*;/i', $sql)) {
                fwrite(STDERR, "{$nombre} crea la tabla de trabajo {$tabla} y no la borra.\n");
                exit(1);
            }
            continue;
        }
        if (isset($tablas[$clave])) {
            fwrite(STDERR, "La tabla {$tabla} se crea más de una vez ({$tablas[$clave]} y {$nombre}).\n");
            exit(1);
        }
        $tablas[$clave] = $nombre;
    }

    $fuentes[] = $nombre;
    $migraciones[] = [
        'numero' => $numero,
        'nombre' => $nombre,
        'sha256' => hash('sha256', $sql),
    ];
    $partes[] = "-- ============================================================================\n"
        . "-- INICIO {$nombre}\n"
        . "-- ============================================================================\n"
        . rtrim($sql)
        . "\n-- FIN {$nombre}\n";
}

if ($tablas === []) {
    fwrite(STDERR, "Los guiones no contienen ninguna CREATE TABLE.\n");
    exit(1);
}

$cabecera = "-- El Timón - esquema consolidado para instalación nueva\n"
    . '-- Fuentes: ' . count($fuentes) . " guiones numerados\n"
    . '-- Tablas declaradas: ' . count($tablas) . "\n"
    . "-- IMPORTANTE: usar exclusivamente sobre una base VACIA.\n"
    . "-- No contiene CREATE DATABASE, USE, DROP DATABASE ni DROP TABLE, salvo las\n"
    . "-- tablas de trabajo appNNN_* que su propio guion crea y borra.\n"
    . "-- No contiene DEFINER, GRANT, procedimientos, funciones, eventos ni triggers.\n"
    . "-- Seleccione la base al invocar mysql: mysql ... NOMBRE_BASE < este-archivo.sql\n\n"
    . "SET NAMES utf8mb4;\n"
    . "SET time_zone = '-06:00';\n\n";

$valoresMigracion = array_map(
    static fn (array $migracion): string => sprintf(
        "  (%d, '%s', '%s')",
        $migracion['numero'],
        str_replace("'", "''", $migracion['nombre']),
        $migracion['sha256']
    ),
    $migraciones
);
$registroMigraciones = "-- El importador no ejecuta el registro que hace aplica-esquema.php después\n"
    . "-- de cada archivo. En una instalación nueva, este bloque deja el mismo libro.\n"
    . "INSERT IGNORE INTO migracion_esquema (numero, nombre, sha256) VALUES\n"
    . implode(",\n", $valoresMigracion)
    . ";\n";

$contenido = $cabecera . implode("\n", $partes) . "\n" . $registroMigraciones;
$directorioSalida = dirname($salida);
if (!is_dir($directorioSalida) && !mkdir($directorioSalida, 0775, true) && !is_dir($directorioSalida)) {
    fwrite(STDERR, "No se pudo crear {$directorioSalida}.\n");
    exit(1);
}

escribeAtomico($salida, $contenido);
$hash = hash_file('sha256', $salida);
if ($hash === false) {
    fwrite(STDERR, "No se pudo calcular SHA-256 de {$salida}.\n");
    exit(1);
}

escribeAtomico($salida . '.sha256', $hash . '  ' . basename($salida) . "\n");
escribeAtomico(
    $salida . '.json',
    (string) json_encode([
        'archivo' => basename($salida),
        'sha256' => $hash,
        'cantidad_guiones' => count($fuentes),
        'cantidad_tablas' => count($tablas),
        'guiones' => $fuentes,
        'tablas' => array_keys($tablas),
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n"
);

printf(
    "SQL generado: %s\nGuiones: %d\nTablas: %d\nSHA-256: %s\n",
    $salida,
    count($fuentes),
    count($tablas),
    $hash
);

/** @return never|void */
function escribeAtomico(string $destino, string $contenido): void
{
    $temporal = tempnam(dirname($destino), '.app-');
    if ($temporal === false || file_put_contents($temporal, $contenido, LOCK_EX) === false) {
        fwrite(STDERR, "No se pudo escribir el archivo temporal para {$destino}.\n");
        exit(1);
    }
    if (!rename($temporal, $destino)) {
        @unlink($temporal);
        fwrite(STDERR, "No se pudo publicar {$destino}.\n");
        exit(1);
    }
}
