<?php
declare(strict_types=1);

/**
 * El respaldo de la base (paso 20.5).
 *
 *   /opt/homebrew/opt/php@8.3/bin/php guiones/respaldo.php
 *   php guiones/respaldo.php --cuantos=30      (conserva 30 en vez de 14)
 *   php guiones/respaldo.php --sin-comprimir
 *   php guiones/respaldo.php --cifrar         (además deja la copia cifrada que sale del hospedaje)
 *
 * **Está escrito en PHP a propósito, sin `mysqldump`.** En un hospedaje
 * compartido no siempre hay acceso a la consola, y el cron que sí hay siempre
 * es el que corre un archivo PHP. Un respaldo que depende de poder entrar por
 * SSH es un respaldo que el día que alguien cambie de plan deja de correr sin
 * que nadie se entere.
 *
 * **Un archivo por corrida, con la fecha en el nombre, y se conservan los
 * últimos catorce.** Sobrescribir siempre el mismo archivo es tener un solo
 * respaldo: el día que se respalde una base ya corrompida, se pierde el bueno.
 *
 * ⚠️ **El archivo lleva toda la operación del negocio.** Se escribe en
 * `almacenamiento/respaldos/`, fuera de `publico/`, donde el servidor no lo
 * sirve —hay una comprobación de eso en `pruebas/humo.sh`—. Si se copia a otra
 * parte, es un archivo que hay que tratar como confidencial.
 *
 * Lo que **no** trae: la contraseña de la base, que vive en `config/bd.php` y no
 * se respalda aquí. Restaurar en otro servidor necesita escribir ese archivo a
 * mano, que es justo lo que se quiere.
 *
 * Cómo se comprueba que sirve: `pruebas/respaldo.sh` lo restaura en una base
 * aparte y compara tabla por tabla, con `CHECKSUM TABLE`. Un respaldo que nunca se restauró no
 * es un respaldo, es un archivo.
 */

$raiz = dirname(__DIR__);

require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);

// En la línea de comandos PHP corre en UTC si nadie le dice otra cosa, y el
// cron del hospedaje es línea de comandos. Sin esto, este guion y la
// aplicación web tendrían horas distintas —seis, aquí— para el mismo
// instante. La regla está en `pruebas/ArquitecturaPrueba.php`.
Nucleo\Reloj::fijaLaZona($raiz);

use Nucleo\BaseDatos;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

$banderas = array_slice($argv, 1);
$opcion   = static function (string $nombre, int $porOmision) use ($banderas): int {
    foreach ($banderas as $bandera) {
        if (str_starts_with($bandera, '--' . $nombre . '=')) {
            return max(1, (int) substr($bandera, strlen($nombre) + 3));
        }
    }

    return $porOmision;
};

$comprime = !in_array('--sin-comprimir', $banderas, true);
$cifra    = in_array('--cifrar', $banderas, true);
$cuantos  = $opcion('cuantos', 14);
$carpeta  = $raiz . '/almacenamiento/respaldos';

if (!is_dir($carpeta) && !mkdir($carpeta, 0750, true) && !is_dir($carpeta)) {
    fwrite(STDERR, "No se pudo crear $carpeta\n");
    exit(1);
}

$configuracion = Nucleo\Configuracion::baseDatos($raiz);
$bd            = new BaseDatos($configuracion);
$base          = (string) $configuracion['base'];

$arranque = microtime(true);
$nombre   = sprintf('%s-%s.sql', $base, date('Y-m-d-His'));
$destino  = $carpeta . '/' . $nombre . ($comprime ? '.gz' : '');

$manejador = $comprime ? gzopen($destino, 'wb9') : fopen($destino, 'wb');

if ($manejador === false) {
    fwrite(STDERR, "No se pudo abrir $destino\n");
    exit(1);
}

// Si el disco se llena a la mitad, el respaldo tiene que fallar con ruido. Un
// respaldo truncado que no avisa es peor que no tener respaldo, porque el día de
// la restauración se descubre que lo que había era medio archivo.
$escribe = static function (string $texto) use ($manejador, $comprime): void {
    $escritos = $comprime ? gzwrite($manejador, $texto) : fwrite($manejador, $texto);

    if ($escritos === false || $escritos < strlen($texto)) {
        throw new RuntimeException('Se escribió a medias: el respaldo no sirve');
    }
};

// La cabecera. Las tres líneas de arriba son las que permiten restaurar sin
// cuidar el orden de las tablas: con 44 tablas y sus llaves cruzadas, el orden
// correcto existe pero no vale la pena calcularlo.
$escribe("-- Respaldo de «{$base}» · " . date('Y-m-d H:i:s') . "\n");
$escribe("-- El Timón. Este archivo lleva la operación completa: trátese como confidencial.\n");
$escribe("SET NAMES utf8mb4;\n");
$escribe("SET FOREIGN_KEY_CHECKS = 0;\n");
$escribe("SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n\n");

$tablas    = [];
$renglones = 0;

foreach ($bd->filas('SHOW FULL TABLES WHERE Table_type = "BASE TABLE"') as $fila) {
    $tablas[] = (string) array_values($fila)[0];
}

sort($tablas);

foreach ($tablas as $tabla) {
    // El nombre viene de `SHOW TABLES`, no de nadie de fuera, pero se comprueba
    // igual: es lo único que se pega en una consulta en todo el guion.
    if (preg_match('/^[A-Za-z0-9_]+$/', $tabla) !== 1) {
        fwrite(STDERR, "Nombre de tabla inesperado: se detiene.\n");
        exit(1);
    }

    $crear = $bd->fila('SHOW CREATE TABLE `' . $tabla . '`');

    $escribe("-- ---------------------------------------------------------------\n");
    $escribe("DROP TABLE IF EXISTS `$tabla`;\n");
    $escribe(str_replace("\n", ' ', (string) array_values($crear ?? [])[1]) . ";\n");

    $columnas = [];

    foreach ($bd->filas('SHOW COLUMNS FROM `' . $tabla . '`') as $columna) {
        // Una columna generada la recalcula la base al restaurar; escribirla falla.
        if (str_contains(strtoupper((string) $columna['Extra']), 'GENERATED')) {
            continue;
        }
        $columnas[] = (string) $columna['Field'];
    }

    $lista  = '`' . implode('`, `', $columnas) . '`';
    $juntos = [];
    $cuenta = 0;

    // Se lee sin traer la tabla entera a memoria: el día que `movimiento` tenga
    // dos millones de renglones, esto sigue corriendo en el mismo hospedaje.
    foreach ($bd->porRenglon('SELECT ' . $lista . ' FROM `' . $tabla . '`') as $renglon) {
        $valores = [];

        foreach ($columnas as $columna) {
            $valores[] = $renglon[$columna] === null
                ? 'NULL'
                : "'" . $bd->escapa((string) $renglon[$columna]) . "'";
        }

        $juntos[] = '(' . implode(',', $valores) . ')';
        $cuenta++;
        $renglones++;

        // De cien en cien: un INSERT por renglón hace archivos enormes y
        // lentos de restaurar, y uno solo con todo no cabe en `max_allowed_packet`.
        if (count($juntos) >= 100) {
            $escribe("INSERT INTO `$tabla` ($lista) VALUES " . implode(',', $juntos) . ";\n");
            $juntos = [];
        }
    }

    if ($juntos !== []) {
        $escribe("INSERT INTO `$tabla` ($lista) VALUES " . implode(',', $juntos) . ";\n");
    }

    $escribe("\n");
    printf("  %-28s %7d renglones\n", $tabla, $cuenta);
}

$escribe("SET FOREIGN_KEY_CHECKS = 1;\n");
$escribe("-- Fin del respaldo.\n");

if ($comprime) {
    gzclose($manejador);
} else {
    fclose($manejador);
}

@chmod($destino, 0640);

printf(
    "\n  %s · %s tablas, %s renglones, %.1f KB, %.1f segundos\n",
    basename($destino),
    count($tablas),
    number_format($renglones),
    (filesize($destino) ?: 0) / 1024,
    microtime(true) - $arranque
);

// --- La copia que sale del hospedaje (fase 29) ------------------------------
// Va cifrada en `respaldos/cifrados/`, que es lo único que se descarga fuera del
// hosting. Se descifra en el acto y se compara la huella: una copia que no se
// puede abrir se descubre hoy, no el día que hace falta.
if ($cifra) {
    $carpetaCifrada = $carpeta . '/cifrados';
    if (!is_dir($carpetaCifrada) && !mkdir($carpetaCifrada, 0750, true) && !is_dir($carpetaCifrada)) {
        fwrite(STDERR, "No se pudo crear $carpetaCifrada\n");
        exit(1);
    }
    $copia = $carpetaCifrada . '/' . basename($destino) . '.sgr';
    try {
        $cifrador = new Nucleo\Seguridad\CifradorArchivo(Nucleo\Configuracion::llaveRespaldo($raiz));
        $cifrador->cifra($destino, $copia);
        if (!hash_equals((string) hash_file('sha256', $destino), $cifrador->descifra($copia))) {
            @unlink($copia);
            throw new RuntimeException('La copia cifrada no coincide con el respaldo');
        }
    } catch (Throwable $e) {
        fwrite(STDERR, 'No se pudo cifrar el respaldo: ' . $e->getMessage() . "\n");
        exit(1);
    }
    printf("  Copia cifrada y verificada: cifrados/%s\n", basename($copia));

    $cifrados = glob($carpetaCifrada . '/' . $base . '-*.sql*.sgr') ?: [];
    usort($cifrados, static fn (string $a, string $b) => filemtime($b) <=> filemtime($a));
    foreach (array_slice($cifrados, $cuantos) as $archivo) {
        unlink($archivo);
    }
}

// --- Se tiran los viejos -----------------------------------------------------
// Conservar todos llena el disco del hospedaje y entonces el respaldo del día
// que hacía falta es el que no se pudo escribir.

// ⚠️ **Se ordena por la fecha del archivo, no por su nombre.** Ordenar por
// nombre parece lo mismo y no lo es: el nombre lo escribe un reloj, y el día
// que ese reloj cambia —como cuando se corrigió que el cron corría en UTC y no
// en la hora del negocio— los nombres nuevos quedan seis horas *atrás* de los
// viejos. Ordenando por nombre, esa corrida tira la copia más nueva y conserva
// las viejas. La fecha del archivo no depende de cómo se llame.
$viejos = glob($carpeta . '/' . $base . '-*.sql*') ?: [];
usort($viejos, static fn (string $a, string $b) => filemtime($b) <=> filemtime($a));
$sobran = array_slice($viejos, $cuantos);

foreach ($sobran as $archivo) {
    unlink($archivo);
}

printf(
    "  Se conservan %d y se tiraron %d.\n\n",
    min(count($viejos), $cuantos),
    count($sobran)
);
