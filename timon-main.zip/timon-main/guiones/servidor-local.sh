#!/usr/bin/env bash
# El panel de todos los días en local, contra la base `timon`.
#
#   guiones/servidor-local.sh            → http://127.0.0.1:8080
#   PB_SERVIDOR=127.0.0.1:8090 guiones/servidor-local.sh
#
# Las pruebas usan `servidor-pruebas.sh` (8081, base `timon_pruebas`): así una
# tanda de `pruebas/todo.sh` nunca toca lo que se captura a mano.

set -euo pipefail

RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
PHP83="/opt/homebrew/opt/php@8.3/bin/php"
DIRECCION="${PB_SERVIDOR:-127.0.0.1:8080}"

if [ ! -x "$PHP83" ]; then
  echo "No se encontró PHP 8.3 en $PHP83" >&2
  exit 1
fi

export APP_ENTORNO=local

exec "$PHP83" \
  -d upload_max_filesize=10M \
  -d post_max_size=12M \
  -S "$DIRECCION" \
  -t "$RAIZ/publico" \
  "$RAIZ/pruebas/servidor-local.php"
