<?php
declare(strict_types=1);

/**
 * Crea (o rehace) los disparadores que anotan en `cambio_replica` lo que el
 * servidor de sucursal tiene que subir al central. Se corre al instalar y
 * después de cada migración.
 *
 *   php guiones/disparadores-replica.php
 *
 * Solo corre en un servidor de sucursal: en el central no hay nada que subir.
 * Las tablas salen de `Servicios\Replica::SUBIDA`; las del catálogo que la
 * sucursal solo toca en algunas columnas (`solo`) anotan únicamente cuando
 * cambian esas columnas. Lo que escribe la propia réplica al bajar
 * (`@replica_bajando`) no se anota.
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

use Nucleo\BaseDatos;
use Nucleo\Configuracion;
use Servicios\Replica;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion solo corre en la línea de comandos.\n");
    exit(1);
}
if ((Configuracion::instalacion($raiz)['tipo'] ?? null) !== 'sucursal') {
    fwrite(STDERR, "Solo se corre en un servidor de sucursal (config/instalacion.php con tipo sucursal).\n");
    exit(1);
}

$bd = new BaseDatos(Configuracion::baseDatos($raiz));

/** @param list<string> $llave */
$json = static function (array $llave, string $fila): string {
    return 'JSON_OBJECT(' . implode(', ', array_map(static fn (string $c): string => "'" . $c . "', " . $fila . '.' . $c, $llave)) . ')';
};
$anota = static fn (string $tabla, string $llaveJson): string =>
    'IF @replica_bajando IS NULL THEN INSERT INTO cambio_replica (tabla, llave) VALUES (\'' . $tabla . '\', ' . $llaveJson . '); END IF';

$tablas = Replica::SUBIDA + ['bitacora' => ['llave' => ['id'], 'solo_alta' => true]];
$creados = 0;
foreach ($tablas as $tabla => $definicion) {
    foreach (['ins' => 'INSERT', 'upd' => 'UPDATE', 'del' => 'DELETE'] as $sufijo => $evento) {
        $bd->ejecuta('DROP TRIGGER IF EXISTS trg_replica_' . $tabla . '_' . $sufijo);
    }
    $llave = $definicion['llave'];
    if (isset($definicion['solo'])) {
        // Del catálogo: solo cuando cambia lo que escribe la sucursal.
        $cambio = implode(' OR ', array_map(static fn (string $c): string => 'NOT (NEW.' . $c . ' <=> OLD.' . $c . ')', $definicion['solo']));
        $bd->ejecuta('CREATE TRIGGER trg_replica_' . $tabla . '_upd AFTER UPDATE ON ' . $tabla . ' FOR EACH ROW BEGIN IF ' . $cambio
            . ' THEN ' . $anota($tabla, $json($llave, 'NEW')) . '; END IF; END');
        $creados++;
        continue;
    }
    $bd->ejecuta('CREATE TRIGGER trg_replica_' . $tabla . '_ins AFTER INSERT ON ' . $tabla . ' FOR EACH ROW BEGIN '
        . $anota($tabla, $json($llave, 'NEW')) . '; END');
    $creados++;
    if ($definicion['solo_alta'] ?? false) {
        continue;
    }
    $bd->ejecuta('CREATE TRIGGER trg_replica_' . $tabla . '_upd AFTER UPDATE ON ' . $tabla . ' FOR EACH ROW BEGIN '
        . $anota($tabla, $json($llave, 'NEW')) . '; END');
    $bd->ejecuta('CREATE TRIGGER trg_replica_' . $tabla . '_del AFTER DELETE ON ' . $tabla . ' FOR EACH ROW BEGIN '
        . $anota($tabla, $json($llave, 'OLD')) . '; END');
    $creados += 2;
}

fwrite(STDOUT, 'Disparadores de réplica: ' . $creados . " listos.\n");
