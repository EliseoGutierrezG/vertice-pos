<?php
declare(strict_types=1);

/**
 * Crea el par de llaves que firma las versiones del sistema para las
 * computadoras de sucursal (`docs/servidor-sucursal.md`, «Actualizaciones»).
 *
 *   php guiones/genera-llave-firma.php [--privada=RUTA]
 *
 * - La **pública** queda en `config/firma-liberaciones.pub`: no es secreta,
 *   entra a Git y viaja en cada versión.
 * - La **privada** queda fuera del proyecto, por omisión en
 *   `~/.timon/firma-liberaciones.llave`, con permisos 0600. No se imprime:
 *   guarde una copia en su gestor de contraseñas. Quien la tenga puede
 *   mandar código a todas las sucursales.
 *
 * No sobrescribe ninguna de las dos: perder la privada obliga a cambiar de
 * llave en cada sucursal a mano.
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZonaConNombre('America/Mexico_City');

use Nucleo\Seguridad\FirmaLiberacion;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion solo corre en la línea de comandos.\n");
    exit(1);
}
$privada = (string) (getenv('HOME') ?: '') . '/.timon/firma-liberaciones.llave';
foreach (array_slice($argv, 1) as $argumento) {
    if (str_starts_with($argumento, '--privada=')) {
        $privada = substr($argumento, strlen('--privada='));
    }
}
$publica = $raiz . '/' . FirmaLiberacion::ARCHIVO;
foreach ([$privada, $publica] as $ruta) {
    if (file_exists($ruta)) {
        fwrite(STDERR, "Ya existe {$ruta}; no se sobrescribió.\n");
        exit(2);
    }
}
$carpeta = dirname($privada);
if (!is_dir($carpeta) && !mkdir($carpeta, 0700, true) && !is_dir($carpeta)) {
    fwrite(STDERR, "No se pudo crear {$carpeta}.\n");
    exit(1);
}

$par = FirmaLiberacion::generaPar();
$temporal = $privada . '.tmp-' . bin2hex(random_bytes(4));
if (file_put_contents($temporal, $par['privada'] . "\n", LOCK_EX) === false || !chmod($temporal, 0600) || !rename($temporal, $privada)) {
    @unlink($temporal);
    fwrite(STDERR, "No se pudo crear {$privada}.\n");
    exit(1);
}
if (file_put_contents($publica, $par['publica'] . "\n", LOCK_EX) === false) {
    fwrite(STDERR, "No se pudo escribir {$publica}.\n");
    exit(1);
}

fwrite(STDOUT, "Llave privada (0600): {$privada}\n");
fwrite(STDOUT, "Llave pública: {$publica}\n");
fwrite(STDOUT, "Guarde una copia de la privada fuera de esta computadora.\n");
