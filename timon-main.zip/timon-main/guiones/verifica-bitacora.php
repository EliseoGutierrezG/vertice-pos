<?php
declare(strict_types=1);

/**
 * Rehace los sellos de la bitácora y dice si algo no cuadra.
 *
 *   php guiones/verifica-bitacora.php
 *
 * El mantenimiento diario ya lo hace; esto es para comprobarlo a mano, por ejemplo
 * en una auditoría. Sale con 1 si encuentra una alteración.
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

$bd = new Nucleo\BaseDatos(Nucleo\Configuracion::baseDatos($raiz));
$problemas = (new Servicios\SelloBitacora($bd, Nucleo\Configuracion::llaveSello($raiz)))->verifica();
$tramos = (int) $bd->valor('SELECT COUNT(*) FROM bitacora_sello');

if ($problemas === []) {
    printf("Bitácora íntegra: %d tramos sellados, sin diferencias.\n", $tramos);
    exit(0);
}

fwrite(STDERR, "⚠️ La bitácora no cuadra con sus sellos:\n  - " . implode("\n  - ", $problemas) . "\n");
exit(1);
