#!/usr/bin/env bash
# Prepara la computadora de una sucursal para que opere sin internet
# (docs/servidor-sucursal.md). Se corre una sola vez, en esa computadora, con
# Docker y openssl instalados, desde la carpeta de un paquete firmado
# (guiones/prepara-liberacion-sucursal.sh) ya extraído:
#
#   tar -xzf timon-<versión>.tar.gz && cd timon
#   bash guiones/instala-sucursal.sh ../timon-<versión>.tar.gz ../timon-<versión>.firma.json
#
# Después, las versiones nuevas llegan solas desde el central (actualiza.php).
#
# Antes hay que registrar la sucursal en el panel central (Operación local):
# el registro da el número y la llave que este guion pide.
#
# Deja todo lo de esta instalación en despliegue/sucursal/local/, que no entra
# a Git: certificados, base, el esquema inicial y local/raiz, con las versiones
# del código (liberaciones/), el enlace `actual` y lo compartido entre
# versiones (configuración y almacenamiento). Las llaves se leen sin mostrarse
# y nunca se imprimen.
set -euo pipefail

RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
SUCURSAL="$RAIZ/despliegue/sucursal"
LOCAL="$SUCURSAL/local"
COMPOSE=(docker compose -f "$SUCURSAL/compose.yaml")

falla() { printf 'Error: %s\n' "$1" >&2; exit 1; }

command -v docker >/dev/null || falla 'falta Docker.'
command -v openssl >/dev/null || falla 'falta openssl.'
docker compose version >/dev/null 2>&1 || falla 'falta docker compose.'
PAQUETE="${1:-}"; FIRMA="${2:-}"
[ -f "$PAQUETE" ] && [ -f "$FIRMA" ] || falla 'indique el paquete .tar.gz y su .firma.json.'
PAQUETE="$(cd "$(dirname "$PAQUETE")" && pwd)/$(basename "$PAQUETE")"
FIRMA="$(cd "$(dirname "$FIRMA")" && pwd)/$(basename "$FIRMA")"
[ "$(dirname "$PAQUETE")" = "$(dirname "$FIRMA")" ] || falla 'el paquete y su firma van en la misma carpeta.'
CODIGO="$LOCAL/raiz"
CONFIG="$CODIGO/compartido/config"
[ -e "$CONFIG/instalacion.php" ] && falla "esta computadora ya está instalada ($LOCAL). Para empezar de cero, mueva esa carpeta."

pregunta() { local valor; read -r -p "$1: " valor; printf '%s' "$valor"; }
secreta() { local valor; read -r -s -p "$1: " valor; printf '\n' >&2; printf '%s' "$valor"; }

echo 'Datos de esta sucursal (los da el panel central al registrarla):'
IP="$(pregunta 'IP fija de esta computadora en el WiFi del restaurante (ej. 192.168.1.50)')"
[[ "$IP" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || falla 'la IP no tiene la forma 192.168.1.50.'
CENTRAL="$(pregunta 'Dirección del panel central (ej. https://timon.ejemplo.com.mx)')"
CENTRAL="${CENTRAL%/}"
[[ "$CENTRAL" =~ ^https://[a-z0-9.-]+(:[0-9]+)?$ ]] || falla 'la dirección del central debe empezar con https://.'
ID_SUCURSAL="$(pregunta 'Número de la sucursal en el central')"
[[ "$ID_SUCURSAL" =~ ^[0-9]+$ ]] || falla 'el número de sucursal es un entero.'
DESPLAZAMIENTO="$(pregunta 'Número que dio el registro (de 2 a 99)')"
[[ "$DESPLAZAMIENTO" =~ ^[0-9]+$ ]] && [ "$DESPLAZAMIENTO" -ge 2 ] && [ "$DESPLAZAMIENTO" -le 99 ] || falla 'el número del registro va de 2 a 99.'
SECRETO="$(secreta 'Llave que dio el registro (no se muestra)')"
[[ "$SECRETO" =~ ^[a-f0-9]{64}$ ]] || falla 'la llave del registro son 64 letras y números.'
LLAVE_TOTP="$(secreta 'llave_totp de config/seguridad.php del central (no se muestra)')"
[ "$(printf '%s' "$LLAVE_TOTP" | openssl base64 -d -A 2>/dev/null | wc -c | tr -d ' ')" = 32 ] || falla 'llave_totp debe ser base64 de 32 bytes.'

umask 077
mkdir -p "$LOCAL"/{tls,inicial,secretos,base} "$CONFIG" "$CODIGO"/{liberaciones,compartido/descargas} \
  "$CODIGO"/compartido/almacenamiento/{registros,respaldos/cifrados,tareas,sesiones,alertas,imagenes/productos,marca,replica}

# --- Configuración -------------------------------------------------------------
CLAVE_BD="$(openssl rand -hex 24)"
printf '%s' "$CLAVE_BD" > "$LOCAL/secretos/bd_clave"

cat > "$CONFIG/app.php" <<PHP
<?php
return [
    'nombre'       => 'El Timón',
    'entorno'      => 'produccion',
    'depurar'      => false,
    'zona_horaria' => 'America/Mexico_City',
    'url_publica'  => 'https://$IP',
    'registros'    => __DIR__ . '/../almacenamiento/registros',
];
PHP
cat > "$CONFIG/bd.php" <<PHP
<?php
return ['host' => 'bd', 'base' => 'timon', 'usuario' => 'timon', 'clave' => '$CLAVE_BD', 'puerto' => 3306];
PHP
cat > "$CONFIG/seguridad.php" <<PHP
<?php
declare(strict_types=1);
// llave_totp es la del central: con ella se leen los segundos factores que bajan.
// llave_sello es propia, aunque aquí no se sella (la bitácora la sella el central).
return ['llave_totp' => '$LLAVE_TOTP', 'llave_sello' => '$(openssl rand -base64 32)'];
PHP
cat > "$CONFIG/respaldo.php" <<PHP
<?php
declare(strict_types=1);
return ['llave' => '$(openssl rand -base64 32)'];
PHP
cat > "$CONFIG/alertas.php" <<'PHP'
<?php
declare(strict_types=1);
// Sin correo en la sucursal: los avisos quedan en almacenamiento/alertas/.
return ['correo' => 'sucursal@localhost', 'remitente' => 'sucursal@localhost', 'transporte' => 'archivo',
    'espacio_minimo_mb' => 2048, 'registros_maximo_mb' => 200];
PHP
cat > "$CONFIG/instalacion.php" <<PHP
<?php
declare(strict_types=1);
return ['tipo' => 'sucursal', 'desplazamiento' => $DESPLAZAMIENTO, 'id_sucursal' => $ID_SUCURSAL,
    'url_central' => '$CENTRAL', 'secreto' => '$SECRETO', 'salud_ca' => '/etc/timon/tls/ca.crt'];
PHP
unset SECRETO LLAVE_TOTP CLAVE_BD
# El giro y la llave pública de firma viajan en cada versión; la marca es de la instalación.
[ -f "$RAIZ/config/marca-visual.php" ] && cp "$RAIZ/config/marca-visual.php" "$CONFIG/"

# --- Autoridad y certificado ---------------------------------------------------
# Una IP de la red local no puede tener certificado público: la sucursal tiene
# su propia autoridad, que se instala una vez en cada tableta y PC. El
# certificado vence a los 825 días, el máximo que aceptan iPad y Android.
openssl req -x509 -newkey rsa:3072 -sha256 -nodes -days 3650 \
  -keyout "$LOCAL/tls/ca.key" -out "$LOCAL/tls/ca.crt" \
  -subj "/O=El Timón/CN=El Timón sucursal $ID_SUCURSAL" \
  -addext 'basicConstraints=critical,CA:TRUE,pathlen:0' -addext 'keyUsage=critical,keyCertSign,cRLSign' 2>/dev/null
openssl req -newkey rsa:2048 -sha256 -nodes -keyout "$LOCAL/tls/servidor.key" -out "$LOCAL/tls/servidor.csr" \
  -subj "/O=El Timón/CN=$IP" 2>/dev/null
printf 'subjectAltName=IP:%s\nbasicConstraints=CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\n' "$IP" > "$LOCAL/tls/servidor.ext"
openssl x509 -req -in "$LOCAL/tls/servidor.csr" -CA "$LOCAL/tls/ca.crt" -CAkey "$LOCAL/tls/ca.key" -CAcreateserial \
  -days 825 -sha256 -extfile "$LOCAL/tls/servidor.ext" -out "$LOCAL/tls/servidor.crt" 2>/dev/null
rm -f "$LOCAL/tls/servidor.csr" "$LOCAL/tls/servidor.ext"
chmod 644 "$LOCAL/tls/ca.crt" "$LOCAL/tls/servidor.crt"
# La llave de la autoridad no la necesita el contenedor; se guarda aparte.
mkdir -p "$LOCAL/autoridad" && mv "$LOCAL/tls/ca.key" "$LOCAL/tls/ca.srl" "$LOCAL/autoridad/" 2>/dev/null || true

# Los contenedores corren como www-data (33). El actualizador escribe en
# liberaciones/ y mueve `actual`: el código queda a su nombre.
chmod 755 "$LOCAL/tls"
chmod 600 "$LOCAL/tls/servidor.key"

# --- Imagen, base y disparadores ----------------------------------------------
echo 'Armando la imagen…'
"${COMPOSE[@]}" build

echo 'Instalando la versión del paquete…'
# La firma se comprueba con la llave pública de este mismo paquete: es la
# primera, la que trae en la mano quien instala. Las siguientes se comprueban
# con la del código ya instalado.
docker run --rm -v "$CODIGO:/srv/timon" -v "$(dirname "$PAQUETE"):/paquete:ro" -v "$RAIZ:/fuente:ro" timon-sucursal \
  php /fuente/guiones/actualiza.php --instala="/paquete/$(basename "$PAQUETE")" --firma="/paquete/$(basename "$FIRMA")" \
  --base=/srv/timon --sin-base
# También funciona en Docker Desktop: los permisos se fijan desde el contenedor.
# Nunca dejar configuración o código escribible por cualquier usuario del host.
docker run --rm -v "$CODIGO:/srv/timon" timon-sucursal \
  sh -c 'chown -R 33:33 /srv/timon && chmod -R u+rwX,go-rwx /srv/timon/compartido && chmod 755 /srv/timon /srv/timon/liberaciones'
docker run --rm -v "$CODIGO:/srv/timon" -v "$LOCAL/inicial:/salida" timon-sucursal \
  php /srv/timon/actual/guiones/genera-sql-despliegue.php /salida/001_esquema.sql >/dev/null
chmod 644 "$LOCAL/inicial/001_esquema.sql"

echo 'Creando la base…'
"${COMPOSE[@]}" up -d --wait bd
"${COMPOSE[@]}" run --rm --no-deps web php /srv/timon/actual/guiones/migraciones.php
"${COMPOSE[@]}" run --rm --no-deps web php /srv/timon/actual/guiones/disparadores-replica.php

echo 'Arrancando…'
"${COMPOSE[@]}" up -d

cat <<TXT

Listo. La computadora de la sucursal ya responde en https://$IP
  · El catálogo y lo de hoy bajan solos en cuanto hay internet (servicio «sincroniza»).
  · En cada tableta y PC: abra http://$IP/ca.crt e instale la autoridad (docs/servidor-sucursal.md).
  · En la app: dé de alta el equipo con la dirección $IP y apruébelo en https://$IP/equipos-comanda.
  · Guarde fuera de esta computadora la carpeta despliegue/sucursal/local/autoridad/ y la llave de respaldo.
  · Las versiones nuevas se asignan en el central (Operación local) y se instalan solas.
TXT
