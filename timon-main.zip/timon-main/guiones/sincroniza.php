<?php
declare(strict_types=1);

/**
 * El proceso que mantiene al servidor de sucursal al día con el central.
 *
 *   php guiones/sincroniza.php            (no para; lo levanta Docker o el sistema)
 *   php guiones/sincroniza.php --una-vez  (un ciclo y sale; para pruebas)
 *
 * Cada 15 s sube lo pendiente (`cambio_replica`) y cada 60 s pregunta por el
 * catálogo. La primera vez hace el arranque: baja el catálogo y la operación
 * viva de la sucursal. Si no hay internet, espera y vuelve a intentar: la
 * sucursal sigue operando con su base.
 *
 * Deja su estado en `almacenamiento/replica/estado.json`, que lee la salud
 * para que la app diga «Sin internet: todo funciona».
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

use Nucleo\Aplicacion;
use Nucleo\BaseDatos;
use Nucleo\Configuracion;
use Nucleo\ContextoAuditoria;
use Nucleo\Instalacion;
use Servicios\ClienteCentral;
use Servicios\Replica;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion solo corre en la línea de comandos.\n");
    exit(1);
}
$unaVez = in_array('--una-vez', array_slice($argv, 1), true);

$contenedor = (new Aplicacion($raiz))->contenedor();
/** @var Instalacion $instalacion */
$instalacion = $contenedor->obtiene(Instalacion::class);
if (!$instalacion->esSucursal()) {
    fwrite(STDERR, "Este servidor no es de sucursal: falta config/instalacion.php con tipo sucursal.\n");
    exit(1);
}
$contenedor->obtiene(ContextoAuditoria::class)->comoGuion('sincroniza');
/** @var Replica $replica */
$replica = $contenedor->obtiene(Replica::class);
$sucursal = (int) $instalacion->idSucursal();
$version = Configuracion::liberacion($raiz)['id'];
$carpeta = $raiz . '/almacenamiento/replica';
if (!is_dir($carpeta) && !mkdir($carpeta, 0770, true) && !is_dir($carpeta)) {
    fwrite(STDERR, "No se pudo crear almacenamiento/replica.\n");
    exit(1);
}
$archivo = $carpeta . '/estado.json';
$candadoReplica = fopen($carpeta . '/proceso.candado', 'c');
if ($candadoReplica === false) {
    fwrite(STDERR, "No se pudo abrir el candado de réplica.\n");
    exit(1);
}
if (!flock($candadoReplica, LOCK_EX | LOCK_NB)) {
    fclose($candadoReplica);
    fwrite(STDOUT, "Ya hay otra sincronización en curso.\n");
    exit(0);
}
// El sistema libera el candado al salir, también ante una señal o error fatal.
$estado = (is_file($archivo) ? json_decode((string) file_get_contents($archivo), true) : null) ?: [];
$estado += ['huella' => '', 'arranque' => false, 'alcanzable' => false, 'ultimo_contacto' => null, 'error' => '', 'espera_actualizacion' => false];

$cliente = new ClienteCentral($instalacion, $version, static fn (): int => $replica->pendientes());
$llama = $cliente->llama(...);

// Con liberaciones (docs/servidor-sucursal.md, «Actualizaciones»), el código
// vive en liberaciones/<id> y `actual` apunta al instalado. Si el actualizador
// lo movió, este proceso sale para que lo vuelvan a levantar con el nuevo.
$actual = dirname($raiz, 2) . '/actual';
$cambioDeVersion = static fn (): bool => is_link($actual) && realpath($actual) !== realpath($raiz);

$guarda = static function () use (&$estado, $archivo): void {
    file_put_contents($archivo . '.tmp', json_encode($estado, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    rename($archivo . '.tmp', $archivo);
};
$informa = static function (string $texto): void {
    fwrite(STDOUT, '[' . date('Y-m-d H:i:s') . '] ' . $texto . "\n");
};

$bajaCatalogo = static function (bool $forzada) use ($llama, $replica, $sucursal, &$estado, $informa): void {
    $datos = $llama('GET', '/catalogo?huella=' . rawurlencode($forzada ? '' : (string) $estado['huella']));
    // El central se actualiza primero. Mientras esta computadora tenga un
    // esquema anterior, el catálogo nuevo no cabe: se sigue subiendo y se
    // espera a que el actualizador instale la versión.
    $requerido = (int) ($datos['esquema'] ?? 0);
    $filas = $replica->aplicaBajada($sucursal, $datos);
    $estado['espera_actualizacion'] = $filas === null;
    if ($estado['espera_actualizacion']) {
        $informa('El central tiene el esquema ' . $requerido . '; el catálogo baja después de actualizar.');
        return;
    }
    if (($datos['cambio'] ?? false) === true) {
        $informa('Catálogo al día: ' . $filas . ' filas cambiaron.');
    }
    $estado['huella'] = (string) ($datos['huella'] ?? '');
};

$sube = static function () use ($llama, $replica, $informa): int {
    $total = 0;
    // Hasta diez lotes por ciclo: después de un corte largo, se pone al día rápido.
    for ($vuelta = 0; $vuelta < 10; $vuelta++) {
        $lote = $replica->lotePendiente();
        if ($lote['cambios'] === []) {
            break;
        }
        $hecho = $llama('POST', '/subida', ['filas' => $lote['filas']]);
        $replica->marcaEnviados($lote['cambios']);
        $total += count($lote['cambios']);
        $informa('Subidos ' . count($lote['cambios']) . ' cambios (' . (int) ($hecho['filas'] ?? 0) . ' filas, '
            . (int) ($hecho['bitacora'] ?? 0) . ' apuntes).');
    }

    return $total;
};

$ultimaBajada = 0;
$ultimaPurga = 0;
for (;;) {
    $operacion = null;
    try {
        $operacion = Nucleo\CerrojoActualizacion::lectura($raiz);
        if (!$estado['arranque']) {
            $bajaCatalogo(true);
        }
        if (!$estado['arranque'] && !$estado['espera_actualizacion']) {
            $tablas = $llama('GET', '/arranque')['tablas'] ?? [];
            $filas = $replica->aplicaArranque($sucursal, $tablas);
            $estado['arranque'] = true;
            $informa('Arranque hecho: ' . $filas . ' filas de operación.');
            $ultimaBajada = time();
        }
        $sube();
        if (time() - $ultimaBajada >= 60) {
            $bajaCatalogo(false);
            $ultimaBajada = time();
        }
        if (time() - $ultimaPurga >= 86400) {
            $replica->purga();
            $ultimaPurga = time();
        }
        $estado['alcanzable'] = true;
        $estado['ultimo_contacto'] = date('c');
        $estado['error'] = '';
    } catch (Throwable $e) {
        $sinConexion = str_starts_with($e->getMessage(), 'sin_conexion');
        $estado['alcanzable'] = !$sinConexion;
        $estado['error'] = $sinConexion ? 'Sin conexión con el central' : $e->getMessage();
        $informa($estado['error']);
    } finally {
        Nucleo\CerrojoActualizacion::libera($operacion);
    }
    $estado['pendientes'] = $replica->pendientes();
    $guarda();
    if ($unaVez) {
        exit($estado['error'] === '' ? 0 : 1);
    }
    if ($cambioDeVersion()) {
        $informa('Hay versión nueva instalada: sale para arrancar con ella.');
        exit(0);
    }
    sleep(15);
}
