import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const raiz = fileURLToPath(new URL('../', import.meta.url));
const marca = JSON.parse(readFileSync(resolve(raiz, 'marca/tokens.json'), 'utf8'));
const c = marca.colores;
const verifica = process.argv.includes('--verifica');

function luminancia(hex) {
    if (!/^#[0-9A-F]{6}$/i.test(hex)) throw new Error(`Color inválido: ${hex}`);
    const canales = hex.slice(1).match(/../g).map(par => parseInt(par, 16) / 255);
    const [r, g, b] = canales.map(valor => valor <= 0.04045
        ? valor / 12.92
        : ((valor + 0.055) / 1.055) ** 2.4);
    return r * .2126 + g * .7152 + b * .0722;
}

for (const [a, b, minimo] of [
    ['tinta', 'fondo', 4.5], ['tinta', 'superficie', 4.5], ['primario', 'superficie', 4.5],
    ['acento', 'superficie', 4.5], ['exito', 'superficie', 4.5], ['tinta', 'aviso', 4.5],
    ['secundario', 'fondo', 4.5], ['borde', 'superficie', 3],
]) {
    const valores = [luminancia(c[a]), luminancia(c[b])].sort((x, y) => y - x);
    const contraste = (valores[0] + .05) / (valores[1] + .05);
    if (contraste < minimo) throw new Error(`${a}/${b}: ${contraste.toFixed(2)} < ${minimo}`);
    console.log(`${a}/${b} ${contraste.toFixed(2)}:1`);
}

function guarda(ruta, contenido) {
    const destino = resolve(raiz, ruta);
    if (verifica) {
        if (readFileSync(destino, 'utf8') !== contenido) throw new Error(`Regenera ${ruta}`);
    } else {
        mkdirSync(dirname(destino), { recursive: true });
        writeFileSync(destino, contenido);
    }
}

const php = texto => "'" + texto.replaceAll('\\', '\\\\').replaceAll("'", "\\'") + "'";
const panel = Object.keys(c);
guarda('servicios/MarcaBase.php', `<?php
declare(strict_types=1);

namespace Servicios;

// Generado por guiones/genera-marca.mjs.
final class MarcaBase
{
    public const VALORES = [
        'nombre' => ${php(marca.nombre)},
        'nombre_corto' => ${php(marca.nombre_corto)},
        'lema' => ${php(marca.lema)},
        'colores' => [
${panel.map(clave => `            '${clave}' => '${c[clave]}',`).join('\n')}
        ],
        'logo' => null,
    ];
}
`);
guarda('publico/recursos/marca.css', `/* Generado por guiones/genera-marca.mjs. */
:root {
${Object.entries(c).map(([clave, valor]) => `    --marca-${clave}: ${valor};`).join('\n')}
}
`);
guarda('app/src/nucleo/marca.ts', `// Generado por guiones/genera-marca.mjs.
export const marca = ${JSON.stringify(marca, null, 2)} as const;
`);

const escapa = texto => texto.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
const nombre = escapa(marca.nombre);
const rueda = (trazo, ola, fondo) => `  <g fill="none" stroke="${trazo}" stroke-linecap="round" stroke-width="7">
    <circle cx="50" cy="46" r="27"/>
    <path d="M50 8v76M12 46h76M23 19l54 54M23 73l54-54"/>
    <circle cx="50" cy="46" r="8" fill="${fondo}"/>
  </g>
  <path d="M7 66c13-9 24-9 38 0s25 9 37 1l11-5" fill="none" stroke="${fondo}" stroke-width="12" stroke-linecap="round"/>
  <path d="M7 66c13-9 24-9 38 0s25 9 37 1l11-5" fill="none" stroke="${ola}" stroke-width="6" stroke-linecap="round"/>`;
const svg = (ancho, contenido) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${ancho} 94" role="img" aria-labelledby="titulo">
  <title id="titulo">${nombre}</title>
${contenido}
</svg>
`;
const rotulo = color => `  <text x="110" y="57" fill="${color}" font-family="Barlow Condensed, Arial, sans-serif" font-size="42" font-weight="800">${nombre}</text>
  <text x="112" y="75" fill="${color}" font-family="Arial, sans-serif" font-size="11" font-weight="700" letter-spacing="3">MARISCOS</text>`;

const simbolo = svg(100, rueda(c.primario, c.acento, c.superficie));
const icono = svg(100, `  <rect width="100" height="94" rx="19" fill="${c.tinta}"/>
${rueda(c.superficie, c.limon, c.tinta)}`);
guarda('marca/timon-y-ola.svg', simbolo);
guarda('publico/recursos/simbolo.svg', icono);
guarda('publico/recursos/isotipo.svg', icono);
guarda('publico/recursos/logo-horizontal.svg', svg(285, rueda(c.primario, c.acento, c.superficie) + '\n' + rotulo(c.tinta)));
guarda('publico/recursos/logo-monocromo.svg', svg(285, rueda('#000000', '#000000', '#FFFFFF') + '\n' + rotulo('#000000')));

guarda('marca/icono-cuadrado.svg', `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="1024" height="1024">
  <rect width="100" height="100" fill="${c.tinta}"/>
  <g transform="translate(11 13) scale(.78)">
${rueda(c.superficie, c.limon, c.tinta)}
  </g>
</svg>
`);

guarda('app/public/manifest.webmanifest', JSON.stringify({
    id: '/app/',
    name: marca.nombre + ' · Comanda',
    short_name: marca.nombre_corto,
    lang: 'es-MX',
    start_url: '/app/',
    scope: '/app/',
    display: 'standalone',
    theme_color: c.tinta,
    background_color: c.fondo,
    icons: [192, 512].map(lado => ({
        src: '/app/icono-' + lado + '.png', sizes: lado + 'x' + lado, type: 'image/png', purpose: 'any',
    })),
}, null, 2) + '\n');
