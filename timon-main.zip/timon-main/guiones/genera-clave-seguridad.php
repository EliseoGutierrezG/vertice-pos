<?php
declare(strict_types=1);

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

$pruebas = in_array('--pruebas', $argv, true);
$destino = $raiz . '/config/seguridad' . ($pruebas ? '.pruebas' : '') . '.php';

if (is_file($destino)) {
    fwrite(STDERR, "Ya existe {$destino}; no se sobrescribió.\n");
    exit(2);
}

$contenido = "<?php\ndeclare(strict_types=1);\n\nreturn [\n    'llave_totp' => '"
    . base64_encode(random_bytes(32)) . "',\n];\n";
$temporal = $destino . '.tmp-' . bin2hex(random_bytes(4));
if (file_put_contents($temporal, $contenido, LOCK_EX) === false || !chmod($temporal, 0600) || !rename($temporal, $destino)) {
    @unlink($temporal);
    fwrite(STDERR, "No se pudo crear {$destino}.\n");
    exit(1);
}

fwrite(STDOUT, "Configuración creada con permisos 0600: {$destino}\n");
