<?php
declare(strict_types=1);

/**
 * Abre una copia cifrada del respaldo (fase 29).
 *
 *   php guiones/descifra-respaldo.php ARCHIVO.sgr --verifica
 *   php guiones/descifra-respaldo.php ARCHIVO.sgr --salida=/ruta/respaldo.sql.gz
 *
 * `--verifica` recorre el archivo completo sin escribir nada: sirve para que el
 * dueño confirme, en su propia computadora, que la copia que descargó está
 * completa y que su llave la abre. Con `--salida` deja el respaldo listo para
 * `guiones/restaura.php`. La llave sale de `config/respaldo.php` o, fuera del
 * proyecto, de la variable `PB_LLAVE_RESPALDO_ARCHIVO` con la ruta de ese
 * archivo; nunca se escribe en la línea de comandos.
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(1);
}

$archivo = null;
$salida = null;
$verifica = false;
foreach (array_slice($argv, 1) as $argumento) {
    if ($argumento === '--verifica') {
        $verifica = true;
    } elseif (str_starts_with($argumento, '--salida=')) {
        $salida = substr($argumento, 9);
    } elseif (!str_starts_with($argumento, '--')) {
        $archivo = $argumento;
    }
}

if ($archivo === null || ($salida === null) === !$verifica) {
    fwrite(STDERR, "Uso: descifra-respaldo.php ARCHIVO.sgr (--verifica | --salida=RUTA)\n");
    exit(2);
}
if (!is_file($archivo)) {
    fwrite(STDERR, "No existe el archivo indicado.\n");
    exit(2);
}
if ($salida !== null && file_exists($salida)) {
    fwrite(STDERR, "La salida ya existe; no se sobrescribe.\n");
    exit(2);
}

try {
    $rutaLlave = getenv('PB_LLAVE_RESPALDO_ARCHIVO') ?: '';
    if ($rutaLlave !== '') {
        $config = is_file($rutaLlave) ? require $rutaLlave : null;
        if (!is_array($config) || !is_string($config['llave'] ?? null)) {
            throw new RuntimeException('El archivo de llave no es válido');
        }
        $llave = $config['llave'];
    } else {
        $llave = Nucleo\Configuracion::llaveRespaldo($raiz);
    }

    $huella = (new Nucleo\Seguridad\CifradorArchivo($llave))->descifra($archivo, $salida);
} catch (Throwable $e) {
    fwrite(STDERR, 'No se pudo abrir la copia: ' . $e->getMessage() . "\n");
    exit(1);
}

fwrite(STDOUT, ($verifica ? 'Copia íntegra' : 'Respaldo descifrado en ' . $salida) . "\n");
fwrite(STDOUT, 'SHA-256 del respaldo: ' . $huella . "\n");
