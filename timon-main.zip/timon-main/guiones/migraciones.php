#!/usr/bin/env php
<?php
declare(strict_types=1);

/**
 * Consulta o aplica únicamente los guiones incrementales pendientes.
 *
 *   php guiones/migraciones.php
 *   php guiones/migraciones.php --aplicar --acepto=NOMBRE_BASE
 *   php guiones/migraciones.php --aplicar --acepto=NOMBRE_BASE \
 *     --respaldo-verificado=almacenamiento/respaldos/ARCHIVO.sql.gz
 *
 * Sin --aplicar nunca escribe. En producción exige además un respaldo local
 * no vacío; este guion no sustituye la prueba de restauración.
 */

use Nucleo\Configuracion;
use Nucleo\MigracionesEsquema;
use Nucleo\Reloj;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion sólo corre en la línea de comandos.\n");
    exit(2);
}

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Reloj::fijaLaZona($raiz);

$aplicar = in_array('--aplicar', $argv, true);
$acepto = '';
$respaldo = '';
foreach (array_slice($argv, 1) as $argumento) {
    if (str_starts_with($argumento, '--acepto=')) {
        $acepto = substr($argumento, strlen('--acepto='));
    } elseif (str_starts_with($argumento, '--respaldo-verificado=')) {
        $respaldo = substr($argumento, strlen('--respaldo-verificado='));
    } elseif (!in_array($argumento, ['--estado', '--aplicar'], true)) {
        fwrite(STDERR, "Argumento no reconocido: {$argumento}\n");
        exit(2);
    }
}

$entorno = Configuracion::entorno($raiz);
$config = Configuracion::baseDatos($raiz);
$base = (string) $config['base'];
$inventario = MigracionesEsquema::inventario($raiz . '/esquema');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conexion = new mysqli(
    (string) $config['host'],
    (string) $config['usuario'],
    (string) $config['clave'],
    $base,
    (int) $config['puerto']
);
$conexion->set_charset('utf8mb4');

$tablaExiste = static function (mysqli $conexion, string $tabla): bool {
    $sentencia = $conexion->prepare(
        'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?'
    );
    $sentencia->bind_param('s', $tabla);
    $sentencia->execute();
    $existe = (int) $sentencia->get_result()->fetch_row()[0] === 1;
    $sentencia->close();
    return $existe;
};

$tieneLibro = $tablaExiste($conexion, 'migracion_esquema');
$aplicadas = [];

if ($tieneLibro) {
    $aplicadas = $conexion->query(
        'SELECT numero,nombre,sha256 FROM migracion_esquema ORDER BY numero'
    )->fetch_all(MYSQLI_ASSOC);
} else {
    // Toda instalación nace con el libro: lo crea 001 y lo llenan
    // `aplica-esquema.php` y el SQL de despliegue. Una base sin libro no es de
    // este sistema, o se instaló a mano: no se adivina qué tiene.
    fwrite(STDERR, "La base no tiene libro de migraciones (migracion_esquema).\n");
    fwrite(STDERR, "Una base nueva se instala con aplica-esquema.php o con el SQL de despliegue.\n");
    exit(1);
}

$estado = MigracionesEsquema::compara($inventario, $aplicadas);
foreach ($estado['errores'] as $error) {
    fwrite(STDERR, "ERROR: {$error}\n");
}

printf(
    "Base: %s · entorno: %s · registradas: %d · disponibles: %d\n",
    $base,
    $entorno,
    count($aplicadas),
    count($inventario)
);
if ($estado['pendientes'] === []) {
    echo "Estado: al día.\n";
} else {
    echo "Pendientes:\n";
    foreach ($estado['pendientes'] as $archivo) {
        printf("  %03d · %s · %s\n", $archivo['numero'], $archivo['nombre'], $archivo['sha256']);
    }
}

if ($estado['errores'] !== []) {
    exit(1);
}
if (!$aplicar) {
    exit(0);
}
if ($estado['pendientes'] === []) {
    echo "No hay nada que aplicar.\n";
    exit(0);
}
if ($acepto !== $base) {
    fwrite(STDERR, "Para aplicar agrega --acepto={$base}\n");
    exit(2);
}
if ($entorno === 'produccion') {
    $rutaRespaldo = $respaldo === '' ? '' : (realpath($respaldo) ?: '');
    if ($rutaRespaldo === '' || !is_file($rutaRespaldo) || filesize($rutaRespaldo) === 0) {
        fwrite(STDERR, "Producción exige --respaldo-verificado=RUTA a un archivo local no vacío.\n");
        exit(2);
    }
}

$maximo = 0;
foreach ($aplicadas as $fila) {
    $maximo = max($maximo, (int) $fila['numero']);
}
foreach ($estado['pendientes'] as $archivo) {
    if ($archivo['numero'] <= $maximo) {
        fwrite(STDERR, "Hay un hueco antes de una migración ya aplicada; se detiene.\n");
        exit(1);
    }
}

$candado = 'app:migraciones:' . substr(hash('sha256', $base), 0, 24);
$sentenciaCandado = $conexion->prepare('SELECT GET_LOCK(?, 5)');
$sentenciaCandado->bind_param('s', $candado);
$sentenciaCandado->execute();
$obtenido = (int) $sentenciaCandado->get_result()->fetch_row()[0];
$sentenciaCandado->close();
if ($obtenido !== 1) {
    fwrite(STDERR, "Otra ejecución tiene el candado de migraciones.\n");
    exit(1);
}

try {
    foreach ($estado['pendientes'] as $archivo) {
        printf("Aplicando %s…\n", $archivo['nombre']);
        $sql = file_get_contents($archivo['ruta']);
        if ($sql === false) {
            throw new RuntimeException("No se pudo leer {$archivo['nombre']}");
        }

        $conexion->multi_query($sql);
        do {
            if ($resultado = $conexion->store_result()) {
                $resultado->free();
            }
        } while ($conexion->more_results() && $conexion->next_result());

        if (!$tablaExiste($conexion, 'migracion_esquema')) {
            throw new RuntimeException('La migración no dejó disponible el libro del esquema');
        }
        $registra = $conexion->prepare(
            'INSERT INTO migracion_esquema(numero,nombre,sha256) VALUES(?,?,?)'
        );
        $numero = $archivo['numero'];
        $nombre = $archivo['nombre'];
        $sha256 = $archivo['sha256'];
        $registra->bind_param('iss', $numero, $nombre, $sha256);
        $registra->execute();
        $registra->close();

        $huella = $conexion->query(
            'SELECT sha256 FROM migracion_esquema WHERE numero = ' . (int) $archivo['numero']
        )->fetch_row()[0] ?? '';
        if (!hash_equals($archivo['sha256'], (string) $huella)) {
            throw new RuntimeException("La postcomprobación de {$archivo['nombre']} no coincidió");
        }
        echo "  aplicada y registrada.\n";
    }
} finally {
    $libera = $conexion->prepare('SELECT RELEASE_LOCK(?)');
    $libera->bind_param('s', $candado);
    $libera->execute();
    $libera->close();
    $conexion->close();
}

echo "Esquema al día.\n";
