<?php
declare(strict_types=1);

/**
 * Mantiene al día el código de la computadora de sucursal
 * (`docs/servidor-sucursal.md`, «Actualizaciones»).
 *
 *   php guiones/actualiza.php
 *       Un ciclo: pregunta al central, baja la versión asignada y la instala
 *       si no hay cuentas ni turno abiertos. Lo corre la tarea cada 15 min.
 *
 *   php guiones/actualiza.php --instala=PAQUETE.tar.gz --firma=PAQUETE.firma.json [--base=DIR] [--sin-base]
 *       Instala a mano un paquete firmado (por VPN, o la primera vez con
 *       `--sin-base`, cuando la base todavía no existe).
 *
 *   php guiones/actualiza.php --comprueba=ID
 *       Sale con 0 si este código es la versión ID y la base está migrada.
 *       Lo usa el actualizador después de mover `actual`.
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
// La primera instalación corre desde el paquete recién extraído, que no trae
// configuración de ninguna computadora.
is_file($raiz . '/config/app.php') ? Nucleo\Reloj::fijaLaZona($raiz) : Nucleo\Reloj::fijaLaZonaConNombre('America/Mexico_City');

use Nucleo\Aplicacion;
use Nucleo\BaseDatos;
use Nucleo\Configuracion;
use Nucleo\ContextoAuditoria;
use Nucleo\Instalacion;
use Nucleo\Seguridad\FirmaLiberacion;
use Servicios\Actualizador;
use Servicios\ClienteCentral;
use Servicios\Replica;

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Este guion solo corre en la línea de comandos.\n");
    exit(1);
}
$opcion = static function (string $nombre) use ($argv): ?string {
    foreach (array_slice($argv, 1) as $argumento) {
        if (str_starts_with($argumento, '--' . $nombre . '=')) {
            return substr($argumento, strlen($nombre) + 3);
        }
    }
    return null;
};
$informa = static function (string $texto): void {
    fwrite(STDOUT, '[' . date('Y-m-d H:i:s') . '] ' . $texto . "\n");
};

// --- Comprobación de una versión recién instalada ----------------------------
$comprueba = $opcion('comprueba');
if ($comprueba !== null) {
    try {
        $liberacion = Configuracion::liberacion($raiz);
        $bd = (new Aplicacion($raiz))->contenedor()->obtiene(BaseDatos::class);
        $esquema = (int) $bd->valor('SELECT COALESCE(MAX(numero), 0) FROM migracion_esquema');
        if ($liberacion['id'] !== $comprueba || $esquema < $liberacion['esquema']) {
            fwrite(STDERR, "Se esperaba {$comprueba} con esquema {$liberacion['esquema']}; hay {$liberacion['id']} con {$esquema}.\n");
            exit(1);
        }
        // Comprueba el proceso web real, incluido Apache/opcache y su enlace
        // actual. La CA local se confía explícitamente, nunca se desactiva TLS.
        $config = Configuracion::aplicacion($raiz);
        $local = Configuracion::instalacion($raiz) ?? [];
        $url = rtrim((string) $config['url_publica'], '/') . '/api/v1/salud';
        $bien = false;
        for ($intento = 0; $intento < 12; $intento++) {
            $curl = curl_init($url);
            curl_setopt_array($curl, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 2,
                CURLOPT_TIMEOUT => 3, CURLOPT_FOLLOWLOCATION => false]);
            if (!empty($local['salud_ca'])) {
                curl_setopt($curl, CURLOPT_CAINFO, $local['salud_ca']);
            }
            $salud = json_decode((string) curl_exec($curl), true);
            $codigo = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            curl_close($curl);
            if ($codigo === 200 && ($salud['ok'] ?? false) === true
                && ($salud['datos']['liberacion'] ?? '') === $comprueba
                && ($salud['datos']['base'] ?? '') === 'viva'
                && (int) ($salud['datos']['esquema'] ?? 0) >= $liberacion['esquema']) {
                $bien = true;
                break;
            }
            usleep(500000);
        }
        if (!$bien) {
            throw new RuntimeException('La salud web no confirmó la versión nueva');
        }
    } catch (Throwable $e) {
        fwrite(STDERR, $e->getMessage() . "\n");
        exit(1);
    }
    exit(0);
}

// --- Instalación a mano ------------------------------------------------------
$paquete = $opcion('instala');
if ($paquete !== null) {
    $base = $opcion('base') ?? Actualizador::baseDe($raiz);
    $firma = $opcion('firma');
    $descriptor = $firma !== null && is_file($firma) ? json_decode((string) file_get_contents($firma), true) : null;
    if ($base === null || !is_dir($base . '/compartido/config') || !is_array($descriptor) || !is_file($paquete)) {
        fwrite(STDERR, "Uso: actualiza.php --instala=PAQUETE --firma=FIRMA.json [--base=DIR con compartido/config] [--sin-base]\n");
        exit(2);
    }
    // La llave con que se comprueba es la del código que ya está instalado; la
    // primera vez, la de este paquete, que quien instala tiene en la mano.
    $llave = FirmaLiberacion::publicaDe(is_dir($base . '/actual') ? (string) realpath($base . '/actual') : $raiz);
    if ($llave === null) {
        fwrite(STDERR, "Falta config/firma-liberaciones.pub: no se instala nada sin firma.\n");
        exit(1);
    }
    $sinBase = in_array('--sin-base', $argv, true);
    $bd = $sinBase ? null : new BaseDatos(Configuracion::baseDatos((string) realpath($base . '/actual')));
    try {
        // Sin base, el actualizador no la toca: solo extrae, enlaza y mueve `actual`.
        $actualizador = new Actualizador($base, $bd);
        $actualizador->instala($paquete, $descriptor, $llave, !$sinBase);
    } catch (Throwable $e) {
        fwrite(STDERR, 'No se instaló: ' . $e->getMessage() . "\n");
        exit(1);
    }
    $informa('Instalada ' . $descriptor['id'] . ' en ' . $base . '/actual.');
    exit(0);
}

// --- Ciclo automático --------------------------------------------------------
$contenedor = (new Aplicacion($raiz))->contenedor();
/** @var Instalacion $instalacion */
$instalacion = $contenedor->obtiene(Instalacion::class);
$base = Actualizador::baseDe($raiz);
if (!$instalacion->esSucursal() || $base === null) {
    fwrite(STDERR, "Solo se corre en una computadora de sucursal instalada por versiones (liberaciones/<id>).\n");
    exit(1);
}
$contenedor->obtiene(ContextoAuditoria::class)->comoGuion('actualiza');
$replica = $contenedor->obtiene(Replica::class);
$cliente = new ClienteCentral($instalacion, Configuracion::liberacion($raiz)['id'], static fn (): int => $replica->pendientes());
try {
    $informa((new Actualizador($base, $contenedor->obtiene(BaseDatos::class), $cliente))->ciclo());
} catch (Throwable $e) {
    // Sin internet no es una falla: se intenta en el próximo ciclo.
    $informa(str_starts_with($e->getMessage(), 'sin_conexion') ? 'Sin conexión con el central.' : $e->getMessage());
    exit(str_starts_with($e->getMessage(), 'sin_conexion') ? 0 : 1);
}
