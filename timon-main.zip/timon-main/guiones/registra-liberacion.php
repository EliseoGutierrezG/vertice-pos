<?php
declare(strict_types=1);

/**
 * Registra en el central una versión firmada para las computadoras de
 * sucursal, cuando el paquete pesa más de lo que deja subir el panel.
 * Después se asigna a cada sucursal en «Operación local».
 *
 *   php guiones/registra-liberacion.php PAQUETE.tar.gz PAQUETE.firma.json ["notas"]
 */

$raiz = dirname(__DIR__);
require $raiz . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raiz);
Nucleo\Reloj::fijaLaZona($raiz);

use Nucleo\Aplicacion;
use Nucleo\ContextoAuditoria;
use Nucleo\Errores\ErrorHttp;
use Servicios\Liberaciones;

if (PHP_SAPI !== 'cli' || $argc < 3) {
    fwrite(STDERR, "Uso: registra-liberacion.php PAQUETE.tar.gz PAQUETE.firma.json [\"notas\"]\n");
    exit(2);
}
$descriptor = is_file($argv[2]) ? json_decode((string) file_get_contents($argv[2]), true) : null;
if (!is_file($argv[1]) || !is_array($descriptor)) {
    fwrite(STDERR, "No se encontró el paquete o su firma.\n");
    exit(2);
}
$contenedor = (new Aplicacion($raiz))->contenedor();
if (!$contenedor->obtiene(Nucleo\Instalacion::class)->esCentral()) {
    fwrite(STDERR, "Solo se registra en el central (config/instalacion.php con tipo central).\n");
    exit(1);
}
$contenedor->obtiene(ContextoAuditoria::class)->comoGuion('registra-liberacion');
try {
    $id = $contenedor->obtiene(Liberaciones::class)->registra($argv[1], $descriptor, (string) ($argv[3] ?? ''));
} catch (ErrorHttp $e) {
    fwrite(STDERR, 'No se registró: ' . $e->getMessage() . ' ' . json_encode($e->campos(), JSON_UNESCAPED_UNICODE) . "\n");
    exit(1);
}
fwrite(STDOUT, "Registrada {$id}. Asígnela en Operación local.\n");
