#!/usr/bin/env php
<?php
declare(strict_types=1);

/** Genera el descriptor no secreto que identifica exactamente un paquete. */

$raizProyecto = dirname(__DIR__);
require $raizProyecto . '/nucleo/Autocargador.php';
Nucleo\Autocargador::registrar($raizProyecto);
Nucleo\Reloj::fijaLaZonaConNombre('America/Mexico_City');

if (PHP_SAPI !== 'cli' || $argc !== 4) {
    fwrite(STDERR, "Uso: genera-liberacion.php ARBOL CONFIG INSTALACION\n");
    exit(2);
}

[$ignorado, $arbol, $config, $instalacion] = $argv;
$arbol = rtrim($arbol, '/');
$config = rtrim($config, '/');
$instalacion = rtrim($instalacion, '/');

if (!is_dir($arbol) || !is_dir($config) || !is_dir($instalacion)) {
    fwrite(STDERR, "Las tres rutas deben existir.\n");
    exit(2);
}

$lineas = [];
$iterador = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($arbol, FilesystemIterator::SKIP_DOTS)
);
foreach ($iterador as $archivo) {
    if (!$archivo->isFile()) {
        continue;
    }
    $ruta = $archivo->getPathname();
    $relativa = ltrim(substr($ruta, strlen($arbol)), '/');
    if (in_array(basename($ruta), ['liberacion.php', 'LIBERACION.json', 'MANIFIESTO-SHA256.txt'], true)) {
        continue;
    }
    $huella = hash_file('sha256', $ruta);
    if ($huella === false) {
        throw new RuntimeException("No se pudo leer {$relativa}");
    }
    $lineas[] = $huella . '  ' . $relativa;
}
sort($lineas, SORT_STRING);
$fuente = hash('sha256', implode("\n", $lineas) . "\n");

$guiones = glob(dirname($config) . '/esquema/[0-9][0-9][0-9]_*.sql') ?: [];
$version = 0;
foreach ($guiones as $guion) {
    if (preg_match('/^(\d{3})_/', basename($guion), $coincidencia)) {
        $version = max($version, (int) $coincidencia[1]);
    }
}
if ($version === 0) {
    throw new RuntimeException('El paquete no contiene guiones numerados de esquema');
}

$creada = gmdate('Y-m-d\TH:i:s\Z');
$id = gmdate('Ymd\THis\Z') . '-' . substr($fuente, 0, 12);
$datos = [
    'id' => $id,
    'creada_en' => $creada,
    'fuente_sha256' => $fuente,
    'esquema' => $version,
];

$php = "<?php\nreturn " . var_export($datos, true) . ";\n";
$json = json_encode($datos, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
if (file_put_contents($config . '/liberacion.php', $php, LOCK_EX) === false
    || file_put_contents($instalacion . '/LIBERACION.json', $json, LOCK_EX) === false) {
    throw new RuntimeException('No se pudo escribir el descriptor de liberación');
}

echo $id . "\n";
