#!/usr/bin/env bash
# Build de la plantilla CI/CD (GitHub Actions → Hostinger por FTP).
#
#   npm run build        # lo llama .github/workflows/build_project.sh
#
# Arma `entregables/despliegue/app-subdominio-ftp/`, la misma carpeta del
# procedimiento manual (INSTRUCCIONES-SUBDOMINIO.md), lista para una
# ACTUALIZACIÓN de un sitio ya instalado:
#   - la regla pública ya activa como `.htaccess` (se conserva `.htaccess.app`
#     para que el manifiesto siga cuadrando);
#   - sin el cerrojo de instalación.
# La configuración del servidor (`.app/config/*.php`), los datos y el SQL de
# instalación no se suben: los excluye FTP_EXCLUDE en service.sh. Las
# migraciones de la base NO corren aquí; se aplican por SSH con migraciones.php.
set -euo pipefail

RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
cd "$RAIZ"

# En CI no existe `config/giro.php` (vive fuera de Git): se usa la plantilla,
# que enciende restaurante y sitio público como la instalación de El Timón.
[ -f config/giro.php ] || cp config/giro.php.ejemplo config/giro.php

case "${DEPLOY_ENV:-production}" in
  staging) URL="${DEV_SERVICE_URL:-}" ;;
  *)       URL="${PROD_SERVICE_URL:-}" ;;
esac

# App de comanda web (PWA), que viaja en `app/`.
if [ -n "${CI:-}" ] || [ ! -d app/node_modules ]; then
  npm --prefix app ci --no-audit --no-fund
fi
npm --prefix app run web

URL_PUBLICA="$URL" bash guiones/prepara-despliegue-subdominio.sh

FTP="$RAIZ/entregables/despliegue/app-subdominio-ftp"
cp "$FTP/.htaccess.app" "$FTP/.htaccess"
rm -f "$FTP/app-bloqueo-instalacion.htaccess"
printf 'Carpeta lista para la sincronización FTP (%s): %s\n' "${DEPLOY_ENV:-production}" "$FTP"
