#!/usr/bin/env bash
# Arma y firma una versión del sistema para las computadoras de sucursal
# (docs/servidor-sucursal.md, «Actualizaciones»).
#
#   bash guiones/prepara-liberacion-sucursal.sh [CARPETA_DE_SALIDA]
#
# Deja en la carpeta (por omisión entregables/sucursal/) dos archivos:
#   timon-<versión>.tar.gz      el código, la PWA compilada y el esquema
#   timon-<versión>.firma.json  la firma, que se sube al central con el paquete
#
# Necesita la PWA compilada (npm --prefix app run web) y la llave privada de
# firma (guiones/genera-llave-firma.php). El paquete no lleva configuración de
# ninguna instalación: cada computadora conserva la suya.
set -euo pipefail

RAIZ="$(cd "$(dirname "$0")/.." && pwd)"
. "$RAIZ/guiones/archivos-despliegue.sh"
SALIDA="${1:-$RAIZ/entregables/sucursal}"
APK="${2:-}"
APP_MINIMA="${3:-1.0.0}"
ESCENA="$(mktemp -d "${TMPDIR:-/tmp}/timon-liberacion.XXXXXX")"
trap 'rm -rf "$ESCENA"' EXIT

falla() { printf 'Error: %s\n' "$1" >&2; exit 1; }
[ -f "$RAIZ/app/dist/index.html" ] || falla 'falta la PWA: corra npm --prefix app run web.'
[ -f "$RAIZ/config/firma-liberaciones.pub" ] || falla 'falta config/firma-liberaciones.pub: corra php guiones/genera-llave-firma.php.'

DESTINO="$ESCENA/timon"
mkdir -p "$DESTINO"/{config,guiones,instalacion,app,despliegue,esquema}
for directorio in "${DIRECTORIOS_CODIGO[@]}"; do
  cp -R "$RAIZ/$directorio" "$DESTINO/"
done
cp "$RAIZ"/esquema/[0-9][0-9][0-9]_*.sql "$DESTINO/esquema/"
cp -R "$RAIZ/app/dist" "$DESTINO/app/dist"
# El paquete Docker sin lo de ninguna computadora (local/).
mkdir -p "$DESTINO/despliegue/sucursal"
find "$RAIZ/despliegue/sucursal" -maxdepth 1 -type f -exec cp {} "$DESTINO/despliegue/sucursal/" \;

# Los guiones que usa una computadora de sucursal; nada que recree la base.
for guion in "${GUIONES_DESPLIEGUE[@]}" instala-sucursal.sh; do
  cp "$RAIZ/guiones/$guion" "$DESTINO/guiones/"
done
cp -R "$RAIZ/despliegue/synology" "$DESTINO/despliegue/"
mkdir -p "$DESTINO/docs"
cp "$RAIZ/docs/servidor-sucursal.md" "$DESTINO/docs/"

if [ -f "$RAIZ/config/giro.php" ]; then cp "$RAIZ/config/giro.php" "$DESTINO/config/"; else cp "$RAIZ/config/giro.php.ejemplo" "$DESTINO/config/giro.php"; fi
cp "$RAIZ/config/firma-liberaciones.pub" "$DESTINO/config/"
cp "$RAIZ"/config/*.ejemplo "$DESTINO/config/"
php -r '$v = json_decode(file_get_contents($argv[1]), true)["expo"]["version"];
  if (!preg_match("/^\\d+\\.\\d+\\.\\d+$/D", $argv[3]) || version_compare($argv[3], $v, ">")) {
    fwrite(STDERR, "Versión mínima de app inválida.\n"); exit(1);
  }
  file_put_contents($argv[2], "<?php\nreturn " . var_export(["version" => $v, "minima" => $argv[3]], true) . ";\n");' \
  "$RAIZ/app/app.json" "$DESTINO/config/app-movil.php" "$APP_MINIMA"
if [ -n "$APK" ]; then
  [ -f "$APK" ] || falla 'no se encontró el APK.'
  mkdir -p "$DESTINO/movil"
  cp "$APK" "$DESTINO/movil/comanda.apk"
fi

php "$RAIZ/guiones/genera-sql-despliegue.php" "$DESTINO/instalacion/esquema.sql" >/dev/null
ID="$(php "$RAIZ/guiones/genera-liberacion.php" "$DESTINO" "$DESTINO/config" "$DESTINO/instalacion")"
ESQUEMA="$(php -r 'echo (require $argv[1])["esquema"];' "$DESTINO/config/liberacion.php")"
(
  cd "$DESTINO"
  find . -type f ! -path './instalacion/MANIFIESTO-SHA256.txt' -print0 | LC_ALL=C sort -z \
    | xargs -0 shasum -a 256 > instalacion/MANIFIESTO-SHA256.txt
)

CARPETA="${ID//:/_}"
mkdir -p "$SALIDA"
PAQUETE="$SALIDA/timon-$CARPETA.tar.gz"
# Sin los metadatos extendidos de macOS (avisos LIBARCHIVE.xattr en Linux).
COPYFILE_DISABLE=1 tar --no-xattrs -C "$ESCENA" -czf "$PAQUETE" timon
php "$RAIZ/guiones/firma-paquete.php" "$PAQUETE" "$ID" "$ESQUEMA" >/dev/null

printf 'Versión %s (esquema %s)\n' "$ID" "$ESQUEMA"
printf '  %s\n  %s\n' "$PAQUETE" "${PAQUETE%.tar.gz}.firma.json"
printf 'Súbalos al central en Operación local › Subir versión.\n'
