<?php
declare(strict_types=1);

/**
 * Pieza de `guiones/demo.php`: tres semanas de operación y el día en curso.
 *
 * Simula el servicio como lo escribiría la aplicación: cada cuenta se abre,
 * manda sus rondas, la cocina las prepara, se pide la cuenta y se cobra en el
 * turno de caja del día; el cobro descuenta los insumos de las recetas en
 * orden de caducidad, las compras llegan en los días de cada proveedor y lo
 * que caduca o se cae se asienta como merma. El día en curso se corta en el
 * «ahora» de la simulación: quedan cuentas abiertas, platillos en cocina,
 * mesas por limpiar y el turno abierto.
 *
 * No se escribe la bitácora de cada movimiento: la bitácora dice quién movió
 * qué, y esto no lo movió nadie. La carga deja un solo apunte con su resumen.
 */

final class DemoOperacion
{
    private const AREAS = ['caliente' => 'Cocina caliente', 'fria' => 'Cocina fría', 'barra' => 'Barra'];
    private const DISCRETAS = ['pza', 'botella', 'manojo', 'porción'];
    private const NOMBRES = ['Alejandra', 'Roberto', 'Gabriela', 'Fernando', 'Lucía', 'Arturo', 'Mónica', 'Eduardo', 'Claudia',
        'Sergio', 'Verónica', 'Manuel', 'Patricia', 'Javier', 'Adriana', 'Raúl', 'Leticia', 'Francisco', 'Silvia', 'Gustavo',
        'Carmen', 'Alberto', 'Rocío', 'Enrique', 'Laura', 'Martín', 'Beatriz', 'Hugo', 'Elena', 'Pablo'];
    private const APELLIDOS = ['García', 'Hernández', 'López', 'Martínez', 'González', 'Pérez', 'Rodríguez', 'Sánchez', 'Ramírez',
        'Torres', 'Flores', 'Rivera', 'Gómez', 'Díaz', 'Cruz', 'Morales', 'Reyes', 'Jiménez', 'Ruiz', 'Mendoza', 'Aguilar',
        'Vargas', 'Castro', 'Romero', 'Herrera', 'Medina', 'Rojas', 'Navarro', 'Delgado', 'Salazar'];
    private const DIRECCIONES = [
        1 => ['Calle 9 Poniente 2108, Col. Centro', 'Av. Juárez 2915, Col. La Paz', 'Calle 31 Oriente 812, Col. El Carmen',
            'Privada 5 B Sur 4102, Col. Gabriel Pastor', 'Calle 14 Sur 3504, Col. Volcanes', 'Av. 25 Poniente 1306, Col. Chulavista',
            'Calle 2 Norte 1004, Barrio de Xanenetla', 'Calle 43 Poniente 512, Col. Huexotitla', 'Av. 11 Sur 7302, Col. Bugambilias',
            'Calle 3 Sur 3911, Col. El Carmen', 'Calle 18 Poniente 707, Col. San Miguel', 'Blvd. 5 de Mayo 2203, Col. Ladrillera'],
        2 => ['Calle 6 Norte 404, San Andrés Cholula', 'Av. Las Torres 1802, Tlaxcalancingo', 'Calle Morelos 1110, San Pedro Cholula',
            'Privada Lomas 18, Lomas de Angelópolis', 'Circuito Juan Pablo II 2905, Reserva Territorial Atlixcáyotl',
            'Calle 14 Oriente 9, San Andrés Cholula', 'Av. Camino Real a Cholula 3601, Zerezotla', 'Calle 2 Sur 1508, San Pedro Cholula',
            'Paseo de los Ángeles 22, Lomas de Angelópolis', 'Calle Hidalgo 702, Momoxpan', 'Calle 5 de Mayo 301, Tlaxcalancingo'],
    ];
    private const REPARTIDORES = [1 => ['Antonio Herrera', 'Miguel Rosas'], 2 => ['Javier Toledo', 'Ulises Paredes']];
    private const NOTAS = [
        'fria' => ['Sin cebolla', 'Poco picante', 'Sin cilantro', 'Extra limón', 'La salsa aparte'],
        'caliente' => ['Sin picante', 'Bien dorado', 'Sin arroz', 'La salsa aparte', 'Para compartir'],
        'barra' => ['Sin hielo', 'Bien fría', 'Con mucho limón', 'Sin chile'],
    ];
    private const MOTIVOS = ['El cliente cambió de opinión', 'Platillo equivocado', 'Se tardó demasiado', 'Se capturó dos veces',
        'No le gustó al cliente'];
    private const MERMAS = ['Se cayó al preparar', 'Llegó en mal estado', 'Producto golpeado', 'Devolución del cliente'];

    private int $corte;
    private DateTimeImmutable $hoy;
    /** @var array<string,int> */
    private array $ids = ['cuenta' => 0, 'cuenta_mesa' => 0, 'ronda' => 0, 'item' => 0, 'pago' => 0, 'forma' => 0, 'turno' => 0,
        'asiento' => 0, 'gasto' => 0];
    /** @var list<array<string,mixed>> */
    private array $trabajos = [];
    /** @var array<int,list<array{int,int,int,array<int,int>}>> */
    private array $consumos = [1 => [], 2 => []];
    /** @var array<int,string> */
    private array $mesaHoy = [];
    /** @var list<array<string,mixed>> */
    private array $reservas = [];
    /** @var array<string,mixed> */
    private array $resumen = ['ventas' => [], 'cuentas' => [], 'abiertas' => 0];

    public function __construct(private DemoSql $sql, private DemoAzar $azar, private array $cat, private DateTimeImmutable $ahora)
    {
        $this->corte = $ahora->getTimestamp();
        $this->hoy = $ahora->setTime(0, 0);
    }

    /** @return array<string,mixed> */
    public function corre(): array
    {
        $porDia = $this->reservaciones();
        for ($d = 21; $d >= 0; $d--) {
            $this->dia($this->hoy->modify('-' . $d . ' days'), 21 - $d, $porDia);
        }
        $this->escribeReservaciones();
        $this->escribeMesas();
        $this->inventario();
        $this->escribeTrabajos();
        return $this->resumen;
    }

    // ── Un día ──────────────────────────────────────────────────────────────

    private function dia(DateTimeImmutable $dia, int $n, array $porDia): void
    {
        $cero = $dia->getTimestamp();
        $fecha = $dia->format('Y-m-d');
        $dow = (int) $dia->format('N');
        $planes = [];
        $turnos = [];
        foreach ($this->cat['sucursales'] as $suc => $s) {
            $cajero = $this->cajeroDelDia($s, $dow);
            $abre = $cero + (11 * 60 + 30 + $this->azar->entero(0, 12)) * 60;
            if ($abre > $this->corte) {
                continue;
            }
            $turnos[$suc] = ['cajero' => $cajero, 'abre' => $abre];
            array_push($planes, ...$this->planea($suc, $s, $dia, $n, $cajero, $porDia[$suc][$fecha] ?? []));
        }
        if ($turnos === []) {
            return;
        }
        $planes = array_values(array_filter($planes, fn (array $p): bool => $p['abre'] <= $this->corte));
        usort($planes, static fn (array $a, array $b): int => $a['abre'] <=> $b['abre']);

        foreach ($turnos as &$t) {
            $t['id'] = ++$this->ids['turno'];
        }
        unset($t);
        foreach ($planes as &$p) {
            $p['id'] = ++$this->ids['cuenta'];
        }
        unset($p);

        // Las ids siguen al reloj: rondas por hora de envío, cobros por hora de pago.
        $rondas = [];
        foreach ($planes as $i => $p) {
            foreach ($p['rondas'] as $j => $r) {
                if ($r['t'] <= $this->corte) {
                    $rondas[] = [$r['t'], $i, $j];
                }
            }
        }
        sort($rondas);
        foreach ($rondas as [, $i, $j]) {
            $planes[$i]['rondas'][$j]['id'] = ++$this->ids['ronda'];
        }
        foreach ($planes as $i => $p) {
            foreach ($p['sueltos'] as $k => $_) {
                $planes[$i]['sueltos'][$k]['id'] = ++$this->ids['item'];
            }
        }
        foreach ($rondas as [, $i, $j]) {
            foreach ($planes[$i]['rondas'][$j]['items'] as $k => $_) {
                $planes[$i]['rondas'][$j]['items'][$k]['id'] = ++$this->ids['item'];
            }
        }

        $cobros = [];
        foreach ($planes as $i => $p) {
            $cobro = $this->escribeCuenta($p, $turnos[$p['suc']]);
            if ($cobro !== null) {
                $cobros[] = $cobro;
            }
        }
        usort($cobros, static fn (array $a, array $b): int => $a['t'] <=> $b['t']);
        $efectivo = [];
        foreach ($cobros as $cobro) {
            $efectivo[$cobro['suc']][] = [$cobro['t'], $this->escribePago($cobro, $turnos[$cobro['suc']])];
        }

        $asientos = [];
        $gastos = [];
        foreach ($turnos as $suc => $t) {
            $this->planeaCaja($suc, $this->cat['sucursales'][$suc], $cero, $dow, $n, $t, $efectivo[$suc] ?? [], $asientos, $gastos);
        }
        usort($asientos, static fn (array $a, array $b): int => $a['t'] <=> $b['t']);
        foreach ($asientos as &$a) {
            $a['id'] = ++$this->ids['asiento'];
            $this->sql->agrega('asiento_caja', ['id' => $a['id'], 'id_turno' => $turnos[$a['suc']]['id'], 'id_usuario' => $a['usuario'],
                'concepto' => $a['concepto'], 'importe' => demo_pesos($a['importe']), 'creado_en' => demo_fecha($a['t'])]);
            if ($a['gasto'] !== null) {
                $gastos[] = $a['gasto'] + ['asiento' => $a['id'], 't' => $a['t'], 'suc' => $a['suc'], 'usuario' => $a['usuario']];
            }
        }
        unset($a);
        usort($gastos, static fn (array $a, array $b): int => $a['t'] <=> $b['t']);
        foreach ($gastos as $g) {
            $this->sql->agrega('gasto_sucursal', ['id' => ++$this->ids['gasto'], 'id_sucursal' => $g['suc'],
                'id_proveedor' => $g['proveedor'], 'id_usuario' => $g['usuario'], 'id_asiento' => $g['asiento'],
                'concepto' => $g['concepto'], 'importe' => demo_pesos($g['importe']), 'comprobante' => $g['comprobante'],
                'creado_en' => demo_fecha($g['t'])]);
        }
        foreach ($turnos as $suc => $t) {
            $this->cierraTurno($suc, $cero, $t, $efectivo[$suc] ?? [], array_filter($asientos, static fn ($a) => $a['suc'] === $suc));
        }
    }

    private function cajeroDelDia(array $s, int $dow): int
    {
        foreach ($s['cajeros'] as $c) {
            if (in_array($dow, $c['agenda'], true)) {
                return $c['id'];
            }
        }
        return $s['gerente'];
    }

    private function festivo(DateTimeImmutable $d): float
    {
        $mes = (int) $d->format('n');
        $dia = (int) $d->format('j');
        $lunes = $d->format('N') === '1';
        return match (true) {
            $mes === 11 && $lunes && $dia >= 15 && $dia <= 21 => 1.35,   // Revolución, tercer lunes
            $mes === 2 && $lunes && $dia <= 7 => 1.3,                    // Constitución, primer lunes
            $mes === 3 && $lunes && $dia >= 15 && $dia <= 21 => 1.3,     // Natalicio de Juárez
            in_array($d->format('m-d'), ['11-02', '09-16', '12-12', '05-01', '01-01'], true) => 1.25,
            default => 1.0,
        };
    }

    // ── Planeación de cuentas ───────────────────────────────────────────────

    private function planea(int $suc, array $s, DateTimeImmutable $dia, int $n, int $cajero, array $reservas): array
    {
        $az = $this->azar;
        $cero = $dia->getTimestamp();
        $dow = (int) $dia->format('N');
        $esHoy = $dia == $this->hoy;
        $factor = $this->festivo($dia) * [0.97, 1.0, 1.03, 1.05][min(3, intdiv($n, 7))] * max(0.75, $az->normal(1, 0.09));
        $total = (int) round($s['demanda'][$dow - 1] * $factor);

        $meseros = array_values(array_filter($s['meseros'], static fn ($m) => $m['agenda'] !== $dow));
        $areas = array_keys($s['areas']);
        $porArea = [];
        foreach ($meseros as $k => $m) {
            $porArea[$areas[$k % count($areas)]][] = $m['id'];
        }
        $todos = array_column($meseros, 'id');
        $menu = array_diff_key($s['platillos'], $esHoy ? array_flip($s['agotados']) : []);

        $ocupacion = [];
        $planes = [];
        foreach ($reservas as $r) {
            if ($r['estado'] === 'confirmada') {
                $ocupacion[$r['mesa']][] = [$r['desde'] - 45 * 60, $r['hasta'] + 30 * 60];
            } elseif ($r['estado'] === 'atendida') {
                $mesa = $s['mesas'][$r['mesa']];
                $plan = $this->planMesa($suc, $menu, $r['llegada'], $r['llegan']);
                $plan['mesa'] = $mesa;
                $plan['mesero'] = $az->elige($porArea[$mesa['id_area']] ?? $todos);
                $ocupacion[$mesa['id']][] = [$r['desde'] - 45 * 60, $plan['libre']];
                $planes[] = $plan;
            }
        }

        $llegadas = [];
        for ($k = 0; $k < $total; $k++) {
            $llegadas[] = $this->llegada($cero, $dow);
        }
        sort($llegadas);
        foreach ($llegadas as $t) {
            $tipo = $az->pondera(['mesa' => 82, 'llevar' => 12, 'domicilio' => 6]);
            if ($tipo !== 'mesa') {
                $planes[] = $this->planPedido($suc, $menu, $t, $tipo, $cajero);
                continue;
            }
            $personas = (int) $az->pondera([1 => 6, 2 => 30, 3 => 16, 4 => 26, 5 => 8, 6 => 8, 7 => 2, 8 => 2, 9 => 1, 10 => 1]);
            $plan = $this->planMesa($suc, $menu, $t, $personas);
            $mesa = $this->buscaMesa($s, $ocupacion, $t, $plan['libre'], $personas);
            if ($mesa === null) {
                continue;   // No había mesa: se fueron a otro lado.
            }
            $plan['mesa'] = $mesa;
            $plan['mesero'] = $az->elige($porArea[$mesa['id_area']] ?? $todos);
            $ocupacion[$mesa['id']][] = [$t, $plan['libre']];
            $planes[] = $plan;
        }
        return $planes;
    }

    private function llegada(int $cero, int $dow): int
    {
        $finDeSemana = $dow >= 6;
        $minuto = $this->azar->prob($finDeSemana ? 0.78 : 0.7)
            ? $this->azar->normal($finDeSemana ? 14 * 60 + 20 : 14 * 60 + 45, 65)
            : $this->azar->normal(19 * 60 + 10, 45);
        $minuto = max(12 * 60 + 5, min(20 * 60 + 40, $minuto));
        return $cero + (int) round($minuto * 60) + $this->azar->entero(0, 59);
    }

    private function buscaMesa(array $s, array $ocupacion, int $desde, int $hasta, int $personas): ?array
    {
        $candidatas = [];
        foreach ($s['mesas'] as $m) {
            if ($m['estado'] === 'bloqueada' || $m['capacidad'] < $personas) {
                continue;
            }
            foreach ($ocupacion[$m['id']] ?? [] as [$a, $b]) {
                if ($desde < $b && $a < $hasta) {
                    continue 2;
                }
            }
            $candidatas[] = $m;
        }
        if ($candidatas === []) {
            return null;
        }
        $minima = min(array_column($candidatas, 'capacidad'));
        return $this->azar->elige(array_values(array_filter($candidatas, static fn ($m) => $m['capacidad'] <= $minima + 2)));
    }

    /** Una mesa: bebidas y entradas, luego los fuertes, a veces otra ronda y postre. */
    private function planMesa(int $suc, array $menu, int $t0, int $personas): array
    {
        $az = $this->azar;
        $rondas = [];
        $primera = [...$this->bebidas($menu, $personas, 0.85), ...$this->entradas($menu, $personas)];
        if ($primera !== []) {
            $rondas[] = ['t' => $t0 + $az->entero(180, 480), 'items' => $primera];
        }
        if ($az->prob(0.93)) {
            $fuertes = $this->fuertes($menu, $personas);
            if ($az->prob(0.2)) {
                array_push($fuertes, ...$this->entradas($menu, 1));
            }
            if ($fuertes !== []) {
                $rondas[] = ['t' => $t0 + $az->entero(14 * 60, 26 * 60), 'items' => $fuertes];
            }
        }
        if ($az->prob($personas >= 2 ? 0.5 : 0.3)) {
            $tercera = $this->bebidas($menu, $personas, 0.5);
            if ($az->prob(0.3)) {
                array_push($tercera, ...$this->linea($menu, $this->elige($menu, ['postre']), $az->entero(1, 2), 'fuerte'));
            }
            if ($tercera !== []) {
                $rondas[] = ['t' => $t0 + $az->entero(42 * 60, 65 * 60), 'items' => $tercera];
            }
        }
        $servido = $t0;
        foreach ($rondas as &$r) {
            $this->cocina($r, true);
            foreach ($r['items'] as $it) {
                $servido = max($servido, $it['entrega'] ?? $it['cancela']);
            }
        }
        unset($r);

        $estancia = (int) round((45 + 7 * $personas + $az->normal(0, 10)) * 60);
        $precuenta = max($t0 + $estancia, $servido + $az->entero(15 * 60, 30 * 60));
        $pago = $precuenta + $az->entero(4 * 60, 12 * 60);
        $plan = ['suc' => $suc, 'tipo' => 'mesa', 'abre' => $t0, 'personas' => $personas, 'rondas' => $rondas, 'sueltos' => [],
            'precuenta' => $precuenta, 'pago' => $pago, 'libre' => $pago + $az->entero(4 * 60, 10 * 60), 'cancela' => null,
            'entregas' => [], 'cliente' => null, 'telefono' => null, 'direccion' => null, 'repartidor' => null,
            'descuento' => $az->prob(0.03)];
        // A veces se abre una mesa por error y se cancela sin pedir nada. Lo
        // mismo si al final no quedó nada vivo: sin platillos no se cobra.
        $vivos = array_filter(array_merge(...array_column($rondas, 'items')), static fn ($it) => $it['cancela'] === null);
        if ($vivos === [] || $az->prob(0.006)) {
            $plan['rondas'] = $vivos === [] ? $rondas : [];
            $plan['precuenta'] = null;
            $plan['pago'] = null;
            $plan['cancela'] = max($servido, $t0) + $az->entero(120, 600);
            $plan['libre'] = $plan['cancela'];
        }
        return $plan;
    }

    /** Para llevar o a domicilio: una sola ronda, la abre y la cobra la caja. */
    private function planPedido(int $suc, array $menu, int $t0, string $tipo, int $cajero): array
    {
        $az = $this->azar;
        $items = [];
        for ($k = $az->entero(1, 4); $k > 0; $k--) {
            array_push($items, ...$this->linea($menu, $this->elige($menu, ['fuerte']), 1, 'fuerte'));
        }
        for ($k = $az->entero(0, 2); $k > 0; $k--) {
            array_push($items, ...$this->linea($menu, $this->elige($menu, ['entrada']), 1, 'fuerte'));
        }
        array_push($items, ...$this->bebidas($menu, $az->entero(0, 3), 0.8));
        $items = $this->junta($items);
        $plan = ['suc' => $suc, 'tipo' => $tipo, 'abre' => $t0, 'personas' => 0, 'rondas' => [], 'sueltos' => [],
            'precuenta' => null, 'pago' => null, 'libre' => null, 'cancela' => null, 'entregas' => [],
            'cliente' => $az->elige(self::NOMBRES) . ' ' . $az->elige(self::APELLIDOS),
            'telefono' => $tipo === 'domicilio' || $az->prob(0.6) ? $this->telefono() : null,
            'direccion' => $tipo === 'domicilio' ? $az->elige(self::DIRECCIONES[$suc]) : null,
            'repartidor' => $tipo === 'domicilio' ? $az->elige(self::REPARTIDORES[$suc]) : null,
            'mesa' => null, 'mesero' => $cajero, 'descuento' => false];

        if ($az->prob(0.03)) {
            // El cliente canceló antes de que se mandara a cocina.
            $plan['cancela'] = $t0 + $az->entero(120, 360);
            foreach ($items as $it) {
                $plan['sueltos'][] = $it + ['cancela' => $plan['cancela'], 'motivo' => 'El cliente canceló el pedido'];
            }
            $plan['entregas'] = [['cancelado', $plan['cancela']]];
            return $plan;
        }
        $ronda = ['t' => $t0 + $az->entero(120, 300), 'items' => $items];
        $this->cocina($ronda, false);
        $plan['rondas'] = [$ronda];
        $listo = max(array_map(static fn ($it) => $it['listo'], $ronda['items'])) + 60;
        $plan['entregas'] = [['preparando', $ronda['t'] + 60], ['listo', $listo]];
        if ($tipo === 'llevar') {
            $plan['pago'] = $listo + $az->entero(3 * 60, 15 * 60);
            $plan['entregas'][] = ['entregado', $plan['pago'] + 60];
        } else {
            $plan['pago'] = $listo + $az->entero(60, 240);
            $camino = $plan['pago'] + $az->entero(60, 180);
            $plan['entregas'][] = ['en_camino', $camino];
            $plan['entregas'][] = ['entregado', $camino + $az->entero(12 * 60, 30 * 60)];
        }
        foreach ($plan['rondas'][0]['items'] as &$it) {
            $it['entrega'] = $listo + $az->entero(10, 90);
        }
        unset($it);
        return $plan;
    }

    /** Tiempos de cocina: cada área de la ronda avanza junta, como en la pantalla. */
    private function cocina(array &$ronda, bool $puedeCancelar): void
    {
        $az = $this->azar;
        $hora = (int) date('G', $ronda['t']);
        $dow = (int) date('N', $ronda['t']);
        $carga = ($hora >= 14 && $hora <= 16 ? 1.25 : 1.0) + ($dow >= 6 ? 0.1 : 0.0);
        $base = ['barra' => [3.0, 1.2], 'fria' => [9.0, 2.5], 'caliente' => [17.0, 4.5]];
        $tiempos = [];
        foreach ($ronda['items'] as $it) {
            if (!isset($tiempos[$it['prep']])) {
                $prepara = $ronda['t'] + $az->entero(30, 180);
                $minutos = max(1.5, $az->normal(...$base[$it['prep']])) * $carga;
                $tiempos[$it['prep']] = [$prepara, $prepara + (int) round($minutos * 60)];
            }
        }
        foreach ($ronda['items'] as &$it) {
            [$prepara, $listo] = $tiempos[$it['prep']];
            $it['prepara'] = $prepara;
            $it['listo'] = $listo;
            $it['entrega'] = $listo + $az->entero(40, 240);
            $it['cancela'] = null;
            $it['motivo'] = null;
            if ($puedeCancelar && $az->prob(0.018) && $prepara - $ronda['t'] > 60) {
                $it['cancela'] = $ronda['t'] + $az->entero(45, $prepara - $ronda['t'] - 5);
                $it['motivo'] = $az->elige(self::MOTIVOS);
                $it['entrega'] = null;
            }
        }
        unset($it);
    }

    private function elige(array $menu, array $grupos): int
    {
        $pesos = [];
        foreach (array_keys($menu) as $id) {
            $p = $this->cat['platillos'][$id];
            if (in_array($p['grupo'], $grupos, true)) {
                $pesos[$id] = $p['peso'];
            }
        }
        return (int) $this->azar->pondera($pesos);
    }

    /** Un renglón de cuenta con sus modificadores y, a veces, una nota. */
    private function linea(array $menu, int $platillo, int $cantidad, string $tiempo): array
    {
        $p = $this->cat['platillos'][$platillo];
        $mods = [];
        $precio = $menu[$platillo];
        if ($p['modificadores'] !== [] && $this->azar->prob(0.15)) {
            $m = $this->azar->elige($p['modificadores']);
            $mods[] = $m;
            $precio += $m['suplemento'];
        }
        $nota = $this->azar->prob(0.06) ? $this->azar->elige(self::NOTAS[$p['preparacion']]) : '';
        return [['platillo' => $platillo, 'nombre' => $p['nombre'], 'prep' => $p['preparacion'], 'cantidad' => $cantidad,
            'precio' => $precio, 'mods' => $mods, 'nota' => $nota, 'tiempo' => $tiempo]];
    }

    private function bebidas(array $menu, int $personas, float $probabilidad): array
    {
        $items = [];
        for ($k = 0; $k < $personas; $k++) {
            if ($this->azar->prob($probabilidad)) {
                array_push($items, ...$this->linea($menu, $this->elige($menu, ['bebida']), 1, 'fuerte'));
            }
        }
        return $this->junta($items);
    }

    private function entradas(array $menu, int $personas): array
    {
        $items = [];
        $n = $personas === 1 ? ($this->azar->prob(0.4) ? 1 : 0) : max(1, (int) round($personas / 2.3));
        for ($k = 0; $k < $n; $k++) {
            if (!$this->azar->prob(0.85)) {
                continue;
            }
            $id = $this->elige($menu, ['entrada']);
            $cantidad = str_starts_with($this->cat['platillos'][$id]['nombre'], 'Tostada')
                ? $this->azar->entero(1, max(1, min(3, $personas))) : 1;
            array_push($items, ...$this->linea($menu, $id, $cantidad, 'entrada'));
        }
        return $this->junta($items);
    }

    private function fuertes(array $menu, int $personas): array
    {
        $items = [];
        $cubiertos = 0;
        if ($personas >= 2 && $this->azar->prob(0.12)) {
            $id = $this->elige($menu, ['compartir']);
            $cubiertos = str_contains($this->cat['platillos'][$id]['nombre'], '4 personas') ? 4 : 2;
            array_push($items, ...$this->linea($menu, $id, 1, 'fuerte'));
        }
        $n = $personas === 1 ? ($this->azar->prob(0.85) ? 1 : 0) : (int) round($personas * $this->azar->real(0.6, 0.95));
        for ($k = max(0, $n - $cubiertos); $k > 0; $k--) {
            array_push($items, ...$this->linea($menu, $this->elige($menu, ['fuerte']), 1, 'fuerte'));
        }
        return $this->junta($items);
    }

    /** Lo mismo sin cambios va en un solo renglón con su cantidad. */
    private function junta(array $items): array
    {
        $juntos = [];
        foreach ($items as $it) {
            $clave = $it['mods'] === [] && $it['nota'] === '' ? $it['platillo'] . '|' . $it['tiempo'] : null;
            if ($clave !== null && isset($juntos[$clave])) {
                $juntos[$clave]['cantidad'] += $it['cantidad'];
                continue;
            }
            $juntos[$clave ?? 'u' . count($juntos)] = $it;
        }
        return array_values($juntos);
    }

    private function telefono(): string
    {
        return '222 ' . $this->azar->entero(200, 899) . ' ' . str_pad((string) $this->azar->entero(0, 9999), 4, '0', STR_PAD_LEFT);
    }

    // ── Escritura de una cuenta ─────────────────────────────────────────────

    /** Escribe la cuenta como estaba en el corte. Devuelve su cobro, si ya se cobró. */
    private function escribeCuenta(array $p, array $turno): ?array
    {
        $c = $this->corte;
        $s = $this->cat['sucursales'][$p['suc']];
        $eventos = [];
        $renglones = [];
        $total = 0;

        foreach ($p['sueltos'] as $it) {
            $renglones[] = $this->renglon($it, null, null, $p, $s);
            $eventos[] = $it['cancela'] - 30;
            if ($it['cancela'] <= $c) {
                $eventos[] = $it['cancela'];
            }
        }
        foreach ($p['rondas'] as $r) {
            if (!isset($r['id'])) {
                continue;
            }
            $this->sql->agrega('ronda', ['id' => $r['id'], 'id_cuenta' => $p['id'], 'id_usuario' => $p['mesero'],
                'enviada_en' => demo_fecha($r['t'])]);
            $eventos[] = $r['t'];
            $comandas = [];
            $areas = [];
            foreach ($r['items'] as $it) {
                $eventos[] = $r['t'] - 20;   // capturado
                $renglones[] = $this->renglon($it, $r['id'], $r['t'], $p, $s);
                $comandas[$it['prep']][] = $it['cantidad'] . ' x ' . $it['nombre'];
                foreach ($it['mods'] as $m) {
                    $comandas[$it['prep']][] = '  ' . $m['nombre'];
                }
                if ($it['nota'] !== '') {
                    $comandas[$it['prep']][] = '  ' . $it['nota'];
                }
                if ($it['cancela'] !== null && $it['cancela'] <= $c) {
                    $eventos[] = $it['cancela'];
                    continue;
                }
                $areas[$it['prep']] = [$it['prepara'], $it['listo']];
                if ($it['entrega'] <= $c) {
                    $eventos[] = $it['entrega'];
                }
                $total += $it['precio'] * $it['cantidad'];
            }
            foreach ($areas as [$prepara, $listo]) {
                array_push($eventos, ...array_filter([$prepara, $listo], static fn ($t) => $t <= $c));
            }
            $origen = $p['mesa'] === null ? ucfirst($p['tipo']) . ' #' . $p['id'] : 'Mesa ' . $p['mesa']['numero'];
            foreach ($comandas as $area => $lineas) {
                $this->imprime($r['t'], $p['suc'], $area, 'comanda', $r['id'], [$origen . ' · Ronda #' . $r['id'], self::AREAS[$area], ...$lineas]);
            }
        }

        $pagada = $p['pago'] !== null && $p['pago'] <= $c;
        $cancelada = $p['cancela'] !== null && $p['cancela'] <= $c;
        $pedida = $p['precuenta'] !== null && $p['precuenta'] <= $c;
        if ($pedida) {
            $eventos[] = $p['precuenta'];
        }
        if ($pagada) {
            $eventos[] = $p['pago'];
        }
        if ($cancelada && $p['tipo'] === 'mesa') {
            $eventos[] = $p['cancela'];
        }
        $entrega = $p['tipo'] === 'mesa' ? null : 'recibido';
        $repartidor = null;
        foreach ($p['entregas'] as [$estado, $t]) {
            if ($t <= $c) {
                $entrega = $estado;
                $eventos[] = $t;
                if ($estado === 'en_camino') {
                    $repartidor = $p['repartidor'];
                }
            }
        }
        $abierta = !$pagada && !$cancelada;
        $cerrada = $pagada ? $p['pago'] : ($cancelada ? $p['cancela'] : null);

        $this->sql->agrega('cuenta', [
            'id' => $p['id'], 'id_sucursal' => $p['suc'], 'id_mesa' => $p['mesa']['id'] ?? null, 'id_mesero' => $p['mesero'],
            'tipo' => $p['tipo'], 'estado' => $cancelada ? 'cancelada' : ($pagada ? 'pagada' : ($pedida ? 'cuenta_pedida' : 'ocupada')),
            'abierta' => $abierta ? 1 : null, 'version' => 1 + count(array_filter($eventos, static fn ($t) => $t <= $c)),
            'abierta_en' => demo_fecha($p['abre']), 'cerrada_en' => $cerrada === null ? null : demo_fecha($cerrada),
            'cliente' => $p['cliente'], 'telefono' => $p['telefono'], 'direccion' => $p['direccion'],
            'repartidor' => $repartidor ?? ($entrega === 'entregado' ? $p['repartidor'] : null), 'entrega' => $entrega,
        ]);
        if ($p['mesa'] !== null) {
            $this->sql->agrega('cuenta_mesa', ['id' => ++$this->ids['cuenta_mesa'], 'id_sucursal' => $p['suc'], 'id_cuenta' => $p['id'],
                'id_mesa' => $p['mesa']['id'], 'abierta' => $abierta ? 1 : null]);
            if ($pagada && $p['libre'] > $c) {
                $this->mesaHoy[$p['mesa']['id']] = 'por_limpiar';
            }
        }
        foreach ($renglones as $r) {
            $this->sql->agrega('cuenta_item', $r);
        }
        if ($abierta) {
            $this->resumen['abiertas']++;
        }

        $vivos = array_values(array_filter(array_merge(...array_map(static fn ($r) => isset($r['id']) ? $r['items'] : [], $p['rondas'])),
            static fn ($it) => $it['cancela'] === null || $it['cancela'] > $c));
        if ($pedida) {
            $lineas = ['PRECUENTA #' . $p['id']];
            foreach ($vivos as $it) {
                $lineas[] = $it['cantidad'] . ' x ' . $it['nombre'] . ' $' . demo_pesos($it['precio']);
            }
            $lineas[] = 'Total: $' . demo_pesos($total);
            $this->imprime($p['precuenta'], $p['suc'], 'caja', 'precuenta', $p['id'], $lineas);
        }
        if (!$pagada) {
            return null;
        }
        return ['t' => $p['pago'], 'suc' => $p['suc'], 'cuenta' => $p['id'], 'tipo' => $p['tipo'], 'total' => $total,
            'items' => $vivos, 'descuento' => $p['descuento'], 'personas' => $p['personas'], 'gerente' => $s['gerente']];
    }

    /** El renglón de `cuenta_item` en el estado que tenía al corte. */
    private function renglon(array $it, ?int $ronda, ?int $enviada, array $p, array $s): array
    {
        $c = $this->corte;
        $cancelado = $it['cancela'] !== null && $it['cancela'] <= $c;
        [$estado, $en] = match (true) {
            $cancelado => ['cancelado', $it['cancela']],
            $ronda === null => ['capturado', $c],
            $it['entrega'] <= $c => ['entregado', $it['entrega']],
            $it['listo'] <= $c => ['listo', $it['listo']],
            $it['prepara'] <= $c => ['en_preparacion', $it['prepara']],
            default => ['enviado', $enviada],
        };
        $preparado = !$cancelado && $ronda !== null && $it['prepara'] <= $c ? $it['prepara'] : null;
        $listo = !$cancelado && $ronda !== null && $it['listo'] <= $c ? $it['listo'] : null;
        return [
            'id' => $it['id'], 'id_cuenta' => $p['id'], 'id_ronda' => $ronda, 'id_platillo' => $it['platillo'],
            'platillo' => $it['nombre'], 'preparacion' => $it['prep'], 'cantidad' => $it['cantidad'],
            'precio' => demo_pesos($it['precio']),
            'modificadores' => json_encode(array_map(static fn ($m) => ['id' => $m['id'], 'nombre' => $m['nombre'],
                'suplemento' => demo_pesos($m['suplemento'])], $it['mods']), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
            'nota' => $it['nota'], 'tiempo' => $it['tiempo'], 'asiento' => null, 'estado' => $estado,
            'estado_en' => demo_fecha($en), 'preparado_en' => $preparado === null ? null : demo_fecha($preparado),
            'listo_en' => $listo === null ? null : demo_fecha($listo),
            // Cancelar algo ya enviado lo firma la gerencia; lo capturado, no.
            'cancelado_por' => $cancelado && $ronda !== null ? $s['gerente'] : null,
            'motivo' => $cancelado ? $it['motivo'] : null,
        ];
    }

    /** Escribe el cobro y devuelve el efectivo que entró a la caja. */
    private function escribePago(array $cobro, array $turno): int
    {
        $az = $this->azar;
        $id = ++$this->ids['pago'];
        $descuento = $cobro['descuento'] ? intdiv($cobro['total'] * 10, 100 * 100) * 100 : 0;
        $neto = $cobro['total'] - $descuento;
        $propina = 0;
        if ($cobro['tipo'] === 'mesa' && $az->prob(0.88)) {
            $propina = (int) round($neto * (int) $az->pondera([10 => 35, 12 => 15, 15 => 35, 18 => 5, 20 => 10]) / 100 / 100) * 100;
        } elseif ($cobro['tipo'] === 'llevar' && $az->prob(0.15)) {
            $propina = $az->entero(1, 3) * 1000;
        }
        $pagado = $neto + $propina;
        $medios = $cobro['tipo'] === 'domicilio'
            ? ['efectivo' => 60, 'transferencia' => 40] : ['efectivo' => 38, 'tarjeta' => 52, 'transferencia' => 10];
        $formas = [];
        if ($cobro['tipo'] === 'mesa' && $cobro['personas'] >= 3 && $az->prob(0.08)) {
            $primera = (int) round($pagado * $az->real(0.35, 0.65) / 100) * 100;
            $formas[] = [(string) $az->pondera(['efectivo' => 40, 'tarjeta' => 60]), $primera];
            $formas[] = ['tarjeta', $pagado - $primera];
        } else {
            $formas[] = [(string) $az->pondera($medios), $pagado];
        }
        $this->sql->agrega('pago_cuenta', [
            'id' => $id, 'id_cuenta' => $cobro['cuenta'], 'id_turno' => $turno['id'], 'id_cajero' => $turno['cajero'],
            'total' => demo_pesos($neto), 'propina' => demo_pesos($propina), 'descuento' => demo_pesos($descuento),
            'descuento_autorizado_por' => $descuento > 0 ? $cobro['gerente'] : null, 'token_publico' => $az->hex(16),
            'pagado_en' => demo_fecha($cobro['t']),
        ]);
        $efectivo = 0;
        foreach ($formas as [$medio, $importe]) {
            $this->sql->agrega('pago_cuenta_forma', ['id' => ++$this->ids['forma'], 'id_pago' => $id, 'medio' => $medio,
                'importe' => demo_pesos($importe), 'referencia' => match ($medio) {
                    'efectivo' => null,
                    'tarjeta' => 'Aut. ' . str_pad((string) $az->entero(0, 999999), 6, '0', STR_PAD_LEFT),
                    default => 'SPEI ' . $az->entero(1000000, 9999999),
                }]);
            if ($medio === 'efectivo') {
                $efectivo += $importe;
            }
        }
        $lineas = array_map(static fn ($it) => $it['cantidad'] . ' x ' . $it['nombre'] . ' $' . demo_pesos($it['precio']), $cobro['items']);
        $this->imprime($cobro['t'], $cobro['suc'], 'caja', 'ticket', $id, ['TICKET #' . $id, ...$lineas, 'Venta: $' . demo_pesos($neto),
            'Propina: $' . demo_pesos($propina), 'Pagado: $' . demo_pesos($pagado)]);

        $platillos = [];
        foreach ($cobro['items'] as $it) {
            $platillos[$it['platillo']] = ($platillos[$it['platillo']] ?? 0) + $it['cantidad'];
        }
        $this->consumos[$cobro['suc']][] = [$cobro['t'], $cobro['cuenta'], $turno['cajero'], $platillos];
        $this->resumen['ventas'][$cobro['suc']] = ($this->resumen['ventas'][$cobro['suc']] ?? 0) + $neto;
        $this->resumen['cuentas'][$cobro['suc']] = ($this->resumen['cuentas'][$cobro['suc']] ?? 0) + 1;
        return $efectivo;
    }

    // ── Caja y gastos ───────────────────────────────────────────────────────

    /**
     * Movimientos de caja y gastos del día. Los gastos pagados con efectivo de
     * la caja salen como asiento del turno, como los registra la pantalla.
     */
    private function planeaCaja(int $suc, array $s, int $cero, int $dow, int $n, array $turno, array $efectivo, array &$asientos, array &$gastos): void
    {
        $az = $this->azar;
        $prov = $s['proveedores'];
        $enCaja = function (int $t, string $concepto, int $importe, ?array $gasto) use ($suc, $turno, &$asientos): void {
            if ($t <= $this->corte) {
                $asientos[] = ['t' => $t, 'suc' => $suc, 'usuario' => $turno['cajero'], 'concepto' => $concepto, 'importe' => $importe,
                    'gasto' => $gasto];
            }
        };
        $gasto = function (int $t, string $concepto, int $importe, ?int $proveedor, string $comprobante) use ($suc, $s, &$gastos): void {
            if ($t <= $this->corte) {
                $gastos[] = ['t' => $t, 'suc' => $suc, 'usuario' => $s['gerente'], 'asiento' => null, 'concepto' => $concepto,
                    'importe' => $importe, 'proveedor' => $proveedor, 'comprobante' => $comprobante];
            }
        };
        $conCaja = static fn (string $concepto, int $importe, ?int $proveedor, string $comprobante): array =>
            ['concepto' => $concepto, 'importe' => $importe, 'proveedor' => $proveedor, 'comprobante' => $comprobante];

        $bolsas = $az->entero(...$s['hielo']) + ($dow >= 6 ? 2 : 0);
        $t = $turno['abre'] + $az->entero(20 * 60, 80 * 60);
        $enCaja($t, 'Hielo', -$bolsas * 3200, $conCaja('Hielo (' . $bolsas . ' bolsas)', $bolsas * 3200, $prov['hielo'], ''));
        if ($dow === 2 || $dow === 5) {
            $garrafones = $az->entero(6, 10);
            $t = $turno['abre'] + $az->entero(30 * 60, 120 * 60);
            $enCaja($t, 'Garrafones de agua', -$garrafones * 3800, $conCaja('Garrafones de agua (' . $garrafones . ')', $garrafones * 3800, null, ''));
        }
        if ($n === 6) {
            $t = $turno['abre'] + $az->entero(60 * 60, 240 * 60);
            $enCaja($t, 'Rollos para impresora', -38000, $conCaja('Rollos para impresora térmica', 38000, $prov['abarrotes'], 'Nota 2231'));
        }
        if ($suc === 2 && $n === 8) {
            $t = $turno['abre'] + $az->entero(120 * 60, 300 * 60);
            $enCaja($t, 'Plomero', -95000, $conCaja('Plomero: fuga en el baño', 95000, null, 'Recibo simple'));
        }
        if ($dow >= 5) {
            // Retiro parcial a la caja fuerte cuando ya hay mucho efectivo.
            $t = $cero + (17 * 60 + 30 + $az->entero(0, 20)) * 60;
            $antes = array_sum(array_map(static fn ($e) => $e[0] <= $t ? $e[1] : 0, $efectivo));
            if ($antes >= $s['retiro'] + 150000) {
                $enCaja($t, 'Retiro a caja fuerte', -$s['retiro'], null);
            }
        }

        $hora = fn (int $desde, int $hasta): int => $cero + $az->entero($desde * 60, $hasta * 60) * 60;
        if ($dow === 1) {
            $gasto($hora(10, 13), 'Gas LP', $az->entero($suc === 1 ? 2300 : 1500, $suc === 1 ? 2900 : 1900) * 100, $prov['gas'],
                'Factura G-' . $az->entero(10000, 99999));
        }
        if ($dow === 3) {
            $gasto($hora(10, 17), 'Productos de limpieza', $az->entero(600, 950) * 100, $prov['limpieza'], 'Nota L-' . $az->entero(1000, 9999));
        }
        if ($n === 4) {
            $gasto($hora(10, 18), 'Internet y teléfono', $suc === 1 ? 79900 : 64900, null, 'Factura en línea');
        }
        if ($n === 10) {
            $gasto($hora(9, 11), 'Fumigación mensual', $suc === 1 ? 125000 : 95000, null, 'Factura F-' . $az->entero(100, 999));
        }
        if ($n === 17) {
            $gasto($hora(10, 18), 'Luz (bimestre)', $suc === 1 ? 1438000 : 892000, null, 'Recibo CFE');
        }
        if ($suc === 1 && $n === 13) {
            $gasto($hora(11, 17), 'Reparación del refrigerador de mariscos', 345000, null, 'Nota 0912');
        }
    }

    private function cierraTurno(int $suc, int $cero, array $turno, array $efectivo, array $asientos): void
    {
        $az = $this->azar;
        $s = $this->cat['sucursales'][$suc];
        $ultimo = max([$cero + 21 * 3600, ...array_column($efectivo, 0)]);
        $cierre = $ultimo + $az->entero(15 * 60, 35 * 60);
        $abierto = $cierre > $this->corte;
        $esperado = $s['fondo'] + array_sum(array_column($efectivo, 1)) + array_sum(array_column($asientos, 'importe'));
        $diferencia = $az->prob(0.85) ? 0 : $az->elige([-5000, -2000, -1000, 1000, 2000]);
        $declarado = max(0, $esperado + $diferencia);
        $this->sql->agrega('turno_caja', [
            'id' => $turno['id'], 'id_sucursal' => $suc, 'id_cajero' => $turno['cajero'], 'abierto' => $abierto ? 1 : null,
            'fondo' => demo_pesos($s['fondo']), 'abierto_en' => demo_fecha($turno['abre']),
            'cerrado_en' => $abierto ? null : demo_fecha($cierre),
            'efectivo_declarado' => $abierto ? null : demo_pesos($declarado), 'efectivo_esperado' => $abierto ? null : demo_pesos($esperado),
        ]);
        if (!$abierto) {
            $this->imprime($cierre, $suc, 'caja', 'corte', $turno['id'], ['CORTE #' . $turno['id'],
                'Efectivo contado: $' . demo_pesos($declarado), 'Efectivo esperado: $' . demo_pesos($esperado),
                'Diferencia: $' . demo_pesos($declarado - $esperado)]);
        }
    }

    // ── Reservaciones ───────────────────────────────────────────────────────

    /** Tres semanas atrás y una adelante. Devuelve las de cada sucursal por día. */
    private function reservaciones(): array
    {
        $az = $this->azar;
        $porDia = [];
        $horas = [];
        for ($m = 13 * 60; $m <= 20 * 60; $m += 30) {
            $horas[$m] = ($m >= 14 * 60 && $m <= 15 * 60 + 30) || ($m >= 19 * 60) ? 3 : 1;
        }
        foreach ($this->cat['sucursales'] as $suc => $s) {
            $maxima = max(array_column(array_filter($s['mesas'], static fn ($m) => $m['estado'] !== 'bloqueada'), 'capacidad'));
            for ($d = -21; $d <= 7; $d++) {
                $dia = $this->hoy->modify(($d >= 0 ? '+' : '') . $d . ' days');
                $cero = $dia->getTimestamp();
                $fecha = $dia->format('Y-m-d');
                $dow = (int) $dia->format('N');
                $ocupacion = [];
                $cuantas = (int) round($s['reservas'][$dow - 1] * $this->festivo($dia) * $az->real(0.6, 1.4));
                for ($k = 0; $k < $cuantas; $k++) {
                    $desde = $cero + (int) $az->pondera($horas) * 60;
                    $hasta = $desde + 90 * 60;
                    $personas = min($maxima, (int) $az->pondera([2 => 10, 3 => 8, 4 => 22, 5 => 12, 6 => 18, 7 => 6, 8 => 10, 9 => 3,
                        10 => 5, 11 => 2, 12 => 2]));
                    $llegada = $desde + $az->entero(-5 * 60, 12 * 60);
                    $paso = $llegada <= $this->corte;
                    $estado = $paso ? ($az->prob(0.84) ? 'atendida' : 'cancelada') : ($az->prob(0.62) ? 'confirmada' : 'solicitada');
                    $mesa = null;
                    if ($estado === 'atendida' || $estado === 'confirmada') {
                        $mesa = $this->buscaMesa($s, $ocupacion, $desde - 120 * 60, $hasta + 60 * 60, $personas);
                        if ($mesa === null) {
                            $estado = $paso ? 'cancelada' : 'solicitada';
                        } else {
                            $ocupacion[$mesa['id']][] = [$desde - 120 * 60, $hasta + 60 * 60];
                        }
                    }
                    $creada = $desde - $az->entero(4 * 3600, 6 * 86400);
                    if ($creada > $this->corte) {
                        $creada = $this->corte - $az->entero(600, 4 * 86400);
                    }
                    $creada = min($creada, $desde - 1800);
                    $r = ['suc' => $suc, 'mesa' => $mesa['id'] ?? null, 'cliente' => $az->elige(self::NOMBRES) . ' ' . $az->elige(self::APELLIDOS),
                        'telefono' => $this->telefono(), 'personas' => $personas, 'desde' => $desde, 'hasta' => $hasta,
                        'estado' => $estado, 'creada' => $creada, 'llegada' => $llegada,
                        'llegan' => max(1, $personas - ($az->prob(0.15) ? 1 : 0))];
                    $this->reservas[] = $r;
                    $porDia[$suc][$fecha][] = $r;
                }
            }
        }
        return $porDia;
    }

    private function escribeReservaciones(): void
    {
        usort($this->reservas, static fn ($a, $b) => [$a['creada'], $a['suc'], $a['desde']] <=> [$b['creada'], $b['suc'], $b['desde']]);
        foreach ($this->reservas as $i => $r) {
            $this->sql->agrega('reservacion', ['id' => $i + 1, 'id_sucursal' => $r['suc'], 'id_mesa' => $r['mesa'],
                'cliente' => $r['cliente'], 'telefono' => $r['telefono'], 'personas' => $r['personas'], 'desde' => demo_fecha($r['desde']),
                'hasta' => demo_fecha($r['hasta']), 'estado' => $r['estado'], 'creada_en' => demo_fecha($r['creada'])]);
        }
    }

    private function escribeMesas(): void
    {
        foreach ($this->cat['sucursales'] as $suc => $s) {
            foreach ($s['mesas'] as $m) {
                $this->sql->agrega('mesa', ['id' => $m['id'], 'id_sucursal' => $suc, 'id_area' => $m['id_area'], 'numero' => $m['numero'],
                    'capacidad' => $m['capacidad'], 'forma' => $m['forma'], 'x' => $m['x'], 'y' => $m['y'],
                    'estado' => $this->mesaHoy[$m['id']] ?? $m['estado']]);
            }
        }
    }

    // ── Impresión ───────────────────────────────────────────────────────────

    private function imprime(int $t, int $suc, string $destino, string $tipo, int $entidad, array $lineas): void
    {
        $this->trabajos[] = ['t' => $t, 'suc' => $suc, 'destino' => $destino, 'tipo' => $tipo, 'entidad' => $entidad,
            'contenido' => implode("\n", $lineas)];
    }

    private function escribeTrabajos(): void
    {
        $az = $this->azar;
        $lista = [];
        foreach ($this->trabajos as $k => $t) {
            $t['orden'] = $k;
            $lista[] = $t;
            // De vez en cuando se acaba el papel: falla y se reimprime.
            if ($az->prob(0.003) && $t['t'] + 300 < $this->corte) {
                $lista[array_key_last($lista)]['falla'] = true;
                $lista[] = ['t' => $t['t'] + $az->entero(60, 180), 'orden' => $k + 0.5, 'reimprime' => $k] + $t;
            }
        }
        usort($lista, static fn ($a, $b) => [$a['t'], $a['orden']] <=> [$b['t'], $b['orden']]);
        $ids = [];
        foreach ($lista as $i => $t) {
            $id = $i + 1;
            if (!isset($t['reimprime'])) {
                $ids[$t['orden']] = $id;
            }
            $s = $this->cat['sucursales'][$t['suc']];
            $fin = min($this->corte, $t['t'] + $az->entero(2, 6));
            $this->sql->agrega('trabajo_impresion', [
                'id' => $id, 'id_sucursal' => $t['suc'], 'id_impresora' => $s['impresoras'][$t['destino']], 'tipo' => $t['tipo'],
                'entidad' => $t['entidad'], 'contenido' => isset($t['reimprime']) ? "REIMPRESION\n" . $t['contenido'] : $t['contenido'],
                'estado' => isset($t['falla']) ? 'fallido' : 'impreso', 'id_equipo' => $s['impresor'],
                'arrendado_hasta' => demo_fecha($t['t'] + 30), 'creado_en' => demo_fecha($t['t']), 'terminado_en' => demo_fecha($fin),
                'id_original' => isset($t['reimprime']) ? $ids[$t['reimprime']] : null,
            ]);
        }
    }

    // ── Inventario ──────────────────────────────────────────────────────────

    private function inventario(): void
    {
        $compras = [];
        $lotes = [];
        $kardex = [];
        foreach ($this->cat['sucursales'] as $suc => $s) {
            $this->inventarioSucursal($suc, $s, $compras, $lotes, $kardex);
        }
        usort($compras, static fn ($a, $b) => [$a['creada'], $a['clave']] <=> [$b['creada'], $b['clave']]);
        $idLinea = 0;
        $lineas = [];
        foreach ($compras as $i => $c) {
            $this->sql->agrega('compra_insumo', ['id' => $i + 1, 'id_sucursal' => $c['suc'], 'id_proveedor' => $c['proveedor'],
                'id_usuario' => $c['usuario'], 'referencia' => $c['referencia'], 'estado' => $c['estado'],
                'creada_en' => demo_fecha($c['creada']), 'recibida_en' => $c['recibida'] === null ? null : demo_fecha($c['recibida'])]);
            foreach ($c['lineas'] as $l) {
                $lineas[$l['clave']] = ++$idLinea;
                $this->sql->agrega('compra_insumo_linea', ['id' => $idLinea, 'id_compra' => $i + 1, 'id_insumo' => $l['insumo'],
                    'cantidad' => demo_cantidad($l['cantidad']), 'costo' => demo_pesos($l['costo']), 'vence' => $l['vence']]);
            }
        }
        uasort($lotes, static fn ($a, $b) => [$a['creado'], $a['clave']] <=> [$b['creado'], $b['clave']]);
        $idsLote = [];
        $id = 0;
        foreach ($lotes as $clave => $l) {
            $idsLote[$clave] = ++$id;
            $this->sql->agrega('lote_insumo', ['id' => $id, 'id_insumo' => $l['insumo'], 'id_compra_linea' => $lineas[$l['linea']],
                'vence' => $l['vence'], 'saldo' => demo_cantidad($l['saldo']), 'costo' => demo_pesos($l['costo']),
                'creado_en' => demo_fecha($l['creado'])]);
        }
        usort($kardex, static fn ($a, $b) => [$a['t'], $a['orden']] <=> [$b['t'], $b['orden']]);
        foreach ($kardex as $i => $k) {
            $this->sql->agrega('kardex_insumo', ['id' => $i + 1, 'id_lote' => $idsLote[$k['lote']], 'id_usuario' => $k['usuario'],
                'id_cuenta' => $k['cuenta'], 'tipo' => $k['tipo'], 'cantidad' => demo_cantidad($k['cantidad']), 'motivo' => $k['motivo'],
                'creado_en' => demo_fecha($k['t'])]);
        }
    }

    /**
     * Compras en los días de cada proveedor, por lo que se espera vender hasta
     * la siguiente; cobros que consumen por caducidad (primero lo que vence
     * antes); merma de lo caducado y de lo que se cae; conteo los domingos.
     */
    private function inventarioSucursal(int $suc, array $s, array &$compras, array &$lotes, array &$kardex): void
    {
        $az = $this->azar;
        $meta = $this->cat['insumos'];
        $proveedores = $this->cat['proveedores'];
        $responsable = $s['almacen'];
        $orden = 0;

        // Lo que pide cada cobro, en milésimas por insumo, y lo de cada día.
        $consumos = $this->consumos[$suc];
        usort($consumos, static fn ($a, $b) => $a[0] <=> $b[0]);
        $uso = [];
        $pedidos = [];
        foreach ($consumos as [$t, $cuenta, $cajero, $platillos]) {
            $req = [];
            foreach ($platillos as $p => $cantidad) {
                foreach ($this->cat['platillos'][$p]['receta'] as $insumo => $milesimas) {
                    $req[$insumo] = ($req[$insumo] ?? 0) + $milesimas * $cantidad;
                }
            }
            $d = intdiv($t - ($this->hoy->getTimestamp() - 21 * 86400), 86400);
            foreach ($req as $insumo => $q) {
                $uso[$d][$insumo] = ($uso[$d][$insumo] ?? 0) + $q;
            }
            $pedidos[] = [$t, $cuenta, $cajero, $req];
        }
        $usoDe = static function (int $d, string $insumo) use ($uso): int {
            while ($d > 21) {
                $d -= 7;
            }
            return $uso[$d][$insumo] ?? 0;
        };

        $existencias = [];   // insumo => list de claves de lote
        $sec = 0;
        $fechaDe = fn (int $d): string => $this->hoy->modify(($d - 21 >= 0 ? '+' : '') . ($d - 21) . ' days')->format('Y-m-d');
        $usable = static fn (array $l, string $fecha): bool => $l['saldo'] > 0 && ($l['vence'] === null || $l['vence'] >= $fecha);
        $mueve = function (int $t, string $lote, int $cantidad, string $tipo, string $motivo, int $usuario, ?int $cuenta)
            use (&$kardex, &$lotes, &$orden): void {
            $lotes[$lote]['saldo'] += $cantidad;
            $kardex[] = ['t' => $t, 'orden' => $orden++, 'lote' => $lote, 'usuario' => $usuario, 'cuenta' => $cuenta, 'tipo' => $tipo,
                'cantidad' => $cantidad, 'motivo' => $motivo];
        };
        $redondea = static function (string $insumo, string $unidad, float $q): int {
            if ($q <= 0) {
                return 0;
            }
            $paso = match (true) {
                $insumo === 'Cerveza clara' || $insumo === 'Cerveza oscura' => 24000,
                $unidad === 'botella' => 12000,
                in_array($unidad, self::DISCRETAS, true) => 1000,
                $q < 3000 => 250,
                default => 500,
            };
            return (int) (ceil($q / $paso) * $paso);
        };
        $compra = function (string $grupo, int $creada, ?int $recibida, array $cantidades, int $d, string $referencia, string $estado = 'recibida')
            use ($suc, $s, $meta, $responsable, &$compras, &$lotes, &$existencias, &$sec, $fechaDe, $mueve, $az): void {
            $clave = $suc . '-' . (++$sec);
            $lineas = [];
            foreach ($cantidades as $insumo => $cantidad) {
                [, $costo, , $vida] = $meta[$insumo];
                if (in_array($grupo, ['mariscos', 'verduras'], true)) {
                    $costo = (int) round($costo * (1 + $az->normal(0, 0.03)) / ($costo >= 2000 ? 50 : 10)) * ($costo >= 2000 ? 50 : 10);
                }
                $linea = $clave . '-' . count($lineas);
                $vence = $vida === null ? null : $fechaDe($d + $vida);
                $lineas[] = ['clave' => $linea, 'insumo' => $s['insumos'][$insumo], 'cantidad' => $cantidad, 'costo' => $costo, 'vence' => $vence];
                if ($estado === 'recibida') {
                    $lotes[$linea] = ['clave' => $linea, 'insumo' => $s['insumos'][$insumo], 'linea' => $linea, 'vence' => $vence,
                        'saldo' => 0, 'costo' => $costo, 'creado' => $recibida, 'nombre' => $insumo];
                    $existencias[$insumo][] = $linea;
                    $mueve($recibida, $linea, $cantidad, 'entrada', '', $responsable, null);
                }
            }
            if ($lineas !== []) {
                $compras[] = ['clave' => $clave, 'suc' => $suc, 'proveedor' => $s['proveedores'][$grupo], 'usuario' => $responsable,
                    'referencia' => $referencia, 'estado' => $estado, 'creada' => $creada, 'recibida' => $estado === 'recibida' ? $recibida : null,
                    'lineas' => $lineas];
            }
        };
        $folio = 0;
        $prefijos = ['mariscos' => 'Factura MG-', 'verduras' => 'Nota CA-', 'abarrotes' => 'Factura AC-', 'tortilleria' => 'Nota T-',
            'bebidas' => 'Remisión EF-', 'postres' => 'Nota DL-'];
        $grupos = [];
        foreach ($s['insumos'] as $insumo => $_) {
            $grupos[$meta[$insumo][2]][] = $insumo;
        }

        for ($d = 0; $d <= 21; $d++) {
            $cero = $this->hoy->getTimestamp() - (21 - $d) * 86400;
            if ($cero > $this->corte) {
                break;
            }
            $fecha = $fechaDe($d);
            $dow = (int) date('N', $cero);
            $eventos = [['t' => $cero + 8 * 3600, 'tipo' => 'caduca']];
            foreach ($grupos as $grupo => $insumos) {
                $dias = $proveedores[$grupo][2];
                if ($d === 0 || in_array($dow, $dias, true)) {
                    $recibe = $grupo === 'tortilleria' ? $cero + $az->entero(660, 700) * 60 : $cero + $az->entero(540, 690) * 60;
                    $eventos[] = ['t' => $recibe, 'tipo' => 'compra', 'grupo' => $grupo];
                }
            }
            foreach ($pedidos as $i => $p) {
                if ($p[0] >= $cero && $p[0] < $cero + 86400) {
                    $eventos[] = ['t' => $p[0], 'tipo' => 'consumo', 'pedido' => $i];
                }
            }
            if ($az->prob(0.6)) {
                $eventos[] = ['t' => $cero + $az->entero(750, 1230) * 60, 'tipo' => 'merma'];
            }
            if ($dow === 7) {
                $eventos[] = ['t' => $cero + (21 * 60 + 55) * 60, 'tipo' => 'conteo'];
            }
            usort($eventos, static fn ($a, $b) => $a['t'] <=> $b['t']);

            foreach ($eventos as $e) {
                if ($e['t'] > $this->corte) {
                    break;
                }
                if ($e['tipo'] === 'caduca') {
                    foreach ($existencias as $insumo => $claves) {
                        foreach ($claves as $k) {
                            if ($lotes[$k]['saldo'] > 0 && $lotes[$k]['vence'] !== null && $lotes[$k]['vence'] < $fecha) {
                                $mueve($e['t'], $k, -$lotes[$k]['saldo'], 'merma', 'Producto caducado', $responsable, null);
                            }
                        }
                    }
                } elseif ($e['tipo'] === 'compra') {
                    $grupo = $e['grupo'];
                    $siguiente = $d + 1;
                    while (!in_array((int) date('N', $cero + ($siguiente - $d) * 86400), $proveedores[$grupo][2], true) && $siguiente < $d + 8) {
                        $siguiente++;
                    }
                    $fin = $fechaDe($siguiente - 1);
                    $cantidades = [];
                    foreach ($grupos[$grupo] as $insumo) {
                        $necesita = 0;
                        for ($x = $d; $x < $siguiente; $x++) {
                            $necesita += $usoDe($x, $insumo);
                        }
                        $hay = 0;
                        foreach ($existencias[$insumo] ?? [] as $k) {
                            if ($usable($lotes[$k], $fecha)) {
                                $hay += $lotes[$k]['vence'] === null || $lotes[$k]['vence'] >= $fin ? $lotes[$k]['saldo'] : intdiv($lotes[$k]['saldo'], 2);
                            }
                        }
                        $diario = $necesita / max(1, $siguiente - $d);
                        $q = $redondea($insumo, $meta[$insumo][0], $necesita * $az->real(1.15, 1.35) + 0.3 * $diario - $hay);
                        if ($q > 0) {
                            $cantidades[$insumo] = $q;
                        }
                    }
                    $creada = $cero + $az->entero(435, 510) * 60;
                    $compra($grupo, min($creada, $e['t'] - 1800), $e['t'], $cantidades, $d, $prefijos[$grupo] . (4100 + $suc * 1000 + (++$folio)));
                } elseif ($e['tipo'] === 'consumo') {
                    [$t, $cuenta, $cajero, $req] = $pedidos[$e['pedido']];
                    foreach ($req as $insumo => $falta) {
                        $disponibles = array_values(array_filter($existencias[$insumo] ?? [], fn ($k) => $usable($lotes[$k], $fecha)));
                        $total = array_sum(array_map(static fn ($k) => $lotes[$k]['saldo'], $disponibles));
                        if ($total < $falta) {
                            // Se acabó a media tarde: compra urgente al proveedor de siempre.
                            $grupo = $meta[$insumo][2];
                            $q = $redondea($insumo, $meta[$insumo][0], max(($falta - $total) * 3, $usoDe($d, $insumo) * 0.5));
                            $compra($grupo, $t - 1800, $t - 600, [$insumo => $q], $d, 'Compra urgente ' . $prefijos[$grupo] . (4100 + $suc * 1000 + (++$folio)));
                            $disponibles = array_values(array_filter($existencias[$insumo], fn ($k) => $usable($lotes[$k], $fecha)));
                        }
                        usort($disponibles, static fn ($a, $b) => [$lotes[$a]['vence'] === null, $lotes[$a]['vence'], $a]
                            <=> [$lotes[$b]['vence'] === null, $lotes[$b]['vence'], $b]);
                        foreach ($disponibles as $k) {
                            $toma = min($falta, $lotes[$k]['saldo']);
                            $mueve($t, $k, -$toma, 'consumo', '', $cajero, $cuenta);
                            $falta -= $toma;
                            if ($falta === 0) {
                                break;
                            }
                        }
                    }
                } elseif ($e['tipo'] === 'merma') {
                    $candidatos = [];
                    foreach (array_merge($grupos['mariscos'] ?? [], $grupos['verduras'] ?? []) as $insumo) {
                        foreach ($existencias[$insumo] ?? [] as $k) {
                            if ($usable($lotes[$k], $fecha) && $lotes[$k]['saldo'] >= 2000) {
                                $candidatos[] = $k;
                            }
                        }
                    }
                    if ($candidatos !== []) {
                        $k = $az->elige($candidatos);
                        $unidad = $meta[$lotes[$k]['nombre']][0];
                        $q = in_array($unidad, self::DISCRETAS, true) ? $az->entero(1, 4) * 1000 : $az->entero(30, 140) * 5;
                        $mueve($e['t'], $k, -min($q, $lotes[$k]['saldo']), 'merma', $az->elige(self::MERMAS), $responsable, null);
                    }
                } else {
                    $nombres = array_keys(array_filter($existencias, fn ($claves) => array_filter($claves, fn ($k) => $usable($lotes[$k], $fecha)) !== []));
                    foreach (array_slice($az->mezcla($nombres), 0, 5) as $insumo) {
                        $vivos = array_values(array_filter($existencias[$insumo], fn ($k) => $usable($lotes[$k], $fecha)));
                        $k = end($vivos);
                        $saldo = $lotes[$k]['saldo'];
                        $delta = (int) round($saldo * $az->real(-0.03, 0.01));
                        if (in_array($meta[$insumo][0], self::DISCRETAS, true)) {
                            $delta = (int) round($delta / 1000) * 1000;
                        }
                        $delta = max(-$saldo, $delta);
                        if ($delta !== 0) {
                            $mueve($e['t'], $k, $delta, 'conteo', 'Conteo semanal', $responsable, null);
                        }
                    }
                }
            }
        }

        // Una orden que llega mañana y una que se canceló.
        $manana = $this->hoy->getTimestamp() + 11 * 3600 + $az->entero(0, 3600);
        if ($manana <= $this->corte) {
            $pide = [];
            foreach (array_slice($grupos['bebidas'] ?? [], 0, 3) as $insumo) {
                $pide[$insumo] = $redondea($insumo, $meta[$insumo][0], 30000);
            }
            $compra('bebidas', $manana, null, $pide, 21, 'Pedido para mañana', 'ordenada');
        }
        $cancelada = $this->hoy->getTimestamp() - 12 * 86400 + 8 * 3600 + $az->entero(0, 1800);
        $pide = [];
        foreach (array_slice($grupos['postres'] ?? [], 0, 2) as $insumo) {
            $pide[$insumo] = 12000;
        }
        $compra('postres', $cancelada, null, $pide, 9, 'Nota DL-duplicada', 'cancelada');
    }
}

/** @return array<string,mixed> */
function demo_opera(DemoSql $sql, DemoAzar $azar, array $cat, DateTimeImmutable $ahora): array
{
    return (new DemoOperacion($sql, $azar, $cat, $ahora))->corre();
}
