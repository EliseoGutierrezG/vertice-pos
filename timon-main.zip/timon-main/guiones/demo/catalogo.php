<?php
declare(strict_types=1);

/**
 * Pieza de `guiones/demo.php`: las herramientas de la carga y el catálogo.
 *
 * Aquí viven el azar con semilla, el escritor de SQL y todo lo que existe
 * antes de abrir el restaurante: las dos sucursales, su personal, el plano,
 * el menú con sus precios, las impresoras, los equipos, los insumos, los
 * proveedores y las recetas.
 *
 * El SQL se escribe como texto porque se importa en otra base (staging, por
 * phpMyAdmin): no hay consulta preparada donde poner parámetros. Los valores
 * son nuestros, no de nadie de fuera, y pasan todos por `DemoSql::literal()`.
 */

/** Azar con semilla: misma semilla, mismos movimientos. */
final class DemoAzar
{
    private Random\Randomizer $r;

    public function __construct(int $semilla)
    {
        $this->r = new Random\Randomizer(new Random\Engine\Mt19937($semilla));
    }

    public function entero(int $min, int $max): int
    {
        return $this->r->getInt($min, $max);
    }

    public function real(float $min = 0.0, float $max = 1.0): float
    {
        return $min + ($max - $min) * $this->r->nextFloat();
    }

    public function prob(float $p): bool
    {
        return $this->r->nextFloat() < $p;
    }

    public function normal(float $media, float $desviacion): float
    {
        $u = max(1e-12, $this->r->nextFloat());
        return $media + $desviacion * sqrt(-2 * log($u)) * cos(2 * M_PI * $this->r->nextFloat());
    }

    /** @template T @param list<T> $lista @return T */
    public function elige(array $lista): mixed
    {
        return $lista[$this->r->getInt(0, count($lista) - 1)];
    }

    /** @param array<array-key,float|int> $pesos */
    public function pondera(array $pesos): int|string
    {
        $x = $this->r->nextFloat() * array_sum($pesos);
        foreach ($pesos as $clave => $peso) {
            $x -= $peso;
            if ($x < 0) {
                return $clave;
            }
        }
        return array_key_last($pesos);
    }

    public function hex(int $bytes): string
    {
        return bin2hex($this->r->getBytes($bytes));
    }

    /** @template T @param list<T> $lista @return list<T> */
    public function mezcla(array $lista): array
    {
        return $this->r->shuffleArray($lista);
    }
}

/**
 * Junta renglones por tabla y los escribe como INSERT de varios renglones,
 * en el orden que piden las llaves foráneas.
 */
final class DemoSql
{
    public const ORDEN = [
        'sucursal', 'personal', 'usuario', 'area', 'mesa', 'categoria_menu', 'platillo', 'platillo_sucursal',
        'modificador_platillo', 'impresora', 'equipo', 'proveedor', 'insumo', 'receta_insumo', 'turno_caja',
        'reservacion', 'cuenta', 'cuenta_mesa', 'ronda', 'cuenta_item', 'pago_cuenta', 'pago_cuenta_forma',
        'asiento_caja', 'gasto_sucursal', 'compra_insumo', 'compra_insumo_linea', 'lote_insumo', 'kardex_insumo',
        'trabajo_impresion',
    ];

    /** Tablas que pueden tener renglones antes de la carga: el administrador, su persona y los equipos que pidieron alta. */
    public const CON_PREVIOS = ['personal', 'usuario', 'equipo'];

    /** @var array<string,list<string>> */
    private array $columnas = [];
    /** @var array<string,list<list<mixed>>> */
    private array $filas = [];

    /** @param array<string,mixed> $fila */
    public function agrega(string $tabla, array $fila): void
    {
        if (!in_array($tabla, self::ORDEN, true)) {
            throw new LogicException('La tabla no está en el orden de la carga: ' . $tabla);
        }
        $columnas = array_keys($fila);
        if (!isset($this->columnas[$tabla])) {
            $this->columnas[$tabla] = $columnas;
        } elseif ($this->columnas[$tabla] !== $columnas) {
            throw new LogicException('Un renglón de ' . $tabla . ' trae otras columnas');
        }
        $this->filas[$tabla][] = array_values($fila);
    }

    /** @return array<string,int> */
    public function conteos(): array
    {
        $conteos = [];
        foreach (self::ORDEN as $tabla) {
            if (isset($this->filas[$tabla])) {
                $conteos[$tabla] = count($this->filas[$tabla]);
            }
        }
        return $conteos;
    }

    /** @return Generator<int,string> */
    public function sentencias(int $tanda = 300): Generator
    {
        foreach (self::ORDEN as $tabla) {
            if (!isset($this->filas[$tabla])) {
                continue;
            }
            $filas = $this->filas[$tabla];
            // Por id: una impresión repetida apunta a la original, que va antes.
            if ($this->columnas[$tabla][0] === 'id') {
                usort($filas, static fn (array $a, array $b): int => $a[0] <=> $b[0]);
            }
            $cabeza = 'INSERT INTO `' . $tabla . '` (`' . implode('`, `', $this->columnas[$tabla]) . "`) VALUES\n";
            foreach (array_chunk($filas, $tanda) as $grupo) {
                $renglones = array_map(
                    static fn (array $f): string => '(' . implode(', ', array_map([self::class, 'literal'], $f)) . ')',
                    $grupo
                );
                yield $cabeza . implode(",\n", $renglones);
            }
        }
    }

    public static function literal(mixed $valor): string
    {
        return match (true) {
            $valor === null => 'NULL',
            is_bool($valor) => $valor ? '1' : '0',
            is_int($valor) => (string) $valor,
            is_string($valor) => "'" . strtr($valor, [
                '\\' => '\\\\', "\0" => '\\0', "\n" => '\\n', "\r" => '\\r', "'" => "\\'", "\x1a" => '\\Z',
            ]) . "'",
            // El dinero y las cantidades viajan como cadena: nunca en coma flotante.
            default => throw new LogicException('Valor sin literal SQL: ' . get_debug_type($valor)),
        };
    }

    /**
     * Revisa que la base esté lista para la carga. Devuelve por qué no, o null.
     *
     * @param array<string,int> $puestos
     */
    public static function verificaBase(Nucleo\BaseDatos $bd, array $puestos, int $primerId): ?string
    {
        foreach ($puestos as $clave => $id) {
            if ((int) $bd->valor('SELECT id FROM puesto WHERE clave = ?', [$clave]) !== $id) {
                return 'Los puestos de la base no son los del esquema 006 (' . $clave . ')';
            }
        }
        foreach (self::ORDEN as $tabla) {
            if (in_array($tabla, self::CON_PREVIOS, true)) {
                if ((int) $bd->valor('SELECT COALESCE(MAX(id), 0) FROM `' . $tabla . '`') >= $primerId) {
                    return 'Ya hay ' . $tabla . ' con id ' . $primerId . ' o mayor';
                }
                continue;
            }
            if ((int) $bd->valor('SELECT COUNT(*) FROM `' . $tabla . '`') > 0) {
                return 'La tabla ' . $tabla . ' ya tiene datos: la demostración sólo se carga en una base sin operación';
            }
        }
        return null;
    }
}

/**
 * La demostración va sin segundo factor: basta la contraseña. Es el mismo
 * cambio que hace `Modelos\Parametros::cambia()` (cierra el renglón vigente el
 * día anterior y abre el nuevo), escrito para el SQL que se importa en
 * phpMyAdmin. Se vuelve a encender en «Seguridad».
 *
 * @return list<string>
 */
function demo_sin_segundo_factor(string $desde): array
{
    $clave = DemoSql::literal(DEMO_SEGUNDO_FACTOR);
    $dia   = DemoSql::literal($desde);
    return [
        "UPDATE `parametro` SET `vigente_hasta` = DATE_SUB({$dia}, INTERVAL 1 DAY)\n"
            . "WHERE `clave` = {$clave} AND `vigente_hasta` IS NULL AND `vigente_desde` < {$dia}",
        "INSERT INTO `parametro` (`clave`, `valor`, `descripcion`, `vigente_desde`)\n"
            . "SELECT `clave`, '0', `descripcion`, {$dia} FROM `parametro` WHERE `clave` = {$clave}\n"
            . "ORDER BY `vigente_desde` DESC LIMIT 1\n"
            . "ON DUPLICATE KEY UPDATE `valor` = '0', `vigente_hasta` = NULL",
    ];
}

const DEMO_SEGUNDO_FACTOR = 'segundo_factor_web';

/** Milésimas a «12.345». */
function demo_cantidad(int $milesimas): string
{
    $signo = $milesimas < 0 ? '-' : '';
    $milesimas = abs($milesimas);
    return $signo . intdiv($milesimas, 1000) . '.' . str_pad((string) ($milesimas % 1000), 3, '0', STR_PAD_LEFT);
}

/** Centavos a «1234.50». */
function demo_pesos(int $centavos): string
{
    $signo = $centavos < 0 ? '-' : '';
    $centavos = abs($centavos);
    return $signo . intdiv($centavos, 100) . '.' . str_pad((string) ($centavos % 100), 2, '0', STR_PAD_LEFT);
}

function demo_fecha(int $momento): string
{
    return date('Y-m-d H:i:s', $momento);
}

function demo_ascii(string $texto): string
{
    return strtolower(strtr($texto, ['á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ñ' => 'n', 'Á' => 'a',
        'É' => 'e', 'Í' => 'i', 'Ó' => 'o', 'Ú' => 'u', 'Ñ' => 'n', 'ü' => 'u', ' ' => '']));
}

/**
 * Las ids de los puestos que siembra `esquema/006_datos_base.sql`. La carga
 * directa comprueba que la base las tenga así.
 */
const DEMO_PUESTOS = ['administrador' => 1, 'gerente' => 2, 'cajero' => 3, 'mesero' => 4, 'cocina' => 5, 'barra' => 6, 'almacen' => 7];

/** Personal y usuarios empiezan aquí: no chocan con el administrador ya creado. */
const DEMO_PRIMER_ID = 1001;

/**
 * Insumos: unidad, costo en centavos, proveedor, días de vida (null: no caduca).
 * Las cantidades de las recetas van en milésimas de la unidad.
 */
function demo_insumos(): array
{
    return [
        'Camarón' => ['kg', 28500, 'mariscos', 4], 'Pulpo' => ['kg', 33000, 'mariscos', 4],
        'Filete de pescado' => ['kg', 16500, 'mariscos', 4], 'Huachinango' => ['pza', 14500, 'mariscos', 3],
        'Pescado entero' => ['kg', 19000, 'mariscos', 3], 'Atún fresco' => ['kg', 39000, 'mariscos', 3],
        'Callo de hacha' => ['kg', 68000, 'mariscos', 4], 'Ostión' => ['pza', 950, 'mariscos', 3],
        'Limón' => ['kg', 3200, 'verduras', 10], 'Cebolla morada' => ['kg', 2800, 'verduras', 12],
        'Pepino' => ['kg', 2000, 'verduras', 7], 'Aguacate' => ['kg', 6800, 'verduras', 5],
        'Jitomate' => ['kg', 2600, 'verduras', 6], 'Chile serrano' => ['kg', 4200, 'verduras', 8],
        'Cilantro' => ['manojo', 900, 'verduras', 4],
        'Clamato' => ['l', 4200, 'abarrotes', null], 'Salsa negra' => ['l', 8500, 'abarrotes', null],
        'Tostada' => ['pza', 110, 'abarrotes', 30], 'Tortilla de harina' => ['pza', 320, 'abarrotes', 10],
        'Queso Oaxaca' => ['kg', 13500, 'abarrotes', 10], 'Mantequilla' => ['kg', 15000, 'abarrotes', 20],
        'Ajo' => ['kg', 9500, 'abarrotes', 30], 'Chile guajillo' => ['kg', 19000, 'abarrotes', null],
        'Arroz' => ['kg', 2900, 'abarrotes', null], 'Flor de jamaica' => ['kg', 14000, 'abarrotes', null],
        'Azúcar' => ['kg', 2700, 'abarrotes', null], 'Café molido' => ['kg', 26000, 'abarrotes', null],
        'Tortilla de maíz' => ['kg', 2200, 'tortilleria', 1],
        'Cerveza clara' => ['botella', 1750, 'bebidas', null], 'Cerveza oscura' => ['botella', 1950, 'bebidas', null],
        'Refresco' => ['botella', 1250, 'bebidas', null], 'Agua mineral' => ['botella', 1080, 'bebidas', null],
        'Flan (porción)' => ['porción', 2200, 'postres', 4], 'Pay de limón (rebanada)' => ['porción', 2600, 'postres', 4],
    ];
}

/**
 * Proveedores por grupo: nombre, contacto, días de compra (1 lunes … 7 domingo).
 * `gas`, `limpieza` y `hielo` sólo aparecen en gastos.
 */
function demo_proveedores(): array
{
    return [
        'mariscos' => ['Mariscos del Golfo', 'Pedidos: Rogelio Bautista', [2, 4, 6]],
        'verduras' => ['Frutas y Legumbres Central de Abasto', 'Bodega 114: Martha Solís', [1, 4]],
        'abarrotes' => ['Abarrotes y Desechables La Concha', 'Ventas: Gerardo Paredes', [1]],
        'tortilleria' => ['Tortillería La Guadalupana', 'Mostrador', [1, 2, 3, 4, 5, 6, 7]],
        'bebidas' => ['Depósito de Bebidas El Faro', 'Ruta 7: Samuel Ortiz', [1, 5]],
        'postres' => ['Repostería Doña Lupe', 'Guadalupe Andrade', [2, 5]],
        'gas' => ['Gas del Valle de Puebla', 'Atención a negocios', []],
        'limpieza' => ['Limpieza Total Puebla', 'Ventas: Irma Castañeda', []],
        'hielo' => ['Hielo Cristal del Valle', 'Reparto diario', []],
    ];
}

/**
 * El menú. Por platillo: nombre, preparación, precio en Centro, precio en
 * Cholula (null: no se vende ahí), peso de popularidad, foto, descripción,
 * modificadores [nombre, suplemento] y receta [insumo => milésimas].
 */
function demo_menu(): array
{
    return [
        ['Cócteles', 'entrada', [
            ['Cóctel de camarón', 'fria', 165, 175, 10, 'coctel-camaron', 'Camarón cocido en la salsa de la casa, con aguacate, cebolla morada y cilantro.',
                [['Grande', 60], ['Con aguacate extra', 25]],
                ['Camarón' => 150, 'Clamato' => 120, 'Aguacate' => 40, 'Cebolla morada' => 20, 'Cilantro' => 100, 'Limón' => 30]],
            ['Campechana', 'fria', 210, 220, 6, null, 'Camarón, pulpo y ostión en salsa roja, con aguacate y limón.',
                [['Grande', 70]],
                ['Camarón' => 120, 'Pulpo' => 80, 'Ostión' => 3000, 'Clamato' => 150, 'Aguacate' => 40, 'Cebolla morada' => 20, 'Limón' => 30]],
            ['Vuelve a la vida', 'fria', 235, 245, 4, null, 'Cóctel de mariscos surtidos con ostión fresco.',
                [],
                ['Camarón' => 120, 'Pulpo' => 100, 'Ostión' => 4000, 'Clamato' => 150, 'Aguacate' => 40, 'Limón' => 30]],
            ['Cóctel de pulpo', 'fria', 195, 205, 3, null, 'Pulpo tierno en salsa de la casa con aguacate.',
                [],
                ['Pulpo' => 150, 'Clamato' => 120, 'Aguacate' => 40, 'Cebolla morada' => 20, 'Limón' => 30]],
        ]],
        ['Aguachiles y ceviches', 'entrada', [
            ['Aguachile verde', 'fria', 195, 205, 9, 'aguachile-verde', 'Camarón crudo curtido en limón con chile serrano, pepino y cebolla morada.',
                [['Extra picante', 0], ['Sin cebolla', 0]],
                ['Camarón' => 180, 'Pepino' => 80, 'Cebolla morada' => 40, 'Chile serrano' => 20, 'Limón' => 80, 'Cilantro' => 100]],
            ['Aguachile negro', 'fria', 205, 215, 4, null, 'Camarón curtido en salsa negra con pepino y cebolla.',
                [['Extra picante', 0]],
                ['Camarón' => 180, 'Salsa negra' => 40, 'Pepino' => 60, 'Cebolla morada' => 40, 'Limón' => 60]],
            ['Ceviche de pescado', 'fria', 155, 160, 7, 'ceviche-cebolla', 'Pescado blanco en limón con jitomate, cebolla y cilantro. Con tostadas.',
                [],
                ['Filete de pescado' => 150, 'Jitomate' => 60, 'Cebolla morada' => 30, 'Cilantro' => 100, 'Limón' => 80, 'Tostada' => 3000]],
            ['Ceviche de camarón', 'fria', 175, 180, 6, 'ceviche-camaron', 'Camarón en limón con jitomate, pepino y cilantro. Con tostadas.',
                [],
                ['Camarón' => 150, 'Jitomate' => 60, 'Cebolla morada' => 30, 'Pepino' => 40, 'Limón' => 80, 'Tostada' => 3000]],
            ['Callo de hacha', 'fria', 295, null, 2, null, 'Callo de hacha en láminas con pepino, cebolla morada y salsa negra.',
                [],
                ['Callo de hacha' => 120, 'Pepino' => 50, 'Cebolla morada' => 30, 'Limón' => 40, 'Salsa negra' => 20]],
        ]],
        ['Tostadas', 'entrada', [
            ['Tostada de atún', 'fria', 95, 99, 8, 'tostada-atun', 'Atún fresco con aguacate, cebolla frita y mayonesa de chipotle.',
                [],
                ['Atún fresco' => 80, 'Tostada' => 1000, 'Aguacate' => 30, 'Cebolla morada' => 10, 'Salsa negra' => 10]],
            ['Tostada de ceviche', 'fria', 65, 69, 7, null, 'Ceviche de pescado sobre tostada de maíz.',
                [],
                ['Filete de pescado' => 60, 'Tostada' => 1000, 'Jitomate' => 30, 'Limón' => 30]],
            ['Tostada de pulpo', 'fria', 89, 92, 4, null, 'Pulpo picado con aguacate y salsa de la casa.',
                [],
                ['Pulpo' => 70, 'Tostada' => 1000, 'Aguacate' => 30]],
        ]],
        ['Ostiones', 'entrada', [
            ['Ostiones en su concha', 'fria', 190, 195, 4, 'ostiones', 'Seis ostiones frescos abiertos al momento, con limón y salsas.',
                [['Docena', 170]],
                ['Ostión' => 6000, 'Limón' => 50]],
            ['Ostiones preparados', 'fria', 230, null, 2, null, 'Seis ostiones con clamato, salsa negra y cebolla.',
                [],
                ['Ostión' => 6000, 'Clamato' => 80, 'Salsa negra' => 20, 'Limón' => 50, 'Cebolla morada' => 20]],
        ]],
        ['Camarones', 'fuerte', [
            ['Camarones a la diabla', 'caliente', 245, 255, 8, 'camarones-diabla', 'Camarón salteado en salsa de chiles secos. Con arroz.',
                [['Extra picante', 0]],
                ['Camarón' => 220, 'Chile guajillo' => 20, 'Jitomate' => 50, 'Ajo' => 10, 'Mantequilla' => 20, 'Arroz' => 80]],
            ['Camarones al ajillo', 'caliente', 245, 255, 7, 'camarones-ajillo', 'Camarón con ajo dorado y chile guajillo. Con arroz.',
                [],
                ['Camarón' => 220, 'Ajo' => 20, 'Chile guajillo' => 10, 'Mantequilla' => 30, 'Arroz' => 80]],
            ['Camarones empanizados', 'caliente', 235, 240, 5, null, 'Camarón empanizado y crujiente. Con arroz y ensalada.',
                [],
                ['Camarón' => 220, 'Arroz' => 80, 'Aguacate' => 30]],
            ['Camarones al mojo de ajo', 'caliente', 245, 255, 4, null, 'Camarón en mantequilla con ajo. Con arroz.',
                [],
                ['Camarón' => 220, 'Ajo' => 30, 'Mantequilla' => 40, 'Arroz' => 80]],
        ]],
        ['Pescados y pulpo', 'fuerte', [
            ['Pescado zarandeado (kg)', 'caliente', 420, null, 4, 'pescado-zarandeado', 'Pescado entero abierto, adobado y asado a la leña. Precio por kilo.',
                [],
                ['Pescado entero' => 1000, 'Chile guajillo' => 30, 'Tortilla de maíz' => 150, 'Cebolla morada' => 50, 'Limón' => 50]],
            ['Filete a la talla', 'caliente', 230, 235, 5, null, 'Filete adobado con chiles y asado a la plancha. Con arroz.',
                [],
                ['Filete de pescado' => 250, 'Chile guajillo' => 20, 'Arroz' => 80]],
            ['Filete empapelado', 'caliente', 235, 240, 4, 'pescado-hoja', 'Filete al vapor en papel con jitomate, cebolla y especias.',
                [],
                ['Filete de pescado' => 250, 'Jitomate' => 60, 'Cebolla morada' => 40, 'Mantequilla' => 20]],
            ['Huachinango frito', 'caliente', 340, 350, 4, null, 'Huachinango entero frito, con arroz y ensalada.',
                [],
                ['Huachinango' => 1000, 'Arroz' => 80, 'Limón' => 40, 'Ajo' => 10]],
            ['Filete al mojo de ajo', 'caliente', 215, 220, 5, null, 'Filete en mantequilla con ajo dorado. Con arroz.',
                [],
                ['Filete de pescado' => 250, 'Ajo' => 30, 'Mantequilla' => 40, 'Arroz' => 80]],
            ['Pulpo a las brasas', 'caliente', 310, 320, 4, 'pulpo-brasa', 'Pulpo asado a las brasas con mantequilla de ajo.',
                [],
                ['Pulpo' => 300, 'Mantequilla' => 30, 'Ajo' => 10, 'Arroz' => 80]],
        ]],
        ['Caldos', 'fuerte', [
            ['Caldo de camarón', 'caliente', 165, 170, 5, null, 'Caldo picosito de camarón con verduras.',
                [],
                ['Camarón' => 150, 'Jitomate' => 80, 'Chile guajillo' => 20, 'Cebolla morada' => 30, 'Limón' => 30, 'Tortilla de maíz' => 100]],
            ['Caldo siete mares', 'caliente', 215, 225, 5, 'caldo-mariscos', 'Caldo de mariscos surtidos con pescado, camarón y pulpo.',
                [],
                ['Camarón' => 100, 'Pulpo' => 60, 'Filete de pescado' => 100, 'Jitomate' => 100, 'Chile guajillo' => 20, 'Limón' => 30, 'Tortilla de maíz' => 100]],
            ['Sopa de mariscos', 'caliente', 195, null, 3, null, 'Sopa espesa de mariscos con un toque de chipotle.',
                [],
                ['Camarón' => 80, 'Pulpo' => 50, 'Filete de pescado' => 80, 'Jitomate' => 80, 'Cebolla morada' => 30]],
        ]],
        ['Tacos', 'fuerte', [
            ['Tacos de pescado (3)', 'caliente', 135, 139, 7, 'tacos-pescado', 'Pescado capeado con col, crema y salsa de la casa.',
                [['Tortilla de harina', 10]],
                ['Filete de pescado' => 150, 'Tortilla de maíz' => 100, 'Aguacate' => 30, 'Cebolla morada' => 20]],
            ['Tacos gobernador (3)', 'caliente', 165, 169, 6, null, 'Camarón con queso fundido y chile poblano.',
                [['Tortilla de harina', 10]],
                ['Camarón' => 150, 'Queso Oaxaca' => 80, 'Tortilla de maíz' => 100, 'Jitomate' => 30]],
            ['Tacos de camarón (3)', 'caliente', 155, 159, 5, null, 'Camarón capeado con col y aderezo de chipotle.',
                [['Tortilla de harina', 10]],
                ['Camarón' => 150, 'Tortilla de maíz' => 100, 'Aguacate' => 30]],
        ]],
        ['Para compartir', 'compartir', [
            ['Mariscada para dos', 'caliente', 640, 660, 2, 'mariscada', 'Camarón, pulpo, filete y ostiones gratinados, con arroz.',
                [],
                ['Camarón' => 300, 'Pulpo' => 200, 'Filete de pescado' => 200, 'Ostión' => 4000, 'Mantequilla' => 50, 'Ajo' => 20, 'Arroz' => 150]],
            ['Parrillada del mar (4 personas)', 'caliente', 1150, null, 1, null, 'Parrillada de camarón, pulpo, filete y pescado zarandeado.',
                [],
                ['Camarón' => 500, 'Pulpo' => 350, 'Filete de pescado' => 400, 'Pescado entero' => 800, 'Mantequilla' => 100, 'Arroz' => 300, 'Tortilla de maíz' => 200]],
            ['Torre de mariscos', 'fria', 560, 580, 2, null, 'Torre de camarón, pulpo y atún con aguacate y pepino.',
                [],
                ['Camarón' => 200, 'Pulpo' => 150, 'Atún fresco' => 100, 'Aguacate' => 100, 'Pepino' => 80, 'Salsa negra' => 40, 'Limón' => 50]],
        ]],
        ['Bebidas', 'bebida', [
            ['Michelada', 'barra', 85, 89, 9, 'michelada', 'Cerveza clara con limón, sal y salsas.',
                [['Con clamato', 15], ['Cerveza oscura', 5]],
                ['Cerveza clara' => 1000, 'Limón' => 30, 'Salsa negra' => 10]],
            ['Cerveza clara', 'barra', 55, 58, 10, null, 'Botella de 355 ml.', [], ['Cerveza clara' => 1000]],
            ['Cerveza oscura', 'barra', 60, 62, 5, null, 'Botella de 355 ml.', [], ['Cerveza oscura' => 1000]],
            ['Clamato preparado', 'barra', 95, 99, 3, null, 'Cerveza con clamato, limón y salsas.',
                [],
                ['Cerveza clara' => 1000, 'Clamato' => 250, 'Limón' => 30, 'Salsa negra' => 20]],
            ['Agua de jamaica (1 l)', 'barra', 55, 55, 7, 'agua-jamaica', 'Agua fresca de flor de jamaica.', [['Sin azúcar', 0]],
                ['Flor de jamaica' => 25, 'Azúcar' => 80]],
            ['Limonada mineral', 'barra', 50, 52, 5, null, 'Limón recién exprimido con agua mineral.', [],
                ['Limón' => 100, 'Azúcar' => 60, 'Agua mineral' => 1000]],
            ['Refresco', 'barra', 38, 40, 7, null, 'Refresco de 355 ml.', [], ['Refresco' => 1000]],
            ['Agua mineral', 'barra', 40, 42, 4, null, 'Botella de 355 ml.', [], ['Agua mineral' => 1000]],
            ['Café americano', 'barra', 38, 38, 2, null, 'Café de grano recién hecho.', [], ['Café molido' => 15, 'Azúcar' => 10]],
        ]],
        ['Postres', 'postre', [
            ['Flan napolitano', 'fria', 70, 72, 3, null, 'Flan casero con caramelo.', [], ['Flan (porción)' => 1000]],
            ['Pay de limón', 'fria', 75, 78, 3, null, 'Rebanada de pay de limón con galleta.', [], ['Pay de limón (rebanada)' => 1000]],
        ]],
    ];
}

/**
 * Sucursales, personal, plano, menú, equipos, insumos y recetas.
 *
 * @param array{clave:string,pin:string} $credenciales
 * @return array<string,mixed>
 */
function demo_catalogo(DemoSql $sql, DemoAzar $azar, DateTimeImmutable $ahora, array $credenciales): array
{
    $inicio = $ahora->setTime(0, 0)->modify('-21 days');
    $alta = $inicio->modify('-45 days')->setTime(10, 0)->getTimestamp();

    $sucursales = [
        1 => ['clave' => 'CEN', 'nombre' => 'El Timón Centro', 'calle' => 'Av. Reforma', 'numero' => '1520', 'colonia' => 'Centro',
            'cp' => '72000', 'id_municipio' => 1699, 'telefono' => '222 246 1520', 'latitud' => '19.0451200', 'longitud' => '-98.2061400',
            'whatsapp' => '2222461520', 'fondo' => 200000, 'red' => '192.168.10.', 'demanda' => [34, 36, 40, 44, 58, 82, 90],
            'reservas' => [2, 2, 3, 3, 5, 8, 9], 'retiro' => 500000, 'hielo' => [6, 9]],
        2 => ['clave' => 'CHO', 'nombre' => 'El Timón Cholula', 'calle' => 'Blvd. Forjadores de Puebla', 'numero' => '3204',
            'colonia' => 'San Bernardino Tlaxcalancingo', 'cp' => '72820', 'id_municipio' => 1704, 'telefono' => '222 283 3204',
            'latitud' => '19.0287300', 'longitud' => '-98.2552100', 'whatsapp' => '2222833204', 'fondo' => 150000,
            'red' => '192.168.20.', 'demanda' => [22, 24, 27, 30, 40, 56, 62], 'reservas' => [1, 1, 2, 2, 3, 5, 6],
            'retiro' => 300000, 'hielo' => [4, 6]],
    ];
    foreach ($sucursales as $id => $s) {
        $sql->agrega('sucursal', [
            'id' => $id, 'clave' => $s['clave'], 'nombre' => $s['nombre'], 'calle' => $s['calle'], 'numero' => $s['numero'],
            'colonia' => $s['colonia'], 'cp' => $s['cp'], 'id_estado' => 21, 'id_municipio' => $s['id_municipio'],
            'telefono' => $s['telefono'], 'latitud' => $s['latitud'], 'longitud' => $s['longitud'], 'id_estatus' => 4,
            'creado_en' => demo_fecha($alta), 'creado_por' => null,
            'horario_publico' => 'Lunes a domingo de 12:00 a 21:00', 'whatsapp_publico' => $s['whatsapp'],
        ]);
    }

    // Personal: [nombre, paterno, materno, puesto, sucursal, descanso (1 lunes … 7 domingo) o días de caja].
    $gente = [
        ['Mariana', 'Ortega', 'Ruiz', 'gerente', 1, null], ['Jorge', 'Méndez', 'Lara', 'cajero', 1, [1, 3, 5, 7]],
        ['Paola', 'Cruz', 'Huerta', 'cajero', 1, [2, 4, 6]], ['Luis Ángel', 'Romero', 'Díaz', 'mesero', 1, 1],
        ['Daniela', 'Flores', 'Sánchez', 'mesero', 1, 2], ['Ricardo', 'Vázquez', 'Pérez', 'mesero', 1, 3],
        ['Fernanda', 'Juárez', 'Morales', 'mesero', 1, 4], ['Emilio', 'Castillo', 'Reyes', 'mesero', 1, 1],
        ['Andrea', 'Núñez', 'Rosales', 'mesero', 1, 2], ['Rosa María', 'Aguilar', 'Torres', 'cocina', 1, null],
        ['Héctor', 'Salinas', 'Mora', 'cocina', 1, null], ['Juan Carlos', 'Ibarra', 'Soto', 'cocina', 1, null],
        ['Alejandro', 'Pineda', 'Gil', 'barra', 1, null], ['Ernesto', 'Domínguez', 'Ávila', 'almacen', 1, null],
        ['Sofía', 'Ramírez', 'Campos', 'gerente', 2, [2]], ['Diego', 'Herrera', 'Luna', 'cajero', 2, [1, 3, 4, 5, 6, 7]],
        ['Valeria', 'Gómez', 'Ortiz', 'mesero', 2, 1], ['Iván', 'Morales', 'Cano', 'mesero', 2, 2],
        ['Karla', 'Rivera', 'Sosa', 'mesero', 2, 3], ['Óscar', 'León', 'Treviño', 'mesero', 2, 4],
        ['Guadalupe', 'Martínez', 'Vega', 'cocina', 2, null], ['Raúl', 'Espinoza', 'Durán', 'cocina', 2, null],
        ['Brenda', 'Contreras', 'Paz', 'barra', 2, null],
    ];
    $claveHash = password_hash($credenciales['clave'], PASSWORD_DEFAULT);
    $pinHash = password_hash($credenciales['pin'], PASSWORD_DEFAULT);
    $personal = [];
    $gerentes = [];
    $id = DEMO_PRIMER_ID;
    foreach ($gente as [$nombre, $paterno, $materno, $puesto, $suc, $agenda]) {
        $usuario = demo_ascii(explode(' ', $nombre)[0]) . '.' . demo_ascii($paterno);
        $ingreso = $inicio->modify('-' . $azar->entero(60, 700) . ' days');
        $sql->agrega('personal', [
            'id' => $id, 'nombre' => $nombre, 'apellido_paterno' => $paterno, 'apellido_materno' => $materno,
            'id_puesto' => DEMO_PUESTOS[$puesto], 'id_sucursal' => $suc,
            'id_superior' => $puesto === 'gerente' ? null : ($gerentes[$suc] ?? null),
            'telefono' => null, 'correo' => null, 'fecha_ingreso' => $ingreso->format('Y-m-d'), 'fecha_baja' => null,
            'id_estatus' => 4, 'creado_en' => demo_fecha($alta), 'creado_por' => null, 'anonimizado_en' => null,
        ]);
        $sql->agrega('usuario', [
            'id' => $id, 'id_personal' => $id, 'usuario' => $usuario, 'clave_hash' => $claveHash, 'cambiar_clave' => 0,
            'sesion_version' => 1, 'id_estatus' => 4,
            'ultimo_acceso' => demo_fecha($ahora->getTimestamp() - $azar->entero(600, 86400)),
            'creado_en' => demo_fecha($alta), 'creado_por' => null, 'pin_hash' => $pinHash,
        ]);
        if ($puesto === 'gerente') {
            $gerentes[$suc] = $id;
        }
        $personal[] = ['id' => $id, 'usuario' => $usuario, 'nombre' => $nombre . ' ' . $paterno, 'puesto' => $puesto,
            'sucursal' => $suc, 'agenda' => $agenda];
        $id++;
    }
    foreach ($sucursales as $suc => &$s) {
        $s['gerente'] = $gerentes[$suc];
        $s['meseros'] = array_values(array_filter($personal, static fn ($p) => $p['sucursal'] === $suc && $p['puesto'] === 'mesero'));
        $s['cajeros'] = array_values(array_filter($personal, static fn ($p) => $p['sucursal'] === $suc
            && ($p['puesto'] === 'cajero' || ($p['puesto'] === 'gerente' && $p['agenda'] !== null))));
        $almacen = array_values(array_filter($personal, static fn ($p) => $p['sucursal'] === $suc && $p['puesto'] === 'almacen'));
        $s['almacen'] = $almacen[0]['id'] ?? $gerentes[$suc];
    }
    unset($s);

    // Plano. Mesas: [número, capacidad, forma, x, y]. `bloqueada` queda fuera de la operación.
    $planos = [
        1 => [
            'Salón' => [['S1', 2, 'redonda', 10, 15], ['S2', 2, 'redonda', 30, 15], ['S3', 4, 'cuadrada', 50, 15],
                ['S4', 4, 'cuadrada', 70, 15], ['S5', 4, 'cuadrada', 10, 45], ['S6', 4, 'cuadrada', 30, 45],
                ['S7', 4, 'cuadrada', 50, 45], ['S8', 4, 'cuadrada', 70, 45], ['S9', 6, 'rectangular', 15, 78],
                ['S10', 6, 'rectangular', 40, 78], ['S11', 8, 'rectangular', 65, 78], ['S12', 10, 'rectangular', 88, 50]],
            'Terraza' => [['T1', 4, 'redonda', 15, 20], ['T2', 4, 'redonda', 40, 20], ['T3', 4, 'redonda', 65, 20],
                ['T4', 4, 'redonda', 88, 20], ['T5', 6, 'rectangular', 25, 60], ['T6', 6, 'rectangular', 60, 60],
                ['T7', 2, 'redonda', 20, 88], ['T8', 2, 'redonda', 50, 88]],
            'Barra' => [['B1', 2, 'redonda', 15, 50], ['B2', 2, 'redonda', 38, 50], ['B3', 2, 'redonda', 62, 50],
                ['B4', 2, 'redonda', 85, 50]],
        ],
        2 => [
            'Salón' => [['S1', 2, 'redonda', 12, 15], ['S2', 2, 'redonda', 35, 15], ['S3', 4, 'cuadrada', 60, 15],
                ['S4', 4, 'cuadrada', 85, 15], ['S5', 4, 'cuadrada', 12, 50], ['S6', 4, 'cuadrada', 35, 50],
                ['S7', 4, 'cuadrada', 60, 50], ['S8', 6, 'rectangular', 85, 50], ['S9', 6, 'rectangular', 25, 85],
                ['S10', 8, 'rectangular', 65, 85]],
            'Jardín' => [['J1', 4, 'redonda', 15, 25], ['J2', 4, 'redonda', 45, 25], ['J3', 4, 'redonda', 75, 25, 'bloqueada'],
                ['J4', 6, 'rectangular', 20, 70], ['J5', 6, 'rectangular', 50, 70], ['J6', 10, 'rectangular', 80, 70]],
        ],
    ];
    $idArea = 1;
    $idMesa = 1;
    foreach ($planos as $suc => $areas) {
        $sucursales[$suc]['areas'] = [];
        $sucursales[$suc]['mesas'] = [];
        foreach ($areas as $nombreArea => $mesas) {
            $sql->agrega('area', ['id' => $idArea, 'id_sucursal' => $suc, 'nombre' => $nombreArea]);
            $sucursales[$suc]['areas'][$idArea] = $nombreArea;
            foreach ($mesas as $m) {
                // La mesa se escribe al final: su estado de hoy depende de la operación.
                $sucursales[$suc]['mesas'][$idMesa] = ['id' => $idMesa, 'id_area' => $idArea, 'numero' => $m[0],
                    'capacidad' => $m[1], 'forma' => $m[2], 'x' => $m[3], 'y' => $m[4], 'estado' => $m[5] ?? 'libre'];
                $idMesa++;
            }
            $idArea++;
        }
    }

    // Menú.
    $platillos = [];
    $idPlatillo = 1;
    $idModificador = 1;
    foreach (demo_menu() as $orden => [$categoria, $grupo, $lista]) {
        $idCategoria = $orden + 1;
        $sql->agrega('categoria_menu', ['id' => $idCategoria, 'nombre' => $categoria, 'orden' => ($orden + 1) * 10]);
        foreach ($lista as [$nombre, $preparacion, $precioCen, $precioCho, $peso, $foto, $descripcion, $modificadores, $receta]) {
            $sql->agrega('platillo', [
                'id' => $idPlatillo, 'id_categoria' => $idCategoria, 'nombre' => $nombre, 'descripcion' => $descripcion,
                'foto' => $foto === null ? null : '/recursos/menu/' . $foto . '.webp', 'preparacion' => $preparacion, 'activo' => 1,
            ]);
            $mods = [];
            foreach ($modificadores as [$nombreMod, $suplemento]) {
                $sql->agrega('modificador_platillo', ['id' => $idModificador, 'id_platillo' => $idPlatillo, 'nombre' => $nombreMod,
                    'suplemento' => demo_pesos($suplemento * 100), 'activo' => 1]);
                $mods[] = ['id' => $idModificador, 'nombre' => $nombreMod, 'suplemento' => $suplemento * 100];
                $idModificador++;
            }
            $platillos[$idPlatillo] = ['id' => $idPlatillo, 'nombre' => $nombre, 'grupo' => $grupo, 'preparacion' => $preparacion,
                'peso' => $peso, 'modificadores' => $mods, 'receta' => $receta, 'precios' => [1 => $precioCen * 100,
                    2 => $precioCho === null ? null : $precioCho * 100]];
            $idPlatillo++;
        }
    }
    // Lo agotado hoy: el callo en Centro y los ostiones en su concha en Cholula.
    $agotados = [1 => ['Callo de hacha'], 2 => ['Ostiones en su concha']];
    foreach ($sucursales as $suc => &$s) {
        $s['platillos'] = [];
        $s['agotados'] = [];
        foreach ($platillos as $p) {
            if ($p['precios'][$suc] === null) {
                continue;
            }
            $agotado = in_array($p['nombre'], $agotados[$suc], true);
            $sql->agrega('platillo_sucursal', ['id_sucursal' => $suc, 'id_platillo' => $p['id'],
                'precio' => demo_pesos($p['precios'][$suc]), 'agotado' => $agotado ? 1 : 0]);
            $s['platillos'][$p['id']] = $p['precios'][$suc];
            if ($agotado) {
                $s['agotados'][] = $p['id'];
            }
        }
    }
    unset($s);

    // Impresoras y equipos.
    $idImpresora = 1;
    $idEquipo = DEMO_PRIMER_ID;
    $equipos = [
        1 => [['Caja principal', 'caja', 'web'], ['Tableta Salón', 'mesero', 'android'], ['Tableta Terraza', 'mesero', 'android'],
            ['Pantalla de cocina', 'cocina', 'web'], ['Pantalla de barra', 'barra', 'web'], ['Puente de impresión', 'impresor', 'android'],
            ['iPad de gerencia', 'gerencia', 'ios']],
        2 => [['Caja', 'caja', 'web'], ['Tableta Salón', 'mesero', 'android'], ['Tableta Jardín', 'mesero', 'android'],
            ['Pantalla de cocina', 'cocina', 'web'], ['Pantalla de barra', 'barra', 'web'], ['Puente de impresión', 'impresor', 'android']],
    ];
    foreach ($sucursales as $suc => &$s) {
        $s['impresoras'] = [];
        foreach ([['Cocina caliente', 'caliente', '80'], ['Cocina fría', 'fria', '80'], ['Barra', 'barra', '58'], ['Caja', 'caja', '80']]
            as $n => [$nombre, $destino, $ancho]) {
            $sql->agrega('impresora', ['id' => $idImpresora, 'id_sucursal' => $suc, 'nombre' => $nombre, 'ip' => $s['red'] . (50 + $n),
                'puerto' => 9100, 'ancho' => $ancho, 'destino' => $destino, 'activa' => 1]);
            $s['impresoras'][$destino] = $idImpresora++;
        }
        foreach ($equipos[$suc] as [$nombre, $tipo, $plataforma]) {
            // Sin secreto conocido: estos equipos no pueden entrar. Un equipo real
            // se registra solo y se autoriza desde el panel.
            $sql->agrega('equipo', ['id' => $idEquipo, 'id_sucursal' => $suc, 'nombre' => $nombre, 'tipo' => $tipo,
                'plataforma' => $plataforma, 'codigo' => strtoupper($azar->hex(5)), 'identificador_hash' => $azar->hex(32),
                'config' => null, 'autorizado' => 1, 'creado_en' => demo_fecha($alta + 86400 * 30),
                'autorizado_en' => demo_fecha($alta + 86400 * 30 + 600)]);
            if ($tipo === 'impresor') {
                $s['impresor'] = $idEquipo;
            }
            $idEquipo++;
        }
    }
    unset($s);

    // Proveedores, insumos y recetas por sucursal.
    $insumos = demo_insumos();
    $idProveedor = 1;
    $idInsumo = 1;
    foreach ($sucursales as $suc => &$s) {
        $s['proveedores'] = [];
        foreach (demo_proveedores() as $grupo => [$nombre, $contacto]) {
            $sql->agrega('proveedor', ['id' => $idProveedor, 'id_sucursal' => $suc, 'nombre' => $nombre, 'contacto' => $contacto]);
            $s['proveedores'][$grupo] = $idProveedor++;
        }
        $usados = [];
        foreach (array_keys($s['platillos']) as $p) {
            foreach (array_keys($platillos[$p]['receta']) as $insumo) {
                $usados[$insumo] = true;
            }
        }
        $s['insumos'] = [];
        foreach ($insumos as $nombre => [$unidad]) {
            if (!isset($usados[$nombre])) {
                continue;
            }
            $sql->agrega('insumo', ['id' => $idInsumo, 'id_sucursal' => $suc, 'nombre' => $nombre, 'unidad' => $unidad]);
            $s['insumos'][$nombre] = $idInsumo++;
        }
        foreach (array_keys($s['platillos']) as $p) {
            foreach ($platillos[$p]['receta'] as $insumo => $milesimas) {
                $sql->agrega('receta_insumo', ['id_sucursal' => $suc, 'id_platillo' => $p, 'id_insumo' => $s['insumos'][$insumo],
                    'cantidad' => demo_cantidad($milesimas)]);
            }
        }
    }
    unset($s);

    return ['sucursales' => $sucursales, 'platillos' => $platillos, 'personal' => $personal, 'insumos' => $insumos,
        'proveedores' => demo_proveedores()];
}
