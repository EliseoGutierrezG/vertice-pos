<?php
declare(strict_types=1);

/**
 * Rutas de la API que consume la app.
 *
 * Van versionadas desde el primer día (`/api/v1`): una app instalada no se
 * actualiza cuando uno quiere, así que el servidor tendrá que sostener dos
 * versiones a la vez alguna vez.
 *
 * Tres niveles, de menos a más exigente:
 *   abierto     · salud y acceso: la app necesita esto ANTES de tener token
 *   con token   · sabe quién es, pero el equipo puede seguir en espera
 *   autorizado  · el equipo ya se autorizó desde el panel: opera
 *
 * Las fases del giro agregan aquí sus rutas: plano de mesas, cuentas, rondas,
 * `/cambios` para la sincronización en vivo y la cola de impresión.
 */

use Controladores\Api\Comanda;
use Controladores\Api\Entrada;
use Controladores\Api\EquipoRestaurante;
use Controladores\Api\Replica;
use Controladores\Api\Salud;
use Controladores\Web\SitioRestaurante;
use Nucleo\Giro;
use Nucleo\Middleware\ExigeDispositivo;
use Nucleo\Middleware\ExigeEquipo;
use Nucleo\Middleware\ExigeInstalacion;
use Nucleo\Middleware\ExigePermiso;
use Nucleo\Middleware\ExigeToken;
use Nucleo\Router;

return function (Router $r): void {
    // --- Abierto ------------------------------------------------------------
    $r->grupo('/api/v1', [ExigePermiso::class], function (Router $r): void {
        $r->get('/salud',   [Salud::class, 'ver'])->llamada('api.salud');
        $r->get('/app/apk', [Salud::class, 'apk'])->llamada('api.app.apk');
        $r->post('/entrar', [Entrada::class, 'entra'])->llamada('api.entrar');
        $r->post('/salir',  [Entrada::class, 'sale'])->llamada('api.salir');
        $r->post('/cambiar-clave', [Entrada::class, 'cambiaClave'])->llamada('api.cambiar_clave');
    });

    // --- Con token, aunque el equipo siga en espera --------------------------
    // Sirve para que la app pregunte "¿ya me autorizaron?" sin operar.
    $r->grupo('/api/v1', [ExigeToken::class, ExigePermiso::class], function (Router $r): void {
        $r->get('/yo', [Entrada::class, 'yo'])->llamada('api.yo');
    });

    // --- Con token y equipo autorizado ---------------------------------------
    $r->grupo('/api/v1', [ExigeToken::class, ExigeDispositivo::class, ExigePermiso::class], function (Router $r): void {
        $r->get('/estado', [Salud::class, 'listoParaSincronizar'])->llamada('api.estado');
    });
    if (!Giro::activo('restaurante')) {
        return;
    }

    $r->grupo('/api/v1', [ExigePermiso::class], function (Router $r): void {
        if (Giro::activo('sitio_publico')) {
            $r->get('/sucursales-publicas', [SitioRestaurante::class, 'sucursales'])->llamada('api.sitio.sucursales');
            $r->get('/redes', [SitioRestaurante::class, 'redes'])->llamada('api.sitio.redes');
            $r->get('/menu-publico/{sucursal:[a-zA-Z0-9]+}', [SitioRestaurante::class, 'menuPublico'])->llamada('api.sitio.menu');
            $r->post('/reservaciones', [SitioRestaurante::class, 'reserva'])->llamada('api.sitio.reserva');
        }
        $r->post('/equipo', [EquipoRestaurante::class, 'registra'])->llamada('api.equipo.registra');
        $r->get('/equipo', [EquipoRestaurante::class, 'estado'])->llamada('api.equipo.estado');
        $r->post('/equipo/entrar', [EquipoRestaurante::class, 'entra'])->llamada('api.equipo.entra');
    });

    // --- Servidores de sucursal: la réplica con el central --------------------
    $r->grupo('/api/v1/replica', [ExigeInstalacion::class, ExigePermiso::class], function (Router $r): void {
        $r->get('/catalogo', [Replica::class, 'catalogo'])->llamada('api.replica.catalogo');
        $r->get('/arranque', [Replica::class, 'arranque'])->llamada('api.replica.arranque');
        $r->post('/subida', [Replica::class, 'subida'])->llamada('api.replica.subida');
        $r->get('/liberacion', [Replica::class, 'liberacion'])->llamada('api.replica.liberacion');
        $r->get('/liberacion/paquete', [Replica::class, 'paquete'])->llamada('api.replica.paquete');
        $r->post('/actualizacion', [Replica::class, 'actualizacion'])->llamada('api.replica.actualizacion');
    });

    $r->grupo('/api/v1', [ExigeEquipo::class, ExigePermiso::class], function (Router $r): void {
        $r->post('/equipo/salir', [EquipoRestaurante::class, 'sale'])->llamada('api.equipo.sale');
        $r->post('/equipo/actividad', [EquipoRestaurante::class, 'actividad'])->llamada('api.equipo.actividad');
        $r->get('/plano', [Comanda::class, 'plano'])->llamada('api.comanda.plano');
        $r->get('/cambios', [Comanda::class, 'cambios'])->llamada('api.comanda.cambios');
        $r->get('/carta', [Comanda::class, 'menu'])->llamada('api.comanda.menu');
        $r->post('/carta/{id:\d+}/agotado', [Comanda::class, 'agota'])->llamada('api.comanda.agota');
        $r->get('/cuentas/{id:\d+}', [Comanda::class, 'cuenta'])->llamada('api.comanda.cuenta');
        $r->post('/cuentas', [Comanda::class, 'abre'])->llamada('api.comanda.abre');
        $r->post('/cuentas/{id:\d+}/{accion:cambia-mesa|une-mesa|items|edita-item|rondas|precuenta|estado-item|entrega|transfiere|cancelar|separa|reparte|reune}', [Comanda::class, 'accion'])->llamada('api.comanda.accion');
        $r->post('/mesas/{id:\d+}/limpia', [Comanda::class, 'limpiaMesa'])->llamada('api.comanda.mesa.limpia');
        $r->get('/pedidos', [Comanda::class, 'pedidos'])->llamada('api.comanda.pedidos');
        $r->get('/cocina', [Comanda::class, 'cocina'])->llamada('api.cocina.lista');
        $r->post('/cocina/{id:\d+}/{accion:preparar|listo|retomar|despachar}', [Comanda::class, 'cocinaAvanza'])->llamada('api.cocina.avanza');
        $r->get('/caja', [Comanda::class, 'caja'])->llamada('api.caja.estado');
        $r->post('/caja/{accion:abrir|cerrar|movimiento}', [Comanda::class, 'cajaAccion'])->llamada('api.caja.turno');
        $r->post('/mostrador/cotiza', [Comanda::class, 'cotiza'])->llamada('api.caja.cotiza');
        $r->post('/mostrador', [Comanda::class, 'mostrador'])->llamada('api.caja.mostrador');
        $r->post('/cuentas/{id:\d+}/cobro', [Comanda::class, 'cobra'])->llamada('api.caja.cobra');
        $r->get('/impresiones', [Comanda::class, 'trabajos'])->llamada('api.impresion.lista');
        $r->post('/impresiones/tomar', [Comanda::class, 'tomaImpresion'])->llamada('api.impresion.toma');
        $r->post('/impresiones/{id:\d+}/confirmar', [Comanda::class, 'confirmaImpresion'])->llamada('api.impresion.confirma');
        $r->post('/impresiones/{id:\d+}/reimprimir', [Comanda::class, 'reimprime'])->llamada('api.impresion.reimprime');
    });
};
