<?php
declare(strict_types=1);

/**
 * Rutas de la plataforma web.
 *
 * Leer este archivo debe bastar para saber qué protege a qué. Los
 * intermediarios se declaran aquí, nunca escondidos dentro del controlador.
 *
 * El orden importa:
 *   ExigeSesion  · sabe quién es, y carga sus permisos en una consulta
 *   ExigeClaveDefinitiva · con una contraseña temporal sólo se puede
 *                  cambiarla o salir (`#[Accion(conClaveTemporal: true)]`)
 *   ExigeMarca   · la marca CSRF en todo lo que cambia algo
 *   ExigePermiso · lee por reflexión qué exige la acción, y lo comprueba
 *
 * ExigePermiso va en TODAS, incluidas las públicas: así una acción sin
 * atributo #[Accion] se rechaza siempre, y el descuido falla cerrado.
 */

use Controladores\Sistema\Diagnostico;
use Controladores\Web\BitacoraWeb;
use Controladores\Web\CajaConsultaWeb;
use Controladores\Web\Sucursales;
use Controladores\Web\DispositivosWeb;
use Controladores\Web\Entrada;
use Controladores\Web\MarcaWeb;
use Controladores\Web\Perfil;
use Controladores\Web\Restaurante;
use Controladores\Web\SitioRestaurante;
use Controladores\Web\PersonalWeb;
use Controladores\Web\SegundoFactorWeb;
use Controladores\Web\PrivacidadWeb;
use Controladores\Web\SeguridadWeb;
use Controladores\Web\SesionWeb;
use Controladores\Web\ServidoresWeb;
use Controladores\Web\AvisosWeb;
use Controladores\Web\Tablero;
use Nucleo\Giro;
use Nucleo\Middleware\ExigeClaveDefinitiva;
use Nucleo\Middleware\ExigeEnvioUnico;
use Nucleo\Middleware\ExigeEscrituraDeSucursal;
use Nucleo\Middleware\ExigeMarca;
use Nucleo\Middleware\ExigePermiso;
use Nucleo\Middleware\ExigeSesion;
use Nucleo\Router;

return function (Router $r): void {
    $r->grupo('', [ExigeEscrituraDeSucursal::class, ExigeMarca::class, ExigePermiso::class], function (Router $r): void {
        // La raíz es la landing pública: en el servidor la sirve
        // `.htaccess` desde `sitio/`. Si llega aquí —en local no hay `sitio/`—,
        // se manda al panel con la misma consulta.
        $r->get('/', [Tablero::class, 'raiz'])->llamada('raiz');
        if (Giro::activo('restaurante')) {
            $r->get('/ticket/{token:[a-f0-9]+}', [SitioRestaurante::class, 'ticket'])->llamada('sitio.ticket');
            $r->get('/fotos-menu/{clave:[a-f0-9]+}.webp', [SitioRestaurante::class, 'foto'])->llamada('sitio.foto');
            if (Giro::activo('sitio_publico')) {
                $r->get('/menu/{sucursal:[a-zA-Z0-9]+}', [SitioRestaurante::class, 'carta'])->llamada('sitio.menu');
                $r->get('/robots.txt', [SitioRestaurante::class, 'robots'])->llamada('sitio.robots');
                $r->get('/sitemap.xml', [SitioRestaurante::class, 'mapaSitio'])->llamada('sitio.mapa');
            }
        }
        $r->get('/aviso-privacidad', [PrivacidadWeb::class, 'aviso'])->llamada('privacidad.aviso');
        $r->get('/entrar',  [Entrada::class, 'formulario'])->llamada('entrada.formulario');
        $r->post('/entrar', [Entrada::class, 'entra'])->llamada('entrada.entra');
        $r->get('/segundo-factor', [SegundoFactorWeb::class, 'formulario'])->llamada('segundo_factor.formulario');
        $r->post('/segundo-factor', [SegundoFactorWeb::class, 'valida'])->llamada('segundo_factor.valida');
        $r->get('/segundo-factor/configurar', [SegundoFactorWeb::class, 'configurar'])->llamada('segundo_factor.configurar');
        $r->post('/segundo-factor/configurar', [SegundoFactorWeb::class, 'confirma'])->llamada('segundo_factor.confirma');
        $r->get('/segundo-factor/codigos', [SegundoFactorWeb::class, 'codigos'])->llamada('segundo_factor.codigos');
        // La marca visual de la instalación: colores y logotipo
        // validados por `MarcaVisual`. Públicas, porque las usa Entrar.
        $r->get('/marca/tema.css', [MarcaWeb::class, 'tema'])->llamada('marca_visual.tema');
        $r->get('/marca/logo', [MarcaWeb::class, 'logo'])->llamada('marca_visual.logo');
    });

    $r->grupo('', [ExigeEscrituraDeSucursal::class, ExigeSesion::class, ExigeClaveDefinitiva::class, ExigeMarca::class, ExigePermiso::class, ExigeEnvioUnico::class], function (Router $r): void {
        $r->get('/panel',  [Tablero::class, 'ver'])->llamada('tablero');
        $r->get('/perfil', [Perfil::class, 'ver'])->llamada('perfil.ver');
        $r->post('/salir', [Entrada::class, 'sale'])->llamada('entrada.sale');
        // El aviso antes de vencer (homologación §S): consultar no cuenta como uso.
        $r->get('/sesion/estado', [SesionWeb::class, 'estado'])->llamada('sesion.estado');
        $r->post('/sesion/renovar', [SesionWeb::class, 'renueva'])->llamada('sesion.renueva');
        $r->get('/sesion/lista', [SesionWeb::class, 'lista'])->llamada('sesion.lista');
        $r->get('/cambiar-clave',  [Perfil::class, 'clave'])->llamada('perfil.clave');
        $r->post('/cambiar-clave', [Perfil::class, 'cambiaClave'])->llamada('perfil.cambia_clave');

        if (Giro::activo('restaurante')) {
            $r->get('/areas', [Restaurante::class, 'areas'])->llamada('restaurante.areas');
            $r->get('/areas/{id:\d+}', [Restaurante::class, 'verArea'])->llamada('restaurante.area.ver');
            $r->post('/areas', [Restaurante::class, 'guardaArea'])->llamada('restaurante.area.crea');
            $r->post('/areas/{id:\d+}', [Restaurante::class, 'guardaArea'])->llamada('restaurante.area.actualiza');
            $r->get('/mesas', [Restaurante::class, 'mesas'])->llamada('restaurante.mesas');
            $r->get('/mesas/plano', [Restaurante::class, 'planoSalon'])->llamada('restaurante.plano');
            $r->get('/mesas/{id:\d+}', [Restaurante::class, 'verMesa'])->llamada('restaurante.mesa.ver');
            $r->post('/mesas', [Restaurante::class, 'guardaMesa'])->llamada('restaurante.mesa.crea');
            $r->post('/mesas/{id:\d+}', [Restaurante::class, 'guardaMesa'])->llamada('restaurante.mesa.actualiza');
            $r->get('/mesas/{id:\d+}/qr', [SitioRestaurante::class, 'qrMesa'])->llamada('restaurante.mesa.qr');
            $r->post('/mesas/{id:\d+}/posicion', [Restaurante::class, 'mueveMesa'])->llamada('restaurante.mesa.mueve');
            $r->post('/{plano:areas|mesas}/{id:\d+}/baja', [Restaurante::class, 'bajaPlano'])->llamada('restaurante.plano.baja');
            $r->get('/categorias-menu', [Restaurante::class, 'categorias'])->llamada('restaurante.categorias');
            $r->get('/categorias-menu/{id:\d+}', [Restaurante::class, 'verCategoria'])->llamada('restaurante.categoria.ver');
            $r->post('/categorias-menu/{id:\d+}/baja', [Restaurante::class, 'bajaCategoria'])->llamada('restaurante.categoria.baja');
            $r->get('/platillos', [Restaurante::class, 'platillos'])->llamada('restaurante.platillos');
            $r->get('/platillos/{id:\d+}', [Restaurante::class, 'verPlatillo'])->llamada('restaurante.platillo.ver');
            $r->post('/{catalogo:categorias-menu|platillos|modificadores}', [Restaurante::class, 'guardaCatalogo'])->llamada('restaurante.catalogo.crea');
            $r->post('/{catalogo:categorias-menu|platillos|modificadores}/{id:\d+}', [Restaurante::class, 'guardaCatalogo'])->llamada('restaurante.catalogo.actualiza');
            $r->post('/platillos/{id:\d+}/disponibilidad', [Restaurante::class, 'disponibilidad'])->llamada('restaurante.platillo.disponibilidad');
            $r->post('/platillos/precios', [Restaurante::class, 'precios'])->llamada('restaurante.platillos.precios');
            $r->get('/promociones', [Restaurante::class, 'promociones'])->llamada('restaurante.promociones');
            $r->get('/promociones/{id:\d+}', [Restaurante::class, 'verPromocion'])->llamada('restaurante.promocion.ver');
            $r->post('/promociones', [Restaurante::class, 'guardaPromocion'])->llamada('restaurante.promocion.crea');
            $r->post('/promociones/{id:\d+}', [Restaurante::class, 'guardaPromocion'])->llamada('restaurante.promocion.actualiza');
            $r->post('/promociones/{id:\d+}/{accion:pausar|reanudar|baja}', [Restaurante::class, 'estadoPromocion'])->llamada('restaurante.promocion.estado');
            $r->get('/carta', [Restaurante::class, 'carta'])->llamada('restaurante.carta');
            $r->get('/carta/hoja', [Restaurante::class, 'hojaCarta'])->llamada('restaurante.carta.hoja');
            $r->get('/carta/huella', [Restaurante::class, 'huellaCarta'])->llamada('restaurante.carta.huella');
            $r->post('/carta/textos', [Restaurante::class, 'guardaTextosCarta'])->llamada('restaurante.carta.textos');
            $r->get('/equipos-comanda', [Restaurante::class, 'equipos'])->llamada('restaurante.equipos');
            $r->post('/equipos-comanda', [Restaurante::class, 'autorizaEquipo'])->llamada('restaurante.equipo.autoriza');
            $r->post('/equipos-comanda/{id:\d+}/autorizar', [Restaurante::class, 'autorizaPendiente'])->llamada('restaurante.equipo.pendiente');
            $r->post('/equipos-comanda/{id:\d+}', [Restaurante::class, 'actualizaEquipo'])->llamada('restaurante.equipo.actualiza');
            $r->post('/equipos-comanda/{id:\d+}/retirar', [Restaurante::class, 'retiraEquipo'])->llamada('restaurante.equipo.retira');
            $r->post('/perfil/pin', [Restaurante::class, 'cambiaPin'])->llamada('restaurante.pin');

            $r->get('/impresoras', [Restaurante::class, 'impresoras'])->llamada('restaurante.impresoras');
            $r->get('/impresoras/{id:\d+}', [Restaurante::class, 'verImpresora'])->llamada('restaurante.impresora.ver');
            $r->post('/impresoras', [Restaurante::class, 'guardaImpresora'])->llamada('restaurante.impresora.crea');
            $r->post('/impresoras/{id:\d+}', [Restaurante::class, 'guardaImpresora'])->llamada('restaurante.impresora.actualiza');
            $r->get('/reservaciones', [Restaurante::class, 'reservaciones'])->llamada('restaurante.reservaciones');
            $r->post('/reservaciones', [Restaurante::class, 'reservaManual'])->llamada('restaurante.reserva.manual');
            $r->get('/reservaciones/{id:\d+}', [Restaurante::class, 'verReserva'])->llamada('restaurante.reserva.ver');
            $r->post('/reservaciones/{id:\d+}', [Restaurante::class, 'reservaAccion'])->llamada('restaurante.reserva.cambia');
            $r->post('/sucursales/datos-publicos', [Restaurante::class, 'datosPublicos'])->llamada('restaurante.sucursal.publica');
            $r->get('/inventario/{tipo:insumos|lotes|compras|proveedores|recetas|movimientos}', [Restaurante::class, 'inventario'])->llamada('restaurante.inventario');
            $r->get('/inventario/{tipo:compras|movimientos}/exportar', [Restaurante::class, 'inventarioExporta'])->llamada('restaurante.inventario.exporta');
            $r->get('/inventario/{tipo:insumos|proveedores}/exportar', [Restaurante::class, 'catalogoExporta'])->llamada('restaurante.inventario.catalogo_exporta');
            $r->get('/inventario/compras/{id:\d+}', [Restaurante::class, 'verCompra'])->llamada('restaurante.compra.ver');
            $r->get('/inventario/compras/{id:\d+}/recibir', [Restaurante::class, 'recibirCompra'])->llamada('restaurante.compra.recibir');
            $r->get('/inventario/{tipo:insumos|proveedores}/{id:\d+}', [Restaurante::class, 'verCatalogoInventario'])->llamada('restaurante.inventario.catalogo');
            $r->post('/inventario/{tipo:insumos|proveedores}/{id:\d+}', [Restaurante::class, 'cambiaCatalogoInventario'])->llamada('restaurante.inventario.edita');
            $r->post('/inventario/{tipo:insumos|proveedores}/{id:\d+}/baja', [Restaurante::class, 'cambiaCatalogoInventario'])->llamada('restaurante.inventario.baja');
            $r->post('/inventario/{accion:insumo|compra|recibir|cancelar-compra|proveedor|receta|merma|conteo|existencia-inicial}', [Restaurante::class, 'inventarioAccion'])->llamada('restaurante.inventario.guarda');
            $r->get('/gastos', [Restaurante::class, 'gastos'])->llamada('restaurante.gastos');
            $r->get('/gastos.xlsx', [Restaurante::class, 'gastosExporta'])->llamada('restaurante.gastos.exporta');
            $r->post('/gastos', [Restaurante::class, 'gastoRegistra'])->llamada('restaurante.gasto.registra');
            $r->get('/gastos/{id:\d+}', [Restaurante::class, 'verGasto'])->llamada('restaurante.gasto.ver');
            $r->post('/gastos/{id:\d+}', [Restaurante::class, 'corrigeGasto'])->llamada('restaurante.gasto.corrige');
            $r->post('/gastos/{id:\d+}/cancelar', [Restaurante::class, 'cancelaGasto'])->llamada('restaurante.gasto.cancela');
            $r->get('/caja/turnos', [CajaConsultaWeb::class, 'lista'])->llamada('restaurante.turnos.lista');
            $r->get('/caja/turnos/{id:\d+}', [CajaConsultaWeb::class, 'ver'])->llamada('restaurante.turnos.ver');
            $r->get('/caja/turnos/exportar', [CajaConsultaWeb::class, 'exporta'])->llamada('restaurante.turnos.exporta');
            $r->get('/inventario/faltantes', [Restaurante::class, 'faltantes'])->llamada('restaurante.faltantes.lista');
            $r->post('/inventario/faltantes/{id:\d+}/atender', [Restaurante::class, 'atiendeFaltante'])->llamada('restaurante.faltante.atiende');
            $r->get('/reportes', [Restaurante::class, 'reportes'])->llamada('restaurante.reportes');
            $r->get('/reportes/vivo', [Restaurante::class, 'reporteVivo'])->llamada('restaurante.reportes.vivo');
            $r->get('/reportes/exportar/{formato:csv|pdf|xlsx}', [Restaurante::class, 'reporteExporta'])->llamada('restaurante.reportes.exporta');
        }

        // --- Sucursales -------------------------------------------------------
        // Leer lo pide `organizacion_ver`; cambiar, `organizacion_admin`. Los
        // formularios viven en modales y se mandan por `fetch`, pero cada POST
        // funciona igual como formulario de toda la vida.
        $r->get('/sucursales.xlsx',                           [Sucursales::class, 'exporta'])->llamada('sucursales.exporta');
        $r->get('/sucursales',                                [Sucursales::class, 'lista'])->llamada('sucursales.lista');
        $r->post('/sucursales',                               [Sucursales::class, 'crea'])->llamada('sucursales.crea');
        $r->get('/sucursales/{id:\d+}',                       [Sucursales::class, 'ver'])->llamada('sucursales.ver');
        $r->post('/sucursales/{id:\d+}',                      [Sucursales::class, 'edita'])->llamada('sucursales.edita');
        $r->post('/sucursales/{id:\d+}/baja',                 [Sucursales::class, 'baja'])->llamada('sucursales.baja');
        $r->post('/sucursales/{id:\d+}/reactiva',             [Sucursales::class, 'reactiva'])->llamada('sucursales.reactiva');

        // --- Servidores de sucursal (réplica con el central) --------------------
        $r->get('/servidores', [ServidoresWeb::class, 'lista'])->llamada('servidores.lista');
        $r->post('/servidores', [ServidoresWeb::class, 'registra'])->llamada('servidores.registra');
        $r->post('/servidores/{id:\d+}/regresar', [ServidoresWeb::class, 'regresa'])->llamada('servidores.regresa');
        $r->post('/servidores/versiones', [ServidoresWeb::class, 'subeVersion'])->llamada('servidores.sube_version');
        $r->post('/servidores/version', [ServidoresWeb::class, 'asignaVersion'])->llamada('servidores.asigna_version');


        // --- Personal, usuarios y equipos ------------------------------------
        // Leer lo pide `personal_ver`; cambiar, `personal_admin`. El usuario
        // sólo nace desde una persona: no hay `POST /usuarios`.
        $r->get('/personal',                              [PersonalWeb::class, 'lista'])->llamada('personal.lista');
        $r->get('/personal.xlsx',                         [PersonalWeb::class, 'exporta'])->llamada('personal.exporta');
        $r->post('/personal',                             [PersonalWeb::class, 'crea'])->llamada('personal.crea');
        $r->get('/personal/{id:\d+}',                     [PersonalWeb::class, 'ver'])->llamada('personal.ver');
        $r->get('/personal-detalle/{id:\d+}',             [PersonalWeb::class, 'detalleModal'])->llamada('personal.detalle_modal');
        $r->post('/personal/{id:\d+}',                    [PersonalWeb::class, 'edita'])->llamada('personal.edita');
        $r->post('/personal/{id:\d+}/baja',               [PersonalWeb::class, 'baja'])->llamada('personal.baja');
        $r->post('/personal/{id:\d+}/reactiva',           [PersonalWeb::class, 'reactiva'])->llamada('personal.reactiva');
        $r->post('/personal/{id:\d+}/usuario',            [PersonalWeb::class, 'creaUsuario'])->llamada('personal.usuario.crea');
        $r->post('/personal/{id:\d+}/usuario/sucursales', [PersonalWeb::class, 'asignaSucursales'])->llamada('personal.usuario.sucursales');
        $r->post('/personal/{id:\d+}/usuario/clave',      [PersonalWeb::class, 'restableceClave'])->llamada('personal.usuario.clave');
        $r->post('/personal/{id:\d+}/usuario/segundo-factor', [PersonalWeb::class, 'restableceSegundoFactor'])->llamada('personal.usuario.segundo_factor');
        $r->post('/personal/{id:\d+}/usuario/baja',       [PersonalWeb::class, 'bloqueaUsuario'])->llamada('personal.usuario.baja');
        $r->post('/personal/{id:\d+}/usuario/reactiva',   [PersonalWeb::class, 'reactivaUsuario'])->llamada('personal.usuario.reactiva');

        $r->get('/dispositivos',                   [DispositivosWeb::class, 'lista'])->llamada('dispositivos.lista');
        $r->get('/dispositivos.xlsx',              [DispositivosWeb::class, 'exporta'])->llamada('dispositivos.xlsx');
        $r->get('/dispositivos/{id:\d+}',          [DispositivosWeb::class, 'ver'])->llamada('dispositivos.ver');
        $r->post('/dispositivos/{id:\d+}/autoriza', [DispositivosWeb::class, 'autoriza'])->llamada('dispositivos.autoriza');
        $r->post('/dispositivos/{id:\d+}/retira',   [DispositivosWeb::class, 'retira'])->llamada('dispositivos.retira');
        $r->post('/dispositivos/notificacion', [DispositivosWeb::class, 'notifica'])->llamada('dispositivos.notifica');

        // Avisos a varios equipos.
        $r->get('/avisos',              [AvisosWeb::class, 'lista'])->llamada('avisos.lista');
        $r->get('/avisos.xlsx',         [AvisosWeb::class, 'exporta'])->llamada('avisos.xlsx');
        $r->get('/avisos/{id:\d+}',     [AvisosWeb::class, 'ver'])->llamada('avisos.ver');
        $r->post('/avisos',             [AvisosWeb::class, 'envia'])->llamada('avisos.envia');

        // Seguridad y privacidad.
        $r->get('/seguridad',                  [SeguridadWeb::class, 'ver'])->llamada('seguridad.ver');
        $r->get('/privacidad',                       [PrivacidadWeb::class, 'lista'])->llamada('privacidad.lista');
        $r->get('/privacidad.xlsx',                  [PrivacidadWeb::class, 'exportaSolicitudes'])->llamada('privacidad.xlsx');
        $r->get('/privacidad/solicitudes/{id:\d+}', [PrivacidadWeb::class, 'verSolicitud'])->llamada('privacidad.ver');
        $r->post('/privacidad/solicitudes',          [PrivacidadWeb::class, 'registra'])->llamada('privacidad.registra');
        $r->post('/privacidad/solicitudes/{id:\d+}/cerrar', [PrivacidadWeb::class, 'cierra'])->llamada('privacidad.cierra');
        $r->get('/privacidad/{tipo:empleado}/{id:\d+}/datos', [PrivacidadWeb::class, 'exporta'])->llamada('privacidad.exporta');
        $r->post('/privacidad/{tipo:empleado}/{id:\d+}/anonimizar', [PrivacidadWeb::class, 'anonimiza'])->llamada('privacidad.anonimiza');
        $r->get('/seguridad/accesos',          [SeguridadWeb::class, 'accesos'])->llamada('seguridad.accesos');
        $r->get('/seguridad/accesos.xlsx',     [SeguridadWeb::class, 'accesosXlsx'])->llamada('seguridad.accesos.xlsx');
        $r->get('/seguridad/accesos.csv',      [SeguridadWeb::class, 'accesosCsv'])->llamada('seguridad.accesos.csv');
        $r->post('/seguridad/accesos/revision', [SeguridadWeb::class, 'registraRevision'])->llamada('seguridad.accesos.revision');
        $r->post('/seguridad/segundo-factor',  [SeguridadWeb::class, 'segundoFactor'])->llamada('seguridad.segundo_factor');

        // --- Bitácora ---------------------------------------------------------
        // Sólo se lee. No hay POST aquí y no debe haberlo: una bitácora que la
        // aplicación puede corregir no contesta «¿quién movió esto?».
        $r->get('/bitacora', [BitacoraWeb::class, 'lista'])->llamada('bitacora.lista');
        $r->get('/bitacora.csv', [BitacoraWeb::class, 'csv'])->llamada('bitacora.csv');
        $r->get('/bitacora.xlsx', [BitacoraWeb::class, 'exporta'])->llamada('bitacora.xlsx');
        $r->get('/bitacora/{id:\d+}', [BitacoraWeb::class, 'ver'])->llamada('bitacora.ver');

        $r->get('/sistema/diagnostico', [Diagnostico::class, 'ver'])->llamada('sistema.diagnostico');
    });
};
